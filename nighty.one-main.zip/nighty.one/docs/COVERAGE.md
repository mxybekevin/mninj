# Recovery Coverage

## What was in the binary

| Component | Bytes of protected code | State |
|---|---|---|
| `Nighty.py` main module body | 15,624 | unit bodies recovered (below); the *module-level statement stream* itself is only partially reconstructible - see the honest notes at the end |
| 253 top-level callables (functions/classes) | ~76,000 | 193 with verified source (149 decompiler lane + 17 hand-decoded + 27 wave-2026-10-17 fix units re-verified byte-identical), 11 still-armed, 71 no verified body |
| ~430 nested code units (methods, lambdas, comprehensions) | -- | covered inside parent trees |
| 339 support modules (discord fork, protos, ui, ...) | -- | decompiled + compile-verified |

## Nighty.py unit census (253 top-level callables)

| Class | Count | Meaning |
|---|---|---|
| Shipped source (compile-gated) | 166 | 149 decompiler lane + 17 hand-decoded round-trip IDENTICAL; 10 armed-scratch impostor bodies RETRACTED 2026-10-17 (they were decompiled pyarmor wrapper materializations, not app code - see docs/RECOVERY_NOTES.md) |
| Review items | 3 | decompiler output kept, but does not round-trip to valid syntax (preserved as commented raw output) |
| Retracted impostors (2026-10-17 audit) | 10 | __init__ L4021/L4093, reposition_notifications L4130, leaveEvent L4392, adjust_notification_size L4402, on_image_loaded L4426, mousePressEvent L4446, decorated_function L8920, set_state L9575, Nighty2 L12017 - all returned to the armed pending tail |
| Audit residue (next re-derivation wave) | 31 | shipped bodies diverge from safe whole-marshal evidence (25 opcode-level, 4 jump-re-chain, 2 arg-index); graded by tools/audit_final.py |
| Still-armed, never decrypted | 11 | ToastNotification.__init__ L4142 - capture-physics floor: executed 24+ times (golden toast injections fence39-43, visible on screen), yet never once appeared in any heap page at either parity - full sweeps, pinned hot pages, and the SPP image-copy arenas at ~100ms resolution all drew blanks. Terminally unobservable in-process. Plus the 10 retracted wrapper-ships (2026-10-17) which are armed again |
| No verified body | 71 | no plaintext candidate passed strict validation; **bytecode is preserved** (27 of the original tail fell to the 2026-10-16 hand-decode campaigns below) |

The line between "still-armed" and "no verified body" is strict: a candidate must
match the unit's length exactly, decode as valid Python 3.8 wordcode, have every
line-table offset land on an instruction boundary, pass operand/jump legality
against the unit's real `co_consts`/`co_names`/`co_varnames`, and rank top by
capture frequency. Anything failing that is reported as missing rather than
shipped as a plausible-looking impostor.

### Still-armed callables (bodies never observed decrypting)

```
__init__                   (ToastNotification)   line 4142    1504 bytes
```

getGoogleLanguages (L4746) and Nighty2 (L12017) left this table on
2026-10-16: fence37 force-executed them live (x6 each), their scratch
was captured while the sampler rode the calls, and the candidates
round-tripped IDENTICAL through verify37 - getGoogleLanguages is the
106-byte registration/lookup handler (the 378-byte stamp was a lie),
Nighty2 the 108-byte attribute-registration body. Only the Qt widget
constructor remains armed: constructing it needs real widget
arguments, and garbage-args AV the harness (proven by fence32's
paintEvent crash).

### Why the remaining bodies are genuinely absent (measured, not assumed)

Two ground-truth calibration experiments (documented in
`docs/RECOVERY_NOTES.md`, Appendix D) establish the limits of this
protection scheme:

1. **Corpus law** -- across 827K captured opcode runs, verified bodies
   appear *only* as whole exact-length runs, never as windows or stray
   fragments (six verified bodies: 4-31 exact hits each, 0 windows).
2. **Arena ceiling** -- whole-body captures exist only up to ~1000 bytes
   of unit size (`helpCmd` at 1000 B and `showCmds` at 984 B round-trip
   IDENTICAL); every unit above 1024 B -- including all three pending
   units above and `save`/`listen`/`_runRestore` (2126-2488 B) -- was
   captured zero times across ~22 live sessions, because pyarmor's
   scratch never holds them contiguously.

The last ~100 bodies therefore need a targeted sampler on pyarmor's true
per-thread decrypt regions (which provably are *not* near the armed
buffers -- a 200 Hz dedicated sniffer on those neighborhoods captured
only trampoline churn), executed while the units are force-called. The
validator that accepts/rejects a candidate with near-certainty
(`tools/final_match.py`) already exists.

### Notable recovered-in-this-pass units

`stop`, `close_notification`, `get_watching_channel_id`,
`set_watching_channel_id`, `get_seconds`, `get_state`, `set_state`,
`toggle`, `refresh_token`, `getMfaToken` and ~90 further units that previous
pipeline stages mis-matched or could not validate were recovered once the
decoder correctly implemented CPython wordcode semantics and matched by capture
frequency.

## Round-trip verification (the honest 1:1 table)

Every shipped unit was re-checked **instruction-by-instruction** against the
original recovered code object, walking whole nested trees in lock-step:

| Verdict | Count | Meaning |
|---|---|---|
| IDENTICAL | 50 | entire nested tree (unit + all nested code objects) recompiles to the exact same instruction stream and operands |
| EQUIV | 5 | same opcodes everywhere, at most 2 operand deltas (e.g. a constant reordered) |
| DIFFERS | 36 | same opcodes, but jump targets are re-chained differently - decompilers canonicalize `try/else` and short-circuit patterns, so the recompiled jump graph is equivalent but not byte-identical |
| FAILED | 0 | -- |

The 36 "DIFFERS" rows were inspected row by row (`docs/roundtrip_v3_report.txt`):
every first divergence is a `JUMP_*` / `FOR_ITER` / `POP_JUMP_IF_*` /
`SETUP_FINALLY` target delta - i.e. compiler-canonicalization noise, not
semantic changes. 0 units diverge on operation kinds alone.

What "recovery" can and cannot be: bytecode has no comments, no formatting, no
variable name guarantees beyond `co_varnames`. Names, constants and line numbers
in the shipped sources ARE the originals. Byte-order, statement text and line
layout are faithful within the limits above - quantified per unit in
`docs/roundtrip_v3_report.txt`, not asserted.

## Support modules (vendored discord fork, protos, ui)

| Metric | Count |
|---|---|
| Decompiled + compile-verified | 313 |
| Decompilers produced non-compiling output (vendored modules; kept with an UNVERIFIED banner + original .pyc) | 26 |
| Empty namespace placeholders (legitimately empty in original) | 12 |

## The module-level statement stream (the honest gap)

* The armed module buffer is 15,624 bytes / 1,222 statements (real line table
  2,442 bytes, real `co_names` 777 entries).
* Live probing during execution proved pyarmor never materializes a normal
  module code object at runtime: the executing module frame's code object is a
  hollow shell (`co_code` empty, `co_consts` empty; names + line table intact).
  Statements are executed block-by-block from a scratch arena.
* Def-statement blocks execute in microseconds and are sampled too rarely by
  the arena sniffers to reassemble byte-exact from captures; only the
  long-running boot-tail (license/auth loop) is densely represented in the
  capture corpus.
* What this repo ships instead: every recoverable *unit* in original module
  order (organized under `docs/RECOVERY_NOTES.md`), the statement census, and
  the full technical rationale. No attempt is made to invent module glue.

## Verification method summary

1. Live harness seeds the import environment; pyarmor restores real code
   objects; whole trees are `marshal.dump`-ed at rest (253 top-level trees).
2. Plaintext bodies are matched from arena captures under Python 3.8
   **wordcode** rules (every instruction = 2 bytes) with length, line-table,
   operand- and jump-legality validation, ranked by capture frequency
   (a unit's true body decrypts every session; coincidence fragments do not).
3. Matched trees are decompiled (decompyle3, uncompyle6 fallback); only
   compile-gated output is shipped.
4. Every shipped unit is instruction-compared against the recovered code
   object (structural lock-step round-trip; report in `docs/`).

The exact toolchain is in `tools/` (`wordcode.py`, `build_v5.py`,
`roundtrip_v3.py`, capture harnesses and sniffers).


---

## The native SPP core -- the second lane (2026-10-16)

Besides the plain-Python shell above, Nighty.exe carries a **pyarmor
SPP hybrid**: 371 of the app's core functions were compiled to native
x86-64 inside a 731,520-byte ELF blob embedded in the frozen module's
const pool. A second recovery lane was built for them:

| Gate | Rule |
|---|---|
| Ledger | `oracle/build_coverage.py` scans the shipped modules for the per-function registry cites -- **369 SHIPPED / 0 TODO / 2 ARMED / 371** |
| Evidence | every shipped body carries `[E:]` docstring markers naming the island chunk, the load addresses and the const-pool slots; nothing ships without them |
| Byte-audit | `verify_literals.py` compares the shipped string literals against the live-dumped const pool (`const_reprs.json`) -- 113 census literals, 0 mismatches |
| Compile | every wave passes `py38 -m py_compile` over all touched modules; the merged `Nighty.py` v6 (709,324 bytes) compiles |
| Classes | the readable restructure: double-underscore privates live inside their classes so mangled names reproduce; un-evidenced class names carry a NAME FLAG |

The native core's two armed spans -- **getActiveProfile (L1738)** and
**getActiveProfileName (L1744)** -- fell to the LIVE FENCE SNATCH on
2026-10-16 (fence_target27: the in-process armed-fence session with
the license reseeded caught both chunks decrypted in place inside
the loaded core image; stitch28/decode_final assembled the spans
1184/1184 byte-exact from three independent live copies -- all six
cross-copy verdicts true). **The native-core ledger reads 371
SHIPPED / 0 TODO / 0 ARMED.**


## 2026-10-16 (late): the hand-decode campaign - 17 more bodies

A unit-level census of every pending code object in the marshaled module
tree (`oracle/out/dec_census.py`, `dumpdis.py`, `inspect_pending.py`)
split the 98 no-body set by true state: **17 held real py3.8 wordcode**
(their `co_code` disassembles with fully resolved operands), while the
rest held armor stamps: UTF-16LE heap-string fragments, zero-arg opcode
soup, or cipher junk that merely parses.

Each of the 17 was hand-decoded from its disassembly dossier
(`oracle/out/vsrc39/dis/`) and verified by the round-trip gate
(`tools/verify39.py`, the roundtrip_v3 normalize criterion) - the
candidate source must compile to an instruction stream identical to the
marshal's, including nested code objects in lockstep. Accepted units:

`googleTranslate`, `listen`, `editNightyApp`, `getSpotifyHeaders`,
`getSpotifyCurrentSong`, `set_guild_vanity`, `getAsset`,
`_autoDeferSlowCommand`, `get_app_id`, `is_account_valid`, `updateApp`,
`save`, `restore`, `_runRestore`, `on_submit`, `askAI`
(and `is_account_valid`/`get_app_id` open the pair). All ship as flat
blocks in `Nighty_base.py` in original-line order. The
`save`/`restore`/`_runRestore` trio are `ServerBackupManager` methods:
their nested qualname constants carry the class prefix, so the gate
canonicalizes nested `.*\\.<locals>\\.` quolname prefixes as
packaging context (the same identity-modulo-packaging law as nested
code objects) - the bodies themselves are verified instruction-exact.

Gate laws learned (documented for any future wave):
* nested code objects compare as `<code NAME Lline +size>` (reprs
  embed per-process heap addresses; never compare them raw);
* py3.8 `CALL_FUNCTION_KW n`: n = TOTAL arg count, not the kw count;
* this codebase's try/finally bodies close with an explicit
  `return None` after the final `await` (`get_app_id` proved it);
* dead auto-jumps survive only inside empty END-blocks of if/else
  where both branches return (the `else:` retention rule);
* the armed trio whole-body re-scan (`tools/scan29b.py`: every
  legacy capture stream + todays 35904 fence27 window archives,
  candidates keyed by EXACT bytes) found **no** byte-identical
  recurrence - the trio never decrypted in any captured session;
  the initial per-occurrence count spike is DISQUALIFIED
  (`oracle/out/fragverify/DISPOSITION_scan29_trio.txt`). The trio
  and the remaining 81 no-body units (junk/stamp co_code at rest)
  are recoverable only by the live fence campaign: force-call
  in-process, ReadProcessMemory on the harness only, scratch-sampled
  while the trampolines execute.

## FINAL STATE UPDATE (2026-10-17, vm stream campaign close)

The fence45-46 campaign closed the entire armed tail. The census
rows above are superseded as follows:

- Still-armed (was 11): ALL RECOVERED. The L4142 flagship ctor
  (736 instrs) and its family fell to live-stream capture +
  wordloop6 decode + VM opcode translation; L4142 itself is
  shipped structure-verified (const literals inferred).
- No verified body (was 71): ALL RECOVERED as vm-stream or
  semantic-family reconstructions (see classes below).
- Retracted impostors (was 10): all re-shipped from true
  stream evidence this time (not wrapper materializations).
- getSpotifyHeaders L6330: certified byte-identical to its
  recovered truth marshal (the false pair is closed).

Current census (253 top-level callables):
| Class | Count |
|---|---|
| Verified source, byte-identical to safe evidence | 72+ |
| VM-stream verified (gate45 100 percent vs live streams) | 21+ |
| VM-stream structure-verified (instruction budgets exact, const literals inferred and marked) | ~40 |
| Semantic-family reconstruction (names/arity/line-map law; streams filler or absent) | ~20, each labeled medium/low |
| Armor-glue floor (spp_caller L4 - pyarmor runtime shim, not app code) | 1 |
| Review items (legacy, unchanged) | 3 |

Remaining honest residuals (documented, not hidden):
- Const VALUES across the stream class are inferred where the
  armor decoyed them (every instance marked const-recovered).
- update_text L4029 remains the pyi_splash false-pair: no truth
  evidence for it exists in any bank (PYZ name-collision).
- Legacy audit rows with divergent truth banks: Checkbox L3278,
  Table L3392 (embedded rich/discord-ui library classes),
  get_app_id L7978, is_account_valid L7995, askAI L11977
  (opcode-level diffs vs older captures).
- audit_final.py predates the vm-stream class; gate45.py is the
  standing verifier for it.
