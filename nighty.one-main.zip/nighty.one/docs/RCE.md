# RCE surface in Nighty - what the recovery proves

Several of these are not bugs in the classic sense. They are a remote code
execution architecture, deliberate and load-bearing. Everything below cites
the recovered, byte-verified source (`../source/Nighty.py`, graded in
`../docs/COVERAGE.md`) or artifacts shipped inside the exe itself.

## 1. Remote Python eval over the websocket (original line 9136)

`handle_execute_js` is a flask-socketio event handler. It takes `code` off
the wire and feeds it to Python `eval` directly:

```python
def handle_execute_js(data):
    js_code = data.get('code', '')
    logging.info(f'Executing JavaScript: {js_code}')
    try:
        result = eval(js_code)          # PYTHON eval, wire-controlled
        emit('js_result', {'result': result})
    except Exception as e:
        emit('js_result', {'error': str(e)})
```

Byte-verified: `names(-armor)=('get','logging','info','eval','emit',
'Exception','str')` with the 8-byte eval call slot at original line 9144.
The unit's marshal evidence is `dec_handle_execute_js_2664158310224.marshal`.

The socket it serves is not loopback-only. `startFlaskServer` (line 8807
region, and observed live in the rebuild boot logs) binds the socketio app
to `0.0.0.0:80` by default - every machine on the LAN can reach it.

Gates on the path:

- `handle_connect` (line 9127) requires `session['user_id']`, or the
  socket is disconnected.
- `handle_preflight` (line 9108) answers CORS preflights with
  `Access-Control-Allow-Origin: *` plus `Access-Control-Allow-Credentials:
  true`.

The web login that mints the session lives in the never-recovered module
wiring. The web config defaults are `{'username': None, 'password': None,
'host': '0.0.0.0', 'port': 80}` - what None credentials authorize on that
login route is the one open question this repo cannot answer from
evidence.

## 2. The shipped web panel evals whatever the socket sends it

`web/index.html` inside the exe (the 3.2 MB React bundle the flask server
serves) contains this, verbatim:

```js
const socket = io();
socket.on('execute_js', (data) => {
    const result = eval(data.code);     // browser-side eval
    socket.emit('js_result', { success: true, result: result, code: data.code });
});
```

Both ends of this socket `eval` the same event name. The Python side
names its handler parameter `js_code` but passes it to Python `eval`. A
code-execution fabric in both directions is the design.

## 3. Arbitrary registered functions over HTTP (original line 9295)

`safe_add_individual_route` exposes any Python function as an HTTP
endpoint with caller-controlled arguments:

```python
def safe_add_individual_route(func):
    route = f'/api/custom/{func.__name__}'
    def handler():
        if request.method == 'OPTIONS':
            return jsonify()
        data = request.get_json(silent=True) or {}
        args = data.get('args', [])
        kwargs = data.get('kwargs', {})
        result = func_to_handle(*args, **kwargs)
        return jsonify({'success': True, 'result': result})
    web_app.route(route, methods=['POST', 'OPTIONS'], ...)(handler)
```

POST `/api/custom/<name>` with `{"args": [...], "kwargs": {...}` calls the
function with arbitrary parameters. The handler applies no session check
of its own; whether the registration call sites wrapped these routes with
`login_required` lived in the unrecovered module wiring.

## 4. The webview bridge reaches Python from remote pages (line 8829)

`add_custom_function` bolts functions onto the pywebview `js_api` object:

```python
def add_custom_function(self, func):
    setattr(self, func.__name__, MethodType(func, self))
```

Every method on a pywebview `js_api` object is callable from JavaScript as
`window.pywebview.api.<name>()`. The windows these bridges ride in load
**nighty.one-hosted pages** (`auth.html`, `discord_login.html`,
`app_verification_mfa.html`, `app_verification_pass.html` - recovered
`load_url` call sites, original lines 12560-12572) and even
`https://discord.com/login` (`addWebAccount`, line 8869, with
`js_api=WebLoginApi()`). Whoever controls the served page controls what
runs in a webview that can reach Python.

Combined with 1-3 the kill chain is short: serve one modified page, or one
POST to the LAN port, and the user's machine runs the operator's Python.

## 5. The script engine is exec-by-design (lines 5007-5027)

```python
def inject(self, scriptname, code):
    ...
    exec(code, globals(), local_scope)
```

Local scripts from `%APPDATA%/Nighty Selfbot/scripts` execute with full
globals. Benign on its own - but items 1-4 can write files, and
`reloadBot` (line 5539) flushes and reloads the injection state over a
fresh `wss://eu.nighty.one/v2` connection. Persistence composes.

## Verdict

For the plain-language version of what this means for people who ran the app, see the "if you ever ran nighty, read this" section in the repo README.

Any one of items 1-4 is a working remote code execution path against
Nighty users; together they are redundant ones. The `eval` handler is the
cleanest single receipt: a byte-verified, wire-controlled Python `eval`
on a LAN-bound socket with permissive CORS. This is what a "remote
support" backdoor looks like when it grows organically.

The rebuild in this repo ships all of these surfaces **neutered**: the
dummy auth never contacts the real servers, `handle_execute_js` and the
custom-route factory are documented but the rebuild wiring never
registers them, and the webview loads the local flask only.
