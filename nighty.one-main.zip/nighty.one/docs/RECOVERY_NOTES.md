# SESSION NOTES - update 2026-10-13 (late)

## BREAKTHROUGHS TODAY

### 1. The module fully executes WITHOUT a tracer (~12,785 lines verified)
- `sys.settrace` (any visibility at pyarmor restore time) = anti-trace sabotage
  path: module defines `spp_export_api` armed function, "EOF" errors, exits
  before definitions. NO TRACER = full body executes on <frozen Nighty>.
- PyArmor executes the module with globals = `sys.modules['__main__'].__dict__`
  (that's what "Loaded module __main__ not found in sys.modules" refers to).
  So the armed module defines everything into the harness script's own
  namespace. All definitions land as real objects.
- spp/license: never actually a license gate for execution. The "EOF read
  where object expected" prints = the module's own except-handler printing a
  failed pyarmor-internal marshal (innocuous). Fake spp module in sys.modules
  is unnecessary-but-harmless; module runs fine either way once import env
  is correct.

### 2. The real blockers were IMPORT-ENVIRONMENT bugs (all fixed now)
The module's try/except catches ANY ImportError and exits early. Fixes:
- `PYZ.pyz_extracted` had 44 empty 16-byte pycs (namespace/empty entries) --
  wrote VALID synthesized empty-module bodies + fixed flat ShadowFiles
  (`zope.pyc`, `discord\ext.pyc`, ... shadowing real dirs). -> fix_empties.py
- native .pyds live in package dirs at the extract ROOT, invisible to the
  PYZ-path-resolved packages -> mirrored 78 pyds (cryptography\_rust.pyd,
  gevent, PyQt5, google\_upb, ...) -> mirror_natives.py
- CArchive data files (lua scripts, tcl/tk data, everything else) ->
  extracted 3423 files to PYZ_extracted with correct base offset
  (cookie at 105079923, base=394752) -> extract_data_files.py
- env: TCL_LIBRARY/TK_LIBRARY = PYZ_extracted\_tcl_data / _tk_data
- pywin32: sys.path += extract\win32 + PYZ\win32 (win32crypt imports flat)
- jaraco.text via pip helper site `oracle\py38_extra` on sys.path
- os._exit patched to raise SystemExit (app's shutdown unwinds to us)
- the APP OVERWRITES stdlib names in __main__ (e.g. `threading` becomes
  engineio.async_drivers.threading!) -> snapshot stdlib refs as X_* aliases

### 3. Armed callables harvest (at rest = SAFE reads; mid-exec reads are POISON)
- fence_target6/7/9/10: import-wrapper scan records identities mid-run
  (getattr-level only); at-rest full_dump reads co_code + metadata safely.
- 184-253 armed top-level callables recorded per run (L4-L8919!):
  getLicense, isValidKey, updateKey, ToastNotification.*, NightyUserApp,
  _cc_AsyncWebSocket.*, helpCmd, botCmd, MainApi.addAccount, ...
- mid-execution co_code reads corrupted pytransform state (ZipImportError /
  hang / crashes) - NEVER read a buffer while its unit executes.
- force-calling armed functions WORKS (faulthandler showed
  "<frozen Nighty>", line 4365 in paintEvent executing from our call, armed
  worker threads running at 4467). Qt GUI natives (paintEvent etc) AV the
  process -> exclude name endswith Event / paint / show / exec.

### 4. THE DECRYPT MODEL IS SETTLED (the BIG one)
- sniffer7 VirtualProtectEx-poller: 9.1 MILLION probes on 104 known armed
  buffers over 215s while force-calls executed them: ZERO page-protection
  changes. Armed co_code buffers are READABLE at all times and NEVER change.
- Conclusion: pyarmor's decrypted blocks are NEVER written into the co_code
  buffer. Execution uses PRIVATE SCRATCH COPIES in the heap (matches the
  earlier t=1245ms capture: pages with plain LOAD_CONST/BUILD_STRING/
  CALL_METHOD/STORE_DEREF + docstrings right during restore).
- plainscan (v1) was wrong: it required the trampoline next to diffs.
  plainscan2/3 scan captured streams for PLAIN opcode runs directly.
- If scratch pages appear in the heap/hammer/grab/windows stores, we can
  recover executed blocks directly from captures.

### 5. Capture runs inventory
- windows.marshal (sniffer3): per-buffer page versions (697) - small
- hammer_stream.bin: 133MB records [addr][len][t][page]
- heap_stream.bin: ~961MB full-heap page captures (append mode)
- grab_stream.bin: 125MB (sniffer6 stop-and-grab)
- fence_calls_run*.log: armed callable identities + buffer addresses
- out/dump: metaA_*.pkl + codeA_*.bin (armed baselines at rest, 440+)
- t6_epi.txt / t7_dump_*.txt: full 184-253 callable inventories

## NEXT
- plainscan3 (running) over all streams looking for plain opcode runs
- match runs to known units via lnotab+names+consts, merge per-unit coverage
- rebuild + decompile the 111 PLAIN units (real partial Nighty.py source!)
- static cipher reverse via pytransform.pyd if dynamic coverage thin

## LATE-BREAKING (2026-10-13 evening)

### 6. plainmatch pipeline - WORKS END TO END
- `unitA_*.marshal` dumps = whole pyarmor-RESTORED code objects (marshal.dumps
  of the live objects - pyarmor already resolved ALL refs/consts/names!)
- their consts contain NESTED units mostly PLAIN (208) + 83 armed tops
- plainscan3 found 21,444 unique plain-opcode runs across all streams
  (windows/hammer/grab/heap) - the private scratch copies ARE in captures
- plainmatch: exact-length + lnotab-boundary validation -> 76/83 armed tops
  recovered; decrypted trees rebuilt (out/decrypted/dec_*.marshal)
- build_decrypted: decompyle3 over whole trees -> 246/253 FULL SOURCE files
  in out/decrypted_src/*.py  (0 failures final pass)
- assemble_nighty.py -> recovered_src/NIGHTY_RECOVERED.py (2020 lines,
  151 whole callables with REAL bodies + 7 still-armed markers)
- REAL recovered source confirmed: refresh_token MFA flow (discord.com/api/v9
  /mfa/finish), spoofed_identify device fingerprints, isTokenValid, toasts...

### 8. Final-day discoveries (17:00+)
- **the first-session "support module decompiles" were garbage**: decompyle3
  prints a grammar-rule dump to CONSOLE and writes the REAL .py to -o dir;
  the old bulk script captured console output. bulk_redecompile.py now
  decompiles + compile()-verifies every file (out/vsrc = verified trees).
- **assemble_final.py**: decompiles dec_*.marshal trees in-memory and emits
  Nighty.py as REAL code - def scaffolds, async fixed (3.8 CO_COROUTINE
  flag = 0x80, not 0x100!), per-unit compile gate, quirk repairs (backtick
  strings, comprehension ternary). RESULT: Nighty.py 2,389 lines,
  COMPILES CLEAN, 148 clean units / 3 review (kept commented) / 7 armed.
- **the "silent force-thread death" mystery solved**: gevent's
  monkey.patch_all() swaps time.sleep mid-run; any *bare* time.sleep call
  in harness threads becomes a hub-sleep that never wakes a raw OS thread
  once the main-thread hub blockts on app greenlets. ONLY _real_sleep
  (the reference saved before the app ran) is safe in harness threads.
- module_done must be defined at module top (threads read it before the
  main flow reaches the exec section).
- app flow variance decoded: %APPDATA%\\Nighty Selfbot auth.json = license
  state. {"license": null} or a stale key -> the app enters its WEBVIEW
  license-wizard which loops forever headless (webview.start patched ->
  NoneType.load_url AttributeError every ~1.5s). The module never finishes
  defining. Deleting auth.json restores the deep-run flow (davey + ico +
  blocked + full defs) in ~10s.
- Remaining armed, precisely: the module body (15624B) + 7 units:
  get/set_watching_channel_id, Nighty2 (1052B), stop, close_notification,
  ToastNotification.__init__ (1504B), getGoogleLanguages. Documented in
  COVERAGE.md; their scratch never got sampled (they never executed in
  any captured session).



## Final round corrections (wordcode, capture counts, honest round-trip)

**The root cause found late in the project:** every custom decoder in the
pipeline stepped 1 byte after "no-argument" opcodes. In CPython 3.6-3.8,
*wordcode* means EVERY instruction occupies exactly 2 bytes
([op][arg-or-0x00-padding]). The stray x00 bytes that looked like
corruption or pyarmor padding were ordinary argument padding of no-arg opcodes.
Consequences fixed in the final pass:

* run extraction, length matching, line-table validation and all audits were
  re-implemented with 2-byte stepping (	ools/wordcode.py);
* "same length + legal operands" alone admits junk fragments from unrelated
  code (they decode fine but have unparseable jump structure - decompilers then
  emit nothing). The discriminator: a unit's TRUE body is restored by pyarmor
  in every session, so it appears in captures with high multiplicity. The
  corpus is now kept as a Counter and candidates are picked by frequency
  (	ools/build_v5.py);
* this converted ~95 previously mislabeled/missing units into real shipped
  bodies and shrank the still-armed list from 7 to 3
  (Nighty2, ToastNotification.__init__, getGoogleLanguages - none of these
  ever executed during any capture session, so their plaintext was never in
  the arena to sample).

**Live module probe (t12 harness + sys._current_frames):** the executing
module frame's code object is a hollow shell - co_code = empty,
co_consts = empty; only names (777) and the line table survive. The
"module statement stream" never exists as normal bytecode at runtime, which
together with the def-blocks' microsecond residency explains why no contiguous
span of it was ever captured.

**Round-trip truth table (v3, wordcode-correct, structural lock-step):**
50 IDENTICAL / 5 EQUIV (<=2 operand deltas) / 36 canonicalized-jump deltas /
0 FAILED across the 149 clean shipped units - full rows in
docs/roundtrip_v3_report.txt. Earlier, more optimistic claims
("148 byte-accurate") were based on a broken comparator and are superseded by
this table.

**Flow variance irreducibility:** the app's auth path nondeterministically
gates BEFORE the definition block (only a handful of units defined) or after
it (full 253 harvest). It happens with identical appdata state and CPU load.
Pass/focus ownership therefore moved into the scan thread (t14), with
watchdog heartbeats. Anti-tamper kills the harness threads at ~10s in the
gated flow; native-window teardown (unpatched webview.create_window) kills
the whole process at ~12-17s in the wizard flow.

======================================================================
Appendix D - the 'trigger everything' round (final capture engineering)
======================================================================

Motivation: the pending bodies were called 'never executed', but they can be
forced to execute; live-execution is the only decrypt mechanism.

What was done this round:
- Identified Nighty2 (line 12017) as the auth/startup orchestrator - it
  executes in EVERY session; the webview 'login loop' is Nighty2's own
  web-login branch. Its body was never captured whole because the scratch
  arena caps at ~1 KB (see below).
- Seeded the real license key and removed the socket blackholing for live
  sessions: the license server round-trip slows the early auth gate enough
  that the module's 253-def block completes first (deep flow) instead of
  stalling at rec=1 (gated flow). The app's server rejects the key and
  rewrites auth.json to null - each session must reseed.
- Online deep-flow sessions rebuilt: Nighty2 executing, toast UI drawing,
  getGoogleLanguages force-called with correct arity. A dedicated sniffer
  (fence_sniffer5.py) sampled the target buffers' neighborhoods ~200x/sec;
  multi_session.ps1 ran batches of four sessions, reseeding each time.

Ground-truth measurements (tools: calibrate.py, calib2.py):
1. THE CORPUS LAW - bodies appear in captures ONLY as whole exact-length
   runs. Six verified bodies: exact-run hits 4-31 each, WINDOW hits 0.
   Implication: no fragment/window assembly can ever work from this
   capture model - matching must find the whole run or nothing.
2. THE ARENA CEILING - whole-body captures exist only up to ~1000 bytes
   (helpCmd 1000B and showCmds 984B round-trip IDENTICAL); every unit over
   1024 bytes (Nighty2 1052B, ToastNotification.__init__ 1504B, save 2274B,
   listen 2126B, _runRestore 2488B ...) was captured ZERO times in ~22
   sessions - the pyarmor scratch never holds them contiguously.
3. THE SCRATCH ADDRESS - the dedicated 200Hz sampler on the buffers'
   +-16KB neighborhoods recorded only 16-142B trampoline/control churn and
   ZERO whole-length candidates: the decrypt scratch does NOT live near the
   armed buffers; sniffer3 catches bodies only when its wide +-64KB sweeps
   overlap the real per-thread scratch by luck.

Statistical validator calibrated this round (profile_window.py):
- learned a real-code opcode log-likelihood profile from all verified
  bodies (floor -7.9, threshold -8.245) - this cleanly rejects the
  cipher-decode noise (repeating BINARY_RSHIFT/DELETE_DEREF/EXTENDED_ARG
  chains) that gamed every purely syntactic validator.
- correctness note: CPython 3.8's dis.stack_effect() raises for no-arg
  opcodes given an oparg (GET_AWAITABLE et al) - stack walks must use the
  argless form for ops < HAVE_ARGUMENT.

Final verified state (unchanged from the main table):
- 149 shipped unit bodies compile-verified; instruction-level round-trip:
  50 IDENTICAL, 5 EQUIV (<=2 operand deltas), 36 decompiler
  jump-canonicalization deltas, 0 failures; instruction-count audit:
  115 exact, 34 small deltas, 0 truncations.
- Pending, with the exact reason now measured: 3 armed never-captured
  (Nighty2, ToastNotification.__init__, getGoogleLanguages) + 99 units
  whose bodies never appeared as whole runs in any capture. Their metadata
  (names, varnames, signatures, line tables) is intact and their
  armed/cipher bodies are preserved in tools output for future work.

The precise continuation path (for finishing the last ~100 bodies):
reverse pyarmor super-mode's scratch allocator to locate the per-thread
decrypt regions at runtime (they are not addressed near the armed
buffers), then run a focused sampler on those exact pages during
force-called executions of the pending units. Every validator needed to
accept or reject a candidate body with near-certainty already exists in
tools/ (final_match.py: length + legality + line-table + profile).

======================================================================
Appendix E - recovery tooling vs. recovered source (purity guarantee)
======================================================================

NONE of the capture-session scaffolding exists in the recovered source:

* the DNS/network gating (blocking Discord endpoints so the owner's
  client was not disturbed during capture sessions), the webview /
  dialog / os.exit stubs, the fake spp_export_api module, sleep capping,
  frame grabbers, hunters and sniffers are ALL runtime monkey-patches
  that live only inside the harness process (tools/fence_target*.py,
  tools/fence_sniffer*.py);
* every .py file shipped in this repository is compiled from the code
  objects recovered FROM THE ORIGINAL BINARY (live-restored trees and
  capture-matched ciphertext), decompiled and compile-gated - nothing
  was authored, and no stub behavior ever reached the shipped files;
* the final capture round also produced false positives worth noting:
  in-process hunts of tiny candidates can read NATIVE x86-64 code
  (function prologues like 'push r15; push r14...' decode as valid
  wordcode). Every candidate for units under ~32 bytes was rejected
  accordingly; nothing from that batch was integrated.


======================================================================
2026-10-16 - THE NATIVE CORE CLOSED AT 369/371; REA DEPLOYED
======================================================================

The native-core lane (the SPP ELF's 371 functions) reached
369 SHIPPED / 0 TODO / 2 ARMED, measured by the everything-register
(oracle/build_coverage.py -> oracle/out/coverage.txt). The final
wave shipped seven functions: the complete settings-backup store
listBackups/resolveBackup/autocompleteChoices with its trailing-zone
sort key; the VoicemuteSettingsView split (the registry interleaves
TWO discord View classes - the callback families and the
'Voicemute >> Settings' embed title lock the boundary);
getActiveCtxMenus + extract_chat_response; safe_add_individual_route
with its Flask CORS handler; and verifyDevPortalMfa, the chunk-8829
totp twin of verifyDevPortalPass (all deltas address-staged: sig
CONST[557], 'totp' CONST[569], window 1075x670, the CONST[576]
watcher byte-identical to the pass variant's CONST[580] copy).

Laws added to the workbook this arc:

* THE CHUNK-KEY LAW - an island dump is keyed by the NEXT registry
  line, so a function's body lives under its successor's key.
* THE TRAILING ZONE - nested code objects live past the last
  registry span (on_closed's epilogue at 0xa91e0); the handler of
  safe_add is a full prologue at 0xa93a0, the listBackups sort-key
  lambda decodes at 0x9e530; a raw-address capstone pass over the
  dump_island preamble reaches them.
* STORE_GLOBAL EMISSIONS - a9d50 name-load + value-store pairs
  outside any function frame are `global X` declarations
  (__all_notifications__, __custom_ui_tabs__).
* POOL-EXACT F-STRINGS - splitting an f-string across implicit
  concatenation can cut a pool literal in half and produce pieces
  that never existed; the verify_literals byte-audit (113 census
  literals) catches the drift before any commit.
* THE CONSOLE REPR TRAP - const displays mangle glyphs and strips
  look like tags; disputed slots must be hex-probed from
  const_reprs.json (the extract_chat_response pattern slot 230 is
  r'</think\s*(.*)' - the closing-tag thinking stripper).
* REPARSE + ENCODING traps on the host side - PowerShell `>`
  writes UTF-16; the working directory is a junction chain whose
  C: paths REA's Windows P0 admission refuses (use the real D:
  paths for native analysis).

REA (github.com/morluto/rea, npm rea-agents 6.5.0) is deployed as
the native-analysis harness: rea doctor reports the Ghidra provider
HEALTHY against the staged portable stack (tools/ghidra_12.1.4_PUBLIC
+ tools/jdk-21.0.12.1+1; verified version 12.1.4, x64 decompile.exe,
JDK 21.0.12.1, Job Object/DACL/reparse controls). The cold import
of oracle/pytransform.pyd.orig is running; the goal is the armed
pair getActiveProfile (L1738) / getActiveProfileName (L1744):
decompile the armed-blob load/decrypt path in the pyarmor runtime -
if the key material is static the two 1184-byte cipher chunks
decrypt offline; if runtime-keyed the pseudocode becomes the
blueprint for the live fence session (fence_target* harness class,
license reseeded, ReadProcessMemory only, never touching the
owner's Discord client).


======================================================================
2026-10-16 (late) - THE ARMED PAIR FELL: 371/371
======================================================================

getActiveProfile (L1738) and getActiveProfileName (L1744) - the
last two armed-cipher spans - recovered by a live fence snatch:

* fence_target27 = the armed-fence session (the fence_target26
  harness class; ReadProcessMemory on the harness process ONLY,
  never any other process; the license reseeded in
  %APPDATA%/Nighty Selfbot/auth.json). The sniffer thread walked
  the process regions from before the bootstrap exec and archived
  4096-byte window dumps at every SPP 8-push prologue it found.
* The bootstrap boot itself executed the app deep into the web
  settings window - and the armed chunks sat DECRYPTED IN PLACE
  inside THREE loaded copies of the spp core image
  (live bases 0x28a966b6920 / 0x28a96d05f78 / 0x28a96e60040;
  pyarmor's spp load makes whole-image copies, so rip-relative
  GOT refs stay valid - which is why in-place decryption is the
  only coherent mechanism).
* triage27 matched every window against the static image, derived
  each window's implied live base, and found the windows covering
  the two armed chunk offsets (0x1f120/0x1f5c0 +1184B). stitch28
  assembled both spans 1184/1184 byte-exact; decode_final trimmed
  at each epilogue ret and verified: ALL SIX cross-copy verdicts
  byte-identical.
* Both bodies decode as the profile twins: getConfigData() ->
  config.get('logins', {}) -> logins.items() with the sel-8
  identity compare (data.get('active') is True); the found path
  returns the VALUE dict (getActiveProfile) or the KEY string
  (getActiveProfileName); the exhaust runs the implicit-None
  epilogue. The registry chunk-1750 bound sits 0x40 past the Name
  twin's true entry (the chunk-start artifact law).
* Shipped into profiles_and_files.py with full [E:] live-capture
  citations; the byte-audit 113/113; the ledger now reads
  **371 SHIPPED / 0 TODO / 0 ARMED / 371** (commits df8787d +
  1be3e88).
* REA got the last word on the armor: xrefs on pytransform's own
  spp strings resolve to the four loader sites - 'Call spp code
  out of pyarmor' @0x6d604e27, 'Init spp mode failed' @0x6d6060cc,
  'Failed to alloc memory for spp code' @0x6d60979b, '<sppcode>'
  @0x6d60bcf8.


======================================================================
2026-10-16 (night) - THE HAND-DECODE CAMPAIGN: 17 PLAIN-LANE BODIES
======================================================================

Unit census of the 101-row pending tail (per code object state):

* 17 units with REAL py3.8 wordcode in the v5 marshals (incl. the big
  ones: listen 2126B, save 2274B, _runRestore 2488B - every async
  client family the decompilers could never emit);
* ~13 UTF-16LE heap-string arrays masquerading as code
* ~9 zero-arg opcode-soup armor stamps (POP_TOP x37 etc.)
* 1 dis-crashing cipher stub; the rest: cipher-at-rest states
* the 3 still-armed trio (74-stub armed, never decrypted)

The fleet: seven parallel decode squads (subagents) with the shared
round-trip gate (tools/verify39.py - roundtrip_v3 normalize, jumps as
ordinals, nested trees in lockstep). The gate is the only acceptance
authority: every shipped body compiled to an IDENTICAL instruction
stream against its marshal. Two gate canonicalizations discovered
mid-campaign now documented in COVERAGE.md: nested code-object
constants (per-process heap reprs) and class-prefixed nested qualnames
(packaging context; the ServerBackupManager trio).

Shipped (17): googleTranslate, listen, editNightyApp,
getSpotifyHeaders, getSpotifyCurrentSong, set_guild_vanity, getAsset,
_autoDeferSlowCommand, get_app_id, is_account_valid, updateApp, save,
restore, _runRestore, on_submit, askAI + the campaign's finished list
in COVERAGE.md. Commits 109f312/90216b9/134c168/f53e348/c754827/
1cd1442/1438b51/4e203c7.

Highlights recovered as evidence:
* updateApp opens with a dead `[None, None]` expression statement
  (anti-tamper tombstone) - shipped verbatim;
* listen = the WSS message pump: server-driven commands
  (communityContent, shareTheme/shareScript/shareRPC/shareUserProfile
  P2P flows that embed incoming payloads into JS template literals,
  session kick, badge/discoverable sync), all mapped;
* the ServerBackupManager trio: the full server backup engine
  (schema-1 server.json, role/category/channel/avatar/emoji/sticker
  serialization, ratelimit-cap abort codes 30008/30018/30039,
  with_retry policy);
* getAsset: discord.com/api/v10/oauth2/applications/{app_id}/assets;
* askAI: OpenAI-compatible completions, X-Title: display_name;
* set_guild_vanity: MFA cookie __Secure-recent_mfa + chrome TLS
  client spoofing (chrome_110-115), 401/code 60003 detection.

The trio re-scan disposition (tools/scan29b.py, byte-keyed candidates
over ALL legacy streams + todays fence27 windows): NO byte-identical
recurrence - the still-armed trio never decrypted in any capture
session. The initial scan29 hit spike was a per-occurrence counting
bug on sliding windows; formally DISQUALIFIED in
oracle/out/fragverify/DISPOSITION_scan29_trio.txt. The trio + the
remaining 81 no-body units (junk/stamp co_code at rest) require the
live fence campaign (in-process force-call, ReadProcessMemory on the
harness only, scratch sampled while trampolines execute).

In parallel the 2.6.1 update hunt ran (license-authenticated, official
nighty.one domains only) with a staged extraction and the
unit-level VERSION_DIFF for the rebase.

---

# FENCE CAMPAIGNS 29-32 (2026-10-16 evening) - the armor model, settled

Four in-process live sessions (all ReadProcessMemory-on-self, license
reseeded, user's Discord client untouched). Tooling preserved in
`tools/fence_target29.py` through `tools/fence_target32.py`; analysis in `tools/analyze29*.py`,
`tools/catalog_check*.py`, gate `tools/verify29d.py`.

## What shipped from this wave (5 + 1 disqualification cleanup)

Round-trip IDENTICAL againstlive-captured candidate marshals:

```
__init__                     L4021  (fence29 stream, 104 B)
decorated_function           L8920  (fence29 stream,  86 B, *args/**kwargs)
on_image_loaded               L4426  (fence29 stream, 110 B)
reposition_notifications     L4130  (fence29 stream,  86 B)
set_state                     L9575  (fence29 stream,  84 B)
```

Every one of the 22 shipped bodies was independently confirmed by live
memory: fence29's 101.7 MB scratch stream contained each shipped body's
exact bytes recurring byte-identically (listen x41, save x18,
_runRestore x15, ... close_notification-family stamps x920).

Three candidate arms were formally retired as a new class of PROVEN
FLOOR (not "pending"): `getRPCProfileData` L6889, `run` L4462,
`inject` L4659. Their scratch bodies carry pyarmor's armed-token int in
the await slot - `GET_AWAITABLE; LOAD_CONST <token-int>; YIELD_FROM` -
and CPython 3.8 hardcodes `None` in that slot in every construct that
emits YIELD_FROM (probed exhaustively). No source can compile to their
scratch bytes; residual ndiff is exactly 3 await slots each. The 5
shipped units had their tokens in literalizable positions (hence
IDENTICAL with the token literalized; see the SyntaxWarnings at
`seconds is 620` - the evidence-honest residue of armed consts).

## The armor model - now proven at scale (fence30/31)

- pyarmor's module bootstrap does NOT exec into the caller's dict: the
  exec dict receives only the `pyarmor` stub key, and
  `sys.modules['__main__']` is rebound to a 4-key decoy module. The
  real app namespace (633 keys) is reachable only via live frames or
  gc-walked containers (classes/instances -> methods -> __globals__).
- The runtime RELABELS co_firstlineno on live objects (setup_logging's
  live line 1348 vs original 1187), so strict name+line identity never
  matches live objects; fingerprinting by co_varnames/co_names (data,
  not relabelable) does.
- Live function objects of the whole pending tail stay ARMED at rest
  in a fully-booted app (48 of 51 fingerprint-matched objects carry
  the exact at-rest 74-byte stub). Decrypt-at-call goes to scratch and
  is never restored in place. The fence30 162 B "real setup_logging"
  was discord_bot.utils's own copy (different function), not the
  Nighty.py unit.
- The still-armed trio (getGoogleLanguages, Nighty2,
  ToastNotification.__init__) is ARMED in every live capture too:
  their decrypts have never existed in any observable memory.
- The stamp sizes recorded in the at-rest marshals are NOT the real
  body sizes (162 vs 188 for the same-name unit in different modules) -
  stream matching must never assume them.

## fence32 - the force-call experiment and its post-mortem

Force-calling harvested armed objects proved decrypt-and-run: the
harness died executing `paintEvent` L4363 at its post-decrypt frame -
direct evidence the trampoline decrypts before doing argument
validation. Consequences:

- UI-family methods genuinely paint when invoked and AV the process on
  a non-Qt thread with dummy args; the safe force-call set excludes
  the Qt event family.
- The in-session length-free validator (operand-bounds only,
  no length key) is formally deprecated: it admits nearly every valid
  run against every target (129k RECURRENCE lines of noise - the same
  disease as the disqualified scan29 spike). Exact-length + catalog +
  uniqueness + the round-trip gate remain the only accepted truth.
- Re-analysis of the 5.1 MB fence32 stream with the *proven*
  discipline gave only re-confirmations of shipped bodies plus known
  stamp alphabets. Two CANDIDATE-UNIQUE survivors (nightyScript L4608,
  set_watching_channel_id L9595) disassembled to soup
  (INPLACE_RSHIFT opener; all-jumps-to-0) and were retired.

## Where the recovery stands under 2.6.1 (2026-10-16 final)

The fresh official 2.6.1 download (Nighty.exe SHA256
`b3893d223e98920fd70e56b394d49772463c0ab32b6378ed24b54caa5ca6fea`,
103,922,753 B) was verified against the recovered 2.6.0 baseline:
**Nighty.pyc, the PYZ archive (all 3,813 modules), pytransform.pyd
and the SPP core are byte-identical** - only the exe wrapper's
version resources and packaging differ. The repo therefore already
contains the complete 2.6.1 application code; the plain-lane tail and
the native registry documented above apply 1:1 to 2.6.1. Full
comparison record: `update_2.6.1/NEW_BUILD_REPORT.md` (final verdict
section), including the case-sensitivity caveat on the generator's
hash comparisons.

## Where this leaves the tail

22 round-trip bodies shipped tonight; 3 proven floors documented as
compiler-impossible from scratch evidence; trio armed in every capture;
the remaining ~45 armed units decrypt only into transient scratch while
genuinely executing - every recovery from here requires catching a
unit mid-real-execution (UI-driven events, user commands) and passing
the same gate. No impostor was shipped: the gate stays the only truth.


## FENCE37 - THE TRIO FALLS (2026-10-16 late evening)

The proven fence31 skeleton + the trigger campaign + a sampler that
starts only AFTER both harvests (pre-boot samplers break the boot-window
GC - fence33/34's 592-dict/1-match regressions against fence31's
1289-dict/51-match). One infrastructure lesson learned the hard way:
pyarmor's namespace merge rebinds module names in the harness's own
globals (fence37-1 died calling threading.Thread - 'threading' had
become engineio.async_drivers.threading; fix: capture THREAD pre-boot).

Outcome: getGoogleLanguages and Nighty2 EXECUTED live, x6 each (the
former raising KeyError inside its real body, the latter completing),
the real toast fired paint/leave/mousepress on the UI thread, and the
sampler streamed 45.8 MB across the whole call phase. Round-tripped
IDENTICAL and shipped (27 hand-decoded bodies total tonight):

```
paintEvent                         n/a (see floors)
__init__                       L4093        80 B (tier-A call)
leaveEvent                     L4392       120 B (real toast firing)
mousePressEvent                L4446        78 B (real toast firing)
getGoogleLanguages             L4746       106 B (trio #1 - x6 unique
                                             candidate, recurrences ==
                                             executions)
Nighty2                       L12017       108 B (trio #2 - x12,
                                             x0 in the fence29 control)
```

### New floors (the 4th documented class)

paintEvent L4363: DIFFERS ndiff=1 - the armed-token int sits in the
except-as cleanup wrap (BEGIN_FINALLY/LOAD_CONST/STORE_FAST/
DELETE_FAST/END_FINALLY) where CPython 3.8's unwind_fblock hardwires
None. Same class as the await-token floor (run/inject/
getRPCProfileData): armed tokens in compiler-hardwired-None slots are
unprovable-from-scratch, everything else in the body matches.

### New analysis laws (recorded for any future campaign)

- The stamp lnotab offsets are a hidden LENGTH key: real bodies with
  shorter-than-stamp lengths fail the lnotab check. Drop lnotab, add
  RET-tail + named-op floors, for length-unknown targets.
- A never-called target's true scratch exists ONLY in streams from
  sessions where it was called: the cross-stream control (a stream
  predating the target's first execution) disqualified 161 of
  Nighty2's 164 lenient-bounds candidates instantly.
- Named-op floors must be target-aware (getGoogleLanguages has only
  5 co_names - a named>=6 filter excludes the very target).

### Final tail state after tonight

27 round-trip bodies shipped; 4 proven floors documented; 1 still-armed
(ToastNotification.__init__ L4142 - Qt constructor, execution-gated);
71 no-body (execution-gated units whose decrypts never occurred in any
captured session). The gate remains the only truth; no impostor was
ever shipped.


## 2026-10-17 - THE IMPOSTOR DISCOVERY AND RETRACTION (post-midnight audit)

### How it surfaced
A fresh py_compile of Nighty.py emitted three SyntaxWarnings (is not 345,
is 620) on shipped bodies. Inspection exposed decompiler mangles:
	ext.AlignLeft &= max_width.__armor_wrap__(),
except slide_up:, self.height.__armor_wrap__(),
self.startfile[__armor_wrap__(event)] - ten sections total.

### The paradox that explained everything
The poisoned sections compiled BYTE-IDENTICAL to their evidence
(recovered_*.bin banks) - the round-trip gate passed them. So the gate
was faithful, but the EVIDENCE was not the app code: those fence banks
hold pyarmor WRAPPER materializations - runtime armor code that reuses
the unit name/varname tables (their stamps carry __armor_wrap__ in
co_names). The early scratch-capture waves decompiled wrapper runs and
shipped them as app bodies. Compilable, byte-faithful, semantically
false.

### Evidence-grade taxonomy (new law)
- SAFE: whole-marshal objects (dec trees, unitA dumps, post marshals,
  live objects) - alignment-safe by construction.
- UNTRUSTED: raw stream runs (any *stream.bin) - may be wrapper
  materializations, misaligned scratch, or another unit's bytes.
  A run bank is only admissible when its disassembly is coherent app
  code AND no armor token appears in the name tables.
- The gate proves faithfulness to evidence; it cannot prove the
  evidence is the app.

### Retracted (ten; returned to the armed pending tail)
__init__ L4021, __init__ L4093, reposition_notifications L4130,
leaveEvent L4392, adjust_notification_size L4402, on_image_loaded
L4426, mousePressEvent L4446, decorated_function L8920,
set_state L9575, Nighty2 L12017.
Their vsrc39/verified sources moved to vsrc39/retracted; the census
re-arms them; Nighty.py and Nighty_base.py carry retraction banners.

### Cleared by safe evidence (34-object consensus, IDENTICAL)
get_app_id L7978, is_account_valid L7995, askAI L11977.
getGoogleLanguages L4746 remains IDENTICAL to its live capture.

### The anti-impostor invariant (new standing gate)
tools/audit_final.py: compile Nighty.py, map every unit to its section
header, compare against ALL banks (fence runs, dec trees, unitA,
post marshals, verified bank) with EXTENDED_ARG-fused grading:
IDENTICAL / JUMP-only / EQUIV-<=2arg / ARG / HARD.* Only whole-marshal
sources count as truth. Post-retraction residue: 48 IDENTICAL,
31 divergences (25 opcode-level, 4 jump-rechain, 2 arg) - the next
re-derivation wave, listed in audit_final_report.txt.

### fence39-43: the L4142 campaign closes terminal
- fence39: blanket sampler pause starved the capture; the L4433 trigger
  cross-thread QTimer deadlocked the session (visible toasts though -
  construction proven).
- fence40: burst sampling, 12 golden sends, worker died on
  on_click=None (None.get at true lines 4466/4471).
- fence41/42: pinned private-heap hot pages; zero L4142 candidates;
  the address histogram + ASLR lesson (hot pages are per-process).
- fence43: find_elf_bases pinned the four SPP image-copy arenas,
  dual-parity run extraction (the even-only stride of every earlier
  sampler was blind to odd-address buffers), 12 constructions, ~70
  pinned passes: ZERO constructor-sized runs at either parity.
- VERDICT: L4142 executed 24+ times and never once became observable
  in any readable page. Capture-physics floor, terminal in-process.
  (Fifth documented floor class.)

### Correction
The previous entry closed with 'no impostor was ever shipped'. That
was wrong: ten were. The 27-body hand-decode ledger drops to 17; the
shipped plain-lane count drops 176 -> 166; still-armed goes 1 -> 11.

## 2026-10-17 - THE FRAME-HOOK ENDGAME: mechanism complete, fix wave shipped

### The fix wave (24 units, byte-verified, shipped)
Every divergent shipped unit identified by tools/audit_final.py was
rebuilt from dec-tree truth by three parallel decode agents and the
updated gate (truth flags masked of pyarmor runtime bit 0x20000000):
_nighty_pop_curl/aws_close/ws_recv, _nightyInteractionCheck,
fetchAccessToken, _resolveGuild, spoofed_identify, sendCmdError,
storeSnipeAttachments, reloadBot, backupServers, dmToClientUser,
embedImage, autoLeaveCountdown, _botCmdSend (with _deliverFollowup
closure), editBotCmd, delete (nested no/yes_callback), listResponse,
both on_submit units, and the four voicemute responses.
Systematic decompiler frauds cured: hallucinated explicit
try/finally cleanup (py38 emits it implicitly for except-as),
invented else clauses, misattributed args. Audit final state:
75 IDENTICAL, 2 known false-pairs (update_text vs pyi_splash
name-collision; getSpotifyHeaders pending real truth), 0 real
residue.

### The external-hook capture campaign (fences 44a-j)
Frida (via the REA toolset) attached to our own harness processes -
rules-legal: our process only, never the user's Discord. Journey:
PyCode_New hooks never fired (super-mode bypasses the export);
_PyEval_EvalFrameDefault hooks fire at millions of frames; the
winning layout (empirically calibrated): frame is arg[0], f_code
@+32, co_firstlineno @+40, co_code @+48, co_consts @+56, co_names
@+64, co_varnames @+72, co_cell2arg @+96, co_filename @+104,
co_name @+112 (py38 added co_posonlyargcount AND co_cell2arg).
Filters that never matched: census names (mangled at runtime),
filename equality (not <frozen Nighty> at runtime - that string
lives in co_name). The winning filter: firstlineno membership
against the union of census + banner + all v5-stamp lines.

### The final mechanism, proven by the captures
64 envelope captures streamed. Every one is THE ARMED STUB'S FULL
RUNTIME ENVELOPE: stub header (LOAD_GLOBAL <wrap>; CALL_FUNCTION 0;
NOP; RETURN_VALUE = 74 71 83 00 09 00 53 00) followed by CIPHER
payload, with TRUE varnames/names tables (L4142: 18 varnames and 114
names EXACTLY matching its stamp; envelope size 1504 = the census
size). The true bodies NEVER become Python code objects: pyarmor
super-mode executes them inside its own native VM (the __armor_wrap__
mechanism). Python-level evaluation sees only envelope + ciphertext;
memory samplers at any resolution could never have caught plaintext
because plaintext exists only inside the armor VM's transient decode
buffers. The capture-physics floor is now MECHANISTICALLY
UNDERSTOOD, not merely observed.

### What the envelopes buy
The cipher tails + bilingual tables + census sizes = a complete
static-cipher input set (64 specimens, all known-plain structure
metadata). The anticipated fallback lane - static cipher reverse of
pytransform.pyd / the SPP core - now has its exact inputs. That is
the only remaining path for the 11 still-armed + 71 no-body units
and L4142 in particular.
## fence45: the static cipher campaign - the armor falls open (2026-10-17)

The whole pyarmor super-mode mechanism is now reversed end to end
from pytransform.pyd (Ghidra lane, image base 0x6d600000) and
validated live. Every armed envelope in evidence decodes offline.

### Mechanism (fully proven)

- `__armor_wrap__` (METH_NOARGS, ml_meth 0x6d604cd0): reads the
  calling frame, computes the envelope geometry
  `[8B stub][4B reentrancy counter @ +12][cipher span][16B tail]`,
  passes (frame, code, span ptr, span len, buf+12, tail ptr) to the
  engine at 0x6d604850. Engine args 5/6 confirmed by live trap
  (s6hex equals env tail exactly).
- Engine 0x6d604850: license/expiry guard, caller-frame walk for
  bit-28 units, then armor classes by co_flags bits:
  - bit 27 (0x08000000) CTR build state:
    ctr_start(cipher id 1 = AES, IV = tail16, key = 16 bytes derived
    from the tail mangled with the bss qwords at 0x6d70a1ce /
    0x6d70a1d6), in-place ctr_decrypt (libtomcrypt ctr_decrypt.c +
    ctr_start.c + FUN_6d6162e0 partial-block helper), then execute.
  - bit 30 (0x40000000) steady state: per-unit constant re-arm at
    engine exit with the cheap layers, per-call inline decrypt at
    entry. The wordloop key cycle is SIX words (the cycle ends at
    key buffer + 0x18):
      K6 = [ t0^d2.w0, (t1-0xb35)^d2.w1, (t2+0xd6ae)^da.w0,
             (t3+0xe9c3)^da.w1, e2.w0, e2.w1 ]
    where t* are the tail words and d2/da/e2 are the machine-stable
    license cluster qwords at bss 0x6d70a1d2 / 0x6d70a1da /
    0x6d70a1e2 (values in evidence/bss_dump.json and
    sess2_cluster.json).
    Arithmetic: decrypt w = (w ^ K6[i%6]) + 0xdd15,
    re-arm w = (w - 0xdd15) ^ K6[i%6]. XOR-24 arc = 24-byte key at
    0x6d70a1d2 mangled per byte with ((0x17-i)^2 + 3).
- The executor FUN_6d67b650 is a vendored CPython ceval loop with
  custom handlers on unused opcode slots - the armored streams are
  real py38 opcodes interleaved with special armor opcodes
  (0x7a 0x87 0xbc 0xc6 0x14 0x4c 0x5d 0xf1 0xf8 style).
- Live traps (hook45/hook45b): engine entry, ctr_start id/IV/key,
  and the decisive scoop at the exec return (buffer still plain
  before re-arm) validated the model with emprical key solving;
  the same-tail families share one K (K is a pure function of the
  tail) and the fifth/sixth cycle words equal the raw e2 cluster.

### Results

- decode_all45.py (validated wordloop6 + AES-128-CTR via Windows
  CNG bcrypt) decodes the entire armed v5 stamp corpus and the
  fence44 runtime envelopes offline: 200 stream files covering the
  toast family, the whole no-body band, L4142 (1472-byte ctor
  stream), L4746 getGoogleLanguages, L6330 getSpotifyHeaders
  (ctr-be, closing its false-pair), L4949/4959 runtime handler
  factories, and every other armed unit. Streams live in
  tools/fence45/evidence/streams45 with an index.json.
- Two runtime-generated handler bodies (event closures invisible to
  static stamps) were scooped live for the first time ever.
- The remaining work is one bounded step: map the custom armor
  opcodes from the ceval handler layout, then run reconstruction
  waves (agents: stream + census metadata + family context) to
  rebuild the missing python sources, gated by py_compile plus
  semantic cross-checks against the streams. The CTR trio bodies
  that never executed in any harness session are already readable
  offline from their at-rest envelopes with the validated formulas.

## fence45-46: the vm stream reconstruction waves (2026-10-17, later)

The armor decode from the morning session turned into full source
recovery the same day.

### The vm opcode map (proven by byte-exact gates)

The armored streams are REAL py38 instructions with a partial
opcode substitution plus injected decoys:

- identity ops stay: LOAD_CONST/LOAD_FAST/STORE_FAST/LOAD_GLOBAL/
  CALL_FUNCTION/POP_JUMP_IF_*/JUMP_ABSOLUTE/FOR_ITER/NOP
- remapped: 0xc6=LOAD_ATTR 0x76=LOAD_METHOD 0xf8=CALL_METHOD
  0x10=POP_TOP 0x23=RETURN_VALUE 0x41=GET_ITER 0x87=COMPARE_OP
  0x12=BINARY_ADD 0x0c=INPLACE_SUBTRACT 0xe5=STORE_ATTR
  0xf1=JUMP_FORWARD 0x8d/0xce/0xea=BUILD_LIST/BUILD_STRING
  0xc8=LOAD_FAST(armor self-wrap) 0xc9=BUILD_TUPLE 0x4c=
  BINARY_SUBTRACT 0xf4=call-variant 0xf6=FORMAT_VALUE
  0x9d-family=BUILD_STRING 0x54=BINARY_OR 0xb1=BUILD_LIST0
  0x8d-alias=CALL_FUNCTION_KW 0xc4/0xbc=decoy pairs
- decoy triplets: (0xf4-call, LOAD_FAST, LOAD_ATTR) injected
  before real call sites; a decoy name inserted into co_names
  shifts later name indices (+1 observed in L4105)
- jump args are absolute in the FULL code object; streams are
  code[16:-16] so stream targets = arg - 16

### Pipeline (all tools in oracle/ and repo tools/fence45)

1. live streams from the fence45/46 traps + stamp envelopes via
   the validated wordloop6/AES cluster decode
2. vmtranslate45.py: VM -> standard py38 bytes (strict oracle)
3. disprint45.py: resolved dis with TRUE names/varnames/lines
4. reconstruction (in-session + agent fleet) against family
   siblings; every inferred literal marked const-recovered
5. gate45.py: compile -> vmize -> byte-compare vs the live
   stream (const args masked for decoys, decoy triplets
   skipped, opcode equivalence classes)
6. ship45.py: idempotent section insert + ledger update

### Results this wave

- 36 units shipped including the two flagships: L4142
  ToastNotification.__init__ (736 instrs, med-high) and L12017
  Nighty2 bootstrap (509 instrs, medium, decoy consts inferred)
- 21+ units at 100 percent byte-gate vs live streams; the
  toast family, worker/manager, events, paint, fades, queue
  paths, closeToast/sendToast, the flask-adjacent managers
- L6330 getSpotifyHeaders certified byte-identical to its dec
  bank truth marshal (the false pair closed)
- honest floors: L4054/L4087 semantic-family (stamp evidence is
  decoy filler), L4462 run (different armor tier, semantic),
  L4506 closeEvent (names-order fit, envelope never captured)
