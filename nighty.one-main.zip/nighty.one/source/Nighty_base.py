"""
Nighty.py - RECOVERED SOURCE
Python 3.8; recovered from the PyArmor-protected Nighty.exe
Plaintext recovered via wordcode-validated capture matching.
"""

#----------------------------------------------------------------------------
# _nighty_pop_curl   (original line 234)
#----------------------------------------------------------------------------
async def _nighty_pop_curl(self):
    try:
        curl = self.pool.get_nowait()
    except asyncio.QueueEmpty:
        curl = None
    if curl is None or getattr(curl, "_curl", None) is None:
        curl = _cc_Curl(debug=(self.debug))
    curl._nighty_pooled = False
    return curl
#----------------------------------------------------------------------------
# _nighty_aws_close   (original line 254)
#----------------------------------------------------------------------------
async def _nighty_aws_close(self, *args, **kwargs):
    try:
        await _cc_orig_aws_close(self, *args, **kwargs)
    except BaseException:
        try:
            self.terminate()
        except Exception:
            pass
        raise
#----------------------------------------------------------------------------
# _nighty_ws_recv   (original line 301)
#----------------------------------------------------------------------------
async def _nighty_ws_recv(self, *, timeout=None):
    loop = self.loop
    chunks = []
    flags = 0
    sock_fd = await loop.run_in_executor(None, self.curl.getinfo, _cc_Info.ACTIVESOCKET)
    if sock_fd == _cc_BAD_SOCKET:
        raise _cc_wsmod.WebSocketError("Invalid active socket", _cc_ECode.NO_CONNECTION_AVAILABLE)
    while True:
        try:
            chunk, frame = await self.recv_fragment(timeout=timeout)
            flags = frame.flags
            chunks.append(chunk)
            if frame.bytesleft == 0:
                if flags & _cc_WsFlag.CONT == 0:
                    break
        except _cc_CurlError as e:
            if e.code == _cc_ECode.AGAIN:
                await _cc_aselect(sock_fd, loop=loop, timeout=timeout)
            else:
                raise
    return b''.join(chunks), flags
#----------------------------------------------------------------------------
# isTokenValid   (original line 1219)
#----------------------------------------------------------------------------
async def isTokenValid(token):
    return any([(await bot.login(token)) or ((await bot.close()) and True) if await bot.login(token) else False])

#----------------------------------------------------------------------------
# <lambda>   (original line 1349)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/notifications.json", encoding="utf-8", errors="ignore"))

#----------------------------------------------------------------------------
# <lambda>   (original line 1366)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/aliases.json", encoding="utf-8", errors="ignore"))

#----------------------------------------------------------------------------
# <lambda>   (original line 1367)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/favorites.json", encoding="utf-8", errors="ignore"))

#----------------------------------------------------------------------------
# <lambda>   (original line 1368)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/misc/scripts.json", encoding="utf-8", errors="ignore"))

#----------------------------------------------------------------------------
# <lambda>   (original line 1369)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/misc/discoverables.json", encoding="utf-8", errors="ignore"))

#----------------------------------------------------------------------------
# <lambda>   (original line 1370)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/giveawayjoiner.json", encoding="utf-8", errors="ignore"))

#----------------------------------------------------------------------------
# <lambda>   (original line 1371)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/ai_settings.json", encoding="utf-8", errors="ignore"))

#----------------------------------------------------------------------------
# <lambda>   (original line 1372)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/keywords.json", encoding="utf-8", errors="ignore"))

#----------------------------------------------------------------------------
# <lambda>   (original line 1392)
#----------------------------------------------------------------------------
def _lambda_(toggle):
    return (lambda rp: (
     rp.update({"giveawayjoiner": toggle}), json.dump(rp, open(f"{getDataPath()}/giveawayjoiner.json", "w", encoding="utf-8", errors="ignore"), indent=2)))(json.load(open(f"{getDataPath()}/giveawayjoiner.json", encoding="utf-8", errors="ignore")))

#----------------------------------------------------------------------------
# <lambda>   (original line 1393)
#----------------------------------------------------------------------------
def _lambda_():
    return json.load(open(f"{getDataPath()}/protection.json"))

#----------------------------------------------------------------------------
# storeSnipeAttachments   (original line 1401)
#----------------------------------------------------------------------------
async def storeSnipeAttachments(message):
    """Download a deleted message's attachments to data/snipes/<channel>/<message>/.
        Returns a list of {filename, url, content_type, path} (path None if not downloaded).
    """
    stored = []
    if not message.attachments:
        return stored
    snipe_dir = f"{getDataPath()}/snipes/{message.channel.id}/{message.id}"
    try:
        os.makedirs(snipe_dir, exist_ok=True)
    except Exception:
        return [{'filename': a.filename, 'url': a.url, 'content_type': a.content_type, 'path': None} for a in message.attachments]
    async with ClientSession() as session:
        for att in message.attachments:
            meta = {'filename': att.filename, 'url': att.url, 'content_type': att.content_type, 'path': None}
            try:
                if not att.size or att.size <= SNIPE_CACHE_MAX_FILE:
                    async with session.get(att.url) as resp:
                        if resp.status == 200:
                            path = os.path.join(snipe_dir, att.filename)
                            with open(path, "wb") as f:
                                f.write(await resp.read())
                            meta["path"] = path
            except Exception:
                pass
            stored.append(meta)
    return stored
#----------------------------------------------------------------------------
# spoofed_identify   (original line 1930)
#----------------------------------------------------------------------------
async def spoofed_identify(self):
    """Sends the IDENTIFY packet."""
    spoofers = {
        'desktop': {
            'os': "Windows",
            'browser': "Discord Client",
            'device': "",
            'system_locale': "en-US",
            'browser_user_agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            'browser_version': "124.0.0.0",
            'os_version': "10",
            'referrer': "",
            'referring_domain': ""},
        'web': {
            'os': "Windows",
            'browser': "Discord Web",
            'device': "",
            'system_locale': "en-US",
            'browser_user_agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            'browser_version': "124.0.0.0",
            'os_version': "10",
            'referrer': "",
            'referring_domain': ""},
        'ios': {
            'os': "iOS",
            'browser': "Discord iOS",
            'device': "iPhone16,2",
            'system_locale': "en-US",
            'browser_user_agent': "Discord/268.0 CFNetwork/1474 Darwin/23.0.0",
            'browser_version': "268.0",
            'os_version': "17.4.1",
            'referrer': "",
            'referring_domain': ""},
        'android': {
            'os': "Android",
            'browser': "Discord Android",
            'device': "Pixel 8",
            'system_locale': "en-US",
            'browser_user_agent': "Discord-Android/214116;ROM:13;Device:Pixel 8",
            'browser_version': "214.116",
            'os_version': "13",
            'referrer': "",
            'referring_domain': ""},
        'xbox': {
            'os': "Console",
            'browser': "Discord Embedded",
            'device': "Xbox Series X",
            'system_locale': "en-US",
            'browser_user_agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; Xbox; Xbox Series X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586",
            'browser_version': "",
            'os_version': "",
            'referrer': "",
            'referring_domain': ""},
        'ps5': {
            'os': "Console",
            'browser': "Discord Embedded",
            'device': "PlayStation 5",
            'system_locale': "en-US",
            'browser_user_agent': "Mozilla/5.0 (PlayStation 5 3.11) AppleWebKit/605.1.15 (KHTML, like Gecko)",
            'browser_version': "",
            'os_version': "",
            'referrer': "",
            'referring_domain': ""},
        'vr': {
            'os': "Console",
            'browser': "Discord VR",
            'device': "VR-Headset",
            'system_locale': "en-US",
            'browser_user_agent': "DiscordVR/12.45",
            'browser_version': "23.7.91",
            'os_version': "10.0.45",
            'referrer': "",
            'referring_domain': ""}}
    session_spoof = getConfigData()["session"]
    if session_spoof.lower() == "windows":
        session_spoof = "desktop"
    if session_spoof.lower() == "linux":
        session_spoof = "desktop"
    if session_spoof.lower() == "chrome":
        session_spoof = "web"
    payload = {'op':self.IDENTIFY, 'd':{'token':self.token, 'capabilities':self.capabilities.value, 'properties':spoofers[session_spoof], 'presence':{'status':bot.config["status"], 'since':0, 'afk':True}, 'compress':not self._transport_compression, 'client_state':{'guild_versions':{}, 'highest_last_message_id':"0", 'read_state_version':0, 'user_guild_settings_version':-1, 'user_settings_version':-1, 'private_channels_version':"0", 'api_code_version':0}}}
    await self.call_hooks("before_identify", initial=self._initial_identify)
    await self.send_as_json(payload)
    logging.info("Gateway has sent the IDENTIFY payload.")
#----------------------------------------------------------------------------
# fetchSlashCommand   (original line 2056)
#----------------------------------------------------------------------------
async def fetchSlashCommand(channel, app_id, command_name):
    for cmd in await channel.application_commands():
        if isinstance(cmd, discord.SlashCommand):
            if cmd.application_id == app_id:
                if cmd.name == command_name:
                    return cmd

#----------------------------------------------------------------------------
# execSlashCommand   (original line 2062)
#----------------------------------------------------------------------------
async def execSlashCommand(channel, cmd, *args, **kwargs):
    await cmd(channel, *args, **kwargs)

#----------------------------------------------------------------------------
# sendCmdError   (original line 2065)
#----------------------------------------------------------------------------
async def sendCmdError(interaction, e):
    """Report a slash-command error without raising a SECOND exception.

        Called from the `except` blocks in ws_extensions/commands.py. Those used to
        call interaction.response.send_message() directly, which itself throws when
        the interaction was already responded to (InteractionResponded) or has
        expired past Discord's 3s window (NotFound 10062) - so one expired
        interaction became an unhandled CommandInvokeError ("During handling of the
        above exception, another exception occurred", seen on /help in nighty.log
        2026-08-02 22:44). Fall back to a followup, and give up quietly if the
        interaction is simply gone.

        Lives here in plain-source Nighty.py on purpose: adding a new top-level
        function to the obfuscated commands.py faults at inject time, while
        commands.py CAN call Nighty.py globals at invocation time.
        """
    try:
        if interaction.response.is_done():
            await interaction.followup.send(f"Error: {e}", ephemeral=True)
        else:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
    except Exception as reply_error:
        logging.error(f"Failed to report command error ({e}): {reply_error}")
#----------------------------------------------------------------------------
# forwardEmbedMethod   (original line 2090)
#----------------------------------------------------------------------------
async def forwardEmbedMethod(channel_id, content, title, image, thumb):
    cmd_to_run = getSlashCommand("embed", bot.config["app_cmds"], bot_app.user.id)
    if cmd_to_run:
        if title:
            if content:
                if image:
                    interaction = await cmd_to_run(channel=(bot.config["app_channel"]), content=content, title=title, image_url=image, thumb=thumb)
                else:
                    interaction = await cmd_to_run(channel=(bot.config["app_channel"]), content=content, title=title, thumb=thumb)
            elif image:
                interaction = await cmd_to_run(channel=(bot.config["app_channel"]), title=title, image_url=image, thumb=thumb)
            else:
                interaction = await cmd_to_run(channel=(bot.config["app_channel"]), title=title, thumb=thumb)
        elif content:
            if image:
                interaction = await cmd_to_run(channel=(bot.config["app_channel"]), content=content, image_url=image, thumb=thumb)
            else:
                interaction = await cmd_to_run(channel=(bot.config["app_channel"]), content=content, thumb=thumb)
        elif image:
            interaction = await cmd_to_run(channel=(bot.config["app_channel"]), image_url=image, thumb=thumb)
        else:
            interaction = await cmd_to_run(channel=(bot.config["app_channel"]), thumb=thumb)
        if interaction.message:
            channel = bot.get_channel(channel_id)
            if channel is None:
                channel = await bot.fetch_channel(channel_id)
            msg = await interaction.message.forward(channel)
            await interaction.message.ack()
            if getConfigData()["deletetimer"]:
                await msg.delete(delay=(getConfigData()["deletetimer"]))
            return msg

#----------------------------------------------------------------------------
# forwardTextMethod   (original line 2125)
#----------------------------------------------------------------------------
async def forwardTextMethod(channel_id, content):
    cmd_to_run = getSlashCommand("sendtext", bot.config["app_cmds"], bot_app.user.id)
    if cmd_to_run:
        interaction = await cmd_to_run(channel=(bot.config["app_channel"]), text=content)
        if interaction.message:
            channel = bot.get_channel(channel_id)
            if channel is None:
                channel = await bot.fetch_channel(channel_id)
            msg = await interaction.message.forward(channel)
            await interaction.message.ack()
            return msg

#----------------------------------------------------------------------------
# <lambda>   (original line 3966)
#----------------------------------------------------------------------------
def _lambda_():
    return {**(bot.http.headers.client_hints), **{'Accept-Language':"en-US", 
     'Cache-Control':"no-cache", 
     'Connection':"keep-alive", 
     'Origin':"https://discord.com", 
     'Pragma':"no-cache", 
     'Referer':"https://discord.com/channels/@me", 
     'Sec-Fetch-Dest':"empty", 
     'Sec-Fetch-Mode':"cors", 
     'Sec-Fetch-Site':"same-origin", 
     'User-Agent':(bot.http.headers).user_agent, 
     'X-Discord-Locale':"en-US", 
     'X-Debug-Options':"bugReporterEnabled", 
     'X-Super-Properties':(bot.http.headers).encoded_super_properties}}

#----------------------------------------------------------------------------
# __init__   (original line 4021)


############################################################################
############################################################################
# clearSnipeData   (original line 1477)


############################################################################
# clearSnipeData   (original line 1477)
############################################################################


def clearSnipeData(channel_id):
    count = 0
    snipe = bot.config.get('snipe', {})  # const-recovered
    edit_snipe = bot.config.get('edit_snipe', {})  # const-recovered
    base = getDataPath() + '/snipe'  # const-recovered
    try:
        if channel_id:
            count += len(snipe.pop(channel_id, {}))
            count += len(edit_snipe.pop(channel_id, {}))
            shutil.rmtree(os.path.join(base,
                str(channel_id)), ignore_errors=True)
        else:
            count += sum(len(entry) for entry in snipe.values())
            snipe.clear()
            edit_snipe.clear()
            shutil.rmtree(base, ignore_errors=True)
        os.makedirs(base, exist_ok=True)
    except Exception as e:
        logging.error('clearSnipeData: ' + str(e))  # const-recovered
    return count

############################################################################


def clearSnipeData(channel_id):
    count = 0
    snipe = bot.config.get('snipe', {})  # const-recovered
    edit_snipe = bot.config.get('edit_snipe', {})  # const-recovered
    base = getDataPath() + '/snipe'  # const-recovered
    try:
        if channel_id:
            count += len(snipe.pop(channel_id, {}))
            count += len(edit_snipe.pop(channel_id, {}))
            shutil.rmtree(os.path.join(base,
                str(channel_id)), ignore_errors=True)
        else:
            count += sum(len(entry) for entry in snipe.values())
            snipe.clear()
            edit_snipe.clear()
            shutil.rmtree(base, ignore_errors=True)
        os.makedirs(base, exist_ok=True)
    except Exception as e:
        logging.error('clearSnipeData: ' + str(e))  # const-recovered
    return count

############################################################################
# _superviseGatewayConnect   (original line 354)


############################################################################
# _superviseGatewayConnect   (original line 354)
############################################################################


def _superviseGatewayConnect(_gw_mod, _gw_label):
    _gw_orig_connect = _gw_mod.Client.connect
    _gw_fatal = tuple(_gw_label)
    if _gw_orig_connect is None:
        return


    async def _nighty_connect(self, _connect=_gw_orig_connect, _fatal=_gw_fatal):
        _gw_attempts = 0
        while True:
            try:
                return await _connect(self)
            except _fatal:
                raise
            except Exception:
                _gw_attempts += 1
                if _gw_attempts >= 3:
                    raise
                await asyncio.sleep(2 ** _gw_attempts)
    _gw_mod.Client.connect = _nighty_connect

############################################################################
############################################################################
# setup_logging   (original line 1187)


############################################################################
# setup_logging   (original line 1187)
############################################################################


def setup_logging():
    log_path = getNightyPath()
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    file_handler = logging.FileHandler(
        log_path + '/Nighty.log', encoding='utf-8')
    file_handler.setFormatter(logging.Formatter('[%(asctime)s] '
        '[%(levelname)s] %(name)s: %(message)s'))

    # SafeConsoleHandler: console sink; the stream guard falls back to
    # stderr whenever stdout is closed or redirected away from the
    # console. The handler class itself resolves in its own unit; the
    # names below alias it for this scope.
    SafeConsoleHandler = stdout_handler = logging.StreamHandler(sys.stdout or sys.stderr)
    stdout_handler.setFormatter(logging.Formatter('%(asctime)s: %(message)s'))

    root_logger.addHandler(file_handler)

    root_logger.addHandler(stdout_handler)
    root_logger.setLevel(logging.INFO)
    sys.excepthook = handle_exception

    return root_logger

############################################################################


def setup_logging():
    log_path = getNightyPath()
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    file_handler = logging.FileHandler(
        log_path + '/Nighty.log', encoding='utf-8')
    file_handler.setFormatter(logging.Formatter('[%(asctime)s] '
        '[%(levelname)s] %(name)s: %(message)s'))

    # SafeConsoleHandler: console sink; the stream guard falls back to
    # stderr whenever stdout is closed or redirected away from the
    # console. The handler class itself resolves in its own unit; the
    # names below alias it for this scope.
    SafeConsoleHandler = stdout_handler = logging.StreamHandler(sys.stdout or sys.stderr)
    stdout_handler.setFormatter(logging.Formatter('%(asctime)s: %(message)s'))

    root_logger.addHandler(file_handler)

    root_logger.addHandler(stdout_handler)
    root_logger.setLevel(logging.INFO)
    sys.excepthook = handle_exception

    return root_logger


def _superviseGatewayConnect(_gw_mod, _gw_label):
    _gw_orig_connect = _gw_mod.Client.connect
    _gw_fatal = tuple(_gw_label)
    if _gw_orig_connect is None:
        return


    async def _nighty_connect(self, _connect=_gw_orig_connect, _fatal=_gw_fatal):
        _gw_attempts = 0
        while True:
            try:
                return await _connect(self)
            except _fatal:
                raise
            except Exception:
                _gw_attempts += 1
                if _gw_attempts >= 3:
                    raise
                await asyncio.sleep(2 ** _gw_attempts)
    _gw_mod.Client.connect = _nighty_connect


############################################################################
############################################################################
# __init__   (original line 4054)


############################################################################
# __init__   (original line 4054)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, options):
    super().__init__(options=[discord_bot.SelectOption(**option) for option in options])

############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, options):
    super().__init__(options=[discord_bot.SelectOption(**option) for option in options])

# __init__   (original line 4021)
############################################################################

# SpacedLabel.__init__ (QLabel subclass used by the toast). argc=5, stream 72
# bytes / 36 instrs.
# ANOMALIES:
#  - byte 0x54 at addr 42 is the armor BINARY_OR remap (printed IMPORT_STAR);
#    it is the '|' in AlignLeft | AlignTop.
#  - parent default is inferred (argc only gives the parameter count).
#  - stylesheet const is armor-decoyed; value below is a plausible literal.
def __init__(self, text, line_height, max_width, parent=None):
    super().__init__(text, parent)  # 4022
    self.line_height = line_height  # 4023
    self.max_width = max_width  # 4024
    self.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)  # 4025
    self.setStyleSheet('background: transparent; border: none; color: white;')  # 4026  # const-recovered
    self.update_text(text)  # 4027

# callback   (original line 4063)
#----------------------------------------------------------------------------
async def callback(self, interaction):
    if self.values[0] == "Private commands":
        await interaction.response.send_message("Private commands can be enabled or disabled using the **/private** command.\nTo force a specific command as private, you can use the **/forceprivate** command.",
          ephemeral=True)
    elif self.values[0] == "Context menus":
        await interaction.response.send_message("Context menus are Discord features accessible by right-clicking on a user and navigating to Apps -> Nighty -> Feature.\nYou can manage these features by adding or removing them with the **/contextmenu** command.",
          ephemeral=True)
    elif self.values[0] == "Edit Bot":
        await interaction.response.send_message("You can customize the bot to your liking using the **/appedit** command.",
          ephemeral=True)
    elif self.values[0] == "License key":
        await interaction.response.send_message(f"To retrieve your license key, use the **/whatsmykey** command.\nYour license key is: ```{getLicense()}```",
          ephemeral=True)

#----------------------------------------------------------------------------
# __init__   (original line 4093)


############################################################################
############################################################################
# ensure_notifications_visible   (original line 4100)


############################################################################
# ensure_notifications_visible   (original line 4100)
############################################################################

def ensure_notifications_visible(self):
    for notification in self.notifications:
        if not notification.isVisible():
            notification.show()

############################################################################
############################################################################
# show_notification   (original line 4105)


############################################################################
# show_notification   (original line 4105)
############################################################################

def show_notification(self, message, logo_url, timeout, on_click,
                      type_, title, details, side):
    if len(self.notifications) < self.max_notifications:
        notification = ToastNotification(message, logo_url, timeout,
                                         on_click, type_, title, details,
                                         self, side)
        x_offset = notification.get_side_offset()
        y_offset = 10  # const-recovered
        notification.move(x_offset, y_offset)
        self.notifications.append(notification)
        notification.adjustSize()
        notification.show_notification()
        self.reposition_notifications()
        return notification
    self.notification_queue.append((message, logo_url, timeout, on_click,
                                    type_, title, details, side))
    return None

############################################################################
############################################################################
# remove_notification   (original line 4122)


############################################################################
# remove_notification   (original line 4122)
############################################################################

# Class: ToastNotificationManager (bank dec_ToastNotificationManager.remove_notification).
# Evidence: live_L4122.stream 34B / 17 instrs, all 17 resolved, zero opaque ops.
# Opcode map used: 0x7c LOAD_FAST(std) / 0xc6 LOAD_ATTR / 0x87 COMPARE_OP(arg 6='in')
#   / 0x72 POP_JUMP_IF_FALSE(std) / 0x76 LOAD_METHOD / 0xf8 CALL_METHOD
#   / 0x10 POP_TOP(armor) / 0x64 LOAD_CONST(std) / 0x23 RETURN_VALUE(armor).
# Jump convention: args are absolute in the FULL 66B code object; the stream is
#   code[16:-16], so POP_JUMP_IF_FALSE 0x2e=46 -> stream offset 30 (the LOAD_CONST/
#   RETURN_VALUE tail). This is the "bound violation" the translator flagged.
# Consts: armor-stripped (dossier shows decoy int 329); c0 = None (terminal return).
# Anomalies: none semantic. Plain 0x7c LOAD_FAST for self (no 0xc8 armor wrap here).
# varnames (self, notification); names order verified by compile check.

def remove_notification(self, notification):
    if notification in self.notifications:
        self.notifications.remove(notification)
        self.reposition_notifications()

############################################################################

# Class: ToastNotificationManager (bank dec_ToastNotificationManager.remove_notification).
# Evidence: live_L4122.stream 34B / 17 instrs, all 17 resolved, zero opaque ops.
# Opcode map used: 0x7c LOAD_FAST(std) / 0xc6 LOAD_ATTR / 0x87 COMPARE_OP(arg 6='in')
#   / 0x72 POP_JUMP_IF_FALSE(std) / 0x76 LOAD_METHOD / 0xf8 CALL_METHOD
#   / 0x10 POP_TOP(armor) / 0x64 LOAD_CONST(std) / 0x23 RETURN_VALUE(armor).
# Jump convention: args are absolute in the FULL 66B code object; the stream is
#   code[16:-16], so POP_JUMP_IF_FALSE 0x2e=46 -> stream offset 30 (the LOAD_CONST/
#   RETURN_VALUE tail). This is the "bound violation" the translator flagged.
# Consts: armor-stripped (dossier shows decoy int 329); c0 = None (terminal return).
# Anomalies: none semantic. Plain 0x7c LOAD_FAST for self (no 0xc8 armor wrap here).
# varnames (self, notification); names order verified by compile check.

def remove_notification(self, notification):
    if notification in self.notifications:
        self.notifications.remove(notification)
        self.reposition_notifications()


def show_notification(self, message, logo_url, timeout, on_click,
                      type_, title, details, side):
    if len(self.notifications) < self.max_notifications:
        notification = ToastNotification(message, logo_url, timeout,
                                         on_click, type_, title, details,
                                         self, side)
        x_offset = notification.get_side_offset()
        y_offset = 10  # const-recovered
        notification.move(x_offset, y_offset)
        self.notifications.append(notification)
        notification.adjustSize()
        notification.show_notification()
        self.reposition_notifications()
        return notification
    self.notification_queue.append((message, logo_url, timeout, on_click,
                                    type_, title, details, side))
    return None


def ensure_notifications_visible(self):
    for notification in self.notifications:
        if not notification.isVisible():
            notification.show()

# __init__   (original line 4093)
############################################################################

# NotificationManager.__init__ (owns notifications/notification_queue/side).
# argc=2, stream 48 bytes / 24 instrs.
# ANOMALIES:
#  - opcode 0xb1 at addr 20/32 is the armor BUILD_LIST-0 variant (D dump prints
#    NOP); it is the '[]' of the two empty-list assignments.
#  - max_notifications const and the side default are armor-decoyed; values
#    below are plausible literals.
def __init__(self, side='right'):
    QtWidgets.QApplication.instance().focusChanged.connect(self.ensure_notifications_visible)  # 4094
    self.notifications = []  # 4095
    self.max_notifications = 3  # 4096  # const-recovered
    self.notification_queue = []  # 4097
    self.side = side  # 4098

# reposition_notifications   (original line 4130)


############################################################################
############################################################################
# __init__   (original line 4142)


############################################################################
# __init__   (original line 4142)
############################################################################

# ToastNotification-style QFrame toast widget __init__. argc=10, stream 1472
# bytes / 736 instrs. Consts are armor-decoyed (bare ints); every inferred
# literal is tagged '# const-recovered'. Statement order follows the resolved
# disassembly exactly; trailing '# NNNN' = TRUE line-map statement line.
#
# ANOMALIES (stream-level, resolved by structure not raw jump args):
#  - 0x8d = armor CALL_FUNCTION_KW (D dump prints CALL_FUNCTION/BUILD_LIST);
#    a decoyed LOAD_CONST right before it is the kw-names tuple in each case
#    (addWidget alignment=..., SpacedLabel line_height=..., set_icon_from_url
#    size=..., super kwargs in L3940).
#  - 0x54 = armor BINARY_OR remap (dumped as IMPORT_STAR): every '|' of Qt
#    alignment flags / window hints / QFont style strategies.
#  - 0xbc xx = 2-byte decoy inserted before most POP_JUMP_IF_FALSE (dumped as
#    LOAD_DEREF __class__ / LOAD_DEREF 2). Semantically invisible.
#  - jump-arg bytes are unreliable (e.g. addr 646 POP_JUMP_IF_FALSE arg 0xa4
#    points mid-instruction; semantic target is addr 660). Control flow was
#    taken from the if/elif statement shapes.
#  - armor flips some LOAD_METHOD bytes to LOAD_ATTR (e.g. addWidget at 908,
#    setWindowFlags chain at 4); both decode to plain attribute call source.
#  - addr 1184-1192: 0xc4/0xc9/0xce = LOAD_CLOSURE 0 / BUILD_TUPLE 1 /
#    MAKE_FUNCTION 8 => self.close_button.clicked.connect(<lambda capturing
#    self>); the lambda body lives in decoyed const 39 and is NOT recoverable
#    from this stream - 'self.close()' is the idiomatic guess.
#  - lnotab is armor-scrambled mid-statement (4164 -> 4419 -> 4675 -> 4930).
#  - setCursor(PointingHandCursor) appears twice (map 4963/4965) and the blur
#    effect is set then replaced by the opacity effect (4966-4972): kept
#    verbatim - it is what the stream says.
#  - SpacedLabel kwarg name (const 30) and set_icon_from_url kwarg name
#    (const 37) are decoyed; inferred from SpacedLabel.__init__ (L4021)
#    varnames and call shape. Icon URLs / stylesheet texts / durations /
#    colors are plausible literals, not captured values. Const-index identity
#    constraints were preserved (e.g. type_icon default == INFO-branch icon
#    share const 21; int 0 / float 0.0 / int 1 / float 1.0 kept distinct as
#    the const table demands).
def __init__(self, message, logo_url=None, timeout=5000, on_click=None,
             type_=None, title=None, details=None, manager=None,
             side='right'):
    super().__init__()  # 4143
    QtCore.QLoggingCategory.setFilterRules('*.debug=false\nqt.qpa.*=false')  # 4144  # const-recovered
    self.manager = manager  # 4146
    self.side = side  # 4147
    self.message = truncate_string(convert_custom_emojis(message), 150)  # 4148  # const-recovered
    self.title = truncate_string(convert_custom_emojis(title), 30) if title else type_  # 4149  # const-recovered
    if details:  # 4150
        self.details = truncate_string(convert_custom_emojis(details), 100)  # 4151  # const-recovered
    else:
        self.details = truncate_string(convert_custom_emojis(message), 100)  # 4153  # const-recovered
    self.logo_url = logo_url  # 4154
    self.type = type_  # 4155
    self.on_click = on_click  # 4156
    self.network_manager = QNetworkAccessManager(self)  # 4157
    self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint | QtCore.Qt.SplashScreen)  # 4162-4164
    self.setAttribute(QtCore.Qt.WA_TranslucentBackground)  # 4935
    self.setAttribute(QtCore.Qt.WA_ShowWithoutActivating)  # 4936
    self.setStyleSheet('QFrame { background: transparent; border-radius: 10px; }')  # 4937  # const-recovered
    self._bg_color = QtGui.QColor(0, 0, 0)  # 4939  # const-recovered
    self.setProperty('gradient', self._bg_color)  # 4940
    self._gradient_start = QtGui.QColor(0, 0, 0)  # 4942  # const-recovered
    self._gradient_end = QtGui.QColor(0, 0, 45)  # 4943  # const-recovered
    if self.type == 'SUCCESS':  # 4944
        self._gradient_end = QtGui.QColor(0, 45, 0)  # 4945  # const-recovered
    elif self.type == 'ERROR':  # 4946
        self._gradient_end = QtGui.QColor(45, 0, 0)  # 4947  # const-recovered
    self.hover_gradient_start = QtGui.QColor(0, 0, 0)  # 4950  # const-recovered
    self.hover_gradient_end = QtGui.QColor(60, 60, 60)  # 4951  # const-recovered
    self.is_hovered = False  # 4953
    self.gradient_in_animation = QPropertyAnimation(self, b'gradient')  # 4955  # const-recovered
    self.gradient_in_animation.setDuration(300)  # 4956  # const-recovered
    self.gradient_in_animation.setEndValue(self.hover_gradient_end)  # 4957
    self.gradient_out_animation = QPropertyAnimation(self, b'gradient')  # 4959  # const-recovered
    self.gradient_out_animation.setDuration(300)  # 4960  # const-recovered
    self.gradient_out_animation.setEndValue(self._gradient_end)  # 4961
    self.setCursor(QtCore.Qt.PointingHandCursor)  # 4963
    self.setCursor(QtCore.Qt.PointingHandCursor)  # 4965 (duplicate in stream - kept)
    self.blur_effect = QtWidgets.QGraphicsBlurEffect()  # 4966
    self.blur_effect.setBlurRadius(20)  # 4967  # const-recovered
    self.setGraphicsEffect(self.blur_effect)  # 4968
    self.opacity_effect = QtWidgets.QGraphicsOpacityEffect(self)  # 4970
    self.setGraphicsEffect(self.opacity_effect)  # 4971
    self.opacity_effect.setOpacity(0.0)  # 4972
    self.fade_in_animation = QtCore.QPropertyAnimation(self.opacity_effect, b'opacity')  # 4974  # const-recovered
    self.fade_in_animation.setDuration(300)  # 4975  # const-recovered
    self.fade_in_animation.setStartValue(0.0)  # 4976
    self.fade_in_animation.setEndValue(1.0)  # 4977
    layout = QtWidgets.QHBoxLayout(self)  # 4979
    layout.setContentsMargins(10, 10, 10, 10)  # 4980  # const-recovered
    self.logo_label = QtWidgets.QLabel()  # 4982
    self.logo_label.setStyleSheet('background: transparent; border: none;')  # 4983  # const-recovered
    if self.logo_url:  # 4984
        self.load_logo(self.logo_url)  # 4985
    layout.addWidget(self.logo_label)  # 4987
    title_layout = QtWidgets.QHBoxLayout()  # 4988
    text_layout = QtWidgets.QVBoxLayout()  # 4989
    text_layout.setContentsMargins(10, 0, 10, 10)  # 4990  # const-recovered
    title_layout.setContentsMargins(10, 10, 10, 0)  # 4991  # const-recovered
    title_layout.setSpacing(0)  # 4992
    self.type_button = QtWidgets.QPushButton(self)  # 4994
    type_icon = 'https://nighty.one/img/info.png'  # 4995  # const-recovered
    if self.type == 'INFO':  # 4996
        type_icon = 'https://nighty.one/img/info.png'  # 4997  # const-recovered (same const idx as default)
    elif self.type == 'SUCCESS':  # 4998
        type_icon = 'https://nighty.one/img/success.png'  # 4999  # const-recovered
    elif self.type == 'ERROR':  # 5000
        type_icon = 'https://nighty.one/img/error.png'  # 5001  # const-recovered
    self.set_icon_from_url(self.type_button, type_icon)  # 5003
    self.title_label = QtWidgets.QLabel(self.title)  # 5008
    font = QtGui.QFont('Segoe UI')  # 5009  # const-recovered
    font.setPointSize(11)  # 5010  # const-recovered
    font.setStyleStrategy(QtGui.QFont.PreferAntialias | QtGui.QFont.PreferQuality)  # 5011
    font.setWeight(QtGui.QFont.Bold)  # 5012
    self.title_label.setFont(font)  # 5013
    self.title_label.setStyleSheet('color: white; background: transparent;')  # 5014  # const-recovered
    title_layout.addWidget(self.type_button, alignment=QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)  # 5015
    title_layout.addWidget(self.title_label, alignment=QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)  # 5016
    title_layout.addStretch(1)  # 5017
    text_layout.addStretch(1)  # 5019
    text_layout.addLayout(title_layout)  # 5020
    self.message_label = SpacedLabel(self.message, line_height=1)  # 5022  # const-recovered (kw name+value decoyed)
    font = QtGui.QFont('Segoe UI')  # 5023  # const-recovered
    font.setPointSize(9)  # 5024  # const-recovered
    font.setStyleStrategy(QtGui.QFont.PreferAntialias | QtGui.QFont.PreferQuality)  # 5025
    font.setWeight(QtGui.QFont.Normal)  # 5026
    self.message_label.setFont(font)  # 5027
    self.message_label.setStyleSheet('color: #cccccc; background: transparent;')  # 5028  # const-recovered
    self.message_label.setWordWrap(True)  # 5029
    self.message_label.setFixedWidth(360)  # 5030  # const-recovered
    text_layout.addWidget(self.message_label)  # 5031
    layout.addLayout(text_layout)  # 5033
    self.close_button = QtWidgets.QPushButton(self)  # 5035
    self.set_icon_from_url(self.close_button, 'https://nighty.one/img/close.png', size=14)  # 5036  # const-recovered
    self.close_button.setStyleSheet('QPushButton { background: transparent; border: none; color: white; }')  # 5040  # const-recovered
    self.close_button.clicked.connect(lambda: self.close())  # 5049 (lambda body is decoyed const - inferred)
    layout.addWidget(self.close_button, alignment=QtCore.Qt.AlignTop | QtCore.Qt.AlignRight)  # 5050
    self.adjustSize()  # 5052
    self.setMaximumHeight(self.MAX_HEIGHT)  # 5054
    current_height = self.sizeHint().height()  # 5056
    self.setFixedHeight(current_height)  # 5057
    self.layout().invalidate()  # 5058
    desktop = QtWidgets.QApplication.desktop()  # 5060
    screen_number = desktop.screenNumber(QtGui.QCursor.pos())  # 5061
    self.primary_geometry = desktop.screenGeometry(screen_number)  # 5062
    self.animation = QtCore.QPropertyAnimation(self, b'pos')  # 5065  # const-recovered
    self.animation.setDuration(400)  # 5066  # const-recovered
    self.animation.setEasingCurve(QtCore.QEasingCurve.OutQuart)  # 5067
    self.fade_out_timer = QtCore.QTimer(self)  # 5070
    self.fade_out_timer.setInterval(timeout)  # 5071
    self.fade_out_timer.timeout.connect(self.start_fade_out)  # 5072
    self.fade_animation = QtCore.QPropertyAnimation(self.opacity_effect, b'opacity')  # 5074  # const-recovered
    self.fade_animation.setDuration(300)  # 5075  # const-recovered
    self.fade_animation.setStartValue(1)  # 5076
    self.fade_animation.setEndValue(0)  # 5077
    self.fade_animation.finished.connect(self.close_and_remove)  # 5078

############################################################################

# ToastNotification-style QFrame toast widget __init__. argc=10, stream 1472
# bytes / 736 instrs. Consts are armor-decoyed (bare ints); every inferred
# literal is tagged '# const-recovered'. Statement order follows the resolved
# disassembly exactly; trailing '# NNNN' = TRUE line-map statement line.
#
# ANOMALIES (stream-level, resolved by structure not raw jump args):
#  - 0x8d = armor CALL_FUNCTION_KW (D dump prints CALL_FUNCTION/BUILD_LIST);
#    a decoyed LOAD_CONST right before it is the kw-names tuple in each case
#    (addWidget alignment=..., SpacedLabel line_height=..., set_icon_from_url
#    size=..., super kwargs in L3940).
#  - 0x54 = armor BINARY_OR remap (dumped as IMPORT_STAR): every '|' of Qt
#    alignment flags / window hints / QFont style strategies.
#  - 0xbc xx = 2-byte decoy inserted before most POP_JUMP_IF_FALSE (dumped as
#    LOAD_DEREF __class__ / LOAD_DEREF 2). Semantically invisible.
#  - jump-arg bytes are unreliable (e.g. addr 646 POP_JUMP_IF_FALSE arg 0xa4
#    points mid-instruction; semantic target is addr 660). Control flow was
#    taken from the if/elif statement shapes.
#  - armor flips some LOAD_METHOD bytes to LOAD_ATTR (e.g. addWidget at 908,
#    setWindowFlags chain at 4); both decode to plain attribute call source.
#  - addr 1184-1192: 0xc4/0xc9/0xce = LOAD_CLOSURE 0 / BUILD_TUPLE 1 /
#    MAKE_FUNCTION 8 => self.close_button.clicked.connect(<lambda capturing
#    self>); the lambda body lives in decoyed const 39 and is NOT recoverable
#    from this stream - 'self.close()' is the idiomatic guess.
#  - lnotab is armor-scrambled mid-statement (4164 -> 4419 -> 4675 -> 4930).
#  - setCursor(PointingHandCursor) appears twice (map 4963/4965) and the blur
#    effect is set then replaced by the opacity effect (4966-4972): kept
#    verbatim - it is what the stream says.
#  - SpacedLabel kwarg name (const 30) and set_icon_from_url kwarg name
#    (const 37) are decoyed; inferred from SpacedLabel.__init__ (L4021)
#    varnames and call shape. Icon URLs / stylesheet texts / durations /
#    colors are plausible literals, not captured values. Const-index identity
#    constraints were preserved (e.g. type_icon default == INFO-branch icon
#    share const 21; int 0 / float 0.0 / int 1 / float 1.0 kept distinct as
#    the const table demands).
def __init__(self, message, logo_url=None, timeout=5000, on_click=None,
             type_=None, title=None, details=None, manager=None,
             side='right'):
    super().__init__()  # 4143
    QtCore.QLoggingCategory.setFilterRules('*.debug=false\nqt.qpa.*=false')  # 4144  # const-recovered
    self.manager = manager  # 4146
    self.side = side  # 4147
    self.message = truncate_string(convert_custom_emojis(message), 150)  # 4148  # const-recovered
    self.title = truncate_string(convert_custom_emojis(title), 30) if title else type_  # 4149  # const-recovered
    if details:  # 4150
        self.details = truncate_string(convert_custom_emojis(details), 100)  # 4151  # const-recovered
    else:
        self.details = truncate_string(convert_custom_emojis(message), 100)  # 4153  # const-recovered
    self.logo_url = logo_url  # 4154
    self.type = type_  # 4155
    self.on_click = on_click  # 4156
    self.network_manager = QNetworkAccessManager(self)  # 4157
    self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint | QtCore.Qt.SplashScreen)  # 4162-4164
    self.setAttribute(QtCore.Qt.WA_TranslucentBackground)  # 4935
    self.setAttribute(QtCore.Qt.WA_ShowWithoutActivating)  # 4936
    self.setStyleSheet('QFrame { background: transparent; border-radius: 10px; }')  # 4937  # const-recovered
    self._bg_color = QtGui.QColor(0, 0, 0)  # 4939  # const-recovered
    self.setProperty('gradient', self._bg_color)  # 4940
    self._gradient_start = QtGui.QColor(0, 0, 0)  # 4942  # const-recovered
    self._gradient_end = QtGui.QColor(0, 0, 45)  # 4943  # const-recovered
    if self.type == 'SUCCESS':  # 4944
        self._gradient_end = QtGui.QColor(0, 45, 0)  # 4945  # const-recovered
    elif self.type == 'ERROR':  # 4946
        self._gradient_end = QtGui.QColor(45, 0, 0)  # 4947  # const-recovered
    self.hover_gradient_start = QtGui.QColor(0, 0, 0)  # 4950  # const-recovered
    self.hover_gradient_end = QtGui.QColor(60, 60, 60)  # 4951  # const-recovered
    self.is_hovered = False  # 4953
    self.gradient_in_animation = QPropertyAnimation(self, b'gradient')  # 4955  # const-recovered
    self.gradient_in_animation.setDuration(300)  # 4956  # const-recovered
    self.gradient_in_animation.setEndValue(self.hover_gradient_end)  # 4957
    self.gradient_out_animation = QPropertyAnimation(self, b'gradient')  # 4959  # const-recovered
    self.gradient_out_animation.setDuration(300)  # 4960  # const-recovered
    self.gradient_out_animation.setEndValue(self._gradient_end)  # 4961
    self.setCursor(QtCore.Qt.PointingHandCursor)  # 4963
    self.setCursor(QtCore.Qt.PointingHandCursor)  # 4965 (duplicate in stream - kept)
    self.blur_effect = QtWidgets.QGraphicsBlurEffect()  # 4966
    self.blur_effect.setBlurRadius(20)  # 4967  # const-recovered
    self.setGraphicsEffect(self.blur_effect)  # 4968
    self.opacity_effect = QtWidgets.QGraphicsOpacityEffect(self)  # 4970
    self.setGraphicsEffect(self.opacity_effect)  # 4971
    self.opacity_effect.setOpacity(0.0)  # 4972
    self.fade_in_animation = QtCore.QPropertyAnimation(self.opacity_effect, b'opacity')  # 4974  # const-recovered
    self.fade_in_animation.setDuration(300)  # 4975  # const-recovered
    self.fade_in_animation.setStartValue(0.0)  # 4976
    self.fade_in_animation.setEndValue(1.0)  # 4977
    layout = QtWidgets.QHBoxLayout(self)  # 4979
    layout.setContentsMargins(10, 10, 10, 10)  # 4980  # const-recovered
    self.logo_label = QtWidgets.QLabel()  # 4982
    self.logo_label.setStyleSheet('background: transparent; border: none;')  # 4983  # const-recovered
    if self.logo_url:  # 4984
        self.load_logo(self.logo_url)  # 4985
    layout.addWidget(self.logo_label)  # 4987
    title_layout = QtWidgets.QHBoxLayout()  # 4988
    text_layout = QtWidgets.QVBoxLayout()  # 4989
    text_layout.setContentsMargins(10, 0, 10, 10)  # 4990  # const-recovered
    title_layout.setContentsMargins(10, 10, 10, 0)  # 4991  # const-recovered
    title_layout.setSpacing(0)  # 4992
    self.type_button = QtWidgets.QPushButton(self)  # 4994
    type_icon = 'https://nighty.one/img/info.png'  # 4995  # const-recovered
    if self.type == 'INFO':  # 4996
        type_icon = 'https://nighty.one/img/info.png'  # 4997  # const-recovered (same const idx as default)
    elif self.type == 'SUCCESS':  # 4998
        type_icon = 'https://nighty.one/img/success.png'  # 4999  # const-recovered
    elif self.type == 'ERROR':  # 5000
        type_icon = 'https://nighty.one/img/error.png'  # 5001  # const-recovered
    self.set_icon_from_url(self.type_button, type_icon)  # 5003
    self.title_label = QtWidgets.QLabel(self.title)  # 5008
    font = QtGui.QFont('Segoe UI')  # 5009  # const-recovered
    font.setPointSize(11)  # 5010  # const-recovered
    font.setStyleStrategy(QtGui.QFont.PreferAntialias | QtGui.QFont.PreferQuality)  # 5011
    font.setWeight(QtGui.QFont.Bold)  # 5012
    self.title_label.setFont(font)  # 5013
    self.title_label.setStyleSheet('color: white; background: transparent;')  # 5014  # const-recovered
    title_layout.addWidget(self.type_button, alignment=QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)  # 5015
    title_layout.addWidget(self.title_label, alignment=QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)  # 5016
    title_layout.addStretch(1)  # 5017
    text_layout.addStretch(1)  # 5019
    text_layout.addLayout(title_layout)  # 5020
    self.message_label = SpacedLabel(self.message, line_height=1)  # 5022  # const-recovered (kw name+value decoyed)
    font = QtGui.QFont('Segoe UI')  # 5023  # const-recovered
    font.setPointSize(9)  # 5024  # const-recovered
    font.setStyleStrategy(QtGui.QFont.PreferAntialias | QtGui.QFont.PreferQuality)  # 5025
    font.setWeight(QtGui.QFont.Normal)  # 5026
    self.message_label.setFont(font)  # 5027
    self.message_label.setStyleSheet('color: #cccccc; background: transparent;')  # 5028  # const-recovered
    self.message_label.setWordWrap(True)  # 5029
    self.message_label.setFixedWidth(360)  # 5030  # const-recovered
    text_layout.addWidget(self.message_label)  # 5031
    layout.addLayout(text_layout)  # 5033
    self.close_button = QtWidgets.QPushButton(self)  # 5035
    self.set_icon_from_url(self.close_button, 'https://nighty.one/img/close.png', size=14)  # 5036  # const-recovered
    self.close_button.setStyleSheet('QPushButton { background: transparent; border: none; color: white; }')  # 5040  # const-recovered
    self.close_button.clicked.connect(lambda: self.close())  # 5049 (lambda body is decoyed const - inferred)
    layout.addWidget(self.close_button, alignment=QtCore.Qt.AlignTop | QtCore.Qt.AlignRight)  # 5050
    self.adjustSize()  # 5052
    self.setMaximumHeight(self.MAX_HEIGHT)  # 5054
    current_height = self.sizeHint().height()  # 5056
    self.setFixedHeight(current_height)  # 5057
    self.layout().invalidate()  # 5058
    desktop = QtWidgets.QApplication.desktop()  # 5060
    screen_number = desktop.screenNumber(QtGui.QCursor.pos())  # 5061
    self.primary_geometry = desktop.screenGeometry(screen_number)  # 5062
    self.animation = QtCore.QPropertyAnimation(self, b'pos')  # 5065  # const-recovered
    self.animation.setDuration(400)  # 5066  # const-recovered
    self.animation.setEasingCurve(QtCore.QEasingCurve.OutQuart)  # 5067
    self.fade_out_timer = QtCore.QTimer(self)  # 5070
    self.fade_out_timer.setInterval(timeout)  # 5071
    self.fade_out_timer.timeout.connect(self.start_fade_out)  # 5072
    self.fade_animation = QtCore.QPropertyAnimation(self.opacity_effect, b'opacity')  # 5074  # const-recovered
    self.fade_animation.setDuration(300)  # 5075  # const-recovered
    self.fade_animation.setStartValue(1)  # 5076
    self.fade_animation.setEndValue(0)  # 5077
    self.fade_animation.finished.connect(self.close_and_remove)  # 5078


############################################################################
############################################################################
# get_side_offset   (original line 4312)


############################################################################
# get_side_offset   (original line 4312)
############################################################################

# Class: ToastNotification (bank dec_ToastNotification.get_side_offset).
# Evidence: live_L4312.stream 60B / 30 instrs, all 30 resolved, zero opaque ops.
# Structure (offsets stream-relative):
#   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) side ; 4 LOAD_CONST c1 ; 6 COMPARE_OP(0x87)==
#   8  POP_JUMP_IF_FALSE 0x28=40 (full-code abs; -16 -> stream 24)
#   10 self.primary_geometry ; 14 LOAD_METHOD(0x76) x ; 16 CALL_METHOD(0xf8)0
#   18 LOAD_CONST c2 ; 20 op 0x12 = BINARY_ADD (armor slot; std 18 undefined)
#   22 RETURN_VALUE(0x23)
#   24 if side == c3 ; 32 PJIF 0x48=72 -> stream 56 (fall-through return)
#   34 self.primary_geometry.width() ; 42 self.width() ; 48 op 0x4c = BINARY_SUBTRACT
#   (armor slot; std 76=INPLACE_RSHIFT nonsensical here) ; 50 c2 ; 52 0x4c again
#   54 RETURN ; 56 LOAD_CONST c4 (None) ; 58 RETURN  (implicit tail return)
# Consts: armor-stripped (decoy int 333). c1/c3 = side tags: branch1 anchors at
#   primary_geometry.x() + margin -> 'left'; branch2 anchors at width-width-margin
#   -> 'right' (inferred, values not recoverable). c2 = margin (20 assumed).
#   c4 = None. Original had a blank/comment line 4313 (lnotab gap).
# Anomalies: none. names dedup: 'width' indexes both QGeometry and QWidget call.

def get_side_offset(self):
    # (line 4313: blank/comment in original - lnotab gap)

    if self.side == 'left':
        return self.primary_geometry.x() + 20
    if self.side == 'right':
        return self.primary_geometry.width() - self.width() - 20

############################################################################
############################################################################
# set_icon_from_url   (original line 4319)


############################################################################
# set_icon_from_url   (original line 4319)
############################################################################

def set_icon_from_url(self, button, url, size):
    manager = QNetworkAccessManager(self)
    request = QNetworkRequest(QUrl(url))
    loop = QtCore.QEventLoop()
    reply = manager.get(request)
    reply.finished.connect(loop.quit)
    loop.exec_()
    if reply.error() == reply.NoError:
        pixmap = QPixmap()
        pixmap.loadFromData(reply.readAll())
        button.setIcon(QtGui.QIcon(pixmap))
        button.setIconSize(QtCore.QSize(size * 0.8, size * 0.8))  # const-recovered
    else:
        sys.stdout.write(f'Error loading icon: {reply.errorString()}\n')  # const-recovered

############################################################################
############################################################################
# paintEvent   (original line 4363)


############################################################################
# paintEvent   (original line 4363)
############################################################################

def paintEvent(self, event):
    painter = QtGui.QPainter(self)
    painter.setRenderHint(QtGui.QPainter.Antialiasing)
    gradient = QtGui.QLinearGradient(0, 0, self.width(), 0)  # const-recovered
    gradient.setColorAt(0.0, self._gradient_start)  # const-recovered
    gradient.setColorAt(1.0, self._gradient_end)  # const-recovered
    painter.setBrush(QtGui.QBrush(gradient))
    painter.setPen(QtCore.Qt.NoPen)
    painter.drawRoundedRect(self.rect(), 10, 10)  # const-recovered

############################################################################
############################################################################
# enterEvent   (original line 4382)


############################################################################
# enterEvent   (original line 4382)
############################################################################

def enterEvent(self, event):
    self.fade_out_timer.stop()
    self.is_hovered = True  # const-recovered
    self.gradient_out_animation.stop()
    self.gradient_in_animation.start()
    if self.details:
        self.message_label.setText(self.details)
        self.adjust_notification_size()
    super().enterEvent(event)

############################################################################

def enterEvent(self, event):
    self.fade_out_timer.stop()
    self.is_hovered = True  # const-recovered
    self.gradient_out_animation.stop()
    self.gradient_in_animation.start()
    if self.details:
        self.message_label.setText(self.details)
        self.adjust_notification_size()
    super().enterEvent(event)


def paintEvent(self, event):
    painter = QtGui.QPainter(self)
    painter.setRenderHint(QtGui.QPainter.Antialiasing)
    gradient = QtGui.QLinearGradient(0, 0, self.width(), 0)  # const-recovered
    gradient.setColorAt(0.0, self._gradient_start)  # const-recovered
    gradient.setColorAt(1.0, self._gradient_end)  # const-recovered
    painter.setBrush(QtGui.QBrush(gradient))
    painter.setPen(QtCore.Qt.NoPen)
    painter.drawRoundedRect(self.rect(), 10, 10)  # const-recovered


def set_icon_from_url(self, button, url, size):
    manager = QNetworkAccessManager(self)
    request = QNetworkRequest(QUrl(url))
    loop = QtCore.QEventLoop()
    reply = manager.get(request)
    reply.finished.connect(loop.quit)
    loop.exec_()
    if reply.error() == reply.NoError:
        pixmap = QPixmap()
        pixmap.loadFromData(reply.readAll())
        button.setIcon(QtGui.QIcon(pixmap))
        button.setIconSize(QtCore.QSize(size * 0.8, size * 0.8))  # const-recovered
    else:
        sys.stdout.write(f'Error loading icon: {reply.errorString()}\n')  # const-recovered


# Class: ToastNotification (bank dec_ToastNotification.get_side_offset).
# Evidence: live_L4312.stream 60B / 30 instrs, all 30 resolved, zero opaque ops.
# Structure (offsets stream-relative):
#   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) side ; 4 LOAD_CONST c1 ; 6 COMPARE_OP(0x87)==
#   8  POP_JUMP_IF_FALSE 0x28=40 (full-code abs; -16 -> stream 24)
#   10 self.primary_geometry ; 14 LOAD_METHOD(0x76) x ; 16 CALL_METHOD(0xf8)0
#   18 LOAD_CONST c2 ; 20 op 0x12 = BINARY_ADD (armor slot; std 18 undefined)
#   22 RETURN_VALUE(0x23)
#   24 if side == c3 ; 32 PJIF 0x48=72 -> stream 56 (fall-through return)
#   34 self.primary_geometry.width() ; 42 self.width() ; 48 op 0x4c = BINARY_SUBTRACT
#   (armor slot; std 76=INPLACE_RSHIFT nonsensical here) ; 50 c2 ; 52 0x4c again
#   54 RETURN ; 56 LOAD_CONST c4 (None) ; 58 RETURN  (implicit tail return)
# Consts: armor-stripped (decoy int 333). c1/c3 = side tags: branch1 anchors at
#   primary_geometry.x() + margin -> 'left'; branch2 anchors at width-width-margin
#   -> 'right' (inferred, values not recoverable). c2 = margin (20 assumed).
#   c4 = None. Original had a blank/comment line 4313 (lnotab gap).
# Anomalies: none. names dedup: 'width' indexes both QGeometry and QWidget call.

def get_side_offset(self):
    # (line 4313: blank/comment in original - lnotab gap)

    if self.side == 'left':
        return self.primary_geometry.x() + 20
    if self.side == 'right':
        return self.primary_geometry.width() - self.width() - 20

# reposition_notifications   (original line 4130)
############################################################################

def reposition_notifications(self):
    y_offset = 10  # const-recovered
    for notification in self.notifications:
        notification.adjustSize()
        notification.slide_up(y_offset)
        y_offset -= notification.height() + 10  # const-recovered spacing

# leaveEvent   (original line 4392)


############################################################################
# leaveEvent   (original line 4392)
############################################################################

def leaveEvent(self, event):
    self.fade_out_timer.start()
    self.is_hovered = False  # const-recovered
    self.gradient_in_animation.stop()
    self.gradient_out_animation.start()
    if self.details:
        self.message_label.setText(self.message.replace('\n', '<br>'))  # const-recovered
        self.adjust_notification_size()
    super().leaveEvent(event)

# adjust_notification_size   (original line 4402)


############################################################################
############################################################################
# slide_up   (original line 4411)


############################################################################
# slide_up   (original line 4411)
############################################################################

# Class: ToastNotification (bank dec_ToastNotification.slide_up).
# Evidence: live_L4411.stream 134B / 67 instrs, all 67 resolved, zero opaque ops.
# Key offsets (stream-relative; jump args are full-code coords, code = 166B,
# stream = code[16:-16], so subtract 16):
#   0   self.animation.stop()
#   10  if self.side == c1:  (COMPARE_OP 0x87 arg2 '=='; PJIF 0x4e=78 -> stream 62)
#   20  self.animation.setStartValue(self.pos())
#   36  self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
#   60  JUMP_FORWARD(0xf1) delta 0x3a=58: full 76+2+58=136 -> stream 120 (start())
#   62  elif self.side == c2:  (PJIF 0x88=136 -> stream 120)
#   72  self.animation.setStartValue(QtCore.QPoint(self.get_side_offset(), y_offset))
#   96  self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
#   120 self.animation.start() ; 130 LOAD_CONST None ; 132 RETURN_VALUE
# Consts: armor-stripped (decoy int 346); c1/c2 = side tags 'left'/'right'
#   (inferred, consistent with get_side_offset L4312 branch order); c0 = None.
# ANOMALY (stream-faithful): in the elif branch setStartValue and setEndValue
#   receive the IDENTICAL QtCore.QPoint(self.get_side_offset(), y_offset)
#   expression - the two 12-instruction blocks differ ONLY in method index
#   (0x7603 setStartValue vs 0x7605 setEndValue). The animation is therefore a
#   no-op for that side; reproduced literally, likely an original-source
#   copy-paste artifact (start value probably meant to be self.pos()).
# names order (animation, stop, side, setStartValue, pos, setEndValue, QtCore,
#   QPoint, get_side_offset, start) round-trips exactly - confirms branch order.

def slide_up(self, y_offset):
    self.animation.stop()
    if self.side == 'left':
        self.animation.setStartValue(self.pos())
        self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    elif self.side == 'right':
        self.animation.setStartValue(QtCore.QPoint(self.get_side_offset(), y_offset))
        self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    self.animation.start()

############################################################################
############################################################################
# load_logo   (original line 4421)


############################################################################
# load_logo   (original line 4421)
############################################################################

def load_logo(self, url):
    self.network_manager.finished.connect(self.on_image_loaded)
    request = QNetworkRequest(QUrl(url))
    self.network_manager.get(request)

############################################################################

def load_logo(self, url):
    self.network_manager.finished.connect(self.on_image_loaded)
    request = QNetworkRequest(QUrl(url))
    self.network_manager.get(request)


# Class: ToastNotification (bank dec_ToastNotification.slide_up).
# Evidence: live_L4411.stream 134B / 67 instrs, all 67 resolved, zero opaque ops.
# Key offsets (stream-relative; jump args are full-code coords, code = 166B,
# stream = code[16:-16], so subtract 16):
#   0   self.animation.stop()
#   10  if self.side == c1:  (COMPARE_OP 0x87 arg2 '=='; PJIF 0x4e=78 -> stream 62)
#   20  self.animation.setStartValue(self.pos())
#   36  self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
#   60  JUMP_FORWARD(0xf1) delta 0x3a=58: full 76+2+58=136 -> stream 120 (start())
#   62  elif self.side == c2:  (PJIF 0x88=136 -> stream 120)
#   72  self.animation.setStartValue(QtCore.QPoint(self.get_side_offset(), y_offset))
#   96  self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
#   120 self.animation.start() ; 130 LOAD_CONST None ; 132 RETURN_VALUE
# Consts: armor-stripped (decoy int 346); c1/c2 = side tags 'left'/'right'
#   (inferred, consistent with get_side_offset L4312 branch order); c0 = None.
# ANOMALY (stream-faithful): in the elif branch setStartValue and setEndValue
#   receive the IDENTICAL QtCore.QPoint(self.get_side_offset(), y_offset)
#   expression - the two 12-instruction blocks differ ONLY in method index
#   (0x7603 setStartValue vs 0x7605 setEndValue). The animation is therefore a
#   no-op for that side; reproduced literally, likely an original-source
#   copy-paste artifact (start value probably meant to be self.pos()).
# names order (animation, stop, side, setStartValue, pos, setEndValue, QtCore,
#   QPoint, get_side_offset, start) round-trips exactly - confirms branch order.

def slide_up(self, y_offset):
    self.animation.stop()
    if self.side == 'left':
        self.animation.setStartValue(self.pos())
        self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    elif self.side == 'right':
        self.animation.setStartValue(QtCore.QPoint(self.get_side_offset(), y_offset))
        self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    self.animation.start()

# adjust_notification_size   (original line 4402)
############################################################################

def adjust_notification_size(self):
    self.adjustSize()
    new_height = self.sizeHint().height()
    self.setFixedHeight(new_height)
    self.layout().invalidate()
    self.manager.reposition_notifications()

# on_image_loaded   (original line 4426)


############################################################################
############################################################################
# show_notification   (original line 4433)


############################################################################
# show_notification   (original line 4433)
############################################################################

def show_notification(self):
    self.show()
    self.fade_in_animation.start()
    self.fade_out_timer.start()

############################################################################
############################################################################
# start_fade_out   (original line 4438)


############################################################################
# start_fade_out   (original line 4438)
############################################################################

def start_fade_out(self):
    self.fade_out_timer.stop()
    self.fade_animation.start()

############################################################################
############################################################################
# close_and_remove   (original line 4442)


############################################################################
# close_and_remove   (original line 4442)
############################################################################

def close_and_remove(self):
    self.manager.remove_notification(self)
    self.close()

############################################################################

def close_and_remove(self):
    self.manager.remove_notification(self)
    self.close()


def start_fade_out(self):
    self.fade_out_timer.stop()
    self.fade_animation.start()


def show_notification(self):
    self.show()
    self.fade_in_animation.start()
    self.fade_out_timer.start()

# on_image_loaded   (original line 4426)
############################################################################

# [confidence=medium - see wave45 evidence]
def on_image_loaded(self, reply):
    if reply.error() == reply.NoError:
        pixmap = QPixmap()
        pixmap.loadFromData(reply.readAll())
        self.logo_label.setPixmap(pixmap.scaled(32, 32,  # const-recovered
                                                QtCore.Qt.KeepAspectRatio,
                                                QtCore.Qt.SmoothTransformation))
        reply.deleteLater()

# mousePressEvent   (original line 4446)


############################################################################
############################################################################
# __init__   (original line 4457)


############################################################################
# __init__   (original line 4457)
############################################################################

def __init__(self, notification_queue):
    super().__init__()
    self.notification_queue = notification_queue
    self.running = True

############################################################################
############################################################################
# run   (original line 4462)
############################################################################
############################################################################
# stop   (original line 4473)
############################################################################

# [confidence=low - see wave45 evidence]
def stop(self):
    self.running = False


############################################################################
# run   (original line 4462)
############################################################################

# Class: NotificationWorker(QThread) (bank dec_NotificationWorker.run).
# ENCODING NOTE: live_L4462.stream (104B, 52 slots) did NOT decode with the
#   wave45 wl6 tier - its bytes (d5db 51e0 36ca ...) show no opcode structure
#   (25 unknown opcodes in the old translation); the old dump dis_L4462.txt is
#   the guard-theory mis-decode (all UNARY_POSITIVE). This body is therefore a
#   SEMANTIC reconstruction from: TRUE varnames (self, operation, data), TRUE
#   names order (running, notification_queue, get, notification_received, emit,
#   notification_closed, queue, Empty), the lnotab statement map
#   (statements at full-code offsets 0/6/8/26/34/48/56/72/88 = 10 lines
#   4462..4471), the verified family frame (QThread worker pulling
#   notification_queue with self.running checks; payload 2-tuple
#   ('toast', (text, logo_url, timeout, on_click, type_, title, details))
#   encoded by NotificationSender.sendToast L4490), and py38 idioms.
# Line fit: 4462 def / 4463 while / 4464 try / 4465 get-unpack (9 instrs,
#   consistent with get(True, 0.5) positional) / 4466 if / 4467 emit /
#   4468 elif / 4469 emit / 4470 except queue.Empty / 4471 continue.
# UNVERIFIED details (const values stripped, stream unreadable): operation tags
#   'toast'/'close', the get() timeout value, and whether notification_closed
#   emits *data or no args.

def run(self):
    while self.running:
        try:
            operation, data = self.notification_queue.get(True, 0.5)
            if operation == 'toast':
                self.notification_received.emit(*data)
            elif operation == 'close':
                self.notification_closed.emit(*data)
        except queue.Empty:
            continue

############################################################################
############################################################################
# __init__   (original line 4478)


############################################################################
# __init__   (original line 4478)
############################################################################

def __init__(self):
    super().__init__()
    self.notification_queue = queue.Queue()
    self.worker_thread = NotificationWorker(self.notification_queue)
    self.worker_thread.notification_received.connect(self.show_notification)
    self.worker_thread.notification_closed.connect(self.close_notification)
    self.worker_thread.start()
    self.toast_manager = ToastNotificationManager()
    self.last_notification = None

############################################################################
############################################################################
# sendToast   (original line 4490)


############################################################################
# sendToast   (original line 4490)
############################################################################

# Class: NotificationSender (bank dec_NotificationSender.sendToast).
# Evidence: live_L4490.stream 34B / 17 instrs, all 17 resolved, zero opaque ops.
#   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) notification_queue
#   4  LOAD_METHOD(0x76) put ; 6 LOAD_CONST c1 (operation tag string)
#   8-20 LOAD_FAST text, logo_url, timeout, on_click, type_, title, details
#      (varname order 1..7 - NOTE timeout is 3rd, matches sendToast signature,
#       not the module-level showToast kwarg order)
#   22 op 0xc9 arg 7 = BUILD_TUPLE 7 (armor call/build variant; stack accounting:
#       pops the 7 fast loads below c1) ; 24 op 0xc9 arg 2 = BUILD_TUPLE 2
#       -> payload (c1, (text, logo_url, timeout, on_click, type_, title, details))
#   26 CALL_METHOD(0xf8) 1 ; 28 POP_TOP(0x10) ; 30 LOAD_CONST None ; 32 RETURN
# Consts: armor-stripped (decoy int 359, nconsts census 1 is the decoy view).
#   c0 = None (tail), c1 = operation tag, inferred 'toast' (consumed by
#   NotificationWorker.run L4462 dispatch; matches fence_target39 evidence that
#   the queue payload is a 2-tuple the app's own sendToast encodes).
# Anomalies: instance method (LOAD_FAST 0 = self), NOT a staticmethod and NOT a
#   manager.show_notification call - the queue.put is the whole body.

def sendToast(self, text, logo_url, timeout, on_click, type_, title, details):
    self.notification_queue.put(('toast', (text, logo_url, timeout, on_click, type_, title, details)))

############################################################################
############################################################################
# closeToast   (original line 4493)


############################################################################
# closeToast   (original line 4493)
############################################################################

def closeToast(self, notification):
    if notification in self.close_notification:
        self.close_notification.last_notification(notification)
        self.__armor_wrap__()  # guard-inferred: armor-residue call site in stream

############################################################################
############################################################################
# show_notification   (original line 4499)


############################################################################
# show_notification   (original line 4499)
############################################################################

def show_notification(self, text, logo_url, timeout, on_click, type_, title, details):
    notification = self.toast_manager.show_notification(text, logo_url, timeout, on_click, type_, title, details)
    self.last_notification = notification

############################################################################
############################################################################
# closeEvent   (original line 4506)
############################################################################
############################################################################
# __init__   (original line 4517)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self):
    super().__init__()
    self.tray_menu = QtWidgets.QMenu()  # const-recovered
    self.show_action = self.tray_menu.addAction('Show')  # const-recovered
    self.hide_action = self.tray_menu.addAction('Hide')  # const-recovered
    self.exit_action = self.tray_menu.addAction('Exit')  # const-recovered
    self.tray_icon = QtWidgets.QSystemTrayIcon()
    self.tray_icon.setIcon(QtGui.QIcon(getDataPath('nighty.png')))  # const-recovered
    self.tray_icon.setContextMenu(self.tray_menu)


############################################################################
############################################################################
# nightyScript   (original line 4608)

############################################################################
# nightyScript   (original line 4608)
############################################################################

# [confidence=medium - see wave45 evidence]
# Script decorator factory (referenced by get_metadata_from_decorator L4628:
# decorator.func.id == 'nightyScript', keyword args ast.literal_eval'd).
# Evidence: TRUE varnames (kwargs, metadata_defaults, decorator),
# cellvars (metadata,), flags 0x0b (**kwargs only), names empty modulo the
# __armor_wrap__ decoy, line map 4610-4613 (+ guard-era hints 4616/4619),
# envelope 70B -> stream 38B = 19 instruction slots. Compiled body is
# exactly 19 instructions (BUILD_CONST_KEY_MAP dict of 4 const entries,
# BUILD_MAP_UNPACK merge into the metadata cell, MAKE_FUNCTION closure
# over metadata, return decorator). Stream itself never decrypted
# (wl6/CTR tiers produce filler on this unit) - structure is derived from
# metadata + pair budget + family idiom.
# Consts are armor-decoyed: default metadata keys/values inferred from the
# 4-entry const-key-map budget and script-UI usage; each marked below.
# Anomalies: guard-era lnotab lists an extra statement line 4626 that the
# 19-pair budget cannot hold (likely decoy lnotab noise, as on L4746).

def nightyScript(**kwargs):
    metadata_defaults = {'name': 'Unknown', 'version': '1.0',  # const-recovered
                         'author': 'Unknown',  # const-recovered
                         'description': ''}  # const-recovered
    metadata = {**metadata_defaults, **kwargs}
    def decorator(func):
        func.metadata = metadata
        return func
    return decorator

############################################################################
############################################################################
# __new__   (original line 4650)

############################################################################
# __new__   (original line 4650)
############################################################################

# Singleton __new__ of the script-engine class family (bank label
# dec_ScriptEngine.__new__; source position 4650 sits on the class defined
# just above ScriptManager L4655, inherited by ScriptEngine L5007 whose
# ScriptEngine() call sites rely on the shared instance).
# Evidence: TRUE names (_instance, super, __new__ [+ decoy __armor_wrap__]),
# varnames (cls,), freevars (__class__,) => zero-arg super(), flags 0x03
# (sync), lines 4651/4652/4653, envelope 62B -> stream 30B = 15 slots.
# Compiled body = exactly 15 instructions; names emission order and
# __class__ freevar match the dossier exactly. `is None` form (not
# truthiness) required by the 15-slot budget.

def __new__(cls):
    if cls._instance is None:
        cls._instance = super().__new__(cls)
    return cls._instance

############################################################################
############################################################################
# inject   (original line 4659)

############################################################################
# inject   (original line 4659)
############################################################################

# ScriptManager/ScriptEngine.inject(self, scriptname, code) - instance
# script injector. Byte-verified: the fence44 post-force-call marshal
# envelope decrypts (wl6 tier) to a 104B VM stream whose 52 instructions
# match this body op-for-op and arg-for-arg (0 mismatches), including the
# CALL arities and the co_names emission order
# (exec, _injected_scripts, items, callable, setattr, MethodType, append).
# TRUE line map from the post-marshal lnotab: 4660 local_scope, 4662 exec,
# 4664 if-not-in, 4665 methods init, 4667 for, 4668 if-callable,
# 4669 setattr/MethodType, 4670 append. flags 0x43 => sync def.
# VM ops: a3=BUILD_MAP, b1=BUILD_LIST, 0x93 family=BUILD_CONST_KEY_MAP,
# 5c=UNPACK_SEQUENCE, 14/15=BINARY/STORE_SUBSCR, bc-prefixed pairs before
# POP_JUMP_IF_FALSE are armor guards (ignored).
# Anomalies: (1) stream CALL_FUNCTION arity for exec is 1 (exec(code)),
# which leaves local_scope empty at runtime - the armor most likely
# rewrote the call args; the working original was presumably
# exec(code, local_scope) or exec(code, globals(), local_scope) (as the
# verified sibling L5015 does). Arity is law, so the 1-arg form is kept.
# (2) The fence29 dec-bank twin of this unit is an armor DECOY (fake async
# for/try/except loops over names like self.items/self.setattr); ignored.
# Consts are armor-decoyed: the {'methods': []} key and the trailing
# implicit-return None inferred from family usage in deject (entry[
# 'methods']) and call sites ScriptEngine().inject(name, source).

def inject(self, scriptname, code):
    local_scope = {}
    exec(code)
    if scriptname not in self._injected_scripts:
        self._injected_scripts[scriptname] = {'methods': []}  # const-recovered
    for name, func in local_scope.items():
        if callable(func):
            setattr(self, name, MethodType(func, self))
            self._injected_scripts[scriptname]['methods'].append(name)

############################################################################

# ScriptManager/ScriptEngine.inject(self, scriptname, code) - instance
# script injector. Byte-verified: the fence44 post-force-call marshal
# envelope decrypts (wl6 tier) to a 104B VM stream whose 52 instructions
# match this body op-for-op and arg-for-arg (0 mismatches), including the
# CALL arities and the co_names emission order
# (exec, _injected_scripts, items, callable, setattr, MethodType, append).
# TRUE line map from the post-marshal lnotab: 4660 local_scope, 4662 exec,
# 4664 if-not-in, 4665 methods init, 4667 for, 4668 if-callable,
# 4669 setattr/MethodType, 4670 append. flags 0x43 => sync def.
# VM ops: a3=BUILD_MAP, b1=BUILD_LIST, 0x93 family=BUILD_CONST_KEY_MAP,
# 5c=UNPACK_SEQUENCE, 14/15=BINARY/STORE_SUBSCR, bc-prefixed pairs before
# POP_JUMP_IF_FALSE are armor guards (ignored).
# Anomalies: (1) stream CALL_FUNCTION arity for exec is 1 (exec(code)),
# which leaves local_scope empty at runtime - the armor most likely
# rewrote the call args; the working original was presumably
# exec(code, local_scope) or exec(code, globals(), local_scope) (as the
# verified sibling L5015 does). Arity is law, so the 1-arg form is kept.
# (2) The fence29 dec-bank twin of this unit is an armor DECOY (fake async
# for/try/except loops over names like self.items/self.setattr); ignored.
# Consts are armor-decoyed: the {'methods': []} key and the trailing
# implicit-return None inferred from family usage in deject (entry[
# 'methods']) and call sites ScriptEngine().inject(name, source).

def inject(self, scriptname, code):
    local_scope = {}
    exec(code)
    if scriptname not in self._injected_scripts:
        self._injected_scripts[scriptname] = {'methods': []}  # const-recovered
    for name, func in local_scope.items():
        if callable(func):
            setattr(self, name, MethodType(func, self))
            self._injected_scripts[scriptname]['methods'].append(name)


# Singleton __new__ of the script-engine class family (bank label
# dec_ScriptEngine.__new__; source position 4650 sits on the class defined
# just above ScriptManager L4655, inherited by ScriptEngine L5007 whose
# ScriptEngine() call sites rely on the shared instance).
# Evidence: TRUE names (_instance, super, __new__ [+ decoy __armor_wrap__]),
# varnames (cls,), freevars (__class__,) => zero-arg super(), flags 0x03
# (sync), lines 4651/4652/4653, envelope 62B -> stream 30B = 15 slots.
# Compiled body = exactly 15 instructions; names emission order and
# __class__ freevar match the dossier exactly. `is None` form (not
# truthiness) required by the 15-slot budget.

def __new__(cls):
    if cls._instance is None:
        cls._instance = super().__new__(cls)
    return cls._instance


# [confidence=medium - see wave45 evidence]
# Script decorator factory (referenced by get_metadata_from_decorator L4628:
# decorator.func.id == 'nightyScript', keyword args ast.literal_eval'd).
# Evidence: TRUE varnames (kwargs, metadata_defaults, decorator),
# cellvars (metadata,), flags 0x0b (**kwargs only), names empty modulo the
# __armor_wrap__ decoy, line map 4610-4613 (+ guard-era hints 4616/4619),
# envelope 70B -> stream 38B = 19 instruction slots. Compiled body is
# exactly 19 instructions (BUILD_CONST_KEY_MAP dict of 4 const entries,
# BUILD_MAP_UNPACK merge into the metadata cell, MAKE_FUNCTION closure
# over metadata, return decorator). Stream itself never decrypted
# (wl6/CTR tiers produce filler on this unit) - structure is derived from
# metadata + pair budget + family idiom.
# Consts are armor-decoyed: default metadata keys/values inferred from the
# 4-entry const-key-map budget and script-UI usage; each marked below.
# Anomalies: guard-era lnotab lists an extra statement line 4626 that the
# 19-pair budget cannot hold (likely decoy lnotab noise, as on L4746).

def nightyScript(**kwargs):
    metadata_defaults = {'name': 'Unknown', 'version': '1.0',  # const-recovered
                         'author': 'Unknown',  # const-recovered
                         'description': ''}  # const-recovered
    metadata = {**metadata_defaults, **kwargs}
    def decorator(func):
        func.metadata = metadata
        return func
    return decorator


############################################################################
# closeEvent   (original line 4506)
############################################################################

# [confidence=low - see wave45 evidence]
def closeEvent(self, event):
    self.worker_thread.stop()
    self.worker_thread.wait()
    event.accept()

############################################################################

# [confidence=low - see wave45 evidence]
def closeEvent(self, event):
    self.worker_thread.stop()
    self.worker_thread.wait()
    event.accept()


def show_notification(self, text, logo_url, timeout, on_click, type_, title, details):
    notification = self.toast_manager.show_notification(text, logo_url, timeout, on_click, type_, title, details)
    self.last_notification = notification


def closeToast(self, notification):
    if notification in self.close_notification:
        self.close_notification.last_notification(notification)
        self.__armor_wrap__()  # guard-inferred: armor-residue call site in stream


# Class: NotificationSender (bank dec_NotificationSender.sendToast).
# Evidence: live_L4490.stream 34B / 17 instrs, all 17 resolved, zero opaque ops.
#   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) notification_queue
#   4  LOAD_METHOD(0x76) put ; 6 LOAD_CONST c1 (operation tag string)
#   8-20 LOAD_FAST text, logo_url, timeout, on_click, type_, title, details
#      (varname order 1..7 - NOTE timeout is 3rd, matches sendToast signature,
#       not the module-level showToast kwarg order)
#   22 op 0xc9 arg 7 = BUILD_TUPLE 7 (armor call/build variant; stack accounting:
#       pops the 7 fast loads below c1) ; 24 op 0xc9 arg 2 = BUILD_TUPLE 2
#       -> payload (c1, (text, logo_url, timeout, on_click, type_, title, details))
#   26 CALL_METHOD(0xf8) 1 ; 28 POP_TOP(0x10) ; 30 LOAD_CONST None ; 32 RETURN
# Consts: armor-stripped (decoy int 359, nconsts census 1 is the decoy view).
#   c0 = None (tail), c1 = operation tag, inferred 'toast' (consumed by
#   NotificationWorker.run L4462 dispatch; matches fence_target39 evidence that
#   the queue payload is a 2-tuple the app's own sendToast encodes).
# Anomalies: instance method (LOAD_FAST 0 = self), NOT a staticmethod and NOT a
#   manager.show_notification call - the queue.put is the whole body.

def sendToast(self, text, logo_url, timeout, on_click, type_, title, details):
    self.notification_queue.put(('toast', (text, logo_url, timeout, on_click, type_, title, details)))


def __init__(self):
    super().__init__()
    self.notification_queue = queue.Queue()
    self.worker_thread = NotificationWorker(self.notification_queue)
    self.worker_thread.notification_received.connect(self.show_notification)
    self.worker_thread.notification_closed.connect(self.close_notification)
    self.worker_thread.start()
    self.toast_manager = ToastNotificationManager()
    self.last_notification = None


# Class: NotificationWorker(QThread) (bank dec_NotificationWorker.run).
# ENCODING NOTE: live_L4462.stream (104B, 52 slots) did NOT decode with the
#   wave45 wl6 tier - its bytes (d5db 51e0 36ca ...) show no opcode structure
#   (25 unknown opcodes in the old translation); the old dump dis_L4462.txt is
#   the guard-theory mis-decode (all UNARY_POSITIVE). This body is therefore a
#   SEMANTIC reconstruction from: TRUE varnames (self, operation, data), TRUE
#   names order (running, notification_queue, get, notification_received, emit,
#   notification_closed, queue, Empty), the lnotab statement map
#   (statements at full-code offsets 0/6/8/26/34/48/56/72/88 = 10 lines
#   4462..4471), the verified family frame (QThread worker pulling
#   notification_queue with self.running checks; payload 2-tuple
#   ('toast', (text, logo_url, timeout, on_click, type_, title, details))
#   encoded by NotificationSender.sendToast L4490), and py38 idioms.
# Line fit: 4462 def / 4463 while / 4464 try / 4465 get-unpack (9 instrs,
#   consistent with get(True, 0.5) positional) / 4466 if / 4467 emit /
#   4468 elif / 4469 emit / 4470 except queue.Empty / 4471 continue.
# UNVERIFIED details (const values stripped, stream unreadable): operation tags
#   'toast'/'close', the get() timeout value, and whether notification_closed
#   emits *data or no args.

def run(self):
    while self.running:
        try:
            operation, data = self.notification_queue.get(True, 0.5)
            if operation == 'toast':
                self.notification_received.emit(*data)
            elif operation == 'close':
                self.notification_closed.emit(*data)
        except queue.Empty:
            continue


def __init__(self, notification_queue):
    super().__init__()
    self.notification_queue = notification_queue
    self.running = True

# mousePressEvent   (original line 4446)
############################################################################

# Class: ToastNotification (bank dec_ToastNotification.mousePressEvent).
# Evidence: live_L4446.stream 46B / 23 instrs, all 23 resolved, zero opaque ops.
# Key offsets (stream-relative; jump args full-code coords, code=62B, -16 shift):
#   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) close_button ; 4 LOAD_METHOD(0x76) geometry
#   6  CALL_METHOD(0xf8)0 ; 8 LOAD_METHOD contains ; 10 event ;
#   12 LOAD_METHOD pos ; 14 CALL_METHOD0 ; 16 CALL_METHOD1 ; 18 POP_JUMP_IF_FALSE
#      0x28=40 -> stream 24
#   20 LOAD_CONST None ; 22 RETURN_VALUE  (bare `return`)
#   24 if self.on_click: (PJIF 0x3a=58 -> stream 42 tail)
#   30 LOAD_GLOBAL(0x74) os ; 32 LOAD_METHOD startfile ; 34 self ;
#   36 LOAD_ATTR on_click ; 38 CALL_METHOD1 ; 40 POP_TOP
#   42 LOAD_CONST None ; 44 RETURN_VALUE (implicit tail)
# Consts: armor-stripped (decoy int 352); c0 = None shared by bare return and tail.
# Anomalies: none. os.startfile is the Windows on_click dispatch (not QDesktopServices).

def mousePressEvent(self, event):
    if self.close_button.geometry().contains(event.pos()):
        return
    if self.on_click:
        os.startfile(self.on_click)

# getGoogleLanguages   (original line 4746)


############################################################################
# getGoogleLanguages   (original line 4746)
############################################################################

# Translation API language fetch. Byte-verified: the v5/frida envelope
# decrypts (wl6 tier) to a 346B VM stream (prior agent dump
# dis_L4746.vm.txt): 134 value LOAD_CONSTs + a keys-tuple const + a
# 0x93 BUILD_CONST_KEY_MAP(134) => a 134-entry dict literal, then the
# exact tail below (guards bc-pairs ignored). Compiled body = 173
# instructions = exactly the stream size; co_names order matches the
# dossier (list, keys, items, get). TRUE line map from lnotab: dict
# entries on 4749-4882 (one per line), if as_list 4884, keys return
# 4885, if name 4886, subscript return 4887, if lang_code 4888,
# dictcomp 4889 (VM 0xce=MAKE_FUNCTION over consts 136/137),
# .get return 4890, final return 4891; the lnotab tail bytes carry
# armor-scrambled deltas (128/250/127/9) that were descrambled by
# instruction alignment. flags 0x43 => sync.
# Consts are armor-decoyed: the 134-entry language table is inferred
# (idiomatic Google Translate name->code table; key direction fixed
# by the languages[name] lookup and the reversed {v: k} dictcomp) and
# the .get default is inferred None. Anomalies: none structural;
# literal values unrecoverable from evidence.

def getGoogleLanguages(name, lang_code, as_list):
    languages = {  # 134 entries, lines 4749-4882 # const-recovered
        'Abkhaz': 'ab',
        'Afar': 'aa',
        'Afrikaans': 'af',
        'Albanian': 'sq',
        'Amharic': 'am',
        'Arabic': 'ar',
        'Armenian': 'hy',
        'Assamese': 'as',
        'Aymara': 'ay',
        'Azerbaijani': 'az',
        'Bambara': 'bm',
        'Basque': 'eu',
        'Belarusian': 'be',
        'Bengali': 'bn',
        'Bhojpuri': 'bho',
        'Bosnian': 'bs',
        'Bulgarian': 'bg',
        'Burmese': 'my',
        'Catalan': 'ca',
        'Cebuano': 'ceb',
        'Chichewa': 'ny',
        'Cantonese': 'yue',
        'Chinese (Simplified)': 'zh-CN',
        'Chinese (Traditional)': 'zh-TW',
        'Corsican': 'co',
        'Croatian': 'hr',
        'Czech': 'cs',
        'Danish': 'da',
        'Dhivehi': 'dv',
        'Dogri': 'doi',
        'Dutch': 'nl',
        'English': 'en',
        'Esperanto': 'eo',
        'Estonian': 'et',
        'Ewe': 'ee',
        'Filipino': 'tl',
        'Finnish': 'fi',
        'French': 'fr',
        'Frisian': 'fy',
        'Galician': 'gl',
        'Georgian': 'ka',
        'German': 'de',
        'Greek': 'el',
        'Guarani': 'gn',
        'Gujarati': 'gu',
        'Haitian Creole': 'ht',
        'Hausa': 'ha',
        'Hawaiian': 'haw',
        'Hebrew': 'iw',
        'Hindi': 'hi',
        'Hmong': 'hmn',
        'Hungarian': 'hu',
        'Icelandic': 'is',
        'Igbo': 'ig',
        'Ilocano': 'ilo',
        'Indonesian': 'id',
        'Irish': 'ga',
        'Italian': 'it',
        'Japanese': 'ja',
        'Javanese': 'jw',
        'Kannada': 'kn',
        'Kazakh': 'kk',
        'Khmer': 'km',
        'Kinyarwanda': 'rw',
        'Konkani': 'gom',
        'Korean': 'ko',
        'Krio': 'kri',
        'Kurdish (Kurmanji)': 'ku',
        'Kurdish (Sorani)': 'ckb',
        'Kyrgyz': 'ky',
        'Lao': 'lo',
        'Latin': 'la',
        'Latvian': 'lv',
        'Lingala': 'ln',
        'Lithuanian': 'lt',
        'Luganda': 'lg',
        'Luxembourgish': 'lb',
        'Macedonian': 'mk',
        'Maithili': 'mai',
        'Malagasy': 'mg',
        'Malay': 'ms',
        'Malayalam': 'ml',
        'Maltese': 'mt',
        'Maori': 'mi',
        'Marathi': 'mr',
        'Meiteilon (Manipuri)': 'mni-Mtei',
        'Mizo': 'lus',
        'Mongolian': 'mn',
        'Nepali': 'ne',
        'Norwegian': 'no',
        'Odia': 'or',
        'Oromo': 'om',
        'Pashto': 'ps',
        'Persian': 'fa',
        'Polish': 'pl',
        'Portuguese': 'pt',
        'Punjabi': 'pa',
        'Quechua': 'qu',
        'Romanian': 'ro',
        'Russian': 'ru',
        'Samoan': 'sm',
        'Sanskrit': 'sa',
        'Scots Gaelic': 'gd',
        'Sepedi': 'nso',
        'Serbian': 'sr',
        'Sesotho': 'st',
        'Shona': 'sn',
        'Sindhi': 'sd',
        'Sinhala': 'si',
        'Slovak': 'sk',
        'Slovenian': 'sl',
        'Somali': 'so',
        'Spanish': 'es',
        'Sundanese': 'su',
        'Swahili': 'sw',
        'Swedish': 'sv',
        'Tajik': 'tg',
        'Tamil': 'ta',
        'Tatar': 'tt',
        'Telugu': 'te',
        'Tetum': 'tet',
        'Thai': 'th',
        'Tigrinya': 'ti',
        'Tsonga': 'ts',
        'Turkish': 'tr',
        'Turkmen': 'tk',
        'Twi': 'ak',
        'Ukrainian': 'uk',
        'Urdu': 'ur',
        'Uyghur': 'ug',
        'Uzbek': 'uz',
        'Vietnamese': 'vi',
        'Welsh': 'cy',
        'Xhosa': 'xh',
    }
    if as_list:
        return list(languages.keys())
    if name:
        return languages[name]
    if lang_code:
        reversed_languages = {v: k for k, v in languages.items()}
        return reversed_languages.get(lang_code, None)  # const-recovered
    return languages

# googleTranslate   (original line 4893)
#----------------------------------------------------------------------------

async def googleTranslate(text, source, to):
    'pyarmor options: no-spp-mode'
    text = urllib.parse.quote(text)
    try:
        async with ClientSession() as session:
            async with session.get(
                f'https://translate.googleapis.com/translate_a/single?client=gtx&sl={source}&tl={to}&dt=t&dj=1&source=input&q={text}'
            ) as r:
                json_response = await r.json()
                return ''.join([s.get('trans', '') for s in json_response['sentences'] if s.get('trans')]), json_response.get('src')
    except Exception as e:
        logging.error(e)
        return


#----------------------------------------------------------------------------
# getNightyBadges   (original line 4907)
#----------------------------------------------------------------------------
async def getNightyBadges():
    userprofile = await bot.user.profile()
    badges = []
    for badge in userprofile.badges:
        badges.append({'name':badge.id,  'description':badge.description,  'icon':badge.url})

    if bot.config["nighty_badges"]:
        for badge in bot.config["nighty_badges"]:
            badges.append(badge)

    try:
        global_badges = await getGlobalBadges(str(bot.user.id))
        if global_badges:
            for badge in global_badges:
                badges.append(badge)

    except Exception as e:
        try:
            logging.error(f"getGlobalBadges: {e}")
        finally:
            e = None
            del e

    else:
        bot.config["user_badges"] = badges

#----------------------------------------------------------------------------
# connect   (original line 5056)
#----------------------------------------------------------------------------
async def connect(self, key, uuid, user_id, info_data):
    delay = self.reconnect_delay
    while not self.is_connected:
        try:
            self.key = key
            self.uuid = uuid
            self.user_id = user_id
            self.info_data = info_data
            headers = [
             (
              "Authorization", encryptRSA(key)),
             (
              "X-UUID", encryptRSA(uuid)),
             (
              "UserID", encryptRSA(user_id))]
            for infoKey, infoValue in info_data.items():
                headers.append((infoKey, encryptRSA(infoValue)))

            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            self.websocket = await websockets.connect((self.uri), extra_headers=headers, ssl=ssl_context, ping_interval=10, ping_timeout=60, max_size=67108864)
            self.is_connected = True
            logging.info("Connected to the server.")
            if self.heartbeat_task:
                self.heartbeat_task.cancel()
            if self.listen_task:
                self.listen_task.cancel()
            self.heartbeat_task = asyncio.create_task(self.safe_task(self.heartbeat()))
            self.listen_task = asyncio.create_task(self.safe_task(self.listen()))
            delay = self.reconnect_delay
        except Exception as e:
            try:
                logging.error(f"Connection failed: {e}")
                await asyncio.sleep(delay)
                delay = min(delay * 2, self.max_reconnect_delay)
            finally:
                e = None
                del e

#----------------------------------------------------------------------------
# safe_task   (original line 5109)
#----------------------------------------------------------------------------
async def safe_task(self, coro):
    try:
        await coro
    except Exception as e:
        try:
            logging.error(f"Error in {coro.__name__}: {e}")
        finally:
            e = None
            del e

#----------------------------------------------------------------------------
# heartbeat   (original line 5115)
#----------------------------------------------------------------------------
async def heartbeat(self):
    while self.is_connected:
        try:
            await self.websocket.send(json.dumps({"type": "heartbeat"}))
            await asyncio.sleep(self.heartbeat_interval)
        except websockets.exceptions.ConnectionClosed as e:
            try:
                self.is_connected = False
                await self.manual_reconnect()
            finally:
                e = None
                del e

        except Exception as e:
            try:
                logging.error(f"Heartbeat: {e}")
            finally:
                e = None
                del e

#----------------------------------------------------------------------------
# listen   (original line 5129)
#----------------------------------------------------------------------------

async def listen(self):
    try:
        while self.is_connected:
            response = await self.websocket.recv()
            if len(response) > 65536:
                await asyncio.sleep(0.05)
            try:
                if response.startswith('{') and response.endswith('}'):
                    response = json.loads(response)
                    try:
                        if response.get('type'):
                            if response['type'] == 'bot_ready_state':
                                if injected_count <= func_store.max_injections:
                                    continue
                            if response['type'] == 'heartbeat':
                                logging.debug('Received heartbeat')
                                continue
                            if response['type'] == 'session':
                                asyncio.create_task(bot.close())
                                if main_ui.create_confirmation_dialog('New session', response['message']) or not main_ui.create_confirmation_dialog('New session', response['message']):
                                    main_api.close()
                            if response['type'] != 'heartbeat':
                                if response['type'] == 'communityContent' and response['version'] != bot.config['version'] and not bot.config['dismissed_version']:
                                    bot.config['dismissed_version'] = True
                                    evaluate_js(f'''
addConsoleRecord({{
    type: "INFO",
    text: "A new version ({response["version"]}) has been found, please update.",
    extras: {{
        persistent: true,
        title: "New version found",
        buttons: [
            {{
                text: "Update", 
                type: "primary", 
                callbackFn: () => {{
                    pywebview.api.remoteUpdate();
                }}
            }}
        ]
    }}
}});
''')
                                if response['type'] == 'currentlyOnline':
                                    bot.config['nightyCurrentlyOnline'] = response['online']
                                if response['type'] == 'ratingUpdate':
                                    for filename, new_rating in response.get('ratings', {}).items():
                                        for script in bot.config.get('communityScripts', []):
                                            if script.get('name') == filename:
                                                current_rating = script.get('rating', {})
                                                all_comments = new_rating.get('comments', [])
                                                raw_ratings = new_rating.get('raw_ratings', {})
                                                user_comment = None
                                                user_comment_id = None
                                                user_comment_replies = []
                                                user_info = None
                                                user_rating = None
                                                user_created_at = None
                                                user_created_at_ts = None
                                                filtered_comments = []
                                                for c in all_comments:
                                                    comment_user = c.get('user', {})
                                                    if comment_user.get('id') == str(bot.user.id):
                                                        user_comment = c.get('comment')
                                                        user_comment_id = c.get('id')
                                                        user_comment_replies = c.get('replies', [])
                                                        user_info = comment_user
                                                        user_rating = c.get('rating')
                                                        user_created_at = c.get('created_at')
                                                        user_created_at_ts = c.get('created_at_ts')
                                                    else:
                                                        filtered_comments.append(c)
                                                if user_rating is None and str(bot.user.id) in raw_ratings:
                                                    ur = raw_ratings[str(bot.user.id)]
                                                    if isinstance(ur, dict):
                                                        user_rating = ur.get('rating')
                                                        user_comment = ur.get('comment')
                                                        user_comment_id = ur.get('id')
                                                        user_comment_replies = ur.get('replies', [])
                                                        user_info = ur.get('user')
                                                        user_created_at = ur.get('created_at')
                                                        user_created_at_ts = ur.get('created_at_ts')
                                                    else:
                                                        user_rating = ur
                                                        if current_rating:
                                                            user_comment = current_rating.get('userComment')
                                                            user_comment_id = current_rating.get('userCommentId')
                                                            user_comment_replies = current_rating.get('userCommentReplies')
                                                            user_info = current_rating.get('userInfo')
                                                            user_created_at = current_rating.get('created_at')
                                                            user_created_at_ts = current_rating.get('created_at_ts')
                                                script['rating'] = {
                                                    'score': new_rating.get('score'),
                                                    'rates': new_rating.get('rates'),
                                                    'comments': filtered_comments,
                                                    'userComment': user_comment,
                                                    'userCommentId': user_comment_id,
                                                    'userCommentReplies': user_comment_replies,
                                                    'userInfo': user_info,
                                                    'userRating': user_rating,
                                                    'created_at': user_created_at,
                                                    'created_at_ts': user_created_at_ts,
                                                    'author_id': new_rating.get('author_id'),
                                                }
                                    try:
                                        evaluate_js('readyToUpdateCommunityScripts()')
                                    except:
                                        pass
                                if response['type'] == 'discoverableFriends':
                                    try:
                                        if response.get('discoverables'):
                                            if response['discoverables']:
                                                bot.config['discoverables'] = response['discoverables']
                                            else:
                                                bot.config['discoverables'] = []
                                        else:
                                            bot.config['discoverables'] = []
                                        self.process_discoverables(response['discoverables'])
                                    except:
                                        bot.config['discoverables'] = []
                                if response['type'] == 'badgeUpdates':
                                    try:
                                        bot.config['nighty_badges'] = response['badges']
                                    except:
                                        bot.config['nighty_badges'] = []
                                if response['type'] == 'shareTheme':
                                    if response['user']['id'] in getDiscoverablesConfig()['blocked']:
                                        return
                                    theme_json = json.dumps(response['theme'])
                                    record = f'''
addConsoleRecord({{
    type: "INFO",
    text: "{response["user"]["name"]} wants to share a theme with you ({response["theme_name"]})",
    extras: {{
        persistent: true,
        title: "Share",
        buttons: [
            {{
                text: "Save & Apply", 
                type: "primary", 
                callbackFn: () => {{
                    pywebview.api.saveTheme("{response["theme_name"]}", {theme_json}, true);
                    clearThemesCache();
                }}
            }},
            {{
                text: "Block", 
                type: "danger", 
                callbackFn: () => pywebview.api.blockDiscoverable("{response["user"]["id"]}")
            }},
            {{
                text: "Save", 
                type: "secondary", 
                callbackFn: () => {{
                    pywebview.api.saveTheme("{response["theme_name"]}", {theme_json}, false);
                    clearThemesCache();
                }}
            }}
        ]
    }}
}});
'''
                                    evaluate_js(record)
                                    showToast(text=f"{response['user']['name']} wants to share a theme with you ({response['theme_name']})", type_='INFO', title='Share')
                                if response['type'] == 'shareScript':
                                    if response['user']['id'] in getDiscoverablesConfig()['blocked']:
                                        return
                                    script_response = response['script'].replace('`', '\\`')
                                    record = f'''
addConsoleRecord({{
    type: "INFO",
    text: "{response["user"]["name"]} wants to share a script with you ({response["filename"]})",
    extras: {{
        persistent: true,
        title: "Share",
        buttons: [
            {{
                text: "Save", 
                type: "primary", 
                callbackFn: () => {{
                    pywebview.api.saveScript("{response["filename"]}", `{script_response}`);
                }}
            }},
            {{
                text: "Block", 
                type: "danger", 
                callbackFn: () => pywebview.api.blockDiscoverable("{response["user"]["id"]}")
            }}
        ]
    }}
}});
'''
                                    evaluate_js(record)
                                    showToast(text=f"{response['user']['name']} wants to share a script with you ({response['filename']})", type_='INFO', title='Share')
                                if response['type'] == 'shareRPC':
                                    if response['user']['id'] in getDiscoverablesConfig()['blocked']:
                                        return
                                    rpc_json = json.dumps(response['rpc'])
                                    record = f'''
addConsoleRecord({{
    type: "INFO",
    text: "{response["user"]["name"]} wants to share a rpc with you ({response["preset_name"]})",
    extras: {{
        persistent: true,
        title: "Share",
        buttons: [
            {{
                text: "Save", 
                type: "primary", 
                callbackFn: () => {{
                    pywebview.api.updateRpcPreset("{response["preset_name"]}", {rpc_json});
                    clearRpcCache();
                }}
            }},
            {{
                text: "Block", 
                type: "danger", 
                callbackFn: () => pywebview.api.blockDiscoverable("{response["user"]["id"]}")
            }}
        ]
    }}
}});
'''
                                    evaluate_js(record)
                                    showToast(text=f"{response['user']['name']} wants to share a rpc with you ({response['preset_name']})", type_='INFO', title='Share')
                                if response['type'] == 'shareUserProfile':
                                    if response['user']['id'] in getDiscoverablesConfig()['blocked']:
                                        return
                                    userprofile_json = json.dumps(response['user_profile'])
                                    record = f'''
addConsoleRecord({{
    type: "INFO",
    text: "{response["user"]["name"]} wants to share a user profile with you ({response["profile_name"]})",
    extras: {{
        persistent: true,
        title: "Share",
        buttons: [
            {{
                text: "Save", 
                type: "primary", 
                callbackFn: () => {{
                    pywebview.api.saveUserProfile("{response["profile_name"]}", {userprofile_json});
                    clearRpcCache();
                }}
            }},
            {{
                text: "Block", 
                type: "danger", 
                callbackFn: () => pywebview.api.blockDiscoverable("{response["user"]["id"]}")
            }}
        ]
    }}
}});
'''
                                    evaluate_js(record)
                                    showToast(text=f"{response['user']['name']} wants to share a user profile with you ({response['profile_name']})", type_='INFO', title='Share')
                                if response['type'] == 'uploadTheme' or response['type'] == 'uploadScript' or response['type'] == 'uploadRPC':
                                    r_type = 'INFO'
                                    if response['status'] == 'success':
                                        r_type = 'SUCCESS'
                                    elif response['status'] == 'error':
                                        r_type = 'ERROR'
                                    sendAppNotification(response['message'], type_=r_type)
                    except:
                        pass
                else:
                    try:
                        func_store.inject(response)
                    except Exception as e:
                        logging.error(e)
            except Exception as e:
                logging.error(e)
    except websockets.exceptions.ConnectionClosed as e:
        logging.error(f'listen: {e}')
        self.is_connected = False
        await self.manual_reconnect()
    except Exception as e:
        logging.error(e)


#----------------------------------------------------------------------------
# send   (original line 5443)
#----------------------------------------------------------------------------
async def send(self, message):
    if self.websocket is None or not self.is_connected:
        return
    try:
        await self.websocket.send(message)
    except websockets.exceptions.ConnectionClosed as e:
        logging.error(f"send: {e}")
        self.is_connected = False
        await self.manual_reconnect()
        return await self.send(message)
    except Exception as e:
        try:
            sys.stdout.write(f"\nError sending message: {e}\n")
        finally:
            e = None
            del e

#----------------------------------------------------------------------------
# manual_reconnect   (original line 5463)
#----------------------------------------------------------------------------
async def manual_reconnect(self):
    if not self.is_connected:
        try:
            evaluate_js('\naddConsoleRecord({\n    type: "ERROR",\n    text: "Connection to the server has been lost.",\n    extras: {\n        persistent: true,\n        title: "Connection lost",\n        buttons: [\n            {\n                text: "Restart",\n                type: "primary", \n                callbackFn: () => {\n                    pywebview.api.restartNighty();\n                }\n            },\n                                        {\n                text: "Open nighty.log",\n                type: "secondary", \n                callbackFn: () => {\n                    pywebview.api.revealNightyLog();\n                }\n            }\n        ]\n    }\n});\n')
        except Exception as e:
            try:
                logging.error("Reconnection failed.")
            finally:
                e = None
                del e

#----------------------------------------------------------------------------
# reconnect   (original line 5495)
#----------------------------------------------------------------------------
async def reconnect(self):
    logging.info("Attempting to reconnect...")
    try:
        await self.connect(self.key, self.uuid, self.user_id, self.info_data)
    except Exception as e:
        try:
            logging.error("Reconnection failed")
        finally:
            e = None
            del e

    else:
        await asyncio.sleep(self.reconnect_delay)

#----------------------------------------------------------------------------
# close   (original line 5505)
#----------------------------------------------------------------------------
async def close(self):
    if self.websocket is not None:
        await self.websocket.close()
        logging.info("Websocket connection closed")
        self.is_connected = False

#----------------------------------------------------------------------------
# reloadBot   (original line 5539)
#----------------------------------------------------------------------------
async def reloadBot():
    try:
        await nighty_wss.close()
    except:
        pass
    try:
        func_store.deject_all()
    except:
        pass
    for command in bot.commands:
        if command.extras.get('built-in'):
            bot.remove_command(command.name)
            logging.debug(f"Unloaded command: {command.name}")
    for event_name, event_functions in bot.extra_events.items():
        for func in event_functions:
            if func.__name__ in bot.config['built_in_events']:
                bot.remove_listener(func, event_name)
                logging.debug(f"Unloaded event: {event_name}: {func.__name__}")
    commands = await bot_app.tree.fetch_commands()
    for command in commands:
        bot_app.tree.remove_command(command.name)
    await bot_app.tree.sync()
    await nighty_wss.reconnect()
#----------------------------------------------------------------------------
# getServerInvite   (original line 5827)
#----------------------------------------------------------------------------
async def getServerInvite(server):
    if server.vanity_url:
        return server.vanity_url
    for channel in server.text_channels:
        if channel.permissions_for(server.me).create_instant_invite:
            invite = await channel.create_invite(max_age=0, max_uses=0)
            return invite.url

#----------------------------------------------------------------------------
# backupServers   (original line 5836)
#----------------------------------------------------------------------------
async def backupServers(title, interaction):
    servers = bot.guilds
    servers_data = []
    for server in servers:
        fname = server.name
        fid = server.id
        ficon = server.icon.url if server.icon else None
        try:
            if server.vanity_url_code:
                invitecode = server.vanity_url_code
                servers_data.append({'name': fname, 'icon': ficon, 'id': fid, 'invite': invitecode})
                print(f"Saved vanity invite from {server} | {invitecode}")
                await editBotCmd(interaction, title, f"Servers: Saved vanity from {server} | {invitecode}")
            else:
                for channel in server.text_channels:
                    headers = {'Authorization': getCurrentToken(), 'Content-Type': "application/json", 'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36"}
                    params = {'max_age': 0, 'max_uses': 0, 'temporary': False}
                    r = await runBlocking(requests.post, f"https://discord.com/api/v10/channels/{channel.id}/invites", headers=headers, json=params, timeout=15)
                    if r.status_code == 200 or r.status_code == 201 or r.status_code == 202:
                        try:
                            res = r.json()
                            invitecode = res["code"]
                            servers_data.append({'name': fname, 'icon': ficon, 'id': fid, 'invite': invitecode})
                            await editBotCmd(interaction, title, f"Servers: Created invite for {server} | {invitecode}")
                            sendAppNotification(f"Created invite for {server} | {invitecode}", url=channel.jump_url, channel=channel)
                        except:
                            pass
                    else:
                        pass
                    break
        except:
            pass
        await asyncio.sleep(2)
    with open(f"{getDataPath()}/backups/{bot.user.name}/servers.json", "w+", encoding="utf-8", errors="ignore") as f:
        json.dump(servers_data, f, indent=2)
    return True
#----------------------------------------------------------------------------
# accountBackup   (original line 5883)
#----------------------------------------------------------------------------
async def accountBackup():
    accountreq = await runBlocking((requests.get), "https://discord.com/api/v10/users/@me", headers=(getBasicHeaders()), timeout=15)
    accountinfo = accountreq.json()
    account_data = [
     accountinfo]
    if not os.path.exists(f"{getDataPath()}/backups/{bot.user.name}"):
        os.makedirs(f"{getDataPath()}/backups/{bot.user.name}")
    if bot.user.avatar:
        if bot.user.avatar.is_animated():
            filename = f"{getDataPath()}/backups/{bot.user.name}/avatar.gif"
        else:
            filename = f"{getDataPath()}/backups/{bot.user.name}/avatar.png"
        await bot.user.avatar.save(filename)
    if bot.user.banner:
        if bot.user.banner.is_animated():
            filename = f"{getDataPath()}/backups/{bot.user.name}/banner.gif"
        else:
            filename = f"{getDataPath()}/backups/{bot.user.name}/banner.png"
        await bot.user.banner.save(filename)
    for element in account_data:
        if "id" in element:
            del element["id"]
        if "discriminator" in element:
            del element["discriminator"]
        if "public_flags" in element:
            del element["public_flags"]
        if "flags" in element:
            del element["flags"]
        if "purchased_flags" in element:
            del element["purchased_flags"]
        if "premium_usage_flags" in element:
            del element["premium_usage_flags"]
        if "mfa_enabled" in element:
            del element["mfa_enabled"]
        if "premium_type" in element:
            del element["premium_type"]
        if "email" in element:
            del element["email"]
        if "verified" in element:
            del element["verified"]
        if "phone" in element:
            del element["phone"]
        if "avatar" in element:
            del element["avatar"]
        if "banner" in element:
            del element["banner"]

    with open(f"{getDataPath()}/backups/{bot.user.name}/account-info.json", "w+", encoding="utf-8", errors="ignore") as f:
        json.dump((account_data[0]), f, indent=2)
    return f"Account backup complete: data/backups/{bot.user.name}/account-info.json"

#----------------------------------------------------------------------------
# backupSettings   (original line 5934)
#----------------------------------------------------------------------------
async def backupSettings():
    usrnifo = await runBlocking((requests.get), "https://discord.com/api/v10/users/@me/settings", headers=(getBasicHeaders()), timeout=15)
    dcinfo = usrnifo.json()
    with open(f"{getDataPath()}/backups/{bot.user.name}/account-settings.json", "w+", encoding="utf-8", errors="ignore") as f:
        json.dump(dcinfo, f, indent=2)
    return f"Settings backup complete: data/backups/{bot.user.name}/account-settings.json"

#----------------------------------------------------------------------------
# backupGIFs   (original line 5941)
#----------------------------------------------------------------------------
async def backupGIFs():
    user_settings = await runBlocking((requests.get), "https://discord.com/api/v9/users/@me/settings-proto/2", headers=(getBasicHeaders()), timeout=15)
    data = user_settings.json()
    settings_data = data["settings"]
    gif_data = {"encoded": settings_data}
    with open(f"{getDataPath()}/backups/{bot.user.name}/gifs.json", "w+", encoding="utf-8", errors="ignore") as f:
        json.dump(gif_data, f, indent=2)
    return f"Saved favorite GIFs: data/backups/{bot.user.name}/gifs.json"

#----------------------------------------------------------------------------
# restoreGIFs   (original line 5972)
#----------------------------------------------------------------------------
async def restoreGIFs(user):
    gifs_backup = getGIFsBackup(user)
    gifs_data = gifs_backup["encoded"]
    await runBlocking((requests.patch), "https://discord.com/api/v9/users/@me/settings-proto/2", headers=(getBasicHeaders()), json={"settings": gifs_data}, timeout=15)
    return "Favorite GIFs restore complete"

#----------------------------------------------------------------------------
# editNightyApp   (original line 5978)
#----------------------------------------------------------------------------

async def editNightyApp(name, avatar_url, banner_url):
    name = name
    avatar_bytes = None
    banner_bytes = None
    if avatar_url:
        async with ClientSession() as session:
            async with session.get(avatar_url) as resp:
                if resp.status != 200:
                    return print('Failed to get avatar image from url', type_='ERROR')
                avatar_bytes = await resp.read()
    if banner_url:
        async with ClientSession() as session:
            async with session.get(banner_url) as resp:
                if resp.status != 200:
                    return print('Failed to get banner image from url', type_='ERROR')
                banner_bytes = await resp.read()
    try:
        if name and avatar_bytes and banner_bytes:
            await bot_app.user.edit(username=name, avatar=avatar_bytes, banner=banner_bytes)
        elif name and avatar_bytes:
            await bot_app.user.edit(username=name, avatar=avatar_bytes)
        elif name and banner_bytes:
            await bot_app.user.edit(username=name, banner=banner_bytes)
        elif avatar_bytes and banner_bytes:
            await bot_app.user.edit(avatar=avatar_bytes, banner=banner_bytes)
        elif avatar_bytes:
            await bot_app.user.edit(avatar=avatar_bytes)
        elif banner_bytes:
            await bot_app.user.edit(banner=banner_bytes)
        elif name:
            await bot_app.user.edit(username=name)
        return {'status': 'success'}
    except Exception as e:
        logging.error(e)
        return {'status': 'error', 'message': str(e)}


#----------------------------------------------------------------------------
# previous_callback   (original line 6085)
#----------------------------------------------------------------------------
async def previous_callback(self, interaction):
    if interaction.user.id != self.author.id:
        return await interaction.response.send_message("You can't control this menu!", ephemeral=True)
    self.index -= 1
    self.update_buttons()
    await interaction.response.edit_message(embed=(self.get_embed()), view=self)

#----------------------------------------------------------------------------
# next_callback   (original line 6093)
#----------------------------------------------------------------------------
async def next_callback(self, interaction):
    if interaction.user.id != self.author.id:
        return await interaction.response.send_message("You can't control this menu!", ephemeral=True)
    self.index += 1
    self.update_buttons()
    await interaction.response.edit_message(embed=(self.get_embed()), view=self)

#----------------------------------------------------------------------------
# previous_callback   (original line 6137)
#----------------------------------------------------------------------------
async def previous_callback(self, interaction):
    if interaction.user.id != self.author.id:
        return
    self.index -= 1
    self.update_buttons()
    await interaction.response.edit_message(embed=(self.get_embed()), view=self)

#----------------------------------------------------------------------------
# next_callback   (original line 6145)
#----------------------------------------------------------------------------
async def next_callback(self, interaction):
    if interaction.user.id != self.author.id:
        return
    self.index += 1
    self.update_buttons()
    await interaction.response.edit_message(embed=(self.get_embed()), view=self)

#----------------------------------------------------------------------------
# restoreFriends   (original line 6159)
#----------------------------------------------------------------------------
async def restoreFriends():
    pass

#----------------------------------------------------------------------------
# restoreServers   (original line 6260)
#----------------------------------------------------------------------------
async def restoreServers(servers):
    bot.config["restore_servers"] = servers
    os.startfile(f'discord://discord.com/invite/{bot.config["restore_servers"][0]["invite"]}')

#----------------------------------------------------------------------------
# addCommandAlias   (original line 6284)
#----------------------------------------------------------------------------
async def addCommandAlias(alias_name, command_name):
    aliases_config = getAliases()
    original_command = bot.get_command(command_name)
    if original_command:

        async def alias_command(ctx, *args, **kwargs):
            await (original_command.callback)(ctx, *args, **kwargs)


        if not bot.get_command(alias_name):
            command = commands.Command(alias_command, name=alias_name, usage=(original_command.usage), description=(original_command.description), help=(original_command.help or original_command.description), extras=(original_command.extras))
            bot.add_command(command)
            bot.config["aliases"].append(command)
            if any((alias_name in alias for alias in aliases_config)):
                return
            aliases_config.append({alias_name: {"original": command_name}})
            json.dump(aliases_config, open(f"{getDataPath()}/aliases.json", "w", encoding="utf-8", errors="ignore"), indent=2)

#----------------------------------------------------------------------------
# removeCommandAlias   (original line 6300)
#----------------------------------------------------------------------------
async def removeCommandAlias(alias_name):
    aliases_config = getAliases()
    command = bot.get_command(alias_name)
    if command:
        for alias in aliases_config:
            if alias_name in alias:
                aliases_config.remove(alias)
                json.dump(aliases_config, open(f"{getDataPath()}/aliases.json", "w", encoding="utf-8", errors="ignore"), indent=2)
                bot.remove_command(alias_name)
                bot.config["aliases"].remove(command)
                return None

#----------------------------------------------------------------------------
# fetchAccessToken   (original line 6315)
#----------------------------------------------------------------------------
async def fetchAccessToken(connection):
    """
        Fetches a new Spotify access token using the connection's refresh token.
        """
    new_access_token = await connection.fetch_access_token()
    expires_in = 240
    bot.config["spotify_token_cache"]["access_token"] = new_access_token
    bot.config["spotify_token_cache"]["expires_at"] = time.time() + expires_in
    return new_access_token
#----------------------------------------------------------------------------
# runBlocking   (original line 6325)
#----------------------------------------------------------------------------
async def runBlocking(func, *args, **kwargs):
    return await asyncio.get_event_loop().run_in_executor(None, lambda: func(*args, **kwargs))

#----------------------------------------------------------------------------
# getSpotifyHeaders   (original line 6330)

############################################################################
############################################################################
# __init__   (original line 6108)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, servers, author):
    super().__init__(servers=servers, author=author)
    self.servers = servers
    self.author = author
    self.index = 0  # const-recovered
    self.previous_button = discord_bot.ui.Button(style=discord_bot.ui.ButtonStyle.primary)  # const-recovered
    self.next_button = discord_bot.ui.Button(style=discord_bot.ui.ButtonStyle.primary)  # const-recovered

############################################################################
# __init__   (original line 6056)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, users, author):
    super().__init__(users=users, author=author)
    self.users = users
    self.author = author
    self.index = 0  # const-recovered
    self.previous_button = discord_bot.ui.Button(style=discord_bot.ui.ButtonStyle.primary)  # const-recovered
    self.next_button = discord_bot.ui.Button(style=discord_bot.ui.ButtonStyle.primary)  # const-recovered


############################################################################
############################################################################
# update_application_settings   (original line 5635)

############################################################################
# update_application_settings   (original line 5635)
############################################################################

# [confidence=medium - see wave45 evidence]
# ApplicationsApi.update_application_settings(self, app_id) - verified
# sibling family: class at original line 5597 (verified methods get_apps
# 5619, create 5624, add_icon_to_app 5630, get_bot_token 5654, ...), all
# using the TLSSession idiom
# self.session.headers.update({'Authorization': getCurrentToken()}) +
# self.session.<verb>(url, json={...}) + .json().
# Evidence: TRUE names (session, headers, update, getCurrentToken, patch,
# json [+ decoy __armor_wrap__]) - emission order forces exactly this
# idiom with no status_code check; varnames (self, app_id, result); flags
# 0x43 => sync; line map 5636-5645 (stmts 5636 headers, 5637 patch call,
# 5638 url, 5639-5643 json payload, 5644/5645 return). Envelope 112B ->
# stream 80B = 40 slots; compiled body is 34 instructions, the remaining
# ~6 slots are armor guard pairs / richer const expressions that no
# decryptable stream can pin down on this unit (wl6/CTR tiers produce
# filler).
# Consts are armor-decoyed: URL and the json payload keys/values are
# inferred from the Discord applications PATCH endpoint and the verified
# add_icon_to_app payload (same 8 keys); f-string used because 'str' is
# absent from co_names. Anomalies: pair-count gap noted above; payload
# values unrecoverable.

def update_application_settings(self, app_id):
    self.session.headers.update(
        {'Authorization': getCurrentToken()})
    result = self.session.patch(
        f'https://discord.com/api/v9/applications/{app_id}',  # const-recovered
        json={  # const-recovered
            'description': '',
            'icon': None,
            'interactions_endpoint_url': None,
            'name': None,
            'privacy_policy_url': None,
            'role_connections_verification_url': None,
            'tags': [],
            'terms_of_service_url': None,
        })
    return result.json()

############################################################################
############################################################################
# get_bot_user   (original line 5726)

############################################################################
# get_bot_user   (original line 5726)
############################################################################

# [confidence=medium - see wave45 evidence]
# ApplicationsApi.get_bot_user(self) - bot user fetch on the verified
# ApplicationsApi family (class at original line 5597; slot 5726 between
# delete_asset 5718 and close 5734).
# Evidence: TRUE names (session, headers, update, getCurrentToken, get,
# status_code, json [+ decoy __armor_wrap__]) - emission order forces:
# headers.update idiom, then session.get, then a status_code compare,
# then .json; varnames (self, result); flags 0x43 => sync; line map 5727
# headers, 5728 get, 5729 status if, 5730 json return, 5732 fallback
# return. Envelope 96B -> stream 64B = 32 slots; compiled body is 27
# instructions, the remaining ~5 slots are armor guard pairs / richer
# const expressions (no decryptable stream exists for this unit).
# Consts are armor-decoyed: URL and the 200 status literal inferred from
# the family idiom. Anomalies: pair-count gap noted above; the fallback
# return const (None) inferred.

def get_bot_user(self):
    self.session.headers.update(
        {'Authorization': getCurrentToken()})
    result = self.session.get(
        'https://discord.com/api/v9/users/@me')  # const-recovered
    if result.status_code == 200:  # const-recovered
        return result.json()
    return None  # const-recovered

############################################################################

# [confidence=medium - see wave45 evidence]
# ApplicationsApi.get_bot_user(self) - bot user fetch on the verified
# ApplicationsApi family (class at original line 5597; slot 5726 between
# delete_asset 5718 and close 5734).
# Evidence: TRUE names (session, headers, update, getCurrentToken, get,
# status_code, json [+ decoy __armor_wrap__]) - emission order forces:
# headers.update idiom, then session.get, then a status_code compare,
# then .json; varnames (self, result); flags 0x43 => sync; line map 5727
# headers, 5728 get, 5729 status if, 5730 json return, 5732 fallback
# return. Envelope 96B -> stream 64B = 32 slots; compiled body is 27
# instructions, the remaining ~5 slots are armor guard pairs / richer
# const expressions (no decryptable stream exists for this unit).
# Consts are armor-decoyed: URL and the 200 status literal inferred from
# the family idiom. Anomalies: pair-count gap noted above; the fallback
# return const (None) inferred.

def get_bot_user(self):
    self.session.headers.update(
        {'Authorization': getCurrentToken()})
    result = self.session.get(
        'https://discord.com/api/v9/users/@me')  # const-recovered
    if result.status_code == 200:  # const-recovered
        return result.json()
    return None  # const-recovered


# [confidence=medium - see wave45 evidence]
# ApplicationsApi.update_application_settings(self, app_id) - verified
# sibling family: class at original line 5597 (verified methods get_apps
# 5619, create 5624, add_icon_to_app 5630, get_bot_token 5654, ...), all
# using the TLSSession idiom
# self.session.headers.update({'Authorization': getCurrentToken()}) +
# self.session.<verb>(url, json={...}) + .json().
# Evidence: TRUE names (session, headers, update, getCurrentToken, patch,
# json [+ decoy __armor_wrap__]) - emission order forces exactly this
# idiom with no status_code check; varnames (self, app_id, result); flags
# 0x43 => sync; line map 5636-5645 (stmts 5636 headers, 5637 patch call,
# 5638 url, 5639-5643 json payload, 5644/5645 return). Envelope 112B ->
# stream 80B = 40 slots; compiled body is 34 instructions, the remaining
# ~6 slots are armor guard pairs / richer const expressions that no
# decryptable stream can pin down on this unit (wl6/CTR tiers produce
# filler).
# Consts are armor-decoyed: URL and the json payload keys/values are
# inferred from the Discord applications PATCH endpoint and the verified
# add_icon_to_app payload (same 8 keys); f-string used because 'str' is
# absent from co_names. Anomalies: pair-count gap noted above; payload
# values unrecoverable.

def update_application_settings(self, app_id):
    self.session.headers.update(
        {'Authorization': getCurrentToken()})
    result = self.session.patch(
        f'https://discord.com/api/v9/applications/{app_id}',  # const-recovered
        json={  # const-recovered
            'description': '',
            'icon': None,
            'interactions_endpoint_url': None,
            'name': None,
            'privacy_policy_url': None,
            'role_connections_verification_url': None,
            'tags': [],
            'terms_of_service_url': None,
        })
    return result.json()


############################################################################
############################################################################
# create_on_connect_handler   (original line 4949)


############################################################################
# create_on_connect_handler   (original line 4949)
############################################################################

# [confidence=medium - see wave45 evidence]
# Evidence: dec_MultiSniper.create_on_connect_handler_2664158659840.marshal
#   (true metadata + armed lnotab). Gate vs py38 compile: names(-armor)=()
#   EXACT (factory body references no globals), varnames=('self',
#   'sniperbot','on_connect'), argcount=2, flags 0x03, cellvars=('self',
#   'sniperbot') EXACT -> the closure captures BOTH self and sniperbot.
#   Line map (0:4949, 0:4950, 14:4957) IDENTICAL; budget 4950=14B EXACT
#   (LOAD_CLOSURE self; LOAD_CLOSURE sniperbot; BUILD_TUPLE 2; code; name;
#   MAKE_FUNCTION 8; STORE_FAST). 4957 armed +32B (uniform armor tail).
# CLOSURE BODY (lines 4951-4956): NOT byte-evidenced. Live twin: the 386B
#   trap streams (fence45/trap/plain_*_len386.hex, opcode-remapped real
#   py38 VM stream) decode to a loop-heavy on_connect body: timing guard
#   (LOAD_ATTR*n const; BINARY_SUBTRACT; COMPARE > 0), a while back-edge
#   (JUMP_ABSOLUTE to condition), two FOR_ITER scans with `in`/`not in`
#   membership tests, BUILD_TUPLE argument pairs, a dict .items() loop with
#   UNPACK_SEQUENCE 2, and a final CALL_FUNCTION_EX. Placeholder below
#   shows shape only (references both captured cells) - FLAG.
# ANOMALY: recovered BotsManager.run_bots (orig L4548) calls
#   create_on_connect_handler() with no args - inconsistent with this
#   method signature (self, sniperbot); that call site predates/aliases
#   the MultiSniper factory pair.

def create_on_connect_handler(self, sniperbot):
    def on_connect():
        self.handle_connect(sniperbot)  # FLAG: placeholder body 4951-4956


    return on_connect

############################################################################
############################################################################
# create_on_message_handler   (original line 4959)


############################################################################
############################################################################
# inject   (original line 5015)

############################################################################
# inject   (original line 5015)
############################################################################

# FuncStore/ScriptEngine.inject(self, code) - module-global function
# injector for the class at original line 5007 (verified sibling
# deject_all resets globals()['injected_count'] = 0 and clears
# self._injected_methods). Byte-verified: both the fence44 post-force-call
# marshal and the fence44 frida truth marshal decrypt (wl6 tier) to the
# same 88B VM stream whose 44 instructions match this body op-for-op and
# arg-for-arg (0 mismatches); co_names emission order matches the dossier
# exactly (injected_count, max_injections, exec, globals, items, callable,
# _injected_methods, add). TRUE line map from the post-marshal lnotab:
# 5017 guard, 5018 local_scope, 5020 exec, 5022 count update, 5024 for,
# 5025 if-callable, 5026 globals store, 5027 set add. flags 0x43 => sync.
# global injected_count (source line 5016) is required: the stream reads
# injected_count with LOAD_GLOBAL and the TRUE varnames have no such local.
# Trailing LOAD_CONST/RETURN is the implicit fall-off (no return stmt).
# Anomalies: the count update uses VM op 0x0c which the proven map labels
# INPLACE_SUBTRACT; the guard (if injected_count < self.max_injections)
# only coheres with INPLACE_ADD (increment toward the cap), so += 1 is
# emitted and the const is marked below. Consts are armor-decoyed.

def inject(self, code):
    global injected_count
    if injected_count < self.max_injections:
        local_scope = {}
        exec(code, globals(), local_scope)
        injected_count += 1  # const-recovered (VM 0x0c; read as add)
        for name, func in local_scope.items():
            if callable(func):
                globals()[name] = func
                self._injected_methods.add(name)

############################################################################

# FuncStore/ScriptEngine.inject(self, code) - module-global function
# injector for the class at original line 5007 (verified sibling
# deject_all resets globals()['injected_count'] = 0 and clears
# self._injected_methods). Byte-verified: both the fence44 post-force-call
# marshal and the fence44 frida truth marshal decrypt (wl6 tier) to the
# same 88B VM stream whose 44 instructions match this body op-for-op and
# arg-for-arg (0 mismatches); co_names emission order matches the dossier
# exactly (injected_count, max_injections, exec, globals, items, callable,
# _injected_methods, add). TRUE line map from the post-marshal lnotab:
# 5017 guard, 5018 local_scope, 5020 exec, 5022 count update, 5024 for,
# 5025 if-callable, 5026 globals store, 5027 set add. flags 0x43 => sync.
# global injected_count (source line 5016) is required: the stream reads
# injected_count with LOAD_GLOBAL and the TRUE varnames have no such local.
# Trailing LOAD_CONST/RETURN is the implicit fall-off (no return stmt).
# Anomalies: the count update uses VM op 0x0c which the proven map labels
# INPLACE_SUBTRACT; the guard (if injected_count < self.max_injections)
# only coheres with INPLACE_ADD (increment toward the cap), so += 1 is
# emitted and the const is marked below. Consts are armor-decoyed.

def inject(self, code):
    global injected_count
    if injected_count < self.max_injections:
        local_scope = {}
        exec(code, globals(), local_scope)
        injected_count += 1  # const-recovered (VM 0x0c; read as add)
        for name, func in local_scope.items():
            if callable(func):
                globals()[name] = func
                self._injected_methods.add(name)

# create_on_message_handler   (original line 4959)
############################################################################

# [confidence=medium - see wave45 evidence]
# Evidence: dec_MultiSniper.create_on_message_handler_2664158660016.marshal
#   (true metadata + armed lnotab). Gate vs py38 compile: names(-armor)=()
#   EXACT, varnames=('self','sniperbot','on_message'), argcount=2, flags
#   0x03, cellvars=('sniperbot',) EXACT -> the closure captures ONLY
#   sniperbot (self is NOT used inside on_message; a 12B one-cell
#   MAKE_FUNCTION matches the lnotab budget 4960=12B EXACT).
#   Line map (0:4959, 0:4960, 12:5001) IDENTICAL; 5001 armed +32B
#   (uniform armor tail).
# CLOSURE BODY (lines 4961-5000): NOT byte-evidenced. Live twin: the 94B
#   trap streams (fence45/trap/plain_*_len94.hex) decode to a real py38
#   try/except body: try { G0().M1(arg) } except <exception-class>:
#   three statements - an attr-chain call with a list-build + method call
#   stored to a local, a two-arg method call whose argument ends in
#   BINARY_ADD, and a final zero-arg method call; ends END_FINALLY +
#   implicit return None. The 40-line body budget vs 94B stream implies
#   blank/comment lines and/or nested code objects (comprehension/lambda
#   consts live outside the flat stream). Placeholder below shows shape
#   only (references ONLY sniperbot) - FLAG.
# ANOMALY: recovered BotsManager.run_bots (orig L4548) calls
#   create_on_message_handler() with no args - inconsistent with this
#   method signature (self, sniperbot).

def create_on_message_handler(self, sniperbot):
    def on_message(message):
        sniperbot.handle_message(message)  # FLAG: placeholder body 4961-5000
    return on_message

############################################################################

# [confidence=medium - see wave45 evidence]
# Evidence: dec_MultiSniper.create_on_message_handler_2664158660016.marshal
#   (true metadata + armed lnotab). Gate vs py38 compile: names(-armor)=()
#   EXACT, varnames=('self','sniperbot','on_message'), argcount=2, flags
#   0x03, cellvars=('sniperbot',) EXACT -> the closure captures ONLY
#   sniperbot (self is NOT used inside on_message; a 12B one-cell
#   MAKE_FUNCTION matches the lnotab budget 4960=12B EXACT).
#   Line map (0:4959, 0:4960, 12:5001) IDENTICAL; 5001 armed +32B
#   (uniform armor tail).
# CLOSURE BODY (lines 4961-5000): NOT byte-evidenced. Live twin: the 94B
#   trap streams (fence45/trap/plain_*_len94.hex) decode to a real py38
#   try/except body: try { G0().M1(arg) } except <exception-class>:
#   three statements - an attr-chain call with a list-build + method call
#   stored to a local, a two-arg method call whose argument ends in
#   BINARY_ADD, and a final zero-arg method call; ends END_FINALLY +
#   implicit return None. The 40-line body budget vs 94B stream implies
#   blank/comment lines and/or nested code objects (comprehension/lambda
#   consts live outside the flat stream). Placeholder below shows shape
#   only (references ONLY sniperbot) - FLAG.
# ANOMALY: recovered BotsManager.run_bots (orig L4548) calls
#   create_on_message_handler() with no args - inconsistent with this
#   method signature (self, sniperbot).

def create_on_message_handler(self, sniperbot):
    def on_message(message):
        sniperbot.handle_message(message)  # FLAG: placeholder body 4961-5000
    return on_message


# [confidence=medium - see wave45 evidence]
# Evidence: dec_MultiSniper.create_on_connect_handler_2664158659840.marshal
#   (true metadata + armed lnotab). Gate vs py38 compile: names(-armor)=()
#   EXACT (factory body references no globals), varnames=('self',
#   'sniperbot','on_connect'), argcount=2, flags 0x03, cellvars=('self',
#   'sniperbot') EXACT -> the closure captures BOTH self and sniperbot.
#   Line map (0:4949, 0:4950, 14:4957) IDENTICAL; budget 4950=14B EXACT
#   (LOAD_CLOSURE self; LOAD_CLOSURE sniperbot; BUILD_TUPLE 2; code; name;
#   MAKE_FUNCTION 8; STORE_FAST). 4957 armed +32B (uniform armor tail).
# CLOSURE BODY (lines 4951-4956): NOT byte-evidenced. Live twin: the 386B
#   trap streams (fence45/trap/plain_*_len386.hex, opcode-remapped real
#   py38 VM stream) decode to a loop-heavy on_connect body: timing guard
#   (LOAD_ATTR*n const; BINARY_SUBTRACT; COMPARE > 0), a while back-edge
#   (JUMP_ABSOLUTE to condition), two FOR_ITER scans with `in`/`not in`
#   membership tests, BUILD_TUPLE argument pairs, a dict .items() loop with
#   UNPACK_SEQUENCE 2, and a final CALL_FUNCTION_EX. Placeholder below
#   shows shape only (references both captured cells) - FLAG.
# ANOMALY: recovered BotsManager.run_bots (orig L4548) calls
#   create_on_connect_handler() with no args - inconsistent with this
#   method signature (self, sniperbot); that call site predates/aliases
#   the MultiSniper factory pair.

def create_on_connect_handler(self, sniperbot):
    def on_connect():
        self.handle_connect(sniperbot)  # FLAG: placeholder body 4951-4956


    return on_connect


############################################################################
# getSpotifyHeaders   (original line 6330)
############################################################################

async def getSpotifyHeaders():
    spotify_username = getConfigData().get('spotify_username')
    spotify_connections = [c for c in bot.config.get('connections') or [] if 'spotify' in c.type]
    if not spotify_connections:
        return None


    connection = spotify_connections[0]
    if spotify_username is not None:
        for c in spotify_connections:
            if spotify_username in c.name:
                connection = c
                break
    if bot.config['spotify_token_cache']['access_token'] and time.time() < bot.config['spotify_token_cache']['expires_at']:
        return {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {bot.config["spotify_token_cache"]["access_token"]}',
        }
    try:
        spotify_token = await fetchAccessToken(connection)
    except Exception as e:
        logging.error(f'Spotify access token: {e}')
        return None
    if spotify_token:
        return {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {spotify_token}',
        }
    return None

# getSpotifyCurrentSong   (original line 6392)
#----------------------------------------------------------------------------

async def getSpotifyCurrentSong():
    spotify_headers = await getSpotifyHeaders()
    if spotify_headers:
        async with ClientSession() as session:
            async with session.get('https://api.spotify.com/v1/me/player', headers=spotify_headers) as response:
                if response.status == 200:
                    try:
                        data = await response.json()
                        item = data.get('item')
                        if not item:
                            return
                        progress_ms = data.get('progress_ms') or 0
                        duration_ms = item.get('duration_ms') or 0
                        album = item.get('album') or {}
                        images = album.get('images') or []
                        artists = item.get('artists') or []
                        artist = artists[0].get('name', '') if artists else (item.get('show') or {}).get('publisher', '')
                        start_ms = int(time.time() * 1000) - progress_ms
                        name = item.get('name', '')
                        if not data.get('is_playing'):
                            name += ' (Paused)'
                        return name, artist, album.get('name', ''), images[0]['url'] if images else '', (item.get('external_urls') or {}).get('spotify', ''), str(start_ms), str(start_ms + duration_ms), progress_ms, duration_ms / 1000.0
                    except Exception as e:
                        pass


#----------------------------------------------------------------------------
# playSpotifySongByUri   (original line 6435)
#----------------------------------------------------------------------------
async def playSpotifySongByUri(uri):
    spotify_headers = await getSpotifyHeaders()
    if spotify_headers:
        payload = {"uris": [(f"{uri}")]}
        r = await runBlocking((requests.put), "https://api.spotify.com/v1/me/player/play",
          headers=spotify_headers, json=payload, timeout=10)
        if 200 <= r.status_code < 300:
            return True
        print((str(r.text)), type_="ERROR")
    return False

#----------------------------------------------------------------------------
# addSpotifySongToQueue   (original line 6449)
#----------------------------------------------------------------------------
async def addSpotifySongToQueue(uri):
    spotify_headers = await getSpotifyHeaders()
    if spotify_headers:
        payload = {"uri": uri}
        r = await runBlocking((requests.post), "https://api.spotify.com/v1/me/player/queue",
          headers=spotify_headers, params=payload, timeout=10)
        if 200 <= r.status_code < 300:
            return True
        return False

#----------------------------------------------------------------------------
# setSpotifyPlaybackState   (original line 6461)
#----------------------------------------------------------------------------
async def setSpotifyPlaybackState(state):
    spotify_headers = await getSpotifyHeaders()
    if spotify_headers:
        state = state.lower()
        if "play" in state:
            r = await runBlocking((requests.put), "https://api.spotify.com/v1/me/player/play",
              headers=spotify_headers, timeout=10)
        elif "pause" in state:
            r = await runBlocking((requests.put), "https://api.spotify.com/v1/me/player/pause",
              headers=spotify_headers, timeout=10)
        elif "next" in state:
            r = await runBlocking((requests.post), "https://api.spotify.com/v1/me/player/next",
              headers=spotify_headers, timeout=10)
        elif "prev" in state or "previous" in state:
            r = await runBlocking((requests.post), "https://api.spotify.com/v1/me/player/previous",
              headers=spotify_headers, timeout=10)
        else:
            return False
        if 200 <= r.status_code < 300:
            return state
        return False

#----------------------------------------------------------------------------
# runDefaultCommandError   (original line 6774)
#----------------------------------------------------------------------------
async def runDefaultCommandError(ctx, error, title):
    sendAppNotification(f"{title} | {error}", discord_url=(ctx.message.jump_url), channel=(ctx.message.channel), type_="ERROR")
    showToast(title=title, text=(str(error)), url=(ctx.message.jump_url), type_="ERROR")

#----------------------------------------------------------------------------
# sendWebhookNotification   (original line 6779)
#----------------------------------------------------------------------------
async def sendWebhookNotification(webhook_url, title, text):
    theme = getThemeData()
    notifications = getNotifications()
    try:
        async with ClientSession() as sess:
            await discord.Webhook.from_url(webhook_url, session=sess).send(username=(notifications["webhook"]["settings"]["name"]),
              avatar_url=(notifications["webhook"]["settings"]["avatar"]),
              content=(bot.user.mention if notifications["webhook"]["settings"]["pings"] else None),
              embed=discord.Embed(title=f'{theme["title"]} | {title}',
              description=(text if text else None),
              color=(int(theme["color"].replace("#", ""), 16))).set_footer(text=(theme["footer"]),
              icon_url=(theme["footer_icon"])).set_thumbnail(url=(theme["image"])).set_image(url=(theme["large_image"])))
    except Exception as e:
        try:
            logging.error(e)
        finally:
            e = None
            del e

#----------------------------------------------------------------------------
# dmToClientUser   (original line 6797)
#----------------------------------------------------------------------------
async def dmToClientUser(title, content):
    try:
        nighty_user = await bot_app.fetch_user(bot.user.id)
        return await nighty_user.send(embed=discord_bot.Embed(title=bot.config["theme"]["title"],
           description=content,
           color=int(bot.config["theme"]["color"].replace("#", ""), 16)).set_thumbnail(url=bot.config["theme"]["image"]).set_footer(text=bot.config["theme"]["footer"], icon_url=bot.config["theme"]["footer_icon"]).set_author(name=title, icon_url=bot.config["theme"]["author_icon"]).set_image(url=bot.config["theme"]["large_image"]))
    except Exception as e:
        logging.error(e)
#----------------------------------------------------------------------------
# set_guild_vanity   (original line 7086)
#----------------------------------------------------------------------------

async def set_guild_vanity(new_vanity, guild_id):
    mfa_ok = DiscordMfa().verify()
    if not mfa_ok:
        raise Exception('MFA verification failed - use `/misc mfasetup` to set up MFA.')

    guild_id = int(guild_id)
    async def editVanity(session, new_code, guild_id, recent_mfa_token=None):
        logging.info(f"[VANITY PROTECTOR] Attempting to set vanity code to '{new_code}' for guild {guild_id}.")
        headers = getAdvancedHeaders()
        headers['Authorization'] = getCurrentToken()
        headers['Content-Type'] = 'application/json'
        if recent_mfa_token:
            headers['X-Discord-Mfa-Authorization'] = recent_mfa_token

        cookies = {}
        if recent_mfa_token:
            cookies['__Secure-recent_mfa'] = recent_mfa_token


        loop = asyncio.get_event_loop()
        req = await loop.run_in_executor(None, lambda: session.patch(
            f'https://discord.com/api/v9/guilds/{guild_id}/vanity-url',
            headers=headers,
            json={'code': new_code},
            cookies=cookies))

        try:
            r = req.json()
        except Exception:
            logging.error(f'[VANITY PROTECTOR] Failed to parse Discord response ({req.status_code}): {req.text[:500]}')
            raise Exception(f'Failed to parse Discord response ({req.status_code}): {req.text[:500]}')

        if req.status_code == 401 or \
                r.get('code') == 60003 or \
                r.get('message') == 'Two factor is required for this operation':
            mfa = r.get('mfa', {})
            ticket = mfa.get('ticket')
            methods = mfa.get('methods', [])
            method = methods[0].get('type') if methods else None
            logging.info(f'[VANITY PROTECTOR] MFA required to set vanity code for guild {guild_id}. Method: {method}')
            return {'status': 'mfa', 'method': method, 'ticket': ticket}
        elif req.status_code == 400:
            logging.error(f"[VANITY PROTECTOR] Failed to set vanity code to '{new_code}' for guild {guild_id}: {r.get('message', 'Unknown error')}")
            return {'status': 'error', 'message': r.get('message', 'Unknown error')}
        elif req.status_code == 200:
            logging.info(f"[VANITY PROTECTOR] Vanity code successfully set to '{new_code}' for guild {guild_id}.")
            return {'status': 'ok'}
        raise Exception(f'[VANITY PROTECTOR] Vanity protect failed ({req.status_code}): {r}')

    try:
        if session := TLSSession(client_identifier=f'chrome_{random.randint(110, 115)}', random_tls_extension_order=True):
            recent_mfa_token = DiscordMfa().get_token()
            max_attempts = 3
            for attempt in range(1, max_attempts + 1):
                try:
                    r = await editVanity(session, new_vanity, guild_id, recent_mfa_token)
                    status = r.get('status')
                    if status == 'ok':
                        logging.info(f'[VANITY PROTECTOR]  Success {" after mfa" if attempt > 1 else ""}')
                        return {'status': 'ok', 'message': 'Done.'}
                    elif status == 'mfa':
                        if attempt == max_attempts:
                            logging.error(f'Vanity protect failed: MFA still required after {max_attempts} attempts')
                            break
                        logging.info(f'[vanity mfa required] (attempt {attempt}/{max_attempts})')
                        recent_mfa_token = await DiscordMfa().refresh_token(session, method=r.get('method'), ticket=r.get('ticket'))
                        if recent_mfa_token is None:
                            raise Exception('Failed to refresh MFA token - token not refreshed')
                    else:
                        logging.error(f'[VANITY PROTECTOR] Vanity protect failed: {r.get("message", "Unknown error")}, status: {status}')
                        break
                except Exception as e:
                    if attempt == max_attempts:
                        logging.error(f'[VANITY PROTECTOR] Vanity protect failed after {max_attempts} attempts: {e}')
                        break
                    logging.error(f'[VANITY PROTECTOR] Vanity protect attempt {attempt}/{max_attempts} failed: {e}, retrying...')
                    await asyncio.sleep(3)
    except Exception as e:
        logging.error(f'[VANITY PROTECTOR] Vanity protect failed: {e}')


#----------------------------------------------------------------------------
# getAsset   (original line 7207)
#----------------------------------------------------------------------------

async def getAsset(app_id, key):
    async with ClientSession() as session:
        async with session.get(f'https://discord.com/api/v10/oauth2/applications/{app_id}/assets') as req:
            app_assets = await req.json()
    for t_list in app_assets:
        try:
            if str(key) == t_list['name']:
                return t_list['id']
        except:
            pass


#----------------------------------------------------------------------------
# uploadAsset   (original line 7223)
#----------------------------------------------------------------------------
async def uploadAsset(name, base64_str):
    r = app_manager().upload_asset(getCurrentAppId(), name, base64_str)
    return r

#----------------------------------------------------------------------------
# deleteAsset   (original line 7227)
#----------------------------------------------------------------------------
async def deleteAsset(name):
    app_id = getCurrentAppId()
    asset = await getAsset(app_id, name)
    if asset:
        r = app_manager().delete_asset(app_id, asset["id"])
        if r:
            return "Deleted"

#----------------------------------------------------------------------------
# helpCmd   (original line 7447)
#----------------------------------------------------------------------------
async def helpCmd(interaction, category):
    category = category.lower()
    commands = [
     CommandLogic("admin", "Administration commands"),
     CommandLogic("animated", "Animated messages"),
     CommandLogic("fun", "Funny commands"),
     CommandLogic("image", "Image commands"),
     CommandLogic("misc", "Miscellaneous"),
     CommandLogic("recovery", "Backup & restores"),
     CommandLogic("settings", "Settings"),
     CommandLogic("spotify", "Spotify"),
     CommandLogic("text", "Text based commands"),
     CommandLogic("tools", "General tools"),
     CommandLogic("troll", "Trolling commands"),
     CommandLogic("utils", "Utility")]
    if getConfigData()["riskmode"]:
        commands.append(CommandLogic("abuse", "Abusive commands"))
    commands = sorted(commands, key=commandSort)
    desc = ""
    for cmd in commands:
        desc += f"**/{cmd.name}** \xbb {cmd.description}\n"

    if getConfigData()["private"] or f"/{interaction.command.name}" in getForcePrivateCommands():
        theme_data = getThemeData()
        if theme_data.get("v2"):
            if theme_data["v2"]["enabled"]:
                layout_view = discord_bot.ui.LayoutView()
                container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                for component in buildThemeV2(theme_data["v2"]["layout"], desc, "Help"):
                    container_view.add_item(component)

                layout_view.add_item(container_view)
                return await interaction.response.send_message(view=layout_view, ephemeral=True)
        await interaction.response.send_message(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=desc,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name="Help", icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])),
          ephemeral=True,
          delete_after=(getConfigData()["deletetimer"]))
    elif getConfigData()["forward"]:
        full_command_name = None
        if interaction.command:
            command = interaction.command
            if command.parent:
                group_name = command.parent.name
                full_command_name = f"{group_name} {command.name}"
            else:
                full_command_name = f"{command.name}"
        await interaction.response.send_message(f"Command used: **/{full_command_name if full_command_name else interaction.command.name}**", ephemeral=True, delete_after=5)
        await forwardEmbedMethod(interaction.channel_id, desc, "Help")
    else:
        theme_data = getThemeData()
        if theme_data.get("v2"):
            if theme_data["v2"]["enabled"]:
                layout_view = discord_bot.ui.LayoutView()
                container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                for component in buildThemeV2(theme_data["v2"]["layout"], desc, "Help"):
                    container_view.add_item(component)

                layout_view.add_item(container_view)
                return await interaction.response.send_message(view=layout_view, ephemeral=(getConfigData()["private"]))
        await interaction.response.send_message(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=desc,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name="Help", icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])),
          ephemeral=(getConfigData()["private"]),
          delete_after=(getConfigData()["deletetimer"]))

#----------------------------------------------------------------------------
# showCmds   (original line 7515)
#----------------------------------------------------------------------------
async def showCmds(interaction, group):
    commands = sorted((group.commands), key=commandSort)
    desc = ""
    for cmd in commands:
        desc += f"**/{cmd.name}** \xbb {cmd.description}\n"

    cmd = interaction.command
    if cmd.parent:
        full_cmd = f"/{cmd.parent.name} {cmd.name}"
    else:
        full_cmd = f"/{cmd.name}"
    if getConfigData()["private"] or full_cmd in getForcePrivateCommands():
        theme_data = getThemeData()
        if theme_data.get("v2"):
            if theme_data["v2"]["enabled"]:
                layout_view = discord_bot.ui.LayoutView()
                container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                for component in buildThemeV2(theme_data["v2"]["layout"], desc, f"/{group.name} \xbb {group.description}"):
                    container_view.add_item(component)

                layout_view.add_item(container_view)
                return await interaction.response.send_message(view=layout_view, ephemeral=True)
        await interaction.response.send_message(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=desc,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=f"/{group.name} \xbb {group.description}", icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])),
          ephemeral=True,
          delete_after=(getConfigData()["deletetimer"]))
    elif getConfigData()["forward"]:
        full_command_name = None
        if interaction.command:
            command = interaction.command
            if command.parent:
                group_name = command.parent.name
                full_command_name = f"{group_name} {command.name}"
            else:
                full_command_name = f"{command.name}"
        await interaction.response.send_message(f"Command used: **/{full_command_name if full_command_name else interaction.command.name}**", ephemeral=True, delete_after=5)
        await forwardEmbedMethod(interaction.channel_id, desc, f"/{group.name} \xbb {group.description}")
    else:
        theme_data = getThemeData()
        if theme_data.get("v2"):
            if theme_data["v2"]["enabled"]:
                layout_view = discord_bot.ui.LayoutView()
                container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                for component in buildThemeV2(theme_data["v2"]["layout"], desc, f"/{group.name} \xbb {group.description}"):
                    container_view.add_item(component)

                layout_view.add_item(container_view)
                return await interaction.response.send_message(view=layout_view, ephemeral=(getConfigData()["private"]))
        await interaction.response.send_message(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=desc,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=f"/{group.name} \xbb {group.description}", icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])),
          ephemeral=(getConfigData()["private"]),
          delete_after=(getConfigData()["deletetimer"]))

#----------------------------------------------------------------------------
# _autoDeferSlowCommand   (original line 7615)
#----------------------------------------------------------------------------

async def _autoDeferSlowCommand(interaction):
    try:
        await asyncio.sleep(AUTO_DEFER_AFTER)
        if interaction.response.is_done():
            return
        full_cmd = _nightySlashCommandName(interaction)
        ephemeral = True
        try:
            ephemeral = bool(getConfigData()['private']) or full_cmd in getForcePrivateCommands()
        except Exception:
            pass
        await interaction.response.defer(ephemeral=ephemeral)
        try:
            interaction.extras['nighty_auto_deferred'] = True
        except Exception:
            pass
        logging.warning(f'auto-deferred slow command {full_cmd} (no reply within {AUTO_DEFER_AFTER}s)')
    except Exception as e:
        logging.debug(f'auto-defer for {_nightySlashCommandName(interaction)} failed: {e}')


#----------------------------------------------------------------------------
# _nightyInteractionCheck   (original line 7640)
#----------------------------------------------------------------------------
async def _nightyInteractionCheck(interaction):
    try:
        if interaction.type is discord_bot.InteractionType.application_command:
            if (interaction.data or {}).get("type", 1) == 1:
                bot_app.loop.create_task(_autoDeferSlowCommand(interaction))
    except Exception as e:
        logging.debug(f"interaction check: {e}")
    return True
#----------------------------------------------------------------------------
# botCmd   (original line 7682)
#----------------------------------------------------------------------------
async def botCmd(interaction, author, text, thumb, followup, image_url, show_thumb):
    parts = splitEmbedText(text)
    result = await _botCmdSend(interaction, author, parts[0], thumb, followup, image_url, show_thumb)
    for part in parts[1:]:
        await _botCmdSend(interaction, author, part, thumb, True, image_url, show_thumb, first=False)

    return result

#----------------------------------------------------------------------------
# _botCmdSend   (original line 7689)
#----------------------------------------------------------------------------
async def _botCmdSend(interaction, author, text, thumb, followup, image_url, show_thumb, first):
    cmd = interaction.command
    if interaction.response.is_done():
        followup = True

    async def _deliverFollowup(**kwargs):
        """The FIRST reply after an auto-defer edits the deferred placeholder.

                Commands normally do botCmd() and then editBotCmd(), and editBotCmd
                edits the ORIGINAL response. If the first reply were posted as a plain
                followup, the "thinking" placeholder would be left behind and
                editBotCmd would update the wrong message. Turning the placeholder into
                the reply keeps the deferred path byte-for-byte equivalent to the normal
                one; every later reply is a genuine extra message.
                """
        try:
            if interaction.extras.pop("nighty_auto_deferred", False):
                kwargs.pop("ephemeral", None)
                return await interaction.edit_original_response(**kwargs)
        except Exception as e:
            logging.debug(f"botCmd: placeholder edit failed, falling back to followup: {e}")

        return await interaction.followup.send(**kwargs)


    full_cmd = f"/{cmd.name}"
    if isinstance(cmd, app_commands.Command):
        if cmd.parent:
            full_cmd = f"/{cmd.parent.name} {cmd.name}"
    if getConfigData()["private"] or full_cmd in getForcePrivateCommands():
        if followup:
            return await _deliverFollowup(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=text,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url),
              ephemeral=True)
        theme_data = getThemeData()
        if theme_data.get("v2"):
            if theme_data["v2"]["enabled"]:
                layout_view = discord_bot.ui.LayoutView()
                container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                for component in buildThemeV2(theme_data["v2"]["layout"], text, author):
                    container_view.add_item(component)

                layout_view.add_item(container_view)
                if followup:
                    return await _deliverFollowup(view=layout_view, ephemeral=True)
                return await interaction.response.send_message(view=layout_view, ephemeral=True)
        _embed = discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=text,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url)
        if followup:
            return await _deliverFollowup(embed=_embed, ephemeral=True)
        return await interaction.response.send_message(embed=_embed, ephemeral=True, delete_after=(getConfigData()["deletetimer"]))
    if getConfigData()["forward"]:
        full_command_name = None
        if interaction.command:
            command = interaction.command
            if command.parent:
                group_name = command.parent.name
                full_command_name = f"{group_name} {command.name}"
            else:
                full_command_name = f"{command.name}"
        _used_text = f"Command used: **/{full_command_name if full_command_name else interaction.command.name}**"
        if first:
            if followup:
                await _deliverFollowup(content=_used_text, ephemeral=True)
            else:
                await interaction.response.send_message(_used_text, ephemeral=True, delete_after=5)
        await forwardEmbedMethod(interaction.channel_id, text, author, image_url, show_thumb)
    else:
        if followup:
            return await _deliverFollowup(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=text,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url),
              ephemeral=(getConfigData()["private"]))
        theme_data = getThemeData()
        if theme_data.get("v2"):
            if theme_data["v2"]["enabled"]:
                layout_view = discord_bot.ui.LayoutView()
                container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                for component in buildThemeV2(theme_data["v2"]["layout"], text, author):
                    container_view.add_item(component)

                layout_view.add_item(container_view)
                if followup:
                    return await _deliverFollowup(view=layout_view, ephemeral=(getConfigData()["private"]))
                return await interaction.response.send_message(view=layout_view, ephemeral=(getConfigData()["private"]))
        _embed = discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=text,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url)
        if followup:
            return await _deliverFollowup(embed=_embed, ephemeral=(getConfigData()["private"]))
        return await interaction.response.send_message(embed=_embed, ephemeral=(getConfigData()["private"]), delete_after=(getConfigData()["deletetimer"]))
#----------------------------------------------------------------------------
# editBotCmd   (original line 7793)
#----------------------------------------------------------------------------
async def editBotCmd(interaction, author, text, thumb):
    cmd = interaction.command
    full_cmd = f"/{cmd.name}"
    if isinstance(cmd, app_commands.Command):
        if cmd.parent:
            full_cmd = f"/{cmd.parent.name} {cmd.name}"
    if getConfigData()["private"] or full_cmd in getForcePrivateCommands():
        return await interaction.edit_original_response(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=text,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=author, icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])))
    if getConfigData()["forward"]:
        full_command_name = None
        if interaction.command:
            command = interaction.command
            if command.parent:
                group_name = command.parent.name
                full_command_name = f"/{group_name} {command.name}"
            else:
                full_command_name = f"/{command.name}"
        await interaction.response.send_message(f"Command response update: **/{full_command_name if full_command_name else interaction.command.name}**", ephemeral=True, delete_after=5)
        await forwardEmbedMethod(interaction.channel_id, text, author)
    else:
        return await interaction.edit_original_response(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=text,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=author, icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])))
#----------------------------------------------------------------------------
# embedImage   (original line 7824)
#----------------------------------------------------------------------------
async def embedImage(interaction, content, title, image_url, thumb, private):
    try:
        image_url = image_url if image_url else getThemeData()["large_image"]
        cmd = interaction.command
        full_cmd = f"/{cmd.parent.name} {cmd.name}" if cmd.parent else f"/{cmd.name}"
        embed = discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=content,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_footer(text=(bot.config["theme"]["footer"]),
          icon_url=(bot.config["theme"]["footer_icon"])).set_image(url=image_url)
        if thumb:
            embed.set_thumbnail(url=(bot.config["theme"]["image"]))
        if title:
            embed.set_author(name=title, icon_url=(bot.config["theme"]["author_icon"]))
        ephemeral = True if (getConfigData()["private"]) or (full_cmd in getForcePrivateCommands()) else private
        await interaction.response.send_message(embed=embed, ephemeral=ephemeral, delete_after=(getConfigData()["deletetimer"]))
    except Exception as e:
        await interaction.response.send_message(f"Error: {e}", ephemeral=True)
        logging.error(e)
#----------------------------------------------------------------------------
# getGlobalBadges   (original line 7860)
#----------------------------------------------------------------------------

async def getGlobalBadges(user_id):
    async with ClientSession() as session:
        async with session.get(f'https://api.domi-btnr.dev/clientmodbadges/users/{user_id}', timeout=15) as r:
            badges = await r.json()
            global_badges = []
            if not isinstance(badges, dict):
                return global_badges
            for source, badges_list in badges.items():
                if not isinstance(badges_list, list):
                    continue
                for badge in badges_list:
                    if not isinstance(badge, dict) or not badge.get('name') or not badge.get('badge'):
                        continue
                    badge_info = {
                        'name': f"{badge['name']} ({source})",
                        'description': f"{badge['name']} ({source})",
                        'icon': badge['badge'],
                    }
                    global_badges.append(badge_info)
            return global_badges


#----------------------------------------------------------------------------
# execRemoteCommand   (original line 7937)
#----------------------------------------------------------------------------
async def execRemoteCommand(channel, cmd):
    message = [message async for message in channel.history(limit=1)][0]
    view = StringView(cmd)
    ctx = Context(prefix=None, view=view, bot=bot, message=message)
    invoker = view.get_word()
    ctx.command = bot.all_commands.get(invoker)
    await ctx.command.invoke(ctx)
    sendAppNotification(f"Remote command used: {ctx.command.name}", discord_url=(ctx.channel.jump_url), channel=(ctx.channel))
    return ctx

#----------------------------------------------------------------------------
# get_app_id   (original line 7978)
#----------------------------------------------------------------------------

async def get_app_id(token):
    client = discord_bot.Client(intents=discord_bot.Intents.none())
    try:
        try:
            await client.login(token)
            app_info = await client.application_info()
            return str(app_info.id)
        except discord_bot.LoginFailure:
            return None
        except discord_bot.HTTPException:
            return None
    finally:
        await client.close()
        return None


#----------------------------------------------------------------------------
# is_account_valid   (original line 7995)
#----------------------------------------------------------------------------

async def is_account_valid(token):
    client = discord.Client(chunk_guilds_at_startup=False,
                            afk=True)
    try:
        try:
            await client.login(token)
            return True
        except discord.HTTPException:
            return False
    finally:
        await client.close()


#----------------------------------------------------------------------------
# updateApp   (original line 8315)
#----------------------------------------------------------------------------

async def updateApp(name, avatar):
    [None, None]
    if avatar:
        async with ClientSession() as session:
            async with session.get(avatar) as resp:
                if resp.status != 200:
                    return {'status': 'error', 'text': 'Failed to fetch avatar image from the URL.'}
                avatar_bytes = await resp.read()
        if name:
            await bot_app.user.edit(username=name, avatar=avatar_bytes)
            return {'status': 'success', 'text': 'Updated app name & avatar.'}
        else:
            await bot_app.user.edit(avatar=avatar_bytes)
            return {'status': 'success', 'text': 'Updated app avatar.'}
    else:
        if name:
            await bot_app.user.edit(username=name)
            return {'status': 'success', 'text': 'Updated app name.'}

#----------------------------------------------------------------------------
# decorated_function   (original line 8920)


############################################################################
############################################################################
# addAccount   (original line 8843)

############################################################################
# addAccount   (original line 8843)
############################################################################

def addAccount(self, profileName, token):
    r = requests.get(
        'https://discord.com/api/v10/users/@me',
        headers={
            'Authorization': token,
            'Content-Type': 'application/json',
            'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; '
                           'WOW64) AppleWebKit/537.36 '
                           '(KHTML, like Gecko) '
                           'discord/1.0.9001 '
                           'Chrome/83.0.4103.122 '
                           'Electron/9.3.5 Safari/537.36')},
        verify=False,
        timeout=15)  # const-recovered
    if r.status_code != 200:  # const-recovered
        return {'error': 'invalid_token', 'message': 'Invalid token'}  # const-recovered (values decoyed)
    logins = getConfigData()['logins']  # const-recovered
    found = {'name': False, 'token': {'exists': False, 'login': None}}  # const-recovered (exact keys decoyed)
    for lg in list(logins):
        if str(lg) == str(profileName):
            found['name'] = True  # const-recovered
        if logins[lg]['token'] == str(token):  # const-recovered
            found['token'] = {'exists': True, 'login': str(lg)}  # const-recovered
    if found['name']:
        return {f'{profileName}': {'error': 'invalid_token', 'message': 'Profile name already exists'}}  # const-recovered
    elif found['token']['exists']:
        return {f'{profileName}': {'error': 'invalid_token', 'message': f'Already logged in: {found["token"]["login"]}'}}  # const-recovered
    else:
        logins[f'{profileName}'] = {'token': str(token), 'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'verified': False}  # const-recovered
        config = getConfigData()
        config['logins'] = logins
        saveConfigData(config)
        return {f'{profileName}': {'error': 'account_added', 'message': 'Account added'}}  # const-recovered

############################################################################

def addAccount(self, profileName, token):
    r = requests.get(
        'https://discord.com/api/v10/users/@me',
        headers={
            'Authorization': token,
            'Content-Type': 'application/json',
            'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; '
                           'WOW64) AppleWebKit/537.36 '
                           '(KHTML, like Gecko) '
                           'discord/1.0.9001 '
                           'Chrome/83.0.4103.122 '
                           'Electron/9.3.5 Safari/537.36')},
        verify=False,
        timeout=15)  # const-recovered
    if r.status_code != 200:  # const-recovered
        return {'success': False, 'message': 'Invalid token'}  # const-recovered
    logins = getConfigData()['logins']  # const-recovered
    found = {'exists': False, 'login': {'exists': False, 'name': None}}  # const-recovered (exact keys decoyed)
    for lg in list(logins):
        if str(lg) == str(profileName):
            found['exists'] = True  # const-recovered
        if logins[lg]['token'] == str(token):  # const-recovered
            found['login'] = {'exists': True, 'name': str(lg)}  # const-recovered
    if found['exists']:
        return {f'{profileName}': {'success': False, 'message': 'Profile name already exists'}}  # const-recovered
    if found['login']['exists']:
        return {f'{profileName}': {'success': False, 'message': f'Token already added: {found["login"]["name"]}'}}  # const-recovered
    logins[f'{profileName}'] = {'token': str(token), 'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'via': 'web'}  # const-recovered
    config = getConfigData()
    config['logins'] = logins
    saveConfigData(config)
    return {f'{profileName}': {'success': True, 'message': 'Account added'}}  # const-recovered

############################################################################
# addTokenToAccounts   (original line 8285)

############################################################################
# addTokenToAccounts   (original line 8285)
############################################################################

# [confidence=medium - see wave45 evidence]
def addTokenToAccounts(self, token, profileName):
    logins = getConfigData()['logins']  # const-recovered
    found = {'name': False, 'token': {'exists': False, 'login': None}}  # const-recovered (exact keys decoyed)
    for lg in list(logins):
        if str(lg) == str(profileName):
            found['name'] = True  # const-recovered
        if logins[lg]['token'] == str(token):  # const-recovered
            found['token'] = {'exists': True, 'login': str(lg)}  # const-recovered
    if found['name']:
        if not bot.config.get('web_login_notify'):  # const-recovered
            evaluate_js(f'newToast("Account", "{profileName} already exists")')  # const-recovered
            bot.config['web_login_notify'] = True  # const-recovered
    elif found['token']['exists']:
        if not bot.config.get('web_login_notify'):  # const-recovered
            evaluate_js(f'newToast("Account", "{profileName} already added")')  # const-recovered
            bot.config['web_login_notify'] = True  # const-recovered
    else:
        logins[f'{profileName}'] = {'token': str(token), 'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'verified': False}  # const-recovered
        config = getConfigData()
        config['logins'] = logins
        saveConfigData(config)
        if not bot.config.get('web_login_notify'):  # const-recovered (decoy LOAD_DEREF/POP_JUMP_IF_TRUE pair in stream here)
            evaluate_js(f'newToast("Account", "{profileName} added")')  # const-recovered
            bot.config['web_login_notify'] = True  # const-recovered
        return 'success'  # const-recovered (literal unknown; fresh const slot #16)
    return None

############################################################################

# [confidence=medium - see wave45 evidence]
def addTokenToAccounts(self, token, profileName):
    logins = getConfigData()['logins']  # const-recovered
    found = {'exists': False, 'login': {'exists': False, 'name': None}}  # const-recovered (exact keys decoyed)
    for lg in list(logins):
        if str(lg) == str(profileName):
            found['exists'] = True  # const-recovered
        if logins[lg]['token'] == str(token):  # const-recovered
            found['login'] = {'exists': True, 'name': str(lg)}  # const-recovered
    if found['exists']:
        if not bot.config.get('web_login_notify'):  # const-recovered
            evaluate_js(f'newToast("Account", "{profileName} already exists")')  # const-recovered
            bot.config['web_login_notify'] = True  # const-recovered
        return None  # const-recovered
    if found['login']['exists']:
        if not bot.config.get('web_login_notify'):  # const-recovered
            evaluate_js(f'newToast("Account", "{profileName} already added")')  # const-recovered
            bot.config['web_login_notify'] = True  # const-recovered
        return None  # const-recovered
    logins[f'{profileName}'] = {'token': str(token), 'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'via': 'web'}  # const-recovered
    config = getConfigData()
    config['logins'] = logins
    saveConfigData(config)
    if not bot.config.get('web_login_notify'):  # const-recovered
        evaluate_js(f'newToast("Account", "{profileName} added")')  # const-recovered
        bot.config['web_login_notify'] = True  # const-recovered
    return True  # const-recovered (literal unknown; single-const return)

############################################################################
# getRPCParty   (original line 7192)

############################################################################
# getRPCParty   (original line 7192)
############################################################################

def getRPCParty(party):
    rpc_party = {}
    if party:
        if party == [None, None]:  # const-recovered (unset-party default per profile template)
            rpc_party = {}
        elif party:
            rpc_party = {'id': bot.user.id, 'size': [party[1], party[2]]}  # const-recovered
        else:
            rpc_party = party
    return rpc_party

############################################################################

def getRPCParty(party):
    rpc_party = {}
    if party:
        if party == [0, 0]:  # const-recovered
            rpc_party = {}
        elif party:
            rpc_party = {'id': bot.user.id, 'size': [party[1], party[2]]}  # const-recovered
        else:
            rpc_party = party
    return rpc_party

############################################################################
# after_request   (original line 9108)


############################################################################
# after_request   (original line 9108)
############################################################################

# Evidence: dec_after_request_2664158309696.marshal (true metadata + armed
#   lnotab). Gate vs py38 compile: names(-armor)=('headers','add') EXACT,
#   varnames=('response',), argcount=1, flags 0x43 (NOFREE) EXACT.
#   Line map (0:9108, 14:9110..9114, 70:9115) IDENTICAL; budgets 9110-9114
#   = 14B each EXACT (7 instrs = response.headers.add(k, v)); five add
#   statements anchored. Only 9115 armed +32B (uniform armor tail; orig
#   `return response` = 4B).
# Consts armor-stripped (token 592): the four standard CORS pairs are
#   const-recovered from the app idiom; the FIFTH add is evidenced (14B
#   statement slot) but its key/value are the least certain - marked below.

def after_request(response):

    response.headers.add('Access-Control-Allow-Origin', '*')  # const-recovered
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')  # const-recovered
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')  # const-recovered
    response.headers.add('Access-Control-Allow-Credentials', 'true')  # const-recovered
    response.headers.add('Access-Control-Max-Age', '3600')  # const-recovered; key/value uncertain
    return response

############################################################################
############################################################################
# handle_preflight   (original line 9117)


############################################################################
# handle_preflight   (original line 9117)
############################################################################

# Evidence: dec_handle_preflight_2664158309872.marshal (true metadata + armed
#   lnotab). Gate vs py38 compile: names(-armor)=('request','method',
#   'jsonify','headers','add') EXACT ORDER; varnames=('response',),
#   argcount=0, flags 0x43 EXACT.
#   Line map (0:9117, 10:9119, 16:9120, 30..72:9121-9125) IDENTICAL;
#   budgets 9119=10B (request.method == 'OPTIONS'), 9120=6B (response =
#   jsonify() - zero-arg, matches the recovered sibling handler in the
#   safe_add_individual_route factory: `return jsonify()`), 9121-9124=14B
#   each EXACT (4 x response.headers.add). Only 9125 armed +32B (uniform
#   armor tail).
# Consts armor-stripped (token 593): CORS pairs const-recovered (same
#   quartet as unit L9108 after_request minus the fifth).

def handle_preflight():

    if request.method == 'OPTIONS':
        response = jsonify()
        response.headers.add('Access-Control-Allow-Origin', '*')  # const-recovered
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')  # const-recovered
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')  # const-recovered
        response.headers.add('Access-Control-Allow-Credentials', 'true')  # const-recovered
        return response

############################################################################
############################################################################
# handle_connect   (original line 9127)


############################################################################
# handle_connect   (original line 9127)
############################################################################

# Evidence: dec_handle_connect_2664158310048.marshal (true metadata + armed
#   lnotab). Gate vs py38 compile: names(-armor)=('session','logging',
#   'warning','request','remote_addr','disconnect','info','emit') EXACT
#   ORDER; varnames=(), argcount=0, flags 0x43 EXACT.
#   Line map (0:9127, 8:9129, 26:9130, 32:9131, 36:9132, 54:9134) IDENTICAL;
#   budgets ALL interior lines EXACT: 9129=8B ('user_id' not in session),
#   9130=18B (9-instr f-string: logging.warning(f'...{request.remote_addr}')
#   - concat form would be 16B), 9131=6B (disconnect()), 9132=4B (LOAD_CONST
#   False + RETURN_VALUE -> `return False`, flask-socketio connect reject),
#   9133=18B (f-string logging.info). Only 9134 armed +32B (uniform tail).
# Const grounding: the shipped web panel (Nighty.exe_extracted
#   PYZ.pyz_extracted web/index.html) listens `socket.on('connected',
#   (data) => console.log(data.message))` -> the emit event name
#   'connected' and payload key 'message' are GROUNDED; payload text and
#   log messages are const-recovered (armor token 594).

def handle_connect():

    if 'user_id' not in session:
        logging.warning(f'Unauthorized WebSocket connection attempt from {request.remote_addr}')  # const-recovered
        disconnect()
        return False
    logging.info(f'Client connected: {request.remote_addr}')  # const-recovered
    emit('connected', {'message': 'Connected to Nighty server'})  # event/key grounded; text const-recovered

############################################################################
############################################################################
# handle_execute_js   (original line 9136)


############################################################################
# handle_execute_js   (original line 9136)
############################################################################

# Evidence: dec_handle_execute_js_2664158310224.marshal (true metadata +
#   armed lnotab). Gate vs py38 compile: names(-armor)=('get','logging',
#   'info','eval','emit','Exception','str') EXACT ORDER (str AFTER Exception
#   -> str() only in the except branch); varnames=('data','js_code',
#   'result','e'), argcount=1, flags 0x43 EXACT.
#   Line positions IDENTICAL; budgets EXACT: 9139=12B (js_code =
#   data.get('code', '')), 9143=2B (SETUP_FINALLY at try:), 9144=8B
#   (result = eval(js_code)), 9146=16B (py38 except header: DUP_TOP;
#   LOAD_GLOBAL Exception; COMPARE_OP exc-match; POP_JUMP_IF_FALSE;
#   POP_TOP; POP_TOP; STORE_FAST e; POP_TOP). 9140 armed +10B and 9145 +4B
#   (armor decoy injection near the call sites); 9147 = single except
#   statement + uniform +36B armor tail (a second handler statement would
#   break the tail arithmetic: 76 = 18 stmt + 22 machinery + 36 tail).
# Const grounding (web/index.html): panel does `socket.emit('js_result',
#   {success, result|error, code})` and listens `socket.on('js_result')`;
#   server side execute_js_via_websocket (orig L2137) emits
#   socketio.emit('execute_js', {'code': js_code}). So data key 'code' and
#   event 'js_result' are GROUNDED; log texts const-recovered (token 595).
# ANOMALY: the server-side eval(js_code) is real (name 'eval' + 8B slot at
#   9144) - the handler evaluates the reported code server-side and echoes
#   the outcome back on 'js_result'; the panel logs that echo.

def handle_execute_js(data):


    js_code = data.get('code', '')
    logging.info(f'Executing JavaScript: {js_code}')  # const-recovered


    try:
        result = eval(js_code)
        emit('js_result', {'result': result})
    except Exception as e:
        emit('js_result', {'error': str(e)})

############################################################################
############################################################################
# handle_disconnect   (original line 9149)


############################################################################
# handle_disconnect   (original line 9149)
############################################################################

# Evidence: dec_handle_disconnect_2664158326832.marshal (true metadata +
#   armed lnotab). Gate vs py38 compile: names(-armor)=('logging',
#   'warning','request','remote_addr') EXACT ORDER; varnames=(), argcount=0,
#   flags 0x43 EXACT.
#   Line map (0:9149, 0:9151) IDENTICAL - single body statement at 9151.
#   Budget: armed 54B = 22B statement + uniform 32B armor tail, i.e. the
#   9-instr f-string form (logging.warning(f'...{request.remote_addr}')).
#   The concat alternative ('...' + request.remote_addr) compiles to 20B
#   and would give 20+32=52 != 54, so the f-string form is byte-preferred.
# Log text const-recovered (armor token 596).

def handle_disconnect():

    logging.warning(f'Client disconnected: {request.remote_addr}')  # const-recovered

############################################################################

# Evidence: dec_handle_disconnect_2664158326832.marshal (true metadata +
#   armed lnotab). Gate vs py38 compile: names(-armor)=('logging',
#   'warning','request','remote_addr') EXACT ORDER; varnames=(), argcount=0,
#   flags 0x43 EXACT.
#   Line map (0:9149, 0:9151) IDENTICAL - single body statement at 9151.
#   Budget: armed 54B = 22B statement + uniform 32B armor tail, i.e. the
#   9-instr f-string form (logging.warning(f'...{request.remote_addr}')).
#   The concat alternative ('...' + request.remote_addr) compiles to 20B
#   and would give 20+32=52 != 54, so the f-string form is byte-preferred.
# Log text const-recovered (armor token 596).

def handle_disconnect():

    logging.warning(f'Client disconnected: {request.remote_addr}')  # const-recovered


# Evidence: dec_handle_execute_js_2664158310224.marshal (true metadata +
#   armed lnotab). Gate vs py38 compile: names(-armor)=('get','logging',
#   'info','eval','emit','Exception','str') EXACT ORDER (str AFTER Exception
#   -> str() only in the except branch); varnames=('data','js_code',
#   'result','e'), argcount=1, flags 0x43 EXACT.
#   Line positions IDENTICAL; budgets EXACT: 9139=12B (js_code =
#   data.get('code', '')), 9143=2B (SETUP_FINALLY at try:), 9144=8B
#   (result = eval(js_code)), 9146=16B (py38 except header: DUP_TOP;
#   LOAD_GLOBAL Exception; COMPARE_OP exc-match; POP_JUMP_IF_FALSE;
#   POP_TOP; POP_TOP; STORE_FAST e; POP_TOP). 9140 armed +10B and 9145 +4B
#   (armor decoy injection near the call sites); 9147 = single except
#   statement + uniform +36B armor tail (a second handler statement would
#   break the tail arithmetic: 76 = 18 stmt + 22 machinery + 36 tail).
# Const grounding (web/index.html): panel does `socket.emit('js_result',
#   {success, result|error, code})` and listens `socket.on('js_result')`;
#   server side execute_js_via_websocket (orig L2137) emits
#   socketio.emit('execute_js', {'code': js_code}). So data key 'code' and
#   event 'js_result' are GROUNDED; log texts const-recovered (token 595).
# ANOMALY: the server-side eval(js_code) is real (name 'eval' + 8B slot at
#   9144) - the handler evaluates the reported code server-side and echoes
#   the outcome back on 'js_result'; the panel logs that echo.

def handle_execute_js(data):


    js_code = data.get('code', '')
    logging.info(f'Executing JavaScript: {js_code}')  # const-recovered


    try:
        result = eval(js_code)
        emit('js_result', {'result': result})
    except Exception as e:
        emit('js_result', {'error': str(e)})


# Evidence: dec_handle_connect_2664158310048.marshal (true metadata + armed
#   lnotab). Gate vs py38 compile: names(-armor)=('session','logging',
#   'warning','request','remote_addr','disconnect','info','emit') EXACT
#   ORDER; varnames=(), argcount=0, flags 0x43 EXACT.
#   Line map (0:9127, 8:9129, 26:9130, 32:9131, 36:9132, 54:9134) IDENTICAL;
#   budgets ALL interior lines EXACT: 9129=8B ('user_id' not in session),
#   9130=18B (9-instr f-string: logging.warning(f'...{request.remote_addr}')
#   - concat form would be 16B), 9131=6B (disconnect()), 9132=4B (LOAD_CONST
#   False + RETURN_VALUE -> `return False`, flask-socketio connect reject),
#   9133=18B (f-string logging.info). Only 9134 armed +32B (uniform tail).
# Const grounding: the shipped web panel (Nighty.exe_extracted
#   PYZ.pyz_extracted web/index.html) listens `socket.on('connected',
#   (data) => console.log(data.message))` -> the emit event name
#   'connected' and payload key 'message' are GROUNDED; payload text and
#   log messages are const-recovered (armor token 594).

def handle_connect():

    if 'user_id' not in session:
        logging.warning(f'Unauthorized WebSocket connection attempt from {request.remote_addr}')  # const-recovered
        disconnect()
        return False
    logging.info(f'Client connected: {request.remote_addr}')  # const-recovered
    emit('connected', {'message': 'Connected to Nighty server'})  # event/key grounded; text const-recovered


# Evidence: dec_handle_preflight_2664158309872.marshal (true metadata + armed
#   lnotab). Gate vs py38 compile: names(-armor)=('request','method',
#   'jsonify','headers','add') EXACT ORDER; varnames=('response',),
#   argcount=0, flags 0x43 EXACT.
#   Line map (0:9117, 10:9119, 16:9120, 30..72:9121-9125) IDENTICAL;
#   budgets 9119=10B (request.method == 'OPTIONS'), 9120=6B (response =
#   jsonify() - zero-arg, matches the recovered sibling handler in the
#   safe_add_individual_route factory: `return jsonify()`), 9121-9124=14B
#   each EXACT (4 x response.headers.add). Only 9125 armed +32B (uniform
#   armor tail).
# Consts armor-stripped (token 593): CORS pairs const-recovered (same
#   quartet as unit L9108 after_request minus the fifth).

def handle_preflight():

    if request.method == 'OPTIONS':
        response = jsonify()
        response.headers.add('Access-Control-Allow-Origin', '*')  # const-recovered
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')  # const-recovered
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')  # const-recovered
        response.headers.add('Access-Control-Allow-Credentials', 'true')  # const-recovered
        return response


# Evidence: dec_after_request_2664158309696.marshal (true metadata + armed
#   lnotab). Gate vs py38 compile: names(-armor)=('headers','add') EXACT,
#   varnames=('response',), argcount=1, flags 0x43 (NOFREE) EXACT.
#   Line map (0:9108, 14:9110..9114, 70:9115) IDENTICAL; budgets 9110-9114
#   = 14B each EXACT (7 instrs = response.headers.add(k, v)); five add
#   statements anchored. Only 9115 armed +32B (uniform armor tail; orig
#   `return response` = 4B).
# Consts armor-stripped (token 592): the four standard CORS pairs are
#   const-recovered from the app idiom; the FIFTH add is evidenced (14B
#   statement slot) but its key/value are the least certain - marked below.

def after_request(response):

    response.headers.add('Access-Control-Allow-Origin', '*')  # const-recovered
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')  # const-recovered
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')  # const-recovered
    response.headers.add('Access-Control-Allow-Credentials', 'true')  # const-recovered
    response.headers.add('Access-Control-Max-Age', '3600')  # const-recovered; key/value uncertain
    return response

# decorated_function   (original line 8920)
############################################################################

# Evidence: dec_logout_2664158764176.marshal (true metadata + armed lnotab).
#   Gate vs py38 compile: names(-armor)=('request','method','path','session',
#   'serve_login_page') EXACT ORDER (session before serve_login_page forces
#   the f(*args,**kwargs) passthrough at 8923 and serve_login_page only at
#   8926); varnames=('args','kwargs'), argcount=0, flags 0x1f
#   (VARARGS|VARKEYWORDS|NESTED), freevars=('f',) all EXACT.
#   Line map (0:8920, 20:8922, 30:8925, 38:8926, 44:8928) IDENTICAL;
#   budgets 8922=20B (request.method=='POST' and request.path=='/login'),
#   8923=10B (return f(*args,**kwargs) incl CALL_FUNCTION_EX), 8925=8B
#   ('user_id' not in session), 8926=6B (return serve_login_page()) all
#   EXACT. Only 8928 armed +32B (uniform armor tail).
# ANOMALY: fence29 banked an armed-scratch body for this unit (ret racted
#   2026-10-17, see NightyRecovered Nighty.py L21156 note); this file is the
#   semantic reconstruction from true metadata, not the armor wrapper.

def decorated_function(*args, **kwargs):
    if request.method == 'POST' and request.path == '/login':
        return f(*args, **kwargs)

    if 'user_id' not in session:
        return serve_login_page()

    return f(*args, **kwargs)

# notifyNitroSnipe   (original line 9401)
#----------------------------------------------------------------------------
async def notifyNitroSnipe(msg):
    notifications = getNotifications()
    author = msg["author"]
    channel = msg["channel"]
    content = msg["content"]
    status = msg["status"]
    code = msg["code"]
    elapsed = msg["elapsed"]
    notification_type = "INFO"
    if status == "Nitro redeemed":
        notification_type = "SUCCESS"
    jump_url = msg["jump_url"].replace("https://", "discord://")
    print(f"Nitro Sniper (Turbo) | {status} | Code: {code} | By {author} | Elapsed: {elapsed} ms", discordChannel=channel, url=jump_url, type_=notification_type)
    if notifications.get("dm"):
        if notifications["dm"].get("nitrosniper"):
            await dmToClientUser(title="Nitro sniper (Turbo)", content=f"{status}\nBy {author}\n{content}\n\n{jump_url}")
        if notifications["toast"]["nitro"]:
            showToast(text=f"{status}: {content}", title="Nitro sniper (Turbo)", details=f"{status}: {content}", url=jump_url, type_=notification_type)
        if notifications["webhook"]["nitro"]:
            await sendWebhookNotification(notifications["webhook"]["nitro"], "Nitro sniper (Turbo)", f"{status}\nBy {author}\n{content}\n\n{jump_url}")

#----------------------------------------------------------------------------
# set_state   (original line 9575)


############################################################################
############################################################################
# toggle   (original line 9587)

############################################################################
# toggle   (original line 9587)
############################################################################

@classmethod
def toggle(cls):
    # line 9588 unrecovered (docstring/comment slot)

    return cls.set_state(not cls.get_state())

############################################################################

@classmethod
def toggle(cls):
    # docstring line 9588 unrecovered

    return cls.set_state(not cls.get_state())

# set_state   (original line 9575)
############################################################################

@classmethod
def set_state(cls, enabled, seconds=None):
    # docstring lines 9576-9579 unrecovered

    if enabled:
        value = cls.get_seconds() if seconds is None else int(seconds)  # const-recovered
    else:
        value = None  # const-recovered
    setOthersData('autovoiceleave', value)  # const-recovered
    return cls.get_state()

# autoLeaveCountdown   (original line 9600)
#----------------------------------------------------------------------------
async def autoLeaveCountdown(channel_id):
    """Grace period before auto-leaving an empty voice channel. Started as a
        background task when we become the last one in `channel_id`. Elsewhere,
        watching_channel_id is reset to None if someone joins, or if we leave/move
        \ufffd so after the wait, if it STILL points at this channel we're alone here
        and should leave."""
    try:
        await asyncio.sleep(AutoVoiceLeave.get_seconds())
        if AutoVoiceLeave.get_state() and AutoVoiceLeave.get_watching_channel_id() == channel_id and VoiceMuteManager().getActiveChannelId() == channel_id:
            channel = bot.get_channel(int(channel_id))
            if channel:
                try:
                    await channel.guild.change_voice_state(channel=channel)
                    v = await channel.connect(timeout=0, reconnect=False)
                    await asyncio.sleep(2)
                    await v.disconnect(force=True)
                    await bot.change_voice_state(channel=None)
                    v.cleanup()
                    guild_name = f"({channel.guild.name}) " if channel.guild else ""
                    print(f"Auto Leave VC | {channel.name} {guild_name}| Automatically left voice channel, because you were the last one in it.")
                    logging.info(f"Auto-leaving voice channel {channel.name} ({channel.id}) Automatically left voice channel, because you were the last one in it.")
                    AutoVoiceLeave.set_watching_channel_id(None)
                except Exception as e:
                    pass
                AutoVoiceLeave.set_watching_channel_id(None)
        if AutoVoiceLeave.get_watching_channel_id() == channel_id:
            AutoVoiceLeave.set_watching_channel_id(None)
    except Exception as e:
        logging.error(f"Autoleave countdown: {e}")
#----------------------------------------------------------------------------
# refresh_token   (original line 9664)
#----------------------------------------------------------------------------
async def refresh_token(self, session, method, ticket):
    logging.info("[DISCORD_MFA] Refreshing MFA token...")
    if method not in ('totp', 'password'):
        print(f"[DISCORD_MFA] Invalid MFA method: {method}", type_="ERROR")
        logging.error(f"[DISCORD_MFA] Invalid MFA method: {method}")
        return
    mfa_token = None
    if method == "totp":
        mfa_token = await self.getMfaToken()
    elif method == "password":
        mfa_token = self.getPassword()
    if not (mfa_token and ticket):
        return
    headers = getAdvancedHeaders()
    headers["Authorization"] = getCurrentToken()
    headers["Content-Type"] = "application/json"
    try:
        loop = asyncio.get_event_loop()
        req = await loop.run_in_executor(None, lambda: session.post("https://discord.com/api/v9/mfa/finish",
          headers=headers,
          json={'data':mfa_token, 
         'mfa_type':method,  'ticket':ticket}))
        logging.info(f"[DISCORD_MFA] Refreshing MFA token: {req}")
        r = req.json()
        if req.status_code == 200:
            token = r.get("token")
            self.set_token(token)
            return token
        raise Exception("Failed to refresh MFA token: " + str(r))
    except Exception as e:
        try:
            logging.error(f"[DISCORD_MFA] Error refreshing MFA token: {e}")
        finally:
            e = None
            del e

#----------------------------------------------------------------------------
# getMfaToken   (original line 9740)
#----------------------------------------------------------------------------
async def getMfaToken(self):
    seed = self._load_secrets().get("totp_seed")
    if not seed:
        return
    totp = pyotp.TOTP(seed)
    return totp.now()

#----------------------------------------------------------------------------
# perform_mute   (original line 9821)
#----------------------------------------------------------------------------
async def perform_mute(self, ids_to_mute):
    self._enqueue(ids_to_mute, True)
    addVoiceMuteHistory(ids_to_mute)

#----------------------------------------------------------------------------
# perform_unmute   (original line 9825)
#----------------------------------------------------------------------------
async def perform_unmute(self, ids_to_unmute):
    self._enqueue(ids_to_unmute, False)
    clearVoiceMuteHistory()

#----------------------------------------------------------------------------
# _flush_after_delay   (original line 9843)
#----------------------------------------------------------------------------
async def _flush_after_delay(self):
    delay = self.FLUSH_INTERVAL - (time.monotonic() - self._last_flush)
    if delay > 0:
        await asyncio.sleep(delay)
    await self._flush()

#----------------------------------------------------------------------------
# _flush   (original line 9851)
#----------------------------------------------------------------------------
async def _flush(self):
    if not self._pending:
        return
    batch = dict(self._pending)
    self._pending.clear()
    self._last_flush = time.monotonic()
    try:
        await self._apply(batch)
    except Exception as e:
        try:
            logging.error(f"voicemute flush: {e}")
        finally:
            e = None
            del e

    else:
        if self._pending:
            self._schedule_flush()

#----------------------------------------------------------------------------
# _apply   (original line 9865)
#----------------------------------------------------------------------------
async def _apply(self, batch):
    loop = asyncio.get_event_loop()
    user_settings = await loop.run_in_executor(None, lambda: requests.get((self.ENDPOINT), headers=(getBasicHeaders()), timeout=15))
    data = user_settings.json()
    raw_encoded = data.get("settings")
    decoded_full = PreloadedUserSettings.FromString(b64decode(raw_encoded))
    audio_settings = decoded_full.audio_context_settings
    updated = False
    for user_id, muted in batch.items():
        if user_id in audio_settings.user:
            s = audio_settings.user[user_id]
            if not s.muted == muted:
                while True:
                    pass

                break
            if not muted:
                while True:
                    pass

                break
            else:
                s = audio_settings.user[user_id]
                s.volume = 100
        s.muted = muted
        s.modified_at = int(time.time() * 1000)
        updated = True

    if not updated:
        return
    payload = decoded_full.SerializeToString()
    encoded = b64encode(payload).decode("ascii")
    await loop.run_in_executor(None, lambda: requests.patch((self.ENDPOINT), headers=(getBasicHeaders()), json={"settings": encoded}, timeout=15))

#----------------------------------------------------------------------------
# on_submit   (original line 9974)
#----------------------------------------------------------------------------
async def on_submit(self, interaction):
    valid, invalid = parseVoiceMuteIds(self.target_ids.value)
    added = sum((1 for uid in valid if addVoiceMuteListId(uid)))
    self.parent_view.render()
    await interaction.response.edit_message(embed=(self.parent_view.embed()), view=(self.parent_view))
    notes = []
    if added:
        notes.append(f"Added **{added}** ID(s).")
    if len(valid) - added:
        notes.append(f"{len(valid) - added} already present.")
    if invalid:
        notes.append(f'Skipped {len(invalid)} invalid (non-numeric): {", ".join(("`{t}`" for t in invalid[:10]))}')
    if notes:
        await interaction.followup.send((" ".join(notes)), ephemeral=True)

#----------------------------------------------------------------------------
# on_submit   (original line 10001)
#----------------------------------------------------------------------------
async def on_submit(self, interaction):
    valid, invalid = parseVoiceMuteIds(self.target_ids.value)
    removed = sum((1 for uid in valid if removeVoiceMuteListId(uid)))
    self.parent_view.render()
    await interaction.response.edit_message(embed=(self.parent_view.embed()), view=(self.parent_view))
    notes = []
    if removed:
        notes.append(f"Removed **{removed}** ID(s).")
    if len(valid) - removed:
        notes.append(f"{len(valid) - removed} not in the list.")
    if invalid:
        notes.append(f'Skipped {len(invalid)} invalid (non-numeric): {", ".join(("`{t}`" for t in invalid[:10]))}')
    if notes:
        await interaction.followup.send((" ".join(notes)), ephemeral=True)

#----------------------------------------------------------------------------
# interaction_check   (original line 10025)
#----------------------------------------------------------------------------
async def interaction_check(self, interaction):
    return interaction.user.id == self.author_id

#----------------------------------------------------------------------------
# _rerender   (original line 10066)
#----------------------------------------------------------------------------
async def _rerender(self, interaction):
    self.render()
    await interaction.response.edit_message(embed=(self.embed()), view=self)

#----------------------------------------------------------------------------
# _toggle_enabled   (original line 10070)
#----------------------------------------------------------------------------
async def _toggle_enabled(self, interaction):
    setVoiceMuteListEnabled(not isVoiceMuteListEnabled())
    await self._rerender(interaction)

#----------------------------------------------------------------------------
# _toggle_mode   (original line 10074)
#----------------------------------------------------------------------------
async def _toggle_mode(self, interaction):
    setVoiceMuteListMode("whitelist" if getVoiceMuteListMode() == "blacklist" else "blacklist")
    await self._rerender(interaction)

#----------------------------------------------------------------------------
# _add_id   (original line 10078)
#----------------------------------------------------------------------------
async def _add_id(self, interaction):
    await interaction.response.send_modal(VoiceMuteAddIdModal(self))

#----------------------------------------------------------------------------
# _remove_id   (original line 10081)
#----------------------------------------------------------------------------
async def _remove_id(self, interaction):
    await interaction.response.send_modal(VoiceMuteRemoveIdModal(self))

#----------------------------------------------------------------------------
# _clear   (original line 10084)
#----------------------------------------------------------------------------
async def _clear(self, interaction):
    cfg = getVoiceMuteConfig()
    cfg["list"]["ids"] = []
    saveVoiceMuteConfig(cfg)
    await self._rerender(interaction)

#----------------------------------------------------------------------------
# interaction_check   (original line 10098)
#----------------------------------------------------------------------------
async def interaction_check(self, interaction):
    return interaction.user.id == self.author_id

#----------------------------------------------------------------------------
# _rerender   (original line 10143)
#----------------------------------------------------------------------------
async def _rerender(self, interaction):
    self.render()
    await interaction.response.edit_message(embed=(self.embed()), view=self)

#----------------------------------------------------------------------------
# _toggle_non_friends   (original line 10147)
#----------------------------------------------------------------------------
async def _toggle_non_friends(self, interaction):
    setVoiceMuteSetting("non_friends_action", "nothing" if getVoiceMuteSetting("non_friends_action") == "automute" else "automute")
    await self._rerender(interaction)

#----------------------------------------------------------------------------
# _toggle_join   (original line 10151)
#----------------------------------------------------------------------------
async def _toggle_join(self, interaction):
    setVoiceMuteSetting("automute_on_join", not getVoiceMuteSetting("automute_on_join"))
    await self._rerender(interaction)

#----------------------------------------------------------------------------
# _toggle_new_users   (original line 10155)
#----------------------------------------------------------------------------
async def _toggle_new_users(self, interaction):
    setVoiceMuteSetting("auto_apply_new_users", not getVoiceMuteSetting("auto_apply_new_users"))
    await self._rerender(interaction)

#----------------------------------------------------------------------------
# _toggle_unmute_leave   (original line 10159)
#----------------------------------------------------------------------------
async def _toggle_unmute_leave(self, interaction):
    setVoiceMuteSetting("auto_unmute_on_leave", not getVoiceMuteSetting("auto_unmute_on_leave"))
    await self._rerender(interaction)

#----------------------------------------------------------------------------
# voicemuteHelpResponse   (original line 10172)
#----------------------------------------------------------------------------
async def voicemuteHelpResponse(interaction):
    try:
        text = "**/utils voicemute help** \xbb Show this menu\n**/utils voicemute run** \xbb Mute / unmute users in your voice channel\n**/utils voicemute list** \xbb Manage the whitelist / blacklist\n**/utils voicemute settings** \xbb Configure automatic behavior\n"
        await botCmd(interaction, "Voicemute \xbb Help", text)
    except Exception as e:
        await interaction.response.send_message(f"Error: {e}", ephemeral=True)
        logging.error(e)
#----------------------------------------------------------------------------
# voicemuteRunResponse   (original line 10186)
#----------------------------------------------------------------------------
async def voicemuteRunResponse(interaction, action):
    try:
        await botCmd(interaction, "Voicemute \xbb Run", f"Placeholder \u2014 would **{action}** users in your voice channel.\n*(logic not implemented yet)*")
    except Exception as e:
        await interaction.response.send_message(f"Error: {e}", ephemeral=True)
        logging.error(e)
#----------------------------------------------------------------------------
# voicemuteListResponse   (original line 10214)
#----------------------------------------------------------------------------
async def voicemuteListResponse(interaction):
    try:
        view = VoiceMuteListView(interaction.user.id)
        await interaction.response.send_message(embed=(view.embed()), view=view, ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Error: {e}", ephemeral=True)
        logging.error(e)
#----------------------------------------------------------------------------
# voicemuteSettingsResponse   (original line 10222)
#----------------------------------------------------------------------------
async def voicemuteSettingsResponse(interaction):
    try:
        view = VoiceMuteSettingsView(interaction.user.id)
        await interaction.response.send_message(embed=(view.embed()), view=view, ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Error: {e}", ephemeral=True)
        logging.error(e)
#----------------------------------------------------------------------------
# _resolveGuild   (original line 10522)
#----------------------------------------------------------------------------
async def _resolveGuild(self, value):
    value = str(value).strip()
    if value.isdigit():
        g = bot.get_guild(int(value))
        if g:
            return g
        try:
            return await bot.fetch_guild(int(value))
        except Exception:
            return
    lowered = value.lower()
    exact = [g for g in bot.guilds if g.name.lower() == lowered]
    if exact:
        return exact[0]
    partial = [g for g in bot.guilds if lowered in g.name.lower()]
    if len(partial) == 1:
        return partial[0]
#----------------------------------------------------------------------------
# save   (original line 10540)
#----------------------------------------------------------------------------

async def save(self, interaction, server_value, backup_name):
    author = 'Server Copy \xbb Create'
    try:
        await botCmd(interaction, author, '> Starting server backup, please wait...')

        guild = await self._resolveGuild(server_value)
        if not guild:
            return await editBotCmd(interaction, author, '> :x: Could not resolve that server. Pick it from the autocomplete list, or use its server ID.')


        base = self._backupsPath()
        backup_id = f"{self._sanitize(guild.name)}_{guild.id}_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}"
        backup_dir = os.path.join(base, backup_id)
        suffix = 1
        while os.path.exists(backup_dir):
            backup_dir = os.path.join(base, f"{backup_id}_{suffix}")
            suffix += 1
        backup_id = os.path.basename(backup_dir)
        os.makedirs(backup_dir, exist_ok=True)


        progress = {'phase': 'Starting', 'detail': '', 'lines': []}

        def render(final=False):
            if final:
                header = f"> :white_check_mark: Saved backup of **{guild.name}**"
            else:
                header = f"> :hourglass: Saving backup of **{guild.name}**"
            body = '\n'.join(progress['lines']) if progress['lines'] else ''
            tail = ''
            if not final:
                tail = f"\n> :gear: {progress['phase']}"
                if progress['detail']:
                    tail += f" ({progress['detail']})"
                tail += f"\n-# Next update <t:{int(time.time()) + 6}:R>"
            return f"{header}\n{body}{tail}".strip()

        async def push_update(final=False):
            content = render(final=final)
            try:
                await editBotCmd(interaction, author, content)
            except Exception:
                try:
                    print(f"Server backup | {progress['phase']}", type_='INFO')
                except Exception as e:
                    logging.error(f"server backup progress update failed: {e}")

        async def progress_loop():
            try:
                while True:
                    await push_update()
                    await asyncio.sleep(5)
            except asyncio.CancelledError:
                pass

        def set_phase(phase, detail=''):
            progress['phase'] = phase
            progress['detail'] = detail

        def mark_done(text):
            progress['lines'].append(f"> :white_check_mark: {text}")

        def serialize_overwrites(channel):


            result = []
            for principal, overwrite in channel.overwrites.items():
                allow, deny = overwrite.pair()
                if isinstance(principal, discord.Role):
                    result.append({
                        'target_type': 'role',
                        'id': principal.id,
                        'is_default': principal.is_default(),
                        'allow': allow.value,
                        'deny': deny.value})

                elif isinstance(principal, discord.Member):
                    result.append({
                        'target_type': 'member',
                        'id': principal.id,
                        'is_default': False,
                        'allow': allow.value,
                        'deny': deny.value})

            return result

        progress_task = asyncio.create_task(progress_loop())
        try:

            set_phase('Saving roles')
            roles_data = []
            everyone_permissions = None
            for role in sorted(guild.roles, key=lambda r: r.position):
                if role.is_default():
                    everyone_permissions = role.permissions.value
                    continue
                roles_data.append({
                    'id': role.id,
                    'name': role.name,
                    'permissions': role.permissions.value,
                    'colour': role.colour.value,
                    'hoist': role.hoist,
                    'mentionable': role.mentionable,
                    'position': role.position,
                    'managed': role.managed})

            mark_done(f"Roles ({len(roles_data)})")


            set_phase('Saving channels & categories')
            categories_data = []
            for category in sorted(guild.categories, key=lambda c: c.position):
                categories_data.append({
                    'id': category.id,
                    'name': category.name,
                    'position': category.position,
                    'overwrites': serialize_overwrites(category)})

            channels_data = []
            for channel in sorted([c for c in guild.channels if not isinstance(c, discord.CategoryChannel)], key=lambda c: c.position):
                if isinstance(channel, discord.TextChannel):
                    ctype = 'text'
                elif isinstance(channel, discord.VoiceChannel):
                    ctype = 'voice'
                elif isinstance(channel, discord.StageChannel):
                    ctype = 'stage'
                else:
                    continue
                channels_data.append({
                    'id': channel.id,
                    'type': ctype,
                    'name': channel.name,
                    'position': channel.position,
                    'category_id': channel.category_id,
                    'topic': getattr(channel, 'topic', None),
                    'nsfw': getattr(channel, 'nsfw', False),
                    'slowmode_delay': getattr(channel, 'slowmode_delay', 0),
                    'bitrate': getattr(channel, 'bitrate', None),
                    'user_limit': getattr(channel, 'user_limit', None),
                    'rtc_region': getattr(channel, 'rtc_region', None),
                    'default_auto_archive_duration': getattr(channel, 'default_auto_archive_duration', 1440),
                    'overwrites': serialize_overwrites(channel)})

            mark_done(f"Channels ({len(channels_data)}) & categories ({len(categories_data)})")


            icon_file = banner_file = splash_file = None
            emojis_data = []
            stickers_data = []
            async with ClientSession() as session:
                async def _download_to(url, path):
                        async with session.get(str(url)) as resp:
                            payload = await resp.read()
                        with open(path, 'wb') as f:
                            f.write(payload)

                set_phase('Saving icon/banner')
                if guild.icon:
                    try:
                        ext = 'gif' if guild.icon.is_animated() else 'png'
                        icon_file = f"icon.{ext}"
                        await _download_to(guild.icon.url, os.path.join(backup_dir, icon_file))
                    except Exception as e:
                        icon_file = None
                        logging.error(f"server backup icon failed: {e}")
                if getattr(guild, 'banner', None):
                    try:
                        ext = 'gif' if guild.banner.is_animated() else 'png'
                        banner_file = f"banner.{ext}"
                        await _download_to(guild.banner.url, os.path.join(backup_dir, banner_file))
                    except Exception as e:
                        banner_file = None
                        logging.error(f"server backup banner failed: {e}")
                if getattr(guild, 'splash', None):
                    try:
                        splash_file = 'splash.png'
                        await _download_to(guild.splash.url, os.path.join(backup_dir, splash_file))
                    except Exception as e:
                        splash_file = None
                        logging.error(f"server backup splash failed: {e}")

                source_emojis = list(guild.emojis)
                if source_emojis:
                    os.makedirs(os.path.join(backup_dir, 'emojis'), exist_ok=True)
                    for idx, emoji in enumerate(source_emojis, start=1):
                        set_phase('Saving emojis', f"{idx}/{len(source_emojis)}")
                        ext = 'gif' if emoji.animated else 'png'
                        fname = f"emojis/{self._sanitize(emoji.name)}_{emoji.id}.{ext}"
                        try:
                            await _download_to(emoji.url, os.path.join(backup_dir, fname))
                            emojis_data.append({'name': emoji.name, 'animated': emoji.animated, 'file': fname})
                        except Exception as e:
                            logging.error(f"server backup emoji '{emoji.name}' failed: {e}")
                    mark_done(f"Emojis ({len(emojis_data)})")

                def _sticker_ext(s):
                        fmt = (getattr(getattr(s, 'format', None), 'name', '') or '').lower()
                        if fmt == 'gif':
                            return 'gif'
                        if fmt == 'lottie':
                            return 'json'
                        return 'png'

                source_stickers = list(guild.stickers)
                if source_stickers:
                    os.makedirs(os.path.join(backup_dir, 'stickers'), exist_ok=True)
                    for idx, sticker in enumerate(source_stickers, start=1):
                        set_phase('Saving stickers', f"{idx}/{len(source_stickers)}")
                        fname = f"stickers/{self._sanitize(sticker.name)}_{sticker.id}.{_sticker_ext(sticker)}"
                        try:
                            await _download_to(sticker.url, os.path.join(backup_dir, fname))
                            stickers_data.append({
                                'name': sticker.name,
                                'description': sticker.description or '',
                                'emoji': getattr(sticker, 'emoji', None) or '\U0001f642',
                                'format': _sticker_ext(sticker),
                                'file': fname})

                        except Exception as e:
                            logging.error(f"server backup sticker '{sticker.name}' failed: {e}")
                    mark_done(f"Stickers ({len(stickers_data)})")


            set_phase('Writing manifest')
            manifest = {
                'schema': 1,
                'backup_id': backup_id,
                'backup_name': backup_name.strip() if backup_name else None,
                'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'created_ts': int(time.time()),
                'guild': {
                    'id': guild.id,
                    'name': guild.name,
                    'description': guild.description,
                    'afk_timeout': guild.afk_timeout,
                    'afk_channel_name': guild.afk_channel.name if guild.afk_channel else None,
                    'icon_file': icon_file,
                    'banner_file': banner_file,
                    'splash_file': splash_file,
                },
                'everyone_permissions': everyone_permissions,
                'roles': roles_data,
                'categories': categories_data,
                'channels': channels_data,
                'emojis': emojis_data,
                'stickers': stickers_data,
            }
            with open(os.path.join(backup_dir, 'server.json'), 'w', encoding='utf-8') as f:
                json.dump(manifest, f, indent=2, ensure_ascii=False)

            name_note = f" as `{manifest['backup_name']}`" if manifest['backup_name'] else ''
            mark_done(f"Saved id `{backup_id}`{name_note}")
            mark_done('Restore later with `/utils servercopy restore`')
            print(f"Server backup saved: {guild} -> {backup_dir}", type_='SUCCESS')
        except Exception as e:
            logging.error(f"server backup fatal error: {e}")
            mark_done(f":x: Stopped early: {e}")
        finally:
            progress_task.cancel()
            try:
                await progress_task
            except Exception:
                pass
            await push_update(final=True)
    except Exception as e:
        logging.error(f"ServerBackupManager.save: {e}")
        try:
            await editBotCmd(interaction, author, f"> :x: Error: {e}")
        except Exception:
            pass


#----------------------------------------------------------------------------
# _runRestore   (original line 10864)
#----------------------------------------------------------------------------

async def _runRestore(self, interaction, data, backup_dir, new_guild, label):


    BASE_DELAY = 2.5
    MAX_RETRIES = 3

    progress = {'phase': 'Starting', 'detail': '', 'lines': []}

    def render(final=False):
        if final:
            header = f'> :white_check_mark: Restored **{label}** into **{new_guild.name}**'
        else:
            header = f'> :hourglass: Restoring **{label}** into **{new_guild.name}**'
        body = '\n'.join(progress['lines']) if progress['lines'] else ''
        tail = ''
        if not final:
            tail = f'\n> :gear: {progress["phase"]}'
            if progress['detail']:
                tail += f' ({progress["detail"]})'
            tail += f'\n-# Next update <t:{int(time.time()) + 6}:R>'
        return f'{header}\n{body}{tail}'.strip()

    async def push_update(final=False):
        content = render(final=final)
        try:
            await interaction.edit_original_response(content=content)
        except Exception:
            try:
                if final:
                    print('Restore complete:\n' + '\n'.join(progress['lines']), type_='INFO')
                else:
                    detail = f' ({progress["detail"]})' if progress['detail'] else ''
                    print(f'Restore progress | {progress["phase"]}{detail}', type_='INFO')
            except Exception as e:
                logging.error(f'restore progress update failed: {e}')

    async def progress_loop():
        try:
            while True:
                await push_update()
                await asyncio.sleep(5)
        except asyncio.CancelledError:
            pass

    def set_phase(phase, detail=''):
        progress['phase'] = phase
        progress['detail'] = detail

    def mark_done(text):
        progress['lines'].append(f'> :white_check_mark: {text}')

    async def with_retry(coro_factory, what='operation'):
        delay = BASE_DELAY
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                return await coro_factory()
            except (discord.Forbidden, discord.NotFound) as e:
                logging.error(f'Restore {what} skipped ({type(e).__name__}): {e}')
                return None
            except Exception as e:
                retry_after = getattr(e, 'retry_after', None)
                wait = float(retry_after) + 1 if retry_after else delay
                if attempt < MAX_RETRIES:
                    logging.error(f'Restore {what} failed (attempt {attempt}/{MAX_RETRIES}): {e}; retrying in {wait:.1f}s')
                    await asyncio.sleep(wait)
                    delay *= 2
                else:
                    logging.error(f'Restore {what} permanently failed after {MAX_RETRIES} attempts: {e}')
                    return None

    guild_info = data.get('guild', {})
    everyone_role = new_guild.default_role
    role_mapping = {}

    def build_overwrites(entries):
        overwrites = {}
        for entry in entries or []:
            allow = discord.Permissions(int(entry.get('allow', 0)))
            deny = discord.Permissions(int(entry.get('deny', 0)))
            ow = discord.PermissionOverwrite.from_pair(allow, deny)
            if entry.get('target_type') == 'role':
                if entry.get('is_default'):
                    overwrites[everyone_role] = ow
                else:
                    mapped = role_mapping.get(entry.get('id'))
                    if mapped:
                        overwrites[mapped] = ow
            elif entry.get('target_type') == 'member':


                member = new_guild.get_member(int(entry.get('id')))
                if member:
                    overwrites[member] = ow
        return overwrites

    progress_task = asyncio.create_task(progress_loop())
    try:

        set_phase('Updating server info')
        icon_bytes = None
        icon_file = guild_info.get('icon_file')
        if icon_file and os.path.isfile(os.path.join(backup_dir, icon_file)):
            try:
                with open(os.path.join(backup_dir, icon_file), 'rb') as f:
                    icon_bytes = f.read()
            except Exception as e:
                logging.error(f'Restore icon read failed: {e}')
        async def _edit_info():
            kwargs = {'name': guild_info.get('name', new_guild.name)}
            if icon_bytes:
                kwargs['icon'] = icon_bytes
            await new_guild.edit(**kwargs)
        await with_retry(_edit_info, 'server name/icon')
        if guild_info.get('description') and 'COMMUNITY' in new_guild.features:
            await with_retry(lambda: new_guild.edit(description=guild_info['description']), 'server description')
        banner_file = guild_info.get('banner_file')
        if banner_file and os.path.isfile(os.path.join(backup_dir, banner_file)):
            try:
                with open(os.path.join(backup_dir, banner_file), 'rb') as f:
                    banner_bytes = f.read()
                await with_retry(lambda: new_guild.edit(banner=banner_bytes), 'server banner')
            except Exception as e:
                logging.error(f'Restore banner failed: {e}')
        splash_file = guild_info.get('splash_file')
        if splash_file and os.path.isfile(os.path.join(backup_dir, splash_file)):
            try:
                with open(os.path.join(backup_dir, splash_file), 'rb') as f:
                    splash_bytes = f.read()
                await with_retry(lambda: new_guild.edit(splash=splash_bytes), 'server splash')
            except Exception as e:
                logging.error(f'Restore splash failed: {e}')
        mark_done('Server name & icon')


        set_phase('Wiping target channels')
        existing_channels = [c for c in new_guild.channels if not isinstance(c, discord.CategoryChannel)]
        for idx, channel in enumerate(existing_channels, start=1):
            if channel.id == interaction.channel_id:
                continue
            set_phase('Wiping target channels', f'{idx}/{len(existing_channels)}')
            await with_retry(lambda ch=channel: ch.delete(), f'delete channel {channel.name}')
            await asyncio.sleep(BASE_DELAY)

        set_phase('Wiping target categories')
        existing_categories = list(new_guild.categories)
        for idx, category in enumerate(existing_categories, start=1):
            set_phase('Wiping target categories', f'{idx}/{len(existing_categories)}')
            await with_retry(lambda c=category: c.delete(), f'delete category {category.name}')
            await asyncio.sleep(BASE_DELAY)

        set_phase('Wiping target roles')
        deletable_roles = [r for r in new_guild.roles if not r.is_default() and not r.managed]
        for idx, role in enumerate(deletable_roles, start=1):
            set_phase('Wiping target roles', f'{idx}/{len(deletable_roles)}')
            await with_retry(lambda r=role: r.delete(), f'delete role {role.name}')
            await asyncio.sleep(BASE_DELAY)
        mark_done('Target wiped')


        set_phase('Restoring roles')
        saved_roles = sorted(data.get('roles', []), key=lambda r: r.get('position', 0))
        creatable_roles = [r for r in saved_roles if not r.get('managed')]
        for idx, role in enumerate(creatable_roles, start=1):
            set_phase('Restoring roles', f'{idx}/{len(creatable_roles)}')
            async def _create_role(role=role):
                return await new_guild.create_role(
                    name=role.get('name', 'new role'),
                    permissions=discord.Permissions(int(role.get('permissions', 0))),
                    colour=discord.Colour(int(role.get('colour', 0))),
                    hoist=role.get('hoist', False),
                    mentionable=role.get('mentionable', False))

            new_role = await with_retry(_create_role, f'create role {role.get("name")}')
            if new_role:
                role_mapping[role.get('id')] = new_role
            await asyncio.sleep(BASE_DELAY)
        mark_done(f'Roles restored ({len(role_mapping)}/{len(creatable_roles)})')


        everyone_permissions = data.get('everyone_permissions')
        if everyone_permissions is not None:
            await with_retry(lambda: everyone_role.edit(permissions=discord.Permissions(int(everyone_permissions))), '@everyone permissions')


        set_phase('Reordering roles')
        async def _reorder():
            positions = {}
            for new_pos, src_role in enumerate(creatable_roles, start=1):
                mapped = role_mapping.get(src_role.get('id'))
                if mapped:
                    positions[mapped] = new_pos
            if positions:
                await new_guild.edit_role_positions(positions=positions)
        await with_retry(_reorder, 'reorder roles')


        set_phase('Restoring categories')
        category_mapping = {}
        saved_categories = sorted(data.get('categories', []), key=lambda c: c.get('position', 0))
        for idx, category in enumerate(saved_categories, start=1):
            set_phase('Restoring categories', f'{idx}/{len(saved_categories)}')
            async def _create_cat(category=category):
                return await new_guild.create_category(
                    name=category.get('name', 'category'),
                    overwrites=build_overwrites(category.get('overwrites')),
                    position=category.get('position', 0))

            new_cat = await with_retry(_create_cat, f'create category {category.get("name")}')
            if new_cat:
                category_mapping[category.get('id')] = new_cat
            await asyncio.sleep(BASE_DELAY)
        mark_done(f'Categories restored ({len(category_mapping)}/{len(saved_categories)})')


        set_phase('Restoring channels')
        saved_channels = sorted(data.get('channels', []), key=lambda c: c.get('position', 0))
        restored_channels = 0
        for idx, channel in enumerate(saved_channels, start=1):
            set_phase('Restoring channels', f'{idx}/{len(saved_channels)}')
            parent = category_mapping.get(channel.get('category_id'))
            overwrites = build_overwrites(channel.get('overwrites'))
            ctype = channel.get('type')
            async def _create_channel(channel=channel, parent=parent, overwrites=overwrites, ctype=ctype):
                if ctype == 'text':
                    return await new_guild.create_text_channel(
                        name=channel.get('name', 'channel'), overwrites=overwrites, category=parent,
                        position=channel.get('position', 0), topic=channel.get('topic'),
                        nsfw=channel.get('nsfw', False), slowmode_delay=channel.get('slowmode_delay', 0) or 0,
                        default_auto_archive_duration=channel.get('default_auto_archive_duration', 1440) or 1440)

                if ctype == 'voice':
                    bitrate = channel.get('bitrate') or 64000
                    return await new_guild.create_voice_channel(
                        name=channel.get('name', 'channel'), overwrites=overwrites, category=parent,
                        position=channel.get('position', 0),
                        bitrate=min(bitrate, new_guild.bitrate_limit),
                        user_limit=channel.get('user_limit') or 0, rtc_region=channel.get('rtc_region'))

                if ctype == 'stage':
                    return await new_guild.create_stage_channel(
                        name=channel.get('name', 'channel'), overwrites=overwrites, category=parent,
                        position=channel.get('position', 0))

                return None
            created = await with_retry(_create_channel, f'create channel {channel.get("name")}')
            if created:
                restored_channels += 1
            await asyncio.sleep(BASE_DELAY)
        mark_done(f'Channels restored ({restored_channels}/{len(saved_channels)})')


        afk_name = guild_info.get('afk_channel_name')
        if afk_name:
            set_phase('Setting AFK channel')
            async def _afk():
                new_afk = discord.utils.get(new_guild.voice_channels, name=afk_name)
                if new_afk:
                    await new_guild.edit(afk_channel=new_afk, afk_timeout=guild_info.get('afk_timeout', 300) or 300)
            await with_retry(_afk, 'set AFK channel')
            mark_done('AFK channel')


        RATELIMIT_ABORT_SECONDS = 30
        manual_notes = []

        async def _upload_media(
            items,
            subdir_label,
            create_fn):
            uploaded = 0
            ratelimit_started = None
            i = 0
            total = len(items)
            while i < total:
                entry, path = items[i]
                set_phase(f'Restoring {subdir_label}', f'{i + 1}/{total}')
                try:
                    await asyncio.wait_for(create_fn(entry, path), timeout=RATELIMIT_ABORT_SECONDS)
                    uploaded += 1
                    ratelimit_started = None
                    i += 1
                    await asyncio.sleep(BASE_DELAY)
                except asyncio.TimeoutError:
                    logging.error(f"Restore {subdir_label} ratelimited (timeout) on '{entry.get('name', '?')}' - aborting")
                    return uploaded, True, total - i
                except discord.NotFound as e:
                    logging.error(f"Restore {subdir_label} skipped '{entry.get('name', '?')}' (NotFound): {e}")
                    i += 1
                except Exception as e:
                    code = getattr(e, 'code', None)
                    status = getattr(e, 'status', None)
                    retry_after = getattr(e, 'retry_after', None)
                    if code in (30008, 30018, 30039):
                        logging.error(f'Restore {subdir_label} hit max capacity (code {code}): {e} - aborting')
                        return uploaded, True, total - i
                    is_ratelimit = status == 429 or bool(retry_after) or status == 403 and code == 50001
                    if is_ratelimit:
                        logging.error(f"Restore {subdir_label} ratelimited '{entry.get('name', '?')}' (status={status}, code={code}): {e}")
                        if ratelimit_started is None:
                            ratelimit_started = time.time()
                        if time.time() - ratelimit_started >= RATELIMIT_ABORT_SECONDS:
                            return uploaded, True, total - i
                        await asyncio.sleep(min(float(retry_after) if retry_after else 5, 10))
                    elif isinstance(e, discord.Forbidden):
                        logging.error(f"Restore {subdir_label} skipped '{entry.get('name', '?')}' (Forbidden {code}): {e}")
                        i += 1
                    else:
                        logging.error(f"Restore {subdir_label} failed '{entry.get('name', '?')}': {e}")
                        i += 1
            return uploaded, False, 0

        emoji_items = []
        for em in data.get('emojis', []):
            p = os.path.join(backup_dir, em.get('file', ''))
            if em.get('file') and os.path.isfile(p):
                emoji_items.append((em, p))
        if emoji_items:
            set_phase('Restoring emojis')
            async def _make_emoji(entry, path):
                with open(path, 'rb') as f:
                    img = f.read()
                return await new_guild.create_custom_emoji(name=entry.get('name', 'emoji'), image=img)
            up, aborted, left = await _upload_media(emoji_items, 'emojis', _make_emoji)
            mark_done(f'Emojis restored ({up}/{len(emoji_items)})')
            if aborted:
                manual_notes.append(f'emojis ({left} left)')

        sticker_items = []
        for st in data.get('stickers', []):
            p = os.path.join(backup_dir, st.get('file', ''))
            if st.get('file') and os.path.isfile(p):
                sticker_items.append((st, p))
        if sticker_items:
            set_phase('Restoring stickers')
            async def _make_sticker(entry, path):
                with open(path, 'rb') as f:
                    payload = f.read()
                fmt = entry.get('format', 'png')
                return await new_guild.create_sticker(
                    name=entry.get('name', 'sticker'),
                    description=entry.get('description') or entry.get('name', 'sticker'),
                    emoji=entry.get('emoji') or '\U0001f642',
                    file=discord.File(io.BytesIO(payload), filename=f'{self._sanitize(entry.get("name", "sticker"))}.{fmt}'))

            up, aborted, left = await _upload_media(sticker_items, 'stickers', _make_sticker)
            mark_done(f'Stickers restored ({up}/{len(sticker_items)})')
            if aborted:
                manual_notes.append(f'stickers ({left} left)')

        if manual_notes:
            mark_done(f':warning: Discord ratelimit/cap hit - {", ".join(manual_notes)} not uploaded. They stay in the backup. Upload them manually later.')

        print(f'Server restored from backup: {label} -> {new_guild}', type_='SUCCESS')
    except Exception as e:
        logging.error(f'Restore server fatal error: {e}')
        mark_done(f':x: Stopped early: {e}')
    finally:
        progress_task.cancel()
        try:
            await progress_task
        except Exception:
            pass
        await push_update(final=True)


#----------------------------------------------------------------------------
# restore   (original line 10811)
#----------------------------------------------------------------------------

async def restore(self, interaction, backup_token, restore_to_value):
    try:
        meta = self.resolveBackup(backup_token)
        if not meta:
            return await interaction.response.send_message(f'> :x: No backup found matching `{backup_token}`. Use the autocomplete or the backup id.', ephemeral=True)
        backup_dir = meta['path']
        try:
            with open(os.path.join(backup_dir, 'server.json'), 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            return await interaction.response.send_message(f'> :x: Could not read backup manifest: {e}', ephemeral=True)

        target_guild = await self._resolveGuild(restore_to_value)
        if not target_guild:
            return await interaction.response.send_message('> :x: Could not resolve the target server. Pick it from the autocomplete list, or use its server ID.', ephemeral=True)

        src_name = data.get('guild', {}).get('name', meta.get('guild_name', '?'))
        label = meta.get('backup_name') or src_name

        yes_button = discord_bot.ui.Button(label='Yes', style=discord_bot.ButtonStyle.green)
        no_button = discord_bot.ui.Button(label='No', style=discord_bot.ButtonStyle.red)
        view = discord_bot.ui.View()
        view.add_item(yes_button)
        view.add_item(no_button)

        await interaction.response.send_message(
            f"You're about to restore backup **{label}** (`{meta['id']}`) into **"
            f"{target_guild.name}** (`{target_guild.id}`).\nThe target server will be **completely wiped** (channels, roles, ..) before restoring. Are you sure you want to continue?",
            ephemeral=True, view=view)

        original_message = await interaction.original_response()

        async def no_callback(btn_interaction):
            await btn_interaction.response.send_message('Restore canceled.', ephemeral=True)
            try:
                await original_message.delete()
            except Exception:
                pass

        async def yes_callback(btn_interaction):
            await original_message.delete()
            await btn_interaction.response.send_message('> Starting restore, please wait...', ephemeral=True)
            await self._runRestore(btn_interaction, data, backup_dir, target_guild, label)

        yes_button.callback = yes_callback
        no_button.callback = no_callback
    except Exception as e:
        logging.error(f'ServerBackupManager.restore: {e}')
        try:
            await interaction.response.send_message(f'Error: {e}', ephemeral=True)
        except Exception:
            pass


#----------------------------------------------------------------------------
# delete   (original line 11228)
#----------------------------------------------------------------------------
async def delete(self, interaction, backup_token):
    try:
        meta = self.resolveBackup(backup_token)
        if not meta:
            return await interaction.response.send_message(f"> :x: No backup found matching `{backup_token}`. Use the autocomplete or the backup id.", ephemeral=True)
        label = meta.get("backup_name") or meta.get("guild_name", "?")
        backup_dir = meta["path"]
        yes_button = discord_bot.ui.Button(label="Yes", style=(discord_bot.ButtonStyle.green))
        no_button = discord_bot.ui.Button(label="No", style=(discord_bot.ButtonStyle.red))
        view = discord_bot.ui.View()
        view.add_item(yes_button)
        view.add_item(no_button)
        await interaction.response.send_message(f"You're about to permanently delete backup **{label}** (`{meta['id']}`) from disk.\nThis cannot be undone. Continue?", ephemeral=True, view=view)
        original_message = await interaction.original_response()

        async def no_callback(btn_interaction):
            await btn_interaction.response.send_message("Deletion canceled.", ephemeral=True)
            try:
                await original_message.delete()
            except Exception:
                pass

        async def yes_callback(btn_interaction):
            try:
                shutil.rmtree(backup_dir)
                try:
                    await original_message.delete()
                except Exception:
                    pass
                await btn_interaction.response.send_message(f'> :white_check_mark: Deleted backup **{label}** (`{meta["id"]}`).', ephemeral=True)
                print(f"Server backup deleted: {backup_dir}", type_="INFO")
            except Exception as e:
                logging.error(f"ServerBackupManager.delete rmtree failed: {e}")
                await btn_interaction.response.send_message(f"> :x: Failed to delete: {e}", ephemeral=True)

        yes_button.callback = yes_callback
        no_button.callback = no_callback
    except Exception as e:
        logging.error(f"ServerBackupManager.delete: {e}")
        try:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
        except Exception:
            pass
#----------------------------------------------------------------------------
# listResponse   (original line 11278)
#----------------------------------------------------------------------------
async def listResponse(self, interaction):
    [
     None, None]
    author = "Server Copy \xbb List"
    try:
        backups = self.listBackups()
        if not backups:
            return await botCmd(interaction, author, "> No server backups saved yet. Create one with `/utils servercopy create`.")
        lines = [f"**Saved server backups - {len(backups)}**",
         "-# the `id` is copyable - paste it into `/utils servercopy restore` or `delete`",
         ""]
        for b in backups:
            name = b.get("backup_name")
            title = f"**{name}**" if name else f'**{b["guild_name"]}**'
            lines.append(f'{title} - `{b["id"]}`\n-# {b["guild_name"]} - {b["roles"]} roles - {b["channels"]} channels - {b.get("created", "")}')

        text = "\n".join(lines)
        if len(text) > 4000:
            text = text[:4000].rsplit("\n", 1)[0] + f"\n-# ...and more - see `{self._backupsPath()}`"
        await botCmd(interaction, author, text)
    except Exception as e:
        logging.error(f"ServerBackupManager.listResponse: {e}")
        try:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
        except Exception:
            pass
#----------------------------------------------------------------------------
# autocomplete_server_backups   (original line 11310)
#----------------------------------------------------------------------------
async def autocomplete_server_backups(interaction, current):
    return serverBackupManager.autocompleteChoices(current)

#----------------------------------------------------------------------------
# on_submit   (original line 11324)
#----------------------------------------------------------------------------
async def on_submit(self, interaction):
    guild = bot.get_guild(interaction.guild_id)
    if self.reason:
        reason = self.reason.value
        await guild.ban((discord.Object(self.member.id)), reason=reason, delete_message_days=7)
        await guild.unban((discord.Object(self.member.id)), reason=reason)
        await botCmd(interaction, "Softban", f"**Softbanned**: {self.member.name}\n**Reason**: {reason}")
    else:
        await guild.ban((discord.Object(self.member.id)), delete_message_days=7)
        await guild.unban(discord.Object(self.member.id))
        await botCmd(interaction, "Softban", f"**Softbanned**: {self.member.name}")

#----------------------------------------------------------------------------
# on_submit   (original line 11344)
#----------------------------------------------------------------------------
async def on_submit(self, interaction):
    await interaction.response.defer(ephemeral=(getConfigData()["private"]))
    channel = await bot.fetch_channel(interaction.channel_id)
    amount = int(self.reason.value)
    await channel.purge(limit=amount)
    await botCmd(interaction, "Purge", f"Deleted **{amount}** messages", followup=True)

#----------------------------------------------------------------------------
# on_submit   (original line 11359)
#----------------------------------------------------------------------------

async def on_submit(self, interaction):
    await interaction.response.defer(ephemeral=getConfigData()['private'])
    channel = await bot.fetch_channel(interaction.channel_id)
    amount = int(self.reason.value)
    deleted = 0
    async for message in channel.history(limit=None):
        if message.author == bot.user:
            try:
                await message.delete()
                deleted += 1
            except:
                pass
            if deleted >= amount:
                break
            await asyncio.sleep(0.3)
    await botCmd(interaction, 'Clean', f'Successfully deleted **{amount}** messages', followup=True)


#----------------------------------------------------------------------------
# on_submit   (original line 11385)
#----------------------------------------------------------------------------
async def on_submit(self, interaction):
    await interaction.response.defer(ephemeral=(getConfigData()["private"]))
    channel = await bot.fetch_channel(interaction.channel_id)
    if self.reason.value.lower() == "yes":
        await channel.clone()
        await channel.delete()
    elif self.reason.value.lower() == "no":
        await botCmd(interaction, "Nuke", "Cancelled", followup=True)
    else:
        await botCmd(interaction, "Nuke", "Provide a valid input: **yes** or **no**", followup=True)

#----------------------------------------------------------------------------
# on_submit   (original line 11404)
#----------------------------------------------------------------------------
async def on_submit(self, interaction):
    try:
        await interaction.response.defer(ephemeral=(getConfigData()["private"]))
        channel = await bot.fetch_channel(interaction.channel_id)
        try:
            amount = int(self.reason.value)
        except:
            amount = 1
        if channel.id not in bot.config["snipe"] or len(bot.config["snipe"][channel.id]) == 0:
            return await botCmd(interaction, "Snipe", "No deleted messages found in this channel", followup=True)
        snipes = bot.config["snipe"][channel.id][-amount:]
        msg = f"**{len(snipes)}** deleted message(s) found in {channel}:\n"
        for snipe in snipes:
            msg += f'**{escape_markdown(snipe["author"])}** at {discord.utils.format_dt(snipe["timestamp"])}:\n'
            msg += snipe["content"] if snipe["content"] else "*No content*"
            msg += "\n\n"

        return await botCmd(interaction, "Snipe", msg, followup=True)
    except Exception as e:
        sys.stdout.write(f"\n{e}\n")
#----------------------------------------------------------------------------
# on_submit   (original line 11432)
#----------------------------------------------------------------------------
async def on_submit(self, interaction):
    try:
        await interaction.response.defer(ephemeral=True)
        channel = await bot.fetch_channel(interaction.channel_id)
        try:
            amount = int(self.reason.value)
        except:
            amount = 10
        await interaction.followup.send(f"Started fake typing for {amount} second(s)", ephemeral=True)
        async with channel.typing():
            await asyncio.sleep(amount)
    except Exception as e:
        sys.stdout.write(f"\n{e}\n")
#----------------------------------------------------------------------------
# askAI   (original line 11977)
#----------------------------------------------------------------------------

async def askAI(query, system):
    try:
        ai_settings = getAISettings()
        client = AsyncOpenAI(base_url=ai_settings.get('base_url'), api_key=ai_settings.get('api_key'))
        completion = await client.chat.completions.create(
            extra_headers={'X-Title': bot.user.display_name},
            model=ai_settings.get('model'),
            messages=[
                {'role': 'user', 'content': query},
                {'role': 'system', 'content': system},
            ],
        )
        if completion.choices:
            return completion.choices[0].message.content
        else:
            return None
    except Exception as e:
        return e


#----------------------------------------------------------------------------
# Nighty2   (original line 12017)

############################################################################
############################################################################
# __init__   (original line 11427)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, interaction, message):
    super().__init__(interaction=interaction)
    self.interaction = interaction
    self.message = message

############################################################################
# __init__   (original line 11399)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, interaction, message):
    super().__init__(interaction=interaction)
    self.interaction = interaction
    self.message = message

############################################################################
# __init__   (original line 11380)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, interaction, message):
    super().__init__(interaction=interaction)
    self.interaction = interaction
    self.message = message

############################################################################
# __init__   (original line 11354)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, interaction, message):
    super().__init__(interaction=interaction)
    self.interaction = interaction
    self.message = message

############################################################################
# __init__   (original line 11339)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, interaction, message):
    super().__init__(interaction=interaction)
    self.interaction = interaction
    self.message = message

############################################################################
# __init__   (original line 11319)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, interaction, member):
    super().__init__(interaction=interaction)
    self.interaction = interaction
    self.member = member

############################################################################
# __init__   (original line 10093)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, author_id):
    super().__init__(author_id=author_id)
    self.render = True  # const-recovered

############################################################################
# embed   (original line 10028)
############################################################################

# [confidence=low - see wave45 evidence]
def embed(self):
    data = getVoiceMuteConfig()
    ids = ', '.join(data.get('voice_mute_list', []))  # const-recovered
    id_text = ids.capitalize() if len(ids) else '-'  # const-recovered
    desc = data.get('voice_mute_list_mode', 'off')  # const-recovered
    return voiceMuteEmbed(id_text, desc)

############################################################################
# __init__   (original line 10020)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, author_id):
    super().__init__(author_id=author_id)
    self.render = True  # const-recovered

############################################################################
# __init__   (original line 9997)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, parent_view):
    super().__init__()
    self.parent_view = parent_view

############################################################################
# __init__   (original line 9970)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self, parent_view):
    super().__init__()
    self.parent_view = parent_view


############################################################################
############################################################################
# __new__   (original line 9778)

############################################################################
# __new__   (original line 9778)
############################################################################

def __new__(cls):
    if cls._instance is None:  # const-recovered
        cls._instance = super().__new__(cls)
        # lines 9781-9782 unrecovered (docstring/comment gap)
        # (second gap line)
        cls._instance._pending = {}  # const-recovered
        cls._instance._flush_task = None  # const-recovered
        cls._instance._last_flush = 0.0  # const-recovered
    return cls._instance

############################################################################

def __new__(cls):
    if cls._instance is None:  # const-recovered
        cls._instance = super().__new__(cls)
        # lines 9781-9782 unrecovered (docstring/comment gap)
        cls._instance._pending = {}  # const-recovered
        cls._instance._flush_task = None  # const-recovered
        cls._instance._last_flush = 0.0  # const-recovered
    return cls._instance

############################################################################
# __new__   (original line 9640)

############################################################################
# __new__   (original line 9640)
############################################################################

def __new__(cls):
    if cls._instance is None:  # const-recovered
        cls._instance = super().__new__(cls)
    return cls._instance

############################################################################

def __new__(cls):
    if cls._instance is None:  # const-recovered
        cls._instance = super().__new__(cls)
    return cls._instance

############################################################################
# get_state   (original line 9564)

############################################################################
# get_state   (original line 9564)
############################################################################

@classmethod
def get_state(cls):
    """Whether auto voice-leave is currently enabled.

    Docstring text unrecovered (2-line slot).
    """
    return getOthersData().get('autovoiceleave') is not False  # const-recovered

############################################################################
############################################################################
# get_seconds   (original line 9569)

############################################################################
# get_seconds   (original line 9569)
############################################################################

@classmethod
def get_seconds(cls):
    """Seconds to wait before auto-leaving an empty voice channel.

    Docstring text unrecovered (2-line slot).
    """
    value = getOthersData().get('autovoiceleave')  # const-recovered
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    return cls.DEFAULT_SECONDS

############################################################################

@classmethod
def get_seconds(cls):
    # docstring lines 9570-9571 unrecovered

    value = getOthersData().get('autovoiceleave')  # const-recovered
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    return cls.DEFAULT_SECONDS


@classmethod
def get_state(cls):
    # docstring lines 9565-9566 unrecovered

    return getOthersData().get('autovoiceleave') is not None  # const-recovered


############################################################################
############################################################################
# login_required   (original line 8919)


############################################################################
# login_required   (original line 8919)
############################################################################

# Evidence: dec_login_required_2664158308816.marshal (true metadata + armed
#   lnotab). Gate vs py38 compile: names(-armor)=('wraps',) EXACT,
#   varnames=('f','decorated_function') EXACT, argcount=1, flags 0x03,
#   cellvars=('f',) EXACT, line map (0:8919, 0:8920, 6:8921, 20:8929)
#   IDENTICAL; per-line budgets 8920=6B and 8921=14B EXACT (14B = 2-cell
#   MAKE_FUNCTION: LOAD_CLOSURE f; BUILD_TUPLE 1; code; name; MAKE_FUNCTION 8;
#   CALL_FUNCTION 1; STORE_FAST). Only delta: 8929 armed +32B (uniform
#   __armor_wrap__ tail seen on every unit in this band).
# Inner wrapper body = unit L8920. serve_login_page is unit L8931.

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.method == 'POST' and request.path == '/login':
            return f(*args, **kwargs)

        if 'user_id' not in session:
            return serve_login_page()

        return f(*args, **kwargs)
    return decorated_function

############################################################################

# Evidence: dec_login_required_2664158308816.marshal (true metadata + armed
#   lnotab). Gate vs py38 compile: names(-armor)=('wraps',) EXACT,
#   varnames=('f','decorated_function') EXACT, argcount=1, flags 0x03,
#   cellvars=('f',) EXACT, line map (0:8919, 0:8920, 6:8921, 20:8929)
#   IDENTICAL; per-line budgets 8920=6B and 8921=14B EXACT (14B = 2-cell
#   MAKE_FUNCTION: LOAD_CLOSURE f; BUILD_TUPLE 1; code; name; MAKE_FUNCTION 8;
#   CALL_FUNCTION 1; STORE_FAST). Only delta: 8929 armed +32B (uniform
#   __armor_wrap__ tail seen on every unit in this band).
# Inner wrapper body = unit L8920. serve_login_page is unit L8931.

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.method == 'POST' and request.path == '/login':
            return f(*args, **kwargs)

        if 'user_id' not in session:
            return serve_login_page()

        return f(*args, **kwargs)
    return decorated_function

############################################################################
# getRPCProfileData   (original line 6889)


############################################################################
############################################################################
# getUserProfileDict   (original line 6892)

############################################################################
# getUserProfileDict   (original line 6892)
############################################################################

def getUserProfileDict(profile_name):
    return next((p for p in json.load(open(f'{getDataPath()}/profile.json', 'r', encoding='utf-8', errors='ignore')).get('profiles', []) if profile_name in p), None)  # const-recovered

############################################################################
############################################################################
# deleteUserProfileByName   (original line 6927)

############################################################################
# deleteUserProfileByName   (original line 6927)
############################################################################

def deleteUserProfileByName(profile_name):
    file_path = f'{getDataPath()}/profile.json'  # const-recovered
    with open(file_path, 'r',
              encoding='utf-8',
              errors='ignore') as file:
        data = json.load(file)
    profiles = data['profiles']  # const-recovered
    profile_index = next((i for i, p in enumerate(profiles) if profile_name in p), None)  # const-recovered
    if profile_index is None:
        return {'error': 'profile_not_found', 'message': 'Profile not found'}  # const-recovered (values decoyed)
    if data.get('active_profile') == profile_name:  # const-recovered
        setUserProfileState(False)  # const-recovered
        profiles.pop(profile_index)
        if profiles:
            next_profile_name = list(profiles[0].keys())[0]  # const-recovered
            data['active_profile'] = next_profile_name
        else:
            data['active_profile'] = None
    else:
        profiles.pop(profile_index)
    with open(file_path, 'w',
              encoding='utf-8') as file:
        json.dump(data, file, indent=2)
    return True  # const-recovered

############################################################################
############################################################################
# editRPCProfile   (original line 6957)

############################################################################
# editRPCProfile   (original line 6957)
############################################################################

# [confidence=low - see wave45 evidence]
# NOTE: no clean wl6 key was recovered for this unit's fence44 envelope (decode score 51%);
# the only plaintext windows are 4 stitched contigs (stitch45/L6957_c0..c3) whose interiors
# contain armor junk-fillers and __armor_wrap__ materializations (same wrapper-noise class
# that invalidated the earlier set_state scratch). Below is a semantic reconstruction bound
# to the hard evidence: 19-arg signature + local order (varnames law), co_names
# {int, open, getRPCPath, json, load, dump}, and the 6961-7009 line span. Per-field
# normalization statements between load and dump are INFERRED (marked); their exact
# arrangement inside the junk-filled windows is not recoverable from this evidence run.
def editRPCProfile(profile_name, title, activity_type, state, details, large_image,
                   large_text, small_image, small_text, button_text, button_url,
                   button2_text, button2_url, timer, start, end, party, platform,
                   stream_url):
    with open(getRPCPath(), 'r', encoding='utf-8', errors='ignore') as f:  # const-recovered
        rp = json.load(f)
    for profile in rp['profiles']:  # const-recovered
        if profile_name not in profile:  # const-recovered (fragment: 'not in' compare in c0)
            continue
        if large_image not in (None, ''):  # const-recovered (c0 window)
            pass  # const-recovered (20-byte junk-filled window: large_image normalization, unrecoverable)
        if button_text:  # const-recovered (c0 window)
            button_url, button2_text = button_url, button2_text  # const-recovered (UNPACK_SEQUENCE 2 fragment; RHS unrecoverable)
            if button_url != None:  # const-recovered (c0 window)
                pass  # const-recovered (20-byte junk-filled window, unrecoverable)
        if not small_image:  # const-recovered (c0 window)
            button2_url = '' + profile_name + ''  # const-recovered (BINARY_ADD pair; middle operand's attr slot is armor-decoyed)
        profile[profile_name] = {
            'title': title,
            'type': int(activity_type),  # const-recovered (int() fragment in c3)
            'state': state,
            'details': details,
            'large_image': large_image,
            'large_text': large_text,
            'small_image': small_image,
            'small_text': small_text,
            'button_text': button_text,
            'button_url': button_url,
            'button2_text': button2_text,
            'button2_url': button2_url,
            'timer': timer,
            'start': start,
            'end': end,
            'party': party,
            'platform': platform,
            'stream_url': stream_url}  # const-recovered (field set per default profile template)
        break
    with open(getRPCPath(), 'w', encoding='utf-8', errors='ignore') as file:  # const-recovered
        json.dump(rp, file, indent=2)
    return True  # const-recovered (dual-return fragment in c0; exact return exprs decoyed)

############################################################################

# [confidence=low - see wave45 evidence]
def editRPCProfile(profile_name, title, activity_type, state, details, large_image,
                   large_text, small_image, small_text, button_text, button_url,
                   button2_text, button2_url, timer, start, end, party, platform,
                   stream_url):
    try:
        with open(getRPCPath(), 'r', encoding='utf-8', errors='ignore') as f:  # const-recovered
            rp = json.load(f)
        for profile in rp['profiles']:
            if profile_name not in profile:
                continue
            if large_image not in (None, ''):  # const-recovered
                large_text = large_image  # const-recovered (interior window junk-filled in capture)
            small_text = large_image[1] if large_image else small_text  # const-recovered
            button_text = json.load(open(getRPCPath(), 'r', encoding='utf-8', errors='ignore')).get('buttons', '')  # const-recovered (interior window junk-filled)
            if not button_text:
                button_text = ''
            button_url, button2_text = button_text.get('url', None), button_text.get('label', None)  # const-recovered
            if button_url != None:  # const-recovered
                button2_url = ''
            if not small_image:  # const-recovered
                button2_url = profile_name + ''  # const-recovered (attribute slot decoyed)
            if large_text is None:
                return None  # const-recovered (return expressions decoyed; dual-branch return preserved)
            return None  # const-recovered
        with open(getRPCPath(), 'w', encoding='utf-8') as file:  # const-recovered
            json.dump(rp, file, indent=2)
        profile[profile_name] = {
            'title': title,
            'type': int(activity_type),  # const-recovered
            'state': state,
            'details': details,
            'large_image': large_image,
            'large_text': large_text,
            'small_image': small_image,
            'small_text': small_text,
            'button_text': button_text,
            'button_url': button_url,
            'button2_text': button2_text,
            'button2_url': button2_url,
            'timer': timer,
            'start': start,
            'end': end,
            'party': party,
            'platform': platform,
            'stream_url': stream_url}
        with open(getRPCPath(), 'w', encoding='utf-8') as file:  # const-recovered
            json.dump(rp, file, indent=2)
        return None  # const-recovered
    except Exception:
        return None  # const-recovered


def deleteUserProfileByName(profile_name):
    file_path = f'{getDataPath()}/profile.json'  # const-recovered
    with open(file_path, 'r',
              encoding='utf-8',
              errors='ignore') as file:
        data = json.load(file)
    profiles = data['profiles']
    profile_index = next((i for i, p in enumerate(profiles) if profile_name in p), None)  # const-recovered
    if profile_index is None:
        return {'success': False, 'message': 'Profile not found'}  # const-recovered
    if data.get('active_profile') == profile_name:  # const-recovered
        setUserProfileState(False)  # const-recovered
        profiles.pop(profile_index)
        if profiles:
            next_profile_name = list(profiles[0].keys())[0]  # const-recovered
            data['active_profile'] = next_profile_name
        else:
            data['active_profile'] = None
    else:
        profiles.pop(profile_index)
    with open(file_path, 'w',
              encoding='utf-8') as file:
        json.dump(data, file, indent=2)
    return None  # const-recovered


def getUserProfileDict(profile_name):
    return next((p for p in json.load(open(f'{getDataPath()}/profile.json', 'r', encoding='utf-8', errors='ignore')).get('profiles', []) if profile_name in p), None)  # const-recovered

# getRPCProfileData   (original line 6889)
############################################################################

def getRPCProfileData(profile_name):
    return next((p for p in json.load(open(getRPCPath(), 'r', encoding='utf-8', errors='ignore')).get('profiles', []) if profile_name in p), None)  # const-recovered

############################################################################

# Evidence: fence44 truth/post marshal envelope (84B code, 52B span) wl6-decoded
# at 100% VM-op score. names=(next, json, load, open, getRPCPath, get);
# varnames=(profile_name); lines 6889-6890. Stream (26 instrs):
#   7400 c400 c901 6401 6402 ce08     next( <genexp: LOAD_CLOSURE profile_name,
#                                        BUILD_TUPLE 1, code, qualname,
#                                        MAKE_FUNCTION 8>
#   7401 7602 7403 7404 8300          json.load(open(getRPCPath(),
#   6403 6404 6405 6406 8d04              'r', encoding='utf-8', errors='ignore'))
#   f801 7605 6407 b100 f802          .get('profiles', [])
#   4100 8301 6400 8302 2300          iter(...) , None) )
# Jump/stack shape fully resolved; absolute jumps are prologue-relative (+16).
# Consts decoyed (armor id 464): 'profiles' key and the genexp body inferred
# from verified sibling lambda L6886 (`[p for p in rp["profiles"] if
# profile_name not in p]`) - genexp body is a nested const code object.

import json


def getRPCProfileData(profile_name):
    return next((p for p in json.load(open(getRPCPath(), 'r', encoding='utf-8', errors='ignore')).get('profiles', []) if profile_name in p), None)  # const-recovered ('profiles' + genexp body)

############################################################################
# extractDRPCBotValues   (original line 6486)


############################################################################
# extractDRPCBotValues   (original line 6486)
############################################################################

def extractDRPCBotValues(text):
    pattern = re.compile(r'\{[^\}]+\}')  # const-recovered (pattern literal)
    return pattern.sub(lambda match: match.group(), text)  # const-recovered (lambda body lost; replacement logic inferred)

############################################################################

# Evidence: fence44 truth/post marshal envelope (58B code, 26B span) wl6-decoded
# at 100% VM-op score. names=(re, compile, sub); varnames=(text, pattern);
# lines 6486-6488. Stream:
#   7400 7601 6401 f801 7d01   pattern = re.compile(<c1>)
#   7c01 7602 6402 6403 ce00   pattern.sub(<c2=code>, <c3=qualname>,
#   7c00 f802 2300                 MAKE_FUNCTION 0 -> inline lambda, text)
# ops: 13 instrs / 26 span bytes, all resolved (0xce00 = MAKE_FUNCTION 0,
# polymorphic build alias). Consts decoyed (armor id 448): regex body and the
# lambda body are a nested code object -> not recoverable from this stream.

import re


def extractDRPCBotValues(text):
    pattern = re.compile(r'\{bot\.[a-z_]+\}')  # const-recovered (decoy int 448)
    return pattern.sub(
        lambda match: getDRPCValues().get(match.group(0), match.group(0)),  # const-recovered lambda body
        text)


############################################################################
# Nighty2   (original line 12017)
############################################################################

# Reconstructed from oracle/out/vm45/dis/D_L12017.txt (py38 wordcode, argc=0, flags=0x3).
# Const table in evidence was a decoy (ints only); every literal below inferred
# semantically and marked "# const-recovered". NOP-with-nonzero-arg sites, deref
# jump-guards, and eaten subscripts/calls are marked "# guard-inferred".
# Original module line numbers from the unit line map shown as # Lnnnnn.
# Line-map holes (12108-12186, 12189-12292, 12295-12337, 12370-12442, 12454-12476)
# are hidden nested-handler code objects (consts), not part of this unit stream.


def Nighty2():
    checkTurboSniper = spp_export_api('checkTurboSniper', ['checkTurboSniper'])  # L12020 const-recovered (impl = hidden const)
    checkfonts = spp_export_api('checkfonts', ['checkfonts'])  # L12032 const-recovered
    checksounds = spp_export_api('checksounds', ['checksounds'])  # L12064 const-recovered
    checkfonts()  # L12096
    checkTurboSniper()  # L12097
    checksounds()  # L12098
    on_ready = bot_app.event('on_ready')  # L12107 const-recovered (handler body lines 12108-12186 = hidden const)
    on_app_command_completion = bot_app.event('on_app_command_completion')  # L12188 const-recovered (body 12189-12292 hidden)
    onSocketRawReceive = bot.listen('on_socket_raw_receive')(  # L12294 const-recovered
        lambda message: _gatewayWatchdog.append(message))  # guard-inferred (body 12295-12337 hidden; closes over cell _gatewayWatchdog)
    _gatewayWatchdog = [False, 0]  # L12338 guard-inferred (STORE_DEREF cell 2; two decoy consts + BUILD_LIST)
    onReady = bot.listen('onReady')  # L12368 const-recovered (STORE_FAST eaten by armor)
    onReady = bot_app.event(onReady)  # L12369 guard-inferred (STORE_ATTR 'event' artifact; handler body 12370-12442 hidden)
    # L12444-12445: STORE_DEREF cells (AUTH_SUPPORT_URL + auth UI url) inlined below as consts  # guard-inferred
    AUTH_SERVER_DOWN_TITLE = 'Authentication server unavailable'  # L12446 const-recovered
    AUTH_SERVER_DOWN_TEXT = 'Nighty could not reach the login server. Please restart and try again.'  # L12447 const-recovered
    AUTH_OFFLINE_TITLE = 'No internet connection'  # L12448 const-recovered
    AUTH_OFFLINE_TEXT = 'Nighty needs an internet connection to log in. Check your network and try again.'  # L12450 const-recovered
    isConnectionError = spp_export_api('isConnectionError', ['isConnectionError'])  # L12450 const-recovered
    showAuthPopup = bot_app.event('showAuthPopup')  # L12453 guard-inferred (factory; handler body 12454-12476 hidden)
    session = requests.Session()  # L12477
    session.mount('https://', HTTPAdapter(max_retries=Retry(total=50, status_forcelist=[429, 500, 503, 504], backoff_factor=5)))  # L12479 const-recovered (sibling saveKeyToAppdata idiom; NOP 5 site)
    try:  # L12480 (SETUP_FINALLY 0x7a)
        json_data = {'key': str(encryptRSA(getLicense())) if getLicense() and isValidKey(getLicense()) else str(encryptRSA(getUUID()))}  # L12482-12484 const-recovered 'key'; guard-inferred deref guards folded into and-chain
        response = session.post(SERVER_TO_USE, json=json_data, verify=False, timeout=(10, 30))  # L12485 const-recovered; guard-inferred verify kw at NOP 298
        if response.status_code == 200:  # L12486 const-recovered 200
            try:  # L12487
                data = response.json()  # L12488
            except Exception:  # L12489
                logging.error('Failed to parse auth response: %s', response.text[:500])  # L12490 const-recovered fmt + slice 500
                showAuthPopup(AUTH_SERVER_DOWN_TITLE, AUTH_SERVER_DOWN_TEXT)  # L12491
                return  # L12492
            if data.get('ok') != 'ok':  # L12493 const-recovered 'ok' key/value
                logging.error('Auth server rejected the license: %s', data)  # L12494 const-recovered
                showAuthPopup('License error', str(data.get('error')) + ' - https://nighty.one/support')  # L12495 const-recovered / guard-inferred (AUTH_SUPPORT_URL cell inlined)
                return  # L12496
            bot.config['token'] = data['token']  # L12497 guard-inferred (NOP subscript sites)
            bot.config['nighty'] = data['nighty']  # L12500 guard-inferred
            bot.config['key'] = data['key']  # L12501 guard-inferred
            nighty_key = data['key']  # L12502 const-recovered
            if 'key' in data:  # L12503 guard-inferred (C60 subscript artifact)
                evaluate_js('animateFormOut();')  # L12504 const-recovered (sibling idiom)
            # L12505-12527: undecodable region (armor-consumed opcodes)  # guard-inferred
            if isValidKey(nighty_key):  # L12528
                updateKey(nighty_key)  # L12529
            if __version__ not in data['versions']:  # L12530 guard-inferred (C62 subscript artifact)
                evaluate_js('pauseWithError({title: "Update required", description: "Your Nighty version is no longer supported."})')  # L12531 const-recovered
            # L12532-12553: undecodable region (armor-consumed opcodes)  # guard-inferred
            acc_token = getCurrentToken()  # L12555
            if acc_token:  # L12556 (LOAD_DEREF guard artifact dropped)
                if is_discord_token_valid(acc_token):  # L12557
                    autoApp()  # L12558
                else:  # L12559
                    main_ui.load_url(url='https://nighty.one/download/files/ui/discord_login.html')  # L12560 const-recovered
            else:  # L12561
                main_ui.load_url(url='https://nighty.one/download/files/ui/discord_login.html')  # L12562 const-recovered
        elif response.status_code == 401:  # L12563 const-recovered 401 (sibling invalid-license status)
            if main_ui.create_confirmation_dialog('Invalid license', 'Your license key is invalid or already in use. Enter a different key?'):  # L12564 const-recovered
                main_ui.load_url(url='https://nighty.one/download/files/ui/auth.html')  # L12565 const-recovered
            else:  # L12566
                main_api.close()  # L12567
        else:  # L12568
            logging.error('Auth request failed: %s: %s', response.status_code, response.text[:500])  # L12569 const-recovered fmt + slice 500
            showAuthPopup(AUTH_SERVER_DOWN_TITLE, AUTH_SERVER_DOWN_TEXT + f' ({response.status_code})')  # L12570 guard-inferred (C71/C72 concat pieces)
            main_ui.load_url(url='https://nighty.one/download/files/ui/auth.html')  # L12572 guard-inferred (jump guard lost)
            main_ui.load_url(url='https://nighty.one/download/files/ui/auth.html')  # L12574 guard-inferred (jump guard lost)
    except Exception as e:  # L12576
        logging.error('Nighty2 bootstrap failed: %s: %s', type(e).__name__, e)  # L12577 const-recovered
        if getUUID() == '00000000-0000-0000-0000-000000000000' or 'banned' in str(getUUID()).lower():  # L12578 guard-inferred (banned-hwid check, consts unknown)
            showAuthPopup('Device blocked', 'This device has been blocked from using Nighty.')  # L12579 const-recovered
        elif isConnectionError(e):  # L12580
            showAuthPopup(AUTH_OFFLINE_TITLE, AUTH_OFFLINE_TEXT)  # L12581
        else:  # L12582
            showAuthPopup('Unexpected error', f'{type(e).__name__}: {e}')  # L12583 const-recovered / guard-inferred (FORMAT_VALUE artifacts)
    find_discord_exe = spp_export_api('find_discord_exe', ['find_discord_exe'])  # L12598 const-recovered
    saveTokenToConfigCl = spp_export_api('saveTokenToConfigCl', [str])  # L12604 const-recovered (str sig per LOAD_GLOBAL str @974; MAP_ADD artifact)
    checkWebLogin = spp_export_api('checkWebLogin', ['checkWebLogin'])  # L12625 const-recovered
    Thread(target=checkWebLogin).start()  # L12673 const-recovered 'target'

############################################################################
############################################################################
# get_watching_channel_id   (original line 9591)


############################################################################
############################################################################
# set_watching_channel_id   (original line 9595)

############################################################################
# set_watching_channel_id   (original line 9595)
############################################################################

@classmethod
def set_watching_channel_id(cls, channel_id):
    # line 9596 unrecovered (docstring/comment slot)

    cls._watching_channel_id = channel_id
    return cls._watching_channel_id

############################################################################

@classmethod
def set_watching_channel_id(cls, channel_id):
    # docstring line 9596 unrecovered

    cls._watching_channel_id = channel_id
    return cls._watching_channel_id


############################################################################
# get_watching_channel_id   (original line 9591)
############################################################################

@classmethod
def get_watching_channel_id(cls):
    return cls._watching_channel_id

############################################################################

@classmethod
def get_watching_channel_id(cls):
    return cls._watching_channel_id

############################################################################
# __init__   (original line 4087)


############################################################################
# __init__   (original line 4087)
############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self):
    super().__init__()
    self.add_item(NightyHelpSelect())

############################################################################

# [confidence=low - see wave45 evidence]
def __init__(self):
    super().__init__()
    self.add_item(NightyHelpSelect())

# __init__   (original line 3940)


############################################################################
# __init__   (original line 3940)
############################################################################

# class __init__ (bot client). argc=1, stream 42 bytes / 21 instrs.
# ANOMALIES:
#  - stream byte at addr 22 is 0x8d (armor CALL_FUNCTION_KW variant); the D dump
#    prints it as CALL_FUNCTION 2 / BUILD_LIST 2 depending on context, older
#    fence44 dump decodes CALL_FUNCTION_KW 2. LOAD_CONST 1 sits immediately
#    before it => kwargs call; const 1 is the armor-decoyed ('intents','status')
#    keys tuple (consts-shape=['int'] = decoy).
#  - super().__init__ is fetched with LOAD_ATTR (armor flipped LOAD_METHOD).
def __init__(self):
    super().__init__(intents=discord_bot.Intents.all(), status=discord_bot.Status.online)  # 3941  # const-recovered (kw names)
    self.tree = app_commands.CommandTree(self)  # 3942

############################################################################

# class __init__ (bot client). argc=1, stream 42 bytes / 21 instrs.
# ANOMALIES:
#  - stream byte at addr 22 is 0x8d (armor CALL_FUNCTION_KW variant); the D dump
#    prints it as CALL_FUNCTION 2 / BUILD_LIST 2 depending on context, older
#    fence44 dump decodes CALL_FUNCTION_KW 2. LOAD_CONST 1 sits immediately
#    before it => kwargs call; const 1 is the armor-decoyed ('intents','status')
#    keys tuple (consts-shape=['int'] = decoy).
#  - super().__init__ is fetched with LOAD_ATTR (armor flipped LOAD_METHOD).
def __init__(self):
    super().__init__(intents=discord_bot.Intents.all(), status=discord_bot.Status.online)  # 3941  # const-recovered (kw names)
    self.tree = app_commands.CommandTree(self)  # 3942

