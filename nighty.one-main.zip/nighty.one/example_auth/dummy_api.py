# dummy_api.py - Local dummy Nighty auth API
# Run this, point the full rebuild at it, done. No real
# nighty.one contact needed.
#
# This mimics eu.nighty.one/v2 (the verified auth endpoint).
# It always returns success so the app proceeds past auth.
#
# CREDITS: Byte X / gang.baby

from flask import Flask, request, jsonify
import uuid as uuid_mod

app = Flask(__name__)
PORT = 9999

# In-memory "licensed" state
LICENSES = set()
SESSIONS = {}


@app.route('/v2', methods=['POST'])
def auth():
    """The auth endpoint Nighty posts to.

    Real server expects:
      POST https://eu.nighty.one/v2
      Content-Type: application/json
      {"uuid": "<RSA-encrypted UUID>", "key": "<RSA-encrypted license>"}

    Our dummy always says "ok" because we're nice like that.
    """
    data = request.get_json(silent=True) or {}

    # Generate a fake session token
    session_token = str(uuid_mod.uuid4())
    SESSIONS[session_token] = {
        'uuid': data.get('uuid', 'unknown'),
        'key': data.get('key', 'unknown'),
        'active': True,
    }

    return jsonify({
        'ok': 'ok',
        'token': session_token,
        # the app reads these straight out of the auth response
        # (bot.config['nighty'] / data['key'] / data['versions'])
        'nighty': {},
        'key': 'DummyKeyForByteX-NIGHTY-LocalMode001',
        'versions': ['2.6.1', '2.6.0', '2.5.9', '2.5.8'],
        'expires': '2099-12-31T23:59:59',
        'message': 'Welcome to the Byte X zone',
    })


@app.route('/v2', methods=['GET'])
def status():
    """Status endpoint (the real one returns {"status": "online"})"""
    return jsonify({'status': 'online', 'server': 'Byte X Dummy'})


@app.route('/v2/validate', methods=['POST'])
def validate():
    """Token validation (if the app checks)"""
    return jsonify({'valid': True, 'message': 'always valid lol'})


@app.route('/health')
def health():
    return jsonify({'healthy': True, 'credits': 'Byte X / gang.baby'})


if __name__ == '__main__':
    print(f"""
    ╔══════════════════════════════════════════╗
    ║  🩸 Byte X Dummy Auth API                 ║
    ║                                          ║
    ║  Running on http://localhost:{PORT}       ║
    ║                                          ║
    ║  Point your rebuild's SERVER_TO_USE at: ║
    ║  http://localhost:{PORT}/v2               ║
    ║                                          ║
    ║  Always returns "ok" because we're      ║
    ║  not paywalling basic functionality 💀  ║
    ║                                          ║
    ║  Credits: Byte X / gang.baby             ║
    ╚══════════════════════════════════════════╝
    """)
    app.run(host='127.0.0.1', port=PORT, debug=False)
