# Swapping the Auth System

Nighty phones home to `eu.nighty.one/v2` with an RSA-encrypted license check. If you want the full GUI version without Nighty's servers, you have three options:

## Option 1: The Dummy API (easiest)

```bash
# Terminal 1: start the dummy API
python example_auth/dummy_api.py

# Terminal 2: point the rebuild at it
# Edit rebuild/app/Nighty_source.py:
#   SERVER_TO_USE = 'http://localhost:9999/v2'
# Then run:
python rebuild/app/run_nighty.py
```

The dummy API always returns `{"ok": "ok"}` so auth always passes.

## Option 2: Your Own Auth Server

The real endpoint expects:

```json
POST /v2
Content-Type: application/json

{
    "uuid": "<RSA-encrypted machine UUID>",
    "key": "<RSA-encrypted license key>"
}
```

Response on success:
```json
{
    "ok": "ok",
    "token": "<session token>",
    "expires": "<ISO datetime>"
}
```

Write your own Flask/FastAPI server that accepts this shape:

```python
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/v2', methods=['POST'])
def auth():
    data = request.get_json()
    # Your validation logic here
    # (or just return ok like our dummy)
    return jsonify({"ok": "ok", "token": "whatever"})

app.run(port=9999)
```

## Option 3: Skip Auth Entirely

In `rebuild/app/Nighty_source.py`, find the Nighty2 function and replace the auth block:

```python
# Find this section in Nighty2():
#   response = session.post(SERVER_TO_USE, json=json_data, ...)
#   if response.status_code == 200: ...

# Replace with:
logging.info("Auth bypassed - Byte X mode 😎")
# ... continue with the rest of the boot
```

## The PEM Key Situation (for the curious)

Nighty uses RSA-OAEP encryption for the auth payload. The public key is hardcoded:

```python
RSA_PUBLIC_KEY_PEM = (
    b'-----BEGIN PUBLIC KEY-----\n'
    b'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvtk0RFtY6XcnA+tH8qEq\n'
    # ... (full key in rebuild/app/Nighty_source.py)
    b'-----END PUBLIC KEY-----'
)
```

The app encrypts your machine UUID + license key with this public key and sends the ciphertext to the server. The server has the private key and decrypts to verify.

**You don't need any of this if you use the dummy API or skip auth.** The key is just there because it was in the original code and we recovered it byte-for-byte. 😎

---

*Credits: Byte X / gang.baby -- if this helped you understand Nighty's auth, star the repo.*
