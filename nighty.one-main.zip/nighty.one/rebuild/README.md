# Rebuild - Full GUI Version

The complete Nighty application rebuilt from recovered source.

## what lib it runs on

not pip. the app imports `discord_bot`, and `discord_bot` sits on `discord` - both forks live in `../lib/` as the original compiled bytecode pulled straight out of nighty.exe. that is literally what his exe ran on.

- `lib/discord` 2.2.0a - the selfbot core (friends, relationships, ack, settings). talks to discord through curl_cffi with a browser TLS fingerprint. this is where the Chrome/83 user agent comes from.
- `lib/discord_bot` 2.8.0a - the newer layer his app actually imports. ui helpers, app commands.
- `lib/discord_protos` - protobuf models the forks use.

neither fork is his from scratch either. both come from the discord.py-self lineage, readable upstream at github.com/dolfies/discord.py-self (itself a fork of Rapptz's discord.py, MIT). his delta on top is the selfbot plumbing: the gateway over curl_cffi instead of aiohttp websockets (the bullet above), extra user-account calls like block/unblock, edit_settings and hypesquad house changes, and selfbot-specific errors like CaptchaRequired and AuthFailure. want a shipped module as readable source? `pip install decompyle3`, then `decompyle3 ../lib/discord/client.pyc`. its python 3.8 bytecode, uncompyle6 works too.

so you never install any discord package. you only install the small stuff underneath:

```
pip install aiohttp curl_cffi==0.9.0 requests urllib3 flask flask-socketio cryptography PyQt5 pywebview
```

notes on that list:
- curl_cffi must be 0.9.0 (what he bundled). run_nighty.py patches in the one export his build added on top of it.
- one heads up: `discord_bot.ext.commands` is broken inside his own bundle (his discord_bot 2.8.0a expects names his discord 2.2.0a fork doesnt have). his app never imports that path and neither does this rebuild, so it never triggers. its his bug, left as shipped.

## Setup

1. install the packages above (Python 3.8)

2. configure auth. the original posts to `eu.nighty.one/v2` with RSA-encrypted `{"uuid": ..., "key": ...}`. three options:
   - use the dummy api (`../example_auth/dummy_api.py`) and point the source at it:
     ```python
     SERVER_TO_USE = 'http://localhost:9999/v2'
     ```
   - write your own (see `../example_auth/README.md`)
   - skip auth entirely (search for "bypass" in the source)

3. run:
   ```
   python run_nighty.py
   ```

## what the launcher does

run_nighty.py puts `../lib` first on sys.path so the bundled forks win over anything pip installed, patches the curl_cffi export, then seeds a fake `spp_export_api` module (spp_fake.py). that last one is because the armor called into a native module at those call sites; the rebuilt source keeps the call sites so the fake answers them. its all in-repo, nothing points outside.

## What Works

- boots clean against the dummy api (auth parses, no bootstrap errors)
- opens webview UI, the js bridge executes
- real RSA crypto executes
- flask+socketio server starts
- notification system (toasts, animations)
- all 771 recovered sections included

## honest limits

the original module-level body of the app was never captured in any evidence bank, so the rebuild wires the globals by hand (see the "Module wiring" block near the bottom of Nighty_source.py). the boot path and auth path are fully wired now.

on 2026-10-18 a port pass wired in 50 recovered function bodies verbatim from `../source/Nighty.py` plus 5 items from `../tools/native_core` (the "Recovered units" section in Nighty_source.py) - loadScripts, reloadAllScripts, botCmd, showToast, notifyNitroSnipe, the RPC/theme/spotify helpers, the app-create family, autoApp and more. undefined-name count went from 142 to 50.

what's still missing is the same list as before, just shorter: the config-getter family (getAliases, getKeywords, getRPCPresets, turbo_sniper and friends - the recovered code that calls the four most common ones gets kept callable by a marked `_config_store` shim), the `_cc_*` curl_cffi patch prologue, TLSSession (that one only exists in his patched curl_cffi binary, which this repo does not ship), some theme-render constants, and LOGIN_PAGE_HTML (register-held payload, never recovered). hitting any of those logs an error instead of crashing. faking them would be lying about what was recovered, so they stay broken and documented.

2026-10-18 update: we tested whether the missing 41 could be pulled from a live running instance. built an offline rig (dummy auth via a local TLS-intercepting proxy, his own verify=False against it), let the exe run to maturity, then swept its whole heap with passive ReadProcessMemory. the ghost names exist in memory as raw armor table bytes (99 hits), but nothing in the process - not the ghosts, not even functions that provably ran, not even sys.modules keys - materializes as standard live CPython objects. the armor keeps the object layer hollow for the entire app. so the 41-name floor is measured, not assumed.

*Credits: Byte X / gang.baby*
