# path helpers - recovered from the spp native lane (the
# getNightyPath family); the app stores everything under
# %APPDATA%/Nighty Selfbot (verified: auth.json, nighty.config,
# web_config.json, voicemute.json all live there).
import os

_APPDATA = os.environ.get('APPDATA', '')
NIGHTY_DIR = os.path.join(_APPDATA, 'Nighty Selfbot')


def getNightyPath():
    return NIGHTY_DIR


def getAuthPath():
    return os.path.join(NIGHTY_DIR, 'auth.json')


def getConfigPath():
    return os.path.join(NIGHTY_DIR, 'nighty.config')


def getWebConfigPath():
    return os.path.join(NIGHTY_DIR, 'web_config.json')


def getDataPath(name='nighty.png'):
    return os.path.join(NIGHTY_DIR, name)


def getSoundsPath():
    return os.path.join(NIGHTY_DIR, 'sounds')


def getScriptsPath():
    return os.path.join(NIGHTY_DIR, 'scripts')


def getRPCPath():
    return os.path.join(NIGHTY_DIR, 'rpc')


DEFAULT_WEB_CONFIG = {'username': None, 'password': None,
                      'host': '0.0.0.0', 'port': 80}
DEFAULT_CONFIG = {'prefix': '.', 'deletetimer': 40,
                  'riskmode': False, 'dmlogger': 'off',
                  'nitrosniper': True, 'theme': 'nighty'}
DEFAULT_THEME = {}

import threading as _th
_web_config_lock = _th.Lock()
_config_lock = _th.Lock()
