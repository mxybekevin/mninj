"""Nighty - recovered application source.
Rebuilt from the fence45-46 evidence campaign.
"""

import os
import sys
import json
import time
import uuid
import base64
import hashlib
import random
import string
import re as _re
import re
import io
import traceback
import platform
import socket
import functools
import collections
import itertools
import contextlib
import shutil
import glob
import tempfile
import queue
import logging
import threading
import subprocess
import webbrowser
import requests
from threading import Thread, Timer, Lock
from cryptography.hazmat.primitives import serialization, padding as _crypto_padding, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from path_helpers import (getNightyPath, getAuthPath,
                          getConfigPath, getWebConfigPath,
                          getDataPath, getSoundsPath,
                          getScriptsPath, getRPCPath,
                          DEFAULT_WEB_CONFIG, DEFAULT_CONFIG,
                          DEFAULT_THEME, _web_config_lock,
                          _config_lock)
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import asyncio
import discord_bot
import discord  # noqa: F401 - the bundled fork via lib/
import discord_bot.app_commands as app_commands
import flask
from flask import Flask, request, jsonify
import webview
from flask_socketio import SocketIO
from PyQt5 import QtCore, QtGui, QtWidgets
import ast  # noqa: F401  (module-body imports, restored)
import copy  # noqa: F401
import urllib  # noqa: F401
from datetime import datetime, timedelta  # noqa: F401
from functools import wraps  # noqa: F401
from inspect import iscoroutinefunction  # noqa: F401
from types import MethodType  # noqa: F401
from signal import SIGTERM  # noqa: F401
from PyQt5.QtCore import QUrl, QPropertyAnimation  # noqa: F401
from PyQt5.QtGui import QPixmap  # noqa: F401
from PyQt5.QtNetwork import QNetworkAccessManager, QNetworkRequest  # noqa: F401
from aiohttp import ClientSession  # noqa: F401
from flask import Response  # noqa: F401 - serve_login_page returns one
try:
    import pyperclip  # noqa: F401
except ImportError:
    pyperclip = None
try:
    import keyring  # noqa: F401
except ImportError:
    keyring = None
try:
    import win32crypt  # noqa: F401
except ImportError:
    win32crypt = None
try:
    from openai import AsyncOpenAI  # noqa: F401
except ImportError:
    AsyncOpenAI = None


#----------------------------------------------------------------------------

def _nighty_handle_select(self, rs, ws):
    for r in rs:
        try:
            self._handle_event(r, self._readers)
        except Exception:
            logging.exception('[curl selector] reader callback '
                              'failed (ignored)')
    for w in ws:
        try:
            self._handle_event(w, self._writers)
        except Exception:
            logging.exception('[curl selector] writer callback '
                              'failed (ignored)')
    if not getattr(self, '_closed', False):
        try:
            self._start_select()
        except Exception:
            logging.exception('[curl selector] re-arm skipped')
    return None

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def _nighty_pop_curl(self):
    try:
        curl = self.pool.get_nowait()
    except asyncio.QueueEmpty:
        curl = None
    if curl is None or getattr(curl, "_curl", None) is None:
        curl = _cc_Curl(debug=(self.debug))
    curl._nighty_pooled = False
    return curl
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def _nighty_release_curl(self, curl):
    if getattr(curl, '_nighty_pooled', False):
        return None
    curl._nighty_pooled = True
    _cc_orig_release_curl(self, curl)
    return None

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def _nighty_aws_close(self, *args, **kwargs):
    try:
        await _cc_orig_aws_close(self, *args, **kwargs)
    except BaseException:
        try:
            self.terminate()
        except Exception:
            pass
        raise
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def _nighty_ws_recv(self, *, timeout=None):
    loop = self.loop
    chunks = []
    flags = 0
    sock_fd = await loop.run_in_executor(None, self.curl.getinfo, _cc_Info.ACTIVESOCKET)
    if sock_fd == _cc_BAD_SOCKET:
        raise _cc_wsmod.WebSocketError("Invalid active socket", _cc_ECode.NO_CONNECTION_AVAILABLE)
    while True:
        try:
            chunk, frame = await self.recv_fragment(timeout=timeout)
            flags = frame.flags
            chunks.append(chunk)
            if frame.bytesleft == 0:
                if flags & _cc_WsFlag.CONT == 0:
                    break
        except _cc_CurlError as e:
            if e.code == _cc_ECode.AGAIN:
                await _cc_aselect(sock_fd, loop=loop, timeout=timeout)
            else:
                raise
    return b''.join(chunks), flags
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def _nighty_eb_init(self, _orig):
    _orig(self)
    self._max = min(self._max, 6)
    return None

# NOTE: recovery flag - see the native_core docstring
#----------------------------------------------------------------------------


def _superviseGatewayConnect(_gw_mod, _gw_label):
    _gw_orig_connect = _gw_mod.Client.connect
    _gw_fatal = tuple(_gw_label)
    if _gw_orig_connect is None:
        return


    async def _nighty_connect(self, _connect=_gw_orig_connect, _fatal=_gw_fatal):
        _gw_attempts = 0
        while True:
            try:
                return await _connect(self)
            except _fatal:
                raise
            except Exception:
                _gw_attempts += 1
                if _gw_attempts >= 3:
                    raise
                await asyncio.sleep(2 ** _gw_attempts)
    _gw_mod.Client.connect = _nighty_connect


#----------------------------------------------------------------------------

def getUUID():
    return str(uuid.UUID(int=uuid.getnode())).upper()

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def encryptRSA(data):
    public_key = serialization.load_pem_public_key(RSA_PUBLIC_KEY_PEM)
    encrypted = public_key.encrypt(
        data.encode('utf-8'),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None))
    return encrypted.hex()


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getClientActivity():
    try:
        with open(getDataPath() + '/misc/client_analytics.json',
                  'r') as f:
            return json.load(f)
    except Exception:
        return {}

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def saveClientActivity(data):
    try:
        with open(getDataPath() + '/misc/client_analytics.json',
                  'w') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getSpySettings():
    with open(getDataPath() + '/misc/spy.json', 'r') as f:
        return json.load(f)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def saveSpySettings(data):
    with open(getDataPath() + '/misc/spy.json', 'w') as f:
        json.dump(data, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getTranslateSettings():
    with open(getDataPath() + '/misc/translate.json', 'r') as f:
        return json.load(f)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def saveTranslateSettings(data):
    with open(getDataPath() + '/misc/translate.json', 'w') as f:
        json.dump(data, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def initialize_forceprivate():
    if not os.path.exists(force_private_path):
        with open(force_private_path, 'w') as f:
            json.dump([], f, indent=2)
        return
    try:
        with open(force_private_path, 'r') as f:
            cmds = json.load(f)
        if not isinstance(cmds, list):
            raise ValueError('Invalid JSON format')
    except (json.JSONDecodeError, ValueError):
        with open(force_private_path, 'w') as f:
            json.dump([], f, indent=2)

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getForcePrivateCommands():
    try:
        with open(force_private_path, 'r', encoding='utf-8',
                  errors='ignore') as f:
            cmds = json.load(f)
        if not isinstance(cmds, list):
            raise ValueError('force_private root is not a list')
    except Exception as e:
        logging.error('getForcePrivateCommands: ' + force_private_path +
                      ' is unreadable (' + str(e) + ') - resetting it')
        atomicJsonDump([], force_private_path)
        return []
    return cmds

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def save_forceprivate_commands(data):
    try:
        with open(force_private_path, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def addForcePrivateCommand(command_name):
    initialize_forceprivate()
    cmds = getForcePrivateCommands()
    if isinstance(cmds, list):
        if command_name not in cmds:
            cmds.append(command_name)
            save_forceprivate_commands(cmds)
            return True
        return False
    return False

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def removeForcePrivateCommand(command_name):
    initialize_forceprivate()
    cmds = getForcePrivateCommands()
    if isinstance(cmds, list):
        if command_name in cmds:
            cmds.remove(command_name)
        save_forceprivate_commands(cmds)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def saveVoiceMuteConfig(data):
    with open(voicemute_path, 'w', encoding='utf-8', errors='ignore') as f:
        json.dump(data, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getVoiceMuteConfig():
    try:
        with open(voicemute_path, 'r', encoding='utf-8',
                  errors='ignore') as f:
            config = json.load(f)
        if not isinstance(config, dict):
            raise ValueError('voicemute.json is not an object')
    except Exception:
        config = copy.deepcopy(VOICEMUTE_DEFAULTS)
        saveVoiceMuteConfig(config)
    _merge_defaults(config, VOICEMUTE_DEFAULTS)
    saveVoiceMuteConfig(config)
    return config


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getVoiceMuteSetting(key):
    return getVoiceMuteConfig()['settings'].get(key)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def setVoiceMuteSetting(key, value):
    config = getVoiceMuteConfig()
    config['settings'][key] = value
    saveVoiceMuteConfig(config)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getVoiceMuteList():
    return getVoiceMuteConfig()['list']


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def isVoiceMuteListEnabled():
    return getVoiceMuteConfig()['list']['enabled']


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def setVoiceMuteListEnabled(state):
    config = getVoiceMuteConfig()
    config['list']['enabled'] = bool(state)
    saveVoiceMuteConfig(config)
    return config['list']['enabled']


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getVoiceMuteListMode():
    return getVoiceMuteConfig()['list']['mode']


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def setVoiceMuteListMode(mode):
    config = getVoiceMuteConfig()
    config['list']['mode'] = 'whitelist' if mode else 'blacklist'
    saveVoiceMuteConfig(config)
    return config['list']['mode']


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def addVoiceMuteListId(user_id):
    config = getVoiceMuteConfig()
    uid = str(user_id)
    ids = config['list']['ids']
    if uid not in ids:
        ids.append(uid)
        saveVoiceMuteConfig(config)
    return True


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def removeVoiceMuteListId(user_id):
    config = getVoiceMuteConfig()
    uid = str(user_id)
    ids = config['list']['ids']
    if uid in ids:
        ids.remove(uid)
        saveVoiceMuteConfig(config)
    return True


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def isInVoiceMuteList(user_id):
    return str(user_id) in getVoiceMuteConfig()['list']['ids']


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def saveVoiceMuteHistory(ids):
    with open(voicemute_history_path, 'w', encoding='utf-8',
              errors='ignore') as f:
        json.dump(ids, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getVoiceMuteHistory():
    try:
        with open(voicemute_history_path, 'r', encoding='utf-8',
                  errors='ignore') as f:
            hist = json.load(f)
        if not isinstance(hist, list):
            raise ValueError('voicemute_history.json is not an array')
        return hist
    except Exception:
        hist = []
        saveVoiceMuteHistory(hist)
        return hist


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def addVoiceMuteHistory(user_id):
    history = getVoiceMuteHistory()
    if isinstance(history, (list, set, tuple)):
        uid = str(user_id)
        if uid not in history:
            history.append(uid)
            saveVoiceMuteHistory(list(history))


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def removeVoiceMuteHistory(user_id):
    history = getVoiceMuteHistory()
    uid = str(user_id)
    if uid in history:
        history.remove(uid)
        saveVoiceMuteHistory(history)
        return True


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def isInVoiceMuteHistory(user_id):
    return str(user_id) in getVoiceMuteHistory()


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def clearVoiceMuteHistory():
    saveVoiceMuteHistory([])

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def saveNoLeaveData(data):
    with open(noleave_path, 'w', encoding='utf-8', errors='ignore') as f:
        json.dump(data, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getNoLeaveData():
    try:
        with open(noleave_path, 'r', encoding='utf-8',
                  errors='ignore') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError('noleave.json is not an object')
    except Exception:
        data = {}
        saveNoLeaveData(data)
    return data

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def isNoLeaveLocked(group_id, user_id):
    return str(user_id) in getNoLeaveData().get(str(group_id))

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def toggleNoLeave(group_id, user_id):
    data = getNoLeaveData()
    gid, uid = str(group_id), str(user_id)
    group = data.get(gid, [])
    if uid in group:
        group.remove(uid)
        data[gid] = group
        saveNoLeaveData(data)
        return False
    group.append(uid)
    data[gid] = group
    saveNoLeaveData(data)
    return True

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getNoLeaveUsers(group_id):
    return getNoLeaveData().get(str(group_id))


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def clearNoLeaveData():
    saveNoLeaveData({})

# NOTE: recovery flag - see the native_core docstring
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def addContextFileFeature(s):
    getContextFileFeatures()
    try:
        with open(context_path, 'r') as f:
            feats = json.load(f)
    except Exception:
        feats = []
    if s not in feats:
        feats.append(s)
        with open(context_path, 'w') as f:
            json.dump(feats, f, indent=2)

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def removeContextFileFeature(s):
    getContextFileFeatures()
    try:
        with open(context_path, 'r') as f:
            feats = json.load(f)
    except Exception:
        feats = []
    feats = [x for x in feats if x != s]
    with open(context_path, 'w') as f:
        json.dump(feats, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def handle_exception(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        return
    logging.error('Uncaught exception',
                  exc_info=(exc_type, exc_value, exc_traceback))
    sys.__excepthook__(exc_type, exc_value, exc_traceback)

#----------------------------------------------------------------------------


def setup_logging():
    log_path = getNightyPath()
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    file_handler = logging.FileHandler(
        log_path + '/Nighty.log', encoding='utf-8')
    file_handler.setFormatter(logging.Formatter('[%(asctime)s] '
        '[%(levelname)s] %(name)s: %(message)s'))

    # SafeConsoleHandler: console sink; the stream guard falls back to
    # stderr whenever stdout is closed or redirected away from the
    # console. The handler class itself resolves in its own unit; the
    # names below alias it for this scope.
    SafeConsoleHandler = stdout_handler = logging.StreamHandler(sys.stdout or sys.stderr)
    stdout_handler.setFormatter(logging.Formatter('%(asctime)s: %(message)s'))

    root_logger.addHandler(file_handler)

    root_logger.addHandler(stdout_handler)
    root_logger.setLevel(logging.INFO)
    sys.excepthook = handle_exception

    return root_logger


#----------------------------------------------------------------------------
async def isTokenValid(token):
    return any([(await bot.login(token)) or ((await bot.close()) and True) if await bot.login(token) else False])

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def atomicJsonDump(data, path):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8', errors='ignore') as f:
        json.dump(data, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def _loadJsonOrRestore(path, defaults, lock):
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError('config root is not an object')
        return data
    except Exception:
        try:
            if os.path.exists(path):
                shutil.copyfile(path, path + '.corrupted')
            atomicJsonDump(defaults, path)
            return dict(defaults)
        except Exception:
            return dict(defaults)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getConfigData():
    return _loadJsonOrRestore(getConfigPath(), DEFAULT_CONFIG, _config_lock)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def saveConfigData(config):
    with _config_lock:
        atomicJsonDump(config, getConfigPath())


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def updateConfig(key, value):
    config = getConfigData()
    config[key] = value
    saveConfigData(config)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getWebConfigData():
    return _loadJsonOrRestore(getWebConfigPath(), DEFAULT_WEB_CONFIG,
                              _web_config_lock)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def updateWebConfig(new_config):
    with _web_config_lock:
        atomicJsonDump(new_config, getWebConfigPath())


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def _loadThemeFile(theme_name):
    try:
        with open(getDataPath() + '/themes/' + theme_name + '.json',
                  encoding='utf-8', errors='ignore') as f:
            theme = json.load(f)
    except Exception:
        theme = None
    if not isinstance(theme, dict):
        raise ValueError('theme root is not an object')
    return theme


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getThemeData(theme_name):
    try:
        return processDThemeData(_loadThemeFile(theme_name),
                                 getConfigData(), getDRPCValues())
    except Exception as e:
        if theme_name != 'nighty':
            logging.error(
                f"Theme '{theme_name}' unavailable ({e}); "
                f"falling back to the default theme.")
            try:
                return processDThemeData(_loadThemeFile('nighty'),
                                         getConfigData(), getDRPCValues())
            except Exception:
                pass
        os.makedirs(getDataPath() + '/themes', exist_ok=True)
        atomicJsonDump(dict(DEFAULT_THEME),
                       getDataPath() + '/themes/nighty.json')
        config = getConfigData()
        if config.get('theme') != 'nighty':
            config['theme'] = 'nighty'
            saveConfigData(config)
        return dict(DEFAULT_THEME)

# NOTE: recovery flag - see the native_core docstring
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getOthersData():
    try:
        with open(getDataPath() + '/others.json', encoding='utf-8',
                  errors='ignore') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def setOthersData(key, value):
    data = getOthersData()
    data[key] = value
    try:
        with open(getDataPath() + '/others.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass

# NOTE: recovery flag - see the native_core docstring
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def addKeyword(keyword):
    kws = getKeywords()
    if keyword not in kws:
        kws.append(keyword)
        try:
            with open(getDataPath() + '/keywords.json', 'w',
                      encoding='utf-8', errors='ignore') as f:
                json.dump(kws, f, indent=2)
        except Exception:
            pass
    return True

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def removeKeyword(keyword):
    kws = getKeywords()
    if keyword in kws:
        kws.remove(keyword)
        try:
            with open(getDataPath() + '/keywords.json', 'w',
                      encoding='utf-8', errors='ignore') as f:
                json.dump(kws, f, indent=2)
        except Exception:
            pass
    return True

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def storeSnipeAttachments(message):
    """Download a deleted message's attachments to data/snipes/<channel>/<message>/.
        Returns a list of {filename, url, content_type, path} (path None if not downloaded).
    """
    stored = []
    if not message.attachments:
        return stored
    snipe_dir = f"{getDataPath()}/snipes/{message.channel.id}/{message.id}"
    try:
        os.makedirs(snipe_dir, exist_ok=True)
    except Exception:
        return [{'filename': a.filename, 'url': a.url, 'content_type': a.content_type, 'path': None} for a in message.attachments]
    async with ClientSession() as session:
        for att in message.attachments:
            meta = {'filename': att.filename, 'url': att.url, 'content_type': att.content_type, 'path': None}
            try:
                if not att.size or att.size <= SNIPE_CACHE_MAX_FILE:
                    async with session.get(att.url) as resp:
                        if resp.status == 200:
                            path = os.path.join(snipe_dir, att.filename)
                            with open(path, "wb") as f:
                                f.write(await resp.read())
                            meta["path"] = path
            except Exception:
                pass
            stored.append(meta)
    return stored
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def cleanupSnipeCache(remove_paths):
    try:
        for path in remove_paths:
            if os.path.isfile(path):
                os.remove(path)
    except Exception:
        pass
    if time.time() - bot.config.get('_snipe_last_sweep', 0) < 60:
        return
    try:
        bot.config['_snipe_last_sweep'] = time.time()
    except Exception as e:
        logging.error('cleanupSnipeCache: ' + str(e))
    if os.path.isdir(getDataPath() + '/snipes'):
        now = time.time()
        candidates = []
        for root, dirs, files in os.walk(getDataPath() + '/snipes'):
            for name in files:
                path = os.path.join(root, name)
                try:
                    st = os.stat(path)
                except Exception:
                    continue
                if now - st.st_mtime > SNIPE_CACHE_MAX_AGE:
                    try:
                        os.remove(path)
                    except Exception:
                        pass
                candidates.append((path, st.st_mtime, st.st_size))
        candidates.sort(key=lambda x: x[1])
        total = sum(size for _, _, size in candidates)
        if total > SNIPE_CACHE_MAX_TOTAL:
            for path, _, size in candidates:
                if total <= SNIPE_CACHE_MAX_TOTAL:
                    break
                try:
                    os.remove(path)
                    total -= size
                except Exception:
                    pass


#----------------------------------------------------------------------------


def clearSnipeData(channel_id):
    count = 0
    snipe = bot.config.get('snipe', {})  # const-recovered
    edit_snipe = bot.config.get('edit_snipe', {})  # const-recovered
    base = getDataPath() + '/snipe'  # const-recovered
    try:
        if channel_id:
            count += len(snipe.pop(channel_id, {}))
            count += len(edit_snipe.pop(channel_id, {}))
            shutil.rmtree(os.path.join(base,
                str(channel_id)), ignore_errors=True)
        else:
            count += sum(len(entry) for entry in snipe.values())
            snipe.clear()
            edit_snipe.clear()
            shutil.rmtree(base, ignore_errors=True)
        os.makedirs(base, exist_ok=True)
    except Exception as e:
        logging.error('clearSnipeData: ' + str(e))  # const-recovered
    return count


#----------------------------------------------------------------------------

def shouldSkipMimic(showToast):
    if not showToast:
        return (False, None)
    config = getConfigData()
    name = showToast.lower()
    blocklist = config.get('mimic_blocklist') or []
    for entry in blocklist:
        entry_clean = (entry or '').lower().strip()
        if not entry_clean:
            continue
        if ' ' in entry_clean:
            if entry_clean in name:
                return (True, entry)
        else:
            if re.search('\\b' + re.escape(entry_clean) + '\\b', name):
                return (True, entry)
    if not config.get('mimic_age_filter', True):
        return (False, None)
    for pattern in MIMIC_AGE_PATTERNS:
        if re.search(pattern, name):
            return (True, 'age/minor filter')
    return None

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def addEnabledScript(script_name):
    scripts = getScriptsConfig()
    if script_name not in scripts['enabled']:
        scripts['enabled'].append(script_name)
        with open(getDataPath() + '/misc/scripts.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(scripts, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def removeEnabledScript(script_name):
    scripts = getScriptsConfig()
    if script_name in scripts['enabled']:
        scripts['enabled'].remove(script_name)
        with open(getDataPath() + '/misc/scripts.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(scripts, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def addBlockedDiscoverable(user_id):
    discoverables = getDiscoverablesConfig()
    if user_id not in discoverables['blocked']:
        discoverables['blocked'].append(user_id)
        with open(getDataPath() + '/misc/discoverables.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(discoverables, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def removeBlockedDiscoverable(user_id):
    discoverables = getDiscoverablesConfig()
    if user_id in discoverables['blocked']:
        discoverables['blocked'].remove(user_id)
        with open(getDataPath() + '/misc/discoverables.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(discoverables, f, indent=2)


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def encryptCurrentToken():
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', True):
            token = entry['token']
            if token and not token.startswith('N1:'):
                app = entry['app']
                enc = win32crypt.CryptProtectData(
                    token.encode('utf-8'), None, None, None, None, 0)
                enc_id = win32crypt.CryptProtectData(
                    app['id'].encode('utf-8'), None, None, None, None, 0)
                enc_token = win32crypt.CryptProtectData(
                    app['token'].encode('utf-8'), None, None, None,
                    None, 0)
                entry['token'] = 'N1:' + base64.b64encode(enc).decode(
                    'utf-8')
                entry['app']['id'] = 'N1:' + base64.b64encode(
                    enc_id).decode('utf-8')
                entry['app']['token'] = 'N1:' + base64.b64encode(
                    enc_token).decode('utf-8')
    with open(getConfigPath(), 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4)
    return True


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def decryptCurrentToken():
    config = getConfigData()
    logins = config.get('logins', {})
    try:
        for key, entry in logins.items():
            if entry.get('active', True):
                token = entry['token']
                app_id = entry['app']['id']
                app_token = entry['app']['token']
                if token and token.startswith('N1:'):
                    payload = token[3:]
                    if len(payload) % 4:
                        payload = payload + '=' * (4 - len(payload) % 4)
                    entry['token'] = win32crypt.CryptUnprotectData(
                        base64.b64decode(payload), None, None, None,
                        0)[1].decode('utf-8')
                    payload = app_id[3:]
                    if len(payload) % 4:
                        payload = payload + '=' * (4 - len(payload) % 4)
                    entry['app']['id'] = win32crypt.CryptUnprotectData(
                        base64.b64decode(payload), None, None, None,
                        0)[1].decode('utf-8')
                    payload = app_token[3:]
                    if len(payload) % 4:
                        payload = payload + '=' * (4 - len(payload) % 4)
                    entry['app']['token'] = win32crypt.CryptUnprotectData(
                        base64.b64decode(payload), None, None, None,
                        0)[1].decode('utf-8')
    except Exception as e:
        logging.error('Decrypt failed:' + str(e))
        return None
    with open(getConfigPath(), 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4)
    return True

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getCurrentAppId():
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', True):
            app_id = entry['app']['id']
            if app_id and app_id.startswith('N1:'):
                try:
                    return _decrypt_n1_field(app_id)
                except Exception:
                    return None
    return None


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getCurrentAppToken():
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', True):
            app_token = entry['app']['token']
            if app_token and app_token.startswith('N1:'):
                try:
                    return _decrypt_n1_field(app_token)
                except Exception:
                    return None
    return None


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getCurrentToken():
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', True):
            token = entry.get('token')
            if token and token.startswith('N1:'):
                try:
                    return _decrypt_n1_field(token)
                except Exception:
                    return None
    return None


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getSniperTokens():
    tokens = []
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', False):
            tokens.append(entry.get('token'))
    return tokens

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getActiveProfile():
    config = getConfigData()
    logins = config.get('logins', {})
    for name, data in logins.items():
        if data.get('active') is True:
            return data

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getActiveProfileName():
    config = getConfigData()
    logins = config.get('logins', {})
    for name, data in logins.items():
        if data.get('active') is True:
            return name

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def buildThemeV2(layout, showToast, image):
    components = []
    for item in layout:
        # ARMED-GAP (0x1fa60 head, ~1549B cipher): the iterable
        # source, the ('layout','content','title') unpack (slot
        # 1604), the style dispatch and the IsTrue guard predicate
        # (0x20091) decrypt at call time. The branch routing
        # translated below is the evidenced three-way dispatch of
        # the plaintext tail; the exact dispatch expressions are
        # flagged, not recovered.
        content = item.get('content')
        title = item.get('title')
        if 'section' in item:
            section = item['section']
            text = section['text']
            text = text.replace('{content}', content)
            if title:
                text = text.replace('{title}', title)
            components.append(discord_bot.ui.Section(
                (discord_bot.ui.TextDisplay(content=text),),
                accessory=discord_bot.ui.Thumbnail(
                    section['thumbnail'])))
        elif item.get('text') is not None:
            text = item.get('text')
            text = text.replace('{content}', content)
            if title:
                text = text.replace('{title}', title)
            components.append(discord_bot.ui.TextDisplay(
                content=text))
        else:
            mode = item.get('separator', '').lower()
            spacing = (discord_bot.ui.SeparatorSpacing.large
                       if mode == 'large'
                       else discord_bot.ui.SeparatorSpacing.small)
            components.append(discord_bot.ui.Separator(
                spacing=spacing))
    return components

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def setActiveProfile(profilename):
    config = getConfigData()
    logins = config.get('logins', True)
    for key, entry in logins.items():
        if key == profilename:
            entry['active'] = True
        else:
            entry['active'] = False
    saveConfigData(config)

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getFileCreatedAt(path):
    try:
        ts = os.path.getctime(path)
    except OSError:
        ts = os.path.getmtime(path)
    return datetime.fromtimestamp(ts).strftime('%d %B %Y, at %H:%M:%S')

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def isNSFW(read):
    config = getConfigData()
    if not read.guild:
        return True
    if config['riskmode']:
        return True
    return read.is_nsfw()

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def spoofed_identify(self):
    """Sends the IDENTIFY packet."""
    spoofers = {
        'desktop': {
            'os': "Windows",
            'browser': "Discord Client",
            'device': "",
            'system_locale': "en-US",
            'browser_user_agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            'browser_version': "124.0.0.0",
            'os_version': "10",
            'referrer': "",
            'referring_domain': ""},
        'web': {
            'os': "Windows",
            'browser': "Discord Web",
            'device': "",
            'system_locale': "en-US",
            'browser_user_agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            'browser_version': "124.0.0.0",
            'os_version': "10",
            'referrer': "",
            'referring_domain': ""},
        'ios': {
            'os': "iOS",
            'browser': "Discord iOS",
            'device': "iPhone16,2",
            'system_locale': "en-US",
            'browser_user_agent': "Discord/268.0 CFNetwork/1474 Darwin/23.0.0",
            'browser_version': "268.0",
            'os_version': "17.4.1",
            'referrer': "",
            'referring_domain': ""},
        'android': {
            'os': "Android",
            'browser': "Discord Android",
            'device': "Pixel 8",
            'system_locale': "en-US",
            'browser_user_agent': "Discord-Android/214116;ROM:13;Device:Pixel 8",
            'browser_version': "214.116",
            'os_version': "13",
            'referrer': "",
            'referring_domain': ""},
        'xbox': {
            'os': "Console",
            'browser': "Discord Embedded",
            'device': "Xbox Series X",
            'system_locale': "en-US",
            'browser_user_agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; Xbox; Xbox Series X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586",
            'browser_version': "",
            'os_version': "",
            'referrer': "",
            'referring_domain': ""},
        'ps5': {
            'os': "Console",
            'browser': "Discord Embedded",
            'device': "PlayStation 5",
            'system_locale': "en-US",
            'browser_user_agent': "Mozilla/5.0 (PlayStation 5 3.11) AppleWebKit/605.1.15 (KHTML, like Gecko)",
            'browser_version': "",
            'os_version': "",
            'referrer': "",
            'referring_domain': ""},
        'vr': {
            'os': "Console",
            'browser': "Discord VR",
            'device': "VR-Headset",
            'system_locale': "en-US",
            'browser_user_agent': "DiscordVR/12.45",
            'browser_version': "23.7.91",
            'os_version': "10.0.45",
            'referrer': "",
            'referring_domain': ""}}
    session_spoof = getConfigData()["session"]
    if session_spoof.lower() == "windows":
        session_spoof = "desktop"
    if session_spoof.lower() == "linux":
        session_spoof = "desktop"
    if session_spoof.lower() == "chrome":
        session_spoof = "web"
    payload = {'op':self.IDENTIFY, 'd':{'token':self.token, 'capabilities':self.capabilities.value, 'properties':spoofers[session_spoof], 'presence':{'status':bot.config["status"], 'since':0, 'afk':True}, 'compress':not self._transport_compression, 'client_state':{'guild_versions':{}, 'highest_last_message_id':"0", 'read_state_version':0, 'user_guild_settings_version':-1, 'user_settings_version':-1, 'private_channels_version':"0", 'api_code_version':0}}}
    await self.call_hooks("before_identify", initial=self._initial_identify)
    await self.send_as_json(payload)
    logging.info("Gateway has sent the IDENTIFY payload.")
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def getSlashCommand(details, cmds, app_id):
    for command in cmds:
        if command.name == details and \
                int(command.application_id) == app_id:
            return command
    return None

# NOTE: recovery flag - see the native_core docstring
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def fetchSlashCommand(channel, app_id, command_name):
    for cmd in await channel.application_commands():
        if isinstance(cmd, discord.SlashCommand):
            if cmd.application_id == app_id:
                if cmd.name == command_name:
                    return cmd
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def execSlashCommand(channel, cmd, *args, **kwargs):
    await cmd(channel, *args, **kwargs)
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def sendCmdError(interaction, e):
    """Report a slash-command error without raising a SECOND exception.

        Called from the `except` blocks in ws_extensions/commands.py. Those used to
        call interaction.response.send_message() directly, which itself throws when
        the interaction was already responded to (InteractionResponded) or has
        expired past Discord's 3s window (NotFound 10062) - so one expired
        interaction became an unhandled CommandInvokeError ("During handling of the
        above exception, another exception occurred", seen on /help in nighty.log
        2026-08-02 22:44). Fall back to a followup, and give up quietly if the
        interaction is simply gone.

        Lives here in plain-source Nighty.py on purpose: adding a new top-level
        function to the obfuscated commands.py faults at inject time, while
        commands.py CAN call Nighty.py globals at invocation time.
        """
    try:
        if interaction.response.is_done():
            await interaction.followup.send(f"Error: {e}", ephemeral=True)
        else:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
    except Exception as reply_error:
        logging.error(f"Failed to report command error ({e}): {reply_error}")
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def forwardEmbedMethod(channel_id, content, title, image, thumb):
    cmd_to_run = getSlashCommand("embed", bot.config["app_cmds"], bot_app.user.id)
    if cmd_to_run:
        if title:
            if content:
                if image:
                    interaction = await cmd_to_run(channel=(bot.config["app_channel"]), content=content, title=title, image_url=image, thumb=thumb)
                else:
                    interaction = await cmd_to_run(channel=(bot.config["app_channel"]), content=content, title=title, thumb=thumb)
            elif image:
                interaction = await cmd_to_run(channel=(bot.config["app_channel"]), title=title, image_url=image, thumb=thumb)
            else:
                interaction = await cmd_to_run(channel=(bot.config["app_channel"]), title=title, thumb=thumb)
        elif content:
            if image:
                interaction = await cmd_to_run(channel=(bot.config["app_channel"]), content=content, image_url=image, thumb=thumb)
            else:
                interaction = await cmd_to_run(channel=(bot.config["app_channel"]), content=content, thumb=thumb)
        elif image:
            interaction = await cmd_to_run(channel=(bot.config["app_channel"]), image_url=image, thumb=thumb)
        else:
            interaction = await cmd_to_run(channel=(bot.config["app_channel"]), thumb=thumb)
        if interaction.message:
            channel = bot.get_channel(channel_id)
            if channel is None:
                channel = await bot.fetch_channel(channel_id)
            msg = await interaction.message.forward(channel)
            await interaction.message.ack()
            if getConfigData()["deletetimer"]:
                await msg.delete(delay=(getConfigData()["deletetimer"]))
            return msg
#----------------------------------------------------------------------------


#----------------------------------------------------------------------------
async def forwardTextMethod(channel_id, content):
    cmd_to_run = getSlashCommand("sendtext", bot.config["app_cmds"], bot_app.user.id)
    if cmd_to_run:
        interaction = await cmd_to_run(channel=(bot.config["app_channel"]), text=content)
        if interaction.message:
            channel = bot.get_channel(channel_id)
            if channel is None:
                channel = await bot.fetch_channel(channel_id)
            msg = await interaction.message.forward(channel)
            await interaction.message.ack()
            return msg

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def execute_js_via_websocket(js_code):
    try:
        if getConfigData()['web']:
            socketio.emit('execute_js', {'code': js_code})
            return True
        return False
    except Exception as e:
        logging.info('JS execution failed: ' + str(e))
        return False


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def evaluate_js(js_code):
    try:
        if getConfigData()['web']:
            socketio.emit('execute_js', {'code': js_code})
            return None
        if hasattr(main_ui, 'evaluate_js'):
            return main_ui.evaluate_js(js_code)
        return None
    except Exception as e:
        logging.info('JavaScript execution failed: ' + str(e))
        return None


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def generate_tailwind_classes(prefix):
    classes = []
    for side in ['', 't', 'r', 'b', 'l', 'x', 'y']:
        for size in range(11):
            classes.append(f'{prefix}{side}-{size}')
    return classes

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def _gap_validator(gap_value):
    if gap_value < 0 or gap_value > 10:
        raise ValueError('Gap value must be between 0 and 10')
    return None

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def variant_validator(valid_variants, value):
    if not value:
        return None
    value = value.replace(' ', '')
    if value not in valid_variants:
        raise ValueError(f"Invalid value: {value}. Valid values "
                         f"are: {valid_variants}.")

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def margin_padding_validator(valid_variants, value):
    for cls in value.split(' '):
        if value not in valid_variants:
            raise ValueError(f'Invalid value: {value}. Valid '
                             f'values are: {valid_variants}.')

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Text:

    def __init__(self, content, tab_updater, parent_tab_name,
                 size, weight, color, align, margin, visible):
        self.__id = None
        self.__content = content
        self.__tab_updater = tab_updater
        self.__parent_tab_name = parent_tab_name
        self.__size = size
        self.__weight = weight
        self.__color = color
        self.__align = align
        self.__margin = margin
        self.__visible = visible

    def render(self):
        if not self.__content:
            raise ValueError('Text content cannot be empty')
        return {
            'type': 'text',
            'id': self.__id,
            'content': self.__content,
            'size': self.__size,
            'weight': self.__weight,
            'color': self.__color,
            'align': self.__align,
            'margin': self.__margin,
            'visible': self.__visible,
        }

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Button:

    def __init__(self, parent_tab_name, tab_updater, label,
                 variant, color, size, full_width, disabled,
                 loading, onClick, margin, visible):
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__label = label
        self.__color = color
        self.__size = size
        self.__variant = variant
        self.__full_width = full_width
        self.__disabled = disabled
        self.__loading = loading
        self.__margin = margin
        self.__visible = visible
        if onClick:
            callback_store.register(self.__id, onClick)
            self.__onClick = onClick.__name__
        margin_padding_validator(VALID_MARGINS, self.__margin)
        variant_validator(ALLOWED_VARIANTS, self.__variant)
        variant_validator(ALLOWED_COLORS, self.__color)
        variant_validator(ALLOWED_SIZES, self.__size)

    def render(self):
        if not self.__onClick:
            raise ValueError('Button onClick callback is not '
                             'defined.')
        if not self.__label or self.__label == '':
            raise ValueError('Button label cannot be empty')
        return {
            'type': 'button',
            'id': self.__id,
            'parent_tab_name': self.__parent_tab_name,
            'label': self.__label,
            'variant': self.__variant,
            'color': self.__color,
            'size': self.__size,
            'full_width': self.__full_width,
            'disabled': self.__disabled,
            'loading': self.__loading,
            'onClick': self.__onClick,
            'margin': self.__margin,
            'visible': self.__visible,
        }


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Input:

    def __init__(self, parent_tab_name, tab_updater, label,
                 placeholder, value, description, margin, onInput,
                 show_clear_button, invalid, disabled, readonly,
                 required, full_width, error_message, visible):
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__listener_id = str(uuid.uuid4())
        self.__label = label
        self.__placeholder = placeholder
        self.__value = value
        self.__margin = margin
        self.__description = description
        self.__show_clear_button = show_clear_button
        self.__invalid = invalid
        self.__full_width = full_width
        self.__disabled = disabled
        self.__readonly = readonly
        self.__required = required
        self.__error_message = error_message
        self.__visible = visible
        if onInput is not None:
            callback_store.register(self.__id, onInput)
            self.__onInput = onInput.__name__
            callback_store.register(
                self.__listener_id,
                None)  # FLAG: closure built via the cell
            # machinery (DAT_000a9d58) \u2014 the registered object is
            # not const-visible (GOT_1848 unlabeled)

    def render(self):
        return {
            'type': 'input',
            'label': self.__label,
            'listener_id': self.__listener_id,
            'id': self.__id,
            'parent_tab_name': self.__parent_tab_name,
            'placeholder': self.__placeholder,
            'value': self.__value,
            'full_width': self.__full_width,
            'margin': self.__margin,
            'onInput': self.__onInput,
            'description': self.__description,
            'show_clear_button': self.__show_clear_button,
            'invalid': self.__invalid,
            'disabled': self.__disabled,
            'readonly': self.__readonly,
            'required': self.__required,
            'error_message': self.__error_message,
            'visible': self.__visible,
        }

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Image:

    def __init__(self, parent_tab_name, tab_updater, url, alt,
                 circle, shadow, width, height, rounded, fill_type,
                 margin, border_color, border_width, visible):
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__url = url
        self.__alt = alt
        self.__circle = circle
        self.__shadow = shadow
        self.__width = width
        self.__height = height
        self.__rounded = rounded
        self.__fill_type = fill_type
        self.__margin = margin
        self.__border_color = border_color
        self.__border_width = border_width
        self.__visible = visible

    def render(self):
        margin_padding_validator(VALID_MARGINS, self.__margin)
        variant_validator(ALLOWED_FILL_TYPES, self.__fill_type)
        variant_validator(ALLOWED_ROUNDED, self.__rounded)
        if not 0 <= self.__border_width <= 10:
            raise ValueError('Border width must be between 0 '
                             'and 10')
        url_pattern = re.compile(_IMAGE_URL_PATTERN)
        if not bool(url_pattern.match(self.__url)):
            raise ValueError('Invalid URL provided')
        return {
            'type': 'image',
            'id': self.__id,
            'parent_tab_name': self.__parent_tab_name,
            'url': self.__url,
            'alt': self.__alt,
            'circle': self.__circle,
            'shadow': self.__shadow,
            'width': self.__width,
            'height': self.__height,
            'rounded': self.__rounded,
            'fill_type': self.__fill_type,
            'margin': self.__margin,
            'border_color': self.__border_color,
            'border_width': self.__border_width,
            'visible': self.__visible,
        }


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Toggle:

    def __init__(self, parent_tab_name, tab_updater, label,
                 checked, disabled, onChange, visible):
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__label = label
        self.__checked = checked
        self.__disabled = disabled
        self.__visible = visible
        self.__onChange = onChange

    def render(self):
        if not self.__label or self.__label == '':
            raise ValueError('Toggle label cannot be empty')
        return {
            'type': 'toggle',
            'id': self.__id,
            'listener_id': self.__listener_id,
            'parent_tab_name': self.__parent_tab_name,
            'label': self.__label,
            'checked': self.__checked,
            'disabled': self.__disabled,
            'onChange': self.__onChange,
            'visible': self.__visible,
        }


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Select:

    def __init__(self, parent_tab_name, tab_updater, label, items,
                 selected_items, disabled_items, mode, description,
                 loading, disabled, invalid, error_message,
                 onChange, margin, full_width, visible):
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__label = label
        self.__items = items if items is not None else []
        self.__selected_items = (selected_items
                                 if selected_items is not None
                                 else [])
        self.__disabled_items = (disabled_items
                                  if disabled_items is not None
                                  else [])
        self.__mode = mode
        self.__description = description
        self.__loading = loading
        self.__disabled = disabled
        self.__invalid = invalid
        self.__error_message = error_message
        self.__margin = margin
        self.__full_width = full_width
        self.__visible = visible
        if onChange is not None:
            callback_store.register(self.__id, onChange)
            self.__onChange = onChange.__name__
            self.__listener_id = str(uuid.uuid4())
            callback_store.register(
                self.__listener_id,
                None)  # FLAG: closure built via the cell
            # machinery (DAT_000a9d58) \u2014 the registered object is
            # not const-visible (GOT_1840 unlabeled)

    def render(self):
        if not self.__label or self.__label == '':
            raise ValueError('Select label cannot be empty')
        self.__items_validator(self.__items)
        self.__keys_validator(self.__selected_items)
        self.__keys_validator(self.__disabled_items)
        variant_validator(ALLOWED_MODES, self.__mode)
        margin_padding_validator(VALID_MARGINS, self.__margin)
        return {
            'type': 'select',
            'id': self.__id,
            'listener_id': self.__listener_id,
            'parent_tab_name': self.__parent_tab_name,
            'label': self.__label,
            'items': self.__items,
            'selected_items': self.__selected_items,
            'disabled_items': self.__disabled_items,
            'mode': self.__mode,
            'description': self.__description,
            'loading': self.__loading,
            'disabled': self.__disabled,
            'invalid': self.__invalid,
            'error_message': self.__error_message,
            'onChange': self.__onChange,
            'margin': self.__margin,
            'full_width': self.__full_width,
            'visible': self.__visible,
        }

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Checkbox:

    def __init__(self, parent_tab_name, tab_updater, label,
                 checked, disabled, invalid, onChange, visible):
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__label = label
        self.__checked = checked
        self.__disabled = disabled
        self.__invalid = invalid
        self.__visible = visible
        self.__onChange = onChange

    def render(self):
        if not self.__label or self.__label == '':
            raise ValueError('Checkbox label cannot be empty')
        return {
            'type': 'checkbox',
            'id': self.__id,
            'listener_id': self.__listener_id,
            'parent_tab_name': self.__parent_tab_name,
            'checked': self.__checked,
            'label': self.__label,
            'disabled': self.__disabled,
            'invalid': self.__invalid,
            'visible': self.__visible,
        }


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Table:

    def __init__(self, parent_tab_name, tab_updater, columns,
                 rows, search, onSelectionChange, items_per_page,
                 selectable, visible):
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__selected_row_ids = []
        self.__rows = rows
        self.__selectable = selectable
        self.__items_per_page = items_per_page
        self.__visible = visible
        self.__search = search
        self.__row_select_listener_id = str(uuid.uuid4())
        self.__button_listener_id = str(uuid.uuid4())
        column_labels = []
        button_labels = []
        for column in columns:
            if column['type'] not in ('text', 'button', 'tag'):
                raise ValueError("Column type must be one of "
                                 "'text', 'button', 'tag'")
            if not column['label'] or \
                    column['label'] in column_labels:
                raise ValueError('Duplicate or empty column '
                                 'labels are not allowed')
            column_labels.append(column['label'])
            if column['type'] == 'button':
                if not isinstance(column['buttons'], list):
                    raise ValueError("Column type 'button' must "
                                     "have a 'buttons' key with "
                                     "a list value")
                for button in column['buttons']:
                    if not button['label']:
                        raise ValueError('Button label cannot '
                                         'be empty')
                    if button['label'] in button_labels:
                        raise ValueError('Duplicate button '
                                         'labels are not '
                                         'allowed')
                    button_labels.append(button['label'])
                    if button['color'] not in ('default',
                                               'danger'):
                        raise ValueError(
                            "Button color must be one of "
                            "'default', 'danger'")
                    if not button['onClick']:
                        raise ValueError('Button onClick '
                                         'callback is not '
                                         'defined.')
                    if not callable(button['onClick']):
                        raise ValueError('Button onClick must '
                                         'be a callable '
                                         'function.')
                    callback_store.register(
                        button['onClick'].__name__,
                        button['onClick'])
                    button['onClick'] = button['onClick'].__name__
        self.__columns = columns
        if onSelectionChange is not None:
            callback_store.register(
                onSelectionChange.__name__, onSelectionChange)
            self.__onSelectionChange = onSelectionChange.__name__
        callback_store.register(
            self.__row_select_listener_id, None)  # FLAG: the
        # ('row_id', 'selected') closure (GOT_1828) \u2014 not
        # const-visible
        callback_store.register(
            self.__button_listener_id, None)  # FLAG: the
        # ('onClick', 'row_id') closure (GOT_1832) \u2014 not
        # const-visible

    def render(self):
        if len(self.__columns) == 0:
            raise ValueError('Table columns cannot be empty')
        return {
            'type': 'table',
            'id': self.__id,
            'row_select_listener_id':
                self.__row_select_listener_id,
            'button_listener_id': self.__button_listener_id,
            'parent_tab_name': self.__parent_tab_name,
            'onSelectionChange': self.__onSelectionChange,
            'columns': self.__columns,
            'selectable': self.__selectable,
            'items_per_page': self.__items_per_page,
            'visible': self.__visible,
            'search': self.__search,
        }

    def __rows_validator(self, rows):
        if not isinstance(rows, list):
            raise Exception('The rows must be a list.')
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                raise Exception('Each row must be a dictionary.')
            if 'id' not in row or not isinstance(row['id'], str):
                raise Exception("Each row must have a unique "
                                "'id' of type string.")
            if row['id'] in seen:
                raise Exception('Duplicate id found: '
                                + row['id'])
            seen.add(row['id'])
            if 'cells' not in row or \
                    not isinstance(row['cells'], list):
                raise Exception('Row with id ' + row['id'] +
                                " must have a 'cells' key with "
                                'a list value.')
            if len(row['cells']) != len(self.__columns):
                raise Exception('Row with id ' + row['id'] +
                                ' must have exactly ' +
                                str(len(self.__columns)) +
                                ' cells.')

    def __get_selected_rows_ids(self):
        selected_ids = []
        for row in self.__rows:
            if 'selected' not in row:
                row['selected'] = False
            if row['selected']:
                selected_ids.append(row['id'])
        return selected_ids

    def delete_rows(self, row_ids):
        if not isinstance(row_ids, list):
            raise ValueError('Row ids must be a list of strings')
        evaluate_js('updateCustomTableRows({ "id": "'
                    + self.__id
                    + '", "idsToDelete": '
                    + json.dumps(row_ids)
                    + ', "type": "delete" } )')
        for row in list(self.__rows):
            if row['id'] in row_ids:
                self.__rows.remove(row)
        for selected_id in list(self.__selected_row_ids):
            if selected_id in row_ids:
                self.__selected_row_ids.remove(selected_id)

    def update_rows(self, rows):
        self.__rows_validator(rows)
        for row in rows:
            if row.get('selected', False):
                self.__selected_row_ids.append(row['id'])
        evaluate_js('updateCustomTableRows({ "id": "'
                    + str(self.__id)
                    + '", "rows": '
                    + json.dumps(rows)
                    + ', "type": "update" } )')
        # FLAG: the evidenced selection-sync tail (enumerate the
        # stored rows with the selected=False resets + the
        # __selected_row_ids add/remove maintenance) awaits the
        # raw tail pass \u2014 order below per the stream cluster.
        for index, row in enumerate(self.__rows):
            if row['id'] in self.__selected_row_ids:
                row['selected'] = True
            else:
                row['selected'] = False

    def insert_rows(self, rows, position):
        self.__rows_validator(rows)
        if not 0 <= position <= len(self.__rows):
            raise ValueError('Position is out of bounds')
        evaluate_js('updateCustomTableRows({ "id": "'
                    + str(self.__id)
                    + '", "rows": '
                    + json.dumps(rows)
                    + ', "type": "insert", "position": '
                    + str(position) + ' } )')
        self.__rows[position:position] = rows

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def table_row_selection_listener(row_id, selected):
    pass


# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def table_button_click_listener(onClick, row_id):
    pass


# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

def ui_element_instance_checker(element):
    if not isinstance(
            element,
            (UI.Button, UI.Text, UI.Input, UI.Image, UI.Toggle,
             UI.Select, UI.Checkbox, UI.Table)):
        raise ValueError(
            'Invalid element type provided. Cards can only hold '
            'Groups or UIElements. Groups can only hold '
            'UIElements or nested groups')


#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Group:

    def __init__(self, tab_updater, parent_tab_name, type,
                 parent_card=None, parent_group=None,
                 horizontal_align=None, vertical_align=None,
                 gap=None, full_width=None):
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__type = type
        self.__parent_card = parent_card
        self.__parent_group = parent_group
        self.__horizontal_align = horizontal_align
        self.__vertical_align = vertical_align
        self.__gap = gap
        self.__full_width = full_width
        self.__elements = []

    def create_group(self, type):
        group = Group(parent_group=self,
                      tab_updater=self.__tab_updater,
                      parent_tab_name=self.__parent_tab_name,
                      type=type)
        self.__elements.append(group)
        return group

    def create_ui_element(self, element):
        element_instance = element(
            parent_tab_name=self.__parent_tab_name,
            tab_updater=self.__tab_updater)
        ui_element_instance_checker(element_instance)
        self.__elements.append(element_instance)
        return element_instance

    def render(self):
        if self.__type not in ('columns_group', 'rows_group'):
            raise ValueError("Group type must be either "
                            "'columns' or 'rows'")
        return {
            'id': str(self.__id),
            'type': self.__type,
            'gap': self.__gap,
            'full_width': self.__full_width,
            'horizontal_align': self.__horizontal_align,
            'vertical_align': self.__vertical_align,
            'elements': [element.render()
                         for element in self.__elements],
        }

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class CardContainer:

    def __init__(self, parent_tab, tab_updater, parent_tab_name,
                 type, height, width, gap):
        if not isinstance(parent_tab, (Tab, CardContainer)):
            raise ValueError('Containers can only be created '
                             'by the Tab or CardContainer class.')
        if type not in ('columns', 'rows'):
            raise ValueError("Container type must be either "
                             "'columns' or 'rows'")
        self.__id = uuid.uuid4()
        self.__tab_updater = tab_updater
        self.__height = height
        self.__width = width
        self.__gap = gap
        self.__parent_tab_name = parent_tab_name
        self.__elements = []
        self.__type = type
        variant_validator(AVAILABLE_HW, self.__height)
        variant_validator(AVAILABLE_HW, self.__width)

    def create_container(self, type):
        container = CardContainer(
            parent_tab=self,
            tab_updater=self.__tab_updater,
            parent_tab_name=self.__parent_tab_name,
            type=type)
        self.__elements.append(container)
        return container

    def create_card(self, type):
        card = Card(
            parent_container=self,
            tab_updater=self.__tab_updater,
            parent_tab_name=self.__parent_tab_name)
        self.__elements.append(card)
        return card

    def render(self):
        return {
            'id': str(self.__id),
            'type': self.__type,
            'height': self.__height,
            'width': self.__width,
            'gap': self.__gap,
            'elements': [element.render()
                         for element in self.__elements],
        }

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Card:

    def __init__(self, parent_container, tab_updater,
                 parent_tab_name, height, width, vertical_align,
                 horizontal_align, gap, disallow_shrink):
        if not isinstance(parent_container, CardContainer):
            raise ValueError('Card must be created by a '
                             'CardContainer.')
        self.__id = uuid.uuid4()
        self.__type = 'card'
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__height = height
        self.__width = width
        self.__vertical_align = vertical_align
        self.__horizontal_align = horizontal_align
        self.__gap = gap
        self.__elements = []
        self.__disallow_shrink = disallow_shrink
        variant_validator(AVAILABLE_HW, self.__height)
        variant_validator(AVAILABLE_HW, self.__width)
        variant_validator(VALID_ALIGN, self.__vertical_align)
        variant_validator(VALID_ALIGN, self.__horizontal_align)
        _gap_validator(self.__gap)

    def create_group(self, type):
        group = Group(parent_card=self,
                      tab_updater=self.__tab_updater,
                      parent_tab_name=self.__parent_tab_name,
                      type=type)
        self.__elements.append(group)
        return group

    def create_ui_element(self, element):
        element_instance = element(
            parent_tab_name=self.__parent_tab_name,
            tab_updater=self.__tab_updater)
        ui_element_instance_checker(element_instance)
        self.__elements.append(element_instance)
        return element_instance

    def render(self):
        return {
            'id': self.__id,
            'type': self.__type,
            'height': self.__height,
            'width': self.__width,
            'gap': self.__gap,
            'vertical_align': self.__vertical_align,
            'horizontal_align': self.__horizontal_align,
            'elements': [element.render()
                         for element in self.__elements],
            'disallow_shrink': self.__disallow_shrink,
        }

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------


#----------------------------------------------------------------------------

class Tab:

    def __init__(self, name, icon, gap, title):
        self.__rendered = False
        self.__name = name
        self.__icon = icon
        self.__gap = gap
        self.__title = title
        self.__card_containers = []
        self.__debounce_timer = None

    def __validate_name(self, name):
        if not name:
            raise ValueError('Tab name cannot be empty')
        if len(name) > 36:
            raise ValueError('Tab name cannot exceed 36 '
                             'characters')
        return name

    def create_container(self, type):
        container = CardContainer(
            parent_tab=self,
            tab_updater=self.__update,
            parent_tab_name=self.__name,
            type=type)
        self.__card_containers.append(container)
        return container

    def toast(self, title, description, type):
        if not title:
            raise ValueError('Toast title cannot be empty')
        if not description:
            raise ValueError('Toast description cannot be empty')
        if type not in ('INFO', 'SUCCESS', 'ERROR'):
            raise ValueError("Toast type must be either 'INFO', "
                             "'SUCCESS', or 'ERROR'")
        evaluate_js('showCustomUIToast({ type: "' + type
                    + '", title: "' + title
                    + '", description: "' + description
                    + '", tabName: "' + self.__name
                    + '" })')

    def __getFormattedData(self):
        data = {
            'name': self.__name,
            'icon': self.__icon,
            'card_containers': [
                container.render()
                for container in self.__card_containers
            ],
            'gap': self.__gap,
            'title': self.__title,
        }
        return json.dumps(data, indent=2)

    def __update(self):
        if self.__rendered:
            if self.__debounce_timer is not None:
                self.__debounce_timer.cancel()
            self.__debounce_timer = Timer(
                0.005, self.__perform_update)
            self.__debounce_timer.start()

    def __perform_update(self):
        evaluate_js('updateCustomUiTab('
                    + str(self.__getFormattedData()) + ')')

    def render(self):
        data = self.__getFormattedData()
        evaluate_js('addCustomTab('
                    + json.dumps(json.loads(data)) + ')')
        __custom_ui_tabs__.append(self.__getFormattedData())
        self.__rendered = True

# NOTE: recovery flag - see the native_core docstring
#----------------------------------------------------------------------------


class NightyUserApp(discord_bot.Client):
    # class __init__ (bot client). argc=1, stream 42 bytes / 21 instrs.
    # ANOMALIES:
    #  - stream byte at addr 22 is 0x8d (armor CALL_FUNCTION_KW variant); the D dump
    #    prints it as CALL_FUNCTION 2 / BUILD_LIST 2 depending on context, older
    #    fence44 dump decodes CALL_FUNCTION_KW 2. LOAD_CONST 1 sits immediately
    #    before it => kwargs call; const 1 is the armor-decoyed ('intents','status')
    #    keys tuple (consts-shape=['int'] = decoy).
    #  - super().__init__ is fetched with LOAD_ATTR (armor flipped LOAD_METHOD).
    def __init__(self):
        super().__init__(intents=discord_bot.Intents.all(), status=discord_bot.Status.online)  # 3941  # const-recovered (kw names)
        self.tree = app_commands.CommandTree(self)  # 3942

    ############################################################################

    # class __init__ (bot client). argc=1, stream 42 bytes / 21 instrs.
    # ANOMALIES:
    #  - stream byte at addr 22 is 0x8d (armor CALL_FUNCTION_KW variant); the D dump
    #    prints it as CALL_FUNCTION 2 / BUILD_LIST 2 depending on context, older
    #    fence44 dump decodes CALL_FUNCTION_KW 2. LOAD_CONST 1 sits immediately
    #    before it => kwargs call; const 1 is the armor-decoyed ('intents','status')
    #    keys tuple (consts-shape=['int'] = decoy).
    #  - super().__init__ is fetched with LOAD_ATTR (armor flipped LOAD_METHOD).
    def __init__(self):
        super().__init__(intents=discord_bot.Intents.all(), status=discord_bot.Status.online)  # 3941  # const-recovered (kw names)
        self.tree = app_commands.CommandTree(self)  # 3942
    # PENDING UNITS (fence45-46 vm-stream campaign; remaining below):
    # PENDING UNITS (fence45-46 vm-stream campaign; remaining below):
    # PENDING UNITS (fence45-46 vm-stream campaign; remaining below):
    #   - spp_caller (line 4, 438 bytes) [OTHER-CLASS]
    #----------------------------------------------------------------------------

    def updateLastSeen():
        bot.last_seen[bot.user.id] = datetime.now()


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def truncate_string(text, max_length):
        if len(text) <= max_length:
            return text
        return text[:max_length - 3] + '...'


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def convert_custom_emojis(message):
        if not isinstance(message, str):
            return message
        return re.sub(r'<a?:(\w+):\d+>', r':\1:', message)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getOS():
        if platform.system() == 'Windows':
            if int(platform.version().split('.')[2]) >= 22000:
                return 'Windows 11'
            return 'Windows 10'
        return f'{platform.system()} {platform.version()}'

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------


class SpacedLabel(QtWidgets.QLabel):
    # SpacedLabel.__init__ (QLabel subclass used by the toast). argc=5, stream 72
    # bytes / 36 instrs.
    # ANOMALIES:
    #  - byte 0x54 at addr 42 is the armor BINARY_OR remap (printed IMPORT_STAR);
    #    it is the '|' in AlignLeft | AlignTop.
    #  - parent default is inferred (argc only gives the parameter count).
    #  - stylesheet const is armor-decoyed; value below is a plausible literal.
    def __init__(self, text, line_height, max_width, parent=None):
        super().__init__(text, parent)  # 4022
        self.line_height = line_height  # 4023
        self.max_width = max_width  # 4024
        self.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)  # 4025
        self.setStyleSheet('background: transparent; border: none; color: white;')  # 4026  # const-recovered
        self.update_text(text)  # 4027
    #----------------------------------------------------------------------------

    def update_text(self, text):
        self.original_text = text
        self.setText(break_text_into_lines(self))

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def break_text_into_lines(self):
        font_metrics = QtGui.QFontMetrics(self.font())
        lines = []
        current_line = ''
        for item in self.original_text:
            if (font_metrics.horizontalAdvance
                    (current_line + item) < self.max_width):
                current_line = current_line + item
            else:
                lines.append(current_line)
                current_line = item
        if current_line:
            lines.append(current_line)
        return ('<div style="line-height:' + self.line_height
                + ';">' + '<br>'.join(lines) + '</div>')

    #----------------------------------------------------------------------------


class NightyHelpSelect(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, options):
        super().__init__(options=[discord_bot.SelectOption(**option) for option in options])

    ############################################################################

    # [confidence=low - see wave45 evidence]
    def __init__(self, options):
        super().__init__(options=[discord_bot.SelectOption(**option) for option in options])
    #----------------------------------------------------------------------------
    async def callback(self, interaction):
        if self.values[0] == "Private commands":
            await interaction.response.send_message("Private commands can be enabled or disabled using the **/private** command.\nTo force a specific command as private, you can use the **/forceprivate** command.",
              ephemeral=True)
        elif self.values[0] == "Context menus":
            await interaction.response.send_message("Context menus are Discord features accessible by right-clicking on a user and navigating to Apps -> Nighty -> Feature.\nYou can manage these features by adding or removing them with the **/contextmenu** command.",
              ephemeral=True)
        elif self.values[0] == "Edit Bot":
            await interaction.response.send_message("You can customize the bot to your liking using the **/appedit** command.",
              ephemeral=True)
        elif self.values[0] == "License key":
            await interaction.response.send_message(f"To retrieve your license key, use the **/whatsmykey** command.\nYour license key is: ```{getLicense()}```",
              ephemeral=True)
    #----------------------------------------------------------------------------


class NightyHelpView:  # line 4087
    # [confidence=low - see wave45 evidence]
    def __init__(self):
        super().__init__()
        self.add_item(NightyHelpSelect())

    ############################################################################

    # [confidence=low - see wave45 evidence]
    def __init__(self):
        super().__init__()
        self.add_item(NightyHelpSelect())


class ToastNotificationManager(QtCore.QObject):
    # NotificationManager.__init__ (owns notifications/notification_queue/side).
    # argc=2, stream 48 bytes / 24 instrs.
    # ANOMALIES:
    #  - opcode 0xb1 at addr 20/32 is the armor BUILD_LIST-0 variant (D dump prints
    #    NOP); it is the '[]' of the two empty-list assignments.
    #  - max_notifications const and the side default are armor-decoyed; values
    #    below are plausible literals.
    def __init__(self, side='right'):
        QtWidgets.QApplication.instance().focusChanged.connect(self.ensure_notifications_visible)  # 4094
        self.notifications = []  # 4095
        self.max_notifications = 3  # 4096  # const-recovered
        self.notification_queue = []  # 4097
        self.side = side  # 4098
    def ensure_notifications_visible(self):
        for notification in self.notifications:
            if not notification.isVisible():
                notification.show()
    def show_notification(self, message, logo_url, timeout, on_click,
                          type_, title, details, side):
        if len(self.notifications) < self.max_notifications:
            notification = ToastNotification(message, logo_url, timeout,
                                             on_click, type_, title, details,
                                             self, side)
            x_offset = notification.get_side_offset()
            y_offset = 10  # const-recovered
            notification.move(x_offset, y_offset)
            self.notifications.append(notification)
            notification.adjustSize()
            notification.show_notification()
            self.reposition_notifications()
            return notification
        self.notification_queue.append((message, logo_url, timeout, on_click,
                                        type_, title, details, side))
        return None
    # Class: ToastNotificationManager (bank dec_ToastNotificationManager.remove_notification).
    # Evidence: live_L4122.stream 34B / 17 instrs, all 17 resolved, zero opaque ops.
    # Opcode map used: 0x7c LOAD_FAST(std) / 0xc6 LOAD_ATTR / 0x87 COMPARE_OP(arg 6='in')
    #   / 0x72 POP_JUMP_IF_FALSE(std) / 0x76 LOAD_METHOD / 0xf8 CALL_METHOD
    #   / 0x10 POP_TOP(armor) / 0x64 LOAD_CONST(std) / 0x23 RETURN_VALUE(armor).
    # Jump convention: args are absolute in the FULL 66B code object; the stream is
    #   code[16:-16], so POP_JUMP_IF_FALSE 0x2e=46 -> stream offset 30 (the LOAD_CONST/
    #   RETURN_VALUE tail). This is the "bound violation" the translator flagged.
    # Consts: armor-stripped (dossier shows decoy int 329); c0 = None (terminal return).
    # Anomalies: none semantic. Plain 0x7c LOAD_FAST for self (no 0xc8 armor wrap here).
    # varnames (self, notification); names order verified by compile check.

    def remove_notification(self, notification):
        if notification in self.notifications:
            self.notifications.remove(notification)
            self.reposition_notifications()

    ############################################################################

    # Class: ToastNotificationManager (bank dec_ToastNotificationManager.remove_notification).
    # Evidence: live_L4122.stream 34B / 17 instrs, all 17 resolved, zero opaque ops.
    # Opcode map used: 0x7c LOAD_FAST(std) / 0xc6 LOAD_ATTR / 0x87 COMPARE_OP(arg 6='in')
    #   / 0x72 POP_JUMP_IF_FALSE(std) / 0x76 LOAD_METHOD / 0xf8 CALL_METHOD
    #   / 0x10 POP_TOP(armor) / 0x64 LOAD_CONST(std) / 0x23 RETURN_VALUE(armor).
    # Jump convention: args are absolute in the FULL 66B code object; the stream is
    #   code[16:-16], so POP_JUMP_IF_FALSE 0x2e=46 -> stream offset 30 (the LOAD_CONST/
    #   RETURN_VALUE tail). This is the "bound violation" the translator flagged.
    # Consts: armor-stripped (dossier shows decoy int 329); c0 = None (terminal return).
    # Anomalies: none semantic. Plain 0x7c LOAD_FAST for self (no 0xc8 armor wrap here).
    # varnames (self, notification); names order verified by compile check.

    def remove_notification(self, notification):
        if notification in self.notifications:
            self.notifications.remove(notification)
            self.reposition_notifications()


    def show_notification(self, message, logo_url, timeout, on_click,
                          type_, title, details, side):
        if len(self.notifications) < self.max_notifications:
            notification = ToastNotification(message, logo_url, timeout,
                                             on_click, type_, title, details,
                                             self, side)
            x_offset = notification.get_side_offset()
            y_offset = 10  # const-recovered
            notification.move(x_offset, y_offset)
            self.notifications.append(notification)
            notification.adjustSize()
            notification.show_notification()
            self.reposition_notifications()
            return notification
        self.notification_queue.append((message, logo_url, timeout, on_click,
                                        type_, title, details, side))
        return None


    def ensure_notifications_visible(self):
        for notification in self.notifications:
            if not notification.isVisible():
                notification.show()
    def reposition_notifications(self):
        y_offset = 10  # const-recovered
        for notification in self.notifications:
            notification.adjustSize()
            notification.slide_up(y_offset)
            y_offset -= notification.height() + 10  # const-recovered spacing


class ToastNotification(QtWidgets.QWidget):
    # ToastNotification-style QFrame toast widget __init__. argc=10, stream 1472
    # bytes / 736 instrs. Consts are armor-decoyed (bare ints); every inferred
    # literal is tagged '# const-recovered'. Statement order follows the resolved
    # disassembly exactly; trailing '# NNNN' = TRUE line-map statement line.
    #
    # ANOMALIES (stream-level, resolved by structure not raw jump args):
    #  - 0x8d = armor CALL_FUNCTION_KW (D dump prints CALL_FUNCTION/BUILD_LIST);
    #    a decoyed LOAD_CONST right before it is the kw-names tuple in each case
    #    (addWidget alignment=..., SpacedLabel line_height=..., set_icon_from_url
    #    size=..., super kwargs in L3940).
    #  - 0x54 = armor BINARY_OR remap (dumped as IMPORT_STAR): every '|' of Qt
    #    alignment flags / window hints / QFont style strategies.
    #  - 0xbc xx = 2-byte decoy inserted before most POP_JUMP_IF_FALSE (dumped as
    #    LOAD_DEREF __class__ / LOAD_DEREF 2). Semantically invisible.
    #  - jump-arg bytes are unreliable (e.g. addr 646 POP_JUMP_IF_FALSE arg 0xa4
    #    points mid-instruction; semantic target is addr 660). Control flow was
    #    taken from the if/elif statement shapes.
    #  - armor flips some LOAD_METHOD bytes to LOAD_ATTR (e.g. addWidget at 908,
    #    setWindowFlags chain at 4); both decode to plain attribute call source.
    #  - addr 1184-1192: 0xc4/0xc9/0xce = LOAD_CLOSURE 0 / BUILD_TUPLE 1 /
    #    MAKE_FUNCTION 8 => self.close_button.clicked.connect(<lambda capturing
    #    self>); the lambda body lives in decoyed const 39 and is NOT recoverable
    #    from this stream - 'self.close()' is the idiomatic guess.
    #  - lnotab is armor-scrambled mid-statement (4164 -> 4419 -> 4675 -> 4930).
    #  - setCursor(PointingHandCursor) appears twice (map 4963/4965) and the blur
    #    effect is set then replaced by the opacity effect (4966-4972): kept
    #    verbatim - it is what the stream says.
    #  - SpacedLabel kwarg name (const 30) and set_icon_from_url kwarg name
    #    (const 37) are decoyed; inferred from SpacedLabel.__init__ (L4021)
    #    varnames and call shape. Icon URLs / stylesheet texts / durations /
    #    colors are plausible literals, not captured values. Const-index identity
    #    constraints were preserved (e.g. type_icon default == INFO-branch icon
    #    share const 21; int 0 / float 0.0 / int 1 / float 1.0 kept distinct as
    #    the const table demands).
    def __init__(self, message, logo_url=None, timeout=5000, on_click=None,
                 type_=None, title=None, details=None, manager=None,
                 side='right'):
        super().__init__()  # 4143
        QtCore.QLoggingCategory.setFilterRules('*.debug=false\nqt.qpa.*=false')  # 4144  # const-recovered
        self.manager = manager  # 4146
        self.side = side  # 4147
        self.message = truncate_string(convert_custom_emojis(message), 150)  # 4148  # const-recovered
        self.title = truncate_string(convert_custom_emojis(title), 30) if title else type_  # 4149  # const-recovered
        if details:  # 4150
            self.details = truncate_string(convert_custom_emojis(details), 100)  # 4151  # const-recovered
        else:
            self.details = truncate_string(convert_custom_emojis(message), 100)  # 4153  # const-recovered
        self.logo_url = logo_url  # 4154
        self.type = type_  # 4155
        self.on_click = on_click  # 4156
        self.network_manager = QNetworkAccessManager(self)  # 4157
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint | QtCore.Qt.SplashScreen)  # 4162-4164
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)  # 4935
        self.setAttribute(QtCore.Qt.WA_ShowWithoutActivating)  # 4936
        self.setStyleSheet('QFrame { background: transparent; border-radius: 10px; }')  # 4937  # const-recovered
        self._bg_color = QtGui.QColor(0, 0, 0)  # 4939  # const-recovered
        self.setProperty('gradient', self._bg_color)  # 4940
        self._gradient_start = QtGui.QColor(0, 0, 0)  # 4942  # const-recovered
        self._gradient_end = QtGui.QColor(0, 0, 45)  # 4943  # const-recovered
        if self.type == 'SUCCESS':  # 4944
            self._gradient_end = QtGui.QColor(0, 45, 0)  # 4945  # const-recovered
        elif self.type == 'ERROR':  # 4946
            self._gradient_end = QtGui.QColor(45, 0, 0)  # 4947  # const-recovered
        self.hover_gradient_start = QtGui.QColor(0, 0, 0)  # 4950  # const-recovered
        self.hover_gradient_end = QtGui.QColor(60, 60, 60)  # 4951  # const-recovered
        self.is_hovered = False  # 4953
        self.gradient_in_animation = QPropertyAnimation(self, b'gradient')  # 4955  # const-recovered
        self.gradient_in_animation.setDuration(300)  # 4956  # const-recovered
        self.gradient_in_animation.setEndValue(self.hover_gradient_end)  # 4957
        self.gradient_out_animation = QPropertyAnimation(self, b'gradient')  # 4959  # const-recovered
        self.gradient_out_animation.setDuration(300)  # 4960  # const-recovered
        self.gradient_out_animation.setEndValue(self._gradient_end)  # 4961
        self.setCursor(QtCore.Qt.PointingHandCursor)  # 4963
        self.setCursor(QtCore.Qt.PointingHandCursor)  # 4965 (duplicate in stream - kept)
        self.blur_effect = QtWidgets.QGraphicsBlurEffect()  # 4966
        self.blur_effect.setBlurRadius(20)  # 4967  # const-recovered
        self.setGraphicsEffect(self.blur_effect)  # 4968
        self.opacity_effect = QtWidgets.QGraphicsOpacityEffect(self)  # 4970
        self.setGraphicsEffect(self.opacity_effect)  # 4971
        self.opacity_effect.setOpacity(0.0)  # 4972
        self.fade_in_animation = QtCore.QPropertyAnimation(self.opacity_effect, b'opacity')  # 4974  # const-recovered
        self.fade_in_animation.setDuration(300)  # 4975  # const-recovered
        self.fade_in_animation.setStartValue(0.0)  # 4976
        self.fade_in_animation.setEndValue(1.0)  # 4977
        layout = QtWidgets.QHBoxLayout(self)  # 4979
        layout.setContentsMargins(10, 10, 10, 10)  # 4980  # const-recovered
        self.logo_label = QtWidgets.QLabel()  # 4982
        self.logo_label.setStyleSheet('background: transparent; border: none;')  # 4983  # const-recovered
        if self.logo_url:  # 4984
            self.load_logo(self.logo_url)  # 4985
        layout.addWidget(self.logo_label)  # 4987
        title_layout = QtWidgets.QHBoxLayout()  # 4988
        text_layout = QtWidgets.QVBoxLayout()  # 4989
        text_layout.setContentsMargins(10, 0, 10, 10)  # 4990  # const-recovered
        title_layout.setContentsMargins(10, 10, 10, 0)  # 4991  # const-recovered
        title_layout.setSpacing(0)  # 4992
        self.type_button = QtWidgets.QPushButton(self)  # 4994
        type_icon = 'https://nighty.one/img/info.png'  # 4995  # const-recovered
        if self.type == 'INFO':  # 4996
            type_icon = 'https://nighty.one/img/info.png'  # 4997  # const-recovered (same const idx as default)
        elif self.type == 'SUCCESS':  # 4998
            type_icon = 'https://nighty.one/img/success.png'  # 4999  # const-recovered
        elif self.type == 'ERROR':  # 5000
            type_icon = 'https://nighty.one/img/error.png'  # 5001  # const-recovered
        self.set_icon_from_url(self.type_button, type_icon)  # 5003
        self.title_label = QtWidgets.QLabel(self.title)  # 5008
        font = QtGui.QFont('Segoe UI')  # 5009  # const-recovered
        font.setPointSize(11)  # 5010  # const-recovered
        font.setStyleStrategy(QtGui.QFont.PreferAntialias | QtGui.QFont.PreferQuality)  # 5011
        font.setWeight(QtGui.QFont.Bold)  # 5012
        self.title_label.setFont(font)  # 5013
        self.title_label.setStyleSheet('color: white; background: transparent;')  # 5014  # const-recovered
        title_layout.addWidget(self.type_button, alignment=QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)  # 5015
        title_layout.addWidget(self.title_label, alignment=QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)  # 5016
        title_layout.addStretch(1)  # 5017
        text_layout.addStretch(1)  # 5019
        text_layout.addLayout(title_layout)  # 5020
        self.message_label = SpacedLabel(self.message, line_height=1)  # 5022  # const-recovered (kw name+value decoyed)
        font = QtGui.QFont('Segoe UI')  # 5023  # const-recovered
        font.setPointSize(9)  # 5024  # const-recovered
        font.setStyleStrategy(QtGui.QFont.PreferAntialias | QtGui.QFont.PreferQuality)  # 5025
        font.setWeight(QtGui.QFont.Normal)  # 5026
        self.message_label.setFont(font)  # 5027
        self.message_label.setStyleSheet('color: #cccccc; background: transparent;')  # 5028  # const-recovered
        self.message_label.setWordWrap(True)  # 5029
        self.message_label.setFixedWidth(360)  # 5030  # const-recovered
        text_layout.addWidget(self.message_label)  # 5031
        layout.addLayout(text_layout)  # 5033
        self.close_button = QtWidgets.QPushButton(self)  # 5035
        self.set_icon_from_url(self.close_button, 'https://nighty.one/img/close.png', size=14)  # 5036  # const-recovered
        self.close_button.setStyleSheet('QPushButton { background: transparent; border: none; color: white; }')  # 5040  # const-recovered
        self.close_button.clicked.connect(lambda: self.close())  # 5049 (lambda body is decoyed const - inferred)
        layout.addWidget(self.close_button, alignment=QtCore.Qt.AlignTop | QtCore.Qt.AlignRight)  # 5050
        self.adjustSize()  # 5052
        self.setMaximumHeight(self.MAX_HEIGHT)  # 5054
        current_height = self.sizeHint().height()  # 5056
        self.setFixedHeight(current_height)  # 5057
        self.layout().invalidate()  # 5058
        desktop = QtWidgets.QApplication.desktop()  # 5060
        screen_number = desktop.screenNumber(QtGui.QCursor.pos())  # 5061
        self.primary_geometry = desktop.screenGeometry(screen_number)  # 5062
        self.animation = QtCore.QPropertyAnimation(self, b'pos')  # 5065  # const-recovered
        self.animation.setDuration(400)  # 5066  # const-recovered
        self.animation.setEasingCurve(QtCore.QEasingCurve.OutQuart)  # 5067
        self.fade_out_timer = QtCore.QTimer(self)  # 5070
        self.fade_out_timer.setInterval(timeout)  # 5071
        self.fade_out_timer.timeout.connect(self.start_fade_out)  # 5072
        self.fade_animation = QtCore.QPropertyAnimation(self.opacity_effect, b'opacity')  # 5074  # const-recovered
        self.fade_animation.setDuration(300)  # 5075  # const-recovered
        self.fade_animation.setStartValue(1)  # 5076
        self.fade_animation.setEndValue(0)  # 5077
        self.fade_animation.finished.connect(self.close_and_remove)  # 5078

    ############################################################################

    # ToastNotification-style QFrame toast widget __init__. argc=10, stream 1472
    # bytes / 736 instrs. Consts are armor-decoyed (bare ints); every inferred
    # literal is tagged '# const-recovered'. Statement order follows the resolved
    # disassembly exactly; trailing '# NNNN' = TRUE line-map statement line.
    #
    # ANOMALIES (stream-level, resolved by structure not raw jump args):
    #  - 0x8d = armor CALL_FUNCTION_KW (D dump prints CALL_FUNCTION/BUILD_LIST);
    #    a decoyed LOAD_CONST right before it is the kw-names tuple in each case
    #    (addWidget alignment=..., SpacedLabel line_height=..., set_icon_from_url
    #    size=..., super kwargs in L3940).
    #  - 0x54 = armor BINARY_OR remap (dumped as IMPORT_STAR): every '|' of Qt
    #    alignment flags / window hints / QFont style strategies.
    #  - 0xbc xx = 2-byte decoy inserted before most POP_JUMP_IF_FALSE (dumped as
    #    LOAD_DEREF __class__ / LOAD_DEREF 2). Semantically invisible.
    #  - jump-arg bytes are unreliable (e.g. addr 646 POP_JUMP_IF_FALSE arg 0xa4
    #    points mid-instruction; semantic target is addr 660). Control flow was
    #    taken from the if/elif statement shapes.
    #  - armor flips some LOAD_METHOD bytes to LOAD_ATTR (e.g. addWidget at 908,
    #    setWindowFlags chain at 4); both decode to plain attribute call source.
    #  - addr 1184-1192: 0xc4/0xc9/0xce = LOAD_CLOSURE 0 / BUILD_TUPLE 1 /
    #    MAKE_FUNCTION 8 => self.close_button.clicked.connect(<lambda capturing
    #    self>); the lambda body lives in decoyed const 39 and is NOT recoverable
    #    from this stream - 'self.close()' is the idiomatic guess.
    #  - lnotab is armor-scrambled mid-statement (4164 -> 4419 -> 4675 -> 4930).
    #  - setCursor(PointingHandCursor) appears twice (map 4963/4965) and the blur
    #    effect is set then replaced by the opacity effect (4966-4972): kept
    #    verbatim - it is what the stream says.
    #  - SpacedLabel kwarg name (const 30) and set_icon_from_url kwarg name
    #    (const 37) are decoyed; inferred from SpacedLabel.__init__ (L4021)
    #    varnames and call shape. Icon URLs / stylesheet texts / durations /
    #    colors are plausible literals, not captured values. Const-index identity
    #    constraints were preserved (e.g. type_icon default == INFO-branch icon
    #    share const 21; int 0 / float 0.0 / int 1 / float 1.0 kept distinct as
    #    the const table demands).
    def __init__(self, message, logo_url=None, timeout=5000, on_click=None,
                 type_=None, title=None, details=None, manager=None,
                 side='right'):
        super().__init__()  # 4143
        QtCore.QLoggingCategory.setFilterRules('*.debug=false\nqt.qpa.*=false')  # 4144  # const-recovered
        self.manager = manager  # 4146
        self.side = side  # 4147
        self.message = truncate_string(convert_custom_emojis(message), 150)  # 4148  # const-recovered
        self.title = truncate_string(convert_custom_emojis(title), 30) if title else type_  # 4149  # const-recovered
        if details:  # 4150
            self.details = truncate_string(convert_custom_emojis(details), 100)  # 4151  # const-recovered
        else:
            self.details = truncate_string(convert_custom_emojis(message), 100)  # 4153  # const-recovered
        self.logo_url = logo_url  # 4154
        self.type = type_  # 4155
        self.on_click = on_click  # 4156
        self.network_manager = QNetworkAccessManager(self)  # 4157
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint | QtCore.Qt.SplashScreen)  # 4162-4164
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)  # 4935
        self.setAttribute(QtCore.Qt.WA_ShowWithoutActivating)  # 4936
        self.setStyleSheet('QFrame { background: transparent; border-radius: 10px; }')  # 4937  # const-recovered
        self._bg_color = QtGui.QColor(0, 0, 0)  # 4939  # const-recovered
        self.setProperty('gradient', self._bg_color)  # 4940
        self._gradient_start = QtGui.QColor(0, 0, 0)  # 4942  # const-recovered
        self._gradient_end = QtGui.QColor(0, 0, 45)  # 4943  # const-recovered
        if self.type == 'SUCCESS':  # 4944
            self._gradient_end = QtGui.QColor(0, 45, 0)  # 4945  # const-recovered
        elif self.type == 'ERROR':  # 4946
            self._gradient_end = QtGui.QColor(45, 0, 0)  # 4947  # const-recovered
        self.hover_gradient_start = QtGui.QColor(0, 0, 0)  # 4950  # const-recovered
        self.hover_gradient_end = QtGui.QColor(60, 60, 60)  # 4951  # const-recovered
        self.is_hovered = False  # 4953
        self.gradient_in_animation = QPropertyAnimation(self, b'gradient')  # 4955  # const-recovered
        self.gradient_in_animation.setDuration(300)  # 4956  # const-recovered
        self.gradient_in_animation.setEndValue(self.hover_gradient_end)  # 4957
        self.gradient_out_animation = QPropertyAnimation(self, b'gradient')  # 4959  # const-recovered
        self.gradient_out_animation.setDuration(300)  # 4960  # const-recovered
        self.gradient_out_animation.setEndValue(self._gradient_end)  # 4961
        self.setCursor(QtCore.Qt.PointingHandCursor)  # 4963
        self.setCursor(QtCore.Qt.PointingHandCursor)  # 4965 (duplicate in stream - kept)
        self.blur_effect = QtWidgets.QGraphicsBlurEffect()  # 4966
        self.blur_effect.setBlurRadius(20)  # 4967  # const-recovered
        self.setGraphicsEffect(self.blur_effect)  # 4968
        self.opacity_effect = QtWidgets.QGraphicsOpacityEffect(self)  # 4970
        self.setGraphicsEffect(self.opacity_effect)  # 4971
        self.opacity_effect.setOpacity(0.0)  # 4972
        self.fade_in_animation = QtCore.QPropertyAnimation(self.opacity_effect, b'opacity')  # 4974  # const-recovered
        self.fade_in_animation.setDuration(300)  # 4975  # const-recovered
        self.fade_in_animation.setStartValue(0.0)  # 4976
        self.fade_in_animation.setEndValue(1.0)  # 4977
        layout = QtWidgets.QHBoxLayout(self)  # 4979
        layout.setContentsMargins(10, 10, 10, 10)  # 4980  # const-recovered
        self.logo_label = QtWidgets.QLabel()  # 4982
        self.logo_label.setStyleSheet('background: transparent; border: none;')  # 4983  # const-recovered
        if self.logo_url:  # 4984
            self.load_logo(self.logo_url)  # 4985
        layout.addWidget(self.logo_label)  # 4987
        title_layout = QtWidgets.QHBoxLayout()  # 4988
        text_layout = QtWidgets.QVBoxLayout()  # 4989
        text_layout.setContentsMargins(10, 0, 10, 10)  # 4990  # const-recovered
        title_layout.setContentsMargins(10, 10, 10, 0)  # 4991  # const-recovered
        title_layout.setSpacing(0)  # 4992
        self.type_button = QtWidgets.QPushButton(self)  # 4994
        type_icon = 'https://nighty.one/img/info.png'  # 4995  # const-recovered
        if self.type == 'INFO':  # 4996
            type_icon = 'https://nighty.one/img/info.png'  # 4997  # const-recovered (same const idx as default)
        elif self.type == 'SUCCESS':  # 4998
            type_icon = 'https://nighty.one/img/success.png'  # 4999  # const-recovered
        elif self.type == 'ERROR':  # 5000
            type_icon = 'https://nighty.one/img/error.png'  # 5001  # const-recovered
        self.set_icon_from_url(self.type_button, type_icon)  # 5003
        self.title_label = QtWidgets.QLabel(self.title)  # 5008
        font = QtGui.QFont('Segoe UI')  # 5009  # const-recovered
        font.setPointSize(11)  # 5010  # const-recovered
        font.setStyleStrategy(QtGui.QFont.PreferAntialias | QtGui.QFont.PreferQuality)  # 5011
        font.setWeight(QtGui.QFont.Bold)  # 5012
        self.title_label.setFont(font)  # 5013
        self.title_label.setStyleSheet('color: white; background: transparent;')  # 5014  # const-recovered
        title_layout.addWidget(self.type_button, alignment=QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)  # 5015
        title_layout.addWidget(self.title_label, alignment=QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)  # 5016
        title_layout.addStretch(1)  # 5017
        text_layout.addStretch(1)  # 5019
        text_layout.addLayout(title_layout)  # 5020
        self.message_label = SpacedLabel(self.message, line_height=1)  # 5022  # const-recovered (kw name+value decoyed)
        font = QtGui.QFont('Segoe UI')  # 5023  # const-recovered
        font.setPointSize(9)  # 5024  # const-recovered
        font.setStyleStrategy(QtGui.QFont.PreferAntialias | QtGui.QFont.PreferQuality)  # 5025
        font.setWeight(QtGui.QFont.Normal)  # 5026
        self.message_label.setFont(font)  # 5027
        self.message_label.setStyleSheet('color: #cccccc; background: transparent;')  # 5028  # const-recovered
        self.message_label.setWordWrap(True)  # 5029
        self.message_label.setFixedWidth(360)  # 5030  # const-recovered
        text_layout.addWidget(self.message_label)  # 5031
        layout.addLayout(text_layout)  # 5033
        self.close_button = QtWidgets.QPushButton(self)  # 5035
        self.set_icon_from_url(self.close_button, 'https://nighty.one/img/close.png', size=14)  # 5036  # const-recovered
        self.close_button.setStyleSheet('QPushButton { background: transparent; border: none; color: white; }')  # 5040  # const-recovered
        self.close_button.clicked.connect(lambda: self.close())  # 5049 (lambda body is decoyed const - inferred)
        layout.addWidget(self.close_button, alignment=QtCore.Qt.AlignTop | QtCore.Qt.AlignRight)  # 5050
        self.adjustSize()  # 5052
        self.setMaximumHeight(self.MAX_HEIGHT)  # 5054
        current_height = self.sizeHint().height()  # 5056
        self.setFixedHeight(current_height)  # 5057
        self.layout().invalidate()  # 5058
        desktop = QtWidgets.QApplication.desktop()  # 5060
        screen_number = desktop.screenNumber(QtGui.QCursor.pos())  # 5061
        self.primary_geometry = desktop.screenGeometry(screen_number)  # 5062
        self.animation = QtCore.QPropertyAnimation(self, b'pos')  # 5065  # const-recovered
        self.animation.setDuration(400)  # 5066  # const-recovered
        self.animation.setEasingCurve(QtCore.QEasingCurve.OutQuart)  # 5067
        self.fade_out_timer = QtCore.QTimer(self)  # 5070
        self.fade_out_timer.setInterval(timeout)  # 5071
        self.fade_out_timer.timeout.connect(self.start_fade_out)  # 5072
        self.fade_animation = QtCore.QPropertyAnimation(self.opacity_effect, b'opacity')  # 5074  # const-recovered
        self.fade_animation.setDuration(300)  # 5075  # const-recovered
        self.fade_animation.setStartValue(1)  # 5076
        self.fade_animation.setEndValue(0)  # 5077
        self.fade_animation.finished.connect(self.close_and_remove)  # 5078
    # Class: ToastNotification (bank dec_ToastNotification.get_side_offset).
    # Evidence: live_L4312.stream 60B / 30 instrs, all 30 resolved, zero opaque ops.
    # Structure (offsets stream-relative):
    #   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) side ; 4 LOAD_CONST c1 ; 6 COMPARE_OP(0x87)==
    #   8  POP_JUMP_IF_FALSE 0x28=40 (full-code abs; -16 -> stream 24)
    #   10 self.primary_geometry ; 14 LOAD_METHOD(0x76) x ; 16 CALL_METHOD(0xf8)0
    #   18 LOAD_CONST c2 ; 20 op 0x12 = BINARY_ADD (armor slot; std 18 undefined)
    #   22 RETURN_VALUE(0x23)
    #   24 if side == c3 ; 32 PJIF 0x48=72 -> stream 56 (fall-through return)
    #   34 self.primary_geometry.width() ; 42 self.width() ; 48 op 0x4c = BINARY_SUBTRACT
    #   (armor slot; std 76=INPLACE_RSHIFT nonsensical here) ; 50 c2 ; 52 0x4c again
    #   54 RETURN ; 56 LOAD_CONST c4 (None) ; 58 RETURN  (implicit tail return)
    # Consts: armor-stripped (decoy int 333). c1/c3 = side tags: branch1 anchors at
    #   primary_geometry.x() + margin -> 'left'; branch2 anchors at width-width-margin
    #   -> 'right' (inferred, values not recoverable). c2 = margin (20 assumed).
    #   c4 = None. Original had a blank/comment line 4313 (lnotab gap).
    # Anomalies: none. names dedup: 'width' indexes both QGeometry and QWidget call.

    def get_side_offset(self):
        # (line 4313: blank/comment in original - lnotab gap)

        if self.side == 'left':
            return self.primary_geometry.x() + 20
        if self.side == 'right':
            return self.primary_geometry.width() - self.width() - 20
    def set_icon_from_url(self, button, url, size):
        manager = QNetworkAccessManager(self)
        request = QNetworkRequest(QUrl(url))
        loop = QtCore.QEventLoop()
        reply = manager.get(request)
        reply.finished.connect(loop.quit)
        loop.exec_()
        if reply.error() == reply.NoError:
            pixmap = QPixmap()
            pixmap.loadFromData(reply.readAll())
            button.setIcon(QtGui.QIcon(pixmap))
            button.setIconSize(QtCore.QSize(size * 0.8, size * 0.8))  # const-recovered
        else:
            sys.stdout.write(f'Error loading icon: {reply.errorString()}\n')  # const-recovered
    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(0, 0, self.width(), 0)  # const-recovered
        gradient.setColorAt(0.0, self._gradient_start)  # const-recovered
        gradient.setColorAt(1.0, self._gradient_end)  # const-recovered
        painter.setBrush(QtGui.QBrush(gradient))
        painter.setPen(QtCore.Qt.NoPen)
        painter.drawRoundedRect(self.rect(), 10, 10)  # const-recovered
    def enterEvent(self, event):
        self.fade_out_timer.stop()
        self.is_hovered = True  # const-recovered
        self.gradient_out_animation.stop()
        self.gradient_in_animation.start()
        if self.details:
            self.message_label.setText(self.details)
            self.adjust_notification_size()
        super().enterEvent(event)

    ############################################################################

    def enterEvent(self, event):
        self.fade_out_timer.stop()
        self.is_hovered = True  # const-recovered
        self.gradient_out_animation.stop()
        self.gradient_in_animation.start()
        if self.details:
            self.message_label.setText(self.details)
            self.adjust_notification_size()
        super().enterEvent(event)


    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(0, 0, self.width(), 0)  # const-recovered
        gradient.setColorAt(0.0, self._gradient_start)  # const-recovered
        gradient.setColorAt(1.0, self._gradient_end)  # const-recovered
        painter.setBrush(QtGui.QBrush(gradient))
        painter.setPen(QtCore.Qt.NoPen)
        painter.drawRoundedRect(self.rect(), 10, 10)  # const-recovered


    def set_icon_from_url(self, button, url, size):
        manager = QNetworkAccessManager(self)
        request = QNetworkRequest(QUrl(url))
        loop = QtCore.QEventLoop()
        reply = manager.get(request)
        reply.finished.connect(loop.quit)
        loop.exec_()
        if reply.error() == reply.NoError:
            pixmap = QPixmap()
            pixmap.loadFromData(reply.readAll())
            button.setIcon(QtGui.QIcon(pixmap))
            button.setIconSize(QtCore.QSize(size * 0.8, size * 0.8))  # const-recovered
        else:
            sys.stdout.write(f'Error loading icon: {reply.errorString()}\n')  # const-recovered


    # Class: ToastNotification (bank dec_ToastNotification.get_side_offset).
    # Evidence: live_L4312.stream 60B / 30 instrs, all 30 resolved, zero opaque ops.
    # Structure (offsets stream-relative):
    #   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) side ; 4 LOAD_CONST c1 ; 6 COMPARE_OP(0x87)==
    #   8  POP_JUMP_IF_FALSE 0x28=40 (full-code abs; -16 -> stream 24)
    #   10 self.primary_geometry ; 14 LOAD_METHOD(0x76) x ; 16 CALL_METHOD(0xf8)0
    #   18 LOAD_CONST c2 ; 20 op 0x12 = BINARY_ADD (armor slot; std 18 undefined)
    #   22 RETURN_VALUE(0x23)
    #   24 if side == c3 ; 32 PJIF 0x48=72 -> stream 56 (fall-through return)
    #   34 self.primary_geometry.width() ; 42 self.width() ; 48 op 0x4c = BINARY_SUBTRACT
    #   (armor slot; std 76=INPLACE_RSHIFT nonsensical here) ; 50 c2 ; 52 0x4c again
    #   54 RETURN ; 56 LOAD_CONST c4 (None) ; 58 RETURN  (implicit tail return)
    # Consts: armor-stripped (decoy int 333). c1/c3 = side tags: branch1 anchors at
    #   primary_geometry.x() + margin -> 'left'; branch2 anchors at width-width-margin
    #   -> 'right' (inferred, values not recoverable). c2 = margin (20 assumed).
    #   c4 = None. Original had a blank/comment line 4313 (lnotab gap).
    # Anomalies: none. names dedup: 'width' indexes both QGeometry and QWidget call.

    def get_side_offset(self):
        # (line 4313: blank/comment in original - lnotab gap)

        if self.side == 'left':
            return self.primary_geometry.x() + 20
        if self.side == 'right':
            return self.primary_geometry.width() - self.width() - 20
    def leaveEvent(self, event):
        self.fade_out_timer.start()
        self.is_hovered = False  # const-recovered
        self.gradient_in_animation.stop()
        self.gradient_out_animation.start()
        if self.details:
            self.message_label.setText(self.message.replace('\n', '<br>'))  # const-recovered
            self.adjust_notification_size()
        super().leaveEvent(event)
    def adjust_notification_size(self):
        self.adjustSize()
        new_height = self.sizeHint().height()
        self.setFixedHeight(new_height)
        self.layout().invalidate()
        self.manager.reposition_notifications()
    # Class: ToastNotification (bank dec_ToastNotification.slide_up).
    # Evidence: live_L4411.stream 134B / 67 instrs, all 67 resolved, zero opaque ops.
    # Key offsets (stream-relative; jump args are full-code coords, code = 166B,
    # stream = code[16:-16], so subtract 16):
    #   0   self.animation.stop()
    #   10  if self.side == c1:  (COMPARE_OP 0x87 arg2 '=='; PJIF 0x4e=78 -> stream 62)
    #   20  self.animation.setStartValue(self.pos())
    #   36  self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    #   60  JUMP_FORWARD(0xf1) delta 0x3a=58: full 76+2+58=136 -> stream 120 (start())
    #   62  elif self.side == c2:  (PJIF 0x88=136 -> stream 120)
    #   72  self.animation.setStartValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    #   96  self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    #   120 self.animation.start() ; 130 LOAD_CONST None ; 132 RETURN_VALUE
    # Consts: armor-stripped (decoy int 346); c1/c2 = side tags 'left'/'right'
    #   (inferred, consistent with get_side_offset L4312 branch order); c0 = None.
    # ANOMALY (stream-faithful): in the elif branch setStartValue and setEndValue
    #   receive the IDENTICAL QtCore.QPoint(self.get_side_offset(), y_offset)
    #   expression - the two 12-instruction blocks differ ONLY in method index
    #   (0x7603 setStartValue vs 0x7605 setEndValue). The animation is therefore a
    #   no-op for that side; reproduced literally, likely an original-source
    #   copy-paste artifact (start value probably meant to be self.pos()).
    # names order (animation, stop, side, setStartValue, pos, setEndValue, QtCore,
    #   QPoint, get_side_offset, start) round-trips exactly - confirms branch order.

    def slide_up(self, y_offset):
        self.animation.stop()
        if self.side == 'left':
            self.animation.setStartValue(self.pos())
            self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
        elif self.side == 'right':
            self.animation.setStartValue(QtCore.QPoint(self.get_side_offset(), y_offset))
            self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
        self.animation.start()
    def load_logo(self, url):
        self.network_manager.finished.connect(self.on_image_loaded)
        request = QNetworkRequest(QUrl(url))
        self.network_manager.get(request)

    ############################################################################

    def load_logo(self, url):
        self.network_manager.finished.connect(self.on_image_loaded)
        request = QNetworkRequest(QUrl(url))
        self.network_manager.get(request)


    # Class: ToastNotification (bank dec_ToastNotification.slide_up).
    # Evidence: live_L4411.stream 134B / 67 instrs, all 67 resolved, zero opaque ops.
    # Key offsets (stream-relative; jump args are full-code coords, code = 166B,
    # stream = code[16:-16], so subtract 16):
    #   0   self.animation.stop()
    #   10  if self.side == c1:  (COMPARE_OP 0x87 arg2 '=='; PJIF 0x4e=78 -> stream 62)
    #   20  self.animation.setStartValue(self.pos())
    #   36  self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    #   60  JUMP_FORWARD(0xf1) delta 0x3a=58: full 76+2+58=136 -> stream 120 (start())
    #   62  elif self.side == c2:  (PJIF 0x88=136 -> stream 120)
    #   72  self.animation.setStartValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    #   96  self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
    #   120 self.animation.start() ; 130 LOAD_CONST None ; 132 RETURN_VALUE
    # Consts: armor-stripped (decoy int 346); c1/c2 = side tags 'left'/'right'
    #   (inferred, consistent with get_side_offset L4312 branch order); c0 = None.
    # ANOMALY (stream-faithful): in the elif branch setStartValue and setEndValue
    #   receive the IDENTICAL QtCore.QPoint(self.get_side_offset(), y_offset)
    #   expression - the two 12-instruction blocks differ ONLY in method index
    #   (0x7603 setStartValue vs 0x7605 setEndValue). The animation is therefore a
    #   no-op for that side; reproduced literally, likely an original-source
    #   copy-paste artifact (start value probably meant to be self.pos()).
    # names order (animation, stop, side, setStartValue, pos, setEndValue, QtCore,
    #   QPoint, get_side_offset, start) round-trips exactly - confirms branch order.

    def slide_up(self, y_offset):
        self.animation.stop()
        if self.side == 'left':
            self.animation.setStartValue(self.pos())
            self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
        elif self.side == 'right':
            self.animation.setStartValue(QtCore.QPoint(self.get_side_offset(), y_offset))
            self.animation.setEndValue(QtCore.QPoint(self.get_side_offset(), y_offset))
        self.animation.start()
    # [confidence=medium - see wave45 evidence]
    def on_image_loaded(self, reply):
        if reply.error() == reply.NoError:
            pixmap = QPixmap()
            pixmap.loadFromData(reply.readAll())
            self.logo_label.setPixmap(pixmap.scaled(32, 32,  # const-recovered
                                                    QtCore.Qt.KeepAspectRatio,
                                                    QtCore.Qt.SmoothTransformation))
            reply.deleteLater()
    def show_notification(self):
        self.show()
        self.fade_in_animation.start()
        self.fade_out_timer.start()
    def start_fade_out(self):
        self.fade_out_timer.stop()
        self.fade_animation.start()
    def close_and_remove(self):
        self.manager.remove_notification(self)
        self.close()

    ############################################################################

    def close_and_remove(self):
        self.manager.remove_notification(self)
        self.close()


    def start_fade_out(self):
        self.fade_out_timer.stop()
        self.fade_animation.start()


    def show_notification(self):
        self.show()
        self.fade_in_animation.start()
        self.fade_out_timer.start()
    # Class: ToastNotification (bank dec_ToastNotification.mousePressEvent).
    # Evidence: live_L4446.stream 46B / 23 instrs, all 23 resolved, zero opaque ops.
    # Key offsets (stream-relative; jump args full-code coords, code=62B, -16 shift):
    #   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) close_button ; 4 LOAD_METHOD(0x76) geometry
    #   6  CALL_METHOD(0xf8)0 ; 8 LOAD_METHOD contains ; 10 event ;
    #   12 LOAD_METHOD pos ; 14 CALL_METHOD0 ; 16 CALL_METHOD1 ; 18 POP_JUMP_IF_FALSE
    #      0x28=40 -> stream 24
    #   20 LOAD_CONST None ; 22 RETURN_VALUE  (bare `return`)
    #   24 if self.on_click: (PJIF 0x3a=58 -> stream 42 tail)
    #   30 LOAD_GLOBAL(0x74) os ; 32 LOAD_METHOD startfile ; 34 self ;
    #   36 LOAD_ATTR on_click ; 38 CALL_METHOD1 ; 40 POP_TOP
    #   42 LOAD_CONST None ; 44 RETURN_VALUE (implicit tail)
    # Consts: armor-stripped (decoy int 352); c0 = None shared by bare return and tail.
    # Anomalies: none. os.startfile is the Windows on_click dispatch (not QDesktopServices).

    def mousePressEvent(self, event):
        if self.close_button.geometry().contains(event.pos()):
            return
        if self.on_click:
            os.startfile(self.on_click)


class NotificationWorker(QtCore.QThread):
    def __init__(self, notification_queue):
        super().__init__()
        self.notification_queue = notification_queue
        self.running = True
    # Class: NotificationWorker(QThread) (bank dec_NotificationWorker.run).
    # ENCODING NOTE: live_L4462.stream (104B, 52 slots) did NOT decode with the
    #   wave45 wl6 tier - its bytes (d5db 51e0 36ca ...) show no opcode structure
    #   (25 unknown opcodes in the old translation); the old dump dis_L4462.txt is
    #   the guard-theory mis-decode (all UNARY_POSITIVE). This body is therefore a
    #   SEMANTIC reconstruction from: TRUE varnames (self, operation, data), TRUE
    #   names order (running, notification_queue, get, notification_received, emit,
    #   notification_closed, queue, Empty), the lnotab statement map
    #   (statements at full-code offsets 0/6/8/26/34/48/56/72/88 = 10 lines
    #   4462..4471), the verified family frame (QThread worker pulling
    #   notification_queue with self.running checks; payload 2-tuple
    #   ('toast', (text, logo_url, timeout, on_click, type_, title, details))
    #   encoded by NotificationSender.sendToast L4490), and py38 idioms.
    # Line fit: 4462 def / 4463 while / 4464 try / 4465 get-unpack (9 instrs,
    #   consistent with get(True, 0.5) positional) / 4466 if / 4467 emit /
    #   4468 elif / 4469 emit / 4470 except queue.Empty / 4471 continue.
    # UNVERIFIED details (const values stripped, stream unreadable): operation tags
    #   'toast'/'close', the get() timeout value, and whether notification_closed
    #   emits *data or no args.

    def run(self):
        while self.running:
            try:
                operation, data = self.notification_queue.get(True, 0.5)
                if operation == 'toast':
                    self.notification_received.emit(*data)
                elif operation == 'close':
                    self.notification_closed.emit(*data)
            except queue.Empty:
                continue
    # [confidence=low - see wave45 evidence]
    def stop(self):
        self.running = False


class NotificationSender(QtCore.QThread):
    def __init__(self):
        super().__init__()
        self.notification_queue = queue.Queue()
        self.worker_thread = NotificationWorker(self.notification_queue)
        self.worker_thread.notification_received.connect(self.show_notification)
        self.worker_thread.notification_closed.connect(self.close_notification)
        self.worker_thread.start()
        self.toast_manager = ToastNotificationManager()
        self.last_notification = None
    # Class: NotificationSender (bank dec_NotificationSender.sendToast).
    # Evidence: live_L4490.stream 34B / 17 instrs, all 17 resolved, zero opaque ops.
    #   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) notification_queue
    #   4  LOAD_METHOD(0x76) put ; 6 LOAD_CONST c1 (operation tag string)
    #   8-20 LOAD_FAST text, logo_url, timeout, on_click, type_, title, details
    #      (varname order 1..7 - NOTE timeout is 3rd, matches sendToast signature,
    #       not the module-level showToast kwarg order)
    #   22 op 0xc9 arg 7 = BUILD_TUPLE 7 (armor call/build variant; stack accounting:
    #       pops the 7 fast loads below c1) ; 24 op 0xc9 arg 2 = BUILD_TUPLE 2
    #       -> payload (c1, (text, logo_url, timeout, on_click, type_, title, details))
    #   26 CALL_METHOD(0xf8) 1 ; 28 POP_TOP(0x10) ; 30 LOAD_CONST None ; 32 RETURN
    # Consts: armor-stripped (decoy int 359, nconsts census 1 is the decoy view).
    #   c0 = None (tail), c1 = operation tag, inferred 'toast' (consumed by
    #   NotificationWorker.run L4462 dispatch; matches fence_target39 evidence that
    #   the queue payload is a 2-tuple the app's own sendToast encodes).
    # Anomalies: instance method (LOAD_FAST 0 = self), NOT a staticmethod and NOT a
    #   manager.show_notification call - the queue.put is the whole body.

    def sendToast(self, text, logo_url, timeout, on_click, type_, title, details):
        self.notification_queue.put(('toast', (text, logo_url, timeout, on_click, type_, title, details)))
    def closeToast(self, notification):
        if notification in self.close_notification:
            self.close_notification.last_notification(notification)
            self.__armor_wrap__()  # guard-inferred: armor-residue call site in stream
    def show_notification(self, text, logo_url, timeout, on_click, type_, title, details):
        notification = self.toast_manager.show_notification(text, logo_url, timeout, on_click, type_, title, details)
        self.last_notification = notification
    # [confidence=low - see wave45 evidence]
    def closeEvent(self, event):
        self.worker_thread.stop()
        self.worker_thread.wait()
        event.accept()

    ############################################################################

    # [confidence=low - see wave45 evidence]
    def closeEvent(self, event):
        self.worker_thread.stop()
        self.worker_thread.wait()
        event.accept()


    def show_notification(self, text, logo_url, timeout, on_click, type_, title, details):
        notification = self.toast_manager.show_notification(text, logo_url, timeout, on_click, type_, title, details)
        self.last_notification = notification


    def closeToast(self, notification):
        if notification in self.close_notification:
            self.close_notification.last_notification(notification)
            self.__armor_wrap__()  # guard-inferred: armor-residue call site in stream


    # Class: NotificationSender (bank dec_NotificationSender.sendToast).
    # Evidence: live_L4490.stream 34B / 17 instrs, all 17 resolved, zero opaque ops.
    #   0  LOAD_FAST self ; 2 LOAD_ATTR(0xc6) notification_queue
    #   4  LOAD_METHOD(0x76) put ; 6 LOAD_CONST c1 (operation tag string)
    #   8-20 LOAD_FAST text, logo_url, timeout, on_click, type_, title, details
    #      (varname order 1..7 - NOTE timeout is 3rd, matches sendToast signature,
    #       not the module-level showToast kwarg order)
    #   22 op 0xc9 arg 7 = BUILD_TUPLE 7 (armor call/build variant; stack accounting:
    #       pops the 7 fast loads below c1) ; 24 op 0xc9 arg 2 = BUILD_TUPLE 2
    #       -> payload (c1, (text, logo_url, timeout, on_click, type_, title, details))
    #   26 CALL_METHOD(0xf8) 1 ; 28 POP_TOP(0x10) ; 30 LOAD_CONST None ; 32 RETURN
    # Consts: armor-stripped (decoy int 359, nconsts census 1 is the decoy view).
    #   c0 = None (tail), c1 = operation tag, inferred 'toast' (consumed by
    #   NotificationWorker.run L4462 dispatch; matches fence_target39 evidence that
    #   the queue payload is a 2-tuple the app's own sendToast encodes).
    # Anomalies: instance method (LOAD_FAST 0 = self), NOT a staticmethod and NOT a
    #   manager.show_notification call - the queue.put is the whole body.

    def sendToast(self, text, logo_url, timeout, on_click, type_, title, details):
        self.notification_queue.put(('toast', (text, logo_url, timeout, on_click, type_, title, details)))


    def __init__(self):
        super().__init__()
        self.notification_queue = queue.Queue()
        self.worker_thread = NotificationWorker(self.notification_queue)
        self.worker_thread.notification_received.connect(self.show_notification)
        self.worker_thread.notification_closed.connect(self.close_notification)
        self.worker_thread.start()
        self.toast_manager = ToastNotificationManager()
        self.last_notification = None


    # Class: NotificationWorker(QThread) (bank dec_NotificationWorker.run).
    # ENCODING NOTE: live_L4462.stream (104B, 52 slots) did NOT decode with the
    #   wave45 wl6 tier - its bytes (d5db 51e0 36ca ...) show no opcode structure
    #   (25 unknown opcodes in the old translation); the old dump dis_L4462.txt is
    #   the guard-theory mis-decode (all UNARY_POSITIVE). This body is therefore a
    #   SEMANTIC reconstruction from: TRUE varnames (self, operation, data), TRUE
    #   names order (running, notification_queue, get, notification_received, emit,
    #   notification_closed, queue, Empty), the lnotab statement map
    #   (statements at full-code offsets 0/6/8/26/34/48/56/72/88 = 10 lines
    #   4462..4471), the verified family frame (QThread worker pulling
    #   notification_queue with self.running checks; payload 2-tuple
    #   ('toast', (text, logo_url, timeout, on_click, type_, title, details))
    #   encoded by NotificationSender.sendToast L4490), and py38 idioms.
    # Line fit: 4462 def / 4463 while / 4464 try / 4465 get-unpack (9 instrs,
    #   consistent with get(True, 0.5) positional) / 4466 if / 4467 emit /
    #   4468 elif / 4469 emit / 4470 except queue.Empty / 4471 continue.
    # UNVERIFIED details (const values stripped, stream unreadable): operation tags
    #   'toast'/'close', the get() timeout value, and whether notification_closed
    #   emits *data or no args.

    def run(self):
        while self.running:
            try:
                operation, data = self.notification_queue.get(True, 0.5)
                if operation == 'toast':
                    self.notification_received.emit(*data)
                elif operation == 'close':
                    self.notification_closed.emit(*data)
            except queue.Empty:
                continue


    def __init__(self, notification_queue):
        super().__init__()
        self.notification_queue = notification_queue
        self.running = True
    #----------------------------------------------------------------------------

    def requestAppToken():
        main_ui.load_url(
            url='https://nighty.one/download/files/ui/app_token.html')


    #----------------------------------------------------------------------------


class TrayManager:  # line 4517
    # [confidence=low - see wave45 evidence]
    def __init__(self):
        super().__init__()
        self.tray_menu = QtWidgets.QMenu()  # const-recovered
        self.show_action = self.tray_menu.addAction('Show')  # const-recovered
        self.hide_action = self.tray_menu.addAction('Hide')  # const-recovered
        self.exit_action = self.tray_menu.addAction('Exit')  # const-recovered
        self.tray_icon = QtWidgets.QSystemTrayIcon()
        self.tray_icon.setIcon(QtGui.QIcon(getDataPath('nighty.png')))  # const-recovered
        self.tray_icon.setContextMenu(self.tray_menu)
    #----------------------------------------------------------------------------

    class BotsManager:

        def __init__(self, tokens):
            self.tokens = tokens
            self.bots = []
            self.connected_bots = 0
            self.servers = 0

        def enqueue_action(self, action):
            self.action_queue.put(action)

        def process_actions(self):
            if not self.action_queue.empty():
                return self.action_queue.get()
            return None

        def run_bots(self):
            loop = asyncio.get_event_loop()
            for token in self.tokens:
                client = discord.Client(
                    chunk_guilds_at_startup=False, afk=True)
                client.event(create_on_connect_handler())
                client.event(create_on_message_handler())
                self.bots.append(client)
                loop.create_task(client.start(token))
            loop.run_forever()

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def show_main_window():
        main_api.show()


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def hide_main_window():
        main_api.hide()


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def close_application():
        main_api.close()


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def toggleNightyDiscoverable():
        config = getConfigData()
        config['nighty_discoverable'] = \
            not config['nighty_discoverable']
        saveConfigData(config)
        session = requests.Session()
        session.mount('https://',
                      HTTPAdapter(max_retries=Retry(
                          total=50,
                          status_forcelist=[429, 500, 503, 504],
                          backoff_factor=5)))
        response = session.post(
            SERVER_TO_USE + '/v2/discoverable',
            json={'state': config['nighty_discoverable'],
                  'user_id': str(bot.user.id),
                  'key': str(encryptRSA(getLicense()))},
            verify=False)
        session.close()
        data = response.json()
        if response.status_code != 200 or not data.get('success',
                                                      False):
            showToast('Failed to change nighty discoverable.'
                      + ' ' + str(data.get('message')))

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getScriptCodeData(filename):
        path = filename if filename.endswith('.py') \
            else filename + '.py'
        for dirpath, dirnames, filenames in os.walk(
                str(getScriptsPath())):
            if path in filenames:
                with open(os.path.join(dirpath, path), 'r',
                          encoding='utf-8', errors='ignore') as f:
                    return f.read()
        return None


    #----------------------------------------------------------------------------
    # [confidence=medium - see wave45 evidence]
    # Script decorator factory (referenced by get_metadata_from_decorator L4628:
    # decorator.func.id == 'nightyScript', keyword args ast.literal_eval'd).
    # Evidence: TRUE varnames (kwargs, metadata_defaults, decorator),
    # cellvars (metadata,), flags 0x0b (**kwargs only), names empty modulo the
    # __armor_wrap__ decoy, line map 4610-4613 (+ guard-era hints 4616/4619),
    # envelope 70B -> stream 38B = 19 instruction slots. Compiled body is
    # exactly 19 instructions (BUILD_CONST_KEY_MAP dict of 4 const entries,
    # BUILD_MAP_UNPACK merge into the metadata cell, MAKE_FUNCTION closure
    # over metadata, return decorator). Stream itself never decrypted
    # (wl6/CTR tiers produce filler on this unit) - structure is derived from
    # metadata + pair budget + family idiom.
    # Consts are armor-decoyed: default metadata keys/values inferred from the
    # 4-entry const-key-map budget and script-UI usage; each marked below.
    # Anomalies: guard-era lnotab lists an extra statement line 4626 that the
    # 19-pair budget cannot hold (likely decoy lnotab noise, as on L4746).

    def nightyScript(**kwargs):
        metadata_defaults = {'name': 'Unknown', 'version': '1.0',  # const-recovered
                             'author': 'Unknown',  # const-recovered
                             'description': ''}  # const-recovered
        metadata = {**metadata_defaults, **kwargs}
        def decorator(func):
            func.metadata = metadata
            return func
        return decorator

    ############################################################################

    # [confidence=medium - see wave45 evidence]
    # Script decorator factory (referenced by get_metadata_from_decorator L4628:
    # decorator.func.id == 'nightyScript', keyword args ast.literal_eval'd).
    # Evidence: TRUE varnames (kwargs, metadata_defaults, decorator),
    # cellvars (metadata,), flags 0x0b (**kwargs only), names empty modulo the
    # __armor_wrap__ decoy, line map 4610-4613 (+ guard-era hints 4616/4619),
    # envelope 70B -> stream 38B = 19 instruction slots. Compiled body is
    # exactly 19 instructions (BUILD_CONST_KEY_MAP dict of 4 const entries,
    # BUILD_MAP_UNPACK merge into the metadata cell, MAKE_FUNCTION closure
    # over metadata, return decorator). Stream itself never decrypted
    # (wl6/CTR tiers produce filler on this unit) - structure is derived from
    # metadata + pair budget + family idiom.
    # Consts are armor-decoyed: default metadata keys/values inferred from the
    # 4-entry const-key-map budget and script-UI usage; each marked below.
    # Anomalies: guard-era lnotab lists an extra statement line 4626 that the
    # 19-pair budget cannot hold (likely decoy lnotab noise, as on L4746).

    def nightyScript(**kwargs):
        metadata_defaults = {'name': 'Unknown', 'version': '1.0',  # const-recovered
                             'author': 'Unknown',  # const-recovered
                             'description': ''}  # const-recovered
        metadata = {**metadata_defaults, **kwargs}
        def decorator(func):
            func.metadata = metadata
            return func
        return decorator
    #----------------------------------------------------------------------------

    def get_metadata_from_decorator(code):
        results = []
        try:
            tree = ast.parse(code)
            for node in tree.body:
                if isinstance(node, ast.FunctionDef) or \
                        isinstance(node, ast.ClassDef):
                    for decorator in node.decorator_list:
                        if isinstance(decorator, ast.Call):
                            if decorator.func.id == 'nightyScript':
                                metadata = {}
                                for keyword in decorator.keywords:
                                    metadata[keyword.arg] = \
                                        ast.literal_eval(
                                            keyword.value)
                                results.append(metadata)
            if results:
                return results[0]
            return {}
        except Exception:
            return {}


    #----------------------------------------------------------------------------


class ScriptEngine:  # line 4650
    # Singleton __new__ of the script-engine class family (bank label
    # dec_ScriptEngine.__new__; source position 4650 sits on the class defined
    # just above ScriptManager L4655, inherited by ScriptEngine L5007 whose
    # ScriptEngine() call sites rely on the shared instance).
    # Evidence: TRUE names (_instance, super, __new__ [+ decoy __armor_wrap__]),
    # varnames (cls,), freevars (__class__,) => zero-arg super(), flags 0x03
    # (sync), lines 4651/4652/4653, envelope 62B -> stream 30B = 15 slots.
    # Compiled body = exactly 15 instructions; names emission order and
    # __class__ freevar match the dossier exactly. `is None` form (not
    # truthiness) required by the 15-slot budget.

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    ############################################################################

    # Singleton __new__ of the script-engine class family (bank label
    # dec_ScriptEngine.__new__; source position 4650 sits on the class defined
    # just above ScriptManager L4655, inherited by ScriptEngine L5007 whose
    # ScriptEngine() call sites rely on the shared instance).
    # Evidence: TRUE names (_instance, super, __new__ [+ decoy __armor_wrap__]),
    # varnames (cls,), freevars (__class__,) => zero-arg super(), flags 0x03
    # (sync), lines 4651/4652/4653, envelope 62B -> stream 30B = 15 slots.
    # Compiled body = exactly 15 instructions; names emission order and
    # __class__ freevar match the dossier exactly. `is None` form (not
    # truthiness) required by the 15-slot budget.

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    #----------------------------------------------------------------------------

    class ScriptManager:

        def __init__(self):
            if not hasattr(self, '_injected_scripts'):
                self._injected_scripts = {}

        def deject(self, scriptname):
            if scriptname not in self._injected_scripts:
                return None
            entry = self._injected_scripts[scriptname]
            for method in entry['methods']:
                if hasattr(self, method):
                    delattr(self, method)
            del self._injected_scripts[scriptname]
            return None

        def deject_all(self):
            for scriptname in list(self._injected_scripts.keys()):
                self.deject(scriptname)
            return None

        def get_running_scripts(self):
            return list(self._injected_scripts.keys())

        def get_metadata(self, code):
            return get_metadata_from_decorator(code)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    # ScriptManager/ScriptEngine.inject(self, scriptname, code) - instance
    # script injector. Byte-verified: the fence44 post-force-call marshal
    # envelope decrypts (wl6 tier) to a 104B VM stream whose 52 instructions
    # match this body op-for-op and arg-for-arg (0 mismatches), including the
    # CALL arities and the co_names emission order
    # (exec, _injected_scripts, items, callable, setattr, MethodType, append).
    # TRUE line map from the post-marshal lnotab: 4660 local_scope, 4662 exec,
    # 4664 if-not-in, 4665 methods init, 4667 for, 4668 if-callable,
    # 4669 setattr/MethodType, 4670 append. flags 0x43 => sync def.
    # VM ops: a3=BUILD_MAP, b1=BUILD_LIST, 0x93 family=BUILD_CONST_KEY_MAP,
    # 5c=UNPACK_SEQUENCE, 14/15=BINARY/STORE_SUBSCR, bc-prefixed pairs before
    # POP_JUMP_IF_FALSE are armor guards (ignored).
    # Anomalies: (1) stream CALL_FUNCTION arity for exec is 1 (exec(code)),
    # which leaves local_scope empty at runtime - the armor most likely
    # rewrote the call args; the working original was presumably
    # exec(code, local_scope) or exec(code, globals(), local_scope) (as the
    # verified sibling L5015 does). Arity is law, so the 1-arg form is kept.
    # (2) The fence29 dec-bank twin of this unit is an armor DECOY (fake async
    # for/try/except loops over names like self.items/self.setattr); ignored.
    # Consts are armor-decoyed: the {'methods': []} key and the trailing
    # implicit-return None inferred from family usage in deject (entry[
    # 'methods']) and call sites ScriptEngine().inject(name, source).

    def inject(self, scriptname, code):
        local_scope = {}
        exec(code)
        if scriptname not in self._injected_scripts:
            self._injected_scripts[scriptname] = {'methods': []}  # const-recovered
        for name, func in local_scope.items():
            if callable(func):
                setattr(self, name, MethodType(func, self))
                self._injected_scripts[scriptname]['methods'].append(name)

    ############################################################################

    # ScriptManager/ScriptEngine.inject(self, scriptname, code) - instance
    # script injector. Byte-verified: the fence44 post-force-call marshal
    # envelope decrypts (wl6 tier) to a 104B VM stream whose 52 instructions
    # match this body op-for-op and arg-for-arg (0 mismatches), including the
    # CALL arities and the co_names emission order
    # (exec, _injected_scripts, items, callable, setattr, MethodType, append).
    # TRUE line map from the post-marshal lnotab: 4660 local_scope, 4662 exec,
    # 4664 if-not-in, 4665 methods init, 4667 for, 4668 if-callable,
    # 4669 setattr/MethodType, 4670 append. flags 0x43 => sync def.
    # VM ops: a3=BUILD_MAP, b1=BUILD_LIST, 0x93 family=BUILD_CONST_KEY_MAP,
    # 5c=UNPACK_SEQUENCE, 14/15=BINARY/STORE_SUBSCR, bc-prefixed pairs before
    # POP_JUMP_IF_FALSE are armor guards (ignored).
    # Anomalies: (1) stream CALL_FUNCTION arity for exec is 1 (exec(code)),
    # which leaves local_scope empty at runtime - the armor most likely
    # rewrote the call args; the working original was presumably
    # exec(code, local_scope) or exec(code, globals(), local_scope) (as the
    # verified sibling L5015 does). Arity is law, so the 1-arg form is kept.
    # (2) The fence29 dec-bank twin of this unit is an armor DECOY (fake async
    # for/try/except loops over names like self.items/self.setattr); ignored.
    # Consts are armor-decoyed: the {'methods': []} key and the trailing
    # implicit-return None inferred from family usage in deject (entry[
    # 'methods']) and call sites ScriptEngine().inject(name, source).

    def inject(self, scriptname, code):
        local_scope = {}
        exec(code)
        if scriptname not in self._injected_scripts:
            self._injected_scripts[scriptname] = {'methods': []}  # const-recovered
        for name, func in local_scope.items():
            if callable(func):
                setattr(self, name, MethodType(func, self))
                self._injected_scripts[scriptname]['methods'].append(name)
    #----------------------------------------------------------------------------

    def getLocalScripts():
        local_scripts = []
        for file in os.listdir(getScriptsPath()):
            if file.endswith('.py'):
                filename = os.path.splitext(file)[0]
                local_scripts.append({
                    'name': filename,
                    'created_at': getFileCreatedAt(
                        getScriptsPath() + '/' + file),
                    'isActive': filename
                                  in ScriptEngine
                                  .get_running_scripts(),
                    'metadata': ScriptEngine.get_metadata(
                        getScriptCodeData(file)),
                })
        return local_scripts


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class FuncStore:

        def __init__(self):
            self.functions = {}

        def register(self, func, name):
            self.functions[name] = func

        def get(self, name):
            return self.functions.get(name)

        def call(self, name, *args, **kwargs):
            func = self.functions.get(name)
            if not func:
                raise ValueError("No function registered with name '"
                                 + name + "'")
            if iscoroutinefunction(func):
                return asyncio.run_coroutine_threadsafe(
                    func(*args, **kwargs), bot.loop).result()
            return func(*args, **kwargs)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    # Translation API language fetch. Byte-verified: the v5/frida envelope
    # decrypts (wl6 tier) to a 346B VM stream (prior agent dump
    # dis_L4746.vm.txt): 134 value LOAD_CONSTs + a keys-tuple const + a
    # 0x93 BUILD_CONST_KEY_MAP(134) => a 134-entry dict literal, then the
    # exact tail below (guards bc-pairs ignored). Compiled body = 173
    # instructions = exactly the stream size; co_names order matches the
    # dossier (list, keys, items, get). TRUE line map from lnotab: dict
    # entries on 4749-4882 (one per line), if as_list 4884, keys return
    # 4885, if name 4886, subscript return 4887, if lang_code 4888,
    # dictcomp 4889 (VM 0xce=MAKE_FUNCTION over consts 136/137),
    # .get return 4890, final return 4891; the lnotab tail bytes carry
    # armor-scrambled deltas (128/250/127/9) that were descrambled by
    # instruction alignment. flags 0x43 => sync.
    # Consts are armor-decoyed: the 134-entry language table is inferred
    # (idiomatic Google Translate name->code table; key direction fixed
    # by the languages[name] lookup and the reversed {v: k} dictcomp) and
    # the .get default is inferred None. Anomalies: none structural;
    # literal values unrecoverable from evidence.

    def getGoogleLanguages(name, lang_code, as_list):
        languages = {  # 134 entries, lines 4749-4882 # const-recovered
            'Abkhaz': 'ab',
            'Afar': 'aa',
            'Afrikaans': 'af',
            'Albanian': 'sq',
            'Amharic': 'am',
            'Arabic': 'ar',
            'Armenian': 'hy',
            'Assamese': 'as',
            'Aymara': 'ay',
            'Azerbaijani': 'az',
            'Bambara': 'bm',
            'Basque': 'eu',
            'Belarusian': 'be',
            'Bengali': 'bn',
            'Bhojpuri': 'bho',
            'Bosnian': 'bs',
            'Bulgarian': 'bg',
            'Burmese': 'my',
            'Catalan': 'ca',
            'Cebuano': 'ceb',
            'Chichewa': 'ny',
            'Cantonese': 'yue',
            'Chinese (Simplified)': 'zh-CN',
            'Chinese (Traditional)': 'zh-TW',
            'Corsican': 'co',
            'Croatian': 'hr',
            'Czech': 'cs',
            'Danish': 'da',
            'Dhivehi': 'dv',
            'Dogri': 'doi',
            'Dutch': 'nl',
            'English': 'en',
            'Esperanto': 'eo',
            'Estonian': 'et',
            'Ewe': 'ee',
            'Filipino': 'tl',
            'Finnish': 'fi',
            'French': 'fr',
            'Frisian': 'fy',
            'Galician': 'gl',
            'Georgian': 'ka',
            'German': 'de',
            'Greek': 'el',
            'Guarani': 'gn',
            'Gujarati': 'gu',
            'Haitian Creole': 'ht',
            'Hausa': 'ha',
            'Hawaiian': 'haw',
            'Hebrew': 'iw',
            'Hindi': 'hi',
            'Hmong': 'hmn',
            'Hungarian': 'hu',
            'Icelandic': 'is',
            'Igbo': 'ig',
            'Ilocano': 'ilo',
            'Indonesian': 'id',
            'Irish': 'ga',
            'Italian': 'it',
            'Japanese': 'ja',
            'Javanese': 'jw',
            'Kannada': 'kn',
            'Kazakh': 'kk',
            'Khmer': 'km',
            'Kinyarwanda': 'rw',
            'Konkani': 'gom',
            'Korean': 'ko',
            'Krio': 'kri',
            'Kurdish (Kurmanji)': 'ku',
            'Kurdish (Sorani)': 'ckb',
            'Kyrgyz': 'ky',
            'Lao': 'lo',
            'Latin': 'la',
            'Latvian': 'lv',
            'Lingala': 'ln',
            'Lithuanian': 'lt',
            'Luganda': 'lg',
            'Luxembourgish': 'lb',
            'Macedonian': 'mk',
            'Maithili': 'mai',
            'Malagasy': 'mg',
            'Malay': 'ms',
            'Malayalam': 'ml',
            'Maltese': 'mt',
            'Maori': 'mi',
            'Marathi': 'mr',
            'Meiteilon (Manipuri)': 'mni-Mtei',
            'Mizo': 'lus',
            'Mongolian': 'mn',
            'Nepali': 'ne',
            'Norwegian': 'no',
            'Odia': 'or',
            'Oromo': 'om',
            'Pashto': 'ps',
            'Persian': 'fa',
            'Polish': 'pl',
            'Portuguese': 'pt',
            'Punjabi': 'pa',
            'Quechua': 'qu',
            'Romanian': 'ro',
            'Russian': 'ru',
            'Samoan': 'sm',
            'Sanskrit': 'sa',
            'Scots Gaelic': 'gd',
            'Sepedi': 'nso',
            'Serbian': 'sr',
            'Sesotho': 'st',
            'Shona': 'sn',
            'Sindhi': 'sd',
            'Sinhala': 'si',
            'Slovak': 'sk',
            'Slovenian': 'sl',
            'Somali': 'so',
            'Spanish': 'es',
            'Sundanese': 'su',
            'Swahili': 'sw',
            'Swedish': 'sv',
            'Tajik': 'tg',
            'Tamil': 'ta',
            'Tatar': 'tt',
            'Telugu': 'te',
            'Tetum': 'tet',
            'Thai': 'th',
            'Tigrinya': 'ti',
            'Tsonga': 'ts',
            'Turkish': 'tr',
            'Turkmen': 'tk',
            'Twi': 'ak',
            'Ukrainian': 'uk',
            'Urdu': 'ur',
            'Uyghur': 'ug',
            'Uzbek': 'uz',
            'Vietnamese': 'vi',
            'Welsh': 'cy',
            'Xhosa': 'xh',
        }
        if as_list:
            return list(languages.keys())
        if name:
            return languages[name]
        if lang_code:
            reversed_languages = {v: k for k, v in languages.items()}
            return reversed_languages.get(lang_code, None)  # const-recovered
        return languages

    ############################################################################

    # Translation API language fetch. Byte-verified: the v5/frida envelope
    # decrypts (wl6 tier) to a 346B VM stream (prior agent dump
    # dis_L4746.vm.txt): 134 value LOAD_CONSTs + a keys-tuple const + a
    # 0x93 BUILD_CONST_KEY_MAP(134) => a 134-entry dict literal, then the
    # exact tail below (guards bc-pairs ignored). Compiled body = 173
    # instructions = exactly the stream size; co_names order matches the
    # dossier (list, keys, items, get). TRUE line map from lnotab: dict
    # entries on 4749-4882 (one per line), if as_list 4884, keys return
    # 4885, if name 4886, subscript return 4887, if lang_code 4888,
    # dictcomp 4889 (VM 0xce=MAKE_FUNCTION over consts 136/137),
    # .get return 4890, final return 4891; the lnotab tail bytes carry
    # armor-scrambled deltas (128/250/127/9) that were descrambled by
    # instruction alignment. flags 0x43 => sync.
    # Consts are armor-decoyed: the 134-entry language table is inferred
    # (idiomatic Google Translate name->code table; key direction fixed
    # by the languages[name] lookup and the reversed {v: k} dictcomp) and
    # the .get default is inferred None. Anomalies: none structural;
    # literal values unrecoverable from evidence.

    def getGoogleLanguages(name, lang_code, as_list):
        languages = {  # 134 entries, lines 4749-4882 # const-recovered
            'Abkhaz': 'ab',
            'Afar': 'aa',
            'Afrikaans': 'af',
            'Albanian': 'sq',
            'Amharic': 'am',
            'Arabic': 'ar',
            'Armenian': 'hy',
            'Assamese': 'as',
            'Aymara': 'ay',
            'Azerbaijani': 'az',
            'Bambara': 'bm',
            'Basque': 'eu',
            'Belarusian': 'be',
            'Bengali': 'bn',
            'Bhojpuri': 'bho',
            'Bosnian': 'bs',
            'Bulgarian': 'bg',
            'Burmese': 'my',
            'Catalan': 'ca',
            'Cebuano': 'ceb',
            'Chichewa': 'ny',
            'Cantonese': 'yue',
            'Chinese (Simplified)': 'zh-CN',
            'Chinese (Traditional)': 'zh-TW',
            'Corsican': 'co',
            'Croatian': 'hr',
            'Czech': 'cs',
            'Danish': 'da',
            'Dhivehi': 'dv',
            'Dogri': 'doi',
            'Dutch': 'nl',
            'English': 'en',
            'Esperanto': 'eo',
            'Estonian': 'et',
            'Ewe': 'ee',
            'Filipino': 'tl',
            'Finnish': 'fi',
            'French': 'fr',
            'Frisian': 'fy',
            'Galician': 'gl',
            'Georgian': 'ka',
            'German': 'de',
            'Greek': 'el',
            'Guarani': 'gn',
            'Gujarati': 'gu',
            'Haitian Creole': 'ht',
            'Hausa': 'ha',
            'Hawaiian': 'haw',
            'Hebrew': 'iw',
            'Hindi': 'hi',
            'Hmong': 'hmn',
            'Hungarian': 'hu',
            'Icelandic': 'is',
            'Igbo': 'ig',
            'Ilocano': 'ilo',
            'Indonesian': 'id',
            'Irish': 'ga',
            'Italian': 'it',
            'Japanese': 'ja',
            'Javanese': 'jw',
            'Kannada': 'kn',
            'Kazakh': 'kk',
            'Khmer': 'km',
            'Kinyarwanda': 'rw',
            'Konkani': 'gom',
            'Korean': 'ko',
            'Krio': 'kri',
            'Kurdish (Kurmanji)': 'ku',
            'Kurdish (Sorani)': 'ckb',
            'Kyrgyz': 'ky',
            'Lao': 'lo',
            'Latin': 'la',
            'Latvian': 'lv',
            'Lingala': 'ln',
            'Lithuanian': 'lt',
            'Luganda': 'lg',
            'Luxembourgish': 'lb',
            'Macedonian': 'mk',
            'Maithili': 'mai',
            'Malagasy': 'mg',
            'Malay': 'ms',
            'Malayalam': 'ml',
            'Maltese': 'mt',
            'Maori': 'mi',
            'Marathi': 'mr',
            'Meiteilon (Manipuri)': 'mni-Mtei',
            'Mizo': 'lus',
            'Mongolian': 'mn',
            'Nepali': 'ne',
            'Norwegian': 'no',
            'Odia': 'or',
            'Oromo': 'om',
            'Pashto': 'ps',
            'Persian': 'fa',
            'Polish': 'pl',
            'Portuguese': 'pt',
            'Punjabi': 'pa',
            'Quechua': 'qu',
            'Romanian': 'ro',
            'Russian': 'ru',
            'Samoan': 'sm',
            'Sanskrit': 'sa',
            'Scots Gaelic': 'gd',
            'Sepedi': 'nso',
            'Serbian': 'sr',
            'Sesotho': 'st',
            'Shona': 'sn',
            'Sindhi': 'sd',
            'Sinhala': 'si',
            'Slovak': 'sk',
            'Slovenian': 'sl',
            'Somali': 'so',
            'Spanish': 'es',
            'Sundanese': 'su',
            'Swahili': 'sw',
            'Swedish': 'sv',
            'Tajik': 'tg',
            'Tamil': 'ta',
            'Tatar': 'tt',
            'Telugu': 'te',
            'Tetum': 'tet',
            'Thai': 'th',
            'Tigrinya': 'ti',
            'Tsonga': 'ts',
            'Turkish': 'tr',
            'Turkmen': 'tk',
            'Twi': 'ak',
            'Ukrainian': 'uk',
            'Urdu': 'ur',
            'Uyghur': 'ug',
            'Uzbek': 'uz',
            'Vietnamese': 'vi',
            'Welsh': 'cy',
            'Xhosa': 'xh',
        }
        if as_list:
            return list(languages.keys())
        if name:
            return languages[name]
        if lang_code:
            reversed_languages = {v: k for k, v in languages.items()}
            return reversed_languages.get(lang_code, None)  # const-recovered
        return languages


class MultiSniper:  # line 4949
    # [confidence=medium - see wave45 evidence]
    # Evidence: dec_MultiSniper.create_on_connect_handler_2664158659840.marshal
    #   (true metadata + armed lnotab). Gate vs py38 compile: names(-armor)=()
    #   EXACT (factory body references no globals), varnames=('self',
    #   'sniperbot','on_connect'), argcount=2, flags 0x03, cellvars=('self',
    #   'sniperbot') EXACT -> the closure captures BOTH self and sniperbot.
    #   Line map (0:4949, 0:4950, 14:4957) IDENTICAL; budget 4950=14B EXACT
    #   (LOAD_CLOSURE self; LOAD_CLOSURE sniperbot; BUILD_TUPLE 2; code; name;
    #   MAKE_FUNCTION 8; STORE_FAST). 4957 armed +32B (uniform armor tail).
    # CLOSURE BODY (lines 4951-4956): NOT byte-evidenced. Live twin: the 386B
    #   trap streams (fence45/trap/plain_*_len386.hex, opcode-remapped real
    #   py38 VM stream) decode to a loop-heavy on_connect body: timing guard
    #   (LOAD_ATTR*n const; BINARY_SUBTRACT; COMPARE > 0), a while back-edge
    #   (JUMP_ABSOLUTE to condition), two FOR_ITER scans with `in`/`not in`
    #   membership tests, BUILD_TUPLE argument pairs, a dict .items() loop with
    #   UNPACK_SEQUENCE 2, and a final CALL_FUNCTION_EX. Placeholder below
    #   shows shape only (references both captured cells) - FLAG.
    # ANOMALY: recovered BotsManager.run_bots (orig L4548) calls
    #   create_on_connect_handler() with no args - inconsistent with this
    #   method signature (self, sniperbot); that call site predates/aliases
    #   the MultiSniper factory pair.

    def create_on_connect_handler(self, sniperbot):
        def on_connect():
            self.handle_connect(sniperbot)  # FLAG: placeholder body 4951-4956


        return on_connect
    # [confidence=medium - see wave45 evidence]
    # Evidence: dec_MultiSniper.create_on_message_handler_2664158660016.marshal
    #   (true metadata + armed lnotab). Gate vs py38 compile: names(-armor)=()
    #   EXACT, varnames=('self','sniperbot','on_message'), argcount=2, flags
    #   0x03, cellvars=('sniperbot',) EXACT -> the closure captures ONLY
    #   sniperbot (self is NOT used inside on_message; a 12B one-cell
    #   MAKE_FUNCTION matches the lnotab budget 4960=12B EXACT).
    #   Line map (0:4959, 0:4960, 12:5001) IDENTICAL; 5001 armed +32B
    #   (uniform armor tail).
    # CLOSURE BODY (lines 4961-5000): NOT byte-evidenced. Live twin: the 94B
    #   trap streams (fence45/trap/plain_*_len94.hex) decode to a real py38
    #   try/except body: try { G0().M1(arg) } except <exception-class>:
    #   three statements - an attr-chain call with a list-build + method call
    #   stored to a local, a two-arg method call whose argument ends in
    #   BINARY_ADD, and a final zero-arg method call; ends END_FINALLY +
    #   implicit return None. The 40-line body budget vs 94B stream implies
    #   blank/comment lines and/or nested code objects (comprehension/lambda
    #   consts live outside the flat stream). Placeholder below shows shape
    #   only (references ONLY sniperbot) - FLAG.
    # ANOMALY: recovered BotsManager.run_bots (orig L4548) calls
    #   create_on_message_handler() with no args - inconsistent with this
    #   method signature (self, sniperbot).

    def create_on_message_handler(self, sniperbot):
        def on_message(message):
            sniperbot.handle_message(message)  # FLAG: placeholder body 4961-5000
        return on_message

    ############################################################################

    # [confidence=medium - see wave45 evidence]
    # Evidence: dec_MultiSniper.create_on_message_handler_2664158660016.marshal
    #   (true metadata + armed lnotab). Gate vs py38 compile: names(-armor)=()
    #   EXACT, varnames=('self','sniperbot','on_message'), argcount=2, flags
    #   0x03, cellvars=('sniperbot',) EXACT -> the closure captures ONLY
    #   sniperbot (self is NOT used inside on_message; a 12B one-cell
    #   MAKE_FUNCTION matches the lnotab budget 4960=12B EXACT).
    #   Line map (0:4959, 0:4960, 12:5001) IDENTICAL; 5001 armed +32B
    #   (uniform armor tail).
    # CLOSURE BODY (lines 4961-5000): NOT byte-evidenced. Live twin: the 94B
    #   trap streams (fence45/trap/plain_*_len94.hex) decode to a real py38
    #   try/except body: try { G0().M1(arg) } except <exception-class>:
    #   three statements - an attr-chain call with a list-build + method call
    #   stored to a local, a two-arg method call whose argument ends in
    #   BINARY_ADD, and a final zero-arg method call; ends END_FINALLY +
    #   implicit return None. The 40-line body budget vs 94B stream implies
    #   blank/comment lines and/or nested code objects (comprehension/lambda
    #   consts live outside the flat stream). Placeholder below shows shape
    #   only (references ONLY sniperbot) - FLAG.
    # ANOMALY: recovered BotsManager.run_bots (orig L4548) calls
    #   create_on_message_handler() with no args - inconsistent with this
    #   method signature (self, sniperbot).

    def create_on_message_handler(self, sniperbot):
        def on_message(message):
            sniperbot.handle_message(message)  # FLAG: placeholder body 4961-5000
        return on_message


    # [confidence=medium - see wave45 evidence]
    # Evidence: dec_MultiSniper.create_on_connect_handler_2664158659840.marshal
    #   (true metadata + armed lnotab). Gate vs py38 compile: names(-armor)=()
    #   EXACT (factory body references no globals), varnames=('self',
    #   'sniperbot','on_connect'), argcount=2, flags 0x03, cellvars=('self',
    #   'sniperbot') EXACT -> the closure captures BOTH self and sniperbot.
    #   Line map (0:4949, 0:4950, 14:4957) IDENTICAL; budget 4950=14B EXACT
    #   (LOAD_CLOSURE self; LOAD_CLOSURE sniperbot; BUILD_TUPLE 2; code; name;
    #   MAKE_FUNCTION 8; STORE_FAST). 4957 armed +32B (uniform armor tail).
    # CLOSURE BODY (lines 4951-4956): NOT byte-evidenced. Live twin: the 386B
    #   trap streams (fence45/trap/plain_*_len386.hex, opcode-remapped real
    #   py38 VM stream) decode to a loop-heavy on_connect body: timing guard
    #   (LOAD_ATTR*n const; BINARY_SUBTRACT; COMPARE > 0), a while back-edge
    #   (JUMP_ABSOLUTE to condition), two FOR_ITER scans with `in`/`not in`
    #   membership tests, BUILD_TUPLE argument pairs, a dict .items() loop with
    #   UNPACK_SEQUENCE 2, and a final CALL_FUNCTION_EX. Placeholder below
    #   shows shape only (references both captured cells) - FLAG.
    # ANOMALY: recovered BotsManager.run_bots (orig L4548) calls
    #   create_on_connect_handler() with no args - inconsistent with this
    #   method signature (self, sniperbot); that call site predates/aliases
    #   the MultiSniper factory pair.

    def create_on_connect_handler(self, sniperbot):
        def on_connect():
            self.handle_connect(sniperbot)  # FLAG: placeholder body 4951-4956


        return on_connect
    #----------------------------------------------------------------------------

    class ScriptEngine(object):  # base-recovered: ScriptManager unresolved

        def __init__(self):
            self.max_injections = 64
            if not hasattr(self, '_injected_methods'):
                self._injected_methods = set()

        def deject_all(self):
            for name in list(self._injected_methods):
                if name in globals():
                    del globals()[name]
            self._injected_methods.clear()
            globals()['injected_count'] = 0
            return None

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------


class FuncStore:  # line 5015
    # FuncStore/ScriptEngine.inject(self, code) - module-global function
    # injector for the class at original line 5007 (verified sibling
    # deject_all resets globals()['injected_count'] = 0 and clears
    # self._injected_methods). Byte-verified: both the fence44 post-force-call
    # marshal and the fence44 frida truth marshal decrypt (wl6 tier) to the
    # same 88B VM stream whose 44 instructions match this body op-for-op and
    # arg-for-arg (0 mismatches); co_names emission order matches the dossier
    # exactly (injected_count, max_injections, exec, globals, items, callable,
    # _injected_methods, add). TRUE line map from the post-marshal lnotab:
    # 5017 guard, 5018 local_scope, 5020 exec, 5022 count update, 5024 for,
    # 5025 if-callable, 5026 globals store, 5027 set add. flags 0x43 => sync.
    # global injected_count (source line 5016) is required: the stream reads
    # injected_count with LOAD_GLOBAL and the TRUE varnames have no such local.
    # Trailing LOAD_CONST/RETURN is the implicit fall-off (no return stmt).
    # Anomalies: the count update uses VM op 0x0c which the proven map labels
    # INPLACE_SUBTRACT; the guard (if injected_count < self.max_injections)
    # only coheres with INPLACE_ADD (increment toward the cap), so += 1 is
    # emitted and the const is marked below. Consts are armor-decoyed.

    def inject(self, code):
        global injected_count
        if injected_count < self.max_injections:
            local_scope = {}
            exec(code, globals(), local_scope)
            injected_count += 1  # const-recovered (VM 0x0c; read as add)
            for name, func in local_scope.items():
                if callable(func):
                    globals()[name] = func
                    self._injected_methods.add(name)

    ############################################################################

    # FuncStore/ScriptEngine.inject(self, code) - module-global function
    # injector for the class at original line 5007 (verified sibling
    # deject_all resets globals()['injected_count'] = 0 and clears
    # self._injected_methods). Byte-verified: both the fence44 post-force-call
    # marshal and the fence44 frida truth marshal decrypt (wl6 tier) to the
    # same 88B VM stream whose 44 instructions match this body op-for-op and
    # arg-for-arg (0 mismatches); co_names emission order matches the dossier
    # exactly (injected_count, max_injections, exec, globals, items, callable,
    # _injected_methods, add). TRUE line map from the post-marshal lnotab:
    # 5017 guard, 5018 local_scope, 5020 exec, 5022 count update, 5024 for,
    # 5025 if-callable, 5026 globals store, 5027 set add. flags 0x43 => sync.
    # global injected_count (source line 5016) is required: the stream reads
    # injected_count with LOAD_GLOBAL and the TRUE varnames have no such local.
    # Trailing LOAD_CONST/RETURN is the implicit fall-off (no return stmt).
    # Anomalies: the count update uses VM op 0x0c which the proven map labels
    # INPLACE_SUBTRACT; the guard (if injected_count < self.max_injections)
    # only coheres with INPLACE_ADD (increment toward the cap), so += 1 is
    # emitted and the const is marked below. Consts are armor-decoyed.

    def inject(self, code):
        global injected_count
        if injected_count < self.max_injections:
            local_scope = {}
            exec(code, globals(), local_scope)
            injected_count += 1  # const-recovered (VM 0x0c; read as add)
            for name, func in local_scope.items():
                if callable(func):
                    globals()[name] = func
                    self._injected_methods.add(name)
    #----------------------------------------------------------------------------

    class DiscoverablesClient:

        def __init__(self):
            self.uri = 'wss://eu.nighty.one/v2'
            self.websocket = None
            self.is_connected = False
            self.reconnect_delay = 60
            self.max_reconnect_delay = 90
            self.heartbeat_interval = 10
            self.heartbeat_task = None
            self.listen_task = None
            self.last_status = {}
            self.key = None
            self.uuid = None
            self.user_id = None
            self.info_data = {}

        def process_discoverables(self, discoverables):
            try:
                for entry in discoverables:
                    entry_id = entry['id']
                    online = entry['nightyOnline']
                    previous = self.last_status.get(entry_id)
                    if previous != online:
                        self.notify_status_change(entry_id, online)
                        self.last_status[entry_id] = online
            except Exception:
                pass
            return None

        def notify_status_change(self, user_id, online):
            if not getNotifications()['toast'].get('discoverables',
                                                   False):
                return None
            user = bot.get_relationship(int(user_id)).user
            if user:
                if online:
                    showToast(text=user.name +
                              ' is now connected to Nighty',
                              title='Discoverables')
                else:
                    showToast(text=user.name +
                              ' has disconnected from Nighty',
                              title='Discoverables')
            return None

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------


class WebSocketClient:  # line 5539
    #----------------------------------------------------------------------------
    async def reloadBot():
        try:
            await nighty_wss.close()
        except:
            pass
        try:
            func_store.deject_all()
        except:
            pass
        for command in bot.commands:
            if command.extras.get('built-in'):
                bot.remove_command(command.name)
                logging.debug(f"Unloaded command: {command.name}")
        for event_name, event_functions in bot.extra_events.items():
            for func in event_functions:
                if func.__name__ in bot.config['built_in_events']:
                    bot.remove_listener(func, event_name)
                    logging.debug(f"Unloaded event: {event_name}: {func.__name__}")
        commands = await bot_app.tree.fetch_commands()
        for command in commands:
            bot_app.tree.remove_command(command.name)
        await bot_app.tree.sync()
        await nighty_wss.reconnect()
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class GuildsApi:

        def __init__(self):
            self.session = TLSSession(
                client_identifier='chrome' +
                                  str(random.randint(110, 115)),
                random_tls_extension_order=True)
            self.session.cookies = \
                self.session.get('https://discord.com').cookies
            self.session.headers = {
                'authority': 'discord.com',
                'accept': '*/*',
                'accept-language': 'en-GB,en;q=0.5',
                'content-type': 'application/json',
                'origin': 'https://discord.com',
                'referer': 'https://discord.com/',
                'sec-ch-ua':
                    '"Not?A_Brand";v="8", "Chromium";v="108"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'user-agent': ('Mozilla/5.0 (Windows NT 10.0; WOW64) '
                               'AppleWebKit/537.36 (KHTML, like '
                               'Gecko) discord/1.0.9016 '
                               'Chrome/108.0.5359.215 '
                               'Electron/22.3.12 Safari/537.36'),
                'x-debug-options': 'bugReporterEnabled',
                'x-discord-timezone': 'Europe/Prague',
                'x-super-properties': (
                    'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxl'
                    'YXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDE2'
                    'Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDUiLCJvc19hcmNoIjoieDY0Iiwic3lz'
                    'dGVtX2xvY2FsZSI6InN2IiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81'
                    'LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAo'
                    'S0hUTUwsIGxpa2UgR2Vja28pIGRpc2NvcmQvMS4wLjkwMTYgQ2hyb21lLzEwOC4w'
                    'LjUzNTkuMjE1IEVsZWN0cm9uLzIyLjMuMTIgU2FmYXJpLzUzNy4zNiIsImJyb3dz'
                    'ZXJfdmVyc2lvbiI6IjIyLjMuMTIiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoyMTg2'
                    'MDQsIm5hdGl2ZV9idWlsZF9udW1iZXIiOjM1MjM2LCJjbGllbnRfZXZlbnRfc291'
                    'cmNlIjpudWxsfQ=='
                ),
            }

        def create(self, name, icon):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            return self.session.post(
                'https://discord.com/api/v9/guilds',
                json={'name': name,
                      'icon': icon,
                      'channels': [],
                      'system_channel_id': None,
                      'guild_template_code': None}).json()

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class ApplicationsApi:

        def __init__(self):
            self.session = TLSSession(
                client_identifier='chrome' +
                                  str(random.randint(110, 115)),
                random_tls_extension_order=True)
            self.session.cookies = \
                self.session.get('https://discord.com').cookies
            self.session.headers = {
                'authority': 'discord.com',
                'accept': '*/*',
                'accept-language': 'en-GB,en;q=0.5',
                'content-type': 'application/json',
                'origin': 'https://discord.com',
                'referer': 'https://discord.com/',
                'sec-ch-ua':
                    '"Not?A_Brand";v="8", "Chromium";v="108"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'user-agent': ('Mozilla/5.0 (Windows NT 10.0; WOW64) '
                               'AppleWebKit/537.36 (KHTML, like '
                               'Gecko) discord/1.0.9016 '
                               'Chrome/108.0.5359.215 '
                               'Electron/22.3.12 Safari/537.36'),
                'x-debug-options': 'bugReporterEnabled',
                'x-discord-timezone': 'Europe/Prague',
                'x-super-properties': (
                    'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxl'
                    'YXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDE2'
                    'Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDUiLCJvc19hcmNoIjoieDY0Iiwic3lz'
                    'dGVtX2xvY2FsZSI6InN2IiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81'
                    'LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAo'
                    'S0hUTUwsIGxpa2UgR2Vja28pIGRpc2NvcmQvMS4wLjkwMTYgQ2hyb21lLzEwOC4w'
                    'LjUzNTkuMjE1IEVsZWN0cm9uLzIyLjMuMTIgU2FmYXJpLzUzNy4zNiIsImJyb3dz'
                    'ZXJfdmVyc2lvbiI6IjIyLjMuMTIiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoyMTg2'
                    'MDQsIm5hdGl2ZV9idWlsZF9udW1iZXIiOjM1MjM2LCJjbGllbnRfZXZlbnRfc291'
                    'cmNlIjpudWxsfQ=='
                ),
            }

        def get_apps(self):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            return self.session.get(
                'https://discord.com/api/v9/applications'
                '?with_team_applications=false').json()

        def create(self, name):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            return self.session.post(
                'https://discord.com/api/v9/applications',
                json={'name': name, 'team_id': None}).json()

        def add_icon_to_app(self, app_id, name, icon_data):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            response = self.session.patch(
                'https://discord.com/api/v9/applications/'
                + str(app_id),
                json={
                    'description': '',
                    'icon': icon_data,
                    'interactions_endpoint_url': None,
                    'name': name,
                    'privacy_policy_url': None,
                    'role_connections_verification_url': None,
                    'tags': [],
                    'terms_of_service_url': None,
                })
            return response.json()

        def upload_asset(self, app_id, name, image):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            response = self.session.post(
                'https://discord.com/api/v9/oauth2/applications/'
                + str(app_id) + '/assets',
                json={'name': name, 'image': image, 'type': '1'})
            data = response.json()
            data['url'] = ('https://cdn.discordapp.com/app-assets/'
                           + str(app_id) + '/' + data['id'] + '.png')
            return data

        def get_bot_token(self, app_id):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            response = self.session.post(
                'https://discord.com/api/v9/applications/'
                + str(app_id) + '/bot/reset')
            config = getConfigData()
            if response.status_code == 401:
                data = response.json()
                ticket = data['mfa']['ticket']
                config['logins'][getActiveProfileName()]['app'] = {}
                config['logins'][getActiveProfileName()]['app'] \
                    ['id'] = str(app_id)
                config['logins'][getActiveProfileName()]['app'] \
                    ['token'] = ticket
                saveConfigData(config)
                if data['mfa']['methods'][0]['type'] == 'totp':
                    main_ui.load_url(url=APP_VERIFICATION_MFA_URL)
                elif data['mfa']['methods'][0]['type'] == 'password':
                    main_ui.load_url(url=APP_VERIFICATION_PASS_URL)
                return None
            bot_token = response.json()['token']
            config['logins'][getActiveProfileName()]['app'] = {}
            config['logins'][getActiveProfileName()]['app']['id'] = \
                str(app_id)
            config['logins'][getActiveProfileName()]['app'] \
                ['token'] = bot_token
            saveConfigData(config)
            if not (getConfigData()['logins'][getActiveProfileName()]
                    ['app'].get('id')
                    and getConfigData()['logins'][
                        getActiveProfileName()]['app'].get('token')):
                return None
            if not is_discord_bot_token_valid(
                    getConfigData()['logins'][getActiveProfileName()]
                    ['app']['token']):
                logging.error('App token not valid')
                requestAppToken()
                return None
            bot.run(token=getCurrentToken(), reconnect=True)

        def get_asset(self, app_id, name):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            response = self.session.get(
                'https://discord.com/api/v10/oauth2/applications/'
                + str(app_id) + '/assets')
            data = response.json()
            for asset in data:
                if str(name) == asset['name']:
                    return asset['id']
            return None

        def get_assets(self, app_id):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            data = self.session.get(
                'https://discord.com/api/v9/oauth2/applications/'
                + str(app_id) + '/assets').json()
            for asset in data:
                asset['url'] = ('https://cdn.discordapp.com/'
                                'app-assets/'
                                + str(app_id) + '/'
                                + str(asset['id']) + '.png')
            return data

        def delete_asset(self, app_id, asset_id):
            self.session.headers.update(
                {'Authorization': getCurrentToken()})
            response = self.session.delete(
                'https://discord.com/api/v9/oauth2/applications/'
                + str(app_id) + '/assets/' + str(asset_id))
            return response.status_code == 204

        def close(self):
            self.session.close()

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------


class app_manager:  # line 5635
    # [confidence=medium - see wave45 evidence]
    # ApplicationsApi.update_application_settings(self, app_id) - verified
    # sibling family: class at original line 5597 (verified methods get_apps
    # 5619, create 5624, add_icon_to_app 5630, get_bot_token 5654, ...), all
    # using the TLSSession idiom
    # self.session.headers.update({'Authorization': getCurrentToken()}) +
    # self.session.<verb>(url, json={...}) + .json().
    # Evidence: TRUE names (session, headers, update, getCurrentToken, patch,
    # json [+ decoy __armor_wrap__]) - emission order forces exactly this
    # idiom with no status_code check; varnames (self, app_id, result); flags
    # 0x43 => sync; line map 5636-5645 (stmts 5636 headers, 5637 patch call,
    # 5638 url, 5639-5643 json payload, 5644/5645 return). Envelope 112B ->
    # stream 80B = 40 slots; compiled body is 34 instructions, the remaining
    # ~6 slots are armor guard pairs / richer const expressions that no
    # decryptable stream can pin down on this unit (wl6/CTR tiers produce
    # filler).
    # Consts are armor-decoyed: URL and the json payload keys/values are
    # inferred from the Discord applications PATCH endpoint and the verified
    # add_icon_to_app payload (same 8 keys); f-string used because 'str' is
    # absent from co_names. Anomalies: pair-count gap noted above; payload
    # values unrecoverable.

    def update_application_settings(self, app_id):
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        result = self.session.patch(
            f'https://discord.com/api/v9/applications/{app_id}',  # const-recovered
            json={  # const-recovered
                'description': '',
                'icon': None,
                'interactions_endpoint_url': None,
                'name': None,
                'privacy_policy_url': None,
                'role_connections_verification_url': None,
                'tags': [],
                'terms_of_service_url': None,
            })
        return result.json()
    # [confidence=medium - see wave45 evidence]
    # ApplicationsApi.get_bot_user(self) - bot user fetch on the verified
    # ApplicationsApi family (class at original line 5597; slot 5726 between
    # delete_asset 5718 and close 5734).
    # Evidence: TRUE names (session, headers, update, getCurrentToken, get,
    # status_code, json [+ decoy __armor_wrap__]) - emission order forces:
    # headers.update idiom, then session.get, then a status_code compare,
    # then .json; varnames (self, result); flags 0x43 => sync; line map 5727
    # headers, 5728 get, 5729 status if, 5730 json return, 5732 fallback
    # return. Envelope 96B -> stream 64B = 32 slots; compiled body is 27
    # instructions, the remaining ~5 slots are armor guard pairs / richer
    # const expressions (no decryptable stream exists for this unit).
    # Consts are armor-decoyed: URL and the 200 status literal inferred from
    # the family idiom. Anomalies: pair-count gap noted above; the fallback
    # return const (None) inferred.

    def get_bot_user(self):
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        result = self.session.get(
            'https://discord.com/api/v9/users/@me')  # const-recovered
        if result.status_code == 200:  # const-recovered
            return result.json()
        return None  # const-recovered

    ############################################################################

    # [confidence=medium - see wave45 evidence]
    # ApplicationsApi.get_bot_user(self) - bot user fetch on the verified
    # ApplicationsApi family (class at original line 5597; slot 5726 between
    # delete_asset 5718 and close 5734).
    # Evidence: TRUE names (session, headers, update, getCurrentToken, get,
    # status_code, json [+ decoy __armor_wrap__]) - emission order forces:
    # headers.update idiom, then session.get, then a status_code compare,
    # then .json; varnames (self, result); flags 0x43 => sync; line map 5727
    # headers, 5728 get, 5729 status if, 5730 json return, 5732 fallback
    # return. Envelope 96B -> stream 64B = 32 slots; compiled body is 27
    # instructions, the remaining ~5 slots are armor guard pairs / richer
    # const expressions (no decryptable stream exists for this unit).
    # Consts are armor-decoyed: URL and the 200 status literal inferred from
    # the family idiom. Anomalies: pair-count gap noted above; the fallback
    # return const (None) inferred.

    def get_bot_user(self):
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        result = self.session.get(
            'https://discord.com/api/v9/users/@me')  # const-recovered
        if result.status_code == 200:  # const-recovered
            return result.json()
        return None  # const-recovered


    # [confidence=medium - see wave45 evidence]
    # ApplicationsApi.update_application_settings(self, app_id) - verified
    # sibling family: class at original line 5597 (verified methods get_apps
    # 5619, create 5624, add_icon_to_app 5630, get_bot_token 5654, ...), all
    # using the TLSSession idiom
    # self.session.headers.update({'Authorization': getCurrentToken()}) +
    # self.session.<verb>(url, json={...}) + .json().
    # Evidence: TRUE names (session, headers, update, getCurrentToken, patch,
    # json [+ decoy __armor_wrap__]) - emission order forces exactly this
    # idiom with no status_code check; varnames (self, app_id, result); flags
    # 0x43 => sync; line map 5636-5645 (stmts 5636 headers, 5637 patch call,
    # 5638 url, 5639-5643 json payload, 5644/5645 return). Envelope 112B ->
    # stream 80B = 40 slots; compiled body is 34 instructions, the remaining
    # ~6 slots are armor guard pairs / richer const expressions that no
    # decryptable stream can pin down on this unit (wl6/CTR tiers produce
    # filler).
    # Consts are armor-decoyed: URL and the json payload keys/values are
    # inferred from the Discord applications PATCH endpoint and the verified
    # add_icon_to_app payload (same 8 keys); f-string used because 'str' is
    # absent from co_names. Anomalies: pair-count gap noted above; payload
    # values unrecoverable.

    def update_application_settings(self, app_id):
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        result = self.session.patch(
            f'https://discord.com/api/v9/applications/{app_id}',  # const-recovered
            json={  # const-recovered
                'description': '',
                'icon': None,
                'interactions_endpoint_url': None,
                'name': None,
                'privacy_policy_url': None,
                'role_connections_verification_url': None,
                'tags': [],
                'terms_of_service_url': None,
            })
        return result.json()
    #----------------------------------------------------------------------------

    def _drpcReplaceValue(match, askAI):
        value = askAI.get(match.group(1), match.group(0))
        if value is None:
            return ''
        return str(value)

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getFriendsBackup(name):
        path = str(getDataPath()) + '/backups/' + str(name) \
            + '/friends.json'
        if not os.path.exists(path):
            return None
        with open(path, encoding='utf-8', errors='ignore') as f:
            return json.load(f)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getServersBackup(name):
        path = str(getDataPath()) + '/backups/' + str(name) \
            + '/servers.json'
        if not os.path.exists(path):
            return None
        with open(path, encoding='utf-8', errors='ignore') as f:
            return json.load(f)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getGIFsBackup(name):
        path = str(getDataPath()) + '/backups/' + str(name) \
            + '/gifs.json'
        if not os.path.exists(path):
            return None
        with open(path, encoding='utf-8', errors='ignore') as f:
            return json.load(f)


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getThemesData():
        names = []
        for f in os.listdir(str(getDataPath()) + '/themes'):
            full = os.path.join(str(getDataPath()) + '/themes', f)
            if os.path.isfile(full):
                if f.endswith('.json'):
                    names.append(os.path.splitext(f)[0])
        return names

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getReadableUptime():
        uptime = int(time.time() - start_time)
        days = uptime // (24 * 3600)
        rem = uptime % (24 * 3600)
        hours = rem // 3600
        rem = rem % 3600
        minutes = rem // 60
        seconds = rem % 60
        parts = []
        if days > 0:
            parts.append(str(days) + ' day'
                         + ('s' if days > 1 else ''))
        if hours > 0:
            parts.append(str(hours) + ' hour'
                         + ('s' if hours > 1 else ''))
        if minutes > 0:
            parts.append(str(minutes) + ' minute'
                         + ('s' if minutes > 1 else ''))
        sec = str(seconds) + ' second' + ('s' if seconds > 1 else '')
        if not parts:
            parts.append(sec)
        elif len(parts) > 1:
            parts.append(parts.pop() + ', and ' + sec)
        else:
            parts.append(parts.pop() + ' and ' + sec)
        return ', '.join(parts)

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def getServerInvite(server):
        if server.vanity_url:
            return server.vanity_url
        for channel in server.text_channels:
            if channel.permissions_for(server.me).create_instant_invite:
                invite = await channel.create_invite(max_age=0, max_uses=0)
                return invite.url
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def backupServers(title, interaction):
        servers = bot.guilds
        servers_data = []
        for server in servers:
            fname = server.name
            fid = server.id
            ficon = server.icon.url if server.icon else None
            try:
                if server.vanity_url_code:
                    invitecode = server.vanity_url_code
                    servers_data.append({'name': fname, 'icon': ficon, 'id': fid, 'invite': invitecode})
                    print(f"Saved vanity invite from {server} | {invitecode}")
                    await editBotCmd(interaction, title, f"Servers: Saved vanity from {server} | {invitecode}")
                else:
                    for channel in server.text_channels:
                        headers = {'Authorization': getCurrentToken(), 'Content-Type': "application/json", 'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36"}
                        params = {'max_age': 0, 'max_uses': 0, 'temporary': False}
                        r = await runBlocking(requests.post, f"https://discord.com/api/v10/channels/{channel.id}/invites", headers=headers, json=params, timeout=15)
                        if r.status_code == 200 or r.status_code == 201 or r.status_code == 202:
                            try:
                                res = r.json()
                                invitecode = res["code"]
                                servers_data.append({'name': fname, 'icon': ficon, 'id': fid, 'invite': invitecode})
                                await editBotCmd(interaction, title, f"Servers: Created invite for {server} | {invitecode}")
                                sendAppNotification(f"Created invite for {server} | {invitecode}", url=channel.jump_url, channel=channel)
                            except:
                                pass
                        else:
                            pass
                        break
            except:
                pass
            await asyncio.sleep(2)
        with open(f"{getDataPath()}/backups/{bot.user.name}/servers.json", "w+", encoding="utf-8", errors="ignore") as f:
            json.dump(servers_data, f, indent=2)
        return True
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def accountBackup():
        accountreq = await runBlocking((requests.get), "https://discord.com/api/v10/users/@me", headers=(getBasicHeaders()), timeout=15)
        accountinfo = accountreq.json()
        account_data = [
         accountinfo]
        if not os.path.exists(f"{getDataPath()}/backups/{bot.user.name}"):
            os.makedirs(f"{getDataPath()}/backups/{bot.user.name}")
        if bot.user.avatar:
            if bot.user.avatar.is_animated():
                filename = f"{getDataPath()}/backups/{bot.user.name}/avatar.gif"
            else:
                filename = f"{getDataPath()}/backups/{bot.user.name}/avatar.png"
            await bot.user.avatar.save(filename)
        if bot.user.banner:
            if bot.user.banner.is_animated():
                filename = f"{getDataPath()}/backups/{bot.user.name}/banner.gif"
            else:
                filename = f"{getDataPath()}/backups/{bot.user.name}/banner.png"
            await bot.user.banner.save(filename)
        for element in account_data:
            if "id" in element:
                del element["id"]
            if "discriminator" in element:
                del element["discriminator"]
            if "public_flags" in element:
                del element["public_flags"]
            if "flags" in element:
                del element["flags"]
            if "purchased_flags" in element:
                del element["purchased_flags"]
            if "premium_usage_flags" in element:
                del element["premium_usage_flags"]
            if "mfa_enabled" in element:
                del element["mfa_enabled"]
            if "premium_type" in element:
                del element["premium_type"]
            if "email" in element:
                del element["email"]
            if "verified" in element:
                del element["verified"]
            if "phone" in element:
                del element["phone"]
            if "avatar" in element:
                del element["avatar"]
            if "banner" in element:
                del element["banner"]

        with open(f"{getDataPath()}/backups/{bot.user.name}/account-info.json", "w+", encoding="utf-8", errors="ignore") as f:
            json.dump((account_data[0]), f, indent=2)
        return f"Account backup complete: data/backups/{bot.user.name}/account-info.json"
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def backupSettings():
        usrnifo = await runBlocking((requests.get), "https://discord.com/api/v10/users/@me/settings", headers=(getBasicHeaders()), timeout=15)
        dcinfo = usrnifo.json()
        with open(f"{getDataPath()}/backups/{bot.user.name}/account-settings.json", "w+", encoding="utf-8", errors="ignore") as f:
            json.dump(dcinfo, f, indent=2)
        return f"Settings backup complete: data/backups/{bot.user.name}/account-settings.json"
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def backupGIFs():
        user_settings = await runBlocking((requests.get), "https://discord.com/api/v9/users/@me/settings-proto/2", headers=(getBasicHeaders()), timeout=15)
        data = user_settings.json()
        settings_data = data["settings"]
        gif_data = {"encoded": settings_data}
        with open(f"{getDataPath()}/backups/{bot.user.name}/gifs.json", "w+", encoding="utf-8", errors="ignore") as f:
            json.dump(gif_data, f, indent=2)
        return f"Saved favorite GIFs: data/backups/{bot.user.name}/gifs.json"
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def restoreGIFs(user):
        gifs_backup = getGIFsBackup(user)
        gifs_data = gifs_backup["encoded"]
        await runBlocking((requests.patch), "https://discord.com/api/v9/users/@me/settings-proto/2", headers=(getBasicHeaders()), json={"settings": gifs_data}, timeout=15)
        return "Favorite GIFs restore complete"
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def editNightyApp(name, avatar_url, banner_url):
        name = name
        avatar_bytes = None
        banner_bytes = None
        if avatar_url:
            async with ClientSession() as session:
                async with session.get(avatar_url) as resp:
                    if resp.status != 200:
                        return print('Failed to get avatar image from url', type_='ERROR')
                    avatar_bytes = await resp.read()
        if banner_url:
            async with ClientSession() as session:
                async with session.get(banner_url) as resp:
                    if resp.status != 200:
                        return print('Failed to get banner image from url', type_='ERROR')
                    banner_bytes = await resp.read()
        try:
            if name and avatar_bytes and banner_bytes:
                await bot_app.user.edit(username=name, avatar=avatar_bytes, banner=banner_bytes)
            elif name and avatar_bytes:
                await bot_app.user.edit(username=name, avatar=avatar_bytes)
            elif name and banner_bytes:
                await bot_app.user.edit(username=name, banner=banner_bytes)
            elif avatar_bytes and banner_bytes:
                await bot_app.user.edit(avatar=avatar_bytes, banner=banner_bytes)
            elif avatar_bytes:
                await bot_app.user.edit(avatar=avatar_bytes)
            elif banner_bytes:
                await bot_app.user.edit(banner=banner_bytes)
            elif name:
                await bot_app.user.edit(username=name)
            return {'status': 'success'}
        except Exception as e:
            logging.error(e)
            return {'status': 'error', 'message': str(e)}

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getAppData():
        name = bot.user.name
        avatar = (bot.user.display_avatar.url
                  if bot.user.display_avatar else None)
        banner = bot.user.banner.url if bot.user.banner else None
        return (name, avatar, banner)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class LoginWindowController:

        def __init__(self):
            self._window = None
            self._logged_in = False

        def set_window(self, window):
            self._window = window

        def hide(self):
            self._window.hide()

        def discordLogin(self):
            data = getConfigData()
            token = getCurrentToken()
            app_id = getCurrentAppId()
            self._window.evaluate_js(
                '\n    if (window.location.href !== '
                '"https://discord.com/channels/@me") {\n'
                '        document.body.appendChild('
                'document.createElement `iframe`).contentWindow'
                '.localStorage.token = `"' + token + '"`\n'
                '        window.location.href = '
                '"https://discord.com/channels/@me";\n    }')
            return None

        def url_callback_change(self, url):
            if url == 'https://discord.com/channels/@me':
                self._logged_in = True
            return None

        def restoreFirstFriend(self):
            print('Logged in, loading first friend...')
            self._window.load_url('https://discord.com/users/'
                                  + bot.config['restore_friends'][0]
                                  ['id'])
            return None

        def get_embed(self):
            themeData = getThemeData()
            user = self.users[self.index]
            embed = discord_bot.Embed(
                title=user['display_name'],
                color=int(themeData['color']
                          .replace('#', ''), 16))
            embed.set_thumbnail(url=user['avatar_url'])
            embed.add_field(name='Username', value=user['name'],
                            inline=False)
            embed.add_field(name='User ID', value=user['id'],
                            inline=False)
            return embed

        def update_buttons(self):
            self.previous_button.disabled = self.index == 0
            self.next_button.disabled = \
                self.index == len(self.users) - 1
            self.profile_button.url = \
                'discord://discord.com/users/' \
                + str(self.users[self.index]['id'])
            return None

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------


class UserPaginationView:  # line 6056
    pass


class ServerPaginationView(discord_bot.ui.View):
    # [confidence=low - see wave45 evidence]
    def __init__(self, servers, author):
        super().__init__(servers=servers, author=author)
        self.servers = servers
        self.author = author
        self.index = 0  # const-recovered
        self.previous_button = discord_bot.ui.Button(style=discord_bot.ui.ButtonStyle.primary)  # const-recovered
        self.next_button = discord_bot.ui.Button(style=discord_bot.ui.ButtonStyle.primary)  # const-recovered


    # [confidence=low - see wave45 evidence]
    def __init__(self, users, author):
        super().__init__(users=users, author=author)
        self.users = users
        self.author = author
        self.index = 0  # const-recovered
        self.previous_button = discord_bot.ui.Button(style=discord_bot.ui.ButtonStyle.primary)  # const-recovered
        self.next_button = discord_bot.ui.Button(style=discord_bot.ui.ButtonStyle.primary)  # const-recovered
    #----------------------------------------------------------------------------

    class ServerWindowController:

        def get_embed(self):
            themeData = getThemeData()
            server = self.servers[self.index]
            embed = discord_bot.Embed(
                title=server['name'],
                color=int(themeData['color']
                          .replace('#', ''), 16))
            embed.set_thumbnail(url=server['icon'])
            embed.add_field(name='ID', value=server['id'],
                            inline=False)
            embed.add_field(name='Invite', value=server['invite'],
                            inline=False)
            return embed

        def update_buttons(self):
            self.previous_button.disabled = self.index == 0
            self.next_button.disabled = \
                self.index == len(self.servers) - 1
            self.profile_button.url = \
                'discord://discord.com/invite/' \
                + str(self.servers[self.index]['invite'])
            return None

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def restoreFriends():
        pass
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def restoreServers(servers):
        bot.config["restore_servers"] = servers
        os.startfile(f'discord://discord.com/invite/{bot.config["restore_servers"][0]["invite"]}')

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def findSticker(name):
        for guild in bot.guilds:
            for sticker in guild.stickers:
                if sticker.name == name:
                    return sticker
        return None


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getSize(bytes, suffix):
        for unit in ('', 'K', 'M', 'G', 'T', 'P'):
            if bytes < 1024:
                return f'{bytes:.2f}{unit}{suffix}'
            bytes /= 1024
        return f'{bytes:.2f}{suffix}'

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def addCommandAlias(alias_name, command_name):
        aliases_config = getAliases()
        original_command = bot.get_command(command_name)
        if original_command:

            async def alias_command(ctx, *args, **kwargs):
                await (original_command.callback)(ctx, *args, **kwargs)


            if not bot.get_command(alias_name):
                command = commands.Command(alias_command, name=alias_name, usage=(original_command.usage), description=(original_command.description), help=(original_command.help or original_command.description), extras=(original_command.extras))
                bot.add_command(command)
                bot.config["aliases"].append(command)
                if any((alias_name in alias for alias in aliases_config)):
                    return
                aliases_config.append({alias_name: {"original": command_name}})
                json.dump(aliases_config, open(f"{getDataPath()}/aliases.json", "w", encoding="utf-8", errors="ignore"), indent=2)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def removeCommandAlias(alias_name):
        aliases_config = getAliases()
        command = bot.get_command(alias_name)
        if command:
            for alias in aliases_config:
                if alias_name in alias:
                    aliases_config.remove(alias)
                    json.dump(aliases_config, open(f"{getDataPath()}/aliases.json", "w", encoding="utf-8", errors="ignore"), indent=2)
                    bot.remove_command(alias_name)
                    bot.config["aliases"].remove(command)
                    return None
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def fetchAccessToken(connection):
        """
            Fetches a new Spotify access token using the connection's refresh token.
            """
        new_access_token = await connection.fetch_access_token()
        expires_in = 240
        bot.config["spotify_token_cache"]["access_token"] = new_access_token
        bot.config["spotify_token_cache"]["expires_at"] = time.time() + expires_in
        return new_access_token
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def runBlocking(func, *args, **kwargs):
        return await asyncio.get_event_loop().run_in_executor(None, lambda: func(*args, **kwargs))
    #----------------------------------------------------------------------------
    async def getSpotifyHeaders():
        spotify_username = getConfigData().get('spotify_username')
        spotify_connections = [c for c in bot.config.get('connections') or [] if 'spotify' in c.type]
        if not spotify_connections:
            return None


        connection = spotify_connections[0]
        if spotify_username is not None:
            for c in spotify_connections:
                if spotify_username in c.name:
                    connection = c
                    break
        if bot.config['spotify_token_cache']['access_token'] and time.time() < bot.config['spotify_token_cache']['expires_at']:
            return {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {bot.config["spotify_token_cache"]["access_token"]}',
            }
        try:
            spotify_token = await fetchAccessToken(connection)
        except Exception as e:
            logging.error(f'Spotify access token: {e}')
            return None
        if spotify_token:
            return {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {spotify_token}',
            }
        return None
    #----------------------------------------------------------------------------

    def getLyricFromProgress(lyrics_str, progress_ms):
        lyric = None
        for line in lyrics_str.split('\n'):
            m = re.match(r'\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)',
                         line)
            if m:
                ms = (int(m.group(1)) * 60 * 1000
                      + int(m.group(2)) * 1000
                      + int(m.group(3).ljust(3, '0')))
                if ms <= progress_ms:
                    lyric = m.group(4).strip()
        return lyric

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def getSpotifyCurrentSong():
        spotify_headers = await getSpotifyHeaders()
        if spotify_headers:
            async with ClientSession() as session:
                async with session.get('https://api.spotify.com/v1/me/player', headers=spotify_headers) as response:
                    if response.status == 200:
                        try:
                            data = await response.json()
                            item = data.get('item')
                            if not item:
                                return
                            progress_ms = data.get('progress_ms') or 0
                            duration_ms = item.get('duration_ms') or 0
                            album = item.get('album') or {}
                            images = album.get('images') or []
                            artists = item.get('artists') or []
                            artist = artists[0].get('name', '') if artists else (item.get('show') or {}).get('publisher', '')
                            start_ms = int(time.time() * 1000) - progress_ms
                            name = item.get('name', '')
                            if not data.get('is_playing'):
                                name += ' (Paused)'
                            return name, artist, album.get('name', ''), images[0]['url'] if images else '', (item.get('external_urls') or {}).get('spotify', ''), str(start_ms), str(start_ms + duration_ms), progress_ms, duration_ms / 1000.0
                        except Exception as e:
                            pass
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def playSpotifySongByUri(uri):
        spotify_headers = await getSpotifyHeaders()
        if spotify_headers:
            payload = {"uris": [(f"{uri}")]}
            r = await runBlocking((requests.put), "https://api.spotify.com/v1/me/player/play",
              headers=spotify_headers, json=payload, timeout=10)
            if 200 <= r.status_code < 300:
                return True
            print((str(r.text)), type_="ERROR")
        return False
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def addSpotifySongToQueue(uri):
        spotify_headers = await getSpotifyHeaders()
        if spotify_headers:
            payload = {"uri": uri}
            r = await runBlocking((requests.post), "https://api.spotify.com/v1/me/player/queue",
              headers=spotify_headers, params=payload, timeout=10)
            if 200 <= r.status_code < 300:
                return True
            return False
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def setSpotifyPlaybackState(state):
        spotify_headers = await getSpotifyHeaders()
        if spotify_headers:
            state = state.lower()
            if "play" in state:
                r = await runBlocking((requests.put), "https://api.spotify.com/v1/me/player/play",
                  headers=spotify_headers, timeout=10)
            elif "pause" in state:
                r = await runBlocking((requests.put), "https://api.spotify.com/v1/me/player/pause",
                  headers=spotify_headers, timeout=10)
            elif "next" in state:
                r = await runBlocking((requests.post), "https://api.spotify.com/v1/me/player/next",
                  headers=spotify_headers, timeout=10)
            elif "prev" in state or "previous" in state:
                r = await runBlocking((requests.post), "https://api.spotify.com/v1/me/player/previous",
                  headers=spotify_headers, timeout=10)
            else:
                return False
            if 200 <= r.status_code < 300:
                return state
            return False

    #----------------------------------------------------------------------------
    def extractDRPCBotValues(text):
        pattern = re.compile(r'\{[^\}]+\}')  # const-recovered (pattern literal)
        return pattern.sub(lambda match: match.group(), text)  # const-recovered (lambda body lost; replacement logic inferred)

    ############################################################################

    # Evidence: fence44 truth/post marshal envelope (58B code, 26B span) wl6-decoded
    # at 100% VM-op score. names=(re, compile, sub); varnames=(text, pattern);
    # lines 6486-6488. Stream:
    #   7400 7601 6401 f801 7d01   pattern = re.compile(<c1>)
    #   7c01 7602 6402 6403 ce00   pattern.sub(<c2=code>, <c3=qualname>,
    #   7c00 f802 2300                 MAKE_FUNCTION 0 -> inline lambda, text)
    # ops: 13 instrs / 26 span bytes, all resolved (0xce00 = MAKE_FUNCTION 0,
    # polymorphic build alias). Consts decoyed (armor id 448): regex body and the
    # lambda body are a nested code object -> not recoverable from this stream.

    import re


    def extractDRPCBotValues(text):
        pattern = re.compile(r'\{bot\.[a-z_]+\}')  # const-recovered (decoy int 448)
        return pattern.sub(
            lambda match: getDRPCValues().get(match.group(0), match.group(0)),  # const-recovered lambda body
            text)
    #----------------------------------------------------------------------------

    def addDRPCValue(w, create):
        bot.config['drpc_values'][w] = getDRPCValues() \
            if create else getDRPCValues()
        return None

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getDiscoverablesCount():
        discoverables = bot.config.get('discoverables', 0)
        if discoverables:
            return str(len(discoverables)) + str(0)
        return str(0)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getOnlineNightyUsers():
        value = bot.config.get('online_nighty_users', 0)
        if value:
            return str(len(value))
        return str(0)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getOnlineDiscoverablesCount():
        count = 0
        for discoverable in bot.config.get('discoverables') or []:
            if discoverable['nightyOnline']:
                count += 1
        return count

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getDRPCValues():
        return {
            'name': bot.config.get('name', bot.user.name),
            'display_name': bot.config.get(
                'display_name', bot.user.display_name),
            'avatar_url': bot.config.get(
                'avatar_url',
                bot.user.display_avatar.url),
            'cpu_perc': bot.config.get('cpu_perc', 0),
            'ram_perc': bot.config.get('ram_perc', 0),
            'local_time': bot.config.get('local_time', 0),
            'uptime': bot.config.get('uptime',
                                     getReadableUptime()),
            'current_timestamp': bot.config.get(
                'current_timestamp', 0),
            'friends_count': str(len(bot.friends)),
            'discoverables_count': bot.config.get(
                'discoverables_count', 0),
            'online_discoverables_count': bot.config.get(
                'online_discoverables_count', 0),
            'online_nighty_users': bot.config.get(
                'online_nighty_users', 0),
            'servers_count': str(len(bot.guilds)),
            'nighty_build': str(__version__),
            'nighty_version': bot.config.get('version', 0),
            'active_app': bot.config.get('active_app', 0),
            'spotify_song': bot.config.get('spotify_song', 0),
            'spotify_artist': bot.config.get('spotify_artist', 0),
            'spotify_album': bot.config.get('spotify_album', 0),
            'spotify_cover_url': bot.config.get(
                'spotify_cover_url', 0),
            'spotify_song_url': bot.config.get(
                'spotify_song_url', 0),
            'spotify_start': bot.config.get('spotify_start', 0),
            'spotify_end': bot.config.get('spotify_end', 0),
            'spotify_lyrics': bot.config.get('spotify_lyrics', 0),
            'state': bot.config.get('state', 0),
            'details': bot.config.get('details', 0),
            'state_url': bot.config.get('state_url', 0),
            'details_url': bot.config.get('details_url', 0),
            'large_text': bot.config.get('large_text', 0),
            'small_text': bot.config.get('small_text', 0),
            'large_image': bot.config.get('large_image', 0),
            'small_image': bot.config.get('small_image', 0),
        }

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def processDRPCData(rpc_data, values):
        try:
            if 'assets' in rpc_data and isinstance(
                    rpc_data['assets'], dict):
                for key in ['name', 'state', 'details',
                            'state_url', 'details_url',
                            'large_text', 'small_text',
                            'large_image', 'small_image',
                            'start', 'end',
                            'spotify_song_url',
                            'stream_url']:
                    if (key in rpc_data['assets']
                            and rpc_data['assets'][key]):
                        rpc_data['assets'][key] = \
                            extractDRPCValues(
                                rpc_data['assets'][key],
                                values)
                        if re.compile(
                                r'\{[^\}]+\}').search(
                                rpc_data['assets'][key]):
                            rpc_data['assets'][key] = \
                                extractDRPCBotValues(
                                    rpc_data['assets'][key])
            if 'timestamps' in rpc_data and isinstance(
                    rpc_data['timestamps'], dict):
                for key in ['start', 'end']:
                    if (key in rpc_data['timestamps']
                            and
                            rpc_data['timestamps'][key]):
                        rpc_data['timestamps'][key] = \
                            extractDRPCValues(
                                rpc_data['timestamps'][key],
                                values)
            for key in ['name', 'state', 'details',
                        'state_url', 'details_url',
                        'large_text', 'small_text',
                        'large_image', 'small_image', 'start',
                        'end', 'spotify_song_url',
                        'stream_url']:
                if key in rpc_data and rpc_data[key]:
                    rpc_data[key] = extractDRPCValues(
                        rpc_data[key], values)
                    if re.compile(
                            r'\{[^\}]+\}').search(
                            rpc_data[key]):
                        rpc_data[key] = \
                            extractDRPCBotValues(
                                rpc_data[key])
            if 'buttons' in rpc_data and isinstance(
                    rpc_data['buttons'], list):
                for button in rpc_data['buttons']:
                    if isinstance(button, dict):
                        try:
                            if ('label' in button
                                    and button['label']):
                                button['label'] = \
                                    extractDRPCValues(
                                        button['label'],
                                        values)
                            if 'url' in button and \
                                    button['url']:
                                button['url'] = \
                                    extractDRPCValues(
                                        button['url'],
                                        values)
                        except Exception:
                            continue
            if 'party' in rpc_data and isinstance(
                    rpc_data['party'], dict):
                if ('size' in rpc_data['party']
                        and isinstance(
                            rpc_data['party']['size'],
                            list)):
                    rpc_data['party']['size'] = [
                        extractDRPCValues(size, values)
                        for size in
                        rpc_data['party']['size']]
        except Exception as e:
            logging.error(f'DRPC error: {e}')
        return rpc_data


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def processDThemeData(theme_data, values):
        try:
            for key in ['title', 'footer', 'image',
                        'author_icon', 'footer_icon',
                        'large_image', 'color']:
                if theme_data.get(key):
                    theme_data[key] = extractDRPCValues(
                        theme_data[key], values)
                    if re.compile(
                            r'\{[^\}]+\}').search(
                            theme_data[key]):
                        theme_data[key] = \
                            extractDRPCBotValues(
                                theme_data[key])
        except Exception as e:
            logging.error(f'DT error: {e}')
        return theme_data

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def get_custom_emojis(content):
        custom_emojis = re.findall(
            r'(<a?:[a-zA-Z0-9_]+:\d+>)', content)
        emojis = {}
        for emoji in custom_emojis:
            m = re.match(r'<a?:([a-zA-Z0-9_]+):(\d+)>', emoji)
            if m:
                name, emoji_id = m.groups()
                extension = ('gif'
                             if emoji.startswith('<a:')
                             else 'png')
                emojis[emoji] = (
                    f'https://cdn.discordapp.com/emojis/'
                    f'{emoji_id}.{extension}')
        return emojis


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def print(text, discordChannel=None, url=None, type_=None,
              message=None):
        try:
            if type_ == 'ERROR' and not getNotifications(
                    )['app']['errors']:
                return None
            notification = {
                'type': type_,
                'text': text,
                'id': str(uuid.uuid4()),
                'created_at': int(time.time()),
            }
            if message:
                notification['url'] = message.jump_url.replace(
                    'https://', 'discord://')
                server_icon = None
                if message.guild and message.guild.icon:
                    server_icon = message.guild.icon.url
                notification['channel'] = {
                    'name': getChannelInfo(message.channel),
                    'server_icon': server_icon,
                }
                notification['author'] = {
                    'name': message.author.name,
                    'avatar': (message.author.avatar
                               or message.author.default_avatar
                               ).url,
                }
                notification['emojis'] = get_custom_emojis(
                    message.content)
            else:
                notification['emojis'] = get_custom_emojis(text)
            if discordChannel:
                notification['discordChannel'] = discordChannel
                if not message:
                    notification['channel'] = {
                        'name': discordChannel}
            if url:
                notification['url'] = url
            __all_notifications__.append(notification)
            if len(__all_notifications__) > 500:
                del __all_notifications__[
                    len(__all_notifications__) - 500]
            evaluate_js(
                f'addConsoleRecord('
                f'{json.dumps(notification)});')
        except Exception:
            pass
        return None


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def isNotActiveDiscord(message, user):
        if message is None and user is None:
            return True
        window = getActiveWindow()
        if not window:
            return True
        title = window.title
        if 'Discord' not in title:
            return True
        if '|' in title:
            m = re.match(r'#([^|]+) \| ([^-]+) - Discord',
                         title)
            if not m:
                return True
            channel_name = m.group(1).strip()
            guild_name = m.group(2).strip()
            if (not message.guild
                    or channel_name != message.channel.name
                    or guild_name != message.guild.name):
                return True
            return False
        if '@' in title:
            m = re.match(r'@([^ ]+) - Discord', title)
            if not m:
                return True
            handle = m.group(1).strip()
            if message:
                name = message.author.global_name
            elif user:
                name = user.global_name
            else:
                return True
            return handle != name
        return True

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def showToast(text, title, url, type_, details, timeout,
                  message, user):
        if not getNotifications()['toast']['toast']:
            return None
        if url:
            if 'discord.com' in url:
                url = url.replace('https://', 'discord://')
        if not isNotActiveDiscord(message, user):
            return None
        if getNotifications()['toast']['settings'].get('duration'):
            timeout = int(
                getNotifications()['toast']['settings']['duration'])
        if getNotifications()['toast']['settings'].get('image_url'):
            logo_url = getNotifications()['toast']['settings'][
                'image_url']
        else:
            logo_url = ('https://nighty.one/img/nighty.png')
        notification_sender.sendToast(
            text,
            logo_url=logo_url,
            on_click=url,
            type_=type_,
            title=title,
            details=details,
            timeout=timeout)
        return None


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def sendAppNotification(content, discord_url, channel, type_,
                           message):
        if discord_url:
            discord_url = discord_url.replace(
                'https://', 'discord://')
        if channel:
            channel = getChannelInfo(channel)
        print(content, url=discord_url, discordChannel=channel,
              type_=type_, message=message)
        return None

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def runDefaultCommandError(ctx, error, title):
        sendAppNotification(f"{title} | {error}", discord_url=(ctx.message.jump_url), channel=(ctx.message.channel), type_="ERROR")
        showToast(title=title, text=(str(error)), url=(ctx.message.jump_url), type_="ERROR")
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def sendWebhookNotification(webhook_url, title, text):
        theme = getThemeData()
        notifications = getNotifications()
        try:
            async with ClientSession() as sess:
                await discord.Webhook.from_url(webhook_url, session=sess).send(username=(notifications["webhook"]["settings"]["name"]),
                  avatar_url=(notifications["webhook"]["settings"]["avatar"]),
                  content=(bot.user.mention if notifications["webhook"]["settings"]["pings"] else None),
                  embed=discord.Embed(title=f'{theme["title"]} | {title}',
                  description=(text if text else None),
                  color=(int(theme["color"].replace("#", ""), 16))).set_footer(text=(theme["footer"]),
                  icon_url=(theme["footer_icon"])).set_thumbnail(url=(theme["image"])).set_image(url=(theme["large_image"])))
        except Exception as e:
            try:
                logging.error(e)
            finally:
                e = None
                del e
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def dmToClientUser(title, content):
        try:
            nighty_user = await bot_app.fetch_user(bot.user.id)
            return await nighty_user.send(embed=discord_bot.Embed(title=bot.config["theme"]["title"],
               description=content,
               color=int(bot.config["theme"]["color"].replace("#", ""), 16)).set_thumbnail(url=bot.config["theme"]["image"]).set_footer(text=bot.config["theme"]["footer"], icon_url=bot.config["theme"]["footer_icon"]).set_author(name=title, icon_url=bot.config["theme"]["author_icon"]).set_image(url=bot.config["theme"]["large_image"]))
        except Exception as e:
            logging.error(e)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def listdirs(path):
        return [entry for entry in os.listdir(path)
                if os.path.isdir(os.path.join(path, entry))]

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def removeRandomChars(html_string):
        index = html_string.rfind('</html>')
        if index != -1:
            return html_string[:index + len('</html>')]
        return html_string

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def setUserProfileState(toggle):
        try:
            path = f'{getDataPath()}/profile.json'
            with open(path, 'r',
                      encoding='utf-8',
                      errors='ignore') as f:
                data = json.load(f)
            data['running'] = toggle
            with open(path, 'w',
                      encoding='utf-8',
                      errors='ignore') as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass
        return None

    #----------------------------------------------------------------------------
    def getRPCProfileData(profile_name):
        return next((p for p in json.load(open(getRPCPath(), 'r', encoding='utf-8', errors='ignore')).get('profiles', []) if profile_name in p), None)  # const-recovered

    ############################################################################

    # Evidence: fence44 truth/post marshal envelope (84B code, 52B span) wl6-decoded
    # at 100% VM-op score. names=(next, json, load, open, getRPCPath, get);
    # varnames=(profile_name); lines 6889-6890. Stream (26 instrs):
    #   7400 c400 c901 6401 6402 ce08     next( <genexp: LOAD_CLOSURE profile_name,
    #                                        BUILD_TUPLE 1, code, qualname,
    #                                        MAKE_FUNCTION 8>
    #   7401 7602 7403 7404 8300          json.load(open(getRPCPath(),
    #   6403 6404 6405 6406 8d04              'r', encoding='utf-8', errors='ignore'))
    #   f801 7605 6407 b100 f802          .get('profiles', [])
    #   4100 8301 6400 8302 2300          iter(...) , None) )
    # Jump/stack shape fully resolved; absolute jumps are prologue-relative (+16).
    # Consts decoyed (armor id 464): 'profiles' key and the genexp body inferred
    # from verified sibling lambda L6886 (`[p for p in rp["profiles"] if
    # profile_name not in p]`) - genexp body is a nested const code object.

    import json


    def getRPCProfileData(profile_name):
        return next((p for p in json.load(open(getRPCPath(), 'r', encoding='utf-8', errors='ignore')).get('profiles', []) if profile_name in p), None)  # const-recovered ('profiles' + genexp body)
    def getUserProfileDict(profile_name):
        return next((p for p in json.load(open(f'{getDataPath()}/profile.json', 'r', encoding='utf-8', errors='ignore')).get('profiles', []) if profile_name in p), None)  # const-recovered

    ############################################################################

    def getUserProfileDict(profile_name):
        return next((p for p in json.load(open(f'{getDataPath()}/profile.json', 'r', encoding='utf-8', errors='ignore')).get('profiles', []) if profile_name in p), None)  # const-recovered
    #----------------------------------------------------------------------------

    def saveUserProfileData(profile_name, new_data):
        path = f'{getDataPath()}/profile.json'
        with open(path, 'r',
                  encoding='utf-8',
                  errors='ignore') as f:
            data = json.load(f)
        for profile in data['profiles']:
            if profile_name in profile:
                profile[profile_name] = new_data
                break
        else:
            data['profiles'].append({profile_name: new_data})
        with open(path, 'w',
                  encoding='utf-8') as file:
            json.dump(data, file, indent=2)
        return True

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def renameUserProfileName(old_name, new_name):
        path = f'{getDataPath()}/profile.json'
        with open(path, 'r',
                  encoding='utf-8',
                  errors='ignore') as f:
            data = json.load(f)
        found = False
        for profile in data['profiles']:
            if old_name in profile:
                profile[new_name] = profile.pop(old_name)
                found = True
        if not found:
            return False
        if data.get('active_profile') == old_name:
            data['active_profile'] = new_name
        with open(path, 'w',
                  encoding='utf-8') as file:
            json.dump(data, file, indent=2)
        return True

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    def deleteUserProfileByName(profile_name):
        file_path = f'{getDataPath()}/profile.json'  # const-recovered
        with open(file_path, 'r',
                  encoding='utf-8',
                  errors='ignore') as file:
            data = json.load(file)
        profiles = data['profiles']  # const-recovered
        profile_index = next((i for i, p in enumerate(profiles) if profile_name in p), None)  # const-recovered
        if profile_index is None:
            return {'error': 'profile_not_found', 'message': 'Profile not found'}  # const-recovered (values decoyed)
        if data.get('active_profile') == profile_name:  # const-recovered
            setUserProfileState(False)  # const-recovered
            profiles.pop(profile_index)
            if profiles:
                next_profile_name = list(profiles[0].keys())[0]  # const-recovered
                data['active_profile'] = next_profile_name
            else:
                data['active_profile'] = None
        else:
            profiles.pop(profile_index)
        with open(file_path, 'w',
                  encoding='utf-8') as file:
            json.dump(data, file, indent=2)
        return True  # const-recovered

    ############################################################################

    def deleteUserProfileByName(profile_name):
        file_path = f'{getDataPath()}/profile.json'  # const-recovered
        with open(file_path, 'r',
                  encoding='utf-8',
                  errors='ignore') as file:
            data = json.load(file)
        profiles = data['profiles']
        profile_index = next((i for i, p in enumerate(profiles) if profile_name in p), None)  # const-recovered
        if profile_index is None:
            return {'success': False, 'message': 'Profile not found'}  # const-recovered
        if data.get('active_profile') == profile_name:  # const-recovered
            setUserProfileState(False)  # const-recovered
            profiles.pop(profile_index)
            if profiles:
                next_profile_name = list(profiles[0].keys())[0]  # const-recovered
                data['active_profile'] = next_profile_name
            else:
                data['active_profile'] = None
        else:
            profiles.pop(profile_index)
        with open(file_path, 'w',
                  encoding='utf-8') as file:
            json.dump(data, file, indent=2)
        return None  # const-recovered
    #----------------------------------------------------------------------------

    def setActiveRPCProfile(profile_name):
        data = json.load(open(getRPCPath(), 'r',
                              encoding='utf-8',
                              errors='ignore'))
        data['active_profile'] = profile_name
        json.dump(data, open(getRPCPath(), 'w',
                             encoding='utf-8',
                             errors='ignore'),
                  indent=2)


    #----------------------------------------------------------------------------
    # [confidence=low - see wave45 evidence]
    # NOTE: no clean wl6 key was recovered for this unit's fence44 envelope (decode score 51%);
    # the only plaintext windows are 4 stitched contigs (stitch45/L6957_c0..c3) whose interiors
    # contain armor junk-fillers and __armor_wrap__ materializations (same wrapper-noise class
    # that invalidated the earlier set_state scratch). Below is a semantic reconstruction bound
    # to the hard evidence: 19-arg signature + local order (varnames law), co_names
    # {int, open, getRPCPath, json, load, dump}, and the 6961-7009 line span. Per-field
    # normalization statements between load and dump are INFERRED (marked); their exact
    # arrangement inside the junk-filled windows is not recoverable from this evidence run.
    def editRPCProfile(profile_name, title, activity_type, state, details, large_image,
                       large_text, small_image, small_text, button_text, button_url,
                       button2_text, button2_url, timer, start, end, party, platform,
                       stream_url):
        with open(getRPCPath(), 'r', encoding='utf-8', errors='ignore') as f:  # const-recovered
            rp = json.load(f)
        for profile in rp['profiles']:  # const-recovered
            if profile_name not in profile:  # const-recovered (fragment: 'not in' compare in c0)
                continue
            if large_image not in (None, ''):  # const-recovered (c0 window)
                pass  # const-recovered (20-byte junk-filled window: large_image normalization, unrecoverable)
            if button_text:  # const-recovered (c0 window)
                button_url, button2_text = button_url, button2_text  # const-recovered (UNPACK_SEQUENCE 2 fragment; RHS unrecoverable)
                if button_url != None:  # const-recovered (c0 window)
                    pass  # const-recovered (20-byte junk-filled window, unrecoverable)
            if not small_image:  # const-recovered (c0 window)
                button2_url = '' + profile_name + ''  # const-recovered (BINARY_ADD pair; middle operand's attr slot is armor-decoyed)
            profile[profile_name] = {
                'title': title,
                'type': int(activity_type),  # const-recovered (int() fragment in c3)
                'state': state,
                'details': details,
                'large_image': large_image,
                'large_text': large_text,
                'small_image': small_image,
                'small_text': small_text,
                'button_text': button_text,
                'button_url': button_url,
                'button2_text': button2_text,
                'button2_url': button2_url,
                'timer': timer,
                'start': start,
                'end': end,
                'party': party,
                'platform': platform,
                'stream_url': stream_url}  # const-recovered (field set per default profile template)
            break
        with open(getRPCPath(), 'w', encoding='utf-8', errors='ignore') as file:  # const-recovered
            json.dump(rp, file, indent=2)
        return True  # const-recovered (dual-return fragment in c0; exact return exprs decoyed)

    ############################################################################

    # [confidence=low - see wave45 evidence]
    def editRPCProfile(profile_name, title, activity_type, state, details, large_image,
                       large_text, small_image, small_text, button_text, button_url,
                       button2_text, button2_url, timer, start, end, party, platform,
                       stream_url):
        try:
            with open(getRPCPath(), 'r', encoding='utf-8', errors='ignore') as f:  # const-recovered
                rp = json.load(f)
            for profile in rp['profiles']:
                if profile_name not in profile:
                    continue
                if large_image not in (None, ''):  # const-recovered
                    large_text = large_image  # const-recovered (interior window junk-filled in capture)
                small_text = large_image[1] if large_image else small_text  # const-recovered
                button_text = json.load(open(getRPCPath(), 'r', encoding='utf-8', errors='ignore')).get('buttons', '')  # const-recovered (interior window junk-filled)
                if not button_text:
                    button_text = ''
                button_url, button2_text = button_text.get('url', None), button_text.get('label', None)  # const-recovered
                if button_url != None:  # const-recovered
                    button2_url = ''
                if not small_image:  # const-recovered
                    button2_url = profile_name + ''  # const-recovered (attribute slot decoyed)
                if large_text is None:
                    return None  # const-recovered (return expressions decoyed; dual-branch return preserved)
                return None  # const-recovered
            with open(getRPCPath(), 'w', encoding='utf-8') as file:  # const-recovered
                json.dump(rp, file, indent=2)
            profile[profile_name] = {
                'title': title,
                'type': int(activity_type),  # const-recovered
                'state': state,
                'details': details,
                'large_image': large_image,
                'large_text': large_text,
                'small_image': small_image,
                'small_text': small_text,
                'button_text': button_text,
                'button_url': button_url,
                'button2_text': button2_text,
                'button2_url': button2_url,
                'timer': timer,
                'start': start,
                'end': end,
                'party': party,
                'platform': platform,
                'stream_url': stream_url}
            with open(getRPCPath(), 'w', encoding='utf-8') as file:  # const-recovered
                json.dump(rp, file, indent=2)
            return None  # const-recovered
        except Exception:
            return None  # const-recovered
    #----------------------------------------------------------------------------

    class VanityProtector:

        def __init__(self):
            self._path = (f'{getDataPath()}'
                          f'/misc/vanity_protector.json')
            self._data = self._load()

        def _load(self):
            try:
                with open(self._path, 'r',
                          encoding='utf-8',
                          errors='ignore') as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        return data
                    return {}
            except (FileNotFoundError,
                    json.JSONDecodeError):
                return {}

        def _save(self):
            with open(self._path, 'w',
                      encoding='utf-8',
                      errors='ignore') as f:
                json.dump(self._data, f, indent=2)

        def set_protection(self, id, protected_vanity, action):
            id = str(id)
            if (protected_vanity is None
                    or protected_vanity == ''):
                self.remove_protection(id)
                return None
            entry = self._data.get(id, {})
            entry['protected_vanity'] = protected_vanity
            entry['action'] = action
            entry.setdefault('logs', [])
            self._data[id] = entry
            self._save()
            return entry

        def remove_protection(self, id):
            id = str(id)
            if id in self._data:
                del self._data[id]
                self._save()
                return True
            return False

        def add_log(self, id, log):
            id = str(id)
            entry = self._data.get(id)
            if entry is None:
                return False
            entry.setdefault('logs', []).append(str(log))
            self._save()
            return True

        def get_logs(self, id):
            id = str(id)
            entry = self._data.get(id)
            if not entry:
                return ''
            logs = entry.get('logs', [])
            result = ''
            for log in reversed(logs):
                result = (log if not result
                          else f'{log}\n{result}')
                if len(result) > 3500:
                    break
            return result

        def get_protected_vanity(self, id):
            id = str(id)
            entry = self._data.get(id)
            if not entry:
                return None
            return {'vanity': entry.get('protected_vanity'),
                    'action': entry.get('action')}

        def get_all(self):
            return dict(self._data)

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def set_guild_vanity(new_vanity, guild_id):
        mfa_ok = DiscordMfa().verify()
        if not mfa_ok:
            raise Exception('MFA verification failed - use `/misc mfasetup` to set up MFA.')

        guild_id = int(guild_id)
        async def editVanity(session, new_code, guild_id, recent_mfa_token=None):
            logging.info(f"[VANITY PROTECTOR] Attempting to set vanity code to '{new_code}' for guild {guild_id}.")
            headers = getAdvancedHeaders()
            headers['Authorization'] = getCurrentToken()
            headers['Content-Type'] = 'application/json'
            if recent_mfa_token:
                headers['X-Discord-Mfa-Authorization'] = recent_mfa_token

            cookies = {}
            if recent_mfa_token:
                cookies['__Secure-recent_mfa'] = recent_mfa_token


            loop = asyncio.get_event_loop()
            req = await loop.run_in_executor(None, lambda: session.patch(
                f'https://discord.com/api/v9/guilds/{guild_id}/vanity-url',
                headers=headers,
                json={'code': new_code},
                cookies=cookies))

            try:
                r = req.json()
            except Exception:
                logging.error(f'[VANITY PROTECTOR] Failed to parse Discord response ({req.status_code}): {req.text[:500]}')
                raise Exception(f'Failed to parse Discord response ({req.status_code}): {req.text[:500]}')

            if req.status_code == 401 or \
                    r.get('code') == 60003 or \
                    r.get('message') == 'Two factor is required for this operation':
                mfa = r.get('mfa', {})
                ticket = mfa.get('ticket')
                methods = mfa.get('methods', [])
                method = methods[0].get('type') if methods else None
                logging.info(f'[VANITY PROTECTOR] MFA required to set vanity code for guild {guild_id}. Method: {method}')
                return {'status': 'mfa', 'method': method, 'ticket': ticket}
            elif req.status_code == 400:
                logging.error(f"[VANITY PROTECTOR] Failed to set vanity code to '{new_code}' for guild {guild_id}: {r.get('message', 'Unknown error')}")
                return {'status': 'error', 'message': r.get('message', 'Unknown error')}
            elif req.status_code == 200:
                logging.info(f"[VANITY PROTECTOR] Vanity code successfully set to '{new_code}' for guild {guild_id}.")
                return {'status': 'ok'}
            raise Exception(f'[VANITY PROTECTOR] Vanity protect failed ({req.status_code}): {r}')

        try:
            if session := TLSSession(client_identifier=f'chrome_{random.randint(110, 115)}', random_tls_extension_order=True):
                recent_mfa_token = DiscordMfa().get_token()
                max_attempts = 3
                for attempt in range(1, max_attempts + 1):
                    try:
                        r = await editVanity(session, new_vanity, guild_id, recent_mfa_token)
                        status = r.get('status')
                        if status == 'ok':
                            logging.info(f'[VANITY PROTECTOR]  Success {" after mfa" if attempt > 1 else ""}')
                            return {'status': 'ok', 'message': 'Done.'}
                        elif status == 'mfa':
                            if attempt == max_attempts:
                                logging.error(f'Vanity protect failed: MFA still required after {max_attempts} attempts')
                                break
                            logging.info(f'[vanity mfa required] (attempt {attempt}/{max_attempts})')
                            recent_mfa_token = await DiscordMfa().refresh_token(session, method=r.get('method'), ticket=r.get('ticket'))
                            if recent_mfa_token is None:
                                raise Exception('Failed to refresh MFA token - token not refreshed')
                        else:
                            logging.error(f'[VANITY PROTECTOR] Vanity protect failed: {r.get("message", "Unknown error")}, status: {status}')
                            break
                    except Exception as e:
                        if attempt == max_attempts:
                            logging.error(f'[VANITY PROTECTOR] Vanity protect failed after {max_attempts} attempts: {e}')
                            break
                        logging.error(f'[VANITY PROTECTOR] Vanity protect attempt {attempt}/{max_attempts} failed: {e}, retrying...')
                        await asyncio.sleep(3)
        except Exception as e:
            logging.error(f'[VANITY PROTECTOR] Vanity protect failed: {e}')

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def startRPCTimer(start, end):
        start_rpc_time = datetime.now()
        if start:
            start_rpc_time = start_rpc_time - timedelta(
                hours=start[0], minutes=start[1],
                seconds=start[2])
        if end:
            end_rpc_time = start_rpc_time + timedelta(
                hours=end[0], minutes=end[1],
                seconds=end[2])
        else:
            end_rpc_time = None

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def get_elapsed_time_unix():
        return int(
            (datetime.fromtimestamp(start_time)
             + timedelta(
                 seconds=time.time() - start_time)
             ).timestamp())

    #----------------------------------------------------------------------------
    def getRPCParty(party):
        rpc_party = {}
        if party:
            if party == [None, None]:  # const-recovered (unset-party default per profile template)
                rpc_party = {}
            elif party:
                rpc_party = {'id': bot.user.id, 'size': [party[1], party[2]]}  # const-recovered
            else:
                rpc_party = party
        return rpc_party

    ############################################################################

    def getRPCParty(party):
        rpc_party = {}
        if party:
            if party == [0, 0]:  # const-recovered
                rpc_party = {}
            elif party:
                rpc_party = {'id': bot.user.id, 'size': [party[1], party[2]]}  # const-recovered
            else:
                rpc_party = party
        return rpc_party
    #----------------------------------------------------------------------------

    async def getAsset(app_id, key):
        async with ClientSession() as session:
            async with session.get(f'https://discord.com/api/v10/oauth2/applications/{app_id}/assets') as req:
                app_assets = await req.json()
        for t_list in app_assets:
            try:
                if str(key) == t_list['name']:
                    return t_list['id']
            except:
                pass

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getAppAssets():
        return app_manager().get_assets(getCurrentAppId())

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def uploadAsset(name, base64_str):
        r = app_manager().upload_asset(getCurrentAppId(), name, base64_str)
        return r
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def deleteAsset(name):
        app_id = getCurrentAppId()
        asset = await getAsset(app_id, name)
        if asset:
            r = app_manager().delete_asset(app_id, asset["id"])
            if r:
                return "Deleted"

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def loadScripts(first=False):
        for command in bot.commands:
            if not command.extras.get('built-in'):
                bot.remove_command(command.name)
                sys.stdout.write(
                    f'\nCommand unloaded: {command.name}\n')
        for event_name, listeners \
                in bot.extra_events.items():
            for listener in listeners:
                if (listener.__name__
                        in bot.config['built_in_events']
                        and listener.__name__
                        in __custom_feature_listeners__):
                    bot.remove_listener(listener, event_name)
                    sys.stdout.write(
                        f'\nUnloaded event: {event_name}: '
                        f'{listener.__name__}\n')
        try:
            ScriptEngine().deject_all()
        except Exception:
            pass
        count = 0
        loaded = []
        enabled = getScriptsConfig()['enabled']
        for filename in os.listdir(
                f'{getDataPath()}/scripts'):
            if os.path.isdir(os.path.join(
                    f'{getDataPath()}/scripts', filename)):
                for subfile in os.listdir(
                        f'{getDataPath()}'
                        f'/scripts/{filename}'):
                    if subfile.endswith('.py'):
                        if (os.path.splitext(subfile)[0]
                                in enabled):
                            with Lock():
                                try:
                                    source = open(
                                        f'{getDataPath()}'
                                        f'/scripts'
                                        f'/{filename}'
                                        f'/{subfile}',
                                        encoding='utf-8',
                                        errors='ignore'
                                    ).read()
                                    ScriptEngine().inject(
                                        os.path.splitext(
                                            subfile)[0],
                                        f'# -*- coding: '
                                        f'utf-8 -*-\n{source}')
                                    count += 1
                                    loaded.append(
                                        os.path.splitext(
                                            subfile)[0])
                                except Exception as e:
                                    logging.error(
                                        f'Script error: '
                                        f'{filename} | {e}')
                                    print(f'{filename} '
                                          f'script: {e}')
                                    showToast(
                                        text=(
                                            f'Error loading '
                                            f'script: '
                                            f'{filename}'),
                                        type_='ERROR',
                                        title='Script error',
                                        details=(
                                            f'Error loading '
                                            f'script: '
                                            f'{filename}'
                                            f'\nTraceback: '
                                            f'{e}'))
                                    removeEnabledScript(
                                        os.path.splitext(
                                            subfile)[0])
            elif filename.endswith('.py'):
                if (os.path.splitext(filename)[0]
                        in enabled):
                    with Lock():
                        try:
                            source = open(
                                f'{getDataPath()}/scripts'
                                f'/{filename}',
                                encoding='utf-8',
                                errors='ignore'
                            ).read()
                            ScriptEngine().inject(
                                os.path.splitext(filename)[0],
                                f'# -*- coding: utf-8 -*-'
                                f'\n{source}')
                            count += 1
                            loaded.append(
                                os.path.splitext(filename)[0])
                        except Exception as e:
                            logging.error(
                                f'Script error: '
                                f'{filename} | {e}')
                            print(f'Error in script: '
                                  f'{filename} | {e}')
                            showToast(
                                text=(
                                    f'Error loading script: '
                                    f'{filename}'),
                                type_='ERROR',
                                title='Script error',
                                details=(
                                    f'Error loading script: '
                                    f'{filename}'
                                    f'\nTraceback: {e}'))
                            removeEnabledScript(
                                os.path.splitext(filename)[0])
        print(f'{count} script(s) loaded!')
        showToast(text=f'{count} script(s) loaded!',
                 type_='SUCCESS',
                 title='Scripts loaded',
                 details=(f'{count} script(s) loaded!\n'
                          + ', '.join(loaded)))


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def unloadScripts():
        for command in bot.commands:
            if not command.extras.get('built-in'):
                bot.remove_command(command.name)
                logging.debug(f'Unloaded command: {command.name}')
        for event_name, listeners \
                in bot.extra_events.items():
            for listener in listeners:
                if (listener.__name__
                        in bot.config['built_in_events']
                        and listener.__name__
                        in __custom_feature_listeners__):
                    bot.remove_listener(listener, event_name)
                    logging.debug(
                        f'Unloaded event: {event_name}: '
                        f'{listener.__name__}')
        ScriptEngine().deject_all()


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def reloadAllScripts():
        evaluate_js('clearCustomUITabs();')
        global __custom_ui_tabs__
        __custom_ui_tabs__ = []
        unloadScripts()
        loadScripts()


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def toggleScriptState(toggle, script):
        if toggle:
            addEnabledScript(script)
        else:
            removeEnabledScript(script)
        reloadAllScripts()


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getRPCPreset(preset_name):
        data = getRPCPresets()
        for preset in data['rpc']:
            if preset_name in preset:
                return preset[preset_name]
        return None


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def renameRPCPreset(name, new_name):
        data = getRPCPresets()
        user_data = getUserProfileData()
        renamed = False
        for preset in data['rpc']:
            if name in preset:
                preset[new_name] = preset.pop(name)
                renamed = True
        for profile in user_data['profiles']:
            for value in profile.values():
                for entry in value:
                    if entry.get('rpc') == name:
                        entry['rpc'] = new_name
                        renamed = True
        if not renamed:
            return False
        with open(f'{getDataPath()}/presets.json', 'w',
                  encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        with open(f'{getDataPath()}/profile.json', 'w',
                  encoding='utf-8') as f:
            json.dump(user_data, f, ensure_ascii=False, indent=4)
        return True

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def deleteRPCPreset(name):
        data = getRPCPresets()
        for preset in data['rpc']:
            if name in preset:
                data['rpc'].remove(preset)
                with open(f'{getDataPath()}/presets.json', 'w',
                          encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False,
                              indent=4)
                return True
        return False


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getAllRPCPresetNames():
        data = getRPCPresets()
        names = []
        for preset in data['rpc']:
            names.extend(preset.keys())
        return names


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def setRPCPreset(preset_name, new_data):
        data = getRPCPresets()
        for preset in data['rpc']:
            if preset_name in preset:
                preset[preset_name].update(new_data)
                with open(f'{getDataPath()}/presets.json', 'w',
                          encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False,
                              indent=4)
                return True
        data['rpc'].append({preset_name: new_data})
        with open(f'{getDataPath()}/presets.json', 'w',
                  encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        return True


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class WebWindow:

        def __init__(self):
            self._window = None

        def set_window(self, window):
            self._window = window

        def hide(self):
            self._window.hide()

        def close(self):
            self._window.destroy()

        def connect(self):
            token = getCurrentToken()
            self._window.evaluate_js(
                f'\n    if (window.location.href !== '
                f'"https://discord.com/channels/@me") {{\n'
                f'        document.body.appendChild('
                f'document.createElement `iframe`).contentWindow'
                f'.localStorage.token = `"{token}"`\n'
                f'        window.location.href = '
                f'"https://discord.com/channels/@me";\n'
                f'    }}')

        def disconnect(self):
            self._window.evaluate_js(
                '\n            function login(token) {\n'
                '                setInterval(() => {\n'
                '                    document.body.appendChild'
                '(document.createElement `iframe`).contentWindow'
                '.localStorage.token = `"${token}"`\n'
                '                }, 50);\n'
                '                setTimeout(() => {\n'
                '                    location.reload();\n'
                '                }, 2500);\n'
                '            }\n\n'
                "            login('PASTE TOKEN HERE')\n"
                '            setTimeout(function() {\n'
                '                pywebview.api.hide();\n'
                '            }, 2000);\n'
                '            ')


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def commandSort(command):
        return command.name


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class NightyCommand:

        def __init__(self, name, description):
            self.name = name
            self.description = description

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def helpCmd(interaction, category):
        category = category.lower()
        commands = [
         CommandLogic("admin", "Administration commands"),
         CommandLogic("animated", "Animated messages"),
         CommandLogic("fun", "Funny commands"),
         CommandLogic("image", "Image commands"),
         CommandLogic("misc", "Miscellaneous"),
         CommandLogic("recovery", "Backup & restores"),
         CommandLogic("settings", "Settings"),
         CommandLogic("spotify", "Spotify"),
         CommandLogic("text", "Text based commands"),
         CommandLogic("tools", "General tools"),
         CommandLogic("troll", "Trolling commands"),
         CommandLogic("utils", "Utility")]
        if getConfigData()["riskmode"]:
            commands.append(CommandLogic("abuse", "Abusive commands"))
        commands = sorted(commands, key=commandSort)
        desc = ""
        for cmd in commands:
            desc += f"**/{cmd.name}** \xbb {cmd.description}\n"

        if getConfigData()["private"] or f"/{interaction.command.name}" in getForcePrivateCommands():
            theme_data = getThemeData()
            if theme_data.get("v2"):
                if theme_data["v2"]["enabled"]:
                    layout_view = discord_bot.ui.LayoutView()
                    container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                    for component in buildThemeV2(theme_data["v2"]["layout"], desc, "Help"):
                        container_view.add_item(component)

                    layout_view.add_item(container_view)
                    return await interaction.response.send_message(view=layout_view, ephemeral=True)
            await interaction.response.send_message(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=desc,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name="Help", icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])),
              ephemeral=True,
              delete_after=(getConfigData()["deletetimer"]))
        elif getConfigData()["forward"]:
            full_command_name = None
            if interaction.command:
                command = interaction.command
                if command.parent:
                    group_name = command.parent.name
                    full_command_name = f"{group_name} {command.name}"
                else:
                    full_command_name = f"{command.name}"
            await interaction.response.send_message(f"Command used: **/{full_command_name if full_command_name else interaction.command.name}**", ephemeral=True, delete_after=5)
            await forwardEmbedMethod(interaction.channel_id, desc, "Help")
        else:
            theme_data = getThemeData()
            if theme_data.get("v2"):
                if theme_data["v2"]["enabled"]:
                    layout_view = discord_bot.ui.LayoutView()
                    container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                    for component in buildThemeV2(theme_data["v2"]["layout"], desc, "Help"):
                        container_view.add_item(component)

                    layout_view.add_item(container_view)
                    return await interaction.response.send_message(view=layout_view, ephemeral=(getConfigData()["private"]))
            await interaction.response.send_message(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=desc,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name="Help", icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])),
              ephemeral=(getConfigData()["private"]),
              delete_after=(getConfigData()["deletetimer"]))
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def showCmds(interaction, group):
        commands = sorted((group.commands), key=commandSort)
        desc = ""
        for cmd in commands:
            desc += f"**/{cmd.name}** \xbb {cmd.description}\n"

        cmd = interaction.command
        if cmd.parent:
            full_cmd = f"/{cmd.parent.name} {cmd.name}"
        else:
            full_cmd = f"/{cmd.name}"
        if getConfigData()["private"] or full_cmd in getForcePrivateCommands():
            theme_data = getThemeData()
            if theme_data.get("v2"):
                if theme_data["v2"]["enabled"]:
                    layout_view = discord_bot.ui.LayoutView()
                    container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                    for component in buildThemeV2(theme_data["v2"]["layout"], desc, f"/{group.name} \xbb {group.description}"):
                        container_view.add_item(component)

                    layout_view.add_item(container_view)
                    return await interaction.response.send_message(view=layout_view, ephemeral=True)
            await interaction.response.send_message(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=desc,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=f"/{group.name} \xbb {group.description}", icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])),
              ephemeral=True,
              delete_after=(getConfigData()["deletetimer"]))
        elif getConfigData()["forward"]:
            full_command_name = None
            if interaction.command:
                command = interaction.command
                if command.parent:
                    group_name = command.parent.name
                    full_command_name = f"{group_name} {command.name}"
                else:
                    full_command_name = f"{command.name}"
            await interaction.response.send_message(f"Command used: **/{full_command_name if full_command_name else interaction.command.name}**", ephemeral=True, delete_after=5)
            await forwardEmbedMethod(interaction.channel_id, desc, f"/{group.name} \xbb {group.description}")
        else:
            theme_data = getThemeData()
            if theme_data.get("v2"):
                if theme_data["v2"]["enabled"]:
                    layout_view = discord_bot.ui.LayoutView()
                    container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                    for component in buildThemeV2(theme_data["v2"]["layout"], desc, f"/{group.name} \xbb {group.description}"):
                        container_view.add_item(component)

                    layout_view.add_item(container_view)
                    return await interaction.response.send_message(view=layout_view, ephemeral=(getConfigData()["private"]))
            await interaction.response.send_message(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=desc,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=f"/{group.name} \xbb {group.description}", icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])),
              ephemeral=(getConfigData()["private"]),
              delete_after=(getConfigData()["deletetimer"]))

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def _nightySlashCommandName(interaction):
        try:
            data = interaction.data or {}
            names = [data.get('name')]
            options = data.get('options')
            while options and isinstance(options, list) \
                    and options[0].get('type') in (1, 2):
                names.append(options[0].get('name'))
                options = options[0].get('options') or []
            names = [name for name in names if name]
            return '/' + ' '.join(names[-2:])
        except Exception:
            return ''

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def _autoDeferSlowCommand(interaction):
        try:
            await asyncio.sleep(AUTO_DEFER_AFTER)
            if interaction.response.is_done():
                return
            full_cmd = _nightySlashCommandName(interaction)
            ephemeral = True
            try:
                ephemeral = bool(getConfigData()['private']) or full_cmd in getForcePrivateCommands()
            except Exception:
                pass
            await interaction.response.defer(ephemeral=ephemeral)
            try:
                interaction.extras['nighty_auto_deferred'] = True
            except Exception:
                pass
            logging.warning(f'auto-deferred slow command {full_cmd} (no reply within {AUTO_DEFER_AFTER}s)')
        except Exception as e:
            logging.debug(f'auto-defer for {_nightySlashCommandName(interaction)} failed: {e}')
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _nightyInteractionCheck(interaction):
        try:
            if interaction.type is discord_bot.InteractionType.application_command:
                if (interaction.data or {}).get("type", 1) == 1:
                    bot_app.loop.create_task(_autoDeferSlowCommand(interaction))
        except Exception as e:
            logging.debug(f"interaction check: {e}")
        return True
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def splitEmbedText(text, limit, max_parts):
        if not text or len(text) <= limit:
            return [text]
        parts = []
        remaining = text
        while remaining and len(parts) < max_parts:
            if len(remaining) <= limit:
                parts.append(remaining)
                remaining = ''
                break
            chunk = remaining[:limit]
            cut = chunk.rfind('\n\n')
            if cut < limit // 2:
                cut = chunk.rfind('\n')
            if cut < limit // 2:
                cut = chunk.rfind(' ')
            if cut < limit // 2:
                cut = limit
            parts.append(remaining[:cut].rstrip())
            remaining = remaining[cut:].lstrip()
        if remaining:
            suffix = ' ...'
            parts[-1] = parts[-1][:limit - len(suffix)] + suffix
        return parts

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def botCmd(interaction, author, text, thumb, followup, image_url, show_thumb):
        parts = splitEmbedText(text)
        result = await _botCmdSend(interaction, author, parts[0], thumb, followup, image_url, show_thumb)
        for part in parts[1:]:
            await _botCmdSend(interaction, author, part, thumb, True, image_url, show_thumb, first=False)

        return result
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _botCmdSend(interaction, author, text, thumb, followup, image_url, show_thumb, first):
        cmd = interaction.command
        if interaction.response.is_done():
            followup = True

        async def _deliverFollowup(**kwargs):
            """The FIRST reply after an auto-defer edits the deferred placeholder.

                    Commands normally do botCmd() and then editBotCmd(), and editBotCmd
                    edits the ORIGINAL response. If the first reply were posted as a plain
                    followup, the "thinking" placeholder would be left behind and
                    editBotCmd would update the wrong message. Turning the placeholder into
                    the reply keeps the deferred path byte-for-byte equivalent to the normal
                    one; every later reply is a genuine extra message.
                    """
            try:
                if interaction.extras.pop("nighty_auto_deferred", False):
                    kwargs.pop("ephemeral", None)
                    return await interaction.edit_original_response(**kwargs)
            except Exception as e:
                logging.debug(f"botCmd: placeholder edit failed, falling back to followup: {e}")

            return await interaction.followup.send(**kwargs)


        full_cmd = f"/{cmd.name}"
        if isinstance(cmd, app_commands.Command):
            if cmd.parent:
                full_cmd = f"/{cmd.parent.name} {cmd.name}"
        if getConfigData()["private"] or full_cmd in getForcePrivateCommands():
            if followup:
                return await _deliverFollowup(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
                  description=text,
                  color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url),
                  ephemeral=True)
            theme_data = getThemeData()
            if theme_data.get("v2"):
                if theme_data["v2"]["enabled"]:
                    layout_view = discord_bot.ui.LayoutView()
                    container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                    for component in buildThemeV2(theme_data["v2"]["layout"], text, author):
                        container_view.add_item(component)

                    layout_view.add_item(container_view)
                    if followup:
                        return await _deliverFollowup(view=layout_view, ephemeral=True)
                    return await interaction.response.send_message(view=layout_view, ephemeral=True)
            _embed = discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=text,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url)
            if followup:
                return await _deliverFollowup(embed=_embed, ephemeral=True)
            return await interaction.response.send_message(embed=_embed, ephemeral=True, delete_after=(getConfigData()["deletetimer"]))
        if getConfigData()["forward"]:
            full_command_name = None
            if interaction.command:
                command = interaction.command
                if command.parent:
                    group_name = command.parent.name
                    full_command_name = f"{group_name} {command.name}"
                else:
                    full_command_name = f"{command.name}"
            _used_text = f"Command used: **/{full_command_name if full_command_name else interaction.command.name}**"
            if first:
                if followup:
                    await _deliverFollowup(content=_used_text, ephemeral=True)
                else:
                    await interaction.response.send_message(_used_text, ephemeral=True, delete_after=5)
            await forwardEmbedMethod(interaction.channel_id, text, author, image_url, show_thumb)
        else:
            if followup:
                return await _deliverFollowup(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
                  description=text,
                  color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url),
                  ephemeral=(getConfigData()["private"]))
            theme_data = getThemeData()
            if theme_data.get("v2"):
                if theme_data["v2"]["enabled"]:
                    layout_view = discord_bot.ui.LayoutView()
                    container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                    for component in buildThemeV2(theme_data["v2"]["layout"], text, author):
                        container_view.add_item(component)

                    layout_view.add_item(container_view)
                    if followup:
                        return await _deliverFollowup(view=layout_view, ephemeral=(getConfigData()["private"]))
                    return await interaction.response.send_message(view=layout_view, ephemeral=(getConfigData()["private"]))
            _embed = discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=text,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url)
            if followup:
                return await _deliverFollowup(embed=_embed, ephemeral=(getConfigData()["private"]))
            return await interaction.response.send_message(embed=_embed, ephemeral=(getConfigData()["private"]), delete_after=(getConfigData()["deletetimer"]))
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def editBotCmd(interaction, author, text, thumb):
        cmd = interaction.command
        full_cmd = f"/{cmd.name}"
        if isinstance(cmd, app_commands.Command):
            if cmd.parent:
                full_cmd = f"/{cmd.parent.name} {cmd.name}"
        if getConfigData()["private"] or full_cmd in getForcePrivateCommands():
            return await interaction.edit_original_response(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=text,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=author, icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])))
        if getConfigData()["forward"]:
            full_command_name = None
            if interaction.command:
                command = interaction.command
                if command.parent:
                    group_name = command.parent.name
                    full_command_name = f"/{group_name} {command.name}"
                else:
                    full_command_name = f"/{command.name}"
            await interaction.response.send_message(f"Command response update: **/{full_command_name if full_command_name else interaction.command.name}**", ephemeral=True, delete_after=5)
            await forwardEmbedMethod(interaction.channel_id, text, author)
        else:
            return await interaction.edit_original_response(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=text,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=author, icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])))
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def embedImage(interaction, content, title, image_url, thumb, private):
        try:
            image_url = image_url if image_url else getThemeData()["large_image"]
            cmd = interaction.command
            full_cmd = f"/{cmd.parent.name} {cmd.name}" if cmd.parent else f"/{cmd.name}"
            embed = discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=content,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_footer(text=(bot.config["theme"]["footer"]),
              icon_url=(bot.config["theme"]["footer_icon"])).set_image(url=image_url)
            if thumb:
                embed.set_thumbnail(url=(bot.config["theme"]["image"]))
            if title:
                embed.set_author(name=title, icon_url=(bot.config["theme"]["author_icon"]))
            ephemeral = True if (getConfigData()["private"]) or (full_cmd in getForcePrivateCommands()) else private
            await interaction.response.send_message(embed=embed, ephemeral=ephemeral, delete_after=(getConfigData()["deletetimer"]))
        except Exception as e:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
            logging.error(e)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def escape_markdown(text):
        return text.replace('_', '\\_').replace('*', '\\*')


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def maskString(s):
        return s[:5] + '\\*' * (len(s) - 5)

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def getGlobalBadges(user_id):
        async with ClientSession() as session:
            async with session.get(f'https://api.domi-btnr.dev/clientmodbadges/users/{user_id}', timeout=15) as r:
                badges = await r.json()
                global_badges = []
                if not isinstance(badges, dict):
                    return global_badges
                for source, badges_list in badges.items():
                    if not isinstance(badges_list, list):
                        continue
                    for badge in badges_list:
                        if not isinstance(badge, dict) or not badge.get('name') or not badge.get('badge'):
                            continue
                        badge_info = {
                            'name': f"{badge['name']} ({source})",
                            'description': f"{badge['name']} ({source})",
                            'icon': badge['badge'],
                        }
                        global_badges.append(badge_info)
                return global_badges

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def morseTranslate(sentence):
        result = ''
        for char in sentence.upper():
            result += {'A': '\u2022- ', 'B': '-\u2022\u2022\u2022 ', 'C': '-\u2022-\u2022 ',
                       'D': '-\u2022\u2022 ', 'E': '\u2022 ', 'F': '\u2022\u2022-\u2022 ',
                       'G': '--\u2022 ', 'H': '\u2022\u2022\u2022\u2022 ', 'I': '\u2022\u2022 ',
                       'J': '\u2022--- ', 'K': '-\u2022- ', 'L': '\u2022-\u2022\u2022 ',
                       'M': '-- ', 'N': '-\u2022 ', 'O': '--- ',
                       'P': '\u2022--\u2022 ', 'Q': '--\u2022- ', 'R': '\u2022-\u2022 ',
                       'S': '\u2022\u2022\u2022 ', 'T': '- ', 'U': '\u2022\u2022- ',
                       'V': '\u2022\u2022\u2022- ', 'W': '\u2022-- ', 'X': '-\u2022\u2022- ',
                       'Y': '-\u2022-- ', 'Z': '--\u2022\u2022 ', ' ': ' | ',
                       '1': '\u2022---- ', '2': '\u2022\u2022--- ', '3': '\u2022\u2022\u2022-- ',
                       '4': '\u2022\u2022\u2022\u2022- ', '5': '\u2022\u2022\u2022\u2022\u2022 ', '6': '-\u2022\u2022\u2022\u2022 ',
                       '7': '--\u2022\u2022\u2022 ', '8': '---\u2022\u2022 ', '9': '----\u2022 ',
                       '0': '----- ', '.': ':', '+': '\u2022-\u2022-\u2022 ',
                       '=': '-\u2022\u2022\u2022- ', '/': '-\u2022\u2022-\u2022 '}[char]
        return result

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def execRemoteCommand(channel, cmd):
        message = [message async for message in channel.history(limit=1)][0]
        view = StringView(cmd)
        ctx = Context(prefix=None, view=view, bot=bot, message=message)
        invoker = view.get_word()
        ctx.command = bot.all_commands.get(invoker)
        await ctx.command.invoke(ctx)
        sendAppNotification(f"Remote command used: {ctx.command.name}", discord_url=(ctx.channel.jump_url), channel=(ctx.channel))
        return ctx

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def before(value, a):
        idx = value.find(a)
        if idx == -1:
            return ''
        return value[0:idx]

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def after(value, a):
        idx = value.rfind(a)
        if idx == -1:
            return ''
        pos = idx + len(a)
        if pos >= len(value):
            return ''
        return value[pos:]

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def get_app_id(token):
        client = discord_bot.Client(intents=discord_bot.Intents.none())
        try:
            try:
                await client.login(token)
                app_info = await client.application_info()
                return str(app_info.id)
            except discord_bot.LoginFailure:
                return None
            except discord_bot.HTTPException:
                return None
        finally:
            await client.close()
            return None

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getAppID(token):
        return asyncio.run(get_app_id(token))

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def is_account_valid(token):
        client = discord.Client(chunk_guilds_at_startup=False,
                                afk=True)
        try:
            try:
                await client.login(token)
                return True
            except discord.HTTPException:
                return False
        finally:
            await client.close()

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def isAccountValid(token):
        return asyncio.run(is_account_valid(token))


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def get_theme_path(theme_name):
        return os.path.join(
            f'{getDataPath()}/themes',
            f'{theme_name}.json')


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def rename_theme(old_name, new_name):
        try:
            old_path = get_theme_path(old_name)
            if not os.path.exists(old_path):
                return (None, None)
            new_path = get_theme_path(new_name)
            os.rename(old_path, new_path)
            return (old_name, new_name)
        except Exception:
            return (None, None)


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def get_script_path(filename):
        return os.path.join(getScriptsPath(), filename)


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def rename_script(old_name, new_name):
        try:
            old_path = get_script_path(old_name)
            if not os.path.exists(old_path):
                return (None, None)
            new_path = get_script_path(new_name)
            os.rename(old_path, new_path)
            return (old_name, new_name)
        except Exception:
            return (None, None)


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def createApp():
        js_source = (
            '\nconsole.log(`injected`)\n'
            'var previousUrl = window.location.href;\n'
            'function checkUrl() {\n'
            '    var currentUrl = window.location.href;\n'
            '    console.log(`current URL: ${currentUrl}`)\n'
            '    pywebview.api.url_callback_change(currentUrl);\n'
            '    setTimeout(checkUrl, 1000); '
            '// Check every second\n'
            '}\n\n'
            'checkUrl();\n'
            '                ')
        api = AppCreateApi()
        window = webview.create_window(
            'Create app',
            url='https://discord.com/login',
            width=1200,
            height=1000,
            resizable=True,
            frameless=False,
            js_api=api)

        def on_loaded():
            api.discordAppLogin()
            window.evaluate_js(js_source)

        api.set_window(window)
        window.events.loaded += on_loaded


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def autoApp():
        config = getConfigData()
        if not config['logins'][getActiveProfileName()].get('app') or \
                not config['logins'][getActiveProfileName()]['app'] \
                .get('id') or \
                not config['logins'][getActiveProfileName()]['app'] \
                .get('id'):
            createApp()
            return None
        if getConfigData()['logins'][getActiveProfileName()]['app'] \
                .get('id') and \
                getConfigData()['logins'][getActiveProfileName()]['app'] \
                .get('token'):
            if is_discord_bot_token_valid(getCurrentAppToken()):
                bot.run(token=getCurrentToken(), reconnect=True)
                return None
            if getConfigData()['logins'][getActiveProfileName()]['app'] \
                    .get('id'):
                if not check_app_id(getConfigData()['logins']
                                   [getActiveProfileName()]['app']
                                   .get('id')):
                    createApp()
                    return None
            logging.error('App token not valid')
            requestAppToken()
        else:
            if getConfigData()['logins'][getActiveProfileName()]['app'] \
                    .get('id'):
                if not check_app_id(getConfigData()['logins']
                                   [getActiveProfileName()]['app']
                                   .get('id')):
                    createApp()
                    return None
                logging.error('App token not valid')
                requestAppToken()

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class AppCreateApi:

        def __init__(self):
            self._window = None

        def set_window(self, window):
            self._window = window

        def hide(self):
            self._window.hide()
            bot.run(token=getCurrentToken(), reconnect=True)

        def close(self):
            self._window.destroy()

        def discordLogin(self):
            getConfigData()
            self._window.evaluate_js(
                f'\n    if (window.location.href !== '
                f'"https://discord.com/oauth2/authorize?client_id='
                f'{getCurrentAppId()}") {{\n'
                f'        document.body.appendChild('
                f'document.createElement `iframe`).contentWindow'
                f'.localStorage.token = `"{getCurrentToken()}"`\n'
                f'        window.location.href = '
                f'"https://discord.com/oauth2/authorize?client_id='
                f'{getCurrentAppId()}";\n    }}')

        def url_change_callback_app(self, url):
            if url == 'https://discord.com/oauth2/authorized':
                self._window.evaluate_js(
                    '\n                \n'
                    '                function login(token) {\n'
                    '                    setInterval(() => {\n'
                    '                        document.body.appendChild'
                    '(document.createElement `iframe`).contentWindow'
                    '.localStorage.token = `"${token}"`\n'
                    '                    }, 50);\n'
                    '                    setTimeout(() => {\n'
                    '                        location.reload();\n'
                    '                    }, 2500);\n'
                    '                }\n\n'
                    "                login('PASTE TOKEN HERE')\n"
                    '                setTimeout(function() {\n'
                    '                    pywebview.api.hide();\n'
                    '                }, 2000);\n'
                    '                ')

        def url_change_callback_app_connect(self, url):
            if url == 'https://discord.com/oauth2/authorized':
                self._window.evaluate_js(
                    '\n                \n'
                    '                function login(token) {\n'
                    '                    setInterval(() => {\n'
                    '                        document.body.appendChild'
                    '(document.createElement `iframe`).contentWindow'
                    '.localStorage.token = `"${token}"`\n'
                    '                    }, 50);\n'
                    '                    setTimeout(() => {\n'
                    '                        location.reload();\n'
                    '                    }, 2500);\n'
                    '                }\n\n'
                    "                login('PASTE TOKEN HERE')\n"
                    '                setTimeout(function() {\n'
                    '                    pywebview.api.close();\n'
                    '                }, 2000);\n'
                    '                ')

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class AppAddAccountApi:

        def __init__(self):
            self._window = None

        def set_window(self, window):
            self._window = window

        def hide(self):
            self._window.hide()

        def close(self):
            self._window.destroy()

        def saveTokenToConfig(self, token):
            r = requests.get(
                'https://discord.com/api/v10/users/@me',
                headers={
                    'Authorization': token,
                    'Content-Type': 'application/json',
                    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; '
                                   'WOW64) AppleWebKit/537.36 (KHTML, '
                                   'like Gecko) discord/1.0.9001 '
                                   'Chrome/83.0.4103.122 '
                                   'Electron/9.3.5 Safari/537.36')},
                verify=False,
                timeout=20)
            if r.status_code == 200:
                data = r.json()
                username = data.get('username')
                config = getConfigData()
                logins = config['logins']
                logins[username] = {
                    'token': str(token),
                    'date_added': datetime.now().strftime(
                        '%d %B %Y, at %H:%M:%S'),
                    'active': True}
                config = getConfigData()
                config['logins'] = logins
                saveConfigData(config)
                setActiveProfile(username)
                autoApp()
            else:
                evaluate_js('location.reload();')
                return {'status': 'error', 'text': 'Invalid token.'}

        def url_change_callback(self, url):
            if url == 'https://discord.com/channels/@me':
                logging.info('[WEB LOGIN] Logged in, retrieving token...')
                pattern = re.compile(
                    'https://discord\\.com/api/v\\d+/users/@me(?:[/?].*)?$')
                for key, value in (
                        self._window.get_request_headers().items()):
                    if pattern.fullmatch(key):
                        for k2, v2 in value.items():
                            if k2 == 'Authorization':
                                logging.info('[WEB LOGIN] Token found, '
                                             'saving to config...')
                                self._window.evaluate_js(
                                    f'\npywebview.api.saveTokenToConfig('
                                    f'"{v2}")\n\n'
                                    'function login(token) {\n'
                                    '    setInterval(() => {\n'
                                    '        document.body.appendChild('
                                    'document.createElement `iframe`)'
                                    '.contentWindow.localStorage.token = '
                                    '`"${token}"`\n'
                                    '    }, 50);\n'
                                    '    setTimeout(() => {\n'
                                    '        location.reload();\n'
                                    '    }, 2500);\n'
                                    '}\n\n'
                                    "login('PASTE TOKEN HERE')\n"
                                    'setTimeout(function() {\n'
                                    '    pywebview.api.hide();\n'
                                    '}, 2000);\n')

        def add_acc_url_change(self, url, profileName):
            if url == 'https://discord.com/channels/@me':
                logging.info('[WEB LOGIN] Logged in, retrieving token...')
                pattern = re.compile(
                    'https://discord\\.com/api/v\\d+/users/@me(?:[/?].*)?$')
                for key, value in (
                        self._window.get_request_headers().items()):
                    if pattern.fullmatch(key):
                        for k2, v2 in value.items():
                            if k2 == 'Authorization':
                                logging.info('[WEB LOGIN] Token found, '
                                             'saving to config...')
                                self._window.evaluate_js(
                                    f'\npywebview.api.saveTokenToConfig('
                                    f'"{v2}")\n\n'
                                    'function login(token) {\n'
                                    '    setInterval(() => {\n'
                                    '        document.body.appendChild('
                                    'document.createElement `iframe`)'
                                    '.contentWindow.localStorage.token = '
                                    '`"${token}"`\n'
                                    '    }, 50);\n'
                                    '    setTimeout(() => {\n'
                                    '        location.reload();\n'
                                    '    }, 2500);\n'
                                    '}\n\n'
                                    "login('PASTE TOKEN HERE')\n"
                                    'setTimeout(function() {\n'
                                    '    pywebview.api.hide();\n'
                                    '}, 2000);\n')

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------


class WebLoginApi:  # line 8285
    # [confidence=medium - see wave45 evidence]
    def addTokenToAccounts(self, token, profileName):
        logins = getConfigData()['logins']  # const-recovered
        found = {'name': False, 'token': {'exists': False, 'login': None}}  # const-recovered (exact keys decoyed)
        for lg in list(logins):
            if str(lg) == str(profileName):
                found['name'] = True  # const-recovered
            if logins[lg]['token'] == str(token):  # const-recovered
                found['token'] = {'exists': True, 'login': str(lg)}  # const-recovered
        if found['name']:
            if not bot.config.get('web_login_notify'):  # const-recovered
                evaluate_js(f'newToast("Account", "{profileName} already exists")')  # const-recovered
                bot.config['web_login_notify'] = True  # const-recovered
        elif found['token']['exists']:
            if not bot.config.get('web_login_notify'):  # const-recovered
                evaluate_js(f'newToast("Account", "{profileName} already added")')  # const-recovered
                bot.config['web_login_notify'] = True  # const-recovered
        else:
            logins[f'{profileName}'] = {'token': str(token), 'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'verified': False}  # const-recovered
            config = getConfigData()
            config['logins'] = logins
            saveConfigData(config)
            if not bot.config.get('web_login_notify'):  # const-recovered (decoy LOAD_DEREF/POP_JUMP_IF_TRUE pair in stream here)
                evaluate_js(f'newToast("Account", "{profileName} added")')  # const-recovered
                bot.config['web_login_notify'] = True  # const-recovered
            return 'success'  # const-recovered (literal unknown; fresh const slot #16)
        return None

    ############################################################################

    # [confidence=medium - see wave45 evidence]
    def addTokenToAccounts(self, token, profileName):
        logins = getConfigData()['logins']  # const-recovered
        found = {'exists': False, 'login': {'exists': False, 'name': None}}  # const-recovered (exact keys decoyed)
        for lg in list(logins):
            if str(lg) == str(profileName):
                found['exists'] = True  # const-recovered
            if logins[lg]['token'] == str(token):  # const-recovered
                found['login'] = {'exists': True, 'name': str(lg)}  # const-recovered
        if found['exists']:
            if not bot.config.get('web_login_notify'):  # const-recovered
                evaluate_js(f'newToast("Account", "{profileName} already exists")')  # const-recovered
                bot.config['web_login_notify'] = True  # const-recovered
            return None  # const-recovered
        if found['login']['exists']:
            if not bot.config.get('web_login_notify'):  # const-recovered
                evaluate_js(f'newToast("Account", "{profileName} already added")')  # const-recovered
                bot.config['web_login_notify'] = True  # const-recovered
            return None  # const-recovered
        logins[f'{profileName}'] = {'token': str(token), 'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'via': 'web'}  # const-recovered
        config = getConfigData()
        config['logins'] = logins
        saveConfigData(config)
        if not bot.config.get('web_login_notify'):  # const-recovered
            evaluate_js(f'newToast("Account", "{profileName} added")')  # const-recovered
            bot.config['web_login_notify'] = True  # const-recovered
        return True  # const-recovered (literal unknown; single-const return)
    #----------------------------------------------------------------------------

    async def updateApp(name, avatar):
        [None, None]
        if avatar:
            async with ClientSession() as session:
                async with session.get(avatar) as resp:
                    if resp.status != 200:
                        return {'status': 'error', 'text': 'Failed to fetch avatar image from the URL.'}
                    avatar_bytes = await resp.read()
            if name:
                await bot_app.user.edit(username=name, avatar=avatar_bytes)
                return {'status': 'success', 'text': 'Updated app name & avatar.'}
            else:
                await bot_app.user.edit(avatar=avatar_bytes)
                return {'status': 'success', 'text': 'Updated app avatar.'}
        else:
            if name:
                await bot_app.user.edit(username=name)
                return {'status': 'success', 'text': 'Updated app name.'}

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def open_file_in_explorer(file_path):
        os.system(f'explorer /select,"{os.path.abspath(file_path)}"')


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def showWelcome(show):
        with open(f'{getDataPath()}/misc/welcome.json', 'r+',
                  encoding='utf-8', errors='ignore') as f:
            data = json.load(f)
            if show is None:
                return data.get('welcome')
            data['welcome'] = show
            f.seek(0)
            json.dump(data, f, indent=2)
            f.truncate()


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getCreatedApp(url):
        match = re.match(
            '^https:\\/\\/discord\\.com\\/developers\\/'
            'applications\\/(\\d+)\\/information\\/?$', url)
        if match:
            return match.group(1)
        return None


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def check_app_id(app_id):
        try:
            logging.info('Making app id check...')
            r = requests.get(
                f'https://discord.com/api/v9/applications/{app_id}',
                headers=getBasicHeaders(),
                timeout=15)
            if r.status_code == 200:
                return True
            return False
        except Exception as e:
            logging.error(f'check_app_id: {e}')
            return False

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class AppsPortalApi:

        def __init__(self):
            self._window = None

        def set_window(self, window):
            self._window = window

        def close(self):
            self._window.destroy()

        def discordAppLogin(self):
            token = getCurrentToken()
            self._window.evaluate_js(
                f'\n            // Prevent multiple alerts or redirects\n'
                f'            if (!window.__nighty_login_injected) {{\n'
                f'                window.__nighty_login_injected = '
                f'true;\n'
                f'                if (window.location.href !== '
                f'"https://discord.com/developers/applications") {{\n'
                f'                    document.body.appendChild('
                f'document.createElement(\'iframe\')).contentWindow'
                f'.localStorage.token = `"{token}"`;\n'
                f'                    window.location.href = '
                f'"https://discord.com/developers/applications";\n'
                f"                    alert('Enter any name for your app "
                f'& click "Create".\');\n'
                f'                }}\n'
                f'            }}\n'
                f'            ')

        def url_callback_change(self, url):
            if url == 'https://discord.com/developers/applications':
                if getattr(self, '_app_clicked', False):
                    return None
                self._app_clicked = True
                self._window.evaluate_js('\n                (function() {\n                    // Don\u2019t click again if modal already open\n                    if (document.querySelector(\'input[name="name"], .modal, [data-testid="application-name-input"]\')) {\n                        return "already-open";\n                    }\n                    const btn = Array.from(document.querySelectorAll(\'button\')).find(b => b.innerText.trim() === \'New Application\');\n                    if (btn) {\n                        btn.click();\n                        return "clicked";\n                    }\n                    return "not-found";\n                })();\n                ')
            created = getCreatedApp(url)
            if created:
                self._window.close()
                config = getConfigData()
                config['logins'][getActiveProfileName()]['app'] = {}
                config['logins'][getActiveProfileName()]['app'][
                    'id'] = str(created)
                saveConfigData(config)
                app_manager().add_icon_to_app(
                    created, 'Nighty',
                    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAACCcAAAgmCAYAAADO0y'
                    '2yAAGt5UlEQVR4nOzd25JcV3of+C9BAGSRbFWRTTVDbnWgJM8oZmLsQDlCtiPmBv'
                    'UGxO1coebKl6x5AtY8QcNPQOgJRN/4wjGehsIR9hwUbihsy7LH7mar2XJTokiwQR'
                    'JAHbDmYmdW5WEfM3PVzsPvx6hgYa+11147AYJVtf/5fYOUUgAAAAAAAAAA5HKj7w'
                    '0AAAAAAAAAAJtNOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyOpm3xsAGPcP/sk/Lz5JoyPp6vM0NnHqWC'
                    'o5Vv55w3rTn0fE639v5/Lznb+zMzE2GAxm7mFGiynAhhlEDMr+46/7+2Aw/ctB9f'
                    'ymv1cGY2sssIfSKcv6e69hzsTeu/w9Os/fuRXnlL5+814jxxot1628j1yu73KHJc'
                    'f2hx9V9iLiYOk7WczTiHjSYf7jOcfyS81Trkuq20wf+1zmNWtvrWSw67Xbzk8LvM'
                    '4VYymt2O8bsBLSqw5/Acz8rKD45PzZ+dXXKIOxr2nHj42+/q45NnHe9Pj4nOnPS3'
                    '49fm6rr7GBzTOIRxHxKPr+Or6LFMXfXZ3+ak6X35em8Z/NNl2n7X6mrsWsf3H/D/'
                    'veAsAl4QQAAKAvh2OfH0QRHoiYDRHsR8Sd/NvpzQcd5n7Uce2vYzb88LTk2OOGXw'
                    'MAAMtzFCkexCAeRMSfRMRJ+BocgC0gnAAAACzTXlwFCw6H/96Pq4oGBxGxe33b2X'
                    'q7EXGv5Ph0IKIu9PCLiPh0+PnTmAw2PK74HAAAKLcXRRhh9M7/ezGIn4SQAgBbQD'
                    'gBAADo4iCuAgjj/96PiDuqaG6kOzFZuWI82FAWahiv1vBpXAUbHpccA4CtV9vWBt'
                    'hExzGIOxMt+Ip2CfcihBQA2GzCCQAAwLTDuAoe7A8/DkLFA9oZr9YwXrWhLMjwJ8'
                    'N/P4miKsOnw4+nMdt6AgAA1t1eRBxHikiDIph0GVIY5ZQmQwrH4etiADaIcAIAAG'
                    'ynvSgCBwdxFT7Yj8l3yENuZSGGcaMqDE8r/g0A603RBNgugziOUeh7+N9/GqSYqa'
                    'JQzL0XET+NiD+KopLCp9ezSQDIRzgBAAA2217MhhAOQhUE1sN4FYYPSsZ/EVfVFj'
                    '6Nq+DC48z7AgCArvYjDauJjWURIkWkSBGDqAopPIiIBxHxT6MIKTy9hr0CQBbCCQ'
                    'AAsDn24yp8cBgR+ymSSghssjvDj7LKC6OqC0/iKrDwNFRcAGBVqJoA22UQJ5efXw'
                    'UPYvxYZUih+OWHEXEUEQ8jxtYCgDUinAAAAOtpPyaDCAeRVEOAMaOqC6PgwkdjY3'
                    '8WV5UWnox9DgAAOexHigcTYYSI8eDBxLGaVg+7UXxdexRFQOFRhr0CQDbCCQAAsB'
                    '4OYxRCKP4tiADzuzv8mG4VIbQAwLVIyibAtnk0iEFlGCEiurZ6uBMRH8dVSOHx8r'
                    'cMAMsnnAAAAKtnPyaDCHf72wpslarQwi/iKqgw+veT0O8XAIBmhxFxL8WwGkJZGC'
                    'Fi3lYP9yLiJxHxRxFxHL4+BWDFCScAAED/9uOqMsJhRNzpbytAiTvDj3tTx7+Oq6'
                    'DC+AcAVFM0AbbNSUREkUtIw08bQgplrR6mQwqT5z+IiPsR8fDyegCwgoQTAADg+u'
                    '3HVRDhfmjRAOtqN4rAwnRo4U9CYAEAgOL7veJrxbEwQWNIoSa4kAapqtXDbkR8FE'
                    'Wrh6PQ6gGAFSScAAAA+e1F8UOpw4g4jKQyAmy4qsDC4yiCCo9DyV2A7aRqAmybhx'
                    'FRGTy4bPUwOr5oq4di7p0oWj38syhaPXy60B0AwBIJJwAAQB6HcRVIuNvnRoCVMB'
                    '1Y+LMoQgqjj6fXvSEAALI6ilHLvqrgQZdWD9PH60IKxS8/iOL70ZMYhSQAoGfCCQ'
                    'AAsBx7UYQR7kfxAyCtGoA6d4cfHw5/PR5W+KSXHQGQVUrKJsA2GQwGJxMHGto3tA'
                    '4pVLR6uDx3ct3diPhxXLV6eNLpJgBgyYQTAABgfgdRBBGOQnUEYDHTYYU/iSKk8D'
                    'j8EBkAYN2cpJTuDIqyBpMWDSnUHEuDNFtFoZh7NyJ+GhH/NIpKCk+73AwALItwAg'
                    'AAdHMYVxUS7vS5EWCjjbeB+EVcBRU+6Wc7AAC0tBcRxxHDoEEaBg3mCClMVEJYtN'
                    'VDMffDKL6XPYria0sAuFbCCQAA0Oz+5UfSrgG4dneiqKjwYUR8HVchhU/Cu94AVp'
                    '9uDrBtjoftFC6lSDFIw7BAy1YNnVo9TB+vCykM4k5E/CQi/lkUIYWn7W4LABZ3o+'
                    '8NAADAirofEY+i+EHNH0fEgwjBBKB3uxHxQUR8HBFfRRFQOIriHXoAAPRrPyKOI8'
                    'VMMCkN/ykNLJXMHz92eW7V3Kg+NnHu5PkfRMSnUXzvCwDXQuUEAAC4chjFQ777KZ'
                    'IgArAOPoirsMIfxVVFBQBWgaoJsF0GcRLjofaSqgaLtnooPh10avUQEZEGqazVw2'
                    '4M4o9DFQUAronKCQAAbLuDiHgYxTtGfhIqJADr60EUlV6eRvH32kGPewEA2Db7ke'
                    'JB28oIKVKkVFNJoWaNVlUUSioxpDRVReFqrioKAFwLlRMAANhG+1H80OUoUtztdy'
                    'sAS7cbER8OP/4sihY1j8I74QCuVUrKJsA2GQwGDy9/UVbBYHR8MH0oxSANZuc3rD'
                    'FTRaFqbsm6qSjdMF1JQRUFALJTOQEAgG1yFEW5859HxI8jBBOAjXc3ir/vvooioH'
                    'DQ52YAADbUYUrpg5mjXaooRE0VhZIqCONVFFpVUig5VlNF4UkUbQ8BYKmEEwAA2H'
                    'QHUZQ3fxpFT/bZHxgBbIcHEfHTKH7YfNTrTgAANstJxLBtwnTVlA6tFxpbPXQJKb'
                    'Q8v6LVw51I8ZMovpcGgKURTgAAYBPtRfHg7UkUD+I+jKLMOQBFNYWPowhtnUTxdy'
                    'YAAPM5jIh74wcqHvgvL6RQc6xVFYX2IYUPo/i++qBkJQDo7GbfGwAAgCU6iIjjiL'
                    'gfwggATXYj4qMo/t78JIqgwqe97QZgU5Q9DAQ22aOIiBhMHR21TRhEDMYHR39HlM'
                    'yfPpYixSANyudOrzF2bBQyGBS/aH290j2nuBsRP41B/G+hkgIACxJOAABgExxFxF'
                    'GkyXerANDKbhQtHx5ExB+FkAIAQFtHEXEnImpDAClSDAYzyYNWoYNULFCEBZYdUq'
                    'jb8yBNhyp+HEWViKMoKnABQGfCCQAArKv9GIUSRj8MAmBRQgoAC5jpNQ9srOGD+5'
                    'NWFQli+PdDlyoKU8cXDSmMVUJofX5J5YcPIsWnUVQrfDx9jwDQ5EbfGwAAgI4Ooi'
                    'ib+fMoypELJgAs34Mo/p59FEUYDACASScRcae0lUuK8hYvqQgppOnBmvmzh1IRdG'
                    'g5f3Qsxdh16643fXx2z7sR8ZMo7h8AOhFOAABgXdyP4p0ZP43ioRkA+Y1CCg8jYq'
                    '/XnQAArI69FOn48lddHvYPj5dWWqkIB1SFFLoEDDqHFMr2HBMhhY+i+B59r2Q2AJ'
                    'TS1gEAgFV3FKN3pADQlw+j+Pv44fDjaX9bAVhBujnAtjmOiN00KP7jn2iZUByYVN'
                    'fqISIGg0Hz/AytHi733qHVQ0REGly2ibgXoc0DAO0JJwAAsIr2ovhhz3Gk2O13Kw'
                    'AM7UbxDrmjKP6O/qTHvQAA9GUviq+FLh/qTzzoHx0vDlypCi7EMKQwGDu/bn6GkM'
                    'JlQKHl9UZVFIZ7HrV5+N9DqwcAGggnAACwSvYi4nhYHlMoAWA13YmIP46IP4niB/'
                    'NP+twMQO9UTYDtMoiHMf79atmD/vGxNg/7h8fHHvi3mj99LEWKQRq0nl8arpg/pP'
                    'BRRBxEEWR9GgBQ4kbfGwAAgIjYj6JM+KdRvCtXMAFg9d2LiJ9G8ff3Xq87AQC4Hv'
                    'uR4kFpKCnF5cP6ND5heLxqftnxUbuHmfkt1ri8fttrjh2b2Hvdvsv2XPzzQRTB1Y'
                    'OSWQCgcgIAAL3aj6Ls44N+twHAAj6Mos/wcWj1AGwbVRNguwzG2haUVSIYHY+ING'
                    'jR6qFmnVFAYTDop9XD5d7bVn+4uu87gxg8juJrw0fT9wXAdlM5AQCAPuxH8UOKn4'
                    'dgAsAmGLV6+CRUUQAANtNhTH//WlVdIKK8GsHY8bbrpDR1ft38qkoKqaaSQs0ara'
                    'oolFRiSCntpkgfR1FhCwAuqZwAAMB12ouI40jxUd8bASCLD6Jo0XMUqigAG27mYS'
                    'Gw6U4GaVgqoE0lganjKVK7KgoVx1NRBuFqjaZ1BtOHUpTuv2GNmSoKbfdd7PnDGM'
                    'RBFFW2ngYAW0/lBAAArsNeFO0bPo0QTADYcLuhigIAsFkOI+LeZRWEumoJNRUGSq'
                    'sodKmkkK7aPczMb7FG7f4rqiCUVoCo2/fssXsp0uOIOCgZBWDLqJwAAEBuJ1H0mt'
                    'ztdxsAXLNRFYX7EfG4z40ALJ2iCbBdBpPtCSqrEFxNqD0+UY1gdLxsrYp1UupYRW'
                    'Hq+CigMCgWaZw/XQHicu9l+ys//26K9DgGvi4E2HYqJwAAkMtRXFVKEEwA2E67Ef'
                    'GT0G8YAFhfR5Hibm0Vgo7VD8arEcyMdVgnpVS+RpdKCqmmkkLNsVZVFCaP70aKn0'
                    'TxswIAtpTKCQAALNthFA+h7va7DQBWyIdR/P/hfhTBNYD1pWoCbJdBnFx+XlWFIK'
                    'K6kkJDRYM06FBFoeJ4io6VFAbTh4aVIBatotDueh9H8XXhUQCwdYQTAABYlv2IeB'
                    'Qp7vW9EQBW0t2IeBLFD6I/6XMjAAAtHUfEnZmjFQ/4I6L8IX/FOZfHo2NIoWKdFC'
                    'kGg5mNXX+rh5q5Qw+i+BnC/Yh4WnI3AGwobR0AAFjUXhSVEn4eIZgAQK3diPjjiL'
                    'F3IAIArKa9iDjp2rZhrlYPcXX8sl1E3Tk162Rv9VCzl5l9159/LyIeR/E6A7AlVE'
                    '4AAGARx1E8YNrtdxsArJmPIuIgiioKT/vcCEBbKennANtkMBgcx/j3uh3aLSza6m'
                    'FUjWCmTcM1t3qoraRQcax1q4fi+N0oWn4dRlFhC4ANp3ICAADzOIziBwc/DsEEAO'
                    'bzQRTvljvodxsAADP2UkrHpSN1lQ/KqhCMKim0PGf8eKsqCg3HS4NVHaoxVO6/RR'
                    'WFdPWL6jWKnyk8juLnDABsOOEEAAC62IuiT/hPougdDgCLuBt+GA0ArJ6HEbFb2i'
                    'IholV7hslDNa0eKs4Zv06nkELZ4ZSqQwoV15w8tFirh4mQQvn5u1H8nOGo/A4A2B'
                    'TaOgAA0NZxSukkVEoAYLlGP4z+XyPiUb9bAQCI/Yh4cPmrqhYJw7GIyNvqYTQ23T'
                    'Kh6pyadVLq2Oqh7B66tnqImGxTUX+9j2MQe1GEQwDYQMIJAAA0OYjiYZFKCQDk9H'
                    'EUDwNO+t0GwJSqdzQDm+qkKiCQIsVgUPbUf/jvnCGFsgf942Md1ikNW9RddyaTkc'
                    'r337DGRLiieu6Po/g5xFEAsHG0dQAAoMpeFO9W+GkIJgBwPT4K1RMAgP4cRMSDuh'
                    'YMlS0SovqcylYJo3YPLc8ZP96p1UPF8YVbPVTtv2urh9k1HoSvCQE2ksoJAACUuR'
                    '9FMOFOv9sAYAuNyigf9bkJgIhQNQG2zWCqnUDXFgkN53SqQlBzzvh10qBFq4eadU'
                    'YBhYmKEMts9TC9zlQFiMu9z+7vQRRvmjiKiKezOwdgHamcAADAuL2I+CQi/jgEEw'
                    'Doz4OIeBzF/5cAAK7DYaS4VzpSU90gpakKBuPnzFOFoEv1g7G9zeyh4zql99H1Hl'
                    'JNJYWaYzVVFD4IXxMCbBSVEwAAGLkfRdnE3X63AQAREXEvih9GH4Z3ywE9KH3YCG'
                    'ysQQxOIqKxUkHVWIo0WX2g6byqKgQR1ZUUGtbqVEWh4niKkooQHaoxVFaC6FpF4W'
                    'ru3fA1IcDGEE4AAGAvIh5Fig/63ggATPHDaADgOhylSPcaH+o3jJW2SBg/r+V6Ey'
                    'GF3K0eKo6Xhi3Krtt1//OFFHxNCLAhhBMAALbb/VAtAYDV5ofRwPVTNAG2zcnMg/'
                    'GIxUIK09UH2qzXtgpBy7Va309F2KH0PrpWgkjD8xcNKQgoAGyEG31vAACAXuxFxC'
                    'cR8cchmADA6hv9MHqv320AABvoKCLuRIqrygPDfy7VBZaqxlLxcL+0RczYtZqOX+'
                    '6lwznTx2f20HGd0vuou+7MoVQEHVrOn3zp09WxdPk14X7JWQCsAZUTAAC2z2EU1R'
                    'Lu9LsNAOhk9MPog8ofWAMAdLMXEQ8njoxVEUiRFq6iUNkioe68eVs91Ky1rFYPrS'
                    'opVKxxWQlisSoKdyPiSQziMCKeBABrRTgBAGC7PIyID/veBADM6W4UAbujfrcBbC'
                    'xBJ9g2xzEoqSZY9WB8aqzuvJmhqlYPo/M6tHqobJXQtFZ0DCl0CVuUzc/X6mE30m'
                    'WLhycluwRgRQknAABsh4OIeDR8hwEArLMHw38f9bkJAGDt7UXEcduwQeeQQs2D/d'
                    'KQQsdKBpdVCDqcM763VvfTNWzRtRLEAiGFQQx2IwQUANaNcAIAwOY7joiTiJJ3gw'
                    'DAenoQEU+j+H8cwHKomgDbZTD1fXKHkMLMA/lVaPXQ8pzp463uZxmtHirWbgxZVB'
                    'wb3vvuIAaPQ0ABYG3c6HsDAABksxcRn0TEj0MwAYDN82GongAAzGc/qloepqgOK4'
                    '1aIwz/aX1OxVhKqahAUHOtNutd7qfrHobHW99PzfHS+yib33X/DWukSLsp0uMofg'
                    'YCwIpTOQEAYDMdpEifRMSdvjcCABl9HBGfRlHSF2BuqfKJHrChTirfrT/SoiJC51'
                    'YPFWOlLRLarNelCkHFOePXSYOW91OxziigMFMRomU1hgVaPYwCCodRVNcCYEWpnA'
                    'AAsHmOI+KnIZgAwHb4JCIOet4DALA+9iPiQbp66/1cVQ+m3r3frZJCxfGUptZpWq'
                    '+pCkGX6gdjeyu9nw7rlN5H13tINZUUyte4G0Vgda98VwCsApUTAAA2x15EPIoUH/'
                    'S9EQC4RrtxFVB42udGgDWlaAJsl0E8Gn06UfmgqqpAMXF0bu1YijRZ/aBF9YWysR'
                    'RptvpA3XlVVQgiqisptFhr4n46XHt0PEVJRYgO1RgqK0FUr3E3BvE4VFAAWFkqJw'
                    'AAbIaDKN4hIJgAwDa6E0VAAQCgzmGkuNe52sDVxPmqDsxRmSGldNkmoepabdabuL'
                    'cuexgeb30/NcdL72OeShBtrpnibiQVFABWlXACAMD6O4oimHC3320AQK/uRcTDvj'
                    'cBAKy0k8vP5mmJMH5u1fEcIYWywY6tIxrva1mhiy5hi2W2epg8XgQU0tjY6OPVFn'
                    '4ArBDhBACA9fYwIj6OoqQ1AGy7D6MI7QEATLsfRZhxUtWD/NHYHIGChUIKFcc7hx'
                    'TmCV+0OD6zhy7rRMV9LDOkcOVuxFULDwBWw82+NwAAwFz2oihfPfuDFQDYbg8j4s'
                    'nwA6Ba3buigU30MCIiBiUjo78PBuOH0vDQoBgvO6/i3ImxwdV6g8kLtN7L+FiKFI'
                    'NByWDVeXX3lgatzxk/ngZjr03Ha4+Op0gRg5h9TarWGUwfSsX+66/5YPirowBgJa'
                    'icAACwfg6ieOAimAAAs3ajeJfcXr/bAABWyFFE3ImI5nYN69LqYbpFQpt9zBwau7'
                    'eua6WOrR4qjpfex3JbPTwIrb8AVobKCQAA6+V+pHgU2jgAQJ27UfwQ+qjfbQAAK2'
                    'AvIk4mjtRVJ6gYb6w20LTu2NhEVYY251XsM6WS6gN161Ucv6xC0OGc8b21vp+Key'
                    'm9j66VINLw/PL5H8YgnoQ2DwC9E04AAFgfxxHx4743AQBr4kFEPA4/hAamVL7bGN'
                    'hUxzGIOzMP8CPahRTKHuSPWj1UnbtISGHOVg+LhhQWbfUwup/G1hWZWz3UhBQ+Hh'
                    '57FAD0RlsHAID18CgEEwCgq4cRsd/zHgCA/uxFxHFl+4CRju0VJtoZdGwTMTE2tt'
                    '68exkfm6vVQ10biy57uI5WD9OHK9ao3H+Kh1G0ygSgJyonAACstr0o3vV5t99tAM'
                    'Ba2o2ITyLioPbBAbA9/F0A22UQxzHWFrGyDcLlhFh+q4e6dRdp9VAx1rnVQ8X+aq'
                    'sQVJwzfp00WEKrh4gYDEruY/5WD7tR/IzlMCKelOwegMxUTgAAWF0HIZgAAIu6G9'
                    'N9pgGAbbAfER/NHB2+Mz9VpZXqqhNE+dhEtYE5qx5cFWJoWXmgYi+j45X32LGSQe'
                    '19tdhbq/upWaf0PjrsJ0Uqgg5Xx3ejqE65V7FzADJSOQEAYDUdRIrHMfYODwBgbh'
                    '9FUUHhSb/bAACu0UlTtYAUNZUU5qhckCIVa81Z9WC6ksJgshTAXOulSLPVB+rOm6'
                    'dCRIu1Wt1PzTqlv1cdqjGkSOP7vxvFm0EOxtepDKwAsDTCCQAAq+coRXoYggkAsE'
                    'yPQo9hANgW+xHx4PJXDe0aKh/gj86NivPrHuSPQgod2kRM73eprR6ipEXC2LXarD'
                    'cRUuiyh3laPVQcL/296tLq4Wr/d6P4+vCo5E4AyEQ4AQBgtRxFxMd9bwIANtCovc'
                    'NJv9sAeuHNsLBdBvFo5ljdg/0YPsCvqqIwOr9D0KCx2kDTulNVB4pPlxBSKLvHFk'
                    'GJyUOp/r4a7qlTSKFt2KJrJYgUMYjBgxjEp+HrQ4Brc6PvDQAAcOlhCCYAQE4fhe'
                    'oJALDpDiPFvcrRFNWBpVQ8+K4s7193bpSPXa7VcN02Yymm9tZ0XsXxynusWq/k+O'
                    'VeOpwzvbfS++mwTul9dL2HlD4K1RMAro3KCQAAq+FRjJecBAByeRgpDvveBHB99B'
                    'CH7TKIwUlENFZKaKoWsJKtHoZjKdJk9YMOrRnGxyrvsWsVgqipENFirYn7mbPVw0'
                    'xFiA7VGFKkh4MYPImIJwFAVsIJAAD9exRJMAEArsm9iDiOomIRALBZDiOmqibUhQ'
                    'EaxkvbB0yfGxXnL9rqoW7dZbd6iIp77BB6mLi3LnuYp9VDxfHSsEXZPcyusZsiPY'
                    '6I/Yh4WrJ7AJZEOAEAoD97EfFJTP/gBADI7SSKqkVPe90FcD0UToDtMYhHM1UFIh'
                    'arohDDB/jT78yfPr/D2p1CCi2qKBSfLiGkUHaPLYISk4dS/X3V3VOX+6lYpzRs0S'
                    '7osBsRj2O8BZj/fwAs3Y2+NwAAsKX2ovimVzABAK7fbhThBABgcxxFijsRxQPu0p'
                    'YuKeofONeNp+LBd2WrmDZrzxxKV2M1120zNnPPTedVHK+8x6r1So5f7qXDOdPHZ/'
                    'bQZZ2ouI/m694NXyMCZKVyAgDA9duLIphwt99tAMBW+yCK0s+P+90GkJ13vsLmK9'
                    '75fhIR9VUFRtpUUqgZK20f0GbtuioKxYYXavUwWm8Qg9KxLutV3mOHdguNFSKuqd'
                    'XDTEWI+moMD6L4+vBRALB0wgkAANdrLwQTAGBVPIyIAw8uAWDtnUQUVRMutQ0pLN'
                    'LqIaI+pLAJrR6i4h4b2jNMHhq7t66tHmJ5IYWZ+yi7brHGxzGIJxHxpGRXACxAWw'
                    'cAgOuzF4IJALBK7kbEcd+bAAAWshep5v/nda0Cpsabzi8dztDqobYlQtO6y271EM'
                    'tp9TDaT+dWD2N7a30/y2n18EkUP8cBYIlUTgAAuB57kQQTFnXx3cUvpo+9+vbixs'
                    'V3F6/arnHrt2/PHHvtzdfulEwFYDucRFG292mvuwAA5nUcEbu1lQoiLt8lv1Crh6'
                    'rxqvYBLc8tG7tszzBn1YPpSgrLavVQeo/X2Oqh9f0s3urhTkR8EkUbMACWRDgBAC'
                    'C/vVAxodyreH7x4uKvI8XNsy9OzyMiLp5d/ODVtxc7EREXz1/Fq+cX42csIUTwbe'
                    '3ojZ3X4rWdosDYrR/c/jxuxIubu7duDG4PXr32xms/iBuxs/geAFghu1EEFI773Q'
                    'YAMIf9GP9/eIeAwVytHprGq9oHtNlf3YP8UUhhzuDEMls91N5jh9BDq1YPZXu4jl'
                    'YPV/PvRfF14knJDgGYg3ACAEBee7HlwYSL7y5+kU7TjfOvz15dfHPx9qtvLr4/Fj'
                    'rYiaUEDpbn1fOLy0DE2Zdn75fNee23bsZrOzfi5vdv/eLm7q0bN3Zu3L7x+o3SuQ'
                    'CshQ8j4mFEfNrvNoAs6kqqA+ttECdRBA0nLRpSWKSKQhTtAyqrKIzO77B2Y7WBpn'
                    'Xr7nfOkELlPbYISkweSvX31XBPnUIKVfcRUR5SKA59FMXPdR6X7AKAjoQTAADy2Y'
                    'ttCSYMKyCcf3V+8+Kb8zcvnp6/c/7sPNJZilix8MEyXPzmPC5+E3H6+enEvb32Wz'
                    'fj5u7N5zffufXlrfdu3RRYAFgrJxFx1PMeAID29iPFg8YqBxGtHubPtApoe37V+C'
                    'KtHqb2dnVoua0eik9bhhRWsdXD2N5a3U/XsMXV/E+iqNLxtGQHAHQgnAAAkMdebG'
                    'gwIZ2nry6+ufjm/Kuz22d/ffr+sArCylVA6EMRWjjfefnLFz8cHbv17q249YPbn9'
                    '/6we3z19567Yd15wPQqwcR8Si8Kw42Trp8ugRsmIeND+pHWlYqqG31UHeNedsgtD'
                    'h3emxprR6GYzOhjA6tGcbHals9lJ23zJBC1/tpaPVQElLYjYhPIuIwAFiIcAIAwP'
                    'LtpUiPYwOCCVdBhPMiiFBUQ3gnIt7pe2/r4uzLs6I9xF98GxERN4dhhdu/c/u1G2'
                    '/ceK/n7QEw6SSSHzoDwBo4jIgPZh7UF78ot2irh9GcOUMQle0D2uxv0VYPdesuu9'
                    'VDVNxjh9DDxL112cM8rR4qjpeELe5FUWnrpGRHALQknAAAsFx7kda3YsKr7y5+cf'
                    'Y3Z3H25dmd8y/PBBEyOP/yLM6/PHv/+V98G4Nbg7j9/u3nt3/3jS9u7t78fgzizb'
                    '73B7Dl7kXxsONxv9sAlkrhBNg8g8kHxK2rCRSTR2s0jpeGFBYMQZS2D5g+v8PanU'
                    'IKy271UDFWeY8dW0ekSPX31XBPnUIK7cIWH0XxdeLjkqsC0IJwAkBufggCm2/yG9'
                    'jHsS7BhFfx/OLZ+X87++r8rbO/Pn3//MuzCK0ZrlU6S/Hys5c7Lz97+aOIiFvv34'
                    '7Xf/f1X976/u334kbs9L0/gC11Ekr2AsAqO4wU9yKi/GF2l1YPdXPGHljPtApoe3'
                    '7VeFX7gDn2dnWoxb13aPVQfNoypND1Hq+j1cPY3krvp8M6U2GLRxFxEBFPS64IQA'
                    'PhBACA5XkUKx5MuPj6/Genn5++c/bF2TsXvznfiYjf73tPXDn7/DTOPj/90URFhb'
                    '2bP+p7XwBbRvUEAFhtDy8/q3hIH9Gy1UPFGhNjw/NrWz3UXaNFSGHprR6aKkh0CC'
                    'nMVI2YI/RQeY/XEVKoup85Wz3EIO4MYvAoIu6ny8kAtCWcAACwHI8i4kHfm5j26s'
                    'WrL05/fXoxVhlBGGENjFdUuLFzI27/zutfvfF7OzcGtwa7fe8NYEuchOoJALCKjm'
                    'L6TQEVD5M7hRQWbfUwmjNnCKKkfUD7tXO0ehgbW2qrh6i4xw6hh4l767KHeVo9VB'
                    'xPkT4YDAZHUfwsCIAOhBMAABb3MFYkmJDO01fnX5198/Kzlz86//Is0ll6r+89sZ'
                    'hXz1/Fi589f+fFz57HzXdvxc4fvPlL1RQAslM9ATaJN7bC5hjESeVYTUihtpx/iz'
                    'XKxpfe6iFm2gcsvHarkEKuVg8VY5X32LF1RIrUfF9dWz2UrVWxTkrpYQzicUR8Wn'
                    'IVACoIJwAALOYoUnzY5wYuvr341emvXr559sXZOxfPzt+JiHf63A/5nH95Fs/+r6'
                    '9/dGPnRrzx+29+8frfef2tuBE7fe8LYEOdhOoJALBKjiPFnYjoHDBYaquHsfGcrR'
                    '4WCilUBTTmDBQ0hhS6Vmaou8c+Wz1U7bl8nd1I8Sh8vQjQiXACAMD8jiLi42u/6q'
                    't4fvbV2V+d/frl3zn99elOOk8/vPY90KtXz1/Fd//hm/ee/6dv443f3/n6jTs7t4'
                    'UUAJZO9QQAWB17EWNVE5rCAxVzemn10LRGzViKVN/qoWrtNgGNOYMTV5mEqYoUHf'
                    'YyPlZ5j/OGFK631cO9KP5cnpRcFYASwgkAAPM5iGsMJoy3azj769OdiPi713VtVl'
                    'c6T/H8P3+3+/w/fxev/+7rz3f+4K3Twa3Bbt/7AtggJ+HdcLD2Rn3OgfU1GAyOI2'
                    'Lye522FRBK5rR+UN/mOm1DCou0eoioDyksu9VD3brX2eqhaR9lv69puE7XVg/RMa'
                    'RwdeyjiPgkIp6UrAzAFOEEAIDuDuIa3kWZztNXp78+vXj5ly/e066BJi8/e7nz8r'
                    'OXO2/s77zY+e/fTCopACzFvYjYD72EAaBPexFxXDm6YEihU6uHujl1rQI6nl863P'
                    'QAv2ntqoBGXUhhkVYPdedlbPVQHE7dWz2M7a3V/UweexQRB5fHAKgknAAA0M1eFI'
                    'n4LO9OLwkkQCcvPn3+xsvPXmj3ALA8J1G0cgIA+vEwpbRbWTlg5DpaPbS5TtUD7v'
                    'Hxumu0aIMwV0hhkYBGh5DCxL5aVF8oG1tGSKExfNFirVb3U8y/GwPtHQDauNH3Bg'
                    'AA1sheFBUT7ixz0XSevnr52csvfvOvv46n//LLd777D9+8d/HsfJmXYMuM2j08/c'
                    'mXO2d/ffp53/sBWHMPoqieAABcv/0o/l8cKaXmNi0prh4ud5yThv+0WqfD+MS603'
                    'Oa9lkzVvta1O2vZGzm3uddd3qtOfYyPlZ5j/PcW9c9DI+3vp8UH0VRaROAGionAC'
                    'xA30rYDmMp+YcRcXcpi76K56e/fvnli1+8+KEKCeSSzlN889Nn77/2vZvx1t9/+/'
                    'PX3n7t/b73BLCmjqOunDQAkMvJ9IHRz+NqKyks2OqhODxoVyWh7jp1rQ86nl86XN'
                    'fqYXR+h7VbtXqoW3eRVg8VY5X32LF1RG2rh4pzxq+TBq3u51EIKADUUjkBAKCdhz'
                    'F8t8bcUnx39sXpL7958iy++j/+dufbf//ND1VI4DpcPDuP3/zrp+9/9x++eR6v0o'
                    'u+9wOwho6iqKAEAFyfw6j5Pvw6KiksusbE+PS6Xc9vqDBQum7Hvc3scYGqB3NXUq'
                    'g4XnmPDZUPJg+NVVFoec703hru525o7QBQS+UEAIBmRxHx4bwnn399/svTz168d/'
                    'r56ZvpPL25vG1BNy9/9XLn9PPTePvge1/cfPfWe33vB2CN7EbE/SjeDQesG0UPYV'
                    '2dRER95YIoHlrXVlGIaK6AUDFnpopC035aViooraIwNadpjbKxFDWvRcfKBa0rSL'
                    'RcN0WarRrRsYpC7T1WnTdPhYgWa9Xcz0dRfM34ackdAGw94QQAgHoHKdLHXU9K5+'
                    'mrlz9/Hqe/Pn3n1fNXP8qxMZhHOk/x7E9/897Nd2/FW3ff/npwa7Db954A1sRJCC'
                    'cAwHU5jIh7EdEqWHDtrR7q1lm01cNozpwhiMbXYt6QQptWD3XrLrvVQ1TcY4fQw8'
                    'S9ddlDc6uHR5HisGRFgK2nrQMAQLW9iHjcevareH72xdkvn/2br+Pr//Ord178/M'
                    'U7r56/yrU3WMj5l2fxm3/1dPf8y7Mv+t4LwJq4E+GHzABwTR5O/KpNa4W4xlYPUT'
                    '7e6TpTrQ8WOb90uK7Vw+j8Dms3tkRoWneRVg9VHSu6tnqo2F/jfXVv9XAviiqcAE'
                    'xROQGgg+d/9bzvLQDXYOd3duL23u04/fr0cRRlnGtdfHvxq5efvnj37PPTnXSeVE'
                    'lgbaTzFN/86bP3br1/+7u3/v7bg7gRO33vCWDFHUfqEFwEAOZxFBF3S0faVD+IvJ'
                    'UU5mr1UDenqqpAl/OrxodtEGJQsm6HvU0eSs333qHVQ/Fpy0oKXe+x31YPDyPik4'
                    'h4WrJrgK0lnAAAUO5fDGJwt/IdF6/i+el/e/nti58/f+/V81c/vN6twXKdfX765m'
                    '9+8zTe/sPf+vLGGzfe7Xs/ACvsg4jYDz2EYb20eLc1sFJOImKxB/6jaSnVBxRGaz'
                    'VMqXpIX2yhQ0hh0VYPdddoWD9FzWsxb6uH0b0v0OphtN5g8gJzhR4q7/EaQwpjrR'
                    '52owgoHJXsFmBraesAADDr5PTp6T8qCyZcfHPx+Xd//u3zp//yy53v/vzb97RtYF'
                    'O8ev4qfvOvnr57+quX2jwA1DvqewNAe2dfn/W9BaCboyhaKbULFq1Iq4fLkv4Ltm'
                    'KobX0wPmfO9Rtfi01p9VB1jx3Wm7i3OdYanv8gtAUDmDBo/J8ywDX6B//knxefXP'
                    '7VNPYF4PhfV1PHUsmx8s8b1pv+PCJe/3sqXMOW2Y9B/PkbP3hjZ3BjGIOfrJLQ7+'
                    '7gGtz6gTYPADW+joi9vjcBtCOcAGtlL4rqRLPtFZsqG7SdEw2tHha83sS7/5ex58'
                    's371dMbHl+1VjlunOuPYiKagMd9jSzVsfzpo93fu3mua/6438WEQd9VvH5l//LP+'
                    '7v4gBTtHUAaHD2xWnfWwCu19Hrv/366eDGYOfVi1dfvPjZ87fOPj/dSefJQ1q2xt'
                    'lfn7757P/5Ot46+N4XN9648V7f+wFYMbtRvKvzUb/bANrwxixYI4M4jojd0ofJbd'
                    'smNM2JJbd6mLreUls9jI0v1Oqhanz47v7KB/hztJG4bM/QsU1E2djMPTe1j+h6j9'
                    'fX6uHu8M/2w4rdA2wV4QSABjdv+qsStsw/HAxufPPNnz7bPf/qzENZttbFs4t49m'
                    '++fu+tg7e/uPnOLf8tAEy6H8IJALBMexFxHDH2gLvMkkIKo+BSbUihZdih6iF9cW'
                    'qLkEKH8YVCCjVjKWoCGx2DBjP3Pmdw4iqTMPbnYYHQQ+U9zhtS6LKHFCdRfO34tO'
                    'QsgK3iiRtAg9PPXva9BeB6/U+nn738Yd+bgFWQzlN886fP3nvr7ttf3vrB7Xf73g'
                    '/ACvkgIvajKD0NACzuJNKwnUPdQ/iRtpUNWlRRiFhCSKFiTusH9W2u0zakMGcIIq'
                    'WaKgpzrN1YbaBp3aYqClVr1ozV3mPdPsp+X9NwnXbn7EZROeGoZDbAVhFOAAC4ch'
                    'QRd/reBKyab//sm3dv//D152/+j29pbwJw5SgiTnreAwBsgv2I+PDyV20ewk/Nq9'
                    'Sh1UNE3pBCp1YPdXOmXp91aPUQ0RBSWKTVQ915GVs9FIdTl1YPD6KonvC4ZFcAW+'
                    'NG3xsAAFghJ31vAFbV6a9e7nz3H7993vc+AFbIUd8bAIANcVJ6NMXlA950+aS3ft'
                    '5Cc+IqpNC41hxz0vCf1vtpOT6x7vR43Rp146l4LSpf94Zzq+5/3nOnx2b2Ned6lb'
                    '/fVeeVHL98/dudc1KxG4CtIZwAAFA4ClUToNbpr17uPPu/v454FUIKAMXXDYd9bw'
                    'IA1txBFO8or9b0EH583hJCCiml5pDCAtfqFFLoMF4bUmjaZ81Y7WvRMWgwc+/zrj'
                    'u91hx7uRyq+/2e597qz7kXAq7AltPWAQCgcNL3BmAdXDy7iGf/79c73/uHu8/jRm'
                    'jzAGy7o1CaF1Zbm3c4A316GBGNbRfGS+TXtnoYzW2z3gq0eigOD5r307HVw+W6c5'
                    'xfOpxqWj2Mzu+wdqtWD3XrLtLqoWKs8h6b1uvS6qGYcBJFeweAraRyAgBAxP1QNQ'
                    'FaGwUUVFAAiPsRsdfzHgBgXR1GxL2IaN12oVWlgLbrdWj1kLuSwqJrTIxPr9v1/I'
                    'Y2CHO/5vPee8uxzpUUKo5X3mO7tg2Teyk/5054gwywxYQTAAAijvveAKwbAQWAiI'
                    'jYjSKgAAB0dzJzpG21k6mH0m3mLTQnGtobjK81x5xOrR6artO21cOCIYV5z618kB'
                    '+zY/OsO3O/c4Yeals9LB5SOA4BV2BLaesAAGy7wxi9UwPo5LLFwx9q8QBstfsp0q'
                    'O+NwEAa+Yoqr4Xb9MqYXzuJrd6qFunw3jl69N0zzXjja9Fx/YKnVo91K277FYPUX'
                    'GPVa9N070Vx3ejCCiclKwAsNGEEwCmtfnGB9gcyTeCsIiLZxfx7E+/3nn7D39LQA'
                    'HYVh9E8c63p/1uAyjT6p3OwLUaPjA+aRUWKE5oPa82pLBAaGBm2jWEFCYerC+y56'
                    'nXpzSg0PL80uGUIgZzBkMWDSk0hAOWGlIou8cWQYnJQ2n8vj6KiEcR8WnJ2QAbS1'
                    'sHAGCbHYaqCbCwi2cX8c2f/kaLB2Cb3e97A8Cs06enfW8BKHcUEXfmaeHQdl5lO4'
                    'O263Vo9dAYgprzektt9TA2nrPVw9yveUWrizbXbdvqYWJvTedVHK+8x/lbPZxczs'
                    'n5AbBChBMAgG1WvFNDxRRY2MWzi/j2yTOVE4Btddz3BgBgTeylSA8vf9Xl4ekc8y'
                    'oflre9doeQQpd9dZnTKaTQYXyhkELNWO1r0TFoMHPv8647tl7VWJf1Ku+xe0jhQU'
                    'TsV1wJYCMJJwAA2+owxqsmCCnAws6/Oo/n//E71ROAbXQ3/GAZANo4jojd0ofEHa'
                    'sjtJ1XW0Uhov16TVMyVlEoDrd8UN/mOm1DCnOu3/hadFx7qtpA93UXqaJQlUOou8'
                    'cOVRlSpJMUef8BWCXCCQDAtjopPSqgAAs5/auXOy/+v+cv+t4HQA/u970BAFhxez'
                    'FWbaj0wWlfIYUlV1HIHVJYdI2y8aW3eohYvNXDPCGFlmNLafUQNffYvoqC6gnAVr'
                    'nZ9wYAAHqwH+NVE6aNAgrC5TCXl3/54o3Xdl/78tZv3363770AXKOjiHjY8x6Acb'
                    '6eh1VzHBG7028KGD3YHYwPpGj35oHRf+dNc8fmpUiT1+q6XstrppRiMGia1LxO2Z'
                    'yJ16ztnluMl/5ejMbrrlE3nobrDkrWbbt2yf033nvLsZk/D1Wv1bz3WHXe5PGHIe'
                    'gKbAnhBIAI75SGbZMqqiZME1KAuX3377599+1/9NoXr7392nt97wXgmoxaO3za7z'
                    'YAYCXtR8RHEVH58HfmwXjb4EHNmlXzKh/Cj89runaLOaMKCrUhhQWu1Smk0GF8oZ'
                    'BCzViKmsBGx6DBzL3PGZwovd8FQg+V91gfevggBnEYEY9LZgBsFG0dAIBtsx+DeN'
                    'AplCTABHP59t8+ey+dp6/73gfANbrf9wYAYEWdTPyqpoT+yrR6iGi/XtOUa2j1MN'
                    'HuYZHrtHl9crV6mGPtVq0e6tZdpNVD1Z/hrq0eirGjy/FlfwCsEOEEAGDbnFx+1j'
                    'WgIKQAnaTzFN/+22e7keK7vvcCcE2O+t4AAKyg/Yh4UDrS5mF7w9y2a9bNqw0pLB'
                    'AamJl2DSGFRdcoG+/8oL1pPDWEFOYIGrQKKbQc6xxSqDjeMaTwIIr/VgA2mrYOAM'
                    'A22Y/pH4h0bd2g1QN0cvHNRTz/T98Ndv6HN/veCsB1uBsRexHxtN9tABHha3ZYFY'
                    'N41Dhn9N9rXduC8bnLbvUwvHaKlL3VQ0Tx0Lq21cNorab9l8zp1OqhzXWG4wu1eq'
                    'gaT8N1BxUtNhrOLRu7/D2c49zpsZk/D1WvVYt7rGz1MHneSQi7AhtO5QQAYJucVI'
                    '50rYygkgK0dvpXL3dO/+rlF33vA+Ca3O97A0DE6VenfW8BKBxGinutZ1e+kb7DO9'
                    'mn12sbVGpTRaFmj12ve+2tHuatcjA1Plerh6bxYZWBufZXMta6zUWLighLbfVQdY'
                    '9Xh1VPADaeygkAwLbYj6oykuPmqaTgHVnQ6PlffPfezXdufXnjjRvv9r0XgMzuR7'
                    'R4hygAbIeTiGhdUaBpbuk72dusO8e8ykoBXddrUUUhIuorKSxQtWGmksIilR+aXp'
                    '9FqijE8LWoqqIwOr/D2pd7TIPmfbWoolB8Oqi8Xt1eLoeq7vHqnJNIqicAm0s4Ad'
                    'he3vEM2+YkIvKEDrR6gFa+/emzd7/3j3efx43Y6XsvABl9EFo7AEBEEdibrJrQtt'
                    'XCaG7Mzl+41UPJmnXzFg4pdGj1EJE3pNCp1UPdnLHXu7QVRl+tHqb2dnVoua0eik'
                    '9bhhS63mOKB1H8DOvTkjMB1p5wAgCwDfZiVGI5Z+hASAFqvXrxKr7782/Tm3/vrb'
                    '63ApDbYUR80vMeYKs1lkoHsho+YH9YOtilikLN/E4PicvW7BhmKH0I37DHznOi+P'
                    'urNqAwWmuOqg0zVRSa9tOyUkFlgGMJIYXK16Jj0KB1BYkOIYVWAZn57vEo6lqTAq'
                    'yxG31vAADgGhxHxO7lrwbRrXpK7vmwRc7+5vTNs785/bLvfQBkdr/vDQBAz44i4k'
                    '7tjBTdwv0Vc9P0QNt1u1w/XV1r5nol89qsVTslpeaQVZv9V8yZuI+mdTqMV74+bf'
                    'ZZNdT0WnTc++Ue29xXw9jM/datWTNWco/HUbzRBmDjCCcAAJtuL4pv6mZdR0gBmP'
                    'H8L757N52nr/veB0BG9/veAAD0aC9Sh3d9dw0JND1s77ruHPNqQwoLhAZmpl1DSG'
                    'FiziLXmXp9Fjm/dDgt8JrPG1JoObbUkEIxuBtFwAdg42jrAGwfDwthu6Spqgllur'
                    'R66DpfqweYkc5TfPfvvtl96x98r++tAOSyGxEHEfGk320AQC+OU6Q7kYYl9Lu0b1'
                    'h2q4cu67ZsuzA+r7KdQdv1Wl6zdauHOa631FYPY+M5Wz0Uf6zmeM1L9n7ZnqFlO4'
                    'e6sdJWIx32Mjo+vMfjSBWtUQDWmHACALDJ9obfzDXrGiLIPR823PnT8zj9q5df3P'
                    'qd2+/1vReATI6iqnoTkNXp09O+twDbbC/G/v83emd644P1qxMKCwYaSh8St123S5'
                    'jhcvlU/rC87bVbzBlVUGgVUmgTsKgLdiwSIJgaXyikUDOWoiaw0TFoMHPvcwYnSv'
                    '88zB96uBPF15OPKnYDsJaEE4Ato2wCbJd0HBG7nYIBQgpwbV781+fv3fztW18Pbg'
                    '7qq5sArKfDvjcAAD04jpLqhSml7lUUIhaueDATGpijOkLbebVVFEZz5wgNzExpE1'
                    'JYIBDR+kF9m+u0DSnMGYJofC06rn25xzSovW5d1YPReZ0CMtVjRyGcAGyYG31vAA'
                    'Agk72IwfHEkUG0/0FIl7mj+V3ISkGk8xTP//23ggnAprobEft9bwIArtF+1FQNSp'
                    'GKh8ldwvop2s+vmJuG/8y17hzzSq/XZb2W10wpXT6cX2itmtdt0TXKxktfmw7nlw'
                    '6nBV7zuj8zdee2HJv589B03qR7UbQKA9gYwgkAwKa6HxG7pSmAXKGDeQINQgpsuf'
                    'On53H+xdnnfe8DIJPDvjcAWyn58OGjp4+TKKmaMG3ukEKXuSXzK0MKC6xZN6/yYX'
                    'nb9VpeszGgMFprjjkTr1nbPbcYrwxwNF2jbjzF/CGFmj8z8547Pdb6z97sescVMw'
                    'HWkrYOwPbwABC2S/FDkaGSXgpaPcDKeP4X373/vf9590XciDf63gvAkt0PpXgB2A'
                    '77EfEgUrT+Gdzonem17QkmTyh0aQ1R0eqhWKZFuf2Wa1bNa9XqoenaLeZce6uHun'
                    'U6jM/V6qFpPBXr1rZ6qNpfyVjrNhdN687f6uF+ROxFxNOKKwOsFeEEAGATHUXEnd'
                    'nDaxBSEFBgC6XzFC9+/jze+Ls7fW8FYNkO/b8dgC3x8PKzjiGClFLxsLZL6KDt+j'
                    'VzU6TJh+Jt151jXquQQpv1GuZce0hhkVBF0+uzYAgipRTFH6s5XvO6kEIaNO+rIf'
                    'jQMaSwG8XPuR5WXBFgrQgnAACb6KQ+GNBDSEEVBah1+suXb9x+//bnN9567f2+9w'
                    'KwRLtRtHZ43O82ACCrw4j4YOZohxDBZRWFaw4pzPVQfIF5tSGFJVVRiLiekEKrKg'
                    'ptrjP2MH8mMNL2/KrxYRWFypBCh71dHWpx7y3HOoQUjkM4AdgQN/reAADAkh3FeN'
                    'WEQdR8k1wy0KUFTNe5OefDBnjxX54LJgCb6LDvDQBAZie1oylaB/BTpMsH6611mV'
                    '6xlzT8Z651u8xLV9drM2+hORHtXss2+296zdruuW5s7LUpfX2arlE3nhpei4ZzZ/'
                    '9oTN37guu2+LN3J3xNCWwI4QQAYNOclB6tDSgMGg9Vyh06EFJgi5w/PY/zL84+73'
                    'sfAEt2v+8NAEBGhxFxr9XMDiGClDqGFDoEIOr2UvqQuO3D+45hhsqH8FPz2qxVO6'
                    'XNa7lAIKJTSKHDeG1IoWmfVUNNr8W8IYUFgxMTa1Wfc1RzBYC1oa0DALBJjmK8as'
                    'K0VWv10HW+Vg9sgRf/9fn7b3//1ncxiDf73gvAktyNiL2IeNrvNmCL+LoZrtOjiM'
                    'jTiiGKh8laPTSst0KtHorDg9J2CJ2u0/T6LNLqIYavRVWrh9H5Hda+3GMaNO9r/l'
                    'YPD6Jo7/C0YnWAtSCcAGw27zaG7ZIaSkmONIYU0uyhyvld1m53uaWtDWvo1YtX8f'
                    'Kzl2ev/+j1vrcCsEyHEfFJz3uArXD61WnfW4BtchSjNwg0PYye1iFEMHpneueQwo'
                    'KBhsqH4gsEH+rmbVJI4TKgMOcaE+OXz+jT7GuzSEghDV/zqpBCh71dHWpx7y3HKk'
                    'IK92MUCAJYU8IJAMCmOIzB2A9F2qgMBlSkALoGCXJWUegyH9bM6V++2H39h6+/iB'
                    'vxRt97AViS+yGcANeitkQ6sDTDB6YnEwc7VkXoes5lSKHuofoi+6kIHtS8k33uNU'
                    'vnDdcsfQhfMq/NWrWXTKn5tWyz/4qH9MUWOoQU5q2iMDWnaY2ysRQ1r0XHoEHrCh'
                    'IdQgpj93scwgnAmhNOAAA2xcnlZ0sLBqxBq4cu82FNpPMUz//Ld2nnD3R2ADbGof'
                    '9fA7BhTqKqreK8IYUOrR4iMoUUaubOhAaW3ephNLepisLYvDZr1U657lYPdess2u'
                    'phNGfOEETja3HdrR7Gxsbu925E7EfEpxVnAKw84QQAYBMcRsS9iSNLfdC/BiEFDz'
                    'zYMGf/7XTnjd/b+Xpwc7Db914AluBO+EEyAJtjL0U6rnxwPjJP5YIO81MahgVyrN'
                    '+11UObdbV6uJqzaKuH4fjSWz3E8LVYpNXD1HirkEK3Vg/Hww+AtXSj7w0AACzBSe'
                    'XIILq9W6N2fslA17W7WNq+YT29+Nnz233vAWCJDvveAGyF5MOHj+wfxYPR3RTFP4'
                    '1aTJmZ3/KcFKl4mNzlGl3nlswvvfe267a9v7F5ta91m/VaXnMUUlh4rZI5E/fQdo'
                    '0W45WvTdM16sZT8VrM/ZpX/Jlpc90WY/drrgyw8oQTAIB1dxjTVRPKzBNSaLtQl7'
                    'WXGpZYwnxYYWe/Pt1J5+nrvvcBsCSHfW8ANt3Lr172vQXYBvuR4nj8AWrrgMI8IY'
                    'XWU1O7B+vz7qfyGfXUA+wu684xr/a1XlJIIaWWr2XbgMXMoQ4hhQ7jC4UUasZqX4'
                    'uOQYOZe59v3Tvh60pgjWnrAGweD+Vg25x0+oFClxYI697qoct8WFEvfvb89s4fvN'
                    'n3NgCW4bDVwxsAWG0nEbEbEVffbza1Hxg3dk4rHef30eqhGJpqL9B23TnmNb7Wqe'
                    'V6K9DqoTg8aN5P03XavD5112hYv/G16Lh2q1YPdeumOIqIxxVnAaw04QQAYJ0dRs'
                    'S9fh/09xBSyBXGgBV09uvTndd//42vBzcHu33vBWBBdyJiPyI+7XcbADC3/Yh4MH'
                    'N03pBClzcYdQgRpEgRKa49pFB6732FFBYIDcxMu4aQwmVAYc41ysZnAiMdzy8dTi'
                    'mKP1ZzvOYlf+ZbhRTK171fcRWAlaetAwCwzo4nftVry4SSgaW0kei6jyXMhxXz8m'
                    'cvbve9B4AlOex7AwCwgJPa0an2A40Vg+Zt9dDynM6tHkbrL7iX0nvP0ephrJ1Bm3'
                    'kLzYmG9gbja80xp1OrhzbXWUarh5p2DSnV/Pnu2OphtM+O5+6GgAKwplROAADW1X'
                    '5EfFA60ls1Aq0eIIezX5/uvP57qicAG+EwIh71vAcAmMdhlFVNmDb1Lu/Sd683nN'
                    'NKh8oLrd75v8h+KvYyU9lg2VUUxq7dqtVD05ot5lx7q4e6dXK3emgaT8M/33WtHq'
                    'r2V9fqoanNxdW59yPik4pZACtLOAHYHN4VDNslNbxjI6Jb6GDdWz10nS+gwJo5+/'
                    'Vp3P7d1/veBsCiDvveAGw0X+NCPoMW34OPm7fVw/CcrtdoNT2la2/1UAxNBTT6av'
                    'UwmttmvRVo9VAcbnhQ3+Y6Ta9PzlYPo/M7rN2q1UMx8X7FCMBK09YBAFhH+zFo8Y'
                    '6NiBVo9TBoPLTUvXSZK9TFGjn95cvdSPG8730ALOhOFNWfAGCdHEaKe3MFgLq2ep'
                    'g6p/U1urZ6WEL7hi5zK1s9tG2D0HFe7Wu95FYPje0eFrhe51YPTa0aptften5Ny4'
                    'W5Wz1E+ViLe9faAVhLKicAG8HzNdg6JylijaoRlAx2reqg1QNbLp2nOPv16fmt37'
                    'nd91YAFnUYWjsAsF4eXn42bwuGsXNaVVJYwnXqpxYBhdatHkbrL1h1ofKd+x1aOH'
                    'S5dm1bjSW1eogYVqVoei3nrNrQqdVD03Xatnqou0ZDu4ZrbvVwGFo7AGtG5QQAYN'
                    '3sR8SDie/H1qIaQQ9VFFRSYMOcfvbye33vAWAJDvveAGyi069O+94CbKqjiLg7c3'
                    'TeKgpN715vOKf1ddpObfPO/0X2U/lG+sxVFMau3Vixou11m6ZcQxWF1pUUOoxXvj'
                    '5t9lk11PRaNFRhmP3jkS4DNVNj9xt2CbByhBMAgHVzMvpk5nn6qrRAWPeQAqyoVy'
                    '9exfmX57/sex8ACzrsewMA0MFJ5cg8wYGp8zq1eugaCugYUsi2fpuH7V3XnWPexr'
                    'V6iPLxTteZen0WOb90uK7Vw+j8DmuXhBTuRMRBzSoAK0c4AQBYJ/sR8WD64MTz91'
                    'V70F8bUlhg/a4hAlUU2BCnn738Ud97AFjQnSi+pgGAVXccxf+36i0SUrj8tENIoe'
                    's1Wp6TIs0XUlhwL5UhhQXWrJu3CSGFTlUU2sxpU0Vh3pBCaggptNzb5KGJe79/uU'
                    'bVB8AKudn3BgAW4uEZbJvjum+qBjH2Pdfo74c234R1mTvv/NK5FQtVzl/CPnLOh2'
                    'tw8fV5pBevvhi8fuO9vvcCsICDiPi05z0AQJ29qKuaUGb0vWOXn9dNnZMixaBpgX'
                    'mv03L+6J3pg0HrE7rtp2IvowfOg6sXo/26be9vbF7ta93m2i33l1Jqfi3b7L9kzs'
                    'Rr1nbPVeNj58/8XpTMmWf9FDWvRd3aJWNje7yfIp1UXBVg5QgnAADrYi8ijpoemM'
                    '8M5w4pLOVBf8ngqoUrusyHzF7+8uVbb/x3O31vA2ARhxHxSc97gM3ia1VYtuOI2J'
                    '3rjUEdggAT50TUPxiuOafrNVpNH77rP0tIoWbuTGig7bpzzGt8recMDcxMafNaLh'
                    'CI6BRS6DBeG1KYc/3G16Lj2inS3Siqcn1acRbAStHWAQBYF8cRsXv5q4ZvfGc6E3'
                    'Rta9Bl7lJbPQwaDy11L12oVsOKOP/ibCdSPO97HwALOOx7AwBQYy+K78HnD/7MW0'
                    '6+bfuBRa7Vcf5crR7azq+YW9nqoc26c8zbhFYPxeE0OWeR60y9PoucXzq8aKuHyf'
                    'HDmtkAK0XlBABgHezF6Acj41q8o39iytpUIygpydC1SoMqCmywdJ7i/Muz39z8/i'
                    '3lE4B1dTeKr2+e9rsN2BytHmACrQxi8DDG3xzQtULBuHnPnWo/MNxX63OWvbfLVg'
                    '8xWLh9Q5e9lN5723WXXUlhgcoGM9OW2eph6npLbfUwNr5Qq4eq8TRcdzDna36198'
                    'OIeFQxC2ClCCcA68m7d2G7pKmqCdNahhTS+C8a5ndZe+H5lQGFqYVWbd9d5sOSvf'
                    'zLl+/f/P6tvrcBsIiDiHjc8x5gI7z86mXfW4BNsp8iPYiY4yFsnXnOnTpnpt3BMq'
                    '/TunPDMKSQo9VDzV5mHox3WbdLmKHNa72kkMLSWj2M5q1Cq4emNWrGUtQENhoCDh'
                    'Fxv2JlgJWjrQMAsOr2oqxqQpmGtgbX1uphnrVXqdVDzvmwJK++vYh0np71vQ+ABR'
                    'z2vQEAKHEy+mShMv9V5jmvbfuBinO6XqPV9B5aPRRDafpAu3XnmNf4Wrddr2nKNb'
                    'R6SFc3tdh12rw+3doxTA7XtXqoX3s3iuArwMoTTgAAVt1xDGJ3mUGCiefpa/Ogv4'
                    'eQQhcCCvTg9LOX533vAWABh31vAACmHETEg/EDtQ+oFwkoXGdIYc5rNE9NvYQUSu'
                    '+9r5DCAqGBmWnXEFJYdI2y8cqAwrwhhdQQUqg+97DmigArQ1sHAGDVHV9+VtkCoU'
                    'TLVg+XU9amZULJi9D1dell37B8539z9s7rd97oexsA8zroewOwMXz9CcsxiIdVQ3'
                    'OXsq8z77lT7QdK97XodTqc07nVw2j9Lq0eSvZSeu9t1+0yb3jt62j1EFE8mG98Ld'
                    'vsv2ROp1YPba4zHF+o1UPVeBquO6j48z177v2I6v+GAVaFygkAwCo7iqI03ZUM1Q'
                    'tmWj2sfDUCrR4gIuLVy1dx8ezil33vA2BOyu8CsEoOI8W9prBPbSn7RSopzHNOGv'
                    '9lyyoK81RSaDu1zTv/F9lP5Rvpp35Pll1FYezarVo9LKGSwrW3epi3ysHU+FytHp'
                    'rGh5UUWlz/XsNVAFaCygkAwCo7qRxZ8rv6Z4bXohpByeCqVYDwLjYyO/v85Xs3vr'
                    'fT9zYA5nUQEU963gMARIx//93iXemV76LvUhFg+ryY49ypd/YXn7Z4132Xa3Wcn9'
                    'Lwtcmxfs3cmd+TtuvOMa/xtZ6zssHMlOFD+dpKCgtUbZippLBI5Yem12eRKgoxfC'
                    '2qqiiMzh/EYUQ8rrgCwEpQOQEAWFVHEXGncdaSqxdMLLc21Qh6qKTQZa4qCmR0/r'
                    'fnkgnAOjvsewOw7k6/Ou17C7AJjmL6Xddt3t2eq4rCvJUUmvZVc07ra7Q8J8Xwnf'
                    '9dKyN0qWTQVBGg67pzzKt9rZdURSHieiopLLrGxPj0ul3PrxofVlGoec0PL88f/w'
                    'BYISonAOvDwy3YNiedvoFacvWCieXWphpByeBaVICA+aXzFBdfnf/ytXdu/qjvvQ'
                    'DM4aDvDQBA1FUtbPGu9Mp30c9bDWHec6fOaVVJYQnXqZ9aBBRq3/lftv6CVRcq37'
                    'nftjpDxyoOlZU0avbYeU4Mq1I0vZZzVm2YqaLQtJ+667SpMrFIJYU0fM1nX4uDyv'
                    '0CrAiVEwCAVXQUEXf6rUZQMrwW1Qh6qKKgkgI9O/v8VDABWFd3I2Kv700AsNWOok'
                    '3VwlaFCBZ4B/0C1226XusqCvNUUmg7tc07/xfZT+VLn7mKwti1GytWtL1u05RrqK'
                    'LQupJCh/HaSiNN+6wamn0tDhtWA+idcAIAsIpOJn61iiGFLmsvaR/d5q9BSAGW5P'
                    'xvzyNSPO97HwBzOuh7AwBsrb2IeNh6dosHvo1l/ucxb7ihbfuBRa7Vcb5WDy3Wa3'
                    'nNa2v1EOXjna4z9foscn7p8FWrh93wtSWw4rR1AABWzVFUvWtjqS0Qus+fuPyqtX'
                    'qonH+NrR7mWTs6rg8VLr46/0JrB2BNHUbE4573AOvL15Iwv0EcR/Ews5sWJe9Xpt'
                    'XD6LwurR6mzln23i5bPcSgW/uGvls9lKxZN6/2tW6zXstrjgIKte0e5rzeUls9jI'
                    '3nbPUQgziIiCc1uwDolXACsPq8uxa2S4rjxjk5H4C3mD9x+VULKVQGFKYWWrV9d5'
                    'kPJc7/9uxHr73j2xtgLR30vQFYV6dfnfa9BVhne5fff8/7s7d1CilMnZMitQsozH'
                    'OdlvMvQwp1D9UX2U/FXmZ+T7qs2yXM0Oa1XnJIofG1bLP/kjmdQgodxhcKKVSPHU'
                    'bEo4pRgN5p6wAArJLDGMTd/5+9v1mSI0kSfT/1bvSc7pk5griHhx9CComgkMIrFF'
                    'JYeXl5uUWuuO16A+SSu443aB8+QcwbAG9Q/QYJru8i6w0yhSuSl2cyp3s+ugqAcx'
                    'HpWRGRHu72rWrm/99IyRSQ5mbqFoFqRJi6qtNIi60ecrZM8Blbc6sHEtIQ6Mt/+a'
                    'IdAgCEutYOAACwSr2MVRN8WxmccynBf2lQzNoh17m2H7hwje8aTsMVWj0cfjSc/4'
                    'bbvAHjFvfadb6lIQVaPQy/3FTcOi7743j9mauFyABAFY8WATCOUypgZXoREekcP+'
                    'iJKFYjuDBdrpYJyVs9nP0wdyUFny9afMcDIjJ8GeTrn7/+v379H39NawcAtXkrIl'
                    'sRudcNAwCwIlsR+cOr3/VtZXB+rcxfv1jmv3Srh+frvFo9+KzlMT641YNrPBfGXm'
                    'z14DJvwLgWWj0cfnvwa/UwN+ZsfxK0enB76AcAlFA5AQAAWHEtIu8P//r8CH0V1Q'
                    'gmhlRTjWDiB4p7GDUeEJEv/5+f/rN2DAAQ6Eo7AADAqvQXf5KiisLig+szT4nHVF'
                    'EIraSwFNfMNc5rOF4zyBBWSSEylsl7T1Cd4dK4xSoKsVUJxmFLVRTGuQLGvKqi4B'
                    'Kzw8+D/3yc/vx6YTUAUENyAgAAsKJ//VtHSQqulA/Mi7Z6SLIvtHpAO74+fv2ddg'
                    'wAEOhaOwAAwGpciciHxVE1JymEXHOWpOB7jfM6zkMd2hPExHNh7KvXxGdez3FOrR'
                    '4SJCkUb/XgnkAw+/OoJAUSXwEYRnICAACw4FpeqiZMKVBFIeH4Vz/OlVwRMnfNSQ'
                    'rAgm9//SbDT8P/WzsOAAhwpR0AAGA19l6jUyQpLA65eFKeJNkg5DqvKgoJKhdcHB'
                    '5SRSFBxYPJKgqe1RFcxzklKbjMtzSkdJJCzDquSQqXr796mSPmzy8AZPBGOwAAmM'
                    'QhFLA2/fKHpef/MHSOH/SOLnH+IBYyfmbsyXQ+c5eI++L4iR/mjj3XfWKVvvzTl1'
                    '//5n/yG+0wAMDXTJImAADJXEvo/+YMEv593fgZbub68fC1mxoUurbDuhev6xziun'
                    'BN6tgGOSQodD6VJX3u/cLYyXt3nTdg3OJ7YGk+xzXHBIWum31DBq83yHC4hxQxn+'
                    '3Pq725fP12ZlUAUEVyAgAA0HYtIu/dD54DkxR8DrQTH5jXm6QwLP7W7NwqcWPtvv'
                    'x/f/7PJCcAqNSViNwpxwBUxavkOQDppOujHggKPez3uP7iAXXM2iHXnl3jlKSQYJ'
                    '35oc9JCnOH6lPzRyY0XExScE188EyQmDyEX4jRe4wc/jdkcS9d4p8Yc7JnrjE7/N'
                    'zjzweJrwDMoq0DAADQdnPyK+fP2M99ASy1HVgY/6rVQ87YfdTc6oFKOzjz9Z+/iA'
                    'zyb9pxAECAK+0AgJr89Z/+qh0CUJvvBxneJynzHjuHw/WzpexD1w657my9LK0exm'
                    'tch7q0J4iJ58LYV6+J67w+6y+1MliI0Xfd4q0e5ubx+Lljq4ermdkAQA3JCQAAQN'
                    'NWRD68+l2vQ+euqgPzVz/OlXSQNO4KkhSAI1//8vV/0I4BAAJcaQcAAGjaXkTcD0'
                    'pdFLj+4gF1TIJCZJLC4sF56Fqe44dhyDf/zNhX9546ScF1r33mWxpSOkkhZp2l/f'
                    'nl59uFlQBABW0dANjCAROwLoP0sz/P3erBdew43udD/8L4plo9uM6fc89p9YAjX/'
                    '/py9//+j/+WjsMAPB1pR0AAKBZNyLybvzFq5LztHrwu86n1cPZNalje2n14FNZ0i'
                    'eeC7FEt3qYmHNu3Oxeu8znuOaYoDDb7iFivZeWFSliPnsvTvz5uBKRH2ZWAAAVVE'
                    '4AAABatjJVNWGK85P0nq0exkt8xtbc6iHJvlyYqKI9R/u+PH75r7RjAIAA77UDAA'
                    'A0aSMy/WDAy1PXqaooxMzhUoL/0lP0MWuHXHt2jVMlhQTrzA8t0OphqSKA77wBVR'
                    'wWWz3EViUYh7nsZWDVBq9WD0vrzFdR2DpECADFkZwAAAC09PnK9zfQ6iFn7D5ja2'
                    '71QJLCan37l68yfB3+STsOAAhwpR0AAKA5OzmqmjAleauH2CSFxSGRZf4D111aL0'
                    'urh/Ea16Eu7Qli4rm49RdbC6Rbf66VwcQ4l7lmh5Ru9eCYhLD086N5twuRAYAK2j'
                    'oAAAANWzmumpClfH+hVg8Jx7/6se++qMQ98UNrbSpiv1xDlb7+85e//HrzhgoKAG'
                    'pzJSJ3yjEA5v30+JN2CEAtNnJITliUtNXDYUKdVg8xa7u2G5i5zqvVg89anuOHYf'
                    'Bv9eA6/0zLgsNvd4tjg9d33WuX+RzXLNbqYRwT2+rh+eeDDO9nZgIANSQnAAAADf'
                    '2r38l2SF0oScHnAHxh/Mny1g76L46fuKlcyRUhc4vn/Kjel//y5T//esPHHQDVud'
                    'IOAKgCf68D3HSyE5G3Ppe8HPgO42fpiPVDD/s9rr94QB2zdkySwssZs0eSgs86Hr'
                    'GNLTu8kxQiExouJilEJD7MjSuZpDCboBCx3qvkIJc53H6+EZHHmZEAUBxtHQAAQG'
                    'kbOa6acC5b+f7ngSotEMLGF231kGRfaPUAO779y9ffaccAAAGutAMAADRjKyJ/DL'
                    '34pTR8SBuC15PFzeFw/cVS/zFrh1x7do2JVg+i1+phON0M93kDxi22elia0+V95t'
                    'o2wyX+ybdr8lYPVyT0AbCGR4kA2MKhEdC+wa2kZL4n6bv6Wz24zq9WjaCCVg8+41'
                    'Glb//yTWSQf5NOSFIAUBPK7wIAUumjKxfIUcn5BHMlqaSw+OD6UYn8VGv7Vjc4W2'
                    '/NrR4OPzp7TQKqI7iOW9xrl9fS5X1WoNXD4bc7tyoJl9fZzFwJACqonAAAAEraPJ'
                    'eVdFOiioKlp/p9prMUt6VKCj5IiGvet3/5+j9oxwAAAa60AwAAVG8rxxULIysXvH'
                    'qaO5ZWFYWYtUP38Oi62bhi1vIY/1JFIdP8l8ZO3rvrvAHjFt8DCaooiDhWUohYz7'
                    'mKwuUxVwtXAUBxJCcAAICSdiLy1k75/kJJCj5jfZIUrCVXzCYpLP/W7NxJ4kgwHl'
                    'X58l++/L12DAAQ4Eo7AABA9T5O/m6qJIXIeVLEEpWkELN2TJLCUlwz1zivkTtJIT'
                    'KWi0kKEXPOjSvR6kFE7LR6eD3HxmFVACiK5AQAAFDKRuSsaoJyNYJXE1d0YP6qio'
                    'KlJAXXiazFTZJCc7795et/pR0DAAS40g4AsOynf/pJOwTAumtZahMUmVhAkkLgdW'
                    'frZamiMF7jPNThyf+YeC4WLzh7TXyrM3iMW0wGSZSkUKKKgnOSwi8/v1pYDQCKe6'
                    'MdAAAAWI2diLyd/Ml4KOz6AbPzHOs8dyfSHX3QSzp3+vGvfuy7Lz5fKCTb84kf+u'
                    'xLiT2P/XINZnz956+8ngBqdKUdAACgar3TqPHvyRFJ2oMM0kmXZK7oOYbla1/iTb'
                    'V2guvGw+bJuGLW8hw/DM97k2P+mbGvXhPXeQPGLe61w3vI6X32nKDQdTMDXeK/MO'
                    'bkPpbi4fMwAIOonAAAAErYyHnVhCkmnowv1OohYZWGels9FK6k4DOWKgrN+Pbv3x'
                    '60YwAAT/NPuwIAcNn34vu/I5GVC149zR1Lq4pCzNprb/UQ2ZbhYqsHzxYOruMW3w'
                    'MJqiiIlKmk4DAHf68EYA6VEwDYwmEQ0KqdDBeqJpxTrkbwamDn8cFcrRrBxBBr1Q'
                    'gujp/YhFwVIHLfJ0z69pevb371W3KyAVRnKyL3yjEAAOqzD77S5anx2cufn+Yexs'
                    '/S4XMlqaKwcP3Fp+hj1g659uwap0oKCdaZH3r4HmT2yf+p+SOrLkzeu+u8PuOe17'
                    '5YSWMmRu8x8lyVYmkvA6s2vKqi4BAPAGjjWzoAAFDCje5T+hfGuw7sPEobGrjP7v'
                    'wXFqoRzI5XqKJAJYXV+Prnr/9JOwYACHClHQAAoDo3IvIuaobIKgqHKYaXw+3oRO'
                    '/YOZwKEVx4ij5m7dAqCmeVFHyvcV7HdajLk/8x8VwsXpC5isLR2osVK1zXXRpSoI'
                    'rCTCWF7XKEAFAOlRMAAEBuN3L8BUmJp/SzzN0dqii4jleuAPHqx1VUI5j4obUKEF'
                    'RRqM63v3z9nXYMABDgSkR+UI4BsIm/jwGX9MmSqhM8gf3yVHqKp7ljqjq4Pt1+6S'
                    'n60LVD7/vsyf7Dvzo8de+zluf4YXjemxzz+1ZRcJk3YNzsXieuoiCyUJUiYr1XlR'
                    'QOP98KFbkAGELlBAAAkFs/+bvJnrq/MDbL+OeBVVQjmFi+mmoEEz/wjd0HVRSa9u'
                    '1fv2mHAAAhrrQDACz66Z9+0g4BsKoXkXdJqhUci5zv1dPcirG4XJ+tikJoJYWluG'
                    'aucV7D8ZpBnp/8T1AZwSeWyXv3qY7gWXFhdq8jKhu8GlagkoJPPABQEskJAAAgpx'
                    'uZKytprRx/SJKCz9zJ43AfX7TVQ5J9uTCRpbhJUqjGt3//9qAdAwB42mgHAACoxk'
                    'ZEdie/kyNJIepyY60eaklSOLvGKUkhwTrzQ/VaPQynm+GXpOA67ihJwWVc1BgRt7'
                    '10TbB49Vsve7Z1mAEAiqGtAwBbOOgBWtM7fYhSboEwOd5pbAOtHlznV2uvUUGrB5'
                    '/xUPHtz1/f/Oo/kJcNoCrvtQMAAFRjJyJvJ38S2pLg0lwSN1/yVg8xczjszWyrh9'
                    'C1Q16Ts/UuxjVzjfM6Hq0eRBbaE4TGMzP21b27zuu7vktbDZf9cnmf5W/1sJ2PAA'
                    'DK4hs6AACQy42IvKupBUJYLIVaPSTcl1fTVVEBYuKHFe05dH3989f/pB0DAATYag'
                    'cAADBvK+dVE87lqKIQMV/SVg+xc8RUUYhZO6bVg0v7gZi1PMcHtXqIbMtwsdWDa4'
                    'UBz3GttHoAACtITgAAALn0J7+q4gA8ZnyhJAWfsT5JCtYO+meTFJZ/a3ZuH7R6aM'
                    'M3+X9qhwAAAbbaAQAAzOvlUtWEc1aTFFLEFTtHTJJCzNoxSQpLcc1c47yGb6uHBO'
                    '0bfGK5mKQQMefcuJJJCj5xxa4HAKWRnAAAAHK4EZF3r363mgPwmPFHSQo+cyePw3'
                    '38qyoKll4j14msxU2Sgilf/n8//9+1YwCAAFfaAQCW/PT4k3YIgDVbEfngfVWOJI'
                    'Woy0lSCLr27JosVRTGa5yHOjz5HxPPxbyAs9fEtzqD57jZvU6UNOBUReEsrpkxVw'
                    '6jAKCYN9oBAMAJDnOANgxyM/vz8c+6y4con7Gh430+DDuP70Q6j1KVJe5zZvyrH/'
                    'vsS7Y9lIW4J35o7b3lMx65fBKRexH5UUS+0w0FALxstAMALHE6eANWpJNuHzXBIO'
                    'm+hxv/eEbMN8ggnXRJ5oqew2FvXuJNuXbIa3K03vjfycm4Llzju4bT8OF5b3LMPz'
                    'P21WviOm/AuMW9dnktXd5nzwkKXTczcDn+zUIkAFAUlRMAAEBq1yLy3mlkRS0Qws'
                    'YXavWQcF/qbfVQuJKCDxLvtPV/93/9jyKHBAUAqMm1dgAAALOuBxl+H520Y7XVwz'
                    'hXinhirg2tohCzdkyrB5f2A+fXBK6xPDSw1UNkW4aLrR48Wzi4jivZ6mGxkgJtHA'
                    'BUgsoJAAAgtT77k/RWnnR3Hv88MHclhYRxnwypphrBxCbU+t5CKp9E5P75y6I7Ef'
                    'm9ajQAACAcf48CftFJP/6r89Pyc1JUKzifL7KKgohIN4yfpSNjiZnD4fqLr0FsFY'
                    'WQa4/23um9EbKOxzVjy47ZJ/+n5o+sujB5767z+ox7XvtiJY2ZGL3HyHNViqW9TF'
                    'kVBQAyoHICAABI6VrGqgk5n6RXfUr/wnifiSuqANGd/8J8NQKFKgo5xyNWf/Tvd0'
                    'oxAEAot0pUwAr89E8/aYcAWHItg7x//XC449PycwxVUThMMbwcbkfHFjtHTCWFmL'
                    'UjqyiMcfle47yO61CXJ/9j4rlYvODsNUldReFo7cU/g4kqKVBFAUDtqJwAAABS6l'
                    '/9Ts4nzEs8pZ9l7i5/FYWE41/9uIpqBBM/rPW9hVCfZGzlcNjrR7VIAAAAgHQ+vv'
                    'zbxNPWs09wu8hRRSFyvpd7ShFb7FPlDtdffA1iqiFEXudcYcN3Lc/xw/C8Nznmnx'
                    'n76jVxnTdg3OJeu7wHXd5nzwkKs5UU+N4BgEFUTgAAAKlcy9wTfjmfpE/21P2FsV'
                    'nGH1VRsPRUv+t01uK2VEnBZyxVFHLqz359qxADAMS61g4AAGDKjYi8e/W7E0/KJ6'
                    'miYKiSwsk91VxFYbw+07pL6zm/N0KqKDheM8jzk/++lRF8KhlMFrCYuPfUlRSOxi'
                    '2+BxJUURBxqqSwXZ4FAMqhcgIAWzikAeo1TFRNmJLrSXrl6gLh458Hdh4fzH2fuk'
                    '+85ydDrL1GF8dO/LCKChAI9EvVhFMPMvVlLgAAAFCHfvanZ09bOz8tvzSnSLrv7C'
                    'IrF7zc0zB+lo6MJWYOh+svvgYxa4dce3aN03sjwTrzQw/fg8w++T81f2TVhcl7d5'
                    '3XZ9zz2rPVTFz2y3FPh2G4tJd8BgZgCpUTAABAClvpPPoi53ySXvUp/QvjXQd2Hq'
                    'UNDdxnd/4L89UIFKooUElBSz/+y9/+d39//Pv3pQMBgEhX2gEAAMzYicsh48TT1t'
                    'FVFMZ5U0lQleHlqfQUFR5SVFJYHHLhKfqYtUOrKJxVUvC9xnkd16HLT/7HxXOxeE'
                    'HmKgpHay9WrHBdd2mI714CgAKSEwAAQAq9iNg6vM15AO473isWg60eZsa/+rGVFg'
                    'i1JykgxqWqCSIid+XCAIAkNtoBANp+evxJOwTAgo0sVU04t4JWD4cpErV6iJ3DtQ'
                    'T/XJn/jOvOXefV6iFXKwYRWj2UbfUAAGpITgAAALG2IvLh5HcsHd5aSZbwGv88sK'
                    'JkjJPlrR30zyYpRMxvJqEFZ/qZnz0WigEAUtlqBwAAMGEnIm+DrpyootBakoK5Kg'
                    'oL12erohCapLAU18w1zms4XjPIEJakEBnLxSSFiDnnxpGkAGDN3mgHAACnOIkB6j'
                    'P0F380/pF2/RzUeY51nTskDhPjnwd2Hh/Mc+2h4/iT5a29RpNjL0zkuo9m3it4Nl'
                    'c1QUTkVkT+WCQSAEhjqx0AAEDdRg7JCeHGzxPd8W8Nz78V8V3cxLxRhri5Xu5pGD'
                    '9LR8YSM4fD9Rdfg5i1Q649u2aQYfl9EbqO4/gx2aTrnC/wi+dCLK9eE595Xe/vaN'
                    'zsXrusnfrPIAAUQOUEAAAQYyvnVROmmKhGkHnucbyPNbV6sFABovZWD3zZ4KI//s'
                    'Xf/nd/f/7zx1KBAAAAAInsJbRqwrmJp62jqyiM86aSoPrBSasHC5UUFodEPEEfse'
                    '7cepZaPXg9+e8z/8xYM60eRNznA4BKUDkBgC0cvAC16WV8ImHpk5ClJ8ytVHTwGn'
                    '9URcF1frVqBBem891HlT2f+KGV91bI+HVZqpogInLH/gGozHvtAABNPz39pB0CoG'
                    '0rLg8E+Jp4Uv7wS2NVFCLmO7mnyIoML/FoVFGIWTt0D4+uc35vhFQu8Bg/DM8VBn'
                    'LMf2Hs5L27zhswbvE9sDQfVRQAVILkBAAAEGorIh9+OYw1lKRg/gA8ZnyhJIWEcZ'
                    '8MyX3Qn2z8xCbU+t5aj/7V70zv0ZOkevIMAADkxd93gD7rQePZoXfTSQq0eghLUv'
                    'BNYPFNpPCI7aXVg2+SQmRCw8UkhYjEh7lxJCkAaB1tHQAAQKj+5FcvZecdP/34fk'
                    'jKVQLfWjl+5/HPA33nTh6H+/ju/BeWXiPXiazFzZcNI5eqCaO7fGEAQBYb7QAAAC'
                    'quReSDV5n6EBPzO5f095w3er6oy4eXw+3ouGLncLj+4msQs3bIdWfrZWn1MF7jPD'
                    'Rjq4eZWF69Jj7zBoxbbPWwNOcvY350XB0AiiA5AQAAhNiIyPeTP3lJUHA4NbV0eK'
                    't2AB47vrN3nzPjX/3YxB7KQtwkKVSg9xj7mCkGAMjlSjsAAICK/uRXSkkKSeZNJc'
                    'EevNyTlSSFxSEXT8qTJBuEXOecvBKSFOCTczAM+eafGfvq3l3nDRi3uNdu8z06jA'
                    'KAYmjrAMAWDleAOgyyk7my6C9l5x3rz6uW708wt3rcY3nKoy9Z1GI5Gj8z9mS63K'
                    '9PsvETP7Ty3goZ3w6fqgkih8oJv88SCQAAAJDGtYi8n/yJb9l8X2cl4Ztu9XCooR'
                    '8fV8wcDveyWOY/ZO3QPXRtP3B+jc86HrEFt3pwnP/S2IutHlzmDRgX3eoBAAyhcg'
                    'IAAPC1EZGd08iXJ7ozVlLwUVELhLDxzwN9n+r3kTjukyHVVCOY+EGt76029FO/+b'
                    'f/l78vHAYAZHOlHQAAoLj97E9zV1EY1zj5Ja0eFmOJraKwcH22Vg+hlRSW4opdx+'
                    'Ma71YP4/yRsUzeu091Bs+1o1s9AIABJCcAAABfO+nkbdiBqeNFVg5vzSQdHI33mb'
                    'ii++zOf5Ezdh+zCQrd4m/NzmvpvVUv36oJIiK36cMAgKw22gEAGn56/Ek7BEDLjY'
                    'h85zQy92HkxPzJkhRSSbAHJCkEXne2XpZWD+M1rkMHzyQF33hmWj0Mp5uRttXD0d'
                    'pOrR5IUgBgGMkJAADAx0aOqyYEHfRmrKJQc5JClrkDqigo7vmrH5vYw6XxFSQptK'
                    '3XDgAAAABIrPe+okQVhYkkhdRzas83/HL6myZJIfP1F18DjSoKrgfnoWt5jh+GId'
                    '/8M2MnqyikTFLw2WsSFAAY9UY7AAAAUJWdiLw9+Z3x8NP1Q8/LeMcLg+f3GJ9jbM'
                    'jckmP888Du6EsWtViOxs+MPZnOZ+4ScV8cP3FTuWPPdZ/1mK+acPl+75JHAgB5XW'
                    'sHAAAoZici74KuHP/+mzNBeTidfzwY7WIWTR135Hwn93R2v6Vjcbn+4msQs3botU'
                    'f75fze8N1jj9jGahidT2VJn3u/MHby3l3nDRg3u9eHH90vzAYARVE5AQAAuNrIcd'
                    'WEc8FPgDteZKUagaWKDl7jnweqtEC4HI7zdNZeI5+JLLxvQ8bb1wde95gwBgAAkM'
                    'FPT7R0wCptJEVlsNwl3S9UUTBZSSHqclo9BF17do3TeyPBOvNDPVs9jPNHxjJ57z'
                    '7VGTzXntnne8fZAKAIkhMAAICrGzmvmjAl6KDX4yIrh7dmkg6OxrsOrOg+X/04d+'
                    'w+Y32SFCra80rMV01Y9pQoDgAoYasdAACgiJ24fOZ2pZSkkGTeVBLsQfJWD7FJCo'
                    'tDLvYbiEtSCLnmLEnB9xrndVyHDp5JCr7xXNz6iQQFzxYOrmsnSRQCgMxo6wDAlv'
                    'oPS4CW7UQkc9l5x/rzquX7E8yt3hrieaC1Vg8z41/92Hdf1Fo9nP0w93vLd3y931'
                    'n0cz/83X/7d0tfyNyJyPuE8QBATmHlvQEANdnIXKXCGLGtCVzml1/WoNWDYzyhc8'
                    'S0eohZO6bVw/N1Xq0efNbyHD8Mg6y61QMAKCM5AQAAuLiR8YvxIge9hpIUzB+Ax4'
                    'wvlKSQMBnjZHlrB/0Xx0/cVK73Vsjc4jm/vtiqCQAAwLq6/m4CxOukl5RVE86lPu'
                    'y/tMbJuWvDSQrjdxYxccXeW0ySQszaMUkKvgksvokUHrGNLTu8kxQiExouJilEJD'
                    '7MjXte785hdgAohrYOAADARX/yq2Jl5x0vUivfnyAOE+OfB1rYQ8fx3fkvLL1Grh'
                    'NZi7ueByr6BHPcJ5gDAEq60g4AAJDNVgb5Q5GVYtsKBMyfpMx86rijwxleDrej44'
                    'qdw+H6i69BzNoh155dY6LVg+i1ehhON8N9Xv9xj45XAEARJCcAAIAlN3KpnHCRg1'
                    '6Pi6wc3qodgMeO7+zd58z4Vz/OHbvPWJIUcklVNSHFHABQ0kY7AABANr2I5E8cOK'
                    'aUpJBk3lQS7MHLPVlJUlgccvGkPC5JIeSal61zTF4JSQrwyTkYhnzzz4x9de+u86'
                    'YeBwAF0dYBgC22D0SAdRocnlIOKYFfc6sH1/FF9iX1+LE8ZeZWD77jXVs9OIz3mX'
                    't+oZjxEz+08t4KGV9OvzTgd//t3xUIAwCK22gHAJTy8+PP2iEAJV2JyIeT3/EtZR'
                    '8j91pnZeibbvVwqKEfH1fMHA73MvsahK4duoev2w8svzd81/IYH9zqwTWeC2Mvtn'
                    'pwmddt3J1DdABQDMkJAABgzo1cqpowpchBr6EkBfMH4DHjCyUpJIz7ZEjug/5k4y'
                    'c2odb3Vn5uVRPc4r0VkT/GBAMAhV2JyA/KMQAA0ttP/m7qA/g5JdY6O/RuOklh/M'
                    '4iJq7Ye4tJUohZOyZJwTeBxTeRokSSQmRCw8UkhYjEh2ePjpEBQBG0dQAAAHN6c2'
                    'XkX8Y7XuT7oThX7Bb30WfiLHNLlvvszn9h6TVyncha3KWe3JrXawcAAAAAJHQtIu'
                    '9nR5QsyZ57rYn5nUv6e84bPV/U5cPL4XZ0XLFzOFx/8TWIWTvkurP1srR6GK9xHj'
                    'oc2j34zO0Tz4Wxr14Tn3ntPFwAABdROQEAAFxyLcdVE8w80X803lIVBdfx1io6OM'
                    '/d5a+ikHD8qx/nqkYQMrdcGj/xw1rfW+m5VU1w95hwLgAoYasdAFBKkr70QAU66X'
                    'rnwaHl9kPkrqQwMf8gQ1wVhXFeI1UUDlM831OK/UxRSWGxEMGF1yCmGkLkdRZaPY'
                    'iIDMPgX0XBdf6Zsa9eE9d5T8c9OEQBAEWRnADAFBsPZgIQERkuPaWc+0Az6KB3JU'
                    'kK6nE/D7SWpDAz9mQ6awf9F8crJCnkus90+sTz3SWeDwBy22oHAJTw09NP2iEApd'
                    'zIUtWEc7mTBqbWy7nW2f003ephTFKIjStmDod7mX0NQteOSVLwfW/4xugRW3CrB8'
                    'f5L4292OrBZd7DuHuH1QGgKNo6AACAKdfd0hcllsrIv4x3vDBZOf4E403uo+NAn/'
                    'lz7+HC+JMhvnGr7fnED2p9b8VJXTUBAAAA0NYHtzRI3cZAe63h/Je0eliMJWYOh+'
                    'uztXrwvfbsGqf3RoJ15od6tnoY54+MZfLeKTQEoFJUTgBgC6UTACv6Q0b4wcXPO5'
                    'YqEZyMd3wU3EQ1gsxzh453GntUSaGS+zy5NSvVCGbHK1RRyDk+TO868Hf/57/zmf'
                    'dHEfnONxgAUOL3dC0AwLIbOWqhGFwxoGQlhdxrTcyfrJKCkSoKhyme72ms/hgTW2'
                    'w8MZUUYtYOeU0mqmwkb/UwXuM4fkxQ6DrXCzzjuRDLq9dked57xxUBoBgqJwAAgH'
                    'PXIvL++Mnoxc9OJZ4u95G7ikKu8Zb20WvugCoKinv+6scm9nBp/MQPre15HjmrJj'
                    'xmmhcAAAC4ZCMi+6kfBFcLKPn0dIkqChOVFFLPqT3fyz2lqqSQ+fqLr0HJKgpn1z'
                    'lX2PBdy3P8MDg+rBEy/8zYySoK02PvHVcDgGJITgAAAOf6k189H1I6nVWaOSw/Hm'
                    '8oSSHH2JC5s4z3eaNExOJjYfzJ8tYO+meTFCLmt/Rn1E2ffEYAqNdGOwAAQLSdiL'
                    'y99ENaPRytcfJLo60eIuY7uSdaPfhftxTXzDXOa/i2evBNUoiMhVYPAGpFWwcAAH'
                    'DsWi6VDe5ExKXVw9FYJ04TphjvGFTI/Gtp9eA0fiy34fHBXPn9crK8tdfItdXD7H'
                    'ifud2XSzb+Mv+qCX5r3gpl0gHU5UoO/+0CmvTTP/+kHQKQ20YOyQmLaPUwPX+yVg'
                    '9n80aJbB1Bq4fAaydaPUzGlXid+aGH70GMtXq4d5wdAIohOQGALSU+PAG4bFj4ou'
                    'To0HHx/NHMYfnR+MHjIiuHtyb30XFg5/EUiPJ9vvpx7tcoSdwTP6z5vfVa7zP4d/'
                    '/N3wUvBAAAABSwk5mqCVMGGcIO4leQpBCVoDDOmzJBQeLme7mnFPuZIklh4dqLr0'
                    'FskoLvdRNJCovvjdAkBdecg+E5WSBHksLM2Ff3fhh77xYEAJRDWwcAADDaisjvnU'
                    'YelW9f/OxUogS+99yOi5SI3UI5ft/xzrE8D8x9nwn35dV02d+LKcZP/LCiPb/gT5'
                    'L/S5Tc8wNAalfaAQAAgm1F5I8hF0a1NChZ4j33Wmel7Wn14BhPzLUL18++BqFrh+'
                    '7h0XVerR581vIcH9TqwXX8hbFJ/lwAQGZUTgAAAKM+9MlopwfkfZ4W9x0f/ES344'
                    'VmqhEEjPWNI8t4nzdKRCwJ4z4ZUk01golNyPXeCplbvObfe0QS6r7AGgCQ0kY7AC'
                    'ArzlLQtl5Eop+sP0zhOUlLVRTGNc6qKByWjNpceZ4kjcj5aPUQce3R+8P5veFbsc'
                    'EjtpdWD+ODG67z+4ydiOXo3u8cZwKAYqicAAAARA5PcXx4+VXgU/eLD1RbqkRwMt'
                    '7xIhPVCDzHmhp/VEnBZ+7kcbiPf1VFwdJr5DqRtbiXx38WeqoDALAqPz39pB0CkN'
                    'NWxs/bCZ7UD34yOnWVAM21JuY3W0kh6vLh5XA7Oq7YOWIqKcSsHXLtRJWNbOs4Dx'
                    '1e2j04z+1bdWHao8csAFAEyQkAAEBkqrd7xKFjlUkKrhdZil3tADx2fGfvPmfGv/'
                    'qxb+w+ksVddZJC7zGTiIj87r/5O99LRETuQi4CAEXX2gEAAIJ8fPU7CQ7Ao1o9NJ'
                    '6kkGTeVBIlpKSaK0mSwuKQmVYPMUkKIdesvNUDbR4AWERyAgAA2Mpx1YRzkUkKrm'
                    'N953Ye7z33SpIUcsThNf6oioKlA3Of6SzFbSlJwcfr8SWrJjwWWgcAAADrdS0i7y'
                    'd/ollFYVy/lNxrTTwpb7KKQsR8J/eUIi6tKgoxa4fuobEkhZcqCvmTFD57rAAAxb'
                    'zRDgAATvgeagCINzg+pTz++XT9MNTJc189h8s6j3l9x4fELSIyOF4YPL/H+Fxjfe'
                    'PIMn7MZPH4kiX3Hi7MfTLEJxbVPZ/YBJvvrd7xqlSeRORt4TUBINRWOwAAgLd+cc'
                    'T49+aI78SO+sv7Xhi9tqm1htP5g/flfE6RdHGfxeh/+fM9jd9ZxMQVe28O1198DW'
                    'LWDr32aO+d3xu+r5dHbGPLjq7zWMAnHgomADCKygkAAKzbVjr5UOKp+8UHsC1VIj'
                    'gZ73hR/BPjDrEkHltqvM/EFVWAeFVFwW41gssL23pvlayaMLorvB4AxHinHQCQw0'
                    '9PP2mHAOTyvVyqmjBFs5LCClo9JKmkkErK19pKq4fQSgqKrR7GuHyvcV7HdejwXE'
                    'nBZ2634ffukwJAOVROAABg3XYv/1boyejFZcw80X803lIVBdfx1io6OM/d5a+ikH'
                    'D8qx/brEaw/EMb760++okdAGgcPYMBoCr7oKsin6w/TDGEVQtIsLbXWpJxvYn5g/'
                    'dlZs4oiapmdNKliS1FJYXFQgQXXoOYagiR13lVUfBZy3P8MDzvTbr57x1nAoCiSE'
                    '4AAGC9NiJyc/I7hQ56nc6ecx6W+45/iaXSJIXs+5J6vM8bJXcsR+Nnxp5MZ+Og32'
                    'G8QpLC5bFRVRMiDuvuxedpNgDQdyVUfQGAGtxITMWbRIfWhyk8J8mdNDC1Xs61zu'
                    '7HbKuHiPlO7inFfsbM4XAvs69B6NoxSQq+7w3fGD1ie2n1kCZJ4dFxBgAoirYOAA'
                    'Cs104u9VrPX77d/bLccQSNd7wocF+Sjy+2L6nHPw+0sIdH4TgP8dkX1T2f+EGuPb'
                    '8cR+8xy4nffve3oZeK8CQJgPpstAMAACzaSMTfb0+kLP+vsLaptYbzXyZq9ZAy7l'
                    'SvdYq4YudwuD5bqwffa8+ucXpvJFhnfqhnq4dx/lN3fhMAQBkkJwAAsE4bOW7pcE'
                    'mhg97Fc1Yzh+XH4z0ushK7xX10Hdh5JCkYuM/u/Bc5Y/cxm6DQLf7W7LzhexhVNQ'
                    'EAVmajHQAAYNFOYqomTCFJIdv8SVompU5QaC1JYXFIpiSFkGvOkhR8r3Fex3Xo4J'
                    'mkcBrPo/uFAFAObR0A2FKqZByAnQwXqiacCyndHji+W7qsRCzeLRAcFym4j1nmNt'
                    'EaohNzrR5mxr/6se++rKXVQ6qnysLcisgfFdcHAF9XIvKDcgxAMj//88/aIQCpbc'
                    'TlQYBQCUr2D/Lc115hbTNrraDVw2GK59c6RWyZWz0chl14b2q0eni+zqvVg89anu'
                    'OH4XlvfObvqJwAwCYqJwAAsD4bEdlZeLp8arzTZTmfLg++T8cLzVQjKBBHlvE+b5'
                    'SIWHw4VFHoJn/hMK/ank/8wDd2N1RNAAAAQEt2cql9YipUUUi7xskvjbZ6iJjv5J'
                    '4sVFGopdXDeN1SXDPXOK/h2+rBbfzDy9yl/swCgCOSEwAAWJ+dHH9ZYumw/Gi8c5'
                    'KCz7zFkhQyze8dS6Y4TIw/SlLwmTt5HO7ju/NfWHqNfCZKG3fvONuk3/6f/jbmch'
                    'HKXAKoz1Y7AADARVspWZWLJIVs85tNUoi63Firh1qSFCZaPSy+NxKsMz/UqdXDvW'
                    'cEAFAMbR0AGFOqPhywZsNu8rdDyrEXavUwe2nE3NnGu7Z6eBmfMRbX8Sb30XFg7a'
                    '0eXOdX+zM68cM0cVuomnCnvD4A+NpqBwAAuKhXWTVl+X+Ftc2sNTF/8L6cz5sqZo'
                    'utHmLmcNib2VYPoWuHvCYTrUCSt3oYr3EcPyYodN3kBbceqwJAUVROAABgXW5Eur'
                    'ezn3RMPBX/erxTFQUrFSBOqig4XGimGkHg3D5yV1EwX43gwnRVVICY+GHcnvcekQ'
                    'EAgMb8/M8/a4cApLQVkQ+qEWhVUUiwtqm1Qp6U95wzmqVWD7FzxFRRiFk7ptXDy9'
                    'Z5tHrwWctz/IVWD/ceKwJAUVROAGALhROAvIbjw8CZx6qNPkXvdJnP0+K+44Pv0/'
                    'FCM9UIAsb6xpFl/JjJkrmSQsK4T4ZUU+liYhP831tpqiak+YLvRxH5LslMAJDfe+'
                    '0AAACT9toBiEiyJ+sPU3hO0lIVhXGNsyoKhyWjNleeJ0kjcr6Xexq/s9CuorBw/c'
                    'XXILaKQsi1R+8P5/eGb8UGj9jGlh3d+OAGVQIBGEZyAgAA63EjnbwTEfea8tYOy5'
                    '/nXlzGzGH5+XjHG7aSYGF2Hx0HdpNPD1y+RDHuk+WtvUYXExTOJvKLu3eMoIRH7Q'
                    'AAAABQtWsR+b12ECdIUsg2v9kkhRSvNUkKUckDJlo9jEkKXXfnsQIAFEVyAgAA69'
                    'G//NurQ8QMSQoFDnoXlzFzWH403lIVBdfxlpJUvMZ3+asoJBw/+cdSfQ/FoYrC2Q'
                    '+X9yVN1QQAWK+NkFiFFqSpgARY0ItImcN4X5GH1ocpHA5cL60t8eubWOtCkkJUgs'
                    'I4r5EqCocpnu8pxX6mSFJYPOe/8BrEJimEVFF4Xs+rioJ4rOU3/vMw8D+yAOz6lX'
                    'YAAACgiBuR56oJx159qOmmfnNm/IyFqVKNd7osZG4fQffpGFShfcw2d444vMb7vF'
                    'Fyx3I03nU6a3FfHD/xw8vje49VL/rt//FvU0wjQqIEgPpcaQcAAHhxLWPLnUFsJt'
                    '0kiGt4/r/g9UvJvdbZXkbty4U5o0XOd3JPKeKKmcPhXmZfg9C1Q/fw6Drn94bvOm'
                    '6x3XrOCgBFkZwAAMA69Bd/MnmAuJCgYOLQ+Wi862XW4s6dpOCjuqQD3/GFkhR8xj'
                    'abpDD7W5+FL0oAAADQjo+vfockhSxrm1prOP+l0SSFqMuHlxYB0XHFzhGTpBCzdk'
                    'ySwlJcsevMX3PrORsAFEVyAgAA7buRqaoJ514dODpUUVB8uvzS3IvLmDksPx/veJ'
                    'GV2C3uo8/EFSVj+PyxjI7FR1gVhY+eq5Rwrx0AAHi60g4AiPXzP/+sHQKQwo3Mfd'
                    'a2mKAgQpJCxvmTJSmkkvK1XnuSQsg1Z0kKvtc4r3PqSUhOAGDcG+0AAOCE78EIAB'
                    'c7EYnoL//qN16PV+l1Pz9+cZmIuZ3He++L4yIlYncdb2kfvebuRDqPUpXKez75x1'
                    'J9D5fGv/rhg5CcAAApbLQDAACIiEu7Mr8+8WUNEh3XIIN0IZMkWNtrLcm43sT8wf'
                    'syM2eUBPO93FOK2GJff4frL74GofEnuG5MUFh8b/iudTr+B4/oAEAFyQkAALTtWk'
                    'S+E5EEh8IzE1g6LD8a73T2bOaw/Hi8oSSFrMkYHmMlx3ifN0ruWI7Gz4w9mc5aEs'
                    'nF8S8/7FN9ufbb/8PfppkIAAAACNOLS4XCkdUkhUSH1ocpPCcpvSe5EyLO5g/el/'
                    'M5RdLFHTnfyT2lSDCIiMXl+tnXIDT+mCSFziGuC9d4xPaDZ2QAUBxtHQAAaFv/6n'
                    'eiS87PTJChpH30eNfLrMXdeQQVuC/J57b4+juNfx6Yaw99xzvEfTLE2ms0zWrVBB'
                    'GRO+0AAMDTtXYAQAxaOqABGxkrFPoq2dbAR8ry/wprm1lrYv5krR5Sxp3qtU4RV+'
                    'wcDtdna/UQ0oJhOP6lw3vDb50nITkBQAWonAAAQLuuReT95E+in4pemCDnE/q+44'
                    '9iWQzLZAWIsWyiw0UmqhFknjt0vNPYMUFhqOY+T24t92sUF3dv7zGxF48mvyAGAA'
                    'CAVTsReRs1Q+6n+EOtpZJC7rUm5o9u9TDOa6SKwmGKxK0eYuZw2JvkrR4c111az+'
                    'm94RbjD56RAIAKkhMA2GLxgxlQq8Gh/2WJJAVLB9TP4xfDMnNYfjzecREDB+ZRcx'
                    'dIUnEabK3Vw8z4yT+W5ZIOXManr5qQPpngSWK/YAaAcrbaAQDAim0ltGrCudJtDX'
                    'wkOAQPPowvmbiRe62JQ+jDL6MyAk7mjBY5X9JWD2M8MQkKMn+9uVYPz9d5tXq4vN'
                    'ZHzwgAQAVtHQAAaNO1dBeqJkyJLlE/U/u9RBn5gPFOl6UraZ9m7u7kXzLN7zE+11'
                    'gT433eKBGx+FgYf7J87rj9xvcv16T6J727LLMCQB7vtAMAgBXrJXVSa8m2Bj4SxE'
                    'Wrh6M1Tn5ptNVDxHy0eoi4djj+V8f3xushDyJyG7A6ABRHcgIAAG3qRUThkHdmAk'
                    'uH5UfjnZMUfOYtlqSQaX7vWDLFYWL8UZKCz9zJ43Af353/Qvc1ehCe3gAAAEAbti'
                    'LyIdvsFhMUREhSyDi/2SSFqMtJUgi69uwa5wSFX4Z99FwRANSQnAAAQHuuRY6qJh'
                    'Q/5F2YwMph+dn4xUvNHJYfjfe5yErsRpNUnAZau0+fP2a5Y7+s95jJyW//979LPa'
                    'WIyH2OSQEgoyvtAABghfbZV7BaRUEkWZKC1tpm1rqQpJBk3lRSvtZWkhQWh1wYFJ'
                    'ukEHLNy9Z5VFEY5OPLtVP/AIAhJCcAANCem8nfLX4o7HB6mjOWiCQF9Vi853ZcxF'
                    'KChdEkFaeB1pIUfKYru+c1VU241w4AADxttAMAQvz855+1QwBCXYvI74utZvlAUa'
                    'uKQoK1Ta018aS8ySoKKVo9jHOliCfm2tAqCjFrx7R6cE9S+JPwmRZARUhOAACgLV'
                    'tZKjNZ/FA4cRWFAge9Tpdle0LfNYCp8YaSFHKNNTG+UJKCz1ifJIVyyRUfPa7U9q'
                    'gdAAB42mgHAAAr06usajVJgVYPadc4+WXDSQpWqijU0uphvG4prhJVXQAgoTfaAQ'
                    'DACd/DPgCnBo8vTDpx/2A0/tkMHr8wQfT8DuMD5l5cpkTcQeMdb9hnX3zH+8Rudh'
                    '8dB3ZD9vdiqvEny+d9jZ4k0xckSUqevnaXY1IAyOhKRH5QjgEA1uJajlsnahjE5n'
                    'dm41/NI2Ib/37f+U6SYG0za03MH7wvC/NGiXwfvtzTcPRkSEwsMXM4XH/xNYhZO2'
                    'QPz9YbZDiO6UFEbgMiAQA1VE4AAKAdW+nkg40nyy+NX5jAZDUCxyoK1vbdUhWFMk'
                    '/pu4334Ty+QBWFhOMn/1j6zO1mL3VVI3jUDgAAAABm7bUDEBG7VRREksRVTauHnO'
                    'tNzJ8kOdtQFYXDFEetHixUUlgcMtPqIbJlQ+h1R1UU9gEzAYAqKicAANCO/uXfzD'
                    'xZfjR+OP+NCxNYjF0OD8cvXpazooPv+JMqCg5BWdr3QpUx0o73eaPkjuVo/EIVhZ'
                    'fp0r4+2aomZHSnHQAAeNpqBwD4+vLnL9ohACFuROQ77SBOlKwY4GMtVRTG9XKuNf'
                    'Gk/OGXxqooRMx3ck8p9jNmjpgqCjFrh+7hL+s9DTJ8DFgZAFSRnAAAQBu2IvLh1e'
                    '8qH34uzz0zgaXD8nG8S6uHo7HZ4gganzFJIWeChbl9dBzom6SQPUnFcUiaJIW95K'
                    'xEkO9JpScReZttdgBIa6sdAACsRK8dwEUkKWRZ29RaZ4feZpMUUrzWa2/14Hvt4Z'
                    'ofpKMKIID60NYBAIA29LM/zVbOXhKUnPetQZ8hnoC5F5dRLt1/ebzjRVZit7iPPh'
                    'NXdJ8+fyxn5s5aNeE//Ne/zTW1CNUTAAAAcGonIu+0g1hkudVDgvL/QW0NSrbAUG'
                    'r1EN3uwWCrh0EGO60eFq6/+BrErO1/3f5lvaV/AMAQkhMAAKjfRqaqJpwzcPg5P9'
                    '4hScFHodgXLzNzWH483nERS+8ZS/voNXdn7z59coH893AvOasm5PWoHQAAeHivHQ'
                    'Dg48tfaOmA6mzEctWEc5YPIBPEFXwQX3JPcq91IUkh9Zza873cU6okhczXX3wNYh'
                    'IU3K79LCTYA6gUyQkAANRv5zXa0oHzON51Aouxu549mzksPx5vKEkhx9iQubOM93'
                    'mj5I7laLzrdO5zP0kn+5fxOf7J6y77CgAAAKjFTmps+WU1SYEqCmnXOPlloioKhp'
                    'IUTu5pzVUU5q/9GDgzAKgjOQEAgLptxDc5YVTkCf2YWHwe7w6ZP/F418usxf2SpJ'
                    'Bpfu9YMsVhYvxRkoLP3D4Sx/2qisL8+L3UXX3gUTsAAAAAmLCR0M/ZVlhMUBAhSS'
                    'Hj/GaTFKIup9XDhWufhOQEABV7ox0AAACIspPYpzk6cf+QNB5MFhu/MEHI/D4fCA'
                    'P3ZjGs4vvoMH7wuMjKe8bkPjoO7DyeAlG+T8c/lk9ySE7I5j/8736bc3oRKicAqM'
                    '+1iNwqxwC4sXpQCkzbi8jbApW78hr/3Fm8jwSxjYfAne8kJfcl91oT8w8y+O/J1L'
                    'ypYk70WnfSpdnP2Dkc9ubiaxCz9um6+4AZAMAMKicAAFCvjaR6msPMk+WXxi9MYD'
                    'R2pyoKBSo6+M3tuIil94z5KiAzAyuqGDH5x/IXP0j9lQcetQMAAACAuq2IfBARuy'
                    '0SfFm+jwRxBVcLKLknJVo9DMe/NFpFwUqrh9g5YqooxKz9y7ofA2cAABNITgAAoF'
                    '47Sd0D09Jh+eR4n5NTh7kLjHe6rEjSge94Q0kKucaaGF8oScHHwviT5X/5Re+5ik'
                    'V32gEAgKeNdgAA0KD+1e9YPdj3ZTVJgVYPadc4+WXDSQrrbfXwJxG5D7oSAIwgOQ'
                    'EAgDptJGcPTJOH5Y4TWDosPxrvnKTgM2+xJIVM83vHkikOE+OPkhR85k4eh/v4ox'
                    '9/kna+HHnSDgAAPFxpBwC4+PLnL9ohAK6uZayacM7qwX4Iq/dBkkK2+c0mKURdvt'
                    'okhf3LNT7/AIAhb7QDAAAAQXaSumrClE7U+twvj1+YIGT+ArEvXlp8Hx3GDx4XWX'
                    'nPFNkXx7Fe4zuRzqNUpfL75fnHvXfSTogyX6jcicj7IisBALAS0QdiQDn9ZJ/4Yy'
                    'l63ltg+T4SxDbIIIuvZaa1zaw1MX/wvpzPmyrmlK91iv2MncNhby6+Bm5rP4jIbU'
                    'BkAGAKlRMAAKjTTbGVzDxZfjTeZwJrsR9VUlCPxXtux0UsvWesVHTwGn9URcFSxY'
                    'hpLVVNEBF51A4AADxstQMAgIZci8h75yfMW3ka2fJ9aFVRSLC2qbXOXmOzVRRStH'
                    'oY50oRT8y1oVUUltfeB8UEAMaQnAAAQH1uRORd8VVNHpY7TmDpsHwc73qZb8Z+kf'
                    's0lKSQa6yJ8YWSFHzGvh7fe8wQ7G/+t78tsYzIoXICANRiqx0AADSkP/6FV5JCC6'
                    'wmKdDqIe0aJ79sOEmh3VYPHyMiAgAzSE4AAKA+verqJg/LHSewdljumqRg5rD8fL'
                    'zjRVbeMxb30Wdie8kYrVVNEGnvfgAAUPXzX37WDgFwcSMXWns5HeBaPdgPYfU+SF'
                    'LINr/ZJIWoy5tMUvgkVPoD0Ig32gEAAAAvN6JRNeHceJCp1Od+efzCBJ3H3L7jI2'
                    'JfXMbivg+OF1mKvci+5Ji7E+k8SlXmv8/ecWRN7rUDAAAPV9oBAEAj+qUBF/vEnw'
                    '468E3OtsbyfQwSHZfTa5lpba+1JON6E/MH78v5vKliTrAHL/eUYj9j53DYm4uvwW'
                    'Htj4ErA4A5VE4AAKAuvXYAJ8w/iT4zgcXYXSv456zo4Dv+pIqCw4WW9t1KRQev8T'
                    '5vlKyxtFg1QaTNewLQrrfaAQBAA27E8QEAr1YPVisQ+LB6H2upojCul3v+4fiXRq'
                    'sopGj1MM6VIp6Ya8OqKDyIyG3EygBgCskJAADU40YsVE2YYvKw3HECS4fl43jXy6'
                    'zF/ZKkkGl+H7oH9wXGHyUp+MztY3587zlbLe61AwAAAEAxGxHZ+17klaTQApIUsq'
                    'xtai1aPfjHUjZJYR+xGgCYQ3ICAAD16LUDWGTi0PbS+IUJrByWn8WyGJaZw/Lj8R'
                    '4XWYnd4j66Duw8khTSxP0nafsQ/0E7AADwcK0dAABUbCcRVWhWVUVBxO59kKSQbf'
                    '5kSQqppHyt60lSeBpk+DhI3P8BgCUkJwAAUIcbsVo14ZzFQ17fJIVisbiPd6qiYO'
                    'Kw/Hi84yKW3jOW9tFr7q7kfe49roz2N/+b35ZcTqTtxAsAAIr5+S8/a4cAzNnIIT'
                    'khCq0eDEkQV/AhbsOtHg6/ZbCKQoIkhVRzZb7+BxF5jFwBAEwhOQEAgDrcaAfgzd'
                    'KB8zjedQKLsbuePZs5LD8ebyhJIcfYkLmzjPd5owTH8lna73V5rx0AAAAAsuslom'
                    'rCOZIUjKCKQto1Tn5ptNVDxHwn92S3isLHiFkBwCSSEwAAsO9aRN5rBxGsyBP6Mb'
                    'EsVFEwceh8NN71MmtxvyQpZJrfO5ZMcZgYf5Sk4DO3m/4ljlL/lHevsioAhLnWDg'
                    'AAKrQVkT/kmNgrSaEFVu+DJIVs85tNUoi63GyrhzU8HABghd5oBwAAABb12gEk0Y'
                    'n7B7TxQLLY+IUJQub3+TAauDeLYRXfR4fxg8dFVt4zJvfRcWDn8RTIchw6X4yU/8'
                    'LzvviKAAAAKKnPvcAgg3RLmbbj33N1EnLTsXwfCWJzei0zrW1mrYn5g/flfN5UMa'
                    'd8rVPsZ+wch73pIyIAALOonAAAgG3XUnPVhHNmniy/NH5hAqOxO1VRKFDRwW9ux0'
                    'UsvWdy7ovv+JAqCvH32TvOkMzf/K9/W3pJEZITANRlox0AMOXnf/lZOwTgkisR+V'
                    'BiIVo9GKJVRSHB2qbWOnuNzVZRsNLqIW6OPwlVEwA0isoJAADY1msHkIWZJ8svjZ'
                    '+ZwOJT9OL4gHyhig5+4x0vtPSesVLRwWu8zxtlcu41lZO81w4AADxcaQcAAJXZl1'
                    '5wPOh0qqRgsfqAL6uVFBI9WX+YwnOSlqoojGucVVE4LBm1ufI8SRqR873c0/idRf'
                    'kqCjuzyT4AEInKCQAA2HUtLVVNmFLkCf3Q8Q5VFKxUIzgav7iMpUoEJ+MdLzJRjc'
                    'BzrKnxR5UUfOZuNVFq2r12AAAAAMjiWhQ/Yzs9ZW65+oAvq/eRYI+DKwaUfH1zrz'
                    'Uxv9lKClGXP99Tirjc5/gkfC4F0DAqJwAAYFevHUAxpp9EX5gg9xP6vnM/j1+81M'
                    'wT/UfjLVVRcB1vqaKD1/jOp4qCWtWE6C+2wj2IyDutxQHAw1Y7AACoSK8dgMhRX/'
                    'v5QQfWqg/4snwfCSpVOL2Wl9aW+PVNrDUxf/C+nM9rpIrCYYrne0qxn/NzPImR/1'
                    'YBQC5UTgAAwKYrab1qwjkzT5YfjfeZwFrsrpUHC1V0cB7bnfyL43jf+TOMN10FZG'
                    'Hg8vj+ZUzpf/Tcq64OAO5IpII5X/7li3YIwJQbMfQZ2/kJ81YqKVi9D80qCuP6pe'
                    'Re62wvzVZRiJjv5J5SxDU9x174PAqgcSQnAABg0047ADXFkw58515IUDBx6Hw03v'
                    'Uya3HnTlLwUV3Sge/42SSFH0WpaoKye+0AAAAAkFSvHcAUrySFFpCkkGVtU2vR6s'
                    'E/ll/meJJDcgIANI3kBAAA7NmKyAftINQVeUI/dLxDFQWDCRaLy5g5LD8f73iRld'
                    'gt7qPPxKfj9x4rJfWb7X/QWlqE5AQAdbnSDgAAjLsR45VmnA5wrR7sh7B6HyQpZJ'
                    's/WZJCKilf63RJCnsReYycCQDMIzkBAAB7eu0AzLB4yOubpOCjUOxOVRSs7XvOKg'
                    'o1JylkmfulisKDiHz0WKUl99oBAICHjXYAAGDYRir6jE2rByMSxFVNqweFJIXUc2'
                    'rPd9LqIXyuB6nov1UAEOONdgAAAODEVqia8Np4qOr6Ia/E+OH8Ny5MYDF2Eelc2i'
                    'RG70vC8S+xOAZlad+L7Evq8Z2ISO+dYNOOe+0AAAAAkMROjFdNODcedHZLfxkf/0'
                    '5f+9/Zrd5HgricX8sMa3uvl3Ots/sJ3peZOaNFzndyT2H72Z/EAQANIzkBAABbeu'
                    '0ATDN5WO44gaXD8nH84HiZicPy8/GOQVl5z1h8/efH61dN0P1S5l51dQDwcyUit8'
                    'oxACIi8uVfv2iHABzbyCE5oUpeSQrWDvZDkKSQZW1Ta529V80mKaR4rccHK9zm0v'
                    '/8DQAF0dYBAAA7tkLVBDdWyvZPjndo9ZCrdL/v+LNWD7OXWmqX8DLe4yIrsVvcx2'
                    'm9xywtutcOAAA8bLQDAACjdiLyVjuIWKtq9SBi9z4Slf8PamtQ8vWtsdXDOG8qKV'
                    '9rt7lu4lYDgLqQnAAAgB29dgBVsXjI65ukUCwW9/GLl+kdls+Md1zE0nvGaJLKM5'
                    '7aOPhROwAAAAAE24rIH7WDSMX5ULuVJAXL95HkHD1wkpJ7knuts9c4OHFjZs5oiZ'
                    'IUFub6LFTAArAyJCcAAGDDRkS+V46hTiYPyx0XtHRYfjTe6bKc+xh8n4aSFHKNLT'
                    'O+97gqi9/8r/5GOwQRkUftAADA0bV2AABgUK8dQA4kKRhBFYW0a5z8sr0khZN7ej'
                    '1PHz4zANSJ5AQAAGzYSQPlJlWZPCx3XNDSYfnReOckBZ95iyUpZJrfO5ZMceQbT9'
                    'WEX9xpBwAAQE2+/OsX7RCA0VYab5nolaTQAqv3QZJCtvnNJilEXf6q1cOfhKoJAF'
                    'bojXYAAABANnJITkAKnbh/YBwPbIuNX5ggZP4CsS9eWnwfHcYPHhdZec/Y2MfeO5'
                    'mlXY/aAQCAo412AABgzEftAEoZZJBu6S/w49//a/97vuX7SBCb02uZaW0za03MH7'
                    'wv5/Omijnlaz3wXSCAdaJyAgAA+nZC1YS0bD2J7tfqYXJ84lgCx2dp9ZC9coGhVg'
                    '85Kyn4uDyeqgmn7rQDAABH32kHAACGXIvIe+0gSqLVgyFaVRQSrG1qrbPX2GwVhb'
                    'hWD59E5D5RNABQFSonAACgayNUTcinyBP6MXPPTGDjKfrT8S5VFI7GOitSucDxQm'
                    'vvmbKv/0fHq7P6zf/yb7RDGD1qBwAAAABvvXYAWsbDW6dKCharD/iyWkkh0ZP1hy'
                    'k8J2mpisK4xlkVhcOSUZsrz5OkETbfk4jsohMuAKBSVE4AAEDXTqiakF+RJ/RDxz'
                    'tUUTBXjcBhGUuVCE7GO16UrhrBTCyJx8aNfxKRvceVa3CnHQAAeNhqBwAABnwvK6'
                    'uaMMXpKXPL1Qd8Wb2PBHscXDGg5Oube62J+c1WUnC3F5LhAawYyQkAAOjZCFUTyj'
                    'J5WO44gdEECxOtHrz3ZSWtHvzG74UvR849agcAAB622gEAgAF77QAsodWDEQniqq'
                    'bVg0KSQpJ5U3HbAx4MALB6JCcAAKDnRqiaUJ6lA+dxvM8E1mLvHC/LmVzhO/6kis'
                    'IKkhSWHb4cGefW/seWH7UDAACgBl/+9Yt2CMCNiLzTDsIa5yfMLR/u+7B6H2upoj'
                    'Cul3v+4fiXRqsoXJ6vFxLhAazcG+0AAABYsZ12AKs2HoK6fgANGR8198wEJWL3HT'
                    '84Xha9LznGO16Y8z3gOz7tPu7F0pcjtr5MfNQOAAAcXYnIrXIMWDNb//uNNeqk1w'
                    '7BsvHwtlvKBh7EYsKwv/G/SdbuJUFczq9lhrVNrXX2Xg3el/M5RdLF/frP04NQNQ'
                    'EAqJwAAICSG+GpDhuKPKEfOt6hikLRqg5ucy8uY6kSwcl4x4usxJ5m7kPVBFxypx'
                    '0AADjaaAcAAIp6GeQdSTLLnJ4yt1p9IITV+1hLJQWlVg9JKimkchpjn3BmAKgWyQ'
                    'kAAOjotQPAEbOH5Y4TGE2wWLzMUnLFy3jHRSy9Z+Lm3gvVAeY8agcAAIB1tHSAso'
                    '0cVyVs6WA9I1o9GJEgruCD+NKtHhSSFFLPGTnfjyLyMeGMAFAt2joAAFDejVA1wS'
                    'aj7RKcJrAYu4h0g8NlxVtmuIzP2OrBd3y+NhJPMtiqmvCb/8XfaIdw7k47AABwdK'
                    'UdAAAo2YnI21e/a7WsvyFerR4OA+tm9T7W0uphXG+9rR52ZpNkAKAwKicAAFBerx'
                    '0AFhR5Qj8mFuVWDwF743SZtbh9Wz0UaJmROI69UBlgyaN2AADgaKMdAAAo2Mpx1Y'
                    'QpHAYuci6D38peWq2kQKuHbPMna/UQPsVnEbmNCwAA2kHlBAAAyroRqibUo8gT+q'
                    'HjFybI+YS+7/ijWBbDMlkBonse73CRlffM8tgnEdmbe2rInjvtAAAAAHBRL1NVE8'
                    '5ZfWLemEGG9VRREMn/FH+otVRSyL3WxPxO73GXef2n6OMWBYC2UDkBAICyeu0A4M'
                    'liJYJu9jdejy8Wi/t4pyoKBSo6+I13XMTSe+by2B+EqgAuHrUDAABH77UDwDp9+d'
                    'cv2iFgvbYi8sHrCqtPzBviVUWhhb20fB8J4gquFlByT3KvdfYaK1RR+CRUTQCAEy'
                    'QnAABQzvdC1YR6mTwsd1zQ0mH50XjnVg8W2iWcjDeUpBA+tve4eu1+1A4AAAAAr+'
                    'yDr7R8IG0ESQpG0Ooh7RonvyyWpNDHLQIA7SE5AQCAcnbaASABk4fljgtaOiw/Gu'
                    '+cpOAzb7EkhUzze8fiNfaTiNx7rLJ2j9oBAICjjXYAAFDItYj8PnoWi4fRxnglKb'
                    'TA6n2QpJBt/sxJCnz2BoAJJCcAAFDGtVButy0mD8sdJ7ByWH42fvFSixUgfC6yEn'
                    'sn/ct4Q//85n/+Nx43XNSddgAA4OhKOwAAKKRPNpPVJ+aNoYqCEYmSFLTWNrPWhS'
                    'SFJPP+4kl4SAkAJpGcAABAGb12AMjA5GG5xwTWYj9KUlCPxXtux0X03zM8ueHvUT'
                    'sAAAAAvLiWHIn/lg+kjaDVgyFaVRQSrG1qrbPXOHEVhb3wWRIAJpGcAABAftdC1Y'
                    'S2mTwsd5xA/7D89XjXy3zm9R0ffJ+GkhSm9R6z4OBWOwAAcLTVDgAACviYdXbLB9'
                    'JGrLLVg8V7odVD2jVOfhmdpPAkg+xfYrfwDwAY8kY7AAAAVqDXDgCFdOL3oc9n/H'
                    'jYHDx+YYLo+R3GB8y9uEyJuIPGO95w2feM7aoJfGECALG22gFgXb782xftELA+Ny'
                    'LyrshKg/gnQ6/MeHjbzW3U+Hf8FvbS6nsiwR47vZaZ1jaz1sT8wfty+B7wMTomAG'
                    'gUyQkAAOR1LVRNWBezh+WOExhNsFhcxuK+D44XlYu9d7wCp26T9B8FAABArL7oai'
                    '0drGc0yLB8eNvKXlq+jwTJE06vZaa1vdaSjOtdSFLw2JcHObR0AABcQHICAAB57b'
                    'QDgBKTh+WOE1iMXUS6weGynBUdfMefVFFwCCrvPtqumiC/PJUCAAi21Q4AADLqpV'
                    'TVhHOWD6SNcH7CvJW9tHofa6miMK6Xc62z+/HYlz5TRADQjF9pBwAAQMO2IvJ77S'
                    'CgrBO/D8wh46PmnpmgROwB9+p0mbW4O48L87wH+pd5Df7z5n/2G48bVvFZOwAAcL'
                    'DVDgDr8fXfvmqHgHXZiIXEf3JpFw3P/+cwsA2D2LyXBHE5v5YZ1ja11nD+y9l9+V'
                    'FEPuYNCADqR3ICAAD59NoBwBDfjP6ih+sLExhNsFhcxmJyxUuSguP4NLF8FuNVEw'
                    'AAAIAZOxF5qx2EiNg9jDbGOUGhlb20eh8kKWSb/8K+7DJGAQDNIDkBAIA8tiLyQT'
                    'sIGGP2sNxxAqMJFk5VFKwkV7yMz1hF4fX43mMGTLvVDgAAHFxpBwAAGWzE4oFfSw'
                    'frmXhVUWhhLy3fR4K4gtvwldyTElUUJpIUnn0WPjcCgJM32gEAANCoXjsAGDYeHr'
                    't+cC4xfjj/jQsTWIxdRLrB4bLofUk8t4jI4Hhh+D7yBQkArIeNp4oBIK29WP7v21'
                    'lferw2Ht52S5vUyl5avY8EcTm/lhnWNrXWcDr/877sMq4IAE2hcgIAAOlthaoJcF'
                    'HkCf2YWJRbPQTsjdNl1uL2bfXgN3//co3Rf978T3/jcUNqbrUDAAAAWKGt1PLZ2u'
                    'oT84Z4VVJogdX7oNVDjvk/ichdxtUAoCkkJwAAkF6vHQAqY/Kw3HECowkWi2GZTK'
                    '7wuMhtGFUTAGB9rrUDAICEeu0AvFgu628IrR6MIEkh5fz9yzpW/wEAQ0hOAAAgra'
                    '3U8mQHbLF4WO6bpFAsFvfxTlUUClR08JvbcZHlYb3H6ph3qx0AAABWfP23r9ohYB'
                    '2updbP1hwGLvKqotDCXlq+jwRxBSUoJFrbwFr/KCL32WYHgAaRnAAAQFo77QBQOU'
                    'uH5ZPjK2v10GVo9eA7PqrVQ3CSAlUTAGCdNtoBAEAivXYA0SwfSBuxylYPFu+FKg'
                    'qhnqSF/1YBQGEkJwAAkM5GRG6UY0ArijyhHzo+Q6uHAgkWVbZ6eElScBz/i95jJb'
                    'j5rB0AADi40g4AABK4FpH32kEkY/Ew2hing22rB/shrN4HSQq+9iLymGQmAFiRN9'
                    'oBAADQkJ2IvNUOAo3pxP1D83g4XWz8wgQh8xeIffHS4vvoMH5wvOgw7LMMFVVNsP'
                    'rFHAAAALTstQNIbvw7r2+i9coMMki3tEmt7KXl+0gQm9NrmWntQms9SYv/rQKAAq'
                    'icAABAGhuhpQNysfhEv88E1mI/qqSgHov33E6L9C/DjP/z5n/8G49NUHerHQAAON'
                    'hqB4C2ff33r9ohoH03IvKddhDZtPT0fyZerR5a2EvL96FVRSHB2gXW2glVEwAgCM'
                    'kJAACksROqJiA3k4fljhMYTbBwuiywjYTz2LRJCg/CIXouj9oBAICDrXYAABCp1w'
                    '6gCKuH0YZ4JSm0wGqSAq0epjyIyMdcoQBA60hOAAAg3kaomoCSTB6WO05gNMFicR'
                    'mLyRUvSQoneo9Z4OdOOwAAAIDG7UTknXYQxVg9jDbG6WC7pb20eh8kKRzrs8cBAA'
                    '0jOQEAgHg7oWoCSjN7WO44gdEECxOtHryTMV4u4umNvO61AwAAB1vtANAuWjogs4'
                    '2s9cCvpYP1jGj1YESCuKpp9TC93mfhczcARHmjHQAAAJXbCFUToGk8yHb9kF5i/H'
                    'D+GxcmsBi7iHSDw2XR+5Jw/EssXe+xAvzdawcAAA7W88QxgNbsZO1J/+Pf/30TuV'
                    'dkPNTuljaplb20eh8J4nJ+LTOs7b3e6Vp9oZUBoFlUTgAAIM73svYvUGBDzvYHvu'
                    'MnY1Fu9RCwN06X2YmbqgllPGgHAAAA0KCNkPT/C6tPzBvi3B6glb20Wklhfa0ePo'
                    'vIbaFVAaBZVE4AACBOrx0AcCLoiftS4xcmMFmNwCEsGxUgenNP0yx48z+q8qPIvf'
                    'BUMgD7rkTkTjkGAPCxF5L+T1l9Yt6YQYb1VFEQmXqK34a1VFIYSKICgBSq/EYQAA'
                    'AjboRDKlhk47B8ZrxDkoLB2BfDKt4y4wVVE8q5E5H32kEAwIKNdgAA4GErIh+0gz'
                    'CrpYP1TGj1YEiC5AmnhJNMay/4JImSP//7/8f/LcU0AFAt2joAABCu1w4AmFWo/U'
                    'H4+JkFLbZ66DxaPeTax+m5e48ZEOdROwAAAIDG9NoBVMFqWX9DvFo9tLCXVu+j3V'
                    'YPfbaZAWBlSE4AACDMjVA1AbUof1juOX5mAqMJFs5JCj7zho2nakJZt9oBAICDa+'
                    '0A0J6v//5VOwS06UqomuDH4mG0MV5JCi2weh9tJSn8oxxa/AEAEqCtAwAAYXrtAA'
                    'BvRtslOE2QrgVCmrmfxy9emn8fe8eRprz5T9V+DHnUDgAAAKAhe+0AqmS5rL8hTu'
                    '0BWtlLy/eRILaoVg+Ra4vIk/AdIAAkReUEAAD83QhVE1Aro+0SnCcwGnuWVg/L45'
                    '+Eqgml3WkHAAAONtoBAICDaxF5rx1E1ayW9TeEVg+GaFVRiF97LySpA0BS1T6yBA'
                    'CAop12AEC0EpURfL4AeDV+ZoLiVR3cxneDw2XR+3Ji7zGTLVa/MHPzICSoAbDtSj'
                    'sAAHDQawfQDMtPzRsxHmo7VVJoYR+tvicSVVE4TOE5SdjaD1Lz524AMIrKCQAA+L'
                    'kWke+0gwCSCXmiP+fcvlUUcsfj46iKwuylaeJ+Er4k0XKvHQAAACV9/etX7RDQnh'
                    'uhakJ6dScAF+H09L3l6gO+rN5Hgj0OrqTgt3YvVE0AgORITgAAwE+vHQCQhdF2CU'
                    '4TGE2wyJyksBe+JNFypx0AACzYaAcAAAt67QCa1dLBeka0ejAiQVxRrR7mL30Q2i'
                    'gCQBYkJwAA4O5aeLoDLSuedOAw3mcCa7EfJSkknpuqCboetQMAgAVU+QJg2Y3QIi'
                    's/ywfSRjg/ed/KXlq9D80qCuP603ZhEwIAlpCcAACAu147AKAIS+0SJudWbvUQcK'
                    '9Ol7nPuxcOyDXdaQcAAABQqY2QZFuWxcNoY7ySFFpAkoLL2p9F5Ie4aAAAl7zRDg'
                    'AAgEpcC1UTsDad+H054DN+PIgPHr8wQfT8DuMD5l5cZjmOQ9UEnwQJY95sqv8I8q'
                    'gdAAA42IrIvXIMAHBuJyJvtYNYnfGzRcWfIUoYD7W7uY1qaS8HsXkfCfbY6bWcX7'
                    'sPXx0AsITKCQAAuOm1AwBUWKxE0M3+xuvxPuy3etgLh+PabrUDAAAHW+0A0Iavf/'
                    '2qHQLasRHKpOuy+sS8MbR6MCJBXIGtHj4Ln/kAIKvqH1sCAKCAa6FqAtauRCUC3/'
                    'HD+W9cmMBi7CLSDQ6Xnc59qJoAC56Ep/4AAAB89MLfn2xo6en/TJyfvG9lL63eh0'
                    '4VhRuzCRsA0AgqJwAAsOxGOwDAjJBqAb7zR8WyUEXBWhUI18sOA/ZC1QQr7rQDAI'
                    'AFV9oBAMCRrYj8QTsInOEAdtHw/H8OA9tgtZJCgrgcX8tPQlssAMiO5AQAAOZtRe'
                    'SDdhCAOdYO+X1bPRhMsFgMq5P9y6Ca/2nDvXYAALBgox0AABzptQPABVYPo41ZVa'
                    'sHEbv3kT9JoY+bHQDgguQEAADm9doBAGZZrETgm6RQLBb38Rcu+yRUTbDkXjsAAA'
                    'By+/rXr9ohoA1bIeHfvpYO1jPxqqLQwl5avo8EcU28lv8gfM4DgCLeaAcAAIBhW+'
                    'FLFGDZeJru+gVByHifLx9ejZ9ZsETsAeO74dVlveMMpv367a/dvtCz7047AABYcK'
                    '0dAAA8+6gdADyMf1Vvp+JZcuPnmW5pk1rZS6v3kSCuo9fySQ5tFAEABVA5AQCAy3'
                    'rtAICq5GyXkKRyQeJWDwVaQzwvQ99Lex61AwAAAKjAtYi81w4CAZrIJ87Lq5JCC6'
                    'zeR5pWD3vhMx4AFEPlBAAApm2FqglAGJ9KB8UrFyxMkLOqQ3jsvbWHVEDlBADmbb'
                    'QDAAAh4b9uVp+YN2aQgSoKFoTH9iAi+0Yq/AFAFUhOAABgWq8dAFA1i+0SXFs9TI'
                    '5PHIv7eKom2PTId1cAjPtOOwDU7dtP37RDQP2+F6omtMHygbQRtHowZBDfuHqhag'
                    'IAFEVyAgAAr22FqglAGsWTDnznnpnARoJFb/ILn1BtHeh/Fr5wBwAAuGSvHQASs3'
                    'wgbYRXkkIL+2j1PeEe14OIfMwZCgDgtV9pBwAAgEE32gEAzenE7wsL37FR4xcmiJ'
                    '7fYfw0qibY9qgdAAAs2GgHAGC1bkTknXYQyKSthOMshuf/WxjUzl5avY/lPd4ViQ'
                    'MAcILkBAAATm2EDydAPkWTDnzHZ0hSCI5FRBprL/Or//hr7RBSu9MOAAAWXGkHAG'
                    'CVNtLY32MxoaWD9YwWExQOg9rYS8v3MR3XZxH5oWgcAAARITkBAIBzOxF5qx0E0L'
                    'TiSQcO430mKBM7VRPsu9cOAAAAwKCdUDVhPSwfSBvhVEXhMLCNvbR6H6/j6lXiAA'
                    'DIG+0AAAAwZCNUTQDKGQ/tXb+4CBkfNffMBPlj7x1HQs+9dgAAsGCrHQDq9O2nb9'
                    'ohoF4b4TP1Og3il5S9QmOCQre0Ua3s5fjZ19q9HOL6LJ3c6gYCAOtFcgIAAL/YCV'
                    'UTgPJ8kgh8x0cnESxMkCdJ4bNw8F2DO+0AAGDBVjsAAKuzEz5Tr5fVw2hjnJIUWt'
                    'pLm8kWNyarOwDAStDWAQCAg43whAegx2Krh272N16P9zE/vvecDToetQMAAAAwZC'
                    'sif9QOAgZYLetvDK0e1NBCEQCUkZwAAMDBTnjCA9BnMUnBdYI0sXwWobxkRT5rBw'
                    'AAM660AwCwKr12ADDG1oG0ScPz/zkMbGMv9e/jSfhvFQCoIzkBAICDG+0AAByJTi'
                    'JIOH4yloUqCuHz9x5XVuNXf/9r7RAAYI022gGgPt9++qYdAuq0FZEP2kHAqBYO1T'
                    'PzSlJogV6Swl6omgAA6khOAADgkJjwTjsIABOsVVHwbfXgNz9VE+pzqx0AAACAAR'
                    '+1A4Bx+k/MV2FVVRRESt/HkxySEwAAyt5oBwAAgAG9dgAAZowH/K5fXBQfvzBB5z'
                    'x3710BAtoetQMAgBnvtQMAsArXwn9v4Gr8XMTnnovGBIVuaZNa2cty97EXPr8BgA'
                    'lUTgAArN2NUDUBqEOJygg+0rZ6oGpCne60AwAAAFDWaweACrX09H8mtHpI6kH4bx'
                    'UAmEFyAgBg7XrtAAB4ypl0oNfqofdYtSq/+rtfa4eQ0712AAAAAIquhaoJiNHKwX'
                    'pGTkkKLSV75LmPPsusAIAgJCcAANbsRqiaANSraNKB73ivJAWqJtTrXjsAAFhwrR'
                    '0AgKZ91A4ADWjpYD0j5yoKLexl2vt4EP5bBQCmvNEOAAAARb12AAAijQf8rl9clB'
                    'g/nP/GzASH8b3j7HVq4cuxeT+KyHfaQQAAEOvbz9+0Q0BdboRkf6Q0fm7wbbe3Im'
                    'OCQre0Sa3sZZr7uImOAwCQFJUTAABrdSN8kQK0o0RlhKi5L07wIFRNqN2jdgAAMG'
                    'OjHQCAZvXaAaBRrTz9n5FTq4fDwDaEvyeoUggABpGcAABYqxvtAABk4PtEhX6rh/'
                    '7lt1v9p3232gEAwIwr7QAANKkXkv2RWysH6xk5JSm0lOzhfx99+iAAALFITgAArN'
                    'G1iLzXDgJAJiWqKKRJUqD3JQAAMIGWDvCwEZGdcgxYi5YO1jNyrqLQwl6638efhE'
                    'RyADCJ5AQAwBr12gEAKMBiksLpb/T6ZQ3y/vOr3/3aY4OqdasdAADM2GoHAKA5Ox'
                    'F5qx0EVqaVg/WMvFo9tLCXy/exKxIHAMAbyQkAgLW5FqomAOtSPOnAaW6qJrTjUT'
                    'sAAJix1Q4AQFO2woEfNLVwqJ6ZV5JCC6aTFD6JyH3pUAAAbt5oBwAAQGG9dgAAlH'
                    'Ti9wWMz/gxQcF9fO8RCWy70w4AAACgkF6omgBt42cunyTxFRpkkG5pk1ray0HG+3'
                    'gSvvsDANOonAAAWJNroWoCsG42Wj1QNaE9D9oBAMAFV9oBwL5vP3/TDgF12IrIB+'
                    '0ggBettCfIaKWtHvZC1QQAMI3KCQCANem1AwBghH+lg5Tje8dZUI97EXmnHQQATO'
                    'AJZwCp7LUDACa19PR/JmOCwgoqKTyJyL6JRAsAaBiVEwAAa3ElVE0AcC6kMoLv/K'
                    'eomtCmO+0AAAAAMroWkd9rBwHM4kB6kVclhTrtReRROQYAwAKSEwAAa7HTDgCAYe'
                    'VaPfQeV1btV79d1UeNR+0AAGDGtXYAAKrXawcAOGmlPUFmjbZ6eBD+WwUAVVjVN4'
                    'YAgNXaCr0xASyJSzpwGf8knfzwcl3r/6zLrXYAAAAAmVwLVQhRm/oO1ovzqqJQx1'
                    '722gEAANyQnAAAWINeOwAAFcmXpLAXnrAHAABAXfbaAQDB6jlYV9NIqwfaJwJARU'
                    'hOAAC0bitUTQAQIiRJ4bIn4Yvdlt1qBwAAM661A4Bd337+ph0CbLsRke+0gwCi2T'
                    '5YN8EpScFusseNdgAAAHckJwAAWtdrBwCgcmmqKOyFqgmte9IOAAAAILFeOwAgGb'
                    'sH66ZU2Orhs5AsDgBVITkBANCyrVA1AUAKca0eqJqwDnfaAQDABRvtAABUaSci77'
                    'SDAJKzdbBuklerB/297LUDAAD4eaMdAACc8Dn4AZYMfEABkNj4v1OuX8Acxu9loG'
                    'rCCtyLyHvtIABgwpV2ALCJlg6YsREO/NC6QfgecsGYoNAtbZTeXn4SqiYAQHVITg'
                    'AAtGojIt8rxwCgVZ24Jigcqias7EuvX/3mVxaeoCntXjsAAACARHYi8lY7CCC78T'
                    'PLyj6v+XJKUtDZy77oagCAJGjrAABo1U46ecsHTADZuLV62ItQNWEl7rQDAIALtt'
                    'oBAKjKRg7JCcB62GhPYJ6xVg+fhARxAKgSyQkAgBZt5PjLFN9e8QDg4/J/Yw5VE7'
                    'AWj9oBAMAF9IwH4GMvVE3AWpGksGh4/j+HgTn38klIogKAapGcAABo0U6mvkwhSQ'
                    'FATq//G7MXDqzX5FY7AAAAgEhbEfmgHQSgjgSFRV5JCunthc/aAFAtkhMAAK3ZyF'
                    'L2NAkKAHL65b8xH/WCgJIn7QAA4IIr7QAAVKHXDgAwgyoKThSqKFChEAAqR3ICAK'
                    'A1O3EpQUkVBQA5dfS/XKk77QAA4IKNdgCw5duXb9ohwJ5roWoC8BpJCosKt3roha'
                    'oJAFC1N9oBAACQ0EZ8e86NCQp80ASQVr/WBKhfvVl1/vOjdgAAAACBeu0AANPG74'
                    '1W+jnPxZig0C1tUvhePghVEwCgeqv+5hAA0JwbcamaMIVKCgDSoWrCet1pBwAAF1'
                    'xpBwDAtGsRea8dBFAFHm5Z5FVJwU/vHw0AwBqSEwAALdlFz0CCAoB4vXYAUHOvHQ'
                    'AAXLDRDgCAaXvtAICq0OrBSeJWDz+KyMeYeAAANtDWAQDQihsReZdkJlo9AAi3+q'
                    'oJTl9AteteOwAAAJYMX1b9v9V47UZEvtMOAqgSrR4WJWz1sEsTEQBAG5UTAACt6J'
                    'PPSKsHAP567QA0dW9W/x/NO+0AAOCCa+0AAJjVawcAVI9KCosiWz18FpHbpAEBAN'
                    'SQnAAAaMGNpKqaMGX1Z20AHK2+agLkUTsAAAAADzeS87M0sDYkKCxySlJ4nezRZw'
                    'sIAFAcyQkAgBb02VegigKAZb12ADDhs3YAADBhox0AbKClA45sRGSvHAPQHqooOH'
                    'GuojDIJ6FqAgA05Y12AAAARLqRkk96jAkKfNAEcIqqCRg9agcAABPoJw/g3E5E3m'
                    'oHATRr/N6IB10uGhMUuvlN6vkODgDaQuUEAEDtepVVqaQA4NReOwCYcacdAAAAwI'
                    'KNHJITAOTGwfqimVYPPAQAAA0iOQEAULPvRbs/JgkKAA5l/O+0g4AZj9oBAMAFW+'
                    '0AAJjRC1UTgHJo9eDkLEnhSUiiAoAmkZwAAKjZTjsAEaGKAoBeOwALujf8h/DZnX'
                    'YAAHDBVjsAACZsReQP2kEAq0SSgpPnBIW9kPgNAE16ox0AAACBrkXkvXYQJ8ZzOT'
                    '5oAmvyWURutYOAKffaAQAAAMzotQMAVm/83oj87kueBhn22kEAAPKgcgIAoFa9dg'
                    'AXUUkBWJNeOwCYc68dAABccKUdAHQNX8iihlyJyAftIAA84z/Ll+yEqgkA0CwqJw'
                    'AAanQt1qomTOmED5pA26iacIz/3h37UUS+0w4CAM5stAMAoG6vHQCAM1RROPcgIh'
                    '+1gwAA5EPlBABAjXrtAJxRRQFoWa8dAMx61A4AAADgzLXUkOQPrNUgJHwf9NoBAA'
                    'DyIjkBAFCba6nxCxWSFIDWUDUBc261AwCACVfaAQBQ1WsHAMDBupMUPgtVEwCgeS'
                    'QnAABqs9MOIApJCkAreu0ALOl+zX/YzjxqBwAAEzbaAUDP8HW9J10QEZEbqTHJH1'
                    'izdf5nu9cOAACQH8kJAICabEXk99pBJME5HlAzqiZgyZ12AAAAAEd67QAABFhXFQ'
                    'U+ZwPASpCcAACoSa8dQFJUUQBqtdcOAObdawcAABN4ahpYpxsReacdBIAI60hS2G'
                    'kHAAAog+QEAEAttiLyQTuILEhSAGryICI/aAcB8+61AwAAAJBDO5e9cgwAUmk3Se'
                    'GTUH0OAFaD5AQAQC167QCyI0EBqEGvHQCq8aAdAABM2GgHAKConYi81Q4CQGLtJS'
                    'j02gEAAMohOQEAUIOttFo14RxVFADLHkTko3YQqMa9dgAAMOFKOwCUN3xt7xQLTj'
                    'ZCmXSgXe1UUfhH4bMTAKwKyQkAgBr02gEUR5ICYFGvHYBF3a/5j9UFd9oBAACAVd'
                    'sJVROA9tWdpPAkfM4GgNUhOQEAYN1W1lI1YQpJCoAVVE2Ar0ftAABgwlY7AABFbE'
                    'Xkj9pBACiozgSFvfC5CQBWh+QEAIB1O+0ATCBBAdDWaweA6txqBwAAE7baAQAoot'
                    'cOAICCuqooPMkhOQEAsDIkJwAALNuIyI1yDHZQRQHQQtUEhHjUDgAAgOFrPadUSG'
                    'Yra64+CKCWJIWd8JkJAFaJ5AQAgGU7oUfmayQpAKX12gGgSnfaAQDAhK12AACy+6'
                    'gdAAAj7CYp8AAAAKwYyQkAAKs2QkuHeSQpACXwpQliPGgHAABnttoBAMjqWkTeaw'
                    'cBwBh7CQq9dgAAAD0kJwAArNoJVRPckKAA5NRrB2BZ92v+A7TgXjsAAACwKr12AA'
                    'CMslNF4bPwAAAArBrJCQAAizZC1QQ/VFEAcngSkR+0g0DV7rUDAIAzV9oBoJzhq4'
                    '1TKBTzvVA1AcAS/SSFXnV1AIA6khMAABbthKoJYUhSAFLai8ijcgyo2712AABwhr'
                    '9jA+3aawcAoCI6SQqfReS2+KoAAFNITgAAWLMRqibEI0EBiPUkfMGLeHfaAQAAgF'
                    'W4EZF32kEAqFDZBIVd0dUAACaRnAAAsOZ74YmuNKiiAMTYC1UTEO9ROwAAmHCtHQ'
                    'CApDZCmXQAMcpUUfgkJG8DAITkBACAPb12AM0hSQHwRdUEpHKrHQAAAGjeTqiaAC'
                    'CFvEkKfbaZAQBVeaMdAAAAR26EL1XyGRMUyvcUBGqzF554d8N/T1w8CRWBANiy0Q'
                    '4A+Q3f+B/pldgIZdIBpDZI6odc/kFE7pPOCACoFpUTAACW9NoBrAJVFIA5VE1w1P'
                    '2K/5g4utMOAADOXGkHACCZnZAECSCHdFUU+IwNADhBcgIAwIoboWpCObR6AC7ZC1'
                    'UTkNa9dgAAAKBJW6FqAoDc4pMU9sJnbADAEZITAABW9NoBrBJJCsAxnuhADvfaAQ'
                    'DAma12AACS6IWqCQBKCUtSeBA+YwMAzpCcAACw4EaomqCLJAVAROSj8EQH0rvXDg'
                    'AAzmy1A0Bew7c0dbhh2lZEPmgHAWCF/P4nphc+YwMAzpCcAACwoNcOAM9IUMC67b'
                    'UDqEX3K/5j4eFeOwAAANCcvXYAAFbMrYrCgxweAAAA4ATJCQAAbddC1QRbqKKAdf'
                    'okHCIjjzvtAADgzFY7AABRrkXk99pBAMBCksKuWBwAgKq80Q4AAI51nIiuziBDrx'
                    '0DLhj/OFIVFuvQaweAZj1qBwAAZ0gMBurWawcAACfG741++Vr3s4j8oBEKAMA+Ki'
                    'cAADRdd9K91w4CC6ikgPZRNQG5fdYOAAAANOFaRPgMDcCmXx5u6fWCAABYR3ICAE'
                    'BTL3KomEHVjArwEqFdvXYAaN6jdgAAcOZKOwAAQT5qBwAAswb5LCK32mEAAOwiOQ'
                    'EAoOVazp74IEmhAlRRQHuomoAS7rQDAIAzG+0AkMfwjZ5sDbsR2rIAsO9GBhH+mf'
                    'kHAFaO5AQAgJb+0g9IUKgASQpoR68dQG26X/GHP8C9dgAAAKB6vXYAALCA5H8AwC'
                    'KSEwAAGq5loU8mVRQqwUuEuvHFCUq51w4AAM5cawcAwEsvVE0AYF+vHQAAwL432g'
                    'EAwAkOOtdhkBvXoWOCwkDdM7vGP7e8RKhPrx0AVuNOOwAAQPto6dCsjYjslGMAgC'
                    'X/ICRlAwAckJwAAChtKyIffC/qpCNBwTqSFFAXqiagpEftAADgzEY7AGTA38Pb1M'
                    'lORN5qhwEAM55EZK8dBACgDrR1AACU1ksnQVUyaPVQicDXFyjso3YAWJ0ftQMAgC'
                    'NX2gEAcLIVqiYAsG8vJGQDAByRnAAAKGkrx1UTSFJoGy8R7PosIrfaQWB1HrUDAA'
                    'AA1ellkLdUxQBg2INQNQEA4IHkBABASf3k7wYeYpOkUAGqKMCmXjuAWnW/4g90hF'
                    'vtAADgyEY7AKQ1fOX0ukFbOU7uH4TWHQAs6oVEbACAB5ITAAClbOX4i5VzEYfYJC'
                    'hUgCQF2EHVBGh51A4AAI58px0AgEX95O+SpADAjgehZSIAwBPJCQCAUnqnUbR6aB'
                    'tJCtDXaweA1brTDgAAAFTjWuaS+0VIUABgwU47AABAfUhOAACUsJWlL1bO0eqhbb'
                    'xE0EHVBGi61w4AAM5stQMAcFHvNIoqCgD0fBaRH7SDAADUh+QEAEAJN0FXRbZ6IE'
                    'nBOKoooLxeOwCs2r12AABwZqsdAIBJ1yLy3usKkhQAlNdrBwAAqBPJCQCA3DYSW+'
                    'YtMkkBxpGkgDKomgALftQOAAAAmLcPvpIkBQBl/En4fA0ACERyAgAgt52IvE0yU+'
                    'AhNlUUKkGSAvLqtQOoXfcr/oAm8KgdAAAcudIOAGkMXzmNbsiNiHwXPQtvCQB57b'
                    'QDAADUi+QEAEBOG8nxgYVWD23jJUJ6VE2AFXfaAQDAkY12AABe6ZPNRBUFAHl8El'
                    'rWAQAikJwAAMhpJ6mqJpyj1UPbqKKAtD5qBwA8e9QOAAAAmLUTkXfJZyVJAUA6T0'
                    'JVQgBAJJITAAC5bKREmTdaPbSNJAXEexCSE2DHrXYAAHDkWjsAxKOlQzM2kvvAj7'
                    'cKgHh7oWoCACDSG+0AAADN2kmuqglTxgNszy9cxgSFgW9qbOuEL9MQqtcOoAVd1/'
                    'FnMI1H7QAAAIBJOynx+Xn8+xwJ4AD8PckhOQEAgChUTgAA5LJTWTWi1QOVFIyjig'
                    'L8UTUB1txpBwAARzbaAQAQkVJVB4/R6gGAv72QbA0ASIDkBABADjdSsmrCuYhDbB'
                    'IUKkCSAtz12gEAEx60AwCAZ99pBwBARA4Hfjqfn0lSAODmQfh8DQBIhOQEAEAOvX'
                    'YAIhJ8iE0VhUqQpIB5VE2AVffaAQAAADO2IvJBOwgSFAAs6LUDAAC0g+QEAEBqNy'
                    'LyTjuIEyQptI2XCNN67QCAC+60AwCAIxvtAICV67UDeEEVBQDTSPwHACT1RjsAAE'
                    'Bzeu0ALuok6MuWMUFh4Jsau8YEBV4iHPDlSWL89y+pR+0AAODIlYjcKseAUN+0A0'
                    'CkK7FQNeHc+Nc+ksABHNxoBwAAaAuVEwAAKd2ItaoJ5yJaAVBFoQK0esBBrx1AU/'
                    'gzldqtdgAAAMCEvXYAs6ikAEDks/D5BQCQGMkJAICUeu0AnNHqoW0kKawZVRMAAH'
                    'C31Q4AWKlrEXmvHYQTEhSANeu1AwAAtIfkBABAKjdivWrClIgqCiQpVICXaI322g'
                    'EAC261AwCAI1vtAICV6rUD8EIVBWCN/iR8dgEAZEByAgAglRvtAIJFtnogScE4qi'
                    'isyZNQNQF1eNIOAABQuW/aASDCjdRSNeEcSQrAmuy0AwAAtInkBABACtdS65crxy'
                    'KTFGAcSQprsBeRR+UYABd32gEAwLMr7QCAFeq1A4hGkgLQuk8icq8dBACgTSQnAA'
                    'BS6LUDSCrwEJsqCpUgSaFVT0JLB9TjXjsAAHi20Q4AWJkbqbEd4iUkKAAtepLWvu'
                    'cDAJhCcgIAINa1tFA1YQqtHtrGS9SavVA1AfW41w4AAFAxWjrUaiMtJtNSRQFozV'
                    '74vAIAyIjkBABArF47gKxo9dA2qii0gqoJufDnI5c77QAA4FmbScaATTsReasdRD'
                    'YkKQAt4LM1ACA7khMAADGuZS1faNLqoW0kKdRuL1RNQF0etQMAAABFbeSQnNA+Eh'
                    'SAmvXCZxUAQGYkJwAAYvTaARRHkkLbeIlqxJMdqNGtdgAAAKCoXlqumnCOKgpAjR'
                    '6Ez9YAgAJITgAAhLqStVRNmBLR6oEkBeOoolCbvfBkBwAAMa61AwAatxWRP2gHoY'
                    'IkBaAmvXYAAIB1IDkBABBqpx2AuohDbBIUKkCSQg2omoCafdYOAAAAFNFrB6COJA'
                    'XAuh9F5KN2EACAdSA5AQAQYisiH7SDMINWD20jScGyj0LVBNTrUTsAAHi20Q4AHr'
                    '5pBwBPV8Jn51+QoABYtdMOAACwHiQnALCl458q/uHJj2kkKbSNl8iivXYATeM9n9'
                    'uddgAA8OxKOwCgYXvtAMyhigJgzWcRudUOAgCwHiQnAAB8baWTDxxazYho9UCSgn'
                    'FUUbDkk4jcawcBRLjXDgAAAGR1LSLvtYMwiyQFwIpeOwAAwLqQnAAA8NW//BuHtJ'
                    'dFHGKToFABkhQs6LUDACLdawcAAM+22gEAjeq1A6gCSQqApk9C1QQAQGEkJwAAfG'
                    'zlvF8mh7TzaPXQNt7/WqiagBbcaQcAAM+22gHA0TftAODhe6Fqgh8SFAANvXYAAI'
                    'D1ITkBAOCjv/gTDmnn0eqhbbxEpfXaAQAJPGoHAAAAstlrB1AlqigAJZH0DwBQQX'
                    'ICAMDVRs6rJkzhkPayyFYPJCkYR4JOKXyBgpZ81g4AAETkSjsAoDE3IvJOO4iqka'
                    'QA5PYkIjvtIAAA60RyAgDA1c55JIe08yKTFGAc7//ceu0AVoH3MACsyVvtAOCAlg'
                    '612Ah/X02HBAUgl71QyQ0AoOSNdgAAgCpsJCSjejzc4guFaYH7MyYoDGysbZ3w3k'
                    '+Pqgloza3QjxoA4IK/V9ZiJyLvSPRMaHzvs6dAKk9C6xkAgCIqJwAAXOwk5okqni'
                    'SfR6uHdvHeT63XDgBI7FE7AAB4dq0dANCAjYxJ/bQlSI89BVLphc8hAABFJCcAAJ'
                    'ZsJFUfOg5pL6PVQ9tIUkiBqglo0Z12AAAAIJmdnCf1c6CeHnsKxHgQqiYAAJSRnA'
                    'AAWLKTlH1oOaSdF7g/VFGoBO//GB+1A1gN3qMl3WsHAAAAktiKyB8v/pTD9PTYUy'
                    'BErx0AAAAkJwAA5mwkVdWEcxzSziNJoW28RL4+i8itdhBABvfaAQDAs2vtAIDK9Y'
                    'sjeOI/PfYU8PGjkPQPADCA5AQAwJwbSVk1YQpJCvMiWj2QpGAc730fvXYAQEY/ag'
                    'cAADDuq3YAWLAVkQ/OozlQT489BVzstAMAAECE5AQAwLxdsZU4pL0s4hCbBIUKkK'
                    'SwhKoJaN2jdgAAIIeKaQDCfAy6isP09EhSAC7hczUAwAySEwAAl9yIyLuiK3JIO4'
                    '9WD23j/X9Jrx0AkNmtdgAAICJX2gEAlboWkffBV3OYngd7CpzrtQMAAGBEcgIA4J'
                    'JebWUOaefR6qFtvETHeLoDa/CoHQAAAAjWJ5mFJIX02FNg9En4XA0AMITkBADAlB'
                    'spXTVhCoe0l0W2eiBJwTgSdEa9dgCrw/tOw512AAAgIlvtAHDBV+0AMON7iamaMI'
                    'UD9fTYU6DXDgAAgGMkJwAApvTaAbzgkHZeZJICjFv3+5+qCViLR+0AAEAsJCYD9d'
                    'lnm5nD9PRIUsA6/aOI3GsHAQDAMZITAADnbsTil5PrPqRdFrg/VFGoxDrf/712AE'
                    'Ahd9oBAAAAbzeS+3Mzh+l5sKdYjyfhczUAwCCSEwAA53rtAGat85DWHa0e2rael+'
                    'hHoWoC1uVBOwAAEJEr7QCAivTFViJJIT32FOuwF6q0AQAMeqMdAADAlO/FYtWEKZ'
                    '3wZcIl4wF2wP6MCQoDm2tXxOtbkb12AKvV9vvKsnup5X9/AbRsox0AUIleNP53e/'
                    'x72noSlvNjT9GuJ+FzNQDAKConAACO7bQD8EIVhXkR+0MVhQq0+/5/EJGP2kEAhd'
                    '1pBwAAMOibdgCYsBHtz80kk6bHnqI9O6FqAgDAKJITAACjaxF5rx1EkHYPadMI3B'
                    '9aPVSivZeo1w4AUPCoHQAACG0dABc7EXmrHQRtCTJgT9EOEv4BAKaRnAAAGPXaAU'
                    'QjSWFeRBUFkhSMa+e9z5coWKtb7QAAQGjrACzZinbVhHMcqKfHnqJ+vXYAAADMIT'
                    'kBACBSc9WEKW0c0uZBq4e21Z+k0GsHACh51A4AAAAs6sVC1YQpHKanR5IC6vRZSP'
                    'gHABj3RjsAADhR96FazfrmPnSP76XW7iuVwP0ZExQGNta2Ot//VE3Amt1pBwAAck'
                    'hYhhXftAPAma2IfNAOYtb4d3++V0lrEPYUNem1AwAAYAmVEwAA1yLyvoEnrqe1el'
                    '+pBO4PrR4qUddL1GsHACh70g4AAABctNcOwBlP/KfHnqIOn4V2cQCACpCcAADoT3'
                    '7V6mF+q/eVSkSrB5IUjKvjvU/VBIDqCQD0bbQDAIy6FpHfawfhjQP19NhT2LbTDg'
                    'AAABckJwDAum1F5P3kT+wfZoZp9b5SiDjEJkGhAraTFHrtAAAD7rUDALB632kHAB'
                    'jVawcQhcP09EhSgD2fhGRnAEAlSE4AgHXrZ39q+zAzXKv3lQqtHtpm7/1P1QTg4F'
                    '47AAAA8Mq1XErorwmH6Xmwp7Cj1w4AAABXJCcAwHptReSD00h7h5lptHpfqdDqoW'
                    '12XqKP2gEARtxpBwAAcviMAOAXH7UDSIokhfTYU+j7RyHRGQBQEZITAGC9eu8r7B'
                    'xmptXqfaUQ2eqBJAXj9BN0nkRkrxoBYMejdgAAICQn2PBNOwA8uxGRd9pBZMGBen'
                    'rsKXQ8CVUTAACVeaMdAABAxVZcqyacGw8yW/vQ3ep9pRKxP510MrCxtum9//fCgS'
                    'wwutUOAABgBH91tqJvPtd6EO1k5faMf37ZV5SxFz5TAwAqQ+UEAFinPnoG/Seu82'
                    'j1vlIJ3B+qKFSi7PufqgnAa0/aAQBYvSvtAAAjdiLybhVPw6/hHjWwp8iPz9QAgC'
                    'qRnAAA67OV0KoJU1o9zG/1vlKh1UPbyrxEe+EJD+DcnXYAAFZvox3A6n3VDgBy+H'
                    'PQn/zOGg6aSVJIjz1FXjvhMzUAoEK0dQBgCoeW+Q0y7LJM3EmbH7pbva8UaPXQtr'
                    'ytHnjCA5h2LyLvtYMAAGDldiLy9tXvrqVc/1rusyT2FOk9iMhH7SAAAAhB5QQAWJ'
                    'dNJ91NttlbrTbQ6n2lQquHtuV5/++FJzyAKffaAQBYvSvtAABlGzkkJ1y2lqfh13'
                    'CPpbGnSKfXDgAAgFAkJwDAuuxE5G32A+FWD/Nbva9USFJoW7qXiKoJwGX32gEAWL'
                    '2NdgCAsr1MVU2YsoaD5rUkYpTEniLeZ6FqAgCgYiQnAMB6bOToCZAiB8KtHua3el'
                    '+pBO4NSQoVSPPe3wtVE4BL7rUDAAAo+qodwOptReSD1xVrOWhey32WxJ4iXK8dAA'
                    'AAMUhOAID12MnEEyDFkhRa1Op9pRBxiE2CQgXCX1+qJgDz7rQDALB677UDABT1wV'
                    'eu5aB5DfdY2lreO0jls4jcagcBAEAMkhMAYB02stA3M3uSQqvVBlq9r1Ro9dA2/9'
                    'f3B6FqAjDnUTsAAABW6lp8qyZMWcNB8xruUQN7Cjc32gEAABCL5AQAWIedOPbNpN'
                    'VDoFbvKxWSFNrm/hL1+YIAmvFZOwAAq7fRDgBQ0CedbQ0HzSQppMeeYt4noQ0cAK'
                    'ABJCcAQPs2slA14VyxVg8tnjm3el+pRLR6IEnBuOX3Pl+kAG4etQMAsHpX2gEAhV'
                    '1LjpYmazloXst9lsSeYlqvHQAAACmQnAAA7fteHKsmnCuWpNCiVu8rhYgEDhIUKn'
                    'D59e2LxgHU6047AAAAVmafdfa1HDSv4R5LW8t7By7+QUj2BwA04o12AABwgnPH9I'
                    'b4A8FOOhlyfiIeX/fWPnS3el+pBO7PmKCQ9T2JeKevL1UTAHf32gEAWL2tdgCr9F'
                    'U7gNW6EZHviqw0fnxp+XuPNdyjhkHY03V7ktxJVAAAFETlBABo242IvEsxEa0eIr'
                    'R6X6nQ6qFth5eo1w0CqMq9dgAAVm+rHQBQUF98xTXkWPPEf3rs6ZrthdZvAICGkJ'
                    'wAAG3rUx+M0+ohQqv3lUJkqweSFEyjagLg5147AAAAVmIniZL5va3loHkt91kSe7'
                    'o2D0LVBABAY2jrAADtupHjL1o6SfoBNntp/VZbIrR6X6lE7E/29iMI1ZM7YhR/XK'
                    'y61w4AwOpttQNYHVo6aNiIhepea2mDQFuC9Nby3kEvVE0AADSGygkA0K7+1e9kaC'
                    '9Aq4dArd5XKoH7QxUFc6iaAIT5UTsAAKu21Q4AKGAnIm+1g3ixhqfh13CPGtjTlj'
                    '2IyEftIAAASI3kBABo043MlaestdVDi2fOrd5XKrR6qF2vHQBQqUftAAAAaNhGDs'
                    'kJ9qzhoJkkhfTY01bttAMAACAHkhMAoE2906hakxRa1Op9pRDxPiVBQdWfhKoJQK'
                    'hb7QAArNqVdgBAZr1Yqppwbi0HzWu5z5LY05Z8FpEftIMAACAHkhMAoD3XMlc1YU'
                    'qGVg9ZD4VbrTbQ6n2lQquH2uy1A8AMvrS07lE7AACrZvfQtkVftQNYna2I/EE7CC'
                    'drOWhewz2Wxp62oNcOAACAXN5oBwAASK4Pumo8u034IbaTToacn4ozxGxCq/eVSu'
                    'D+jAkKWd+TGH0WnvwGYtxpBwAAKIS/mpbWV5e3PEj7Sezjn4PW77Mk9rRmfJ4GAD'
                    'SNygkA0JZrEXkfNUOtrR5a/MDd6n2lEtHqgUoK2fXaAQCVu9cOAMDqXWsHAGRwJS'
                    'IfqkwIWVMVhTXcZ0nsaY1utAMAACAnkhMAoC19splqTVJoUav3lULE+5QEhWx4yg'
                    'OId68dAAAADdq//FutB7a1xu1rDfdY2lreO/X7JHwWAAA0juQEAGjHtcRWTZiS+P'
                    'w2e5JCq9UGWr2vVAL3hyoKWfTaAQCNeNAOAMCqbbQDABK7lqnPy7Ue2NYat4813K'
                    'MG9tS6XjsAAAByIzkBANrRZ5s5w8E4rR4CtXpfqZCkoI2qCUA699oBAFi1K+0AgM'
                    'T62Z/WehBeY8y+an1tLGNPrfoH4TMAAGAFSE4AgDZcS46qCedo9WAHSQrzIlo9kK'
                    'QQpdcOAA74IrIWd9oBAAAy+6IdwGrciOvn5Rr/nrSWg+a13GdJ7KklT3LcegYAgI'
                    'a90Q4AAJDETdHVOkn6AXY8DB5yfSoez5pb/NCd+LVoSsTr3kmX7/3YLqomAGk9ag'
                    'cAYNW22gGsA3/fLKPrvYaPL0ttOcu1xu1rkPbvsbS1vHds2wt//wcArASVEwCgfl'
                    'sR+VB8VVo92NHqfaVCq4dSeu0AgMbcagcAYNW22gEAidyIDO+Crqz1qfJa4/axhn'
                    'vUwJ5qeRA+TwMAVoTkBACoX6+6eq2tHlo8c271vlKh1UNOPwoHqUBqj9oBAAAy+s'
                    'IpYAEbeSmTHrHftR6E1xizr1pfG8vYUw29dgAAAJREcgIA1G0rGlUTptSapNCiVu'
                    '8rhYj3KUkKs/baAQANutMOAMCqbbUDABLYicjbX34Zeepa44HtWg6a13KfJbGnpT'
                    'yIyEftIAAAKOmNdgAAcIJzPz+DwezqTpJ+gB0Pg4dcn4rH91xrH7pbva9UIvanky'
                    '7f+7FOfJkC5PMgImGlqAEgDv/tQe02ckhOmDD+XT7gC4iIS1XVGrevQdq/x9LY09'
                    'xutAMAAKA0KicAQL220hmpmnAuQ3sBWj0EavW+UgncH6oonOi1A4AH8mpqc68dAA'
                    'AAldrJSdWEKRGPhtf6VHmtcftYwz2Wxp7m8llojwgAWCGSEwCgXr2I2D58rrXVg9'
                    'X9jNHqfaVCq4dQVE0A8rrTDgDAql1pBwAE2orIH92HR7Z6qPHQtsaYfdX62ljGnq'
                    'bWawcAAIAGkhMAoE5bkbOqCZYPn2tNUmhRq/eVQsT7dMUJCr12AEDjHrUDALBqG+'
                    '0AgEC9/yWRp641Htiu5aB5LfdZEnuawp+EqgkAgJUiOQEA6nRz8SfWkxSSTpc5Sc'
                    'HyXsZo9b5SodWDK6omAPndaQcAAMjgC6d6GW3lPJHfC60emrWGeyyNPY2x0w4AAA'
                    'AtJCcAQH024vIhxuoZaYaDcVo9BGr1vlIhSWFJrx0APPHlYY0etQMAsGrX2gEAAT'
                    '6mmWalSQqtq/W1sYw9DfFJRO61gwAAQAvJCQBQn52IvHUaafnwudZWD1b3M0ar95'
                    'VKRKuHhpMUqJoAlHGrHQAAABW5FpH3aaek1UOT1nKfJbGnrp6ERH8AwMq90Q4AAO'
                    'BlIyGl38bzUYsfFBPHNh4GDzlvthObexmr1ftKIeJ92kmX9/2oo9cOAFiRJ3FNSg'
                    'SAtDbaATSrub8aGtHl+jvq+IIFJB5HXKqq1rh9DdL+PZa2lvdOuL1QNQEAsHJUTg'
                    'CAuuwk5oDC8ofDDK0esj613mq1gVbvKxVaPYhQNQEo7U47AACrdaUdQJN+JjMhk+'
                    '9lSF014dxKWz3UGLePNdyjBvZ0ypMckhMAAFg1khMAoB4bCamacM7y4XOG2Gj1EK'
                    'jV+0pl3a0ePmoHAKzMvXYAAABUYC8ihQ6aI1s91HhoW2PMvmp9bSxjT8/tReRROQ'
                    'YAANSRnAAA9dhJyrLOlg+fE8dW5EDY6l7GavW+Uoh4n1acpMCTHkB599oBAFitjX'
                    'YAgKMbEXl38jvZD0UjF6jxwHYtB81ruc+S2FORQwXCXjsIAAAsIDkBAOqxyzKr9S'
                    'SFpNPR6iFIq/eVSmSSQmX2wpMeQGl32gEAWK3vtANoDi0dctjI3IGf5SSFWg9sa4'
                    '3b1xrusbS1vHem9doBAABgBckJAFCHG0lZNWGK1TNSWj3Y0ep9pRK4PxVVUaBqQs'
                    '3W+yVgCx61AwAAwLCdnFdNmFKk1QNJCs1Zwz1qWN+ePgjtEQEAeEFyAgDUoS+yiu'
                    'XD51pbPVjdzxit3lcq7bZ62AuHpICGO+0AAKzaVjsAYMZGfCoMFjlojmz1UOOhbY'
                    '0x+6r1tbFsXXt6ox0AAACWkJwAAPbdiMuTIClZPnyuNUmhRa3eVwqRrR4MJilQNQ'
                    'HQ86gdAIBV22oHAMzYSUiFQcutHsbLa7OWg+a13GdJ7e/pZxG51Q4CAABLSE4AYE'
                    'vHP6/+0exLZz1JIel0mQ+ELe9ljFbvK5XIJAVD9sIBKaDps3YAAAAYsxWRP0bNYD'
                    'lJodYD21rj9rWGeyyt3T3ttQMAAMAakhMAwLYb6QpXTZhi6oz0SIaDcVo9BGr1vl'
                    'IJ3B8jVRSomgDoe9QOAMBqXWkHAFzQJ5upSKuHFSYptK7W18ay9vb0T0LVBAAAXi'
                    'E5AQBs60XExqGv5cPnWls9WN3PGK3eVyp1tnrYCwejgLY77QAArNZGO4Bm/NzWiZ'
                    'uyrYh8SDpjkUPRyFYPtb2Faow5xFrus6R29nSnHQAAABaRnAAAdt2IHFVNsHLoay'
                    'WOKbUmKbSo1ftKob5WD3uNRZFQG1/srd29dgAAABiyzzaz5VYP4+W1aeeged4a7r'
                    'G0ut87n4S/wwMAMOmNdgAAcMxA+XJLboapT2HjFml/QOsMxHBJ4tjG9+Xk65FmAX'
                    'leoC2t3lcqgfuT/f146pNQNQGw4F47AACrda0dAHDmWkR+n32V8a/a2b6iiFgge2'
                    'yZ1Bq3jzXco4ZBatvTJ6FqAgAAF1E5AQBsuhaR97NP7lv4YLaiKgqHKWn1EKTV+0'
                    'olcH8KtXrocy8AwMmddgAAABjRF12NVg/p1Rizr1pfG8vq2tO9kOQPAMBFJCcAgE'
                    '398S9mExQsHPpaiWNKra0erO5njFbvK5WIVg+Z3pOUoQTseNQOAMBqbbQDaMLP9Z'
                    'yoGXctIu+Lr0qrh/TqOmgOt5b7LMn+nj4JrREBAJhFWwcAsOdaJr5wmS3lbqV8vp'
                    'U4piSOrUhpfcutM2K0el8pRLxPO+lSvx/7lJMBiPZZNA5kAKzdd9oBNIG/+6bRyU'
                    'fV9Wn1kF6tcfuqry2BfXbfO72QWAwAwCwqJwCAPf3cDxdbPVj4YGYhhksytHrIWk'
                    'nBymuaWqv3lYp+qweqJgAAAMCSGxF5px2EiBRq9RC4iP2nyqfVGrePNdyjBlt7+i'
                    'BUTQAAYBHJCQBgy7U4PhW5mKSgzfLhc4bYaPUQqNX7SkWv1UMfczEMsfVlHeLcag'
                    'cAYLU22gEAItKbOtwtEktkqwcre+Wjxph91fraWGZnT3vtAAAAqAHJCQBgS+97QR'
                    'VVFCzEMSVxbNmrKBwWaVOr95VCxPs08D1J1QTApkftAACs1pV2AFi9Xo6rJtg5iC'
                    'wQS+QCVvbJh6XXN6e13GdJunv6o4hy6xkAACpBcgIA2HElgb2kq2n1YCGOKbR6sK'
                    'HV+0olMknBQx+2CoDM7rQDAAAE+InTx0gbEdlN/sTS4a7lJAVL++Sj1rh9reEeS9'
                    'N57+yKrwgAQKVITgAAO3axE1STpGARrR7saPW+UgncH8ekGaomAHbdawcAYLW22g'
                    'Fg1XYi8nZ2hKXD3SKtHkhSaM4a7lFDuT39LLRgAwDAGckJAGDDVkQ+pJpsMUlBm+'
                    'XD51pbPVjdzxit3lcqeVo99IHRAMjvXjsAAKu11Q4Aq7UV1yR+S4e7RWKJbPVgZa'
                    '981Bizr1pfG8vK7GmffQUAABryRjsAADix1oPIIc8HmU46GaY+hY37rP2h10ocUx'
                    'LHNh4GT74eqXRicy9jtXpfKUS8Tyf++/BZOPwErPtRRL7TDgIAgEJ6WaqacG7866'
                    '2F7xayxxK5wBB+qRpLr29Oa7nPkvLt6SehagIAAF6onAAA+rbSpauacK6aVg8W4p'
                    'iSodVD1koKlvcyRqv3lUqaVg99uoBgAkk9LXrUDgDAKl1pB1Ctn/gf4whbiakuaO'
                    'kJ9Oyx0OqhWWu4x9LS72mffEYAABpHcgIA6OtFJPvhazVJChZl2B9aPQRq9b5SCU'
                    '9SoEcmUIdb7QAArNJGOwCsUp9kFkuHu0VaPawwSaF1tb42lqXb009C9UEAALzR1g'
                    'EAdG3l/GmQzK0OLrZ6GNfW/tBLq4e0LO9njFbvKxX/P8t99oQZFJf1vy0AAAD5XE'
                    'tM1YRzlkrkF4klol+Dpb1yVWPMIdZynyXF7emTiOxShQIAwJpQOQEAdPUXf5LxCf'
                    'FqqihYiGNK4tiyt3o4LNKmVu8rBff3KVUTgHrcagcAYJXeaweA1emzzGrpCXTLrR'
                    '7Gy2tj6fXNaQ33WFrYe2cvtFwDACAIyQkAoGcjLk+D0OrBrgytHrImKVh5TVNr9b'
                    '5SWd6fvkgcKGoY+NayUY/aAQAAHP3E/xYHupbcCTGWDrFp9ZBerXH7WMM9anDf0y'
                    'c5JCcAAIAAJCcAgJ6d88jMh6+LSQraLB8+Z4itSBUFq/sZo9X7SmV6f6iaANTlTj'
                    'sAAAAy2xdbycrhbpGD5sgqClb2ykeNMfuq9bWxzG1PeyFpGACAYCQnAICOjYT0pi'
                    'uQpKCxrjMrcUyh1YMdlt8nFpzuTa8TBIAID9oBAFila+0AsAo3IvJd0RUtHe7S6i'
                    'E9S69vTmu5z5Iu7+mDUDUBAIAob7QDAICV2onI2+Crx8PFDB8+xwPxYWryjOt6sR'
                    'LHlE6SxjX7eqRZQJ4XaE/i16Iph9f9swxUTQAqdC8i77SDAAAs4O+hIXq1JOPx9b'
                    'KQ5Jw9logFLO2Tj1rj9jVI+/dY2uv3Tq8SBwAADSE5AQDK20hI1YQpGQ9fq0lS0I'
                    '5hSob96aTLl6BwWODA4n7GaPW+0tD78hf58Z5v2Z3k7sUNAK9ttANA83Yi8k79EN'
                    'nS4W72WEhSaNIa7lHD4c/jjyLyUTkSAACqR3ICAJS3k5iqCecyH74uJiloH4BZPn'
                    'xOHFv2KgqHReR5kba0el/hHkSomgBU6lE7AACrdCUiPyjHUI+/8pdOTxs5fxpZ84'
                    'DV0uFukVgisiAs7ZUPS0koudT62lg2JHrQCACAlfuVdgAAsDIbSVU14VwnWT90dp'
                    'cmz7yuMytxTEkcW/f8f1lZ3ctYrd6Xv147AOQzfONApHG32gEAAJDYTi4l8Gv+te'
                    'Zyz/nysscSuYCVffJh6fXNaS33md9n4e/hAAAkQXICAJS1k5RVE6ZkTlAgSSFC4r'
                    'iyJylY3ssYrd6XuwehFCUAAPCz1Q4AzdrIUgK/9uGq9vrHLCcpWNonH7XG7WsN95'
                    'jXTjsAAABaQVsHALa0fmA4yE2RdbRbPWRc25mFlhNTMuxPJx2tHkK0el/Leu0AAE'
                    'S51Q4AwCpttQNAs/bimsCvXabeUiuA7LFEbLb26xSq1rh9rOEe8/gkInfaQQAA0A'
                    'oqJwBAOTfSybuiHwILtHqYraSgzfIT8rW2erC6nzFava9pVE0A2vCkHQAA4IK/ri'
                    '/zNcJWRD54X6X5pLulp+yLxBLZ6sHKXvmoMWZftb42enrtAAAAaAnJCQBQTv/yb6'
                    'UPQwskKWis68xKHFNqTVJoUav3darXDgBAEnfaAQBYnSvtANCkPupqWj0cWG71MF'
                    '5eG0uvb05ruc84/ygi99pBAADQEpITAKCMGxF59+p3NZIUsk29UEXBwsGvlTimJI'
                    '4re5KC5b2M0ep9HVA1AWjHvXYAAFbHrew+4O5aQqomnNM+XNVe/5jlJAVL++Sj1r'
                    'h9reEewzwJCf4AACRHcgIAlNHP/rSxKgpVJClYlGF/aPUQqM376rUDQH7DN75ZXI'
                    'l77QAAAIjUJ51N+xDZ0l/BirR6WGGSQutqfW3y2ovIo3IMAAA0h+QEAMjvRqaqJp'
                    'xbS6uHcW1tlg+fa231YHU/Y7RzX1RNANpypx0AgFW61g4AzbgWkfdZZtZOULByuF'
                    'skFlo9NGkt97nsSQ7JCQAAIDGSEwAgv95rdENJCtVUUbAQx5RakxRaVP999doBAE'
                    'jqUTsAAAAi9Fln1z5c1V7/GK0e0qs1bl9ruMd5O+Hv3AAAZEFyAgDk9b24VE2YUv'
                    'owlFYPdmVo9ZA1ScHKa5pavff1JFRNAFpzqx0AAGDCXznNc3AjuaomnNM+RLb0dq'
                    'DVQ3q1xu1jDfc4jcqDAABkRHICAOS1i7q6oSoKh+kXkhS0WT58zhAbrR4C1Xdfe+'
                    '0AAGTxpB0AgNW51g7AvIF/HP7pix92ah6wWjrcraHVg5W98lFjzL5qfW3C9doBAA'
                    'DQMpITACCfa0n1REiDSQoa6zqzEscUWj3YUcd90ScTaNeddgAAAHi6kbGyoMZhp3'
                    'YVBSuHu5ZbPYyX18bS65vTOu7zs1A1AQCArN5oBwAAx7IfkhY0yNAnn3TcnlIfBj'
                    'OuN77Ww9Tkpe/zEitxTOkkaVyzr0eaBeR5gbbYv6+90CcTaNWjdgAAVmejHYBp/2'
                    '73L4RGbGQqaXaQskm/48uk9dWD9vrHsscSsYClffJRa9y+Sv+5LavXDgAAgNZROQ'
                    'EA8rjupEtTNWFK6Q+Bmq0eLHzgtRDDFFo92GHzvqiasDLDNw5FVuZOOwAAq3OlHY'
                    'Bl+t0SzP+zG0Tezm5eSdpPgFv6a1uRVg+Bi2i/TqFqjdtHm/f4WURutYMAAKB1VE'
                    '4AYIu9w71QvQyHg95mnkTPvN5iJQXtD72Wn5BPHFv2KgqHReR5kbbYuq+98GQ10L'
                    'J77QAAAHC0EZGdyMID1xpPnWs+6W7pKfsisUQ8bm9pr3y0XWHgoNbXZtpOOwAAAN'
                    'aAygkAkN61iLwfn6SerQyQQukntjOvV0UVBQtxTEkcW/b37mGRNunfF1UTgPbdaw'
                    'cAYHW22gGgWr0cVU1YfOBaq5KCFktPoGePJXIBK/vkw9Lrm1P99/lJqEwGAEARJC'
                    'cAQHr9ya+68f81mKSQbepKWj1YiGNKhlYPTb13S9G9r71QNQFo3Z12AABW5512AF'
                    'YN/173iVxmWxH5w9QPnJIUStI+XNVe/5jlJAVL++Sj1rh91XuPvXYAAACsBckJAJ'
                    'DWVkTev/rdo0PKIge9pRSoolBFkoJFGfanSBUFq/sZo/x9UTUBWIdH7QAAAHDQLw'
                    '2YPbPVqqKgnaRgRfZYSFJoUn33+I9CVTIAAIohOQEA0upnf3qWpJBNg60eZpMUtF'
                    'k+VK+11YPV/YxR7r72wqElsBaftQMAsDpX2gGgKlci8sF1MK0ezta2crhbJJbIVg'
                    '9W9spHjTH7quO1eRKqJgAAUBTJCQCQzlZcv3h5PqRsrlx+gSQFjXWdWYljSq1JCi'
                    '3Kf1/77CvAnOGb/W/9kMWjdgAAVmejHQCqsve9gFYPxtY/ZrnVw3h5bSy9vjnZvs'
                    '+98HdqAACKIjkBANLpva8o2eqhdJJCtqkrafVgIY4pGVo9NPXeLSXffX0SvlgB1u'
                    'ROOwAAAC64lqmWh45o9WBs/WOWkxQs7ZOPWuP2Ze8eaYkIAIACkhMAII2teJSrPH'
                    'HW6iH7QW8pa2/1IGInjnMZXhtaPQRKf1990tkAWPeoHQCA1bnSDsCkgX9e/ZPo76'
                    'UkKUysb0WRVg8rTFJona3XZif8fRoAgOJITgCANProGc6SFLKh1UNZVuKYUmurB6'
                    'v7GSPNfX0SkfvoWQDU5E47AACrs9EOwJrh3+ycshlyI4O8T3kAudjqQSNJQYulw9'
                    '0isdDqoUn69/kgIh9VIwAAYKVITgCAeFsJrZow5fmQsrly+RnXo9VDpFqTFFoUd1'
                    '99miBQm+HbGr69xAX32gEAADChf/m3xAkKi0kKJWkfrmqvf4xWD+nVGrcvvXvcqa'
                    '0MAMDKvdEOAABO1HjgOGQ6EOxEZPilMsCQ6xPb8zrFZFxvdq/G95b2h/vS++0jcW'
                    'xF3ruHBdoSdl9UTQDW6V47AACrc60dAMy7EZF3J78z/r020ef92ekSr+VEY83z9a'
                    '18l5I9lojN1n6dQtUat4/y9/hZRH4othoAADhB5QQAiLORTr7PNvtZq4dsT6M3VE'
                    'XhMP1CJQVtK6qicJiSVg9B/O6rzxYHAOt+1A4AANaKlg6vbGTu76WJnwSfnU6r1Y'
                    'PWW8LSU/Y1tHqwslc+aozZV7nXpi+yCgAAmERyAgDE2YnI2+wHo2dJCiXWKaJAko'
                    'LGus6sxDGFVg92LN8XVROAdXvUDgDAqmy0A4BpOzmvmjAlQ5JCqbWc0OrhwHKrh/'
                    'Hy2lh6fXPKe5+fReQ22+wAAGARyQkAEG4jxz3qShw0l6iiMK5TOkkh29QLVRQsHG'
                    'hbiWNKhioKTb13S5m/r75YHAAsutUOAMCqfKcdAMzaiG8P91JVFBKv5UT7EFl7/W'
                    'OWkxQs7ZOPWuP2leceb7LMCgAAnJGcAADhdiLy9tXv5j4cLdXqYVyrFO1WDxYOtC'
                    '3EMIVWD3a8vi+qJgB41A4AAAC59Pl4Ca0e8q9vRZFWDyQpNCftPfL5GQAAA0hOAI'
                    'AwG1l6KoRWDybXW0xS0Gb5UL3WVg9W9zPGL/fVq8YBdcO31r+NhIM77QAArM5WOw'
                    'CYsxWRP0bNsIZWD1p/bbN0gF0klshWD1b2ykeNMftK89r00TMAAIBoJCcAQJiduD'
                    'wVUqrVQ9dgufwCSQoa6zqzEseUWpMU2vNZeOoDAP8dAFDeVjsAmNMnm6l0qweNJA'
                    'Utlg7eLbd6GC+vjaXXN6fw+/wH4e/NAACY8EY7AACo0EZ8e2mOB6M5Pyh2h/nHQ9'
                    '4h12Il7uV8vWy3MrNXpe/zEitxTEn82jT33s2vbzTpAoCfe+0AAGCNhn9r5y+Vkb'
                    'Yi8iHpjOPWJvq77uJ0Q7q1nCS+v+rWP5Y9logFLO2Tj1rj9uX35/ZJRPa5QgEAAH'
                    '6onAAA/r6XkF6aIvmfhj9r9ZC9kkIp2q0eLHyotxDDlAz7Q6sHJ59F5FY7CABmPG'
                    'gHAGBVrrQDMGHgn+dD0I9R+zgnQ6uHi9OtrdXDuL4VRVo9BC6i/TqFqjFmX+6vzV'
                    '5EHjNGAgAAPJCcAAD++ugZCrV6OPwrrR7cp19IUtBm+VC91lYPVvdzWa8dAABT7r'
                    'UDALAqG+0AYMa1DPI++yoZkhRKreVEO0HByiF2kVgiWz1Y2StXNcYcYv4+H4SqCQ'
                    'AAmEJyAgD4uRGRd0lmKnEw+rxGkSoKjSUpaKzrzEocU2pNUqgLVRMAnLvTDgAAsE'
                    'q9iJQ7AC1VRSHxWk60D5G11z+WPZbIBazskw9Lr29O0/fYC1UTAAAw5Y12AABwwv'
                    '4hYZ/8A914zzk/KHaH+cdD3iHXYs/rFJNxvdm9KvGauSi93z4Sx1bkvXtYoAa9dg'
                    'CwYfhaxxsWRTxqBwBgVa60A9A2/Cv/GyyHdoenVRPGbcn5uT7xGrPTlbgfC2taWv'
                    '9Y9lgiFrC0Tz5qjdvH6T0+SM7WMwAAIAjJCQDg7kZE3mU7xMx9OHo0f9aD3tKHvJ'
                    'nXW0xS0P5e0vKheobYOunyJSgcFjiwuJ8HVE0AMOVWRP6oHQSA1dhoBwAT9hd/Mk'
                    'j+w0+SFPKvb+UAO3ssEQtov06hLL2+uRxem51uEAAAYAptHQDAXX/yq1wf5Aq1ej'
                    'j8K60e3Ken1UOwWls92NzPXjsAACY9agcAAFiVG1lqd1iy1UPidg+l1nJCq4cDWj'
                    '2kZ+n1zeOziPygHQQAAHiN5AQAcHMjU1++5DrALHEw+rxG9oPehpIUZvfKymG2lT'
                    'im1JqkYAdVEwBccqcdAIBVeb88BI3rnUeWTFJIONVikkJJ2ofI2usfs5ykYGmffN'
                    'Qa97JeOwAAADCN5AQAcNPP/rT2JAUplKRQUuYqClUkKViVOLbmEmwu22sHAMC0B+'
                    '0AAGANhn9t8xTPQy9LVROmlDgAzVBF4eJ0WlUUtJMUrMgeC0kKlSOxHwAAw0hOAI'
                    'Bl1+L65UutSQpnrR6yHfQ2VEXhMP1CkoI2O4fqr2WIrfFWDw9CSUoA8+61AwCwKh'
                    'vtAKBiI7E93Gn1EE/zENnSAXaRWCJbPVjZKx81xvzajXYAAADgMpITAJjS2fy/3v'
                    'vQM9cBZqFWD4d/behJ9AJJChrrOrMSxxRaPbjqVVaFWcPXNr41RFL32gEAWJUr7Q'
                    'CgYicib6NnabXVg0aSghZLB++WWz2Ml9fG0uvr75Pw92IAAEwjOQEA5l3Lc0/VoA'
                    'SFGqsojGtIg+XyafVgI44ptHqY8yAiH4utBqBW99oBAACatpXYqgnnWmv1IEs/zE'
                    'D7EFl7/WOWkxQs7ZOP+uJ+EhL7AQAw7412AABgXH/8i/Gwc/D5dDYeYKb+QJdr3o'
                    'n5g+7bd61SH3gz79vsXuV+zVyV3G8fGfanky7f+/awwEHe/eyzzg6gFXfaAQBYla'
                    '12AGos/j26hE56SVE1Ycq4pzmTfxOvMTtdifuxsOb5+lYS4bPHErHZ2q9TqHri3g'
                    'sJuwAAmEflBAC47FqeqyacC3oqm1YPzusUUaDVw2wlBW3WqyjU2OohzxJUTQDg6l'
                    'E7AACrstUOQMPwL2vNTJCtDPKhSJWD3DJUUii1lhPNJ90tPWVfJJbIVg9W9sqH7Z'
                    'if5JCcAAAAjKNyAgBbbB2W9ksfvLwrCtRaReFojW4oUEXhsEAZBSopmK+iIKIfx5'
                    'TEsWWvAHJYJPVe9klnA9CyW+0AAADN2r/8W+4nqEs9oZ3w6frFkDWqCmhWMrD0lH'
                    '32WCIXsFRxwpWl1/fUXkjWBQCgClROAIBp1yLy3vVp6KAqCjk+yJV4Gv6oikJzlR'
                    'SyTb1QRcHCh3orcUxJHFdF712qJgDw9aQdAIDV2GoHgGKuReT3r34395PfJZ4sz1'
                    'BF4eJ0a6uiYGH9Y9ljiVjA0j75sBX3g5DYDwBANUhOAIBpu5NfORw2Brd6qDFJ4a'
                    'zVQ/aD3lK0Wz1YSA6wEMOUDPtTQauHPkkcaM7w1c63gDDnTjsAAKux1Q4AxfSzP6'
                    'XVg990a01SsKJIq4cVJino67UDAAAA7khOAIDXtjL1ZIiIcxWFoCSFHEpUUThKUi'
                    'ixThEFkhRm19ZmJVFiSuLYsifXHBYJiZmqCQBC3GsHAACtGv7FxglcYdci8n5xVA'
                    'tVFDKsMzuVVpKCFksH70ViiVjA0l650o2Zz84AAFSG5AQAeK2f/SmtHi6uUVG5fP'
                    'X1qqmiYCGOKbUmKbjr8wQBoHH32gEAWI0r7QBQxEev0S0lKSScajFJoSTtg2/t9Y'
                    '9ZbvUwXl4bndf3pviKAAAgCskJAHBqKyIfnEbS6mF6DWms1UPm9apJUrAqQ6sHAw'
                    'k2TyLyQ74gADTsXjsAAKvxVjsAZHcjIu+CrizR6qGyNWj1YGz9Y7R6SK9c3J9F5L'
                    'bISgAAIJk32gEAgDG99xXjQePMB6/xsHPw+XTmMG+QXPNOzB903wHrFJF5vdm96v'
                    'Kt66z0fvvIEFsnXZ737S8LHEwvsReRx3yLA2jYvXYAANAsi38PzuXwd9U+ao5xv3'
                    'ImOg+Z5x/XkHTrzE5XYs8srHm+voVk+CL7EHGz2q9TqPyvb591dgAAkAWVEwDgF1'
                    'txrZowxbHVQ1AlhRwKtXo4/Kv6k+jVrFdFFQULcUxpo9XDkxySE4BJw9c1nYwgwJ'
                    '12AABW5Vo7AGTTS2jVhHMttXpIXEmh1FpOqKJwQKuH9PLt6Z+EqgkAAFSJygkAbN'
                    'E89BwSZFw7PsHt/VR2rVUUjtbohoxVFI7WaaGSwmIVhUzrerESx5TElSayVgA5LC'
                    'DPC4hQNQFAnEftAACgRcNfLP6lN5uNiOySz5r7ye9ST5YnfBJ8MeTSVQW0n87XXv'
                    '9Y9lgiFrC0Tz7Sx71LNhMAACiK5AQAONhKJx+SnT3S6mF6jdytHo7WKSbjetUkKW'
                    'jHMKXOVg9UTQCQwmcRea8dBIBV2GgHUI7Fv/Dm0u1kkLeHf80wfe4D91LtJBKuQa'
                    'uHifWtHLxnj4UkhUCfhHZmAABUi7YOAHBwIyLpP9Q5lJkPbvWQ4wNo4VYP2UrmN9'
                    'jqYbbdgzZaPaSyF556BhDvUTsAAKtxpR0AktuIDLuX08Nc5dhLlPGn1UM8zXYLq2'
                    'r1MC4ScamVvfIRHvOTSILKpwAAQA3JCQBwXrYyx0Grw3zBSQqplThoPktSKLFOEQ'
                    'WSFDTWdWYljin2kxSomgAglTvtAAAA1dqLPFdNOD45zHXwmftQtdShbeIEBZNJCl'
                    'osHbxnjyVyASv75CPslvdC1QQAAKpGcgIAHBIT3r763dQHrY7zmaqiUCJJQbI/ja'
                    '6TpJBt6oUqChaSA6zEMSVxXAnfu3vhaWcAadxrBwBgNbbaAZQw/OWbdgilbEXkw+'
                    'lvHZ0c5jyYbSFJIUMVhcUkhZK0kwS01z9mOUnB0j75cI+bpH4AABpAcgKAtdvIcd'
                    'WEKQpJCuZaPeQ8aC7V6mFcqxTtVg8WkgMsxDAlw/5Evm/5ggVOhi81ftMIBffaAQ'
                    'BYja12AEiqv/yjgkkKObWWpLC2Vg/j+lYUafVAksKZvZDUDwBA9UhOALB2O5mqmj'
                    'AlR6uHXEkKOdDqweR6i0kK2qwkSkyx0+phL3zBAiCdO+0AAKzGRjsAJHMtr6omTD'
                    'lLUsihVAJBbhmSFEqt5UTz8NvSwXuRWCJbPVjZKx/TMT/IbBIVAACoBckJANZsI0'
                    'tVE87lOGh1bPXgdehZaxWFozWabPWQOUlBY11nVuKYop+k8DHd6gBAshOAYr7TDg'
                    'DJ9H7DafXgtU7CqUy1etBa83htKwfvlls9jJfX5vUt9ypxAACA5EhOAGBLV/Afn6'
                    'oJl+JMxXG+1bR6GNeQRpMUsk1dSasHC3FMydDqweG9+0kowQ4gvR+1AwCwGhvtAB'
                    'DtWkTe+19GqwetNWj1YGz9Y5aTFCztk49D3A9CUj8AAM14ox0AACjZiG/VhCmdpP'
                    '1wN55jzsw5HnYOPgs7zBsk17wT8wfdt+9apT6oZ9632b0qeZ9zrMRxLsNr00k397'
                    '7t060EAC8etQMAsBpXInKrHENeFv/OmlIn+7gJxg3qTv41qVzznq+RO4k68X3MTl'
                    'dizyyseb6+lUT47LFEbLb26xTmpvn/FgMAsCJUTgCwVjvp5G2SD2O1tHpwnDdIoV'
                    'YPh39trIoCrR5sKtPqgaoJAHK51Q4AwGpstAPIafjzN+0QcruRZO05ziop5NBSq4'
                    'fElRRKreWEKgoHRWJZRauHz8LfbQEAaArJCQBM6Qr9nxy+hBkXTRU8rR4KJSk02e'
                    'oh03q0eoiUN0mhTzczWjd8qefbQ5jwqB0AgNW40g4AUfr0B6iFWj20kqSQcKrFJI'
                    'WStJMEtNc/RquHWL12AAAAIC2SEwCs0U0n3buT30l5AKmQpBBcRaHmJAUplKRQUu'
                    'YqClUkKViVOLZOOqomAMjpTjsAAKux0Q4AwXYi8svn4qSHlGdVFHImKeRU4uA2Qx'
                    'WFi9NpVVHQTlKwokgVheaSFD4JVRMAAGjOG+0AAEBBL/JLxYGTXvAp+813ieY5nk'
                    '/m55y8pwTzBsk178T8QfcdsE4Rmdeb3avU79kQpffbR9rY+qyJNWhOlv++oWX32g'
                    'EAWI0r7QByabylw0YuPY2ctB/90WS5+tznmvd8jdx/dU98H7PTldgzC2taWPtckV'
                    'gi3rCW9uqg1w4AAACkR+UEAGtzI8dPh8iFtgipniTP8US6Y6uHoEoKORRq9XD4V1'
                    'o9uE9fQRUFC3FMiY+NqgkAcrvXDgDAamy0A0CQnYi8nR2Ro9VD8nnPlmil1UPiSg'
                    'ql1nKiXUXBSr6v5VYP4+X6+NwMAECjqJwAYG1upn7z4tPkqZ4kT/00uON8nXTrqK'
                    'IwrpG7isK4zmGBMjKut1hFIdO6XqzEMSX8vw990jiwDhb/DMC6H0XkO+0gADSP/8'
                    '7UZyOH5IRltVVROFsmi1JPlies1rAYconKEOfrSeE1La1/LHssEQvo7tOTuP53Cg'
                    'AAVIfKCQDW5FpE3s8NmKw4kPIJ7tRPgzvMF1xFIccH0NxPw59VUcheSaGkzFUUqq'
                    'ikYJH//vD0B4BSHrUDALAaG+0A4KWXpaoJ55I+5X00Wc6nx3MndpZ4Cj9DFYWL02'
                    'lVUdCupGBF9lgiNlvnddoLf5cFAKBZJCcAsKXL+I9H1nWRJIWUakxSyIlWD4HTLy'
                    'QpaLOSKDHFPbZ91jjQpG8/N93zGvncaQcAYDWutAOAs62I/CH46tqSFEolEOS2hl'
                    'YPWokC2gkSx4rEEtnqocxePQmfmwEAaBptHQCsxVY6+b3vB6nJtghWWz2Mczq0ej'
                    'gs69nuodZWDyLSDbR68Jv+QjsQKy0WrMQxZT62z8JhIYByHrUDALAaG+0AsrD4d8'
                    '1YXaL2YknbABxNlqu9AK0eJqeSuek0SvqXbi9xvrYorn/McquH8fK8+9QLf48FAK'
                    'BpVE4AsBa9iAQ9ed1iq4fDMENVFEpUUpBCrR5KV1LINnUlrR4sxDFlOq6+bBAAVu'
                    '5WOwAAq3GlHUBqw5+brFp0JSIfks1WWxWF3HOXmD/DGovTramKgoX1j2WPxWSrhw'
                    'ehagIAAM0jOQHAGmxE5PuT3wk40GwxScFcq4ecB81nrR6yJymUot3qwUJygIUYpp'
                    'zuz2fhoBBAWY/aAQBYjY12AHCyz3KgWGuSQk6tJSmsrdXDuL4VRVo9mElS6JPOBg'
                    'AATKKtA4A1uBGRt69+N7A0/GRbhJRl5lO3UHCIzUyrh5zzHs8vhzUuti9IvE4RBV'
                    'o9HKa/0O5B+8sb+60eet0gAKzQnXYAAFbjSjsALLoWkfcvv8pRNj55qwc5TFhrq4'
                    'dxjRKtHiTdOrMh0+pBT5FYIjY7TXw/isjHqBkAAEAVqJwAYA12sz8NfPp78mlyq1'
                    'UUxjkXh3hWFKi1isLRGk22eshcSUFjXWdW4jhF1QQAWh60AwCwChvtALCon/xd01'
                    'UUxglzzHu2RO2tHsZ1Ek5FqwdD6x+z3OphvDzcLupqAABQDZITALTuexF55zQy4F'
                    'CzxVYPh2ErafUwriGNJilkm7qSVg8W4jjotQNAvb791GTPa5Rzrx0AgFX4TjsAzL'
                    'qR46oJ52j18MvcOdHqIZ52koD2+scsJymEXUpCPwAAK0JyAoDW3XhfEVhFIXuSQk'
                    'oOsQUd1teapHA0f5EkhVIKVFGYTVKwQD8OvmQBoOlOOwAAq7HRDgAX9U6jSFIol0'
                    'CQG0kK+de3InssxZIU+rBFAABAjUhOANCyrYj8PujKiFYP2ZIUamn14DhvkEKtHg'
                    '7/2lgVBVo9aOnVVgYAkUftAACsxpV2AKkMf26qatGNuFYSHOU69E862VGSQg4ttX'
                    'pInKRQai0n2gkKVpIUisSStdXDJyGhHwCAVSE5AYAtXdJ/bpLF433ZxEW0ekijVK'
                    'uHrtFWD5nWo9XDJKomANB2qx0AgNXYageAVzYisg+60nwVhXHCHPOeLdFKkkLCqR'
                    'aTFErSThLQXv9Yva0e+rBJAQBArd5oBwAAGd28HETGfkALmGc8qB2OL0oVT+q5HO'
                    'ebvKcE8wbJNe/5GkPgfQesU0zG9Wb3qsRr5qLcfu+LrIJmffupqSc3AQBt22oHkI'
                    'z231VT6WQnIm+j5hj3ImWCb9I5jybLEevxMjmTnHPGnmmN2elK3I+FNc/Xt5CQL1'
                    'IglojNfn3pJxG5jwwIAABUhsoJAFr1vRyXr0zZWsH7koytHsa5UnKILbjVQ42VFM'
                    '5aPWSrpNBQFYXD9AuVFLTl3+8HEfkh6woAsOxWOwAAq7HVDiCF4Z+bSQzciMgu2W'
                    'zmKymctXrI1Zoid+JKpa0eLk6n1epBK8FoVVUUxkUiLh3kSVL+dwoAAFSD5AQArb'
                    'qZ/N1UCQopWz0oxrQ45+KQwCSFHAq1ejj8K60e3KdfbauHPsusAODvSTsAAKuw1Q'
                    '4AJ3oZ5G2WhILUcrR6SD7v2RK0evCbTitJQcuqkhSiFtiLyGOqSAAAQD1o6wCgRV'
                    'sR+f3Fn1pr9TDOVWmrh8OwjlYPOdY5LFAGrR4O0sTxICIfk8wEAPHuROS9dhAAmr'
                    'fVDgAvtiLyh5dfpS53T6uHV8tk0Vqrh3HA2lo9aK5/LHss3gs8iche/XsAAACggs'
                    'oJAFr0vdOo1ls9pPzQSauHi/NnbfUwrlWKdqsHC1/apImhTzILAKRxrx0AgFV4tz'
                    'wEhfSTv5v6CWpaPfwyd06l2knQ6iHv+lYUafXgtEgvVE0AAGC1SE4AYEqX4P/Et2'
                    'edcquH7EkKKdWYpJATrR4Cp19IUtAWd/9UTQBgzb12AABWY6sdAGQrIh9mR5hOKD'
                    'iaM+lkR0kKOZRKIMgtQ5JCqbWcaCYpaCdIHCsSy+wCD3Jo6QAAAFaK5AQArbmSkK'
                    'd2UlZRCExSmJwrhRwHzQ7zBScppFbiYP95jSJVFBpLUtBY11lYHH3yOLBK3376ph'
                    '0C2nGnHQCA1dhqBwDHJFnzCQWSIcZCVRRyHvqWOuAuVUXBaUAG2lUUVpOkcHGBPu'
                    'eqAADAvjfaAQDAifgDyV03zPS3d10/9gNawDzjQe1J3KniST2Xx3yddH6vReo4c8'
                    '97vsZw4bVMvc5hgTK6fGvN7lXp+7zEPQ6qJgCw6FE7AACrsdUOIMbwz9UnBl6LyH'
                    'uvK1L3oc/R1z7pnEeT5Yh1Ypkscs+fYY3F6YZ0azkpsYeW1z+WPZaTBT4Ln5kBAF'
                    'g9khMAtOb7lzL7g+eh+LGUSQqec7SYpBB0WF9rksLR/EWSFEomKEi+9apJUpiPoS'
                    '8SBwD4udUOAMBqbLUDWLk++EqSFPIlKVSUQFBijdnpNA7stZMESidlzMkeyyDCZ2'
                    'YAACC0dQDQlu9F5O3Lr1KU2Vdu9fAq9pTl7tfc6iHnvMfzj4kytHrwmH7mPWLhS5'
                    'vL90/VBAAAsHZb7QBW7HvxrZowxXxrhtTzHQVYa6uHcY3cEt8HrR7O1tZOxB/lje'
                    'WzkDQLAACE5AQAbfn+1e88HyRGJSmkOoyNSFKYnCuF1AfNjvN5vx65DsRLHOyneA'
                    '96rFNMgSQFjXWdvY6jV4kDANx81g4AwCpstQOIMlT9zz7ZgaL5hALJEONRgkKtSQ'
                    'qlDrgTJygsJimUpJ0koL3+sTyx7JLPCAAAqkRyAoBWbETkw8WfVp6kUKSKglKSQo'
                    '55vZVKUpBCSQolaVZRsJKkIPIkIj+oxgEA8x61AwCwClvtAEINT9+0Q4hxIyLvRC'
                    'TtgWLqw8lcSQ/J5jyropAzSSGnUpUaSiUpaFVRIEnhIF0cn0TkLtlsAACgaiQnAG'
                    'jF906jjpIUgqVMUvC+pMJWDwtzBrd6qDFJ4azVQ7YkhQarKBhv9bAXDv4A2HanHQ'
                    'CAVXinHcAKbWSqglfqpIKUSFKg1UPIdGtNUrAgzT700TMAAIBmvNEOAAAS+d5rdC'
                    'fSDYdTzSH0U1Yn8R/QxoNVz3nGg9qT2APnShXT4pwL803eU4J5g+Sa93h+OazRSR'
                    'f+HvRYp4jM613cq9L3eepJRPYmkiTQjG9/rfrpTdh0rx0AgNXYCv/NKWknl5JCxr'
                    '8bp/h7asq5judM/XfopHMe3XSOWM+WyCL3/JnWmd3uUvd0vqbW5z2N+70kPJZ/FP'
                    '53AQAAHKFyAoAWbETk995XVd7q4XDZxEW0ekijVKuH2PegxzrFZFzPYKuHvVA1AY'
                    'B999oBAFiNrXYAK7IRlx7utHpIMGGOec+WyJloXaoCQKkqConXcmKhikKdlRSehK'
                    'oJAADgDJUTANgSdrD4vYiEf1Aby+zHVFJIWbXAUhWF1HM5zhdcRWFh3iAlnsp/ft'
                    '2D7jtgnWIyrje7V+UqKRyqJgCAfXfaAQBYja12ACuyE5G3zqNTPv2d+mnuXJUZks'
                    '15VkUh2bwTy+RMti7xFH6GKgoXp9OqolB6zfP1LVRREHGNZS8k8wMAgDNUTgDQgu'
                    '9FJP6p6aOn2KPmiBVRReFV7CmfJE/9AdghtqCKArVWUjiaP2slhYaqKBymX6ikkN'
                    'de+KIFQB0etQMAsBpb7QB8DU9VtlPaisgfva/KUfkgJfOVFI4my/Uke4kn5EtVUU'
                    'hcSaHUWk40KxnUU0WBZH4AADCJ5AQAtdvIeUuH2APJVls9KMa0OOfikMAkhRwKtX'
                    'o4/CutHtynL97qgS9aANTms3YAAFZhqx2At6HCf2LLpKc83MyVUJBajlYPyec9W4'
                    'JWD6+mMpmkoMV+ksJOSJAFAAATSE4AULvryd9NWEWhxiSFi3GnrKKQ8sDXcb7VVF'
                    'EY15DMVRTGdUonKWSbeqGKQtq198IXLQAAAOe22gGswFYG+ZBkJstJClRRyD93if'
                    'kzrOGUpFCSdpKA9vrHfonlQUQ+aoYCAADseqMdAABE+n72p7G958cD4mGmv73jHN'
                    'EfFjv/OcaD2pO4U8WTei7H+SbvKcG8QXLNOzF/0H37rlXqC43M+za7V2nWpmoCsv'
                    'n21ypLS6MOtyLyXjsIAM3bagewAh9F5Je/z6ZIwB0SzTPOJYbnSz7n0WQ5Yj1eJm'
                    'dSec7YM60xO12J+7Gw5vn6WmufGyKruwAAgKZROQFA7b53GpWwkkLUHLEiWj28ij'
                    '3lk+Q5Wj0szEmrh7zrFFGg1cNsJYVwH4WqCQDq86gdAIBVeKcdQOOu5TzRLNVT0z'
                    'kqH6Rkvn3EWSWFHEpVOcgtQyWFUms50axkYKOKwmehagIAAJhBcgKAml2LyFuvK2'
                    'IPQitu9XC4rKJWD+Oci0M8X4/aWz3Evgc91immQJJC4nX3wcEAgJ477QAArMZWO4'
                    'CG9Rd/YrE9g/mEAskQI60evNZJOJWpVg9aax6vrbd+r7YyAACoAskJAGr2fdBVCa'
                    'so1JikUKSKQsqDZsf5gqoo1JykII0mKWSbeqGKgvvan0TkPkVMAFDYvXYAAFZjqx'
                    '2Aq+GxqnZK17LUnsdqYkGOqgz/f/b+JkmO7EoQNc/1AH8i+AMwH6VyUEIJ1AqIN2'
                    'uRFulATXvCyBUQnLdIIleQxhWk5woSsYJGrCAdvYH2GLX0oOU5JLtePVazku5ZlQ'
                    'wmMyK0B+bqMDO3H72q96qqmX0fxQVws3vPPW4AEW6uR8+ZdZHCRhcFRQqjnbE33L'
                    'l1UZjm/HexHCUGALDTk6kTAFiTd3Hy84jo/0Zr6Oz59gJxk7bPth8jh9U4mTHaC7'
                    'VruZfKp2dOB+PF/phbv6YCcXupFXdL/F5fd+5ZY/1Ao/Lrtve16nb2omxGAKO5mT'
                    'oB4Gw8nzqBE/Wm88r2+9kSxb8l59iXjNXGiznHXAlWI9fVY2oWldeO354R5c7ZG6'
                    '7mn8UuU5y5ef44Z78e5RQA4KjpnAAcq+fRzjMtMKph6P7Bd7BPPOqhWieFYxn10D'
                    'FuLyONelj+9sS6KEwx6qE9eztdE4Bj99XUCQBn4fnUCZygV9G+/80xx84Hs+96sB'
                    'KzaLCVTgo1nEIXhQrnHBz1MEUnhanU/3q/CGPEAIAOdE4AjtXna58V6oJQoovCMk'
                    'yPQCW7KPSIk2JLB4hSd8yXvhu+Y7ytX1OBuNlqd1FYOWPQ38GMc06hk0KPLgqL8l'
                    'nAB9/921G1luY43U6dAHAWnk+dQGdTXijMkQZ8H1q6i8IcY63GnG0XhTbgCF0Uas'
                    'UeI/7qOWN0USh8Vidz6KJQ5/xF8YgAwEnSOQE4Vi+3Pjr0butC+wd1Upiwa0HVLg'
                    'qlY3WM17uLQo0fFIzRfWCli0L1TgpjqtxFYedr9eHPTNcE4BRcTZ0AcBaeT51AF8'
                    '0fjqYocBFNj64Jm+ba/aD03dyz78yw0UWhZieFmsboOlChi8LOcFN1UTidTgq/De'
                    '+XAYCOdE4AZqXrxdQmml8dCNQu7JtIkf2pybxzv2QOq3F6dFFYHt2sPlgmn545HY'
                    'wX+2PuvUt+QNxeancfWInf6+vucc4oKp93oJPCos6pAKO6nToB4Cy8mDqBE/Is2h'
                    'nupe52Lt39oFQR8ey7HpSOuRKs1p3sY9yhP0bXgcJfx95wU3Q1mEMnhWFn30XEZY'
                    'lUAIDzoHMCcIxedr4rfOibuwL7B9/BPlEXheW2ip0UanQR6PRXomcnhRrG6KKw0k'
                    'lhjHNGUfm8La+VrgnAqbieOgHgLDydOoET8jo2X8+SHQtKxZljrNWYpRWNudFJoY'
                    'bad+iP1QGgQieFsc7q5Hi7KFyGAlgAIIPiBOAYfd7+ptOFZqMeBsfZmvcRj3pYLj'
                    'Pqoco5J1KksPFaLeqcAh9896ejaS3NcbudOgHgbLyYOoET8DzargmbSl04nWthwd'
                    'mNemgD1oi7ccSpFCkUDHWwSGFMxzfq4X3omgAAZFKcAMxL6vTx8vE2RQrZcbK3VO'
                    'yiUDpWx3i9uygcY5HCRheF6kUKY6rbRUHXBOCUXE+dAHA2nk2dwAlYxKEuFHMtUi'
                    'jl7IoUNroo1CxSqGmMC+wVuijsDDdVF4WpixS6WYTiVwAg05OpEwDI9CwifvlwMX'
                    'LjDVOKtH1e/PqirXs7K7Q/NR1y3Rdj6BvVnl9He1F7Lfehr8n6AWXfhHfIbevXVC'
                    'BuL6W//m3xY3lGp/+/FDhnFPXOe1O1kANgfO8j4tOpkwBO3ouIuJo4h52aP8y+Y9'
                    'HziPh159WlZtbPLc5qvJLfkpfOr3jMlWA1ct04oprSf267zohy5+xNeYzXbA5ndj'
                    '/7fUS8GSMVAOC06JwAHJuXa59tudu8813hQ9/cFdg/my4KJUc9TJjTwZgHl/TspF'
                    'DaWKMehv4dzDhnNGXPexcz/qE6QE83UycAnIVnUydw5C577Zpb94M5j3poY5ZWY9'
                    'RD8bgbRxj18CjUwVEPU3RSmMrur/f1qHkAACdDcQJwbF5ufbRvkYJRD4Pi7Mz7iE'
                    'c9LJedyaiH9ow40SKF4RZFogDMy/XUCQBn4cXUCRyxlxHxq9675zrqYY6xasQrHn'
                    'PEUQ/HXqQw5qiHOPRkBXMY9fDh/HcR8XaqVACA42asA3BsXu59dktL/LMa9TAkh9'
                    'U4cxz1UCpWx3izG/VQI+6W+L2+7tyzjmPUg64JwKm6nToB4Cw8mzqBvaa8wHfYIi'
                    'LmM1qhZFv5km3+a4yOKBmveMwRRj20x9Qe9RDHdcbecOc26qE9PynkBwD6U5wAHJ'
                    'NnEfHLg6u2XJDsfMF16IXTAvvT/Q8bBhUplChQiPw4oxQplPxBYs0ihRo/8Kx9YX'
                    '+jSKFqgcL9OaPod96ieB6ww7dffzt1CpyXq4j426mTAE7ei6kT2KX5w3dTp7DPy4'
                    'j4LCLKFhfMqbCgRlHBbAsKVmIWi7dRpFCrQCEqxV49o/bF9QpFCjtDnVeRgkJ+AG'
                    'AQxQnAMXmZtbpvkcLUXRTuY6RmwB3sJbso9Iiz9cJ2qQvrNS5sd8gtu0jhWLsorJ'
                    'wx6O9gxjkzLFLwwxbglN1OnQBwFp5OncCRunz0SIkLkHPtojDHWKsxZ130cJ9g7S'
                    '4KtWKPEX/1nDG6KBQ+q7Pxz3w18+4zAMDMXUydAECGl712bZl1n+7/l7tv6Ll99n'
                    'fKtVYOA+JszbtUPqVjZcTL/rMonWftuJtnxMC/g13PGfOHKYfPWtRPAmAy11MnAJ'
                    'yNF1MncGRexb5OgSUuBpaaWV8qzpxj1YhXPOZKsBq5rh5TU83cK52xN9wYX890Z3'
                    '4RETejnAQAnCydE4B52X/R8EVEDOto8Ohm/g6t66fupLByF/ugUQ9DcliNY9RD/1'
                    'EPB+L2Urv7wMaoh+VvK3ZSmL6Lgq4JwDm4C3c1A/U9mzqB7eZ4y2+K6FIgO7cOCK'
                    'W7H5zbqIdiMTdGPRSLu/2Iao501MPOcKc56mFRLTIAcDZ0TgCOyXL25pC7rPt2UW'
                    'j3DlFg/+A72CfqorDcVrGTQo077zt2UejVSaGGMboorHRSGOOcUTw+bzHi6QBTuZ'
                    '46AeAsvJg6gSPyOiI+7by6ZAeEEubY+WD2XQ9WYhYNttJJoYbad+iP1QGgQieFsc'
                    '7qpM55vw1dEwCAAhQnAMfi5aNHpihSMOphcJyteRv1UMZYox5KFMp0PGc0y/N0TQ'
                    'DOxc3UCQBn4dnUCWxq/vDt1Cls8yz6FsiWuOhp1EO/mKXjFS9SqBF344hTKVIoGO'
                    'pgkcKYyr6GdxFxWSwaAHDWjHUAjsWLnc8MaQW/Y9RDxIHW9TMa9bAM0yNQyVEPmX'
                    'FGGfVQKlbHeGc16qE949RGPUS8GbUgAiLi2z/O8iIJp+9m6gSAs/Bi6gQemeNEh4'
                    'jXkZr7UTs9vxkt0Q7/HEY9xIzjFY85wqiH9pjaox7iuM440VEPlxFxOzATAICI0D'
                    'kBOB4v9z5buIvC8uGOox5m0klhshxW42RvqTjqoY1VUofceo96OMZOChujHqp1Uh'
                    'ini8L7iHhT/RSAebieOgHgLDybOoEj8CwiXn+4w3nArc5z64Awtzir8Uqa/fiIjV'
                    'EPNQp0xuhycKSjHnaGm2rUQ78z34euCQBAQYoTgGPxotOqKUY9tHuHKLB/8MXhOY'
                    '56mDCngzEPLulZpFDDSKMelr892lEPi2qRAebnduoEgLPwYuoEjsBlRDx9+KxZ/c'
                    '0MihRKmON4hmMY9VA8ZrP1t0Wd0qiHwkUKY53VSf55i/C9IwBQkOIE4Bg8i4hPs3'
                    'ZMUaQwoy4KvS8QT1gQsDPvkl0USl7Y7hjvbLootGdE5S4K7Tllw+uaAJybq6kTAM'
                    '7C08NLztrziPj1o0fXLlYOuGpZ4qLnHLsfzDVWjXjFY47QRaF27DHir55TMNTBIo'
                    'UxdX8NvVcGAIpTnADMS9r68WJQocGQXB49dFyjHmZRpJC9ZYRRDyMXKRj1UPGsMh'
                    'bFIgEcj7upEwDOwoupE5ixxd5nS4x6aLcPNdcihVIUKdQxxqiHIzvjCEc9vB4lDw'
                    'DgrChOAI7By4jof1F1ylEPMylSGBRjqAGjHqoXKZR0jEUKNR3PqAd3ggDn6nrqBI'
                    'Cz8GzqBFrNP387dQqrXsa2rgnblChSmOOoh7kVO7TxSlKkMF4BQW3nMOrh8ZnvIu'
                    'LtyJkAAGdAcQIwK2n7/16sXdwsWGgwZG9WkcIQBfbPpotCzyKFrbFKqHHhv+Ooh1'
                    '5FCqWNNeph6N/BjHN6WBTNAzJ8+8dZXSTh/NxMnQBwFl5MncCDZkYffb4HPbVRD2'
                    '2sUnHmGGs1ZmlFYzZbf1uUUQ9bQ82ySOGDxcinAwBnQnECcAxeRGxc3BxaaNBX3y'
                    'KFGXVROMYihVMc9bBcNqMuCmMUKcTsihR0TQDO2c3UCQBn4dnUCczQy4j4rNdOox'
                    '6OM1aNeMVjjjjq4diLFMYc9RCHnqxgmdCXEXE18skAwJl4MnUCAB18uvpJihRN++'
                    '6svQiZ+2at777V/c3mQyt51Ty3wP7UdMi1Vg6rcTJjtBe113IvlU/pWB3jbf2aCs'
                    'TtpVbcLfF7fd25Zx0OvahzOMBRuJk6AeAsvJg6gRm6jCaGFQe33+emh98MiDEgjz'
                    'nGaWOVqocumVeNeMVjrgSrkevqMTUL5GvmXumMveHG+HrWvR69KAIAOBs6JwBz93'
                    'Lbg4/uvu575/c5j3pIA+9gn3jUQ/VOCiV1yG02ox5qxl2Nv9JJYYxzttA1ATh3N1'
                    'MnAJyFZ1MnEBHR/PfZjFJ6FRG/jIhyIxaGBivZAaGEOXc+KGn24yM2OinUMFaXg9'
                    'oqdFIY66wdvgjfJwIAFSlOAObuxb4ntxYp9DFFkcLUox7uYxzrqIflti2b5jrqoY'
                    '15cEnmn8exj3oY+ncw45wNl/UOhMO+/eNsLpJwvq6nTgA4C8+mTmBmFo8eGXqxcW'
                    '3/wFEPJYoljHrIj1k6XvEihRpxN4449lEP7TkFQ0006uEudBgEACpTnADMS3r08T'
                    'z7gu7QQoO+jrVIocQF4gmLFEbpolDyunnHeL26KBxzkUKMWqRwF7omMLGPPvlo6h'
                    'TgduoEgLPwy6kTmJFXsTGycE2xIoWBgeZUXDDXwoIaXRlmXaSw0UWhZpFCTWN1ah'
                    'irSKHO13MZuiYAAJUpTgDm7kVEdL44Ovmoh3b/o4c6jnqYSZHCZDmsxsneYtRD17'
                    'i91C5S2Bj1ULlI4TJclAOIiHg3dQIAZ+JZdO3cVax7wUxGPcwpThurlFkXFNSIOU'
                    'KRglEP+eHKnXUXOgwCACN4MnUCAAe8ePhde63ywJuu9qJm0y5Mh/fsCNTpvK57H+'
                    'W1b++QN5YF9qemY661cmhjRH6cra/zkD/LAjkdjJn7d7pQ3F5qxV2NH8szUqT+fw'
                    'd3W/7ApXY3CDjg23811oFZuJ06AeAsvAijZF5HxNPOq9tvgYd8z9q0+wcEK5HHWi'
                    '4zihMzjLUas/T7laIxV77oGrluHFFF7fiVztn7cg8/6zJ8bwgAjEDnBGDOnsW2H+'
                    'BktMUvNuqh4F6jHsaJszVvox7KGGvUw9C/g9tdhh+4ALSup04AOAvPpjy8+e+TFw'
                    'Q+i2VxQr5iox4iBgUqcWf2XLsozDFWjXhVYo406qFmcfwYnRracwqG2huu31nvI2'
                    'LRaycAQCadE4A5e7H32Y53cK/ddT60G0LfN5Rb9na6G37onfqF9g/qpDBh14KqXR'
                    'RKx+oYr3cXhQNxe6kVd/OMpufX/Zg2lQDrbqZOAKC6MS487reIiKdluiAM2B8RkQ'
                    'beWl3iLvmS3RhKxGljlaqHLn1Hfq3ODMVibnRRKBZ3yzE1C+TH6KRQoYvCznD5Zy'
                    '2GZQMA0J3OCcCcPT+4IuMO7rW7r/ve+V2hA0Onu8Jn1ElhshxW42Rv2XL3fcm7/0'
                    'v/AKNDbr06ChxrJ4WV+AM7KVyGrgkAq26mTgA4Cy+nTmBCzyPiryOicBeEoTEGBJ'
                    'tbB4S5xVmNV9LsOymsBKvVjWCMLgdjdVEYq5NCt7PeR8SbYgkBABygOAGYs+edV/'
                    'YZ9dDu62OKUQ/t3iEK7B/cZn+Oox4mzOlgzINLehYp1DDSqIflb7MP0zWB2fj2Xy'
                    'dvLw2tm6kTADhxi0ePzKVIYWiwkkUBJcxxPEOtgoLSaox6KB534wijHvLC7f+aXp'
                    'XNBABgP8UJwLyktY+XvfcfXLZyQXdooUFffYsUZtRFoXeRwoQFATvzLtlFoeRF+o'
                    'y/0zXiZqvdRaE9I7L/Dl6GrgkAm26mTgA4C8+nOrj5/aQFgS8i4tc7ny3WBaHE/g'
                    'GBinZ0mEmcOceqEa94zBG6KNSOPUb8CmccDPf4yXcRcVUuAwCAwxQnAHP2rPeFzm'
                    'MZ9dDuf/TQcY16mEWRQvaWEUY9jFykYNTDTromAOz21dQJACfv+dQJTOTy4IqiXR'
                    'AG7B866qFEHgVSKB6njVWKIoU6jqyAYIwzMkY9LMqdCgDQjeIEYM5++fC7Phc6h4'
                    'x6GLtIYepRD4WKFAbFGGrAqIfqRQolHWORQk3dRj28CV0TAHa5nToBgBP0MiI+67'
                    'zaqIcduRSIM7dihzZeSbMfH7FRpFDDWAUEtVUoUtjz5JehawIAMIEnUycAsMOzrY'
                    '+myH+j1l6vPLCvvbDZtAv7nJVxXte9j/IqfeZqjIH7U9Mh133nx8AcBsRJkR7nPf'
                    'Q1GZjTwZi5f6cLxc1W4+vfccaOv4OXFU8GOHZXkXMBDSDfi8lOHuNi4jap593Ibb'
                    '59C3yL7m/6BxqaR6kYq7FKxYkZxlqNWTpelIx5n2CNr331iFqxx4i/ek6hM/ak/H'
                    'qyfyMBgLOmOAGYqxc7n+l7obNPkcLQQoO+b/SmKlIotP9YixS2vsYlL6yXvkif8X'
                    'c6u0ChQ9xsYxUpNGt/ll+EmeoA+9xOnQBw8p6e2QWwV9HEZ4MvzE95Yf9h/8BAJS'
                    '6wlroYPNfCgtIXu2sVPRSLuRJMkcKoZ2yE8z4ZAJiM4gRgrp4dXDGkSKHDnrULup'
                    'ULIvbuf3Qzf4cLzTMqUuhVoFAih9U4PbooLI+uWKRQuotC7I/Zu4vCgbi91C5SWI'
                    'mfIi0qnQK9fPM/v5k6Bdh0PXUCwFl4FudTDLWIiOm7ILQxihQ5DEhmbsUFc+zI0M'
                    'aKGccrHnPEIoUjKiAY44wm4i6iZ3cXAIACLqZOAGCHF51XrsycL70n3f9v0FlD9u'
                    '3Y+yivfXuHKLC/c661cmhj9IizNfchf5Y14mzGPLikx59HrR+01G6FmdwNAtDBzd'
                    'QJAGfhxdgHNr//duwjIyJeRcSn64nEsKLcqfe3MYYGK5HHWi4zilOy6Lp0AXfp/N'
                    'qYRYM1FeJuP6KaMbrDlPs6LsP3fwDAhHROAGYlpYerlc8iIpom8y7vMUY99D0r47'
                    'yue416GCfO1m4VpbofTDjqYbms48HH2UVhUb0AAuD43UydAMCJeBb77kYu0UlhFq'
                    'MeBiZTqiPE0Bgl48w51mrM2XZRaAMa9dD5nP5n3MWyOAEAYDI6JwBz9SJirVihmy'
                    'GdDTotW7nrfGg3hL76dlIYeqd+of2DOilM2LWgaheF0rEy4vXqolDjhy3l4+qaAN'
                    'Dd+6kTAE7ei7EPbEb+iIjXsdk1YVdiQ7+oIYp1YhgYqFQXhTnFmXOsGvGKx9zool'
                    'Czk0JNY3Vq6HfGZZzPiB0AYKYUJwCzl1Iap0ghY8/kox7a/Y8e6jjqYSZFCpPlsB'
                    'one8sIRQoldcit96iHeRcpLIpEATgPN1MnAJy8Z2Me9t34Ix2eNRGvO18rnNWohq'
                    'E5zGTUw5zitLFKmXVBQY2YIxQpjFVAUFve1/E+vE8GAGZAcQIwV59tPtC7SCFXxh'
                    '3nj4oU+hjagaFPF4V27xAF9g/qolAihzbG3IoUalz47/N3ulDcXobF1TUBIM/11A'
                    'kAFDV224QmXkfE09Wjs/Lsa+r9bYyhwUoWF5Qwx84HtQoKSisac6NIoYbaRQpjFE'
                    'F0P2dRPQ8AgA4UJwBHJ7tIoXJng6KjHsYuUphRF4VjHPWw3La1hUUZRj30jbsomg'
                    'cU8s3/+GbqFGCX26kTAE7ey6kTqOh5RPzt5oXBrOuRJYoMhiha5DBw1MPUX0vpOH'
                    'OOVSNelZgjjXo4lSKF7b6KiDcjZAAAcJDiBGCOnndZNMqoh3Zfp2UFixT62jHqQZ'
                    'FCZpzsLSOMehi5SOGIRz18GbomAOS6mjoBgCO2ePjdxgXI7OuRs+mCMDSHgcnMqb'
                    'hgzqMe5hyveMwRRj20sWsaa5zE4zNeVz4VAKAzxQnAHD3vurD3qIfcC6gZex6Neq'
                    'jYtSFnb+dRDzMpUhgUY6g5jnpoY5V0mkUKlxVOBjh1t1MnAJy852Md9N3/79uxjo'
                    'pYfl2/fvTokCKFqUc1FO1eMJNRD6cYZzVeSYoUxisgqO3D1/EuFKICADPyZOoEAN'
                    'asXnjMeLPWFig0Tc6mvDMe9sThfe3F3KZd2OesjPO67n2U1769Q94sF9ifmo657j'
                    'o/BuYwIE6K9DjviXM6GDP373ShuL3sjuuHLgD9XE+dAHDyPp06gUre7H22/Z41ff'
                    'i0cw3vxt5sU+9vY6SBwUrksZbLjOLEDGOtxixdcF405kqwGrm2caNS7DHifzhnUf'
                    'kEAIAsOicAc/QiInrdfT3qqIdOjQhmMurh0c38Rj3UjrMz7yMe9bBcNusuCosKJw'
                    'Gci/dTJwBwZF5GxGedVk416qHU/mKdGIx6OJpYNeIVjzniqIeanQ7qxv8iFPADAD'
                    'OjOAGYo2drn2Ve3Bxt1EO7r9OyiUc9tPsfPXRGox5KFSlkbxlh1MPIRQozHfWgaw'
                    'LAMDdTJwCcvBejnNKM9JFbGLtxATLremTRAoEBMYbubwYmM7figtKFBaUoUqijZo'
                    'FCG7/8GYviEQEABjLWATgemS3ie496iLxzuu7ZOuoh96wh+3bsHXXUw8bZuftTpI'
                    'gmc7TAZg5D3+wPGPWw3Lb24veKteOAsj/I6JDbzEY9LCpEhWK++Zdvpk4BDrmOrn'
                    'cAA/TzbOoECvo8+v6budHKPauz+9A28FPvb2MY9bA7ThSK1cYrPeohKsQsOuohlg'
                    'FLf+1bjqimXO5fhOJTAGCGdE4A5ujFzmd6jnro1UkhV59RD33Pyjiv695RRj20MQ'
                    'buP9ZRD8ttRzTqoY15cEnmn0f5PHVNABjuduoEgJP3bOoECros0s1g96eH9xY8u9'
                    'f+Yp0cBgQq1RFijl0U5hhrNWbpeEVjjtRFoWYnheHx7yLidYlUAABKU5wAzNGzgy'
                    't6Finkbcg/I2ff2gXdoYUGfU1VpFBw1MMxFimc4qiH5bLJRj0sikQBOG/XUycAnL'
                    'wXtQ/47r99W/uIiIhXEfHpw2dDLiIOGfXQbuhrDhf2S4x6aLcPpUhh2njFY579qI'
                    'fLUHgKAMyU4gTguI3VRaFvkUKnZRtdFCoWROzd/+ihTlejZ1OkMFkOq3Gyt4xQpF'
                    'BSh9x6FYwM+5p1TQAo43bqBACOwLPYVRg7VZFC0S4GA2IM3T+0SGFuxQWlCwtKmX'
                    'VBQY2YIxQp1O6i0J7R3V0sixMAAGZJcQIwLynyL1SOOeoh9wLqkFEPYxcp9O2i0O'
                    '4dYupRDyVyaGPMrUjhWEY9dIy7xaLXLgA2XU2dAHDynk+dQAGvY7VrwjYFCwWOqk'
                    'ihaJHDTIoUSphj54PZFxSsxCwabKVIoYb5jHpYhKJTAGDGFCcAc/RZRFQrBFjb0r'
                    'dIIdeQIoU+pihSmFEXhWMc9bDctrWFRRmnOerhq3AxDaCku6kTAE7a85rBRxjp8C'
                    'y6znAvcaF/96ejnt1rf7Eih4GjHqb+WkrHmXOs1Zil4xUvUqgRd+OI6YoU3oeuCQ'
                    'DAzClOAOatYreCtS0zHPXwcFF3aKFBX4oUhuvzd7FmF4XSsTrGqzjq4TIvKEzjm3'
                    '/5ZuoUoKvrqRMA6K2p/LEsTHjaK6chX0/fUHPoglAkh4GB5lRcMNfCgtIX02ffmW'
                    'GEUQ9t7Jq2576ofCoAwGCKE4Dj0LdIIWf5zEY9LJdOPOqh3f/ooY6jHmZSpDBZDq'
                    'txsreMUKRQ0vhFCu8j4k1eMAAOuJk6AeCkvZg6gQGeRxOvSxUaDNl7VKMe2hhD9w'
                    '8tUphbcUHpwoJSZl1QUCPmCEUKtbsotGcsfRXeIwMAR+DJ1AkArGovXDa73r2lyH'
                    'tj117UzNjTFig0Tc6mvDMe9sThfY9ekz5nZZzXde/BP6vVvUPejBfYn5qOudbKoY'
                    '0R+XG2vs5D/iwL5HQwZu7f6X5xF1l5AdDFzdQJACctr+vAvCyizb/9nrRPsW/Tc9'
                    '+Wc7PSGJLzHPa3MdLAYCXyWMtlRnFihrFWY5Yuji8ac+WLrpHrxhFVfOjuAgAwez'
                    'onAPPyMMlgzx3WI456yOqkULmzQdFRDwX3GvUwTpyteR/xqIflst5dFHRNAKjjZu'
                    'oEgJP3bOoEengeEb9+9OgUXRS2nJs96qHg2b32F+vkMHDUw9RfS+k4c45VI16VmC'
                    'ONeqgT+11EXFWJDABQmM4JwNy8WP0kRdrfRSFilE4K2V0UMs942Ndhz9pd50O7If'
                    'R9U7xlb6e74YfeqV9o/6BOCiW7Fsypi0LpWB3j9eyisOidE4zsm7tvpk4BctxMnQ'
                    'Bw8l7E8V1Au9z5zNAuCoX2Zocq2MGhd4yh+yMi0sBkStwlX7IbQ4k4baxSxeel7/'
                    'iv1ZmhWMyNLgrF4m45pmzcRdFoAAAVKU4A5ubZ5gXNTqMeVtZ3knlhuPeoh8g7J2'
                    'fPWuHGkIKIPvv27N1bUFLi3IL7U9Mh130xTnHUQxur9KiH2B8zo0hB1wSOS627rq'
                    'COm6kTAOjju//2ba3QLyPiVwdXHWORwtSjGkoVOUQMK1KY46iHKBCrRlHBbAsKas'
                    'QcoUihXNwv4viKvgCAM6Y4AZivPkUKI3RRiOhRpFCpaODRa9L3onLhIoXOF5qHXg'
                    'QvsH82XRR6xNlaCDJxTgdj5v6dfmxRMCMA1t1MnQBw8p5XiVqrGDC3Y9fQQoNCF/'
                    'qzQk1dZFC0E8PERQpz7H5QOqdSsVZj1rjoXyzmSrAaubZxY1DsRZE8AABGcjF1Ag'
                    'AHpc1PU+ycVf9hJn1e/Mw9bZFCzTNy9q29Jn3Pavf2teXcvX9We/YNPbfP/k651s'
                    'phQJydeZf6oUmpry0z3o4/C10TAOq7mzoB4KQ9nzqBDC+jic967exbLNEM2Ltxbn'
                    'aooQUeJfYP/dqb1U8GxBlq6NdSOs6cY9WIVzzmSrAauW45JsPfh+JSAODIKE4Ajs'
                    'OOC9856/ucsXd5SuMWKXRallY/qVoQsXf/o4c6XY2eTZHCZDmsxsnesqVIoWRhwQ'
                    'RFClu+pkXBDADY7nrqBABm4k1E9L8YOeQiZsG9WaGKFggMiDF0fzMwmbkVF5QuLC'
                    'hFkUId3ePehffIAMARUpwAHJeNC5oH73bvW6SQs3ysIoU+XRT6njVk3469nTsTDL'
                    '0AXmB/SgO6KJTIoY0x1yKFkroXKeiaADCO26kTAE7ay9IBv/vdt6VDRkS8iohP1x'
                    '6Zqkihr2MuUiha5DCTIoUS5tz5oKRaRQpFg60UKdTQ7TW4DN+3AQBH6MnUCQD0km'
                    'LtjdrBOfUb6zvFj7w9bYFC0+RsyjvjYU8c3vfoNelzVsZ5Xfce/LMaemaJ/fcxUt'
                    'Mh15o5DIiTIj3Ou+/fgUI5HYy5P96bQQUjMIF/v/33qVOAPq4j4ldTJwHQXY2rg2'
                    'mx97g+35a2aebu7btvdX/a+emoZ/faP/T8h/0DkhmaR6kYJePMOdZqzNLxomTM+w'
                    'RrfO2rR2yPfRfL4gQAgKOjcwIwLzlv5mY46iEixh31kNtJYWg3hL76dlKY0aiH3h'
                    'fGS456yP6rdTKjHvzgBWA8t1MnAJy0Z1Mn0MEiovl074opuiFMNeqh3dBXqS4IRX'
                    'IYGGhOIxpKj3qYY6wa8YrHnGzUw+vwPRsAcKR0TgDmJ/eu7I31nboo5MRv94zRRS'
                    'HyznnY12HP2p30Q87qs291/6Ob+bfc4V/j3AL7U9Mh11o5rMbp0UVhefRaC4sy+f'
                    'TM6WC8WIt5GX7wwlGq9dNJqOp66gSAk/bLksEqjHR4FsuLftHpdugpuiEU3JsVqm'
                    'gXgwExinQvGJDM3DoglO5+UKr4fPZdD0rHXAlWq5PCh7hGHgIAR01xAjBfcytSMO'
                    'oh+7yuezuNemj3DhzVMHT/oFEPJXJoY0R+nKpFCvVGPeiaADCu26kTAOisfB3g60'
                    'jxdPshMyxSKFQocFRFCkWLHGZSpDCnwoJjGPVQI2bRUQ8RD0UKdUY9LCpEBQAYjb'
                    'EOwPzlto7PHR8w0qiHrHEPxzTqoeBeox7GibM17/mOergMF8oAxnQ9dQLAyXsxdQ'
                    'I7PI+I17tbs3eohDimUQ9bzs0e9VDw7F77i42bGDjqYeqvpXScOcdajVk6XtGY1U'
                    'Y9vAtdEwCAI6dzAnA8cu4433F3fvFRD5l7UkqzG/WwDN8M74ZQeNTDQ1779sXAcw'
                    'vsH9RJYcKuBaOMehgea9k1ocbdJgDscxexeecwQDHPpk5gh0Ws/tu39a7nGXdRKL'
                    'Q3O1TBDg69Y0w96qFEHmu5zCROG6vkqIeYcbziMauMelgMjgAAMDGdE4Dj0qeLQl'
                    'r9tEMXhT6dFHKW53ZRaM+o2OEhrb9IVbs25Ozt1JlgRp0UJsthNU72li3/nyjZ/W'
                    'BYnMvQNQFgCtdTJwAwsucR8etHj+7tonCgCrfvHdND7rQuuDcrVNEuBhPsX4sxIN'
                    'jcOiDMLc5qvJJqdWYoFnMl2LC47yLiqkBCAACTUpwAHKcxihRq5hMDihRy9Rn10P'
                    'esjPO67u08PmHoxfQC+weNeiiRQxuj5KiH6XJadk2AI/Xvf/jz1CnAELdTJwCctJ'
                    'dTJ7DFYu+zx1ik0JciheHBShYFlDDH8QzHMOqheMxm628zvC6TBwDAtBQnAPMysO'
                    'ig0/q1T/dcTK7creBhyxhdFDL2rb0mQwsN+upbpDCjLgq9ixQmLAjYmXfJLgrdY1'
                    '2Gi2MAU7meOgGAQ777P74tFeplbOuasM3eIoUOe/uYoovClnOzQhU+u9f+YkUOAw'
                    'IV7egwkzhzjlUjXvGYvbsofBG+PwMATsSTqRMA2CpF3pu/nPXtxdFm9aEUza4AW9'
                    'b3OWPv8vsChabJOKRPXu2+Dnvai9RNNMPO6rNvdX+z+dCeP6uS5xbYn5qV13DsHF'
                    'bjZMZY+7MvnU+3WLomAEzrduoEgJP2okiUchcgF9nFuE1sKbptE9oTrMOSovsK78'
                    '0OtfV16nd27xhD90dEpIHJDM1jLZeZxGljlSpkL5lXjXjFY64E6xZ3UeJUAIA50D'
                    'kBmJVBd+2PMeqhTyeFnOV9Rz1U7PDwaNRDxa4NXfdmjXqYSSeFQTGGGjDq4VHupT'
                    'o7tLG2exsujAFM6XrqBICT9mzqBFa8jIjPet0ZfYyjHgrtPctRD83AYHMc9TC3jg'
                    'xtvJJOo5PC30fETakTAQCmpjgBmKXZFynk6DnqoVeRQq4+ox76npVxXte9WUUKQx'
                    'TYf6yjHpbbRh/1sCgUHSbx73/489QpAMCcvZg6gRWXa58VLRioPOph7DERW/aOPu'
                    'phDkUK67+ZLo+SRQql4swx1mrM0orGbLb+NpZdBRclTwIAmJqxDsCsrbXwz20rP3'
                    'A0xNSjHiKWRQqjjXrosK/IqIf2vIIjF7aOIeiwb+i5ffbPZtRDZpwRRz18Ee4KAZ'
                    'ja1dQJACftaZULhfleRcQvHz1adPRCxVEP7d5zGvVQan8MiGHUw3HGqhGveMytox'
                    '4uQ1dBAODEKE4AZu/RRdGcC9t9ChpW1h+86N23SCGzQCEixitS6LBnUNHI6ll99q'
                    '3ubzYf2lNQUvLcAvtT0yHXWjmsxsmMMUKRwqJAFJjWPC64AMCcvYyhhVBD/nu7/P'
                    '510Sl+nyKFR3sqFikULDQYsjcrVLECgZ772xhFihwGJDO34oLShQVzLSo4niKFu2'
                    'g2ursAAJwAYx2AeUm7K8JnP+qhZj4xYNRDpTEUW0c9VBwt0XXvUY16SANGPZTIoY'
                    '3Rc9TDo9yHj5/QNQFgPt5NnQDALt/912+HhngdEZ92Wll81MOBgH1b2k856qHZ+W'
                    'nW3qFnj76/jTE0WKkxBqc86qGNV9Lsx0c0r0PXBADgBClOAObm+tAFzkEXxPus3z'
                    'j7YJFCjjGLFHINKVLoY4oihaEX04dfjF8WKXQtqKiVw4A4W/Pun8+i904AAI7Jyw'
                    'nPfhZN5vedxQsGOgQbUmgwdnFDu3/3p6Oe3Wt/sSKHAYFKFUuUKnSYY5HC7AsKol'
                    'SO7yPizeAoAAAzZKwDMF97WsVvHfWwY+3O2ANGQ+wdH9B31EPmnpTSeKMeOuxb+z'
                    'MZ0ua/x6iBtb0b5x4czbFj39Bz++xPTYdca+UwIE6hUQ+6JgDMy1VEfDZ1EsDJej'
                    'bh2a8j4mmvtvPHMuph55kd9w05c2VvdqghowBKjXoYEqPEqIc2zlxGNJQe9TDHWD'
                    'XiDY+5WA8CAHA6dE4A5u9AF4Xed+3PbdRDuydn+VijHtp9nZZNPOqh3f/ooY6jHq'
                    'bspHC/f/Coh1KdFLK3DBr1sMg/Eebn3//7n6dOAQCOwYu+GweOdHgWy+KEpTG7DB'
                    'zjqIdCe49q1EMbY+j+ZmAyc+uAULr7QSnz7HowNOa70DUBADhhihOA49Bh1MPDRd'
                    'ExRj3kFinkMOoh+7yuezuPTygwqmHo/kGjHkrk0MYYp0hB1wSA+bmaOgHgpL2Y6N'
                    'zLiHj66NEhF//77Dm2IoW+jrlIoWiRw0yKFEqY43iGYxj1kBdzUeF0AIDZUJwAHJ'
                    'cORQpd1+bG3rp+4+ydF5P7dlGoXaRQubPBoKKRHud13dvpwv+Muij0LlIo2UWhZ5'
                    'HC1liPLfKjAwBwxJ7G+KMdnkfEr/euKNoRoe++DsHGLjQocaG/bxqFz+61v1iRw4'
                    'BApYol5thFYY6xasTrFvNdKBAFAE6c4gRgjt4dXLHnYungu/YHFjRUGfXQo0ih9h'
                    'kP+zotK1ik0NeOUQ+KFOrG6dBF4cvQNQFgjq6nTgA4eS967Wp6fuQUxI7ZneDYui'
                    'hMMeqh3dDXqYx6KJFHgRSKx2ljlXLcRQqvCp8EADA7T6ZOAGBNe8Gy6xu/tHtte0'
                    'G0iaZf3AHr184uEb/dk7G+LVBompxN97/m5tVxT4r04TXpc9aQfXv2ruVV49yC+1'
                    'PTIddaOazGyYyx9f8Ty4cuB2YDQB23UycAnLwXMd4dwi+iiV9nFdq237bmFvn22b'
                    'dzT4dgY+ZZYW9WqCHnzmH/WowBwUrkccpxVuOVitXGi6oxjTsEAM6CzgnAPOXcod'
                    '1h1EPvu/YHrj94t/scRz205+TqM+qh71kZ53Xd27kzwdAfRBTYP6iLQokc2hjDRz'
                    '1oWQkwb3dTJwCctOcjnnUZETPoiND3rBl3UuhrSyeFvnuHnj36/jbG0GAlOyCUUD'
                    'LOHGOtxiwtt7sLAMARU5wAzNHtw+8KFyn0itt3/cbZOy8mn+Koh9wihSlHPfQpUj'
                    'DqYVCclbwXBTKA2fj33/956hSgtOupEwBO2ovcDd/979/2OedlRHz28NmYF/GLn9'
                    'Uh2NiFBiUu9PcNVfDs3vuLFTkMHPUw9ddSOs6cY9WIF/Hb0DUBADgTxjoAc3QdEb'
                    '9aeySnjXzXUQ+5cfvkEevr944PqDxSIWLEUQ/tvmMY9dDuP/JRD8swPQJNN+pB1w'
                    'SA+budOgHgpL0Y6ZzF1keHjEMYa4TC1rOMeti6f+pRDVOPeiiRx1ouM4nTxio56i'
                    'FmF+8uIi6rdGQAAJghxQnA8ci5iHpg7VqRQu7F2YHrHxVIDI3f7smpNxirSKHjnq'
                    '1FI7lnDdm3Y+/BP6vVvUN+kFCwSKFXgUIbo0SBQnSOsxg0mgKAMVzHZsEoQDlPYz'
                    'na4abiGa9itWvCNmMXG+Tu27lHkUKxc+ewv42RBgYrWVxQqrAgCsSqUVRQ8u3osP'
                    'wuQ0EoAHBGjHUA5uh277OFRz30Hi0wcP3BlvwjjXroNe4hV59RD33Pyjiv695RRj'
                    '20MQbuP5JRD7omAByH26kTAE7ei8rxF51WjTnqod1X7KzKox7GHhOxZa9RDxPkUS'
                    'rGaqxSceYYazVmnvexLE4AADgbihOAWbm/WH7dbXEULVLoFbddn2PLhe+9a0cqUq'
                    'h9Rs6+QUUjm+f1NVWRQqH9My9SWBSIDrPy59//29QpQA3XUycAnLwXFWO/iohPs3'
                    'bMotigz74OwaYoNBh6ZrPz0277+5rDhf2H/QMDlbj4Xuoi/lwLC0oXKeTFW4RiUA'
                    'DgzChOAGYp62J5oUKCQXftj9FFYWARxMHlfbso9C1S6LRsQNHI0H2r+x891KnCYj'
                    'ZFCpPlsBrnA10TAI7H7dQJACfvZdeF3/3v3+bEfRZD7kbuc7FyFt0XKhYpFCw0GL'
                    'I3K1TRLgYDYgzdP7RIYW7FBXPsyFA6Vhtvf8z3EfGm8KkAALOnOAGYo5uIzIvl5z'
                    'TqoWY+MWKRwpBRD2MXKfTtotDuHWLqUQ8lcmhjLOMsCkQDYBzXUycAnLwXDxfwDn'
                    '3keR0RTwdnN3mxQd+zZlyk0NcxFykULXKYSZFCCXPsfFBr1MP2mK8LnwQAcBSeTJ'
                    '0AwBY3q5+0F8qbpsM7xPYiapc3kwfWpkjRtE/mxO27vln99P5r3p1c3hvm3Hwi83'
                    'VfPSf3jXzH3B69Jn3Oyjiv696Df1ZDzyy4PzUdcq2Vw9JXoWsCp6r0DzFhPt5Hbl'
                    't0gO6eRsTz2HgPONCzKHnRr/1vfG7Bbp99xc9qDgfrsCTvzEr7VvennZ+Oenav/U'
                    'PPf9g/IJmheZSKUTLOnGOtxvwQ711EvC0YHQDgaChOAI7GFEUKWy+Id43brh9Q0L'
                    'BWINFhfZ8zDm5JKb9AIfOMh32d/mhX/kyGFhoULBZQpNDJZdEf7gAwhptQnADU9T'
                    'LKtjZfRImuCZuGXIwf6wL+1rM6BBtyIXbs4oYte7NDDSkymMOF/Yf9AwMNLbZYy2'
                    'UmceYcaz3eolBEAICjY6wDMFfvdj2RNXIgdwTCzqe2jBbIiTunUQ/tnpzlMxv1sF'
                    'w68aiHdv+jhzqOehh6boH9g0c95G1/H+ZpAhyjq6kTAE7ei4KxnkfEXxeM91iftu'
                    '9jjlDYuadDsDHzrLA3K9TQ9v0l2v+X2N8MTKbUGIO5xWljlVK2S9q78P0VAHDGdE'
                    '4AjtKUox6WT/e4a3/geqMeti074lEP7d4hP+QosH9QF4W8HBb9DoD5+/N/+7epU4'
                    'CabqdOADh5LwvGWhSMtd/kHRH6nlWxk8IUHRi2nJuVRtFRCxPsb2M8jHroGaxkB4'
                    'RSHQvm1vmgXKxXhYsdgLnTRRRgjc4JwLykh4/rTjeg59zRn3On94G1g+7a77N+4+'
                    'ydd7xX7lbwsCW3k0LlzgZrr8mQrgKF9x7sejH0zIL7O+XaPwddEwCO1/XUCQAn75'
                    'cR8axAnOcR8esCcbqbRUeEvvs6BBvS0aDvvqHdDPqmUfjsXvuLdXIYEKhUR4g5dl'
                    'GYR6wvYjkyCwDgbClOAObqNiK6t/ifoEhh0KiH3PU7LnznrO9zxsEtY4x6aPd1Wl'
                    'awSKGvHaMezrxIYdE3LQAmdz11AsBZeFkgxqJAjH6GFA5MepZRD1v393Uqox5K5F'
                    'EgheJx2lil9MtrUTADAICjpDgBmKubh99lXHTNvpu/wNpBF8QHrj94IblvkULO8t'
                    'wuCu0ZFYsnBnW2GLpvz95OF/1nVKQwKMYHuiYAHLfbiLibOgng5L3c9+R3//XbQ/'
                    'ufx9hdE7aZRUeEPnsUKRQ7dw7712IMCDa34oK5xVmN181vQ9cEAADFCcBs3Tx6pG'
                    'uL/wlHPcy6SCHHGKMe2nNy9Rn10PesjPO67u3cmWBIgUGh/YW6KCwGZgLA9K6nTg'
                    'A4eS8H7l8UyKGcyTsi9D1rxkUKfW0pUui7d+jZo+9vYwwNVrIooIR5jGfIjXUXEZ'
                    'eFTgMAOGqKE4C5utn5zBEUKfSK267PkXPh+xRHPeQWKUw56qFPkcKMuij0LFLQNQ'
                    'HgNFxPnQBw8n4ZEc967n0ec+iasGkWHRH67usQbOxCgxIX+vuGms2ohhL7jXqYKN'
                    'ZltONLAQDO3JOpEwDY4ebgihSd3kCmlKJpOr7T7Bjz0Nr2Qm7TLsiNG8PWp0gfzh'
                    '4av8eetkCh8+ve44y1fV3+Hqy+JkPO6rNvdX+z+dCeP6uS5xbYn5oOua5bDO7gAD'
                    'P359/929QpwBiup04AOAsvI+Jtj32LolmU1n77nPt9cdNzT7GzOgQbcl6ffYX3Zo'
                    'Uacm6J/W2MofsjItKAZEp8HXOM08Yq9f51Pa/3oWsCAMADnROAOfvq4Ioj6KIw61'
                    'EPAzs1HFzed9RDpQ4PW0c9VOza0HXvqKMeBnZSSKlzF4W70DUB4FRcT50AcBZe9t'
                    'jzPObYNWGbsUc9FOu+cB6jHjqHm3pUg1EP9eOUitXGWxZQ3RaMCgBw1BQnAPOS1j'
                    '5uSxUJPCw71lEPtYsUcvQc9dCrSCHXkCKFPqYoUhhaYNDGGLi/Q66XA08BYD6up0'
                    '4AOAsve+xZFM6hrrEv4h/TqIexixva/bs/HfXsXvvnMuph6q+ldJyysYw6BADYYK'
                    'wDMGdXEfFZVkv6jmuzxg4UOn/rqIeucdv1uaMYZjTqISLyRmz0PCNn39qfyZDRB7'
                    'l/Npt7N8599Hel476h5/bZn5qtud6F4gSAU/NVLGfCA9Tyy1h2QrjpuP55HEvXhE'
                    '3HMurh0b6Kox7avcc06qHdMPWohyExSox6aOPMZURD6VEPw2K9KtqJAZi/UuNhAE'
                    '6YzgnAnN2ufZbbPaDLspy7+QudP+iufaMe8vd1WjbxqId2/6OHOo56GHpugf0buV'
                    '6GtpUAp+Z66gSAs/AyY+2iUg7jKTp+oeK+PsGmGvVQaO9RjXpoYwzd3wxMZm4dEE'
                    'p3Usj3LpY33QAAsELnBGDOrh89ciJdFJZPD7hrf+D6g3fm184nMl/31XPG6KKQsa'
                    '/veV33duqi0O4d8oOXAvvvuyjcNdFcDogEx8WdUJyP6zjWO5SBY/J5bLRA/+7/+H'
                    'bbuudxSv8mjd0RodhZFTspTNGBYcu5WWkU62Iw0f42RhoYrGQHhFLdD6bporAocC'
                    'oAwMnROQGYlbT+v+udd47n3O3dcW3WHf0Fzx90136f9RtnH+ykkKPHXfjZnRQqdz'
                    'YY1Nmix3ld9x78sxp6Zrn9l6FrAsApup46AeAsvOy4blExh2mM2Wmg+Fkdgg3paN'
                    'B339BuBn3TKHx2r/3FOjkMCFSqI8QcuygcjvVl6JoAALCVzgnAnN1GHLhzPLeTQZ'
                    'fmCBN0Uhh8137OXe877s4v1kWh556UUn4XhcwzHvZ1+qMd0Nmix3k7926c26mTwp'
                    'B8h+2/i4jL7LEdAByDq6kTAM7C01h2T3i7Z83zOKWuCZtm0RGhz1kz7qJQaG92qI'
                    'IdHHrHGLo/IiINTKZE54KS3RhKxGlj7Y7zusAJAAAnSecEYF7So493H54qcId/xp'
                    '3h2XfzF1g76K79gV0XOnVR6NNJIWd5bheF9oyKHR4GdbYYum91/6OHOrWBGLuTwm'
                    'XomgBwyr6aOgHgLLw88PxihBymN4uOCH32dAg2Zp4V9maFKtrFYIL9azEGBJtbB4'
                    'S6cb6IiJsC0QEATpLiBGDurlcvkO69gH5iox7Shy96fkUKOcYY9dCek+scRj20e4'
                    'fotv8ulsUJcDb+7b/+aeoUYGzXUycAnIXP9zz3PE65a8I2Y17ELz7qYaZFCn0pUh'
                    'gerGRRQAnlRz3cxbkUUAEA9KQ4AZi7m4ffnWmRQq+4fddvnF3kNR6wZ5QuChn7Bh'
                    'WN9Div695ORQr1uyhchq4JAKfueuoEgLPwaUS82PHcYrw0ZmQWHRH67usQbOxCgx'
                    'IX+vumUfjsXvuLFTkMCFS0o8NM4ixjXYauCQAAez2ZOgGAA64fPZLi4Y1je0G22f'
                    'ZOcmXdQR3XthfLm6bL4vtfu+Sw5/xHX2PO15W7fkvOKdL213fH+j5n7F2e85r3PG'
                    'NtX6c/2pU/k75nZZzXde/e/z+s7ouB527ff9kzIgDH42rqBICz8Soez2x/HufWNW'
                    'FT+z14btFx03NPsbM6BBtyXp99hfdmh+rzZ7Lj7N4xhu6PiEgDkxmax1ouk8dZdh'
                    'MsVegAHIeh//YAnCGdE4C5u9766JZRBF3W7ZWxNuuO/nMZ9dCnk0LO8r6jHip2eB'
                    'jU2WLovj17O496KNdJ4YvQNQHgHFxPnQBwNj7f8thi5Bzma+xRD8W6L8x41EOhvW'
                    'c56qEZGGyOox76xboM74sBAA5SnADM3W1EvN/57JmOeph1kUKOnqMeehUp5Ooz6q'
                    'HvWRnndd3badRDu3eI5f7FwCgAHI93UycAnIXN0Q7P49y7Jmwa+yL+FKMepihS6G'
                    'tLkULfvUPPHn1/G2NosDmNemhjdfc+vC8GAOhEcQJwDG4OrjjTIoVecdv1OXIufF'
                    'fuVvCwZYwuChn7BhWNbJ7XV98ihWFdFL4IMzUBzsn11AkAZ+PVyu8XE+Uwf7MoNu'
                    'izr2OwsQsNSlzo7xuqWIHAgP3FihwGBCrVRWHcOIsCpwEAnAXFCcC8pK0fV1kX9B'
                    '9+e+ACek5OXZbVGPVwYO2gu/YLdF04m1EP7b5OyyYe9dDuf/RQtVEPix3/v/Xh46'
                    'Q//u2//ingTF1PnQBwNj6///V56JpwWNHxCxX39Qlm1EPvs3vHGLp/TqMe6sd5Hx'
                    'FvCpwCAHAWnkydAEAH1xGxvCAUcfiN5ca6FCmabZu6xstY214ob5oOQQue3154bq'
                    'LJi5ubx5b1a2dXiN9pS87rPuCczn8PNl+TPmcN2bdj78E/q9W93c78InRNADg311'
                    'MnAJyNTyPiZax3UOCQJj68F8jZEyPt27mnQ7Ax81zd22fflnOz0hiS8xz2tzHSwG'
                    'Al8ljLpUqcVwUiAwCcDZ0TgGNwvfZZe+fqISvrjHoonEe7fuPsg50UcuTmE5mv++'
                    'o5ubr+Pdh8Tfr+MKTHa7Fvb8FRD4ueWQFwvK6nTgA4I980/7fQNSHfLDoi9D2r8q'
                    'iHsTswtPt3fzrq2b32z2XUw9Rfy/Y47yLiqkBUAICzoXMCcAxuIuIuIp6uPdr17u'
                    '6VdXvvHD+RTgqD79rvftf8zrvzi3VR6LknpVS/i0LGvkGdLTbP6/vDlL6dFHbnq2'
                    'sC563EDzbheL2LiM+mTgI4fc2f4/86dQ5HbUingUm7L1TsotDu7btvyJkre7NDFe'
                    'zgMEmMh/0DA5XogFCyG4OCfTg/JbqwAJw5nROAY3G19dEeXRSWnx7opNBV1+YIOX'
                    'fzFzp/0F37A7sudOqi0KeTQs7yvl0U+nZS6LRsQGeLoftW9z96qFMbiM29iwFZAH'
                    'DcrqZOADgP6Yfp40jx9dR5HL0+d4zPovtCh2BTdEMouDcrVNEuBgNiDN3fDEymTg'
                    'eEPr4M3xMBAGRTnAAci+u9zw4oUhgUL2PtlKMeHr7OMUY95BYp5DDqIfu8rns7jX'
                    'po9+qaAHDurqdOADgTKSJ9P/3L1GmcjMmLDfqeNeMihb6OuUihaJHDTIoU+nld4H'
                    'QAgLNjrAMwL7uvjV5FxN8efNPYtWX+yrpzGPWwfHpl3EKfUQ+567uODxhx1ENEx9'
                    'e95xk5+4qOeii4t+Ooh0WP0+Bk/On/+6epU4CpXU+dAHBGfpz+Mv7NPKViio5fGP'
                    'usDj39h4xsGHvUw5Zzs9IofHav/UPPf9g/IJlpxlYo2AcA6EnnBOBYXEdEXoeELi'
                    'Ye9TB2J4Wtd+1X+Np2xa4y6qFHJ4XaZzzs67RsQGeLHud13bvn/w/vwg9hAM7dTU'
                    'S8nzoJ4Ew8SREfxe+nTuPkzKIjQp+zZtxFYYpRD+2Gvk5l1EOJPLqncBe6JgAA9K'
                    'Y4ATgWtxHx1cNnXS7iHsGoh4jMi+WFCgkGjRYYY9RDnyKFnOV9Rz1ULJ4YVDQydN'
                    '+evVv+rBY9TwDgtFxPnQBwPtKPLn40dQ4nq8/14DEv/h/jqIcpihSmHtVQqshhaJ'
                    'FCyVEPu+NcxvJnVAAA9KA4AZiVtP9/V48ulPYoPuiy7mAXhcJFClN0UVg+PeCu/T'
                    'GKFHL07KLQq0ghV9e/B0OKRnqc13XvSl7vYjliBQCupk4AOCM/TB9Hiq+nTuOkTd'
                    '4Roe9ZMy5S6EuRwvBgJYsU1t3FsjgBAICenkydAECG64gPd3I37bvE9kLqoTeeqc'
                    'OajXiPztqxLifm3mX3F8qbpkPQguenSPmvZ5882vXN6qeFXuMBe1JK3V7zAWfk7F'
                    't7Tfqe1Z7X9wcyW85NkRY9owFweq6nTgA4Iykivp/+Jf6t+XjqVE5a+71/bqFzn3'
                    '3Fz2oOB+uwpPi+6Ll3y7lZaRQ+u9f+oec/7B+QzNA8HsdYhK4JAACD6JwAHJOr1U'
                    '+23mVeatRDu3bXWTvW5cTcuyy3k0KB8wfftT+w60KVUQ85EzPGGvXQ7uu0bEBni9'
                    'Wzhvwg5sNeXRMAWHU1dQLAeUk/ufjLqXM4G7PoiNDnrBl3UZhi1EO7oa+iXRCG5j'
                    'AwmTJdFN6HrgkAAIPpnAAck5uIeB8Rn64+uHbX//KBpX1vPnO6Layse3RWbrzMtZ'
                    '3v6C/cRWH5dI+79geu39tFoU/8dk9mF4WIjt0rVs+IvHOy/h4M6WzR47wdexc9dg'
                    'Jw2r6KiF9OnQRwJj6KiCfpd/FNo0hhLH1uWJ9F94UOwcbMs8LerFBFuxhMsL+N8d'
                    'BFoWew4XksihQ5AMdjyL9bAOykcwIwL+ngx9W2bwy3djbo8g1k17vKV9Yd7KKQ05'
                    'mhw9rsLgqFzh901/7A9Xtf44i82H3yiQGdFHJ1/XswtLNF5nkbdE0AYJurqRMAzk'
                    'v6cVKYMLaxOw0UPatDsKm6IfTV7P308N4pOykU3T+wi0L+9q8i4k3/QwEAaClOAI'
                    '7NVUTsvMDaa9RDu66LnFEPJ1Sk0Ctuuz7HzEY9RMS4ox5yixSGjGzI27foeQqcnK'
                    '//6eupU4A5uZo6AeDM/CBFXMTd1GmcpVkUG/TZV3HUQ7u3775jHPVQan+RIoVRRz'
                    '287n8QAACrFCcAx+Zq7bOSRQo9uihsPWtzbVdd6w5yLpYXOn/QXftjdFEYWARxcH'
                    'nfLgp9ixQ6LRtQNJK3T9cEAHa5njoB4PykH198f+oczlqf68Gz6L5QsUihYKHBkL'
                    '1ZoabugtDGGLp/aJFCt63eEwMAFPRk6gQAMt1ExPuI+HTt0RRb31CmSNGsPtFeiN'
                    '335rPLmi3rHp2VGy9jbXuhvGk6BC14fntBvIkmL25uHlvWr51dIX6nLTmv+4BzOv'
                    '892HxN+px1eN8iMxoA5+Mmmi3flwHU9MP0cfyP+Dqa+HjqVM5aE/kF0u37jT77ip'
                    '3VIYkhefbZ1+7t2xVv49ysNIbkPIf9bYw0MNj+rYv8gAAA7KI4AThGVxHx60eP7r'
                    'jAuvWi9o5ihi7x9q3bewH9xIoUel8Q77N+7Y+uQ5FChUKAtS19ixTKFg2sLNtSpN'
                    'DnxpHH570Pd4jAuqF3eMHpuQ7FCcDYPk5/jj82ihOmNuZF/OJndagG6FswMEVxQ7'
                    's/7fx01LN77R96/sP+Ack8zuOL8J4YAKAoYx2AeUmdPt52ivHo4R6jHtp1XeSMes'
                    'iJ2WFt1tiBQuf3fj1X1+esTZsPVRj1kDu5YYajHh5el75nrZ+36BkBgPNxNXUCwP'
                    'lJP7p4Gim+njoP7hUdvzDmWRVHPew8s+O+KUY9tBv6KjXqoUgOAwN92LoYkA0AAF'
                    'soTgCO0VXnooJSRQo5hQw5RQpddb04nXOxvND5W1/PnLgD1u99ffvEb/fkLM8pDF'
                    'k9o2LxxKCikQ/73kfEmx47ATgvV1MnAJyhFMvuCcxLn+vBQ4oNip1VsUihYKHBkL'
                    '1ZoYoVCAyMMXT/0CKFJr6I5WhRAAAKMtYBOEa3EfFVpPhlRHQbu7B1ysLKaII96x'
                    '7F6nrmyrpHZ+XGy1g75aiH5dPNOKMeVtYb9bBt2eBRD4venRcAOCfXEXEXEU8nzg'
                    'M4M+lHF0+br7/9Opow3mFu+nTVHzIKoeiohwNJTDGyYcjIhI1zs9IoOmphgv1tjI'
                    'dRD1nB7iLitZFucGb8HAxgFDonAMfq7cPvBnQ+GGXUw0OX/dMf9bB8euCohwEdHY'
                    'q9xgP2ZHdSGDLqocvfg9XXpPtZuiYAkON66gSAM6R7wrzNoiNC330dgh3TqIct52'
                    'aPeih4dq/9xTo5dA50GcsbYwAAKExxAnCs3j56ZOwihdwL+rvO2rEuJ+beZRMUKQ'
                    'wa9ZC7fkseVUY99ChSqH3Gw75Oy7KKFBY9MoGT9/V7o61hh6upEwDOU/rRxdNI4T'
                    '/QczakcGDSs4x62Lq/r+Ma9XAXy+IEAAAqUJwAHKvrWL5hfKxr54MdRQpd1mWv2b'
                    'JuzC4KEZkXywsVSfS8a7/I+r1FIH3it3tylud2UWjPqFg80aEIR9cEAHJdTZ0AcK'
                    'Z0Tzges+iI0GePIoVi585h/1qMncEWoWsCAEA1ihOAY/Z25zMDxjNsvag9oOBh37'
                    'pzGvUw6yKFHGOMemjPydVn1MPjsxY9TgbgvF1NnQBwvu67J2wvXGd+Ju+I0PesGR'
                    'cp9LWlSKHv3qFnj76/jfE42PvQNQEAoCrFCcCstBdxO35cHQ4Y4456aNd1caZFCr'
                    '3i9l2/cXaR13jAnlFHPeQWKSz36JoAQF/vpk4AOFMpIv344vtTp0GGWXRE6LuvQ7'
                    'CxCw1KXOjvG6rg2b33FytyaCIU6wMAVKc4AThmb1NK5QoGShYp5F7Q33XWjnU5Mf'
                    'cuyy1SKHD+gbv2y+expUghZ32fM/YuH2vUQ7uv07KHhYuHs3z48PH4A9jnauoEgD'
                    'P2cfo4PorfT50GmWbREaHPWTPuojDFqId2Q19FuyAMyuGrUKwPAFDdk6kTABjgNi'
                    'K+TJF+FSmiiWb/G9L2wtKhN61p+5oUaXlGTrycM1fWPTorN17m2pRSNE2XheXOby'
                    '+IN9Hkxc3NY8v6tbNLxG/3ZKxvCxQ6ve6rZ0TeOV33pEh3TTRvMiLD+Rn6Q084bV'
                    'cR8bdTJwGcr/STi583t99NnQZ9NJFfCNp+XzbGvp17OgQbM88Ke7NCDTl3DvsjXk'
                    'fO+3Pg+OXePARAEYoTgGN3FRG/iri/4FyqSGHHmq0XtbtclO5RpLD3AnqFIoWsi+'
                    'XnVKRQoRBgbUvfIoXcn5kczu1yb1cJANjvauoEgDP3vRTxJP0+vml+PnUq9DD2Rf'
                    'yiBREdgvU5b++ZHfcOudCfdn56eG+UO7vX/vzz34XvZQAARmGsA3Ds3m4+kKJj2/'
                    'wubbp3rOk16qFd18Va6AOjHnJidnlZckc9FDq/1+u5uj5H2vx0b2L94mfuGXXUw+'
                    'N9dxFx2SMaAKx6N3UCwHlLP71QmHDsjmXUw6N9FUc9tHv77jvnUQ/dY7weeBoAAB'
                    '0pTgCO3U1EfLXtiZRSuYKBkkUKOYUMOUUKXXWtO8i5WF7o/K2vZ07cAev3vr594r'
                    'd7cpbnFIasntG3SOGDy1iOSQGAIa6mTgA4cx9FxCfpbuo0KKDPxemixQYd9/UJNn'
                    'aehfdmhRpaZFCqSGG/LyLieuApAAB0pDgBmJfU6+PN7nCpW5HCwM4Hjy5qVy5SGB'
                    'QvY+2UXRQevs6BRQe564sXKfTsojBKkcJyj64J0MEf/7c/Tp0CHIOrqRMASJ9cPL'
                    '3/HpdTMHmxQd+zZlyk0NcxFyns378YEBkAgEyKE4BT8PbQRdmiRQpduyjE9nW9zt'
                    'xYZ9RD4Tza9RtnHyxSyDFmkUKey9A1AYAyrqZOACBSRPrJxfemToOCxryIX/ysDs'
                    'HG7oZQ4kL/7k9HPbvX/vUYfx/LjpwAAIzkydQJABRwExFfRYpfRsTeN6spUjSpOf'
                    'yGtr3Au2/djjXtBe2mfaJLrHZdlzfaK+sendUhvyFntxfKm6bL4szzd6zt/Xquxs'
                    '5ZuxE7Rdr++vbJpeeelFK31zz/jGXXhD5jIQBgu3cR8dnUSQBn7gfpk/he+n38e/'
                    'PzqVOhoPb9Te77l6bnnmJndQjW97ydZ3bcN+TMlb3Zofrm3OuwnTHuIumaAAAwNp'
                    '0TgFPx5uF3XUYGdOmi0MbqsmZHJ4Uu67LXbFl3sJNCFxl39mfdzT+ge8H6Uxtf4z'
                    'GPemj35CyvM+rhMnRNAKCsq6kTAIiISD+5+HlEmMt0imbREaHPnhmPeii096hGPX'
                    'g/DAAwCcUJwKl4++iRMUc97DhvzFEP7XmD4mWsnXLUw8PXOcaoh9wihRzTjnpYdk'
                    '0AgLLeTp0AQEREfBSRfnTh516nbMyL+MVHPcy0SKGv4ytSWL4fbvf68OHjPD4AmA'
                    'Vv0oBTcRMRXz16tMPF34cihUMGdD7Yetd/qc4NG/EOdlE4oSKFXnH7rt84u8hrPG'
                    'BPdpHC4zMuw10iAJR3Hcsf+ANM75P0w3iSfj91GlTU94JTn33Fz+oQrO/FtCH7hl'
                    'zAa/Z+OurZB7wO74cBACbxZOoEAAp6ExF/t/WZ9qLsnjerKaVoojn8hrZDrF1r2g'
                    'vaTfvEgFg71z6E3jhrx7qcmHuX3V8ob5oui+9/zfyaHj+15fXM+YFE7usQ6+tTpO'
                    '2v7471fc44uCWlbq/54zMuu28C3GUBWa4i4ldTJwEQsRzv0Pzh2z9GxCdT50JF7f'
                    'dquYXiTc89xc7qEGzIeX32Fd6bHarPn8mOs3d4H6ujQQEAGJXOCcC8pEEfb/t2Nv'
                    'jwdMdRD22sLmt2dFLIyavzmi3rxuyiEBH5d/MXOH/2ox76dFLIWZ4/6uGLcJcIAP'
                    'VcTZ0AwAPjHc7LLDoi9NnTIdiYeVbYmxWqRBeF3fsXAyIDADCQN2fAKbmJiC87X+'
                    'jf+3THIoUB4xm2XtQeUPCwb905jXqYdZFCjrqjHhYDC4F8+Dirjz/+f/4YQJa3Uy'
                    'cAsOZj4x3OzpgX8acY9TBFkUJfW4oU+u4denZEvAtdEwAAJqU4ATg1bx9+115Y2u'
                    'XQ8xHxUKRwSIdYu9Y8uqjdJVa7rouVeOdUpNArbrs+R9r8tNBrPGDPgdf8i1gW8g'
                    'BALTexbJkMMBvp6cXPI8Wfps6DEc2iI0KffR2DjV1oUKJQoG+ooSPWPuxfDIwEAM'
                    'BAihOAU/M2Iu7WHulZNLC2ZKRRD9kX1XMv6O86a8e6nJh7l9UY9XBg7dbXMyfuwP'
                    'VVRj3kvIy7C0MWmScDQB9vp04AYE2KSD+++G7qNJjALDoi9DnLqIdi5y73vwujpw'
                    'AAJvdk6gQACruN5Q/Df732aHuNdt8b2QNrUiwLFJpoBsVZW7dlTYq0PCMnXs6ZK+'
                    'senZUbL2Nte6G8aToELXh+WyTQRJMXNzePLevXzi4Rv92TsX7jddc1AYCxXEXEX0'
                    '+dBMCaH6RP4t/T7+NPzc+nToUJNJFfJN6+9xpj3849HYKNmefq3j77tpyblUb/nF'
                    '8P7sAAHJe+/0YBUJXiBGBW9t5t3t2biPh174vuBy7+Fi1S2LFm60XtLhelexQp7L'
                    '2AfmJFCg9f4xhFCmt/dB2KFHILFHLyiYfXfZFxCgAMcTV1AgDbpB9f/Lz587f/HN'
                    '/FX0ydCxMY+yJ+0YKIDsH6FgxMUdzQ7k87Py159hcRcd01NAAA9RjrAJyiq4h4f3'
                    'B0wb43sF1GPUTGqIee4xl6jXpo13WRM+ohJ2aHtXvGDlQ7v/frubo+Z+28Rj3omg'
                    'DAmG4j4t3USQBsk55+9BcR8fXUeTChYxn18GhfxVEP7d6++6YY9dBuOGyRExIAgH'
                    'oUJwDzkop9XLYXbQ9edO+Sz86n7y+wlyoYKFmkkFPIkFOk0FXXuoOuBQoFz9/6eu'
                    'bEHbB+7+vbJ36757BFZlQAGOrt1AkAbPVRRPrJhQbv9LuoXrTYoOO+PsHGzrPw3q'
                    'xQ+xf/fSjUBwCYDcUJwKl6GxFrF3oHdQUoVaQwsPPBo6+hcpHCoHgZa6foorB8eq'
                    'VQYGDRQe764kUK+9frmgDAFN5OnQDATj9In8TH6W7qNJiJyYsN+p414yKFvsoWKd'
                    'yFQn0AgFl5MnUCAJXcRMSXEfGriPhQoNAsf9Nse2vbXtjd96437X++HfXQRHM4Tp'
                    'eztqxpL2ivfQ0H8up85sa6rWflxstY2xYoNE2HoAXPT5E+fI05cfuuX/uj2/Mab1'
                    'nfM5/LjAgAUMpNNPE+Ij6dOhGAbdInF0+bb777ffx78/Opc2EG2vdQuZ3s+uwrfl'
                    'ZzOFiHJcX3Rc+9W87NSuPD2ZexHDUFAMBMKE4ATtmbaIsTWvcXegdddO9wMTpFii'
                    'YdKFDoGKtzkUJO8UHXC/oPoQsWKXSpO5igSKH367kae0BBw1qBRIf1GWe8i4jrjJ'
                    '3Api7/FgG7vI2Iv546CYBd0k/Sz5vb5vfxXShQYGlI4cAYhQ07z+oQbMwCjAp7M0'
                    'PdRaNQH85O34IoAEajOAE4ZW8jttytl9MZYED3g85dFLqctee8Rxe1BxQ8HFp38A'
                    'J6wS4KEcsihU4FCjnnH1i7tUihZheFlfWduijkxF/uWWSsBjb86//7f06dAhy7q1'
                    'CcAMxZikg/ufh5c/fd1xHx8dTpMCOz6IjQZ48ihXuvQ9cEAIDZuZg6AYDKLnc+k+'
                    'LDuIddb2lX1uyNs/fptOwE0CVOlzfpW9ak+//l5JV95sprNej1ylybUnropFAqZp'
                    'e1a19nTtwC6/e+xhE5sd/F8qIQAEzlbSznPQPM15OI9PRCYQLb9Wmi1QzYV+ysDk'
                    'kMybNvc7EhTck2zt2TxvtYdtMEAGBmFCcA85KKf7zpWlww6KJ7h4vRD0UKh3QtiO'
                    'hSpDCg4OHQuedUpNArbt/1G2cPfI0XGacDQC1vp04A4KAnEenH6eup02CmxryIX/'
                    'ysDsHGLjQYUtyw5dwtoV4PiA4AQEWKE4BTdxsRX+QUFxy8ILxPlyKFLl0Uupy157'
                    'xeRQq5F/R3nbVjXU7MvctqFinsfGrL65ljYEHDwS4K25/WNQGAubiaOgGATn6QPk'
                    '6fpD9NnQYzNouOCH3OmnEXhUJ7Vz59FwojAQBm68nUCQCM4DIifh0Ry4u4+974th'
                    'd5m+UF4Wbb4pU1XeJsf3pZoNBEMyjO2rqtqW58DQVy37Vu0OvVY21KKZqm408xDv'
                    '25dzy/LRJoln9B9q7NjX1o/drZ3eIvOp4EALW9jYh/mDoJgE4+Tj+Mb+Kf48/NX0'
                    'ydCjPWRH7RevtebYx9O/d0CDZmnhX2Nt4Lw9np808HANPROQE4B9exrJxfyugiML'
                    'itftdRDyW6GnTtotAhr85nbqw7p1EP6cMXXX/UQ9dOFfGwVtcEAObkNiK+nDoJgK'
                    '7ST9JfxPfTP0+dBzM3dqeBKUY9TNFJoa/lud4LAwDMnM4JwLl4ExGfrT3StYtAc+'
                    'Cu9UNxOpzz0EnhUCeAAZ0PHn0NA7sy7Dt30OvVY21boNCpk0LB89e6RfTpjJDzg5'
                    'eN9Qde40VGZAAYw9uI+NXUSQB0lX6S/qL5l/h9/Hvz86lzYeaGdBqYtPtCx2B98h'
                    'y6L3rujXg1qMABOD7aJgAcHZ0TgHPxJiLeb33m0J3sOZ0B9ulwx3ynLgpdztpz3q'
                    'OvYUBXhkO5DXq9eqzt3EWh4PlbX8+cuAPXb3l93SkCwBy9nToBgFzpJ+nncRE6KN'
                    'BNn44Bs+i+0CHYVF0U8vZ+ERE3PU8DAGAkOicA5+QyIv5u57OH7mTf6AzQuytAh7'
                    'vxI93fET8gztq6ralufA0Fct+1btDrlbl2yi4Ky6ebfl0UBqzf6KJw2TEKAIzpNp'
                    'r4MnRPAI5MenrxF83dd/8c38VfTJ0LR2LsjgjFzuqQRNHODRl7u+1b9IgOAMDIdE'
                    '4A5iVV/XgTKe46nd9hzcGuAF3i7H06deukMKDzwdavYUBXhn3rBr9emWtTSt07KR'
                    'Q8P7srRd882vXrZ78Pd6ZCWY0PHz6KffhvFHCM0rJAQQcFsnz4b1/9fcXP6hCsz3'
                    'l7zxy877ehawIAwFHQOQE4J7cRcRkp/jYi9r+x7dpFoHl013penA7npEjRpObwG/'
                    'gBnQ8efQ0DuzLsWzfo9eqxdopOCr1fz9XYOWs/xF7sLAABsv3P/9f/mDoFODVvI+'
                    'Ifpk4CIFvSQYGe2vd1k3ZE6HNWh2B9z9t5Zsd9j8+8Cx0EAQCOhs4JwKyk+v97s3'
                    'JYl4T2r8vpDDDgnM5dFLqctee8R1/DgK4Mh9YNer16rO3cRaHg+Vtfz5y4eevfR8'
                    'SbjB0AMLbbiPhy6iQAemk7KHwUv586FY7QLDoi9NnTIdiYeW7fexnL7zEAADgCih'
                    'OAc3OTIn3xcME458L6oedXihQOrekSZ/vTBUc9tOt2nNNlXe8zN4oUBsXLWDvlqI'
                    'fsv3P5eSwe1vrw4aPMB1DD26kTAOgtRaSnFz+P7ycjHuhnzIv4xUc9zLJI4X3omg'
                    'AAcFQUJwDnaBERUaVDwP2ag10BusTZ+3TBIoUda3p1UWjXdbESb/Drlbl2yiKFXn'
                    'EPr38fuiYAcBzeTp0AwFDpx+kvFCjQ2yw6IvTd1yHYkG4I+RahawIAwFFRnACco5'
                    'uI+CKi5wX4jOKCQRfdO5yTokOBQsdYRYsUci/o7zprx7qcmHuXTVCk0LvoY3X9Y4'
                    'uMCAAwpdsw2gE4AenH6S/ih+lu6jw4YrPoiNDnrNl0UVCkDwBwhJ5MnQDAmvHaaF'
                    '9GE7/+cOzy4KZ9F5zi8BviNtdd61aefxR/c92+sw6c0xYoNNF0y7nn15Uired/6O'
                    'vvumbLukdn5cbLXJtSiqbp+BOQLq9hh7W9/s6txo2H9X4gA8CxeRsRv5o6CYCh0i'
                    'fpaXwUXzf/2nw8dS4csfZ9YM7PQ/rsKX5Wh2B183y9thY4fcYvApwExQnAubqOFO'
                    '8i4rP16+0rF4xzLqx3vEA/6KL7gXM6FykM+Lq2FlmUKOTYsu5gQUeXeBlr2w4KnY'
                    'oUCp7f6+/ceuxFx9VALj/ohFrexnI+9NNp0wAo4Pvp43QR0fyP5uuIUKRAf02MU2'
                    'xQ/KxJihTehVFRAABHyVgH4JwtImLnKIOVT45u1EOnUQVjj3po13WxEm/Q69Vj7R'
                    'SjHpZP9xr1oGsCAMfoNlxQAE7JkxTppxcfRwpjHhhmnHEIlc7qEKxv8e/jfYuekQ'
                    'AAmJjiBOCcXcWy2n7rxeCtF+APySguOHjRfcg5cd8JoFTBQMkihdwL+rvO2rEuJ+'
                    'beZblFCgXO7/F3bpFxMgDMydupEwAo6qOI9PTiaXwUv586FU7AkMKBSc/qEGx4Uc'
                    'S7WP48BwCAI2SsA3DuFhHxjw+fbWmrP/tRD3vWjDHqoT3n0aiHQ/F6jHrYelZuvM'
                    'y1KaW5jnq4Cxd2ADheb2PZAejTifMAKCdFpJ9e/Lz5Y/P7+Lfm51OnwwkYe9RD7r'
                    '5pRj28ytwBHLvcfycAmDWdE4BzdxVt94RVh7oElBz1kAqMLug66qFgzlvPeNx+4r'
                    'CckRBnOOphz9+5y1i2xQaAY/V26gQAakifpJ+nH6U/RsTXU+fCCRhz1EO7r9hZxU'
                    'c9fBERN1k7AACYFcUJALta4++5CH9oTZc4j9bEwIvuXUY9RMeL7CWLFHKKD7rIGf'
                    'VwQkUKG2vvYlmcAADH7HLqBACq+X76JP304uO4MOaBQmZRbNBnX7FRD3dhtCEAwN'
                    'FTnACw7J7wxc5nt1w43noB/pCM4oKDF92HnBPRrYtCl7P2nNerSKFHF4WtZ22u7a'
                    'pr3UHXAoWC5298jZehawIAx+8mtnWwAjgVHy3HPMQPkgIFyulTODCL7guDixQuQ9'
                    'cEAICj92TqBADWTDdDbBERv977PrnNrVl9KN0/1Gx9fmecjuekSMvYHXLJXZNiWa'
                    'DQRDMoztq6ralufA0Fct+1btDrlbm2LVBomg5BC56fIi27Jkz3/xUAKOlNRHw2dR'
                    'IA1aTlmId4En9s/rW5iIgfTp0SJ6KJ/J+htO8z++wrdlaHJDaXXMTv4jsdlwAATo'
                    'HOCQBLNxHxRc4IhvWHKo16SAVGF3Qd9VAw561nPG4/cViPTgpnMOrhMnRNAOB0vI'
                    '1lm2aA0/b99El6dvHD+MiYBwoasyNC8bMO3REQf4jvxV36JEX6JP0wvA8GADgJOi'
                    'cAfLCIiF9HxOE73Q91UegSI2dNsyV+TpwO56RI0aQDXRQ6xtq1ptdr1K7r2nVgpY'
                    'vC2lkd8tsZs8PakTopLLsmAMDpuI0m3kb7PRjAiUs/ufh5/Fvzp+br5ruI+GTqfD'
                    'gRs+iI0OesLcEu4nfpe+mn8b342cqyt+lH2gfCOWn+tU81FADHQOcEgA9uIuK3a4'
                    '/06BTw6M79Eh0CcjoDDDincxeFLmftOW/ra1Sic8OWdYNerx5rO3dR6Hf+ZbhbBM'
                    'bT+PDhY5QPhXfAuflB+mH66cUnuihQ3If/ttbdU/ys5uv4Xvz+vkvCX8b34uOVJ+'
                    '9ieTMJAAAnQOcEgHWXEfE6Ip4+PNKzU8DanfulOgSsxEmRondXgAPnpOU8iWX8zK'
                    '8757xHX0OXDgk5Z66sG/R6Za6t1EXhLpKLNwCcpOuIeBcRn02cB8B4Lu67KPy5+b'
                    'r5Y5Mi4odTp8QJaWLijggdz/qo7ZKQPo5YK0hY9SqWN5MAAHACdE4AWHcbu+7e63'
                    'p3/6OHKnQI6NpFoWM3ht1LUrdOAAO+rl5dFNp1XeR0negRc++y1PH16xbzMnRNAO'
                    'B0vZk6AYBJfD99nJ5e/DC+l343dSqcmFl0RNgixR/i++ku/egi0icXf3lfmLDLby'
                    'LibWY2AADMmOIEgMcWkeL9zmd7XPSffNTD0CKFnFEPYxYp5BYU7Dprx7qcmHuXlS'
                    'lSeNMtAAAcpTexbNsMcH5SRPpR+sv04xRxYdQDhQ0pUih51pP0T+njFOnHFz9LP0'
                    'hPO/xU+ovwPhgA4OQoTgBmpb2IO/lHpNedLurv/WIer1m7KJ7TISCjSGHvugHnPH'
                    'RRKNXVYE+RQk5enddsWTdmF4WID+MeOsf94IvQxhKA03c5dQIAk3qSIv304ufp4/'
                    'SniPh66nQ4MbU7Imzbl+L36Yfp6/Tji0gfp1/Ek87vid/FcpwDAAAnRnECwHZvU6'
                    'R3KQ5cjO954bx3kUKHcwaPLug66qFkwcC2M7YVKXSJlbnuSEY9LDpmARTyP776l6'
                    'lTgHP0ZuoEAGbhB+mH6enFx/GDpKMM5dUe9ZDiD/G99Pv044tIP774eXwvfZzVoT'
                    'DifUR8npkhAABHQnECwG6vIzpejO950b/KGIOxRj1Ex4vsY496aNd1cRxFCromAH'
                    'AubmL53z0AUkT6OD1NP72I+F763dTpcGKGdkR47Ot4kn6XfnQR6ScXP0sfp5/3/K'
                    'nzXSwLE2577QYAYPaeTJ0AwIxdx/IH5L+OWF68btL9u/Bdb+Lba80Zz7cXxJv2wb'
                    'Rnf49zHsXfXLfvrEPnxPIiexNNt5x7fl1bX6MDeXVasyW3Qa9Xj7UppWiavQsXmX'
                    'eZACX0+WEtUMKbuP/eC4BYFil8kv4yvkvR/Kn5Xfx785dTp8QJab/nzX3PuRzZ8H'
                    'U8Sb9P34tfxJP0cUR8vBazn88jxfWgCAAAzJrOCQD7vY5l5X5ErNxd36XzwD4jj3'
                    'po43fNJXfNGKMe2nOy4/UY9bD1rNx4GWv3dFHQNQGAc3MVyznTAKy6WBYppJ/opE'
                    'AF3QsKvo4n6Z/SJynSTy4+Th+nX8STYtX0v4nl9wEAAJwwxQkA+91GxGLzwbUihV'
                    '0GjHrIKlLIWDN4dEHXUQ8Fc956xrYihUN6FCnMYNTDouMJAHBKLqdOAGC2FClQy/'
                    '6RDcuChJ9efJw+KVqQ0Poilt2TAAA4cYoTAA67jBRfbXuicxeFHs+vXRQvWaQQAy'
                    '+6dzjnoUjhkJJFCqW6TWxZN1GRgq4JAJyrtxHxfuokAGbtcZHC11OnxIlYFimMUZ'
                    'DQ+iIiXtUKDgDAvDyZOgGANdXe6w72OlL847a7CNqL1k26f3JXO8S057n2+Y39D7'
                    'HbBw/F2BFn1/OP4g/M99GSlJaxu+Tc8+va+hodyKvTmi3rBr1e+WsXnQo8AOA0LS'
                    'LiH6ZOAmD27osUokkRf27+0PxbcxFNPJ06LY5Qij/E99K36Xvx83iSPo6IX4xw6l'
                    'exHKf5QfcRE8Cx8uMugLOmcwJAN1cR8ff77nxfG/Ww65vsnp0Cskc9tOs6njN41M'
                    'OeNUVHPbTrdpyTHa/HqIetZ+XGO7xW1wQAzt2b0D0BoLsUET9IP0s/vXiaPkkRH8'
                    'U/TZ0SR+Ai/kv6YfpD+slFpJ9e/Cx9nH5esUPCpq8i4mUsx2kCAHAmFCcAdLeIiL'
                    'uI2Hthea1IYZeMEQybsbNjdFwzeHRB11EPBXPeesa2IoVDehQpVB71cNlxNwCcss'
                    'XUCQAcpe+lSD+++EX6yUXED9JdpPjD1CkxEyn+sDKuIdJPLv5j/CD9bIKfEN9FxO'
                    'ehMAEA4OwoTgDo7jY22w0eKFI4eJG6x/OPLoqXLFLYFj8nTodzDhZuZMTqXKRQqt'
                    'vElnVFixSW3kXEdcddAHDK3kZbGApAvouI9MP0NP304mfpkxTxJP1TRHw9dVqM7K'
                    'P4p/TD9If04/vuCD9Kv4jvdXxfXsddLDsm3EyWAQAAk3kydQIAR+ZNRLyKiM/WHk'
                    '2xdS5ie9G6SfdP7pqduGP/2vMb+x9itw8eirEjzq7nH8UfmO/608sfhDTRdMu559'
                    'eVIq3nf+jr77pmy7pBr9d6zEWHlQBwDm6jicuI+NupEwE4ek9SpCfxi2hSxDfN18'
                    '2fm9/Ht/GLqdOigov4L/EkPUlP4i/vRzR8+HPu8r60rmVhQlKQDwBwrhQnAOR7Fc'
                    's725+uPbrnonanIoWeF87XLornXFjveM6jC/y5+e55vnORwoCva2vRQIlCjh3rBr'
                    '1ey64JVwdOBMYw/Q9ugaXLWHauerp/GQCdpIj4Xvo4fS/9IppQqHAKHhcj/MepU9'
                    'rjdegUCABw1ox1AMh3E/vubj8w6uHgWIOMEQybsbNjzGjUQ0odekrOfdTD8Ndr0f'
                    'E0ADgXt7EsUACgtLZQ4UcXv0g/vYiH0Q8p/jB1auz0dXwU/xTfT79Ln6RIP72I9O'
                    'OL/5h+mNrChDn7TSy7UQIAcMYUJwD0cxkpvtq74kCRwuCL+lue33oB/pCMcw5edB'
                    '9yTsSyQKFUwUDJIoWuhQwbuWW+XromAMB2lxHxfuokAE7ekxTpk/SL9JOLn6UfXU'
                    'T6QfpDfBT/NHVaZy3F7+J76b+kj9PX6UcXkX56sSwmOY5ihFUKEwAAiAhjHYC5Oa'
                    'r31vEqUvw/I6LXaINOox727F97fmP/7Ec97FlTZdTDlnWPvoYCue9a1/H1WhyICg'
                    'Dn6jaW/538h2nTADgjH0XER+ln6QfpZxER8U0TzTfxu/im+Sa+i7+IiI8nze8Upf'
                    'hdfJT+nD6KH8dH8bP74oO/nDqtAhQmAADwQOcEgP6uI+K3ETGoC0LRUQ/7OimUHP'
                    'WQBo56iMPPP4x6KNXVoEsXhQ55ZZ/ZreuErgkAsN+b0D0BYDpPUqQfpr9MP774j/'
                    'd370f6OH19Pwbid1Ond1RS/CEu4r/E99P7lY4IkX5y8Zfpk/SL+EH62ZF1Rdjn70'
                    'NhAgAAK3ROABhmERGfR8QvI6JXl4MPT3XoGND17v59XQJKdQi4P2etS0NunA7nPL'
                    'wuzYF2BQO+rkdfQ6luE1vO3fF6LY6sawgATGERuicAzMOys8LH6Xvxi4c3PN80EU'
                    '183XwT/xzfNt/Ed/Ef4pw7LKT4XaSIeJL+lD6K/xApPr4vOvjZ/cep+yIiXk+dBA'
                    'AA86I4AWC4VxH34x0iehcQfHgqdRv1kPn81gvwPUcibHv+YJHCwGKIlNLhUQ9dzt'
                    'pzXq8iha6FDBu5rZylawIAdPMmmngVEZ9NnQgAW3yUIiI+Tk/iPz68UWoi4rsm4r'
                    'v4uvku/lt821xEE9/Fd/HphJmWkeIPkeJf4iJdxEV8ly7iP8RFfBwptb1qH49k6P'
                    'K+8TR8ESleTZ0EAADzozgBYLjrFOlvmmj+bu3RAV0DHi5cdylSyLxwvnYBvlSHgI'
                    '0ihV5dFDqs6dRdoutZ7bodr3+z/qIdjpdz5sq6FOnywA5gCufzg2M4NouI+Mepkw'
                    'CgoxTLooWP4uMU8emj+XjfRUSzUrwQEQ8FDBERTfw0mhG7DCy7Hfzp/vcX8VH6Li'
                    'LiofAgoi3CiDifDgi5vohQmAAAwHaKEwDKuEyRPo+Izx5dmC9VpHAsox4iIjUDRj'
                    '20a7qMeihRpNC1i0KHvDqf+WHd+2ji7YGVAMAHVxHxZUT8auI8ACjhIiJitXjh/v'
                    'Nd2k4MJXzocLDqcbcDcihMAABgL8UJwKyktOeHEPP3KiKuU5Oelh5tMOqoh30xct'
                    'Z0GfWQme/jJWl/4UZGrKKjHtp1h39mttj3czcAYKvXoTgB4Dy1nRiYI4UJAAAc9L'
                    'g+GIC+biLi9fKm/vRwUXtNir03gTys2fpweugYsDdGl/hp86GNfLv8rKdLHm0nhV'
                    '2vR5ezDpyTIi2LWrrm3GXN1j+6La/RsNzfR8SbDhkBAOtuIuK3UycBADxQmAAAQC'
                    'eKEwDKehMRX7YXpXsXKex5vlORQs8L52v5donRrut4zt4ChbGKFAZ+XY++hv4FD4'
                    'sOOwGA7S4j4m7qJACA+G0oTAAAoCPFCQDlvYrlXfEPF6X3Fins07VIocf+fTkU7h'
                    'CwtuZgF4WenSU+PF2wSKFkF4X1dbomAMAwt7Ec7wAATOc3ofAeAIAMihMAyruNzb'
                    'sGVi7MPzLw4n/nUQ+Zz1cYY/Bhzbb4OXE6nHOwcCMjVoUihcXDWh8+fMzy4+n/6V'
                    'kAs/cmIt5NnQQAnKnfhKJ7AAAyPZk6AYATdRXL1oZ/u/ZoikhNioiIJprYfO7+id'
                    '3S9ufbC+RNavbH2LF/Xw4PsdsHD8XYEWfX84/iD8x3/ekUke5jd8m559eVIq3nvz'
                    '+v9+EHOHAcDv2bAMzBq4j436ZOAgDOzG8ieV8LAEA+nRMA6lnEtrv57u/K3TvqYc'
                    'vDXZ5fG/WwK8ah+DvWrOXbJUa7ruM5RzPqYcd5W/88t8dadDgBAOjmJpYFoQBAfX'
                    'cR8Z9DwT0AAD0pTgDmZQatvAt/fB7LN+87v9a9F+W7vFZbn1opUuixf18Oxz7qIa'
                    'UO1QcDvq4Dox50TQCA8hax/G8sAFDPXUS8jGWnSAAA6MVYB4C6bu8LFP5x34iDFC'
                    'mWkwd6jnrYsSZF6jbqIfP5Yx71EBGRUhpl1MPy4WZ13eWBaABAP68i4h+nTgIATt'
                    'T7iPg8Iq6nTQMAgGOncwJAfVcR8dsud/73HvUQu5/vNOphz/59Ocx+1MOeNWOMem'
                    'jPuXcXuiYAQC1XEfH3UycBACfoq4h4EQoTAAAoQHECwDgWEfFlRHQaTdC7SGHCUQ'
                    '9ZRQoZawaNeojDzxctUtg/6uEyIm4PRAAA+luE8Q4AUNK7WI5yuJ02DQAAToWxDg'
                    'DjeRXLOw0+7TriIDWp+GiDWqMeHmKvjzEYPIKh/VoPjnroke/6kmWBQtMcmOPQ7+'
                    'u6i4jLnUUWAEAJtxHNqzDeAQBK+CIivZo6CQAAToviBIDx3MZyRuNVRDyNiE4X1V'
                    'Oz46J8xoX9xw/fx6xQpPCoiOBQIUXmOQeLFAYWQ6R0X2DRJefuX9dluNMEAMZwFU'
                    '38NiL+dupEAOCI/U2kuJw6CQAATo+xDgDjuo6I148e3TcyYKxRD4di7LNlf/aoh8'
                    'xzBo962LOm6KiHiLtIcfmw1ocPH0fz8ez//LMAjtIilvOxAYA8dxHxmwiFCQAA1K'
                    'FzAsD43kTEi4j460fPpOg06iFiRyeFAaMeIu47KQwYjbAth2qjHmLPa5ETp8uoh0'
                    'OdFPafdRm6JsDxOjTqBZirz2NZFPp02jQA4GjcRcTLWP73EwAAqtA5AWAaryPi3d'
                    'Zn2rt2d7l/vlcXhQNrOndRyHz+UdeHgXmurdkWPydOh3MeXpdDHse6C3ecAMAUbm'
                    'JbtyoAYJuvIuJ5KEwAAKAyxQnAvMygjfeIH5/HvpbDHS6q9x71ELufH23UQ5cYO+'
                    'Lsev5gkcKAczqPelg/6zJ0TQCAqbyJiC+mTgIAZu6LiHgZ3rsCADACYx0ApnMbKV'
                    '5FxFU0e1oOpxg26iEO7z846mFXjEPxd6x5iB1NtxhtnI7nrI2S6JNvmVEPuiYAwP'
                    'Rex3Kc1i+nTQMAZum3EbGYOgkAAM6H4gSAaV1HxOeR4h8jolcRwerze4sUMgsIPj'
                    'y1UqTQN78dOawVEfQsdNi1Zudr0SVOh3M6FCm8CXeeAMDUbqO5LwaNPcWgAHBe7i'
                    'LiVaR4O3UiAACcF2MdAKZ3FRG/iYisEQb7nh806mHPuIdS+W3GfTTqYeAIhoc12+'
                    'LnxOlwzsPr8tjlgQwBgHFcR8SriXMAgLn4KpZdhd5OmwYAAOdIcQLAPLxJkT7MRB'
                    '56cT7tuSifcWH/8cOpe5HCofhdihQOySguOFikMOCcFClSWitS+CIibg5EBQDG8z'
                    'aWrasB4Jx9EREvw/tVAAAmYqwDwHy8SpGeRcSvmmh6j0pYey4OjHrYF7/rqIddMX'
                    'qOaXiI3fU1aON0PGdtlESffLuNeljsiQIckWf/l7+I2//HP0+dBlDGIpZ3iv5q2j'
                    'QAYBJ/Ezr8AQAwMcUJwKzsvLP9fLyKiKsU6ZcPF9AHFBGsPp+aPRflMwsIPjy1Uq'
                    'TQN78dOawVEfQsdNh1zloBRG6cw+fomgCn5lCBFHBMXsVypNYvp00DAEbzPiI+j+'
                    'WYIwAAmJTiBIB5uY1li8XrFOnTiFi/QD/k4nwa0EXhwJoUaX8XhY75bT7/qIjg0G'
                    'uQec7BIoV+r8dCkQ0AzNZtfLhA83TKRABgBF/GsjDvdto0AABg6WLqBAB45DZSfB'
                    '4RdxHLC+gPF7tTxMHr3vvW3D+3FrPr3tU1Wx9OD2MN9sbokX/2a5B5zs5igvzXW9'
                    'cEAJi/m1gWg95NmwYAVPU3sSzIu502DQAA+EDnBIB5uo4UL6OJq7i/q2/tLv+eox'
                    'LWnosBnRQmHPWw3JbxGnRcs/O1yInTxGLPCgBgPq6jiVcR8X+fOhEAKGw5xiEZ4w'
                    'AAwPzonAAwX9eR4tW2LgIrnxzuUtDh+b2dA/bZE79zF4Uez2e9BjlrYk9XicNxdE'
                    '0AgOPyNiJ+M3USAFDQFxHxIkJhAgAA86RzAsC8vY2I30SKf4iIhzv31zoILB8Y1k'
                    'EgDeiisOf8tS4KB87PzT/7NdgRZ9fzj+IfznfRadwEcHR+9vJ/iT9c/fep0wDqeB'
                    'MRzyLi76ZNAwAGuYuIV7H8GQIAAMyWzgkA8/cm2rv6Nu7cX7vLf2gHgZUuCls7Bw'
                    'zogvAQs8P5e21Zk/0atOs6ntOxi4KuCQBwvC5j+d9yADhG72LZLeHttGkAAMBhOi'
                    'cAHIc3EfE8Iv42Ih7duZ8irXcQiOjV6WB1/95OCj27NKx1UujQvWDvGY/S6vEadF'
                    'yz87X4sObNnigAwPy9uv/111MmAQAZ7iJiEcsiOwAAOAo6JwAcj0Ws3tW3r4vClu'
                    'cf6fh8ry4KB9Yc7KKQkd9m3KzXIGfNtvhL7yLi6kAEAGD+XoUOCgAch68i4mUoTA'
                    'AA4MjonABwXF7d//rhrr6NDgAP3QlWuwgM6SCQDnRR2Ld3z/lrXRQOnJ+bf/ZrsC'
                    'POruc34i8ORAZOwM/+8/8Sf/jH/z51GkB9r+6/F9BBAYC5+m0k70MBADhOihMAjs'
                    '+r+1/Xf2i+ZdRDxP0F9DFGPeyL33XUw64YPcc0ZL8GbZyO56RI75porg5EBACOy6'
                    'v7XxUoADAnX8Xyv1HX06YBAAD9KU4AOE6v7n99XKAQ8egC/VoHgY3nD+3f9nxq0u'
                    'MChfb5nl0a1ooU+ua3I4es1yDvnMXWsRcAwLF7df+rAgUApnYXy/ENi2nTAACA4R'
                    'QnAByvV/e/Pv6heZdRDyvPH9q/7fkUKaIZMOphx5oUqduoh8znK4x6eBcRVwciAA'
                    'DH61VE3EbEX0+bBgBn7F0s/3t0M20aAABQhuIEgOP26v4i+/a7+roUKQzpIJAGjH'
                    'rYc36nUQ979u/Lofeoh8frFpomAMDJex3L9tn/MG0aAJyZu1h2SricNg0AAChLcQ'
                    'LA8Xt1f5H8110v4mdfoN9XBLAy6uEh5pbn+3RBKDrqYWNN7yKF5RpdEwDgfLy5/x'
                    'ZBgQIAY/gyIl6lZfceAAA4KYoTAE7Dq4iISPcdFLZdZN9xgb7kqIeIZZHCowKF9v'
                    'kBox6WUyQKFCk8qp3IeA0+rFnsWQGcokPFS8CpexPLltpvI+LplIkAcLLex/K9/d'
                    'W0aQAAQD2KEwBOx6v7X3/dpdPBrEc97FiTInUb9ZD5fOZroGsCAJynq2jiZSwLFD'
                    '6dNhUATshdRFxGUgQPAMDpu5g6AQCKehURX0TE8gJ72rNy4/l0/79Oew+tuX9uLW'
                    'bXvatrtj6cHjopHPz6DsVPmw91eg3eHIgMAJyu64h4ERFfTZsGACfiy1j+d2UxbR'
                    'oAADAOxQkAp+dVRPz24bPMi/i9ihT2PTekSGHP82tFCj32r63ZFftxjPehOAEAzt'
                    '1tLC8kfTFtGgAcsfcR8Z8j4vNYjg0CAICzYKwDwGlaxPIHHP/w8EjGqIflQ2l9zM'
                    'HG84f2b3s+NenxqIdDuR2IX2vUw0Ps9ddgsSdL4BTt+7cJOHevYjnq6R/2LwOAB3'
                    'exfF95OW0aAAAwDZ0TAE7Xm4j4zdojQ0Y9RHTrQnAg/hGPetA1AQDY9CYi/tdYfp'
                    '8AAPv8fUQ8D4UJAACcMZ0TAE7bm/tfLyPi6cOjXToJbHRRWC5vDu89FH+li8JDzK'
                    '57Dzz/kOe+Tgo980+RFnt2ACdoa6cXgMeuYznm4W1EfDZlIgDM0rtYdtu5mTYNAA'
                    'CYnuIEgNP3JlJcRxNXsVqgENGpiKD3qId2TYdRD8swW4oUBox6iLgvUug76mE9B1'
                    '0TAIB9biPiZTTxOiL+btpUAJiJdxGxiBRXUycCAABzoTgB4DxcR4qXEfE2mvj00b'
                    'Mdigg+1CRsFBMM6HSw+nxqUn4XhQNrUqT9XRS657fYkwFwijRNAPq5jIirWHZReP'
                    'w9FwDn4H0s30O+mTYNAACYn4upEwBgNNcp0otI8dXWZ1N8uFDf4fl0/7+15/fpEP'
                    '9RzK5795z/ELPL17edrgkAQI7rWI55+Ptp0wBgZO8j4jcR8Ty8hwQAgK0UJwCcl9'
                    'sU6WWkeLfzYnzmRfy1goIBRQSr+3sXKex5vlORwvbnFntOBADY5jYiXkfEf47lxS'
                    'oATtddRPw2loVpbybNBAAAZk5xAsD5uY2IlynSFz0u1O987lEXhZ5FBKvPby1QaJ'
                    '/fp2uRwuH9uiYAAENchS4KAKeqLUp4Hsui9tsJcwEAgKPwZOoEAJjMqxTpOiL+rk'
                    'n3w9W3zVhPOx5vn1vZ1xYTNB8e2D+3fWP/tudTpIhmJWbXvQfWpEix9+teLrrcEx'
                    '04Rfv+TQHo5zaWXRTexrLo8dPpUgGggLuIuLz/uJ0yEQAAODaKEwDO22VE3KRIby'
                    'LiaZOa3QUKEf2KFAYWEbTPp2aj8KHr3nbNjgKFiNhVpHAXuiYAAOVcRRMvYlmo8L'
                    'fTpgJADx+KEpKiBAAA6MNYBwDeRsTLiHj/MO6gz6iHePzcwwiFLnu37N929lrM3N'
                    'zyRj1chrtgAICybmPZ+vs/RcS7STMBoKv3EfE3YXwDAAAMpjgBgIiI61jOQ/5q7U'
                    'L9viKFXbbsWysmGFBEsPr81gKFQ7kdiJ8iRUopIj3cEQMAUMNNLItD/yqWF70AmJ'
                    '/3EfGbWBYlXIaiBAAAGExxAgCt21gWKHwRsbObwAeZRQaPOh4MKCJon+/dReHA+S'
                    'nSZfjBEwBQ39tYXvT6bSzbhQMwvXfxoSjhzaSZAADAiXkydQIAzM6riLiKiH+IiI'
                    'cChSaaiGbL6vYi/7bntjzfFhM00Rzeeyh+OzGiWYk5ILd7dxFxmdKh6gbglDTNvn'
                    '+IAKpbxPKu3EVE/PWUiQCcsS9j+W/x1bRpAADA6VKcAMA2b2I56uFtRHwasSwqaN'
                    'L9xbu+RQrN6qc9ihQOFBkUKlK4DF0TAIDx3UbE62geihR+PWUyAGfiLpbvexeR4m'
                    'baVAAA4PQZ6wDALtexHPPwrn1gbdTDvnEPu2zZ92jUQ+b+bc9vHfVwKLfl83eR4v'
                    'LhHB8+fJzHB8C83MSyk9V/ivtxWwAU9z4i/iaWoxteRShMAACAMShOAGCf24h4Gc'
                    's5yA/WihS2OXTBb+P5h3irz+/TIf6jmN32XoauCQDAPNyEIgWA0t5FxF/FsijhMr'
                    'z/AwCAUSlOAKCLRaT4q1i2vHzQqYvCoSKFjXgPBQVd7mjucHZGkcJdLH84BQAwJz'
                    'ehSAFgiLuI+PtY/jv6MpZjHAAAgAk8mToBAI7G20jxIpp4GxG/bB9sL/w3qVk+0G'
                    'zZ2RYBdHwuRYqmfWDf3tUYu55vax2a+zw3F37Y+ybcNQMAzNdNRLyKaBbLX+N1RD'
                    'ydLBuA+XsXEW8i0puJ8wAAAO7pnABAjpuIeBFpfcxDxMaoh33dDHbpMuohY/+u5/'
                    'd0UbicfO69Dx8+xv0AOE43EbGIZUvy38RybjoAS3ex3iXhzZTJAAAA63ROAKCPRa'
                    'S4ioi30azfsbfWSSG3i8KW5x/irXZSONRF4UD8LV0UvojlD/oBAI7FbSwvur2JJl'
                    '7GspPCr6ZLB2BSX0bEm0hGNgAAwJzpnABAX1cR8TxSfLntyU5dFPbduZw2P13ppN'
                    'DlrudDsdNazMWBaAAAc3YVEZ/H8k7h34ZuCsB5+Coi/iYifhbLfwPfTpkMAABwmO'
                    'IEAIa4jYjPI8XfRIq7zSc7j3rIeK7CqAddEwCAU3ETH0Y+/FUsu0MBnJL3sRzb8L'
                    '9GxIuIuIzl+1IAAOAIGOsAQAmXEXEVKd5ExC83RyqsjXqI2D3uYZpRD4uUDJ+Hc9'
                    'I0+/7BADgZb+8/XsfyjuJXEfHZVMkADHAXy3/P3sSyUwwAAHCkdE4AoJTrWN658t'
                    'tdHQvWOilsk9kJodeoh/U1uiYAAKfuNpYX9F7GcuzD38SyFTrAnN3F8v3aX0XEs1'
                    'gWWF1Nlw4AAFCC4gQASlvEssXmV7uKBQaNeojHz/UqUviQKwDAubiJZcerF6FQAZ'
                    'ifbQUJb6dLBwAAKM1YBwBquI7lD70XkeJvI+LRSIXSox7amGujHnbFXT7/RTS6Jg'
                    'AAZ+smloUKl9HE81h2Vvg8In41VULAWXofywKEq0gKEQAA4NQpTgCgpkW0s0FT/D'
                    'Ii9hcp7CpQ2LJv1/MP8VaLFLbvXRzssACcll3/jgBwE8vRD2/uP/88PhQrfDp+Os'
                    'CJ+yqW7xPfxrKwHQAAOBPGOgBQ23Usuyj8NiJ2jl0oMuohrX66d9TDlxG6JgAA7P'
                    'A2Il5HxPNYjn/4TSy/f7qbLCPg2H0Zy39L/lO0XfYUJgAAwNnROQGAsSxi+YPuy4'
                    'j4bFtHg86jHnY91z5/eNTDZfe0AQDO2k2sd1V4EcuuCu3H07ETAo7CVxFxdf/xds'
                    'pEAACA+VCcAMCYrmP5Q+zXsRyrsPxhdt8ihX6jHt7F8gdkAADku77/uLz//EUsv7'
                    '9rfzUGAs7TXXwoRLgKneoAAIAtFCcAMIXL+HAH3q92dUNYK1Lo20Vh5fn7eIu94y'
                    'GAk9M0u/6RAKCA61htzd7Es1gvVngRuivAKWqLEZYfyYgGAADgMMUJAEzlNiI+j+'
                    'UPrd9ExKf7ihQKjXrQNQEAoK7bWN45/XblseexLFJY/dBhAY7LejFCKEYAAADyKU'
                    '4AYGpXsfyB9SKW4x6ebhvZ0HnUw/7nFgPyBI6RpgkAc3Bz//F24/GXsfw+8PnK7x'
                    'UtwDy8jw9FCO2vAAAAgyhOAGAuFrHsoHAZXUc9bHn+ftG2x3VNAACYl6sdj7+IeB'
                    'gP8fz+47P66cBZexfrhQg306UCAACcKsUJAMzJTXwY9XAZEb/sVKTQrYvColSSAA'
                    'BUdX3/69XG48/jw1iI56FoAfr6Kpb/P7sOXREAAIARKU4AYI6uYvlD51exLFLYOu'
                    'ohYlmk0GHUw7todE0AADhyN7FtPESzNhriWXwoXjAiAj50RLiJiOtI3hcBAADTUZ'
                    'wAwJy9ieUPn19HxOtI8TQi+ox6WDx0UgDOw7ZiJQBO1c39x9WW517GesFC+6FwgV'
                    'PzPj78/+A62mIEAACAGVGcAMDc3cZyJMOb+19/3WnUw4fnv4rd84wBADhtV/e/vt'
                    '3y3ItYFi68vP+8/dWoCObsq1i+R7qK/YU5AAAAs6M4AYBjcRPLMQ+LWBYqfNapSK'
                    'GJy1GyAwDg2Fzf/3q14/mX97++iGURw/PQeYFxtF0QruNDIcJt6IQAAAAcOcUJAB'
                    'ybm1j+oPhlLAsVlkUKW1q4p0jvm2jejJUYAAAn5Wrj121e3v/6IpYFDM/ufx+hiI'
                    'Hd7uJD4cG2XwEAAE6S4gQAjtVVrBYppPv2u+tFCouUUgDno2m2VCoBQD1XG7/u8i'
                    'KWhQsRHwoaNn//IiKeDk2IybVjF27jQ6HB9f3nN/cfAAAAZ0lxAgDH7iq2Fym8j+'
                    'X4BwAAmNr1yu+vOqx/fv/RehEfihu2ff48dGmo5d3K72/iQ3HBbXz4c139PQAAAD'
                    'soTgDgVFzFepHCmwlzAaagaQIAp+Mm1u+wv+oR43msFzi0XsR6YUOXPfvOmENRxL'
                    'sDz9/G9uKBm3jcyeD6fj0AAACFJa1vAQAAAAAAAICaLqZOAAAAAAAAAAA4bYoTAA'
                    'AAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAA'
                    'AAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgK'
                    'oUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAg'
                    'AAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAA'
                    'AAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAF'
                    'CV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTg'
                    'AAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAA'
                    'AAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAA'
                    'CqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQ'
                    'kAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAA'
                    'AAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAA'
                    'BAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpT'
                    'gBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAA'
                    'AAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAA'
                    'AAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqh'
                    'QnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAA'
                    'AAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAA'
                    'AAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJ'
                    'XiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAA'
                    'AAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAA'
                    'AAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAK'
                    'pSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQ'
                    'AAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAA'
                    'AAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAE'
                    'BVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOA'
                    'EAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAA'
                    'AAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAA'
                    'CoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFC'
                    'cAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAA'
                    'AAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAA'
                    'AAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQle'
                    'IEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAA'
                    'AAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAA'
                    'AAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAql'
                    'KcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAA'
                    'AAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAA'
                    'AAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQF'
                    'WKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQ'
                    'AAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAA'
                    'AAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAK'
                    'hKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJw'
                    'AAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAA'
                    'AAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAA'
                    'BVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4g'
                    'QAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAA'
                    'AAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAA'
                    'CgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUp'
                    'wAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAA'
                    'AAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAA'
                    'AAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVY'
                    'oTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAA'
                    'AAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAA'
                    'AAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqE'
                    'pxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAA'
                    'AAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAA'
                    'AAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAF'
                    'UpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBA'
                    'AAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAA'
                    'AAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAK'
                    'AqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnA'
                    'AAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAA'
                    'AAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAA'
                    'BUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVih'
                    'MAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAADA/79dOxYAAA'
                    'AAGORvPYp9xREArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAA'
                    'AAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5A'
                    'QAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAA'
                    'AAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAA'
                    'AAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJ'
                    'ITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAA'
                    'AAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAA'
                    'AAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAM'
                    'BKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAA'
                    'AAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcg'
                    'IAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAA'
                    'AAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAA'
                    'AAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWM'
                    'kJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAA'
                    'AAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAA'
                    'AAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAG'
                    'AlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAA'
                    'AAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQ'
                    'EAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAA'
                    'CAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAA'
                    'AAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArO'
                    'QEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAA'
                    'AAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAA'
                    'AAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAAL'
                    'CSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAA'
                    'AAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnA'
                    'AAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAA'
                    'DASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAA'
                    'AAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVn'
                    'ICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAA'
                    'AAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAA'
                    'AAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAF'
                    'jJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAA'
                    'AAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTg'
                    'AAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAA'
                    'BgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAA'
                    'AAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKz'
                    'kBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAA'
                    'AAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAA'
                    'AAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAK'
                    'zkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAA'
                    'AAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJw'
                    'AAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAA'
                    'CwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAA'
                    'AAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZ'
                    'wAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAA'
                    'AAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAA'
                    'AAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAF'
                    'ZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAA'
                    'AAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEw'
                    'AAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAA'
                    'BYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAA'
                    'AAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk'
                    '4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAA'
                    'AAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAA'
                    'AAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAAC'
                    's5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsArlA7li6b'
                    'pQDAAAAABJRU5ErkJggg==')
                app_manager().upload_asset(
                    created, 'nighty',
                    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAACCcAAAgmCAYAAADO0y'
                    '2yAAGt5UlEQVR4nOzd25JcV3of+C9BAGSRbFWRTTVDbnWgJM8oZmLsQDlCtiPmBv'
                    'UGxO1coebKl6x5AtY8QcNPQOgJRN/4wjGehsIR9hwUbihsy7LH7mar2XJTokiwQR'
                    'JAHbDmYmdW5WEfM3PVzsPvx6hgYa+11147AYJVtf/5fYOUUgAAAAAAAAAA5HKj7w'
                    '0AAAAAAAAAAJtNOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOA'
                    'EAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAA'
                    'AAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAM'
                    'hKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQ'
                    'AAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAA'
                    'AAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyE'
                    'o4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAA'
                    'AAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAA'
                    'AAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISj'
                    'gBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAA'
                    'AAAAAAyEo4AQAAAAAAAADISjgBAAAAAAAAAMhKOAEAAAAAAAAAyEo4AQAAAAAAAA'
                    'DISjgBAAAAAAAAAMhKOAEAAAAAAAAAyOpm3xsAGPcP/sk/Lz5JoyPp6vM0NnHqWC'
                    'o5Vv55w3rTn0fE639v5/Lznb+zMzE2GAxm7mFGiynAhhlEDMr+46/7+2Aw/ctB9f'
                    'ymv1cGY2sssIfSKcv6e69hzsTeu/w9Os/fuRXnlL5+814jxxot1628j1yu73KHJc'
                    'f2hx9V9iLiYOk7WczTiHjSYf7jOcfyS81Trkuq20wf+1zmNWtvrWSw67Xbzk8LvM'
                    '4VYymt2O8bsBLSqw5/Acz8rKD45PzZ+dXXKIOxr2nHj42+/q45NnHe9Pj4nOnPS3'
                    '49fm6rr7GBzTOIRxHxKPr+Or6LFMXfXZ3+ak6X35em8Z/NNl2n7X6mrsWsf3H/D/'
                    'veAsAl4QQAAKAvh2OfH0QRHoiYDRHsR8Sd/NvpzQcd5n7Uce2vYzb88LTk2OOGXw'
                    'MAAMtzFCkexCAeRMSfRMRJ+BocgC0gnAAAACzTXlwFCw6H/96Pq4oGBxGxe33b2X'
                    'q7EXGv5Ph0IKIu9PCLiPh0+PnTmAw2PK74HAAAKLcXRRhh9M7/ezGIn4SQAgBbQD'
                    'gBAADo4iCuAgjj/96PiDuqaG6kOzFZuWI82FAWahiv1vBpXAUbHpccA4CtV9vWBt'
                    'hExzGIOxMt+Ip2CfcihBQA2GzCCQAAwLTDuAoe7A8/DkLFA9oZr9YwXrWhLMjwJ8'
                    'N/P4miKsOnw4+nMdt6AgAA1t1eRBxHikiDIph0GVIY5ZQmQwrH4etiADaIcAIAAG'
                    'ynvSgCBwdxFT7Yj8l3yENuZSGGcaMqDE8r/g0A603RBNgugziOUeh7+N9/GqSYqa'
                    'JQzL0XET+NiD+KopLCp9ezSQDIRzgBAAA2217MhhAOQhUE1sN4FYYPSsZ/EVfVFj'
                    '6Nq+DC48z7AgCArvYjDauJjWURIkWkSBGDqAopPIiIBxHxT6MIKTy9hr0CQBbCCQ'
                    'AAsDn24yp8cBgR+ymSSghssjvDj7LKC6OqC0/iKrDwNFRcAGBVqJoA22UQJ5efXw'
                    'UPYvxYZUih+OWHEXEUEQ8jxtYCgDUinAAAAOtpPyaDCAeRVEOAMaOqC6PgwkdjY3'
                    '8WV5UWnox9DgAAOexHigcTYYSI8eDBxLGaVg+7UXxdexRFQOFRhr0CQDbCCQAAsB'
                    '4OYxRCKP4tiADzuzv8mG4VIbQAwLVIyibAtnk0iEFlGCEiurZ6uBMRH8dVSOHx8r'
                    'cMAMsnnAAAAKtnPyaDCHf72wpslarQwi/iKqgw+veT0O8XAIBmhxFxL8WwGkJZGC'
                    'Fi3lYP9yLiJxHxRxFxHL4+BWDFCScAAED/9uOqMsJhRNzpbytAiTvDj3tTx7+Oq6'
                    'DC+AcAVFM0AbbNSUREkUtIw08bQgplrR6mQwqT5z+IiPsR8fDyegCwgoQTAADg+u'
                    '3HVRDhfmjRAOtqN4rAwnRo4U9CYAEAgOL7veJrxbEwQWNIoSa4kAapqtXDbkR8FE'
                    'Wrh6PQ6gGAFSScAAAA+e1F8UOpw4g4jKQyAmy4qsDC4yiCCo9DyV2A7aRqAmybhx'
                    'FRGTy4bPUwOr5oq4di7p0oWj38syhaPXy60B0AwBIJJwAAQB6HcRVIuNvnRoCVMB'
                    '1Y+LMoQgqjj6fXvSEAALI6ilHLvqrgQZdWD9PH60IKxS8/iOL70ZMYhSQAoGfCCQ'
                    'AAsBx7UYQR7kfxAyCtGoA6d4cfHw5/PR5W+KSXHQGQVUrKJsA2GQwGJxMHGto3tA'
                    '4pVLR6uDx3ct3diPhxXLV6eNLpJgBgyYQTAABgfgdRBBGOQnUEYDHTYYU/iSKk8D'
                    'j8EBkAYN2cpJTuDIqyBpMWDSnUHEuDNFtFoZh7NyJ+GhH/NIpKCk+73AwALItwAg'
                    'AAdHMYVxUS7vS5EWCjjbeB+EVcBRU+6Wc7AAC0tBcRxxHDoEEaBg3mCClMVEJYtN'
                    'VDMffDKL6XPYria0sAuFbCCQAA0Oz+5UfSrgG4dneiqKjwYUR8HVchhU/Cu94AVp'
                    '9uDrBtjoftFC6lSDFIw7BAy1YNnVo9TB+vCykM4k5E/CQi/lkUIYWn7W4LABZ3o+'
                    '8NAADAirofEY+i+EHNH0fEgwjBBKB3uxHxQUR8HBFfRRFQOIriHXoAAPRrPyKOI8'
                    'VMMCkN/ykNLJXMHz92eW7V3Kg+NnHu5PkfRMSnUXzvCwDXQuUEAAC4chjFQ777KZ'
                    'IgArAOPoirsMIfxVVFBQBWgaoJsF0GcRLjofaSqgaLtnooPh10avUQEZEGqazVw2'
                    '4M4o9DFQUAronKCQAAbLuDiHgYxTtGfhIqJADr60EUlV6eRvH32kGPewEA2Db7ke'
                    'JB28oIKVKkVFNJoWaNVlUUSioxpDRVReFqrioKAFwLlRMAANhG+1H80OUoUtztdy'
                    'sAS7cbER8OP/4sihY1j8I74QCuVUrKJsA2GQwGDy9/UVbBYHR8MH0oxSANZuc3rD'
                    'FTRaFqbsm6qSjdMF1JQRUFALJTOQEAgG1yFEW5859HxI8jBBOAjXc3ir/vvooioH'
                    'DQ52YAADbUYUrpg5mjXaooRE0VhZIqCONVFFpVUig5VlNF4UkUbQ8BYKmEEwAA2H'
                    'QHUZQ3fxpFT/bZHxgBbIcHEfHTKH7YfNTrTgAANstJxLBtwnTVlA6tFxpbPXQJKb'
                    'Q8v6LVw51I8ZMovpcGgKURTgAAYBPtRfHg7UkUD+I+jKLMOQBFNYWPowhtnUTxdy'
                    'YAAPM5jIh74wcqHvgvL6RQc6xVFYX2IYUPo/i++qBkJQDo7GbfGwAAgCU6iIjjiL'
                    'gfwggATXYj4qMo/t78JIqgwqe97QZgU5Q9DAQ22aOIiBhMHR21TRhEDMYHR39HlM'
                    'yfPpYixSANyudOrzF2bBQyGBS/aH290j2nuBsRP41B/G+hkgIACxJOAABgExxFxF'
                    'GkyXerANDKbhQtHx5ExB+FkAIAQFtHEXEnImpDAClSDAYzyYNWoYNULFCEBZYdUq'
                    'jb8yBNhyp+HEWViKMoKnABQGfCCQAArKv9GIUSRj8MAmBRQgoAC5jpNQ9srOGD+5'
                    'NWFQli+PdDlyoKU8cXDSmMVUJofX5J5YcPIsWnUVQrfDx9jwDQ5EbfGwAAgI4Ooi'
                    'ib+fMoypELJgAs34Mo/p59FEUYDACASScRcae0lUuK8hYvqQgppOnBmvmzh1IRdG'
                    'g5f3Qsxdh16643fXx2z7sR8ZMo7h8AOhFOAABgXdyP4p0ZP43ioRkA+Y1CCg8jYq'
                    '/XnQAArI69FOn48lddHvYPj5dWWqkIB1SFFLoEDDqHFMr2HBMhhY+i+B59r2Q2AJ'
                    'TS1gEAgFV3FKN3pADQlw+j+Pv44fDjaX9bAVhBujnAtjmOiN00KP7jn2iZUByYVN'
                    'fqISIGg0Hz/AytHi733qHVQ0REGly2ibgXoc0DAO0JJwAAsIr2ovhhz3Gk2O13Kw'
                    'AM7UbxDrmjKP6O/qTHvQAA9GUviq+FLh/qTzzoHx0vDlypCi7EMKQwGDu/bn6GkM'
                    'JlQKHl9UZVFIZ7HrV5+N9DqwcAGggnAACwSvYi4nhYHlMoAWA13YmIP46IP4niB/'
                    'NP+twMQO9UTYDtMoiHMf79atmD/vGxNg/7h8fHHvi3mj99LEWKQRq0nl8arpg/pP'
                    'BRRBxEEWR9GgBQ4kbfGwAAgIjYj6JM+KdRvCtXMAFg9d2LiJ9G8ff3Xq87AQC4Hv'
                    'uR4kFpKCnF5cP6ND5heLxqftnxUbuHmfkt1ri8fttrjh2b2Hvdvsv2XPzzQRTB1Y'
                    'OSWQCgcgIAAL3aj6Ls44N+twHAAj6Mos/wcWj1AGwbVRNguwzG2haUVSIYHY+ING'
                    'jR6qFmnVFAYTDop9XD5d7bVn+4uu87gxg8juJrw0fT9wXAdlM5AQCAPuxH8UOKn4'
                    'dgAsAmGLV6+CRUUQAANtNhTH//WlVdIKK8GsHY8bbrpDR1ft38qkoKqaaSQs0ara'
                    'oolFRiSCntpkgfR1FhCwAuqZwAAMB12ouI40jxUd8bASCLD6Jo0XMUqigAG27mYS'
                    'Gw6U4GaVgqoE0lganjKVK7KgoVx1NRBuFqjaZ1BtOHUpTuv2GNmSoKbfdd7PnDGM'
                    'RBFFW2ngYAW0/lBAAArsNeFO0bPo0QTADYcLuhigIAsFkOI+LeZRWEumoJNRUGSq'
                    'sodKmkkK7aPczMb7FG7f4rqiCUVoCo2/fssXsp0uOIOCgZBWDLqJwAAEBuJ1H0mt'
                    'ztdxsAXLNRFYX7EfG4z40ALJ2iCbBdBpPtCSqrEFxNqD0+UY1gdLxsrYp1UupYRW'
                    'Hq+CigMCgWaZw/XQHicu9l+ys//26K9DgGvi4E2HYqJwAAkMtRXFVKEEwA2E67Ef'
                    'GT0G8YAFhfR5Hibm0Vgo7VD8arEcyMdVgnpVS+RpdKCqmmkkLNsVZVFCaP70aKn0'
                    'TxswIAtpTKCQAALNthFA+h7va7DQBWyIdR/P/hfhTBNYD1pWoCbJdBnFx+XlWFIK'
                    'K6kkJDRYM06FBFoeJ4io6VFAbTh4aVIBatotDueh9H8XXhUQCwdYQTAABYlv2IeB'
                    'Qp7vW9EQBW0t2IeBLFD6I/6XMjAAAtHUfEnZmjFQ/4I6L8IX/FOZfHo2NIoWKdFC'
                    'kGg5mNXX+rh5q5Qw+i+BnC/Yh4WnI3AGwobR0AAFjUXhSVEn4eIZgAQK3diPjjiL'
                    'F3IAIArKa9iDjp2rZhrlYPcXX8sl1E3Tk162Rv9VCzl5l9159/LyIeR/E6A7AlVE'
                    '4AAGARx1E8YNrtdxsArJmPIuIgiioKT/vcCEBbKennANtkMBgcx/j3uh3aLSza6m'
                    'FUjWCmTcM1t3qoraRQcax1q4fi+N0oWn4dRlFhC4ANp3ICAADzOIziBwc/DsEEAO'
                    'bzQRTvljvodxsAADP2UkrHpSN1lQ/KqhCMKim0PGf8eKsqCg3HS4NVHaoxVO6/RR'
                    'WFdPWL6jWKnyk8juLnDABsOOEEAAC62IuiT/hPougdDgCLuBt+GA0ArJ6HEbFb2i'
                    'IholV7hslDNa0eKs4Zv06nkELZ4ZSqQwoV15w8tFirh4mQQvn5u1H8nOGo/A4A2B'
                    'TaOgAA0NZxSukkVEoAYLlGP4z+XyPiUb9bAQCI/Yh4cPmrqhYJw7GIyNvqYTQ23T'
                    'Kh6pyadVLq2Oqh7B66tnqImGxTUX+9j2MQe1GEQwDYQMIJAAA0OYjiYZFKCQDk9H'
                    'EUDwNO+t0GwJSqdzQDm+qkKiCQIsVgUPbUf/jvnCGFsgf942Md1ikNW9RddyaTkc'
                    'r337DGRLiieu6Po/g5xFEAsHG0dQAAoMpeFO9W+GkIJgBwPT4K1RMAgP4cRMSDuh'
                    'YMlS0SovqcylYJo3YPLc8ZP96p1UPF8YVbPVTtv2urh9k1HoSvCQE2ksoJAACUuR'
                    '9FMOFOv9sAYAuNyigf9bkJgIhQNQG2zWCqnUDXFgkN53SqQlBzzvh10qBFq4eadU'
                    'YBhYmKEMts9TC9zlQFiMu9z+7vQRRvmjiKiKezOwdgHamcAADAuL2I+CQi/jgEEw'
                    'Doz4OIeBzF/5cAAK7DYaS4VzpSU90gpakKBuPnzFOFoEv1g7G9zeyh4zql99H1Hl'
                    'JNJYWaYzVVFD4IXxMCbBSVEwAAGLkfRdnE3X63AQAREXEvih9GH4Z3ywE9KH3YCG'
                    'ysQQxOIqKxUkHVWIo0WX2g6byqKgQR1ZUUGtbqVEWh4niKkooQHaoxVFaC6FpF4W'
                    'ru3fA1IcDGEE4AAGAvIh5Fig/63ggATPHDaADgOhylSPcaH+o3jJW2SBg/r+V6Ey'
                    'GF3K0eKo6Xhi3Krtt1//OFFHxNCLAhhBMAALbb/VAtAYDV5ofRwPVTNAG2zcnMg/'
                    'GIxUIK09UH2qzXtgpBy7Va309F2KH0PrpWgkjD8xcNKQgoAGyEG31vAACAXuxFxC'
                    'cR8cchmADA6hv9MHqv320AABvoKCLuRIqrygPDfy7VBZaqxlLxcL+0RczYtZqOX+'
                    '6lwznTx2f20HGd0vuou+7MoVQEHVrOn3zp09WxdPk14X7JWQCsAZUTAAC2z2EU1R'
                    'Lu9LsNAOhk9MPog8ofWAMAdLMXEQ8njoxVEUiRFq6iUNkioe68eVs91Ky1rFYPrS'
                    'opVKxxWQlisSoKdyPiSQziMCKeBABrRTgBAGC7PIyID/veBADM6W4UAbujfrcBbC'
                    'xBJ9g2xzEoqSZY9WB8aqzuvJmhqlYPo/M6tHqobJXQtFZ0DCl0CVuUzc/X6mE30m'
                    'WLhycluwRgRQknAABsh4OIeDR8hwEArLMHw38f9bkJAGDt7UXEcduwQeeQQs2D/d'
                    'KQQsdKBpdVCDqcM763VvfTNWzRtRLEAiGFQQx2IwQUANaNcAIAwOY7joiTiJJ3gw'
                    'DAenoQEU+j+H8cwHKomgDbZTD1fXKHkMLMA/lVaPXQ8pzp463uZxmtHirWbgxZVB'
                    'wb3vvuIAaPQ0ABYG3c6HsDAABksxcRn0TEj0MwAYDN82GongAAzGc/qloepqgOK4'
                    '1aIwz/aX1OxVhKqahAUHOtNutd7qfrHobHW99PzfHS+yib33X/DWukSLsp0uMofg'
                    'YCwIpTOQEAYDMdpEifRMSdvjcCABl9HBGfRlHSF2BuqfKJHrChTirfrT/SoiJC51'
                    'YPFWOlLRLarNelCkHFOePXSYOW91OxziigMFMRomU1hgVaPYwCCodRVNcCYEWpnA'
                    'AAsHmOI+KnIZgAwHb4JCIOet4DALA+9iPiQbp66/1cVQ+m3r3frZJCxfGUptZpWq'
                    '+pCkGX6gdjeyu9nw7rlN5H13tINZUUyte4G0Vgda98VwCsApUTAAA2x15EPIoUH/'
                    'S9EQC4RrtxFVB42udGgDWlaAJsl0E8Gn06UfmgqqpAMXF0bu1YijRZ/aBF9YWysR'
                    'RptvpA3XlVVQgiqisptFhr4n46XHt0PEVJRYgO1RgqK0FUr3E3BvE4VFAAWFkqJw'
                    'AAbIaDKN4hIJgAwDa6E0VAAQCgzmGkuNe52sDVxPmqDsxRmSGldNkmoepabdabuL'
                    'cuexgeb30/NcdL72OeShBtrpnibiQVFABWlXACAMD6O4oimHC3320AQK/uRcTDvj'
                    'cBAKy0k8vP5mmJMH5u1fEcIYWywY6tIxrva1mhiy5hi2W2epg8XgQU0tjY6OPVFn'
                    '4ArBDhBACA9fYwIj6OoqQ1AGy7D6MI7QEATLsfRZhxUtWD/NHYHIGChUIKFcc7hx'
                    'TmCV+0OD6zhy7rRMV9LDOkcOVuxFULDwBWw82+NwAAwFz2oihfPfuDFQDYbg8j4s'
                    'nwA6Ba3buigU30MCIiBiUjo78PBuOH0vDQoBgvO6/i3ImxwdV6g8kLtN7L+FiKFI'
                    'NByWDVeXX3lgatzxk/ngZjr03Ha4+Op0gRg5h9TarWGUwfSsX+66/5YPirowBgJa'
                    'icAACwfg6ieOAimAAAs3ajeJfcXr/bAABWyFFE3ImI5nYN69LqYbpFQpt9zBwau7'
                    'eua6WOrR4qjpfex3JbPTwIrb8AVobKCQAA6+V+pHgU2jgAQJ27UfwQ+qjfbQAAK2'
                    'AvIk4mjtRVJ6gYb6w20LTu2NhEVYY251XsM6WS6gN161Ucv6xC0OGc8b21vp+Key'
                    'm9j66VINLw/PL5H8YgnoQ2DwC9E04AAFgfxxHx4743AQBr4kFEPA4/hAamVL7bGN'
                    'hUxzGIOzMP8CPahRTKHuSPWj1UnbtISGHOVg+LhhQWbfUwup/G1hWZWz3UhBQ+Hh'
                    '57FAD0RlsHAID18CgEEwCgq4cRsd/zHgCA/uxFxHFl+4CRju0VJtoZdGwTMTE2tt'
                    '68exkfm6vVQ10biy57uI5WD9OHK9ao3H+Kh1G0ygSgJyonAACstr0o3vV5t99tAM'
                    'Ba2o2ITyLioPbBAbA9/F0A22UQxzHWFrGyDcLlhFh+q4e6dRdp9VAx1rnVQ8X+aq'
                    'sQVJwzfp00WEKrh4gYDEruY/5WD7tR/IzlMCKelOwegMxUTgAAWF0HIZgAAIu6G9'
                    'N9pgGAbbAfER/NHB2+Mz9VpZXqqhNE+dhEtYE5qx5cFWJoWXmgYi+j45X32LGSQe'
                    '19tdhbq/upWaf0PjrsJ0Uqgg5Xx3ejqE65V7FzADJSOQEAYDUdRIrHMfYODwBgbh'
                    '9FUUHhSb/bAACu0UlTtYAUNZUU5qhckCIVa81Z9WC6ksJgshTAXOulSLPVB+rOm6'
                    'dCRIu1Wt1PzTqlv1cdqjGkSOP7vxvFm0EOxtepDKwAsDTCCQAAq+coRXoYggkAsE'
                    'yPQo9hANgW+xHx4PJXDe0aKh/gj86NivPrHuSPQgod2kRM73eprR6ipEXC2LXarD'
                    'cRUuiyh3laPVQcL/296tLq4Wr/d6P4+vCo5E4AyEQ4AQBgtRxFxMd9bwIANtCovc'
                    'NJv9sAeuHNsLBdBvFo5ljdg/0YPsCvqqIwOr9D0KCx2kDTulNVB4pPlxBSKLvHFk'
                    'GJyUOp/r4a7qlTSKFt2KJrJYgUMYjBgxjEp+HrQ4Brc6PvDQAAcOlhCCYAQE4fhe'
                    'oJALDpDiPFvcrRFNWBpVQ8+K4s7193bpSPXa7VcN02Yymm9tZ0XsXxynusWq/k+O'
                    'VeOpwzvbfS++mwTul9dL2HlD4K1RMAro3KCQAAq+FRjJecBAByeRgpDvveBHB99B'
                    'CH7TKIwUlENFZKaKoWsJKtHoZjKdJk9YMOrRnGxyrvsWsVgqipENFirYn7mbPVw0'
                    'xFiA7VGFKkh4MYPImIJwFAVsIJAAD9exRJMAEArsm9iDiOomIRALBZDiOmqibUhQ'
                    'EaxkvbB0yfGxXnL9rqoW7dZbd6iIp77BB6mLi3LnuYp9VDxfHSsEXZPcyusZsiPY'
                    '6I/Yh4WrJ7AJZEOAEAoD97EfFJTP/gBADI7SSKqkVPe90FcD0UToDtMYhHM1UFIh'
                    'arohDDB/jT78yfPr/D2p1CCi2qKBSfLiGkUHaPLYISk4dS/X3V3VOX+6lYpzRs0S'
                    '7osBsRj2O8BZj/fwAs3Y2+NwAAsKX2ovimVzABAK7fbhThBABgcxxFijsRxQPu0p'
                    'YuKeofONeNp+LBd2WrmDZrzxxKV2M1120zNnPPTedVHK+8x6r1So5f7qXDOdPHZ/'
                    'bQZZ2ouI/m694NXyMCZKVyAgDA9duLIphwt99tAMBW+yCK0s+P+90GkJ13vsLmK9'
                    '75fhIR9VUFRtpUUqgZK20f0GbtuioKxYYXavUwWm8Qg9KxLutV3mOHdguNFSKuqd'
                    'XDTEWI+moMD6L4+vBRALB0wgkAANdrLwQTAGBVPIyIAw8uAWDtnUQUVRMutQ0pLN'
                    'LqIaI+pLAJrR6i4h4b2jNMHhq7t66tHmJ5IYWZ+yi7brHGxzGIJxHxpGRXACxAWw'
                    'cAgOuzF4IJALBK7kbEcd+bAAAWshep5v/nda0Cpsabzi8dztDqobYlQtO6y271EM'
                    'tp9TDaT+dWD2N7a30/y2n18EkUP8cBYIlUTgAAuB57kQQTFnXx3cUvpo+9+vbixs'
                    'V3F6/arnHrt2/PHHvtzdfulEwFYDucRFG292mvuwAA5nUcEbu1lQoiLt8lv1Crh6'
                    'rxqvYBLc8tG7tszzBn1YPpSgrLavVQeo/X2Oqh9f0s3urhTkR8EkUbMACWRDgBAC'
                    'C/vVAxodyreH7x4uKvI8XNsy9OzyMiLp5d/ODVtxc7EREXz1/Fq+cX42csIUTwbe'
                    '3ojZ3X4rWdosDYrR/c/jxuxIubu7duDG4PXr32xms/iBuxs/geAFghu1EEFI773Q'
                    'YAMIf9GP9/eIeAwVytHprGq9oHtNlf3YP8UUhhzuDEMls91N5jh9BDq1YPZXu4jl'
                    'YPV/PvRfF14knJDgGYg3ACAEBee7HlwYSL7y5+kU7TjfOvz15dfHPx9qtvLr4/Fj'
                    'rYiaUEDpbn1fOLy0DE2Zdn75fNee23bsZrOzfi5vdv/eLm7q0bN3Zu3L7x+o3SuQ'
                    'CshQ8j4mFEfNrvNoAs6kqqA+ttECdRBA0nLRpSWKSKQhTtAyqrKIzO77B2Y7WBpn'
                    'Xr7nfOkELlPbYISkweSvX31XBPnUIKVfcRUR5SKA59FMXPdR6X7AKAjoQTAADy2Y'
                    'ttCSYMKyCcf3V+8+Kb8zcvnp6/c/7sPNJZilix8MEyXPzmPC5+E3H6+enEvb32Wz'
                    'fj5u7N5zffufXlrfdu3RRYAFgrJxFx1PMeAID29iPFg8YqBxGtHubPtApoe37V+C'
                    'KtHqb2dnVoua0eik9bhhRWsdXD2N5a3U/XsMXV/E+iqNLxtGQHAHQgnAAAkMdebG'
                    'gwIZ2nry6+ufjm/Kuz22d/ffr+sArCylVA6EMRWjjfefnLFz8cHbv17q249YPbn9'
                    '/6we3z19567Yd15wPQqwcR8Si8Kw42Trp8ugRsmIeND+pHWlYqqG31UHeNedsgtD'
                    'h3emxprR6GYzOhjA6tGcbHals9lJ23zJBC1/tpaPVQElLYjYhPIuIwAFiIcAIAwP'
                    'LtpUiPYwOCCVdBhPMiiFBUQ3gnIt7pe2/r4uzLs6I9xF98GxERN4dhhdu/c/u1G2'
                    '/ceK/n7QEw6SSSHzoDwBo4jIgPZh7UF78ot2irh9GcOUMQle0D2uxv0VYPdesuu9'
                    'VDVNxjh9DDxL112cM8rR4qjpeELe5FUWnrpGRHALQknAAAsFx7kda3YsKr7y5+cf'
                    'Y3Z3H25dmd8y/PBBEyOP/yLM6/PHv/+V98G4Nbg7j9/u3nt3/3jS9u7t78fgzizb'
                    '73B7Dl7kXxsONxv9sAlkrhBNg8g8kHxK2rCRSTR2s0jpeGFBYMQZS2D5g+v8PanU'
                    'IKy271UDFWeY8dW0ekSPX31XBPnUIK7cIWH0XxdeLjkqsC0IJwAkBufggCm2/yG9'
                    'jHsS7BhFfx/OLZ+X87++r8rbO/Pn3//MuzCK0ZrlU6S/Hys5c7Lz97+aOIiFvv34'
                    '7Xf/f1X976/u334kbs9L0/gC11Ekr2AsAqO4wU9yKi/GF2l1YPdXPGHljPtApoe3'
                    '7VeFX7gDn2dnWoxb13aPVQfNoypND1Hq+j1cPY3krvp8M6U2GLRxFxEBFPS64IQA'
                    'PhBACA5XkUKx5MuPj6/Genn5++c/bF2TsXvznfiYjf73tPXDn7/DTOPj/90URFhb'
                    '2bP+p7XwBbRvUEAFhtDy8/q3hIH9Gy1UPFGhNjw/NrWz3UXaNFSGHprR6aKkh0CC'
                    'nMVI2YI/RQeY/XEVKoup85Wz3EIO4MYvAoIu6ny8kAtCWcAACwHI8i4kHfm5j26s'
                    'WrL05/fXoxVhlBGGENjFdUuLFzI27/zutfvfF7OzcGtwa7fe8NYEuchOoJALCKjm'
                    'L6TQEVD5M7hRQWbfUwmjNnCKKkfUD7tXO0ehgbW2qrh6i4xw6hh4l767KHeVo9VB'
                    'xPkT4YDAZHUfwsCIAOhBMAABb3MFYkmJDO01fnX5198/Kzlz86//Is0ll6r+89sZ'
                    'hXz1/Fi589f+fFz57HzXdvxc4fvPlL1RQAslM9ATaJN7bC5hjESeVYTUihtpx/iz'
                    'XKxpfe6iFm2gcsvHarkEKuVg8VY5X32LF1RIrUfF9dWz2UrVWxTkrpYQzicUR8Wn'
                    'IVACoIJwAALOYoUnzY5wYuvr341emvXr559sXZOxfPzt+JiHf63A/5nH95Fs/+r6'
                    '9/dGPnRrzx+29+8frfef2tuBE7fe8LYEOdhOoJALBKjiPFnYjoHDBYaquHsfGcrR'
                    '4WCilUBTTmDBQ0hhS6Vmaou8c+Wz1U7bl8nd1I8Sh8vQjQiXACAMD8jiLi42u/6q'
                    't4fvbV2V+d/frl3zn99elOOk8/vPY90KtXz1/Fd//hm/ee/6dv443f3/n6jTs7t4'
                    'UUAJZO9QQAWB17EWNVE5rCAxVzemn10LRGzViKVN/qoWrtNgGNOYMTV5mEqYoUHf'
                    'YyPlZ5j/OGFK631cO9KP5cnpRcFYASwgkAAPM5iGsMJoy3azj769OdiPi713VtVl'
                    'c6T/H8P3+3+/w/fxev/+7rz3f+4K3Twa3Bbt/7AtggJ+HdcLD2Rn3OgfU1GAyOI2'
                    'Lye522FRBK5rR+UN/mOm1DCou0eoioDyksu9VD3brX2eqhaR9lv69puE7XVg/RMa'
                    'RwdeyjiPgkIp6UrAzAFOEEAIDuDuIa3kWZztNXp78+vXj5ly/e066BJi8/e7nz8r'
                    'OXO2/s77zY+e/fTCopACzFvYjYD72EAaBPexFxXDm6YEihU6uHujl1rQI6nl863P'
                    'QAv2ntqoBGXUhhkVYPdedlbPVQHE7dWz2M7a3V/UweexQRB5fHAKgknAAA0M1eFI'
                    'n4LO9OLwkkQCcvPn3+xsvPXmj3ALA8J1G0cgIA+vEwpbRbWTlg5DpaPbS5TtUD7v'
                    'Hxumu0aIMwV0hhkYBGh5DCxL5aVF8oG1tGSKExfNFirVb3U8y/GwPtHQDauNH3Bg'
                    'AA1sheFBUT7ixz0XSevnr52csvfvOvv46n//LLd777D9+8d/HsfJmXYMuM2j08/c'
                    'mXO2d/ffp53/sBWHMPoqieAABcv/0o/l8cKaXmNi0prh4ud5yThv+0WqfD+MS603'
                    'Oa9lkzVvta1O2vZGzm3uddd3qtOfYyPlZ5j/PcW9c9DI+3vp8UH0VRaROAGionAC'
                    'xA30rYDmMp+YcRcXcpi76K56e/fvnli1+8+KEKCeSSzlN889Nn77/2vZvx1t9/+/'
                    'PX3n7t/b73BLCmjqOunDQAkMvJ9IHRz+NqKyks2OqhODxoVyWh7jp1rQ86nl86XN'
                    'fqYXR+h7VbtXqoW3eRVg8VY5X32LF1RG2rh4pzxq+TBq3u51EIKADUUjkBAKCdhz'
                    'F8t8bcUnx39sXpL7958iy++j/+dufbf//ND1VI4DpcPDuP3/zrp+9/9x++eR6v0o'
                    'u+9wOwho6iqKAEAFyfw6j5Pvw6KiksusbE+PS6Xc9vqDBQum7Hvc3scYGqB3NXUq'
                    'g4XnmPDZUPJg+NVVFoec703hru525o7QBQS+UEAIBmRxHx4bwnn399/svTz168d/'
                    'r56ZvpPL25vG1BNy9/9XLn9PPTePvge1/cfPfWe33vB2CN7EbE/SjeDQesG0UPYV'
                    '2dRER95YIoHlrXVlGIaK6AUDFnpopC035aViooraIwNadpjbKxFDWvRcfKBa0rSL'
                    'RcN0WarRrRsYpC7T1WnTdPhYgWa9Xcz0dRfM34ackdAGw94QQAgHoHKdLHXU9K5+'
                    'mrlz9/Hqe/Pn3n1fNXP8qxMZhHOk/x7E9/897Nd2/FW3ff/npwa7Db954A1sRJCC'
                    'cAwHU5jIh7EdEqWHDtrR7q1lm01cNozpwhiMbXYt6QQptWD3XrLrvVQ1TcY4fQw8'
                    'S9ddlDc6uHR5HisGRFgK2nrQMAQLW9iHjcevareH72xdkvn/2br+Pr//Ord178/M'
                    'U7r56/yrU3WMj5l2fxm3/1dPf8y7Mv+t4LwJq4E+GHzABwTR5O/KpNa4W4xlYPUT'
                    '7e6TpTrQ8WOb90uK7Vw+j8Dms3tkRoWneRVg9VHSu6tnqo2F/jfXVv9XAviiqcAE'
                    'xROQGgg+d/9bzvLQDXYOd3duL23u04/fr0cRRlnGtdfHvxq5efvnj37PPTnXSeVE'
                    'lgbaTzFN/86bP3br1/+7u3/v7bg7gRO33vCWDFHUfqEFwEAOZxFBF3S0faVD+IvJ'
                    'UU5mr1UDenqqpAl/OrxodtEGJQsm6HvU0eSs333qHVQ/Fpy0oKXe+x31YPDyPik4'
                    'h4WrJrgK0lnAAAUO5fDGJwt/IdF6/i+el/e/nti58/f+/V81c/vN6twXKdfX765m'
                    '9+8zTe/sPf+vLGGzfe7Xs/ACvsg4jYDz2EYb20eLc1sFJOImKxB/6jaSnVBxRGaz'
                    'VMqXpIX2yhQ0hh0VYPdddoWD9FzWsxb6uH0b0v0OphtN5g8gJzhR4q7/EaQwpjrR'
                    '52owgoHJXsFmBraesAADDr5PTp6T8qCyZcfHPx+Xd//u3zp//yy53v/vzb97RtYF'
                    'O8ev4qfvOvnr57+quX2jwA1DvqewNAe2dfn/W9BaCboyhaKbULFq1Iq4fLkv4Ltm'
                    'KobX0wPmfO9Rtfi01p9VB1jx3Wm7i3OdYanv8gtAUDmDBo/J8ywDX6B//knxefXP'
                    '7VNPYF4PhfV1PHUsmx8s8b1pv+PCJe/3sqXMOW2Y9B/PkbP3hjZ3BjGIOfrJLQ7+'
                    '7gGtz6gTYPADW+joi9vjcBtCOcAGtlL4rqRLPtFZsqG7SdEw2tHha83sS7/5ex58'
                    's371dMbHl+1VjlunOuPYiKagMd9jSzVsfzpo93fu3mua/6438WEQd9VvH5l//LP+'
                    '7v4gBTtHUAaHD2xWnfWwCu19Hrv/366eDGYOfVi1dfvPjZ87fOPj/dSefJQ1q2xt'
                    'lfn7757P/5Ot46+N4XN9648V7f+wFYMbtRvKvzUb/bANrwxixYI4M4jojd0ofJbd'
                    'smNM2JJbd6mLreUls9jI0v1Oqhanz47v7KB/hztJG4bM/QsU1E2djMPTe1j+h6j9'
                    'fX6uHu8M/2w4rdA2wV4QSABjdv+qsStsw/HAxufPPNnz7bPf/qzENZttbFs4t49m'
                    '++fu+tg7e/uPnOLf8tAEy6H8IJALBMexFxHDH2gLvMkkIKo+BSbUihZdih6iF9cW'
                    'qLkEKH8YVCCjVjKWoCGx2DBjP3Pmdw4iqTMPbnYYHQQ+U9zhtS6LKHFCdRfO34tO'
                    'QsgK3iiRtAg9PPXva9BeB6/U+nn738Yd+bgFWQzlN886fP3nvr7ttf3vrB7Xf73g'
                    '/ACvkgIvajKD0NACzuJNKwnUPdQ/iRtpUNWlRRiFhCSKFiTusH9W2u0zakMGcIIq'
                    'WaKgpzrN1YbaBp3aYqClVr1ozV3mPdPsp+X9NwnXbn7EZROeGoZDbAVhFOAAC4ch'
                    'QRd/reBKyab//sm3dv//D152/+j29pbwJw5SgiTnreAwBsgv2I+PDyV20ewk/Nq9'
                    'Sh1UNE3pBCp1YPdXOmXp91aPUQ0RBSWKTVQ915GVs9FIdTl1YPD6KonvC4ZFcAW+'
                    'NG3xsAAFghJ31vAFbV6a9e7nz3H7993vc+AFbIUd8bAIANcVJ6NMXlA950+aS3ft'
                    '5Cc+IqpNC41hxz0vCf1vtpOT6x7vR43Rp146l4LSpf94Zzq+5/3nOnx2b2Ned6lb'
                    '/fVeeVHL98/dudc1KxG4CtIZwAAFA4ClUToNbpr17uPPu/v454FUIKAMXXDYd9bw'
                    'IA1txBFO8or9b0EH583hJCCiml5pDCAtfqFFLoMF4bUmjaZ81Y7WvRMWgwc+/zrj'
                    'u91hx7uRyq+/2e597qz7kXAq7AltPWAQCgcNL3BmAdXDy7iGf/79c73/uHu8/jRm'
                    'jzAGy7o1CaF1Zbm3c4A316GBGNbRfGS+TXtnoYzW2z3gq0eigOD5r307HVw+W6c5'
                    'xfOpxqWj2Mzu+wdqtWD3XrLtLqoWKs8h6b1uvS6qGYcBJFeweAraRyAgBAxP1QNQ'
                    'FaGwUUVFAAiPsRsdfzHgBgXR1GxL2IaN12oVWlgLbrdWj1kLuSwqJrTIxPr9v1/I'
                    'Y2CHO/5vPee8uxzpUUKo5X3mO7tg2Teyk/5054gwywxYQTAAAijvveAKwbAQWAiI'
                    'jYjSKgAAB0dzJzpG21k6mH0m3mLTQnGtobjK81x5xOrR6artO21cOCIYV5z618kB'
                    '+zY/OsO3O/c4Yeals9LB5SOA4BV2BLaesAAGy7wxi9UwPo5LLFwx9q8QBstfsp0q'
                    'O+NwEAa+Yoqr4Xb9MqYXzuJrd6qFunw3jl69N0zzXjja9Fx/YKnVo91K277FYPUX'
                    'GPVa9N070Vx3ejCCiclKwAsNGEEwCmtfnGB9gcyTeCsIiLZxfx7E+/3nn7D39LQA'
                    'HYVh9E8c63p/1uAyjT6p3OwLUaPjA+aRUWKE5oPa82pLBAaGBm2jWEFCYerC+y56'
                    'nXpzSg0PL80uGUIgZzBkMWDSk0hAOWGlIou8cWQYnJQ2n8vj6KiEcR8WnJ2QAbS1'
                    'sHAGCbHYaqCbCwi2cX8c2f/kaLB2Cb3e97A8Cs06enfW8BKHcUEXfmaeHQdl5lO4'
                    'O263Vo9dAYgprzektt9TA2nrPVw9yveUWrizbXbdvqYWJvTedVHK+8x/lbPZxczs'
                    'n5AbBChBMAgG1WvFNDxRRY2MWzi/j2yTOVE4Btddz3BgBgTeylSA8vf9Xl4ekc8y'
                    'oflre9doeQQpd9dZnTKaTQYXyhkELNWO1r0TFoMHPv8647tl7VWJf1Ku+xe0jhQU'
                    'TsV1wJYCMJJwAA2+owxqsmCCnAws6/Oo/n//E71ROAbXQ3/GAZANo4jojd0ofEHa'
                    'sjtJ1XW0Uhov16TVMyVlEoDrd8UN/mOm1DCnOu3/hadFx7qtpA93UXqaJQlUOou8'
                    'cOVRlSpJMUef8BWCXCCQDAtjopPSqgAAs5/auXOy/+v+cv+t4HQA/u970BAFhxez'
                    'FWbaj0wWlfIYUlV1HIHVJYdI2y8aW3eohYvNXDPCGFlmNLafUQNffYvoqC6gnAVr'
                    'nZ9wYAAHqwH+NVE6aNAgrC5TCXl3/54o3Xdl/78tZv3363770AXKOjiHjY8x6Acb'
                    '6eh1VzHBG7028KGD3YHYwPpGj35oHRf+dNc8fmpUiT1+q6XstrppRiMGia1LxO2Z'
                    'yJ16ztnluMl/5ejMbrrlE3nobrDkrWbbt2yf033nvLsZk/D1Wv1bz3WHXe5PGHIe'
                    'gKbAnhBIAI75SGbZMqqiZME1KAuX3377599+1/9NoXr7392nt97wXgmoxaO3za7z'
                    'YAYCXtR8RHEVH58HfmwXjb4EHNmlXzKh/Cj89runaLOaMKCrUhhQWu1Smk0GF8oZ'
                    'BCzViKmsBGx6DBzL3PGZwovd8FQg+V91gfevggBnEYEY9LZgBsFG0dAIBtsx+DeN'
                    'AplCTABHP59t8+ey+dp6/73gfANbrf9wYAYEWdTPyqpoT+yrR6iGi/XtOUa2j1MN'
                    'HuYZHrtHl9crV6mGPtVq0e6tZdpNVD1Z/hrq0eirGjy/FlfwCsEOEEAGDbnFx+1j'
                    'WgIKQAnaTzFN/+22e7keK7vvcCcE2O+t4AAKyg/Yh4UDrS5mF7w9y2a9bNqw0pLB'
                    'AamJl2DSGFRdcoG+/8oL1pPDWEFOYIGrQKKbQc6xxSqDjeMaTwIIr/VgA2mrYOAM'
                    'A22Y/pH4h0bd2g1QN0cvHNRTz/T98Ndv6HN/veCsB1uBsRexHxtN9tABHha3ZYFY'
                    'N41Dhn9N9rXduC8bnLbvUwvHaKlL3VQ0Tx0Lq21cNorab9l8zp1OqhzXWG4wu1eq'
                    'gaT8N1BxUtNhrOLRu7/D2c49zpsZk/D1WvVYt7rGz1MHneSQi7AhtO5QQAYJucVI'
                    '50rYygkgK0dvpXL3dO/+rlF33vA+Ca3O97A0DE6VenfW8BKBxGinutZ1e+kb7DO9'
                    'mn12sbVGpTRaFmj12ve+2tHuatcjA1Plerh6bxYZWBufZXMta6zUWLighLbfVQdY'
                    '9Xh1VPADaeygkAwLbYj6oykuPmqaTgHVnQ6PlffPfezXdufXnjjRvv9r0XgMzuR7'
                    'R4hygAbIeTiGhdUaBpbuk72dusO8e8ykoBXddrUUUhIuorKSxQtWGmksIilR+aXp'
                    '9FqijE8LWoqqIwOr/D2pd7TIPmfbWoolB8Oqi8Xt1eLoeq7vHqnJNIqicAm0s4Ad'
                    'he3vEM2+YkIvKEDrR6gFa+/emzd7/3j3efx43Y6XsvABl9EFo7AEBEEdibrJrQtt'
                    'XCaG7Mzl+41UPJmnXzFg4pdGj1EJE3pNCp1UPdnLHXu7QVRl+tHqb2dnVoua0eik'
                    '9bhhS63mOKB1H8DOvTkjMB1p5wAgCwDfZiVGI5Z+hASAFqvXrxKr7782/Tm3/vrb'
                    '63ApDbYUR80vMeYKs1lkoHsho+YH9YOtilikLN/E4PicvW7BhmKH0I37DHznOi+P'
                    'urNqAwWmuOqg0zVRSa9tOyUkFlgGMJIYXK16Jj0KB1BYkOIYVWAZn57vEo6lqTAq'
                    'yxG31vAADgGhxHxO7lrwbRrXpK7vmwRc7+5vTNs785/bLvfQBkdr/vDQBAz44i4k'
                    '7tjBTdwv0Vc9P0QNt1u1w/XV1r5nol89qsVTslpeaQVZv9V8yZuI+mdTqMV74+bf'
                    'ZZNdT0WnTc++Ue29xXw9jM/datWTNWco/HUbzRBmDjCCcAAJtuL4pv6mZdR0gBmP'
                    'H8L757N52nr/veB0BG9/veAAD0aC9Sh3d9dw0JND1s77ruHPNqQwoLhAZmpl1DSG'
                    'FiziLXmXp9Fjm/dDgt8JrPG1JoObbUkEIxuBtFwAdg42jrAGwfDwthu6Spqgllur'
                    'R66DpfqweYkc5TfPfvvtl96x98r++tAOSyGxEHEfGk320AQC+OU6Q7kYYl9Lu0b1'
                    'h2q4cu67ZsuzA+r7KdQdv1Wl6zdauHOa631FYPY+M5Wz0Uf6zmeM1L9n7ZnqFlO4'
                    'e6sdJWIx32Mjo+vMfjSBWtUQDWmHACALDJ9obfzDXrGiLIPR823PnT8zj9q5df3P'
                    'qd2+/1vReATI6iqnoTkNXp09O+twDbbC/G/v83emd644P1qxMKCwYaSh8St123S5'
                    'jhcvlU/rC87bVbzBlVUGgVUmgTsKgLdiwSIJgaXyikUDOWoiaw0TFoMHPvcwYnSv'
                    '88zB96uBPF15OPKnYDsJaEE4Ato2wCbJd0HBG7nYIBQgpwbV781+fv3fztW18Pbg'
                    '7qq5sArKfDvjcAAD04jpLqhSml7lUUIhaueDATGpijOkLbebVVFEZz5wgNzExpE1'
                    'JYIBDR+kF9m+u0DSnMGYJofC06rn25xzSovW5d1YPReZ0CMtVjRyGcAGyYG31vAA'
                    'Agk72IwfHEkUG0/0FIl7mj+V3ISkGk8xTP//23ggnAprobEft9bwIArtF+1FQNSp'
                    'GKh8ldwvop2s+vmJuG/8y17hzzSq/XZb2W10wpXT6cX2itmtdt0TXKxktfmw7nlw'
                    '6nBV7zuj8zdee2HJv589B03qR7UbQKA9gYwgkAwKa6HxG7pSmAXKGDeQINQgpsuf'
                    'On53H+xdnnfe8DIJPDvjcAWyn58OGjp4+TKKmaMG3ukEKXuSXzK0MKC6xZN6/yYX'
                    'nb9VpeszGgMFprjjkTr1nbPbcYrwxwNF2jbjzF/CGFmj8z8547Pdb6z97sescVMw'
                    'HWkrYOwPbwABC2S/FDkaGSXgpaPcDKeP4X373/vf9590XciDf63gvAkt0PpXgB2A'
                    '77EfEgUrT+Gdzonem17QkmTyh0aQ1R0eqhWKZFuf2Wa1bNa9XqoenaLeZce6uHun'
                    'U6jM/V6qFpPBXr1rZ6qNpfyVjrNhdN687f6uF+ROxFxNOKKwOsFeEEAGATHUXEnd'
                    'nDaxBSEFBgC6XzFC9+/jze+Ls7fW8FYNkO/b8dgC3x8PKzjiGClFLxsLZL6KDt+j'
                    'VzU6TJh+Jt151jXquQQpv1GuZce0hhkVBF0+uzYAgipRTFH6s5XvO6kEIaNO+rIf'
                    'jQMaSwG8XPuR5WXBFgrQgnAACb6KQ+GNBDSEEVBah1+suXb9x+//bnN9567f2+9w'
                    'KwRLtRtHZ43O82ACCrw4j4YOZohxDBZRWFaw4pzPVQfIF5tSGFJVVRiLiekEKrKg'
                    'ptrjP2MH8mMNL2/KrxYRWFypBCh71dHWpx7y3HOoQUjkM4AdgQN/reAADAkh3FeN'
                    'WEQdR8k1wy0KUFTNe5OefDBnjxX54LJgCb6LDvDQBAZie1oylaB/BTpMsH6611mV'
                    '6xlzT8Z651u8xLV9drM2+hORHtXss2+296zdruuW5s7LUpfX2arlE3nhpei4ZzZ/'
                    '9oTN37guu2+LN3J3xNCWwI4QQAYNOclB6tDSgMGg9Vyh06EFJgi5w/PY/zL84+73'
                    'sfAEt2v+8NAEBGhxFxr9XMDiGClDqGFDoEIOr2UvqQuO3D+45hhsqH8FPz2qxVO6'
                    'XNa7lAIKJTSKHDeG1IoWmfVUNNr8W8IYUFgxMTa1Wfc1RzBYC1oa0DALBJjmK8as'
                    'K0VWv10HW+Vg9sgRf/9fn7b3//1ncxiDf73gvAktyNiL2IeNrvNmCL+LoZrtOjiM'
                    'jTiiGKh8laPTSst0KtHorDg9J2CJ2u0/T6LNLqIYavRVWrh9H5Hda+3GMaNO9r/l'
                    'YPD6Jo7/C0YnWAtSCcAGw27zaG7ZIaSkmONIYU0uyhyvld1m53uaWtDWvo1YtX8f'
                    'Kzl2ev/+j1vrcCsEyHEfFJz3uArXD61WnfW4BtchSjNwg0PYye1iFEMHpneueQwo'
                    'KBhsqH4gsEH+rmbVJI4TKgMOcaE+OXz+jT7GuzSEghDV/zqpBCh71dHWpx7y3HKk'
                    'IK92MUCAJYU8IJAMCmOIzB2A9F2qgMBlSkALoGCXJWUegyH9bM6V++2H39h6+/iB'
                    'vxRt97AViS+yGcANeitkQ6sDTDB6YnEwc7VkXoes5lSKHuofoi+6kIHtS8k33uNU'
                    'vnDdcsfQhfMq/NWrWXTKn5tWyz/4qH9MUWOoQU5q2iMDWnaY2ysRQ1r0XHoEHrCh'
                    'IdQgpj93scwgnAmhNOAAA2xcnlZ0sLBqxBq4cu82FNpPMUz//Ld2nnD3R2ADbGof'
                    '9fA7BhTqKqreK8IYUOrR4iMoUUaubOhAaW3ephNLepisLYvDZr1U657lYPdess2u'
                    'phNGfOEETja3HdrR7Gxsbu925E7EfEpxVnAKw84QQAYBMcRsS9iSNLfdC/BiEFDz'
                    'zYMGf/7XTnjd/b+Xpwc7Db914AluBO+EEyAJtjL0U6rnxwPjJP5YIO81MahgVyrN'
                    '+11UObdbV6uJqzaKuH4fjSWz3E8LVYpNXD1HirkEK3Vg/Hww+AtXSj7w0AACzBSe'
                    'XIILq9W6N2fslA17W7WNq+YT29+Nnz233vAWCJDvveAGyF5MOHj+wfxYPR3RTFP4'
                    '1aTJmZ3/KcFKl4mNzlGl3nlswvvfe267a9v7F5ta91m/VaXnMUUlh4rZI5E/fQdo'
                    '0W45WvTdM16sZT8VrM/ZpX/Jlpc90WY/drrgyw8oQTAIB1dxjTVRPKzBNSaLtQl7'
                    'WXGpZYwnxYYWe/Pt1J5+nrvvcBsCSHfW8ANt3Lr172vQXYBvuR4nj8AWrrgMI8IY'
                    'XWU1O7B+vz7qfyGfXUA+wu684xr/a1XlJIIaWWr2XbgMXMoQ4hhQ7jC4UUasZqX4'
                    'uOQYOZe59v3Tvh60pgjWnrAGweD+Vg25x0+oFClxYI697qoct8WFEvfvb89s4fvN'
                    'n3NgCW4bDVwxsAWG0nEbEbEVffbza1Hxg3dk4rHef30eqhGJpqL9B23TnmNb7Wqe'
                    'V6K9DqoTg8aN5P03XavD5112hYv/G16Lh2q1YPdeumOIqIxxVnAaw04QQAYJ0dRs'
                    'S9fh/09xBSyBXGgBV09uvTndd//42vBzcHu33vBWBBdyJiPyI+7XcbADC3/Yh4MH'
                    'N03pBClzcYdQgRpEgRKa49pFB6732FFBYIDcxMu4aQwmVAYc41ysZnAiMdzy8dTi'
                    'mKP1ZzvOYlf+ZbhRTK171fcRWAlaetAwCwzo4nftVry4SSgaW0kei6jyXMhxXz8m'
                    'cvbve9B4AlOex7AwCwgJPa0an2A40Vg+Zt9dDynM6tHkbrL7iX0nvP0ephrJ1Bm3'
                    'kLzYmG9gbja80xp1OrhzbXWUarh5p2DSnV/Pnu2OphtM+O5+6GgAKwplROAADW1X'
                    '5EfFA60ls1Aq0eIIezX5/uvP57qicAG+EwIh71vAcAmMdhlFVNmDb1Lu/Sd683nN'
                    'NKh8oLrd75v8h+KvYyU9lg2VUUxq7dqtVD05ot5lx7q4e6dXK3emgaT8M/33WtHq'
                    'r2V9fqoanNxdW59yPik4pZACtLOAHYHN4VDNslNbxjI6Jb6GDdWz10nS+gwJo5+/'
                    'Vp3P7d1/veBsCiDvveAGw0X+NCPoMW34OPm7fVw/CcrtdoNT2la2/1UAxNBTT6av'
                    'UwmttmvRVo9VAcbnhQ3+Y6Ta9PzlYPo/M7rN2q1UMx8X7FCMBK09YBAFhH+zFo8Y'
                    '6NiBVo9TBoPLTUvXSZK9TFGjn95cvdSPG8730ALOhOFNWfAGCdHEaKe3MFgLq2ep'
                    'g6p/U1urZ6WEL7hi5zK1s9tG2D0HFe7Wu95FYPje0eFrhe51YPTa0aptften5Ny4'
                    'W5Wz1E+ViLe9faAVhLKicAG8HzNdg6JylijaoRlAx2reqg1QNbLp2nOPv16fmt37'
                    'nd91YAFnUYWjsAsF4eXn42bwuGsXNaVVJYwnXqpxYBhdatHkbrL1h1ofKd+x1aOH'
                    'S5dm1bjSW1eogYVqVoei3nrNrQqdVD03Xatnqou0ZDu4ZrbvVwGFo7AGtG5QQAYN'
                    '3sR8SDie/H1qIaQQ9VFFRSYMOcfvbye33vAWAJDvveAGyi069O+94CbKqjiLg7c3'
                    'TeKgpN715vOKf1ddpObfPO/0X2U/lG+sxVFMau3Vixou11m6ZcQxWF1pUUOoxXvj'
                    '5t9lk11PRaNFRhmP3jkS4DNVNj9xt2CbByhBMAgHVzMvpk5nn6qrRAWPeQAqyoVy'
                    '9exfmX57/sex8ACzrsewMA0MFJ5cg8wYGp8zq1eugaCugYUsi2fpuH7V3XnWPexr'
                    'V6iPLxTteZen0WOb90uK7Vw+j8DmuXhBTuRMRBzSoAK0c4AQBYJ/sR8WD64MTz91'
                    'V70F8bUlhg/a4hAlUU2BCnn738Ud97AFjQnSi+pgGAVXccxf+36i0SUrj8tENIoe'
                    's1Wp6TIs0XUlhwL5UhhQXWrJu3CSGFTlUU2sxpU0Vh3pBCaggptNzb5KGJe79/uU'
                    'bVB8AKudn3BgAW4uEZbJvjum+qBjH2Pdfo74c234R1mTvv/NK5FQtVzl/CPnLOh2'
                    'tw8fV5pBevvhi8fuO9vvcCsICDiPi05z0AQJ29qKuaUGb0vWOXn9dNnZMixaBpgX'
                    'mv03L+6J3pg0HrE7rtp2IvowfOg6sXo/26be9vbF7ta93m2i33l1Jqfi3b7L9kzs'
                    'Rr1nbPVeNj58/8XpTMmWf9FDWvRd3aJWNje7yfIp1UXBVg5QgnAADrYi8ijpoemM'
                    '8M5w4pLOVBf8ngqoUrusyHzF7+8uVbb/x3O31vA2ARhxHxSc97gM3ia1VYtuOI2J'
                    '3rjUEdggAT50TUPxiuOafrNVpNH77rP0tIoWbuTGig7bpzzGt8recMDcxMafNaLh'
                    'CI6BRS6DBeG1KYc/3G16Lj2inS3Siqcn1acRbAStHWAQBYF8cRsXv5q4ZvfGc6E3'
                    'Rta9Bl7lJbPQwaDy11L12oVsOKOP/ibCdSPO97HwALOOx7AwBQYy+K78HnD/7MW0'
                    '6+bfuBRa7Vcf5crR7azq+YW9nqoc26c8zbhFYPxeE0OWeR60y9PoucXzq8aKuHyf'
                    'HDmtkAK0XlBABgHezF6Acj41q8o39iytpUIygpydC1SoMqCmywdJ7i/Muz39z8/i'
                    '3lE4B1dTeKr2+e9rsN2BytHmACrQxi8DDG3xzQtULBuHnPnWo/MNxX63OWvbfLVg'
                    '8xWLh9Q5e9lN5723WXXUlhgcoGM9OW2eph6npLbfUwNr5Qq4eq8TRcdzDna36198'
                    'OIeFQxC2ClCCcA68m7d2G7pKmqCdNahhTS+C8a5ndZe+H5lQGFqYVWbd9d5sOSvf'
                    'zLl+/f/P6tvrcBsIiDiHjc8x5gI7z86mXfW4BNsp8iPYiY4yFsnXnOnTpnpt3BMq'
                    '/TunPDMKSQo9VDzV5mHox3WbdLmKHNa72kkMLSWj2M5q1Cq4emNWrGUtQENhoCDh'
                    'Fxv2JlgJWjrQMAsOr2oqxqQpmGtgbX1uphnrVXqdVDzvmwJK++vYh0np71vQ+ABR'
                    'z2vQEAKHEy+mShMv9V5jmvbfuBinO6XqPV9B5aPRRDafpAu3XnmNf4Wrddr2nKNb'
                    'R6SFc3tdh12rw+3doxTA7XtXqoX3s3iuArwMoTTgAAVt1xDGJ3mUGCiefpa/Ogv4'
                    'eQQhcCCvTg9LOX533vAWABh31vAACmHETEg/EDtQ+oFwkoXGdIYc5rNE9NvYQUSu'
                    '+9r5DCAqGBmWnXEFJYdI2y8cqAwrwhhdQQUqg+97DmigArQ1sHAGDVHV9+VtkCoU'
                    'TLVg+XU9amZULJi9D1dell37B8539z9s7rd97oexsA8zroewOwMXz9CcsxiIdVQ3'
                    'OXsq8z77lT7QdK97XodTqc07nVw2j9Lq0eSvZSeu9t1+0yb3jt62j1EFE8mG98Ld'
                    'vsv2ROp1YPba4zHF+o1UPVeBquO6j48z177v2I6v+GAVaFygkAwCo7iqI03ZUM1Q'
                    'tmWj2sfDUCrR4gIuLVy1dx8ezil33vA2BOyu8CsEoOI8W9prBPbSn7RSopzHNOGv'
                    '9lyyoK81RSaDu1zTv/F9lP5Rvpp35Pll1FYezarVo9LKGSwrW3epi3ysHU+FytHp'
                    'rGh5UUWlz/XsNVAFaCygkAwCo7qRxZ8rv6Z4bXohpByeCqVYDwLjYyO/v85Xs3vr'
                    'fT9zYA5nUQEU963gMARIx//93iXemV76LvUhFg+ryY49ypd/YXn7Z4132Xa3Wcn9'
                    'Lwtcmxfs3cmd+TtuvOMa/xtZ6zssHMlOFD+dpKCgtUbZippLBI5Yem12eRKgoxfC'
                    '2qqiiMzh/EYUQ8rrgCwEpQOQEAWFVHEXGncdaSqxdMLLc21Qh6qKTQZa4qCmR0/r'
                    'fnkgnAOjvsewOw7k6/Ou17C7AJjmL6Xddt3t2eq4rCvJUUmvZVc07ra7Q8J8Xwnf'
                    '9dKyN0qWTQVBGg67pzzKt9rZdURSHieiopLLrGxPj0ul3PrxofVlGoec0PL88f/w'
                    'BYISonAOvDwy3YNiedvoFacvWCieXWphpByeBaVICA+aXzFBdfnf/ytXdu/qjvvQ'
                    'DM4aDvDQBA1FUtbPGu9Mp30c9bDWHec6fOaVVJYQnXqZ9aBBRq3/lftv6CVRcq37'
                    'nftjpDxyoOlZU0avbYeU4Mq1I0vZZzVm2YqaLQtJ+667SpMrFIJYU0fM1nX4uDyv'
                    '0CrAiVEwCAVXQUEXf6rUZQMrwW1Qh6qKKgkgI9O/v8VDABWFd3I2Kv700AsNWOok'
                    '3VwlaFCBZ4B/0C1226XusqCvNUUmg7tc07/xfZT+VLn7mKwti1GytWtL1u05RrqK'
                    'LQupJCh/HaSiNN+6wamn0tDhtWA+idcAIAsIpOJn61iiGFLmsvaR/d5q9BSAGW5P'
                    'xvzyNSPO97HwBzOuh7AwBsrb2IeNh6dosHvo1l/ucxb7ihbfuBRa7Vcb5WDy3Wa3'
                    'nNa2v1EOXjna4z9foscn7p8FWrh93wtSWw4rR1AABWzVFUvWtjqS0Qus+fuPyqtX'
                    'qonH+NrR7mWTs6rg8VLr46/0JrB2BNHUbE4573AOvL15Iwv0EcR/Ews5sWJe9Xpt'
                    'XD6LwurR6mzln23i5bPcSgW/uGvls9lKxZN6/2tW6zXstrjgIKte0e5rzeUls9jI'
                    '3nbPUQgziIiCc1uwDolXACsPq8uxa2S4rjxjk5H4C3mD9x+VULKVQGFKYWWrV9d5'
                    'kPJc7/9uxHr73j2xtgLR30vQFYV6dfnfa9BVhne5fff8/7s7d1CilMnZMitQsozH'
                    'OdlvMvQwp1D9UX2U/FXmZ+T7qs2yXM0Oa1XnJIofG1bLP/kjmdQgodxhcKKVSPHU'
                    'bEo4pRgN5p6wAArJLDGMTd/5+9v1mSI0kSfT/1bvSc7pk5griHhx9CComgkMIrFF'
                    'JYeXl5uUWuuO16A+SSu443aB8+QcwbAG9Q/QYJru8i6w0yhSuSl2cyp3s+ugqAcx'
                    'HpWRGRHu72rWrm/99IyRSQ5mbqFoFqRJi6qtNIi60ecrZM8Blbc6sHEtIQ6Mt/+a'
                    'IdAgCEutYOAACwSr2MVRN8WxmccynBf2lQzNoh17m2H7hwje8aTsMVWj0cfjSc/4'
                    'bbvAHjFvfadb6lIQVaPQy/3FTcOi7743j9mauFyABAFY8WATCOUypgZXoREekcP+'
                    'iJKFYjuDBdrpYJyVs9nP0wdyUFny9afMcDIjJ8GeTrn7/+v379H39NawcAtXkrIl'
                    'sRudcNAwCwIlsR+cOr3/VtZXB+rcxfv1jmv3Srh+frvFo9+KzlMT641YNrPBfGXm'
                    'z14DJvwLgWWj0cfnvwa/UwN+ZsfxK0enB76AcAlFA5AQAAWHEtIu8P//r8CH0V1Q'
                    'gmhlRTjWDiB4p7GDUeEJEv/5+f/rN2DAAQ6Eo7AADAqvQXf5KiisLig+szT4nHVF'
                    'EIraSwFNfMNc5rOF4zyBBWSSEylsl7T1Cd4dK4xSoKsVUJxmFLVRTGuQLGvKqi4B'
                    'Kzw8+D/3yc/vx6YTUAUENyAgAAsKJ//VtHSQqulA/Mi7Z6SLIvtHpAO74+fv2ddg'
                    'wAEOhaOwAAwGpciciHxVE1JymEXHOWpOB7jfM6zkMd2hPExHNh7KvXxGdez3FOrR'
                    '4SJCkUb/XgnkAw+/OoJAUSXwEYRnICAACw4FpeqiZMKVBFIeH4Vz/OlVwRMnfNSQ'
                    'rAgm9//SbDT8P/WzsOAAhwpR0AAGA19l6jUyQpLA65eFKeJNkg5DqvKgoJKhdcHB'
                    '5SRSFBxYPJKgqe1RFcxzklKbjMtzSkdJJCzDquSQqXr796mSPmzy8AZPBGOwAAmM'
                    'QhFLA2/fKHpef/MHSOH/SOLnH+IBYyfmbsyXQ+c5eI++L4iR/mjj3XfWKVvvzTl1'
                    '//5n/yG+0wAMDXTJImAADJXEvo/+YMEv593fgZbub68fC1mxoUurbDuhev6xziun'
                    'BN6tgGOSQodD6VJX3u/cLYyXt3nTdg3OJ7YGk+xzXHBIWum31DBq83yHC4hxQxn+'
                    '3Pq725fP12ZlUAUEVyAgAA0HYtIu/dD54DkxR8DrQTH5jXm6QwLP7W7NwqcWPtvv'
                    'x/f/7PJCcAqNSViNwpxwBUxavkOQDppOujHggKPez3uP7iAXXM2iHXnl3jlKSQYJ'
                    '35oc9JCnOH6lPzRyY0XExScE188EyQmDyEX4jRe4wc/jdkcS9d4p8Yc7JnrjE7/N'
                    'zjzweJrwDMoq0DAADQdnPyK+fP2M99ASy1HVgY/6rVQ87YfdTc6oFKOzjz9Z+/iA'
                    'zyb9pxAECAK+0AgJr89Z/+qh0CUJvvBxneJynzHjuHw/WzpexD1w657my9LK0exm'
                    'tch7q0J4iJ58LYV6+J67w+6y+1MliI0Xfd4q0e5ubx+Lljq4ermdkAQA3JCQAAQN'
                    'NWRD68+l2vQ+euqgPzVz/OlXSQNO4KkhSAI1//8vV/0I4BAAJcaQcAAGjaXkTcD0'
                    'pdFLj+4gF1TIJCZJLC4sF56Fqe44dhyDf/zNhX9546ScF1r33mWxpSOkkhZp2l/f'
                    'nl59uFlQBABW0dANjCAROwLoP0sz/P3erBdew43udD/8L4plo9uM6fc89p9YAjX/'
                    '/py9//+j/+WjsMAPB1pR0AAKBZNyLybvzFq5LztHrwu86n1cPZNalje2n14FNZ0i'
                    'eeC7FEt3qYmHNu3Oxeu8znuOaYoDDb7iFivZeWFSliPnsvTvz5uBKRH2ZWAAAVVE'
                    '4AAABatjJVNWGK85P0nq0exkt8xtbc6iHJvlyYqKI9R/u+PH75r7RjAIAA77UDAA'
                    'A0aSMy/WDAy1PXqaooxMzhUoL/0lP0MWuHXHt2jVMlhQTrzA8t0OphqSKA77wBVR'
                    'wWWz3EViUYh7nsZWDVBq9WD0vrzFdR2DpECADFkZwAAAC09PnK9zfQ6iFn7D5ja2'
                    '71QJLCan37l68yfB3+STsOAAhwpR0AAKA5OzmqmjAleauH2CSFxSGRZf4D111aL0'
                    'urh/Ea16Eu7Qli4rm49RdbC6Rbf66VwcQ4l7lmh5Ru9eCYhLD086N5twuRAYAK2j'
                    'oAAAANWzmumpClfH+hVg8Jx7/6se++qMQ98UNrbSpiv1xDlb7+85e//HrzhgoKAG'
                    'pzJSJ3yjEA5v30+JN2CEAtNnJITliUtNXDYUKdVg8xa7u2G5i5zqvVg89anuOHYf'
                    'Bv9eA6/0zLgsNvd4tjg9d33WuX+RzXLNbqYRwT2+rh+eeDDO9nZgIANSQnAAAADf'
                    '2r38l2SF0oScHnAHxh/Mny1g76L46fuKlcyRUhc4vn/Kjel//y5T//esPHHQDVud'
                    'IOAKgCf68D3HSyE5G3Ppe8HPgO42fpiPVDD/s9rr94QB2zdkySwssZs0eSgs86Hr'
                    'GNLTu8kxQiExouJilEJD7MjSuZpDCboBCx3qvkIJc53H6+EZHHmZEAUBxtHQAAQG'
                    'kbOa6acC5b+f7ngSotEMLGF231kGRfaPUAO779y9ffaccAAAGutAMAADRjKyJ/DL'
                    '34pTR8SBuC15PFzeFw/cVS/zFrh1x7do2JVg+i1+phON0M93kDxi22elia0+V95t'
                    'o2wyX+ybdr8lYPVyT0AbCGR4kA2MKhEdC+wa2kZL4n6bv6Wz24zq9WjaCCVg8+41'
                    'Glb//yTWSQf5NOSFIAUBPK7wIAUumjKxfIUcn5BHMlqaSw+OD6UYn8VGv7Vjc4W2'
                    '/NrR4OPzp7TQKqI7iOW9xrl9fS5X1WoNXD4bc7tyoJl9fZzFwJACqonAAAAEraPJ'
                    'eVdFOiioKlp/p9prMUt6VKCj5IiGvet3/5+j9oxwAAAa60AwAAVG8rxxULIysXvH'
                    'qaO5ZWFYWYtUP38Oi62bhi1vIY/1JFIdP8l8ZO3rvrvAHjFt8DCaooiDhWUohYz7'
                    'mKwuUxVwtXAUBxJCcAAICSdiLy1k75/kJJCj5jfZIUrCVXzCYpLP/W7NxJ4kgwHl'
                    'X58l++/L12DAAQ4Eo7AABA9T5O/m6qJIXIeVLEEpWkELN2TJLCUlwz1zivkTtJIT'
                    'KWi0kKEXPOjSvR6kFE7LR6eD3HxmFVACiK5AQAAFDKRuSsaoJyNYJXE1d0YP6qio'
                    'KlJAXXiazFTZJCc7795et/pR0DAAS40g4AsOynf/pJOwTAumtZahMUmVhAkkLgdW'
                    'frZamiMF7jPNThyf+YeC4WLzh7TXyrM3iMW0wGSZSkUKKKgnOSwi8/v1pYDQCKe6'
                    'MdAAAAWI2diLyd/Ml4KOz6AbPzHOs8dyfSHX3QSzp3+vGvfuy7Lz5fKCTb84kf+u'
                    'xLiT2P/XINZnz956+8ngBqdKUdAACgar3TqPHvyRFJ2oMM0kmXZK7oOYbla1/iTb'
                    'V2guvGw+bJuGLW8hw/DM97k2P+mbGvXhPXeQPGLe61w3vI6X32nKDQdTMDXeK/MO'
                    'bkPpbi4fMwAIOonAAAAErYyHnVhCkmnowv1OohYZWGels9FK6k4DOWKgrN+Pbv3x'
                    '60YwAAT/NPuwIAcNn34vu/I5GVC149zR1Lq4pCzNprb/UQ2ZbhYqsHzxYOruMW3w'
                    'MJqiiIlKmk4DAHf68EYA6VEwDYwmEQ0KqdDBeqJpxTrkbwamDn8cFcrRrBxBBr1Q'
                    'gujp/YhFwVIHLfJ0z69pevb371W3KyAVRnKyL3yjEAAOqzD77S5anx2cufn+Yexs'
                    '/S4XMlqaKwcP3Fp+hj1g659uwap0oKCdaZH3r4HmT2yf+p+SOrLkzeu+u8PuOe17'
                    '5YSWMmRu8x8lyVYmkvA6s2vKqi4BAPAGjjWzoAAFDCje5T+hfGuw7sPEobGrjP7v'
                    'wXFqoRzI5XqKJAJYXV+Prnr/9JOwYACHClHQAAoDo3IvIuaobIKgqHKYaXw+3oRO'
                    '/YOZwKEVx4ij5m7dAqCmeVFHyvcV7HdajLk/8x8VwsXpC5isLR2osVK1zXXRpSoI'
                    'rCTCWF7XKEAFAOlRMAAEBuN3L8BUmJp/SzzN0dqii4jleuAPHqx1VUI5j4obUKEF'
                    'RRqM63v3z9nXYMABDgSkR+UI4BsIm/jwGX9MmSqhM8gf3yVHqKp7ljqjq4Pt1+6S'
                    'n60LVD7/vsyf7Dvzo8de+zluf4YXjemxzz+1ZRcJk3YNzsXieuoiCyUJUiYr1XlR'
                    'QOP98KFbkAGELlBAAAkFs/+bvJnrq/MDbL+OeBVVQjmFi+mmoEEz/wjd0HVRSa9u'
                    '1fv2mHAAAhrrQDACz66Z9+0g4BsKoXkXdJqhUci5zv1dPcirG4XJ+tikJoJYWluG'
                    'aucV7D8ZpBnp/8T1AZwSeWyXv3qY7gWXFhdq8jKhu8GlagkoJPPABQEskJAAAgpx'
                    'uZKytprRx/SJKCz9zJ43AfX7TVQ5J9uTCRpbhJUqjGt3//9qAdAwB42mgHAACoxk'
                    'ZEdie/kyNJIepyY60eaklSOLvGKUkhwTrzQ/VaPQynm+GXpOA67ihJwWVc1BgRt7'
                    '10TbB49Vsve7Z1mAEAiqGtAwBbOOgBWtM7fYhSboEwOd5pbAOtHlznV2uvUUGrB5'
                    '/xUPHtz1/f/Oo/kJcNoCrvtQMAAFRjJyJvJ38S2pLg0lwSN1/yVg8xczjszWyrh9'
                    'C1Q16Ts/UuxjVzjfM6Hq0eRBbaE4TGMzP21b27zuu7vktbDZf9cnmf5W/1sJ2PAA'
                    'DK4hs6AACQy42IvKupBUJYLIVaPSTcl1fTVVEBYuKHFe05dH3989f/pB0DAATYag'
                    'cAADBvK+dVE87lqKIQMV/SVg+xc8RUUYhZO6bVg0v7gZi1PMcHtXqIbMtwsdWDa4'
                    'UBz3GttHoAACtITgAAALn0J7+q4gA8ZnyhJAWfsT5JCtYO+meTFJZ/a3ZuH7R6aM'
                    'M3+X9qhwAAAbbaAQAAzOvlUtWEc1aTFFLEFTtHTJJCzNoxSQpLcc1c47yGb6uHBO'
                    '0bfGK5mKQQMefcuJJJCj5xxa4HAKWRnAAAAHK4EZF3r363mgPwmPFHSQo+cyePw3'
                    '38qyoKll4j14msxU2Sgilf/n8//9+1YwCAAFfaAQCW/PT4k3YIgDVbEfngfVWOJI'
                    'Woy0lSCLr27JosVRTGa5yHOjz5HxPPxbyAs9fEtzqD57jZvU6UNOBUReEsrpkxVw'
                    '6jAKCYN9oBAMAJDnOANgxyM/vz8c+6y4con7Gh430+DDuP70Q6j1KVJe5zZvyrH/'
                    'vsS7Y9lIW4J35o7b3lMx65fBKRexH5UUS+0w0FALxstAMALHE6eANWpJNuHzXBIO'
                    'm+hxv/eEbMN8ggnXRJ5oqew2FvXuJNuXbIa3K03vjfycm4Llzju4bT8OF5b3LMPz'
                    'P21WviOm/AuMW9dnktXd5nzwkKXTczcDn+zUIkAFAUlRMAAEBq1yLy3mlkRS0Qws'
                    'YXavWQcF/qbfVQuJKCDxLvtPV/93/9jyKHBAUAqMm1dgAAALOuBxl+H520Y7XVwz'
                    'hXinhirg2tohCzdkyrB5f2A+fXBK6xPDSw1UNkW4aLrR48Wzi4jivZ6mGxkgJtHA'
                    'BUgsoJAAAgtT77k/RWnnR3Hv88MHclhYRxnwypphrBxCbU+t5CKp9E5P75y6I7Ef'
                    'm9ajQAACAcf48CftFJP/6r89Pyc1JUKzifL7KKgohIN4yfpSNjiZnD4fqLr0FsFY'
                    'WQa4/23um9EbKOxzVjy47ZJ/+n5o+sujB5767z+ox7XvtiJY2ZGL3HyHNViqW9TF'
                    'kVBQAyoHICAABI6VrGqgk5n6RXfUr/wnifiSuqANGd/8J8NQKFKgo5xyNWf/Tvd0'
                    'oxAEAot0pUwAr89E8/aYcAWHItg7x//XC449PycwxVUThMMbwcbkfHFjtHTCWFmL'
                    'UjqyiMcfle47yO61CXJ/9j4rlYvODsNUldReFo7cU/g4kqKVBFAUDtqJwAAABS6l'
                    '/9Ts4nzEs8pZ9l7i5/FYWE41/9uIpqBBM/rPW9hVCfZGzlcNjrR7VIAAAAgHQ+vv'
                    'zbxNPWs09wu8hRRSFyvpd7ShFb7FPlDtdffA1iqiFEXudcYcN3Lc/xw/C8Nznmnx'
                    'n76jVxnTdg3OJeu7wHXd5nzwkKs5UU+N4BgEFUTgAAAKlcy9wTfjmfpE/21P2FsV'
                    'nGH1VRsPRUv+t01uK2VEnBZyxVFHLqz359qxADAMS61g4AAGDKjYi8e/W7E0/KJ6'
                    'miYKiSwsk91VxFYbw+07pL6zm/N0KqKDheM8jzk/++lRF8KhlMFrCYuPfUlRSOxi'
                    '2+BxJUURBxqqSwXZ4FAMqhcgIAWzikAeo1TFRNmJLrSXrl6gLh458Hdh4fzH2fuk'
                    '+85ydDrL1GF8dO/LCKChAI9EvVhFMPMvVlLgAAAFCHfvanZ09bOz8tvzSnSLrv7C'
                    'IrF7zc0zB+lo6MJWYOh+svvgYxa4dce3aN03sjwTrzQw/fg8w++T81f2TVhcl7d5'
                    '3XZ9zz2rPVTFz2y3FPh2G4tJd8BgZgCpUTAABAClvpPPoi53ySXvUp/QvjXQd2Hq'
                    'UNDdxnd/4L89UIFKooUElBSz/+y9/+d39//Pv3pQMBgEhX2gEAAMzYicsh48TT1t'
                    'FVFMZ5U0lQleHlqfQUFR5SVFJYHHLhKfqYtUOrKJxVUvC9xnkd16HLT/7HxXOxeE'
                    'HmKgpHay9WrHBdd2mI714CgAKSEwAAQAq9iNg6vM15AO473isWg60eZsa/+rGVFg'
                    'i1JykgxqWqCSIid+XCAIAkNtoBANp+evxJOwTAgo0sVU04t4JWD4cpErV6iJ3DtQ'
                    'T/XJn/jOvOXefV6iFXKwYRWj2UbfUAAGpITgAAALG2IvLh5HcsHd5aSZbwGv88sK'
                    'JkjJPlrR30zyYpRMxvJqEFZ/qZnz0WigEAUtlqBwAAMGEnIm+DrpyootBakoK5Kg'
                    'oL12erohCapLAU18w1zms4XjPIEJakEBnLxSSFiDnnxpGkAGDN3mgHAACnOIkB6j'
                    'P0F380/pF2/RzUeY51nTskDhPjnwd2Hh/Mc+2h4/iT5a29RpNjL0zkuo9m3it4Nl'
                    'c1QUTkVkT+WCQSAEhjqx0AAEDdRg7JCeHGzxPd8W8Nz78V8V3cxLxRhri5Xu5pGD'
                    '9LR8YSM4fD9Rdfg5i1Q649u2aQYfl9EbqO4/gx2aTrnC/wi+dCLK9eE595Xe/vaN'
                    'zsXrusnfrPIAAUQOUEAAAQYyvnVROmmKhGkHnucbyPNbV6sFABovZWD3zZ4KI//s'
                    'Xf/nd/f/7zx1KBAAAAAInsJbRqwrmJp62jqyiM86aSoPrBSasHC5UUFodEPEEfse'
                    '7cepZaPXg9+e8z/8xYM60eRNznA4BKUDkBgC0cvAC16WV8ImHpk5ClJ8ytVHTwGn'
                    '9URcF1frVqBBem891HlT2f+KGV91bI+HVZqpogInLH/gGozHvtAABNPz39pB0CoG'
                    '0rLg8E+Jp4Uv7wS2NVFCLmO7mnyIoML/FoVFGIWTt0D4+uc35vhFQu8Bg/DM8VBn'
                    'LMf2Hs5L27zhswbvE9sDQfVRQAVILkBAAAEGorIh9+OYw1lKRg/gA8ZnyhJIWEcZ'
                    '8MyX3Qn2z8xCbU+t5aj/7V70zv0ZOkevIMAADkxd93gD7rQePZoXfTSQq0eghLUv'
                    'BNYPFNpPCI7aXVg2+SQmRCw8UkhYjEh7lxJCkAaB1tHQAAQKj+5FcvZecdP/34fk'
                    'jKVQLfWjl+5/HPA33nTh6H+/ju/BeWXiPXiazFzZcNI5eqCaO7fGEAQBYb7QAAAC'
                    'quReSDV5n6EBPzO5f095w3er6oy4eXw+3ouGLncLj+4msQs3bIdWfrZWn1MF7jPD'
                    'Rjq4eZWF69Jj7zBoxbbPWwNOcvY350XB0AiiA5AQAAhNiIyPeTP3lJUHA4NbV0eK'
                    't2AB47vrN3nzPjX/3YxB7KQtwkKVSg9xj7mCkGAMjlSjsAAICK/uRXSkkKSeZNJc'
                    'EevNyTlSSFxSEXT8qTJBuEXOecvBKSFOCTczAM+eafGfvq3l3nDRi3uNdu8z06jA'
                    'KAYmjrAMAWDleAOgyyk7my6C9l5x3rz6uW708wt3rcY3nKoy9Z1GI5Gj8z9mS63K'
                    '9PsvETP7Ty3goZ3w6fqgkih8oJv88SCQAAAJDGtYi8n/yJb9l8X2cl4Ztu9XCooR'
                    '8fV8wcDveyWOY/ZO3QPXRtP3B+jc86HrEFt3pwnP/S2IutHlzmDRgX3eoBAAyhcg'
                    'IAAPC1EZGd08iXJ7ozVlLwUVELhLDxzwN9n+r3kTjukyHVVCOY+EGt76029FO/+b'
                    'f/l78vHAYAZHOlHQAAoLj97E9zV1EY1zj5Ja0eFmOJraKwcH22Vg+hlRSW4opdx+'
                    'Ma71YP4/yRsUzeu091Bs+1o1s9AIABJCcAAABfO+nkbdiBqeNFVg5vzSQdHI33mb'
                    'ii++zOf5Ezdh+zCQrd4m/NzmvpvVUv36oJIiK36cMAgKw22gEAGn56/Ek7BEDLjY'
                    'h85zQy92HkxPzJkhRSSbAHJCkEXne2XpZWD+M1rkMHzyQF33hmWj0Mp5uRttXD0d'
                    'pOrR5IUgBgGMkJAADAx0aOqyYEHfRmrKJQc5JClrkDqigo7vmrH5vYw6XxFSQptK'
                    '3XDgAAAABIrPe+okQVhYkkhdRzas83/HL6myZJIfP1F18DjSoKrgfnoWt5jh+GId'
                    '/8M2MnqyikTFLw2WsSFAAY9UY7AAAAUJWdiLw9+Z3x8NP1Q8/LeMcLg+f3GJ9jbM'
                    'jckmP888Du6EsWtViOxs+MPZnOZ+4ScV8cP3FTuWPPdZ/1mK+acPl+75JHAgB5XW'
                    'sHAAAoZici74KuHP/+mzNBeTidfzwY7WIWTR135Hwn93R2v6Vjcbn+4msQs3botU'
                    'f75fze8N1jj9jGahidT2VJn3u/MHby3l3nDRg3u9eHH90vzAYARVE5AQAAuNrIcd'
                    'WEc8FPgDteZKUagaWKDl7jnweqtEC4HI7zdNZeI5+JLLxvQ8bb1wde95gwBgAAkM'
                    'FPT7R0wCptJEVlsNwl3S9UUTBZSSHqclo9BF17do3TeyPBOvNDPVs9jPNHxjJ57z'
                    '7VGTzXntnne8fZAKAIkhMAAICrGzmvmjAl6KDX4yIrh7dmkg6OxrsOrOg+X/04d+'
                    'w+Y32SFCra80rMV01Y9pQoDgAoYasdAACgiJ24fOZ2pZSkkGTeVBLsQfJWD7FJCo'
                    'tDLvYbiEtSCLnmLEnB9xrndVyHDp5JCr7xXNz6iQQFzxYOrmsnSRQCgMxo6wDAlv'
                    'oPS4CW7UQkc9l5x/rzquX7E8yt3hrieaC1Vg8z41/92Hdf1Fo9nP0w93vLd3y931'
                    'n0cz/83X/7d0tfyNyJyPuE8QBATmHlvQEANdnIXKXCGLGtCVzml1/WoNWDYzyhc8'
                    'S0eohZO6bVw/N1Xq0efNbyHD8Mg6y61QMAKCM5AQAAuLiR8YvxIge9hpIUzB+Ax4'
                    'wvlKSQMBnjZHlrB/0Xx0/cVK73Vsjc4jm/vtiqCQAAwLq6/m4CxOukl5RVE86lPu'
                    'y/tMbJuWvDSQrjdxYxccXeW0ySQszaMUkKvgksvokUHrGNLTu8kxQiExouJilEJD'
                    '7MjXte785hdgAohrYOAADARX/yq2Jl5x0vUivfnyAOE+OfB1rYQ8fx3fkvLL1Grh'
                    'NZi7ueByr6BHPcJ5gDAEq60g4AAJDNVgb5Q5GVYtsKBMyfpMx86rijwxleDrej44'
                    'qdw+H6i69BzNoh155dY6LVg+i1ehhON8N9Xv9xj45XAEARJCcAAIAlN3KpnHCRg1'
                    '6Pi6wc3qodgMeO7+zd58z4Vz/OHbvPWJIUcklVNSHFHABQ0kY7AABANr2I5E8cOK'
                    'aUpJBk3lQS7MHLPVlJUlgccvGkPC5JIeSal61zTF4JSQrwyTkYhnzzz4x9de+u86'
                    'YeBwAF0dYBgC22D0SAdRocnlIOKYFfc6sH1/FF9iX1+LE8ZeZWD77jXVs9OIz3mX'
                    't+oZjxEz+08t4KGV9OvzTgd//t3xUIAwCK22gHAJTy8+PP2iEAJV2JyIeT3/EtZR'
                    '8j91pnZeibbvVwqKEfH1fMHA73MvsahK4duoev2w8svzd81/IYH9zqwTWeC2Mvtn'
                    'pwmddt3J1DdABQDMkJAABgzo1cqpowpchBr6EkBfMH4DHjCyUpJIz7ZEjug/5k4y'
                    'c2odb3Vn5uVRPc4r0VkT/GBAMAhV2JyA/KMQAA0ttP/m7qA/g5JdY6O/RuOklh/M'
                    '4iJq7Ye4tJUohZOyZJwTeBxTeRokSSQmRCw8UkhYjEh2ePjpEBQBG0dQAAAHN6c2'
                    'XkX8Y7XuT7oThX7Bb30WfiLHNLlvvszn9h6TVyncha3KWe3JrXawcAAAAAJHQtIu'
                    '9nR5QsyZ57rYn5nUv6e84bPV/U5cPL4XZ0XLFzOFx/8TWIWTvkurP1srR6GK9xHj'
                    'oc2j34zO0Tz4Wxr14Tn3ntPFwAABdROQEAAFxyLcdVE8w80X803lIVBdfx1io6OM'
                    '/d5a+ikHD8qx/nqkYQMrdcGj/xw1rfW+m5VU1w95hwLgAoYasdAFBKkr70QAU66X'
                    'rnwaHl9kPkrqQwMf8gQ1wVhXFeI1UUDlM831OK/UxRSWGxEMGF1yCmGkLkdRZaPY'
                    'iIDMPgX0XBdf6Zsa9eE9d5T8c9OEQBAEWRnADAFBsPZgIQERkuPaWc+0Az6KB3JU'
                    'kK6nE/D7SWpDAz9mQ6awf9F8crJCnkus90+sTz3SWeDwBy22oHAJTw09NP2iEApd'
                    'zIUtWEc7mTBqbWy7nW2f003ephTFKIjStmDod7mX0NQteOSVLwfW/4xugRW3CrB8'
                    'f5L4292OrBZd7DuHuH1QGgKNo6AACAKdfd0hcllsrIv4x3vDBZOf4E403uo+NAn/'
                    'lz7+HC+JMhvnGr7fnED2p9b8VJXTUBAAAA0NYHtzRI3cZAe63h/Je0eliMJWYOh+'
                    'uztXrwvfbsGqf3RoJ15od6tnoY54+MZfLeKTQEoFJUTgBgC6UTACv6Q0b4wcXPO5'
                    'YqEZyMd3wU3EQ1gsxzh453GntUSaGS+zy5NSvVCGbHK1RRyDk+TO868Hf/57/zmf'
                    'dHEfnONxgAUOL3dC0AwLIbOWqhGFwxoGQlhdxrTcyfrJKCkSoKhyme72ms/hgTW2'
                    'w8MZUUYtYOeU0mqmwkb/UwXuM4fkxQ6DrXCzzjuRDLq9dked57xxUBoBgqJwAAgH'
                    'PXIvL++Mnoxc9OJZ4u95G7ikKu8Zb20WvugCoKinv+6scm9nBp/MQPre15HjmrJj'
                    'xmmhcAAAC4ZCMi+6kfBFcLKPn0dIkqChOVFFLPqT3fyz2lqqSQ+fqLr0HJKgpn1z'
                    'lX2PBdy3P8MDg+rBEy/8zYySoK02PvHVcDgGJITgAAAOf6k189H1I6nVWaOSw/Hm'
                    '8oSSHH2JC5s4z3eaNExOJjYfzJ8tYO+meTFCLmt/Rn1E2ffEYAqNdGOwAAQLSdiL'
                    'y99ENaPRytcfJLo60eIuY7uSdaPfhftxTXzDXOa/i2evBNUoiMhVYPAGpFWwcAAH'
                    'DsWi6VDe5ExKXVw9FYJ04TphjvGFTI/Gtp9eA0fiy34fHBXPn9crK8tdfItdXD7H'
                    'ifud2XSzb+Mv+qCX5r3gpl0gHU5UoO/+0CmvTTP/+kHQKQ20YOyQmLaPUwPX+yVg'
                    '9n80aJbB1Bq4fAaydaPUzGlXid+aGH70GMtXq4d5wdAIohOQGALSU+PAG4bFj4ou'
                    'To0HHx/NHMYfnR+MHjIiuHtyb30XFg5/EUiPJ9vvpx7tcoSdwTP6z5vfVa7zP4d/'
                    '/N3wUvBAAAABSwk5mqCVMGGcIO4leQpBCVoDDOmzJBQeLme7mnFPuZIklh4dqLr0'
                    'FskoLvdRNJCovvjdAkBdecg+E5WSBHksLM2Ff3fhh77xYEAJRDWwcAADDaisjvnU'
                    'YelW9f/OxUogS+99yOi5SI3UI5ft/xzrE8D8x9nwn35dV02d+LKcZP/LCiPb/gT5'
                    'L/S5Tc8wNAalfaAQAAgm1F5I8hF0a1NChZ4j33Wmel7Wn14BhPzLUL18++BqFrh+'
                    '7h0XVerR581vIcH9TqwXX8hbFJ/lwAQGZUTgAAAKM+9MlopwfkfZ4W9x0f/ES344'
                    'VmqhEEjPWNI8t4nzdKRCwJ4z4ZUk01golNyPXeCplbvObfe0QS6r7AGgCQ0kY7AC'
                    'ArzlLQtl5Eop+sP0zhOUlLVRTGNc6qKByWjNpceZ4kjcj5aPUQce3R+8P5veFbsc'
                    'EjtpdWD+ODG67z+4ydiOXo3u8cZwKAYqicAAAARA5PcXx4+VXgU/eLD1RbqkRwMt'
                    '7xIhPVCDzHmhp/VEnBZ+7kcbiPf1VFwdJr5DqRtbiXx38WeqoDALAqPz39pB0CkN'
                    'NWxs/bCZ7UD34yOnWVAM21JuY3W0kh6vLh5XA7Oq7YOWIqKcSsHXLtRJWNbOs4Dx'
                    '1e2j04z+1bdWHao8csAFAEyQkAAEBkqrd7xKFjlUkKrhdZil3tADx2fGfvPmfGv/'
                    'qxb+w+ksVddZJC7zGTiIj87r/5O99LRETuQi4CAEXX2gEAAIJ8fPU7CQ7Ao1o9NJ'
                    '6kkGTeVBIlpKSaK0mSwuKQmVYPMUkKIdesvNUDbR4AWERyAgAA2Mpx1YRzkUkKrm'
                    'N953Ye7z33SpIUcsThNf6oioKlA3Of6SzFbSlJwcfr8SWrJjwWWgcAAADrdS0i7y'
                    'd/ollFYVy/lNxrTTwpb7KKQsR8J/eUIi6tKgoxa4fuobEkhZcqCvmTFD57rAAAxb'
                    'zRDgAATvgeagCINzg+pTz++XT9MNTJc189h8s6j3l9x4fELSIyOF4YPL/H+Fxjfe'
                    'PIMn7MZPH4kiX3Hi7MfTLEJxbVPZ/YBJvvrd7xqlSeRORt4TUBINRWOwAAgLd+cc'
                    'T49+aI78SO+sv7Xhi9tqm1htP5g/flfE6RdHGfxeh/+fM9jd9ZxMQVe28O1198DW'
                    'LWDr32aO+d3xu+r5dHbGPLjq7zWMAnHgomADCKygkAAKzbVjr5UOKp+8UHsC1VIj'
                    'gZ73hR/BPjDrEkHltqvM/EFVWAeFVFwW41gssL23pvlayaMLorvB4AxHinHQCQw0'
                    '9PP2mHAOTyvVyqmjBFs5LCClo9JKmkkErK19pKq4fQSgqKrR7GuHyvcV7HdejwXE'
                    'nBZ2634ffukwJAOVROAABg3XYv/1boyejFZcw80X803lIVBdfx1io6OM/d5a+ikH'
                    'D8qx/brEaw/EMb760++okdAGgcPYMBoCr7oKsin6w/TDGEVQtIsLbXWpJxvYn5g/'
                    'dlZs4oiapmdNKliS1FJYXFQgQXXoOYagiR13lVUfBZy3P8MDzvTbr57x1nAoCiSE'
                    '4AAGC9NiJyc/I7hQ56nc6ecx6W+45/iaXSJIXs+5J6vM8bJXcsR+Nnxp5MZ+Og32'
                    'G8QpLC5bFRVRMiDuvuxedpNgDQdyVUfQGAGtxITMWbRIfWhyk8J8mdNDC1Xs61zu'
                    '7HbKuHiPlO7inFfsbM4XAvs69B6NoxSQq+7w3fGD1ie2n1kCZJ4dFxBgAoirYOAA'
                    'Cs104u9VrPX77d/bLccQSNd7wocF+Sjy+2L6nHPw+0sIdH4TgP8dkX1T2f+EGuPb'
                    '8cR+8xy4nffve3oZeK8CQJgPpstAMAACzaSMTfb0+kLP+vsLaptYbzXyZq9ZAy7l'
                    'SvdYq4YudwuD5bqwffa8+ucXpvJFhnfqhnq4dx/lN3fhMAQBkkJwAAsE4bOW7pcE'
                    'mhg97Fc1Yzh+XH4z0ushK7xX10Hdh5JCkYuM/u/Bc5Y/cxm6DQLf7W7LzhexhVNQ'
                    'EAVmajHQAAYNFOYqomTCFJIdv8SVompU5QaC1JYXFIpiSFkGvOkhR8r3Fex3Xo4J'
                    'mkcBrPo/uFAFAObR0A2FKqZByAnQwXqiacCyndHji+W7qsRCzeLRAcFym4j1nmNt'
                    'EaohNzrR5mxr/6se++rKXVQ6qnysLcisgfFdcHAF9XIvKDcgxAMj//88/aIQCpbc'
                    'TlQYBQCUr2D/Lc115hbTNrraDVw2GK59c6RWyZWz0chl14b2q0eni+zqvVg89anu'
                    'OH4XlvfObvqJwAwCYqJwAAsD4bEdlZeLp8arzTZTmfLg++T8cLzVQjKBBHlvE+b5'
                    'SIWHw4VFHoJn/hMK/ank/8wDd2N1RNAAAAQEt2cql9YipUUUi7xskvjbZ6iJjv5J'
                    '4sVFGopdXDeN1SXDPXOK/h2+rBbfzDy9yl/swCgCOSEwAAWJ+dHH9ZYumw/Gi8c5'
                    'KCz7zFkhQyze8dS6Y4TIw/SlLwmTt5HO7ju/NfWHqNfCZKG3fvONuk3/6f/jbmch'
                    'HKXAKoz1Y7AADARVspWZWLJIVs85tNUoi63Firh1qSFCZaPSy+NxKsMz/UqdXDvW'
                    'cEAFAMbR0AGFOqPhywZsNu8rdDyrEXavUwe2nE3NnGu7Z6eBmfMRbX8Sb30XFg7a'
                    '0eXOdX+zM68cM0cVuomnCnvD4A+NpqBwAAuKhXWTVl+X+Ftc2sNTF/8L6cz5sqZo'
                    'utHmLmcNib2VYPoWuHvCYTrUCSt3oYr3EcPyYodN3kBbceqwJAUVROAABgXW5Eur'
                    'ezn3RMPBX/erxTFQUrFSBOqig4XGimGkHg3D5yV1EwX43gwnRVVICY+GHcnvcekQ'
                    'EAgMb8/M8/a4cApLQVkQ+qEWhVUUiwtqm1Qp6U95wzmqVWD7FzxFRRiFk7ptXDy9'
                    'Z5tHrwWctz/IVWD/ceKwJAUVROAGALhROAvIbjw8CZx6qNPkXvdJnP0+K+44Pv0/'
                    'FCM9UIAsb6xpFl/JjJkrmSQsK4T4ZUU+liYhP831tpqiak+YLvRxH5LslMAJDfe+'
                    '0AAACT9toBiEiyJ+sPU3hO0lIVhXGNsyoKhyWjNleeJ0kjcr6Xexq/s9CuorBw/c'
                    'XXILaKQsi1R+8P5/eGb8UGj9jGlh3d+OAGVQIBGEZyAgAA63EjnbwTEfea8tYOy5'
                    '/nXlzGzGH5+XjHG7aSYGF2Hx0HdpNPD1y+RDHuk+WtvUYXExTOJvKLu3eMoIRH7Q'
                    'AAAABQtWsR+b12ECdIUsg2v9kkhRSvNUkKUckDJlo9jEkKXXfnsQIAFEVyAgAA69'
                    'G//NurQ8QMSQoFDnoXlzFzWH403lIVBdfxlpJUvMZ3+asoJBw/+cdSfQ/FoYrC2Q'
                    '+X9yVN1QQAWK+NkFiFFqSpgARY0ItImcN4X5GH1ocpHA5cL60t8eubWOtCkkJUgs'
                    'I4r5EqCocpnu8pxX6mSFJYPOe/8BrEJimEVFF4Xs+rioJ4rOU3/vMw8D+yAOz6lX'
                    'YAAACgiBuR56oJx159qOmmfnNm/IyFqVKNd7osZG4fQffpGFShfcw2d444vMb7vF'
                    'Fyx3I03nU6a3FfHD/xw8vje49VL/rt//FvU0wjQqIEgPpcaQcAAHhxLWPLnUFsJt'
                    '0kiGt4/r/g9UvJvdbZXkbty4U5o0XOd3JPKeKKmcPhXmZfg9C1Q/fw6Drn94bvOm'
                    '6x3XrOCgBFkZwAAMA69Bd/MnmAuJCgYOLQ+Wi862XW4s6dpOCjuqQD3/GFkhR8xj'
                    'abpDD7W5+FL0oAAADQjo+vfockhSxrm1prOP+l0SSFqMuHlxYB0XHFzhGTpBCzdk'
                    'ySwlJcsevMX3PrORsAFEVyAgAA7buRqaoJ514dODpUUVB8uvzS3IvLmDksPx/veJ'
                    'GV2C3uo8/EFSVj+PyxjI7FR1gVhY+eq5Rwrx0AAHi60g4AiPXzP/+sHQKQwo3Mfd'
                    'a2mKAgQpJCxvmTJSmkkvK1XnuSQsg1Z0kKvtc4r3PqSUhOAGDcG+0AAOCE78EIAB'
                    'c7EYnoL//qN16PV+l1Pz9+cZmIuZ3He++L4yIlYncdb2kfvebuRDqPUpXKez75x1'
                    'J9D5fGv/rhg5CcAAApbLQDAACIiEu7Mr8+8WUNEh3XIIN0IZMkWNtrLcm43sT8wf'
                    'syM2eUBPO93FOK2GJff4frL74GofEnuG5MUFh8b/iudTr+B4/oAEAFyQkAALTtWk'
                    'S+E5EEh8IzE1g6LD8a73T2bOaw/Hi8oSSFrMkYHmMlx3ifN0ruWI7Gz4w9mc5aEs'
                    'nF8S8/7FN9ufbb/8PfppkIAAAACNOLS4XCkdUkhUSH1ocpPCcpvSe5EyLO5g/el/'
                    'M5RdLFHTnfyT2lSDCIiMXl+tnXIDT+mCSFziGuC9d4xPaDZ2QAUBxtHQAAaFv/6n'
                    'eiS87PTJChpH30eNfLrMXdeQQVuC/J57b4+juNfx6Yaw99xzvEfTLE2ms0zWrVBB'
                    'GRO+0AAMDTtXYAQAxaOqABGxkrFPoq2dbAR8ry/wprm1lrYv5krR5Sxp3qtU4RV+'
                    'wcDtdna/UQ0oJhOP6lw3vDb50nITkBQAWonAAAQLuuReT95E+in4pemCDnE/q+44'
                    '9iWQzLZAWIsWyiw0UmqhFknjt0vNPYMUFhqOY+T24t92sUF3dv7zGxF48mvyAGAA'
                    'CAVTsReRs1Q+6n+EOtpZJC7rUm5o9u9TDOa6SKwmGKxK0eYuZw2JvkrR4c111az+'
                    'm94RbjD56RAIAKkhMA2GLxgxlQq8Gh/2WJJAVLB9TP4xfDMnNYfjzecREDB+ZRcx'
                    'dIUnEabK3Vw8z4yT+W5ZIOXManr5qQPpngSWK/YAaAcrbaAQDAim0ltGrCudJtDX'
                    'wkOAQPPowvmbiRe62JQ+jDL6MyAk7mjBY5X9JWD2M8MQkKMn+9uVYPz9d5tXq4vN'
                    'ZHzwgAQAVtHQAAaNO1dBeqJkyJLlE/U/u9RBn5gPFOl6UraZ9m7u7kXzLN7zE+11'
                    'gT433eKBGx+FgYf7J87rj9xvcv16T6J727LLMCQB7vtAMAgBXrJXVSa8m2Bj4SxE'
                    'Wrh6M1Tn5ptNVDxHy0eoi4djj+V8f3xushDyJyG7A6ABRHcgIAAG3qRUThkHdmAk'
                    'uH5UfjnZMUfOYtlqSQaX7vWDLFYWL8UZKCz9zJ43Af353/Qvc1ehCe3gAAAEAbti'
                    'LyIdvsFhMUREhSyDi/2SSFqMtJUgi69uwa5wSFX4Z99FwRANSQnAAAQHuuRY6qJh'
                    'Q/5F2YwMph+dn4xUvNHJYfjfe5yErsRpNUnAZau0+fP2a5Y7+s95jJyW//979LPa'
                    'WIyH2OSQEgoyvtAABghfbZV7BaRUEkWZKC1tpm1rqQpJBk3lRSvtZWkhQWh1wYFJ'
                    'ukEHLNy9Z5VFEY5OPLtVP/AIAhJCcAANCem8nfLX4o7HB6mjOWiCQF9Vi853ZcxF'
                    'KChdEkFaeB1pIUfKYru+c1VU241w4AADxttAMAQvz855+1QwBCXYvI74utZvlAUa'
                    'uKQoK1Ta018aS8ySoKKVo9jHOliCfm2tAqCjFrx7R6cE9S+JPwmRZARUhOAACgLV'
                    'tZKjNZ/FA4cRWFAge9Tpdle0LfNYCp8YaSFHKNNTG+UJKCz1ifJIVyyRUfPa7U9q'
                    'gdAAB42mgHAAAr06usajVJgVYPadc4+WXDSQpWqijU0uphvG4prhJVXQAgoTfaAQ'
                    'DACd/DPgCnBo8vTDpx/2A0/tkMHr8wQfT8DuMD5l5cpkTcQeMdb9hnX3zH+8Rudh'
                    '8dB3ZD9vdiqvEny+d9jZ4k0xckSUqevnaXY1IAyOhKRH5QjgEA1uJajlsnahjE5n'
                    'dm41/NI2Ib/37f+U6SYG0za03MH7wvC/NGiXwfvtzTcPRkSEwsMXM4XH/xNYhZO2'
                    'QPz9YbZDiO6UFEbgMiAQA1VE4AAKAdW+nkg40nyy+NX5jAZDUCxyoK1vbdUhWFMk'
                    '/pu4334Ty+QBWFhOMn/1j6zO1mL3VVI3jUDgAAAABm7bUDEBG7VRREksRVTauHnO'
                    'tNzJ8kOdtQFYXDFEetHixUUlgcMtPqIbJlQ+h1R1UU9gEzAYAqKicAANCO/uXfzD'
                    'xZfjR+OP+NCxNYjF0OD8cvXpazooPv+JMqCg5BWdr3QpUx0o73eaPkjuVo/EIVhZ'
                    'fp0r4+2aomZHSnHQAAeNpqBwD4+vLnL9ohACFuROQ77SBOlKwY4GMtVRTG9XKuNf'
                    'Gk/OGXxqooRMx3ck8p9jNmjpgqCjFrh+7hL+s9DTJ8DFgZAFSRnAAAQBu2IvLh1e'
                    '8qH34uzz0zgaXD8nG8S6uHo7HZ4gganzFJIWeChbl9dBzom6SQPUnFcUiaJIW95K'
                    'xEkO9JpScReZttdgBIa6sdAACsRK8dwEUkKWRZ29RaZ4feZpMUUrzWa2/14Hvt4Z'
                    'ofpKMKIID60NYBAIA29LM/zVbOXhKUnPetQZ8hnoC5F5dRLt1/ebzjRVZit7iPPh'
                    'NXdJ8+fyxn5s5aNeE//Ne/zTW1CNUTAAAAcGonIu+0g1hkudVDgvL/QW0NSrbAUG'
                    'r1EN3uwWCrh0EGO60eFq6/+BrErO1/3f5lvaV/AMAQkhMAAKjfRqaqJpwzcPg5P9'
                    '4hScFHodgXLzNzWH483nERS+8ZS/voNXdn7z59coH893AvOasm5PWoHQAAeHivHQ'
                    'Dg48tfaOmA6mzEctWEc5YPIBPEFXwQX3JPcq91IUkh9Zza873cU6okhczXX3wNYh'
                    'IU3K79LCTYA6gUyQkAANRv5zXa0oHzON51Aouxu549mzksPx5vKEkhx9iQubOM93'
                    'mj5I7laLzrdO5zP0kn+5fxOf7J6y77CgAAAKjFTmps+WU1SYEqCmnXOPlloioKhp'
                    'IUTu5pzVUU5q/9GDgzAKgjOQEAgLptxDc5YVTkCf2YWHwe7w6ZP/F418usxf2SpJ'
                    'Bpfu9YMsVhYvxRkoLP3D4Sx/2qisL8+L3UXX3gUTsAAAAAmLCR0M/ZVlhMUBAhSS'
                    'Hj/GaTFKIup9XDhWufhOQEABV7ox0AAACIspPYpzk6cf+QNB5MFhu/MEHI/D4fCA'
                    'P3ZjGs4vvoMH7wuMjKe8bkPjoO7DyeAlG+T8c/lk9ySE7I5j/8736bc3oRKicAqM'
                    '+1iNwqxwC4sXpQCkzbi8jbApW78hr/3Fm8jwSxjYfAne8kJfcl91oT8w8y+O/J1L'
                    'ypYk70WnfSpdnP2Dkc9ubiaxCz9um6+4AZAMAMKicAAFCvjaR6msPMk+WXxi9MYD'
                    'R2pyoKBSo6+M3tuIil94z5KiAzAyuqGDH5x/IXP0j9lQcetQMAAACAuq2IfBARuy'
                    '0SfFm+jwRxBVcLKLknJVo9DMe/NFpFwUqrh9g5YqooxKz9y7ofA2cAABNITgAAoF'
                    '47Sd0D09Jh+eR4n5NTh7kLjHe6rEjSge94Q0kKucaaGF8oScHHwviT5X/5Re+5ik'
                    'V32gEAgKeNdgAA0KD+1e9YPdj3ZTVJgVYPadc4+WXDSQrrbfXwJxG5D7oSAIwgOQ'
                    'EAgDptJGcPTJOH5Y4TWDosPxrvnKTgM2+xJIVM83vHkikOE+OPkhR85k4eh/v4ox'
                    '9/kna+HHnSDgAAPFxpBwC4+PLnL9ohAK6uZayacM7qwX4Iq/dBkkK2+c0mKURdvt'
                    'okhf3LNT7/AIAhb7QDAAAAQXaSumrClE7U+twvj1+YIGT+ArEvXlp8Hx3GDx4XWX'
                    'nPFNkXx7Fe4zuRzqNUpfL75fnHvXfSTogyX6jcicj7IisBALAS0QdiQDn9ZJ/4Yy'
                    'l63ltg+T4SxDbIIIuvZaa1zaw1MX/wvpzPmyrmlK91iv2MncNhby6+Bm5rP4jIbU'
                    'BkAGAKlRMAAKjTTbGVzDxZfjTeZwJrsR9VUlCPxXtux0UsvWesVHTwGn9URcFSxY'
                    'hpLVVNEBF51A4AADxstQMAgIZci8h75yfMW3ka2fJ9aFVRSLC2qbXOXmOzVRRStH'
                    'oY50oRT8y1oVUUltfeB8UEAMaQnAAAQH1uRORd8VVNHpY7TmDpsHwc73qZb8Z+kf'
                    's0lKSQa6yJ8YWSFHzGvh7fe8wQ7G/+t78tsYzIoXICANRiqx0AADSkP/6FV5JCC6'
                    'wmKdDqIe0aJ79sOEmh3VYPHyMiAgAzSE4AAKA+verqJg/LHSewdljumqRg5rD8fL'
                    'zjRVbeMxb30Wdie8kYrVVNEGnvfgAAUPXzX37WDgFwcSMXWns5HeBaPdgPYfU+SF'
                    'LINr/ZJIWoy5tMUvgkVPoD0Ig32gEAAAAvN6JRNeHceJCp1Od+efzCBJ3H3L7jI2'
                    'JfXMbivg+OF1mKvci+5Ji7E+k8SlXmv8/ecWRN7rUDAAAPV9oBAEAj+qUBF/vEnw'
                    '468E3OtsbyfQwSHZfTa5lpba+1JON6E/MH78v5vKliTrAHL/eUYj9j53DYm4uvwW'
                    'Htj4ErA4A5VE4AAKAuvXYAJ8w/iT4zgcXYXSv456zo4Dv+pIqCw4WW9t1KRQev8T'
                    '5vlKyxtFg1QaTNewLQrrfaAQBAA27E8QEAr1YPVisQ+LB6H2upojCul3v+4fiXRq'
                    'sopGj1MM6VIp6Ya8OqKDyIyG3EygBgCskJAADU40YsVE2YYvKw3HECS4fl43jXy6'
                    'zF/ZKkkGl+H7oH9wXGHyUp+MztY3587zlbLe61AwAAAEAxGxHZ+17klaTQApIUsq'
                    'xtai1aPfjHUjZJYR+xGgCYQ3ICAAD16LUDWGTi0PbS+IUJrByWn8WyGJaZw/Lj8R'
                    '4XWYnd4j66Duw8khTSxP0nafsQ/0E7AADwcK0dAABUbCcRVWhWVUVBxO59kKSQbf'
                    '5kSQqppHyt60lSeBpk+DhI3P8BgCUkJwAAUIcbsVo14ZzFQ17fJIVisbiPd6qiYO'
                    'Kw/Hi84yKW3jOW9tFr7q7kfe49roz2N/+b35ZcTqTtxAsAAIr5+S8/a4cAzNnIIT'
                    'khCq0eDEkQV/AhbsOtHg6/ZbCKQoIkhVRzZb7+BxF5jFwBAEwhOQEAgDrcaAfgzd'
                    'KB8zjedQKLsbuePZs5LD8ebyhJIcfYkLmzjPd5owTH8lna73V5rx0AAAAAsuslom'
                    'rCOZIUjKCKQto1Tn5ptNVDxHwn92S3isLHiFkBwCSSEwAAsO9aRN5rBxGsyBP6Mb'
                    'EsVFEwceh8NN71MmtxvyQpZJrfO5ZMcZgYf5Sk4DO3m/4ljlL/lHevsioAhLnWDg'
                    'AAKrQVkT/kmNgrSaEFVu+DJIVs85tNUoi63GyrhzU8HABghd5oBwAAABb12gEk0Y'
                    'n7B7TxQLLY+IUJQub3+TAauDeLYRXfR4fxg8dFVt4zJvfRcWDn8RTIchw6X4yU/8'
                    'LzvviKAAAAKKnPvcAgg3RLmbbj33N1EnLTsXwfCWJzei0zrW1mrYn5g/flfN5UMa'
                    'd8rVPsZ+wch73pIyIAALOonAAAgG3XUnPVhHNmniy/NH5hAqOxO1VRKFDRwW9ux0'
                    'UsvWdy7ovv+JAqCvH32TvOkMzf/K9/W3pJEZITANRlox0AMOXnf/lZOwTgkisR+V'
                    'BiIVo9GKJVRSHB2qbWOnuNzVZRsNLqIW6OPwlVEwA0isoJAADY1msHkIWZJ8svjZ'
                    '+ZwOJT9OL4gHyhig5+4x0vtPSesVLRwWu8zxtlcu41lZO81w4AADxcaQcAAJXZl1'
                    '5wPOh0qqRgsfqAL6uVFBI9WX+YwnOSlqoojGucVVE4LBm1ufI8SRqR873c0/idRf'
                    'kqCjuzyT4AEInKCQAA2HUtLVVNmFLkCf3Q8Q5VFKxUIzgav7iMpUoEJ+MdLzJRjc'
                    'BzrKnxR5UUfOZuNVFq2r12AAAAAMjiWhQ/Yzs9ZW65+oAvq/eRYI+DKwaUfH1zrz'
                    'Uxv9lKClGXP99Tirjc5/gkfC4F0DAqJwAAYFevHUAxpp9EX5gg9xP6vnM/j1+81M'
                    'wT/UfjLVVRcB1vqaKD1/jOp4qCWtWE6C+2wj2IyDutxQHAw1Y7AACoSK8dgMhRX/'
                    'v5QQfWqg/4snwfCSpVOL2Wl9aW+PVNrDUxf/C+nM9rpIrCYYrne0qxn/NzPImR/1'
                    'YBQC5UTgAAwKYrab1qwjkzT5YfjfeZwFrsrpUHC1V0cB7bnfyL43jf+TOMN10FZG'
                    'Hg8vj+ZUzpf/Tcq64OAO5IpII5X/7li3YIwJQbMfQZ2/kJ81YqKVi9D80qCuP6pe'
                    'Re62wvzVZRiJjv5J5SxDU9x174PAqgcSQnAABg0047ADXFkw58515IUDBx6Hw03v'
                    'Uya3HnTlLwUV3Sge/42SSFH0WpaoKye+0AAAAAkFSvHcAUrySFFpCkkGVtU2vR6s'
                    'E/ll/meJJDcgIANI3kBAAA7NmKyAftINQVeUI/dLxDFQWDCRaLy5g5LD8f73iRld'
                    'gt7qPPxKfj9x4rJfWb7X/QWlqE5AQAdbnSDgAAjLsR45VmnA5wrR7sh7B6HyQpZJ'
                    's/WZJCKilf63RJCnsReYycCQDMIzkBAAB7eu0AzLB4yOubpOCjUOxOVRSs7XvOKg'
                    'o1JylkmfulisKDiHz0WKUl99oBAICHjXYAAGDYRir6jE2rByMSxFVNqweFJIXUc2'
                    'rPd9LqIXyuB6nov1UAEOONdgAAAODEVqia8Np4qOr6Ia/E+OH8Ny5MYDF2Eelc2i'
                    'RG70vC8S+xOAZlad+L7Evq8Z2ISO+dYNOOe+0AAAAAkMROjFdNODcedHZLfxkf/0'
                    '5f+9/Zrd5HgricX8sMa3uvl3Ots/sJ3peZOaNFzndyT2H72Z/EAQANIzkBAABbeu'
                    '0ATDN5WO44gaXD8nH84HiZicPy8/GOQVl5z1h8/efH61dN0P1S5l51dQDwcyUit8'
                    'oxACIi8uVfv2iHABzbyCE5oUpeSQrWDvZDkKSQZW1Ta529V80mKaR4rccHK9zm0v'
                    '/8DQAF0dYBAAA7tkLVBDdWyvZPjndo9ZCrdL/v+LNWD7OXWmqX8DLe4yIrsVvcx2'
                    'm9xywtutcOAAA8bLQDAACjdiLyVjuIWKtq9SBi9z4Slf8PamtQ8vWtsdXDOG8qKV'
                    '9rt7lu4lYDgLqQnAAAgB29dgBVsXjI65ukUCwW9/GLl+kdls+Md1zE0nvGaJLKM5'
                    '7aOPhROwAAAAAE24rIH7WDSMX5ULuVJAXL95HkHD1wkpJ7knuts9c4OHFjZs5oiZ'
                    'IUFub6LFTAArAyJCcAAGDDRkS+V46hTiYPyx0XtHRYfjTe6bKc+xh8n4aSFHKNLT'
                    'O+97gqi9/8r/5GOwQRkUftAADA0bV2AABgUK8dQA4kKRhBFYW0a5z8sr0khZN7ej'
                    '1PHz4zANSJ5AQAAGzYSQPlJlWZPCx3XNDSYfnReOckBZ95iyUpZJrfO5ZMceQbT9'
                    'WEX9xpBwAAQE2+/OsX7RCA0VYab5nolaTQAqv3QZJCtvnNJilEXf6q1cOfhKoJAF'
                    'bojXYAAABANnJITkAKnbh/YBwPbIuNX5ggZP4CsS9eWnwfHcYPHhdZec/Y2MfeO5'
                    'mlXY/aAQCAo412AABgzEftAEoZZJBu6S/w49//a/97vuX7SBCb02uZaW0za03MH7'
                    'wv5/Omijnlaz3wXSCAdaJyAgAA+nZC1YS0bD2J7tfqYXJ84lgCx2dp9ZC9coGhVg'
                    '85Kyn4uDyeqgmn7rQDAABH32kHAACGXIvIe+0gSqLVgyFaVRQSrG1qrbPX2GwVhb'
                    'hWD59E5D5RNABQFSonAACgayNUTcinyBP6MXPPTGDjKfrT8S5VFI7GOitSucDxQm'
                    'vvmbKv/0fHq7P6zf/yb7RDGD1qBwAAAABvvXYAWsbDW6dKCharD/iyWkkh0ZP1hy'
                    'k8J2mpisK4xlkVhcOSUZsrz5OkETbfk4jsohMuAKBSVE4AAEDXTqiakF+RJ/RDxz'
                    'tUUTBXjcBhGUuVCE7GO16UrhrBTCyJx8aNfxKRvceVa3CnHQAAeNhqBwAABnwvK6'
                    'uaMMXpKXPL1Qd8Wb2PBHscXDGg5Oube62J+c1WUnC3F5LhAawYyQkAAOjZCFUTyj'
                    'J5WO44gdEECxOtHrz3ZSWtHvzG74UvR849agcAAB622gEAgAF77QAsodWDEQniqq'
                    'bVg0KSQpJ5U3HbAx4MALB6JCcAAKDnRqiaUJ6lA+dxvM8E1mLvHC/LmVzhO/6kis'
                    'IKkhSWHb4cGefW/seWH7UDAACgBl/+9Yt2CMCNiLzTDsIa5yfMLR/u+7B6H2upoj'
                    'Cul3v+4fiXRqsoXJ6vFxLhAazcG+0AAABYsZ12AKs2HoK6fgANGR8198wEJWL3HT'
                    '84Xha9LznGO16Y8z3gOz7tPu7F0pcjtr5MfNQOAAAcXYnIrXIMWDNb//uNNeqk1w'
                    '7BsvHwtlvKBh7EYsKwv/G/SdbuJUFczq9lhrVNrXX2Xg3el/M5RdLF/frP04NQNQ'
                    'EAqJwAAICSG+GpDhuKPKEfOt6hikLRqg5ucy8uY6kSwcl4x4usxJ5m7kPVBFxypx'
                    '0AADjaaAcAAIp6GeQdSTLLnJ4yt1p9IITV+1hLJQWlVg9JKimkchpjn3BmAKgWyQ'
                    'kAAOjotQPAEbOH5Y4TGE2wWLzMUnLFy3jHRSy9Z+Lm3gvVAeY8agcAAIB1tHSAso'
                    '0cVyVs6WA9I1o9GJEgruCD+NKtHhSSFFLPGTnfjyLyMeGMAFAt2joAAFDejVA1wS'
                    'aj7RKcJrAYu4h0g8NlxVtmuIzP2OrBd3y+NhJPMtiqmvCb/8XfaIdw7k47AABwdK'
                    'UdAAAo2YnI21e/a7WsvyFerR4OA+tm9T7W0uphXG+9rR52ZpNkAKAwKicAAFBerx'
                    '0AFhR5Qj8mFuVWDwF743SZtbh9Wz0UaJmROI69UBlgyaN2AADgaKMdAAAo2Mpx1Y'
                    'QpHAYuci6D38peWq2kQKuHbPMna/UQPsVnEbmNCwAA2kHlBAAAyroRqibUo8gT+q'
                    'HjFybI+YS+7/ijWBbDMlkBonse73CRlffM8tgnEdmbe2rInjvtAAAAAHBRL1NVE8'
                    '5ZfWLemEGG9VRREMn/FH+otVRSyL3WxPxO73GXef2n6OMWBYC2UDkBAICyeu0A4M'
                    'liJYJu9jdejy8Wi/t4pyoKBSo6+I13XMTSe+by2B+EqgAuHrUDAABH77UDwDp9+d'
                    'cv2iFgvbYi8sHrCqtPzBviVUWhhb20fB8J4gquFlByT3KvdfYaK1RR+CRUTQCAEy'
                    'QnAABQzvdC1YR6mTwsd1zQ0mH50XjnVg8W2iWcjDeUpBA+tve4eu1+1A4AAAAAr+'
                    'yDr7R8IG0ESQpG0Ooh7RonvyyWpNDHLQIA7SE5AQCAcnbaASABk4fljgtaOiw/Gu'
                    '+cpOAzb7EkhUzze8fiNfaTiNx7rLJ2j9oBAICjjXYAAFDItYj8PnoWi4fRxnglKb'
                    'TA6n2QpJBt/sxJCnz2BoAJJCcAAFDGtVButy0mD8sdJ7ByWH42fvFSixUgfC6yEn'
                    'sn/ct4Q//85n/+Nx43XNSddgAA4OhKOwAAKKRPNpPVJ+aNoYqCEYmSFLTWNrPWhS'
                    'SFJPP+4kl4SAkAJpGcAABAGb12AMjA5GG5xwTWYj9KUlCPxXtux0X03zM8ueHvUT'
                    'sAAAAAvLiWHIn/lg+kjaDVgyFaVRQSrG1qrbPXOHEVhb3wWRIAJpGcAABAftdC1Y'
                    'S2mTwsd5xA/7D89XjXy3zm9R0ffJ+GkhSm9R6z4OBWOwAAcLTVDgAACviYdXbLB9'
                    'JGrLLVg8V7odVD2jVOfhmdpPAkg+xfYrfwDwAY8kY7AAAAVqDXDgCFdOL3oc9n/H'
                    'jYHDx+YYLo+R3GB8y9uEyJuIPGO95w2feM7aoJfGECALG22gFgXb782xftELA+Ny'
                    'LyrshKg/gnQ6/MeHjbzW3U+Hf8FvbS6nsiwR47vZaZ1jaz1sT8wfty+B7wMTomAG'
                    'gUyQkAAOR1LVRNWBezh+WOExhNsFhcxuK+D44XlYu9d7wCp26T9B8FAABArL7oai'
                    '0drGc0yLB8eNvKXlq+jwTJE06vZaa1vdaSjOtdSFLw2JcHObR0AABcQHICAAB57b'
                    'QDgBKTh+WOE1iMXUS6weGynBUdfMefVFFwCCrvPtqumiC/PJUCAAi21Q4AADLqpV'
                    'TVhHOWD6SNcH7CvJW9tHofa6miMK6Xc62z+/HYlz5TRADQjF9pBwAAQMO2IvJ77S'
                    'CgrBO/D8wh46PmnpmgROwB9+p0mbW4O48L87wH+pd5Df7z5n/2G48bVvFZOwAAcL'
                    'DVDgDr8fXfvmqHgHXZiIXEf3JpFw3P/+cwsA2D2LyXBHE5v5YZ1ja11nD+y9l9+V'
                    'FEPuYNCADqR3ICAAD59NoBwBDfjP6ih+sLExhNsFhcxmJyxUuSguP4NLF8FuNVEw'
                    'AAAIAZOxF5qx2EiNg9jDbGOUGhlb20eh8kKWSb/8K+7DJGAQDNIDkBAIA8tiLyQT'
                    'sIGGP2sNxxAqMJFk5VFKwkV7yMz1hF4fX43mMGTLvVDgAAHFxpBwAAGWzE4oFfSw'
                    'frmXhVUWhhLy3fR4K4gtvwldyTElUUJpIUnn0WPjcCgJM32gEAANCoXjsAGDYeHr'
                    't+cC4xfjj/jQsTWIxdRLrB4bLofUk8t4jI4Hhh+D7yBQkArIeNp4oBIK29WP7v21'
                    'lferw2Ht52S5vUyl5avY8EcTm/lhnWNrXWcDr/877sMq4IAE2hcgIAAOlthaoJcF'
                    'HkCf2YWJRbPQTsjdNl1uL2bfXgN3//co3Rf978T3/jcUNqbrUDAAAAWKGt1PLZ2u'
                    'oT84Z4VVJogdX7oNVDjvk/ichdxtUAoCkkJwAAkF6vHQAqY/Kw3HECowkWi2GZTK'
                    '7wuMhtGFUTAGB9rrUDAICEeu0AvFgu628IrR6MIEkh5fz9yzpW/wEAQ0hOAAAgra'
                    '3U8mQHbLF4WO6bpFAsFvfxTlUUClR08JvbcZHlYb3H6ph3qx0AAABWfP23r9ohYB'
                    '2updbP1hwGLvKqotDCXlq+jwRxBSUoJFrbwFr/KCL32WYHgAaRnAAAQFo77QBQOU'
                    'uH5ZPjK2v10GVo9eA7PqrVQ3CSAlUTAGCdNtoBAEAivXYA0SwfSBuxylYPFu+FKg'
                    'qhnqSF/1YBQGEkJwAAkM5GRG6UY0ArijyhHzo+Q6uHAgkWVbZ6eElScBz/i95jJb'
                    'j5rB0AADi40g4AABK4FpH32kEkY/Ew2hing22rB/shrN4HSQq+9iLymGQmAFiRN9'
                    'oBAADQkJ2IvNUOAo3pxP1D83g4XWz8wgQh8xeIffHS4vvoMH5wvOgw7LMMFVVNsP'
                    'rFHAAAALTstQNIbvw7r2+i9coMMki3tEmt7KXl+0gQm9NrmWntQms9SYv/rQKAAq'
                    'icAABAGhuhpQNysfhEv88E1mI/qqSgHov33E6L9C/DjP/z5n/8G49NUHerHQAAON'
                    'hqB4C2ff33r9ohoH03IvKddhDZtPT0fyZerR5a2EvL96FVRSHB2gXW2glVEwAgCM'
                    'kJAACksROqJiA3k4fljhMYTbBwuiywjYTz2LRJCg/CIXouj9oBAICDrXYAABCp1w'
                    '6gCKuH0YZ4JSm0wGqSAq0epjyIyMdcoQBA60hOAAAg3kaomoCSTB6WO05gNMFicR'
                    'mLyRUvSQoneo9Z4OdOOwAAAIDG7UTknXYQxVg9jDbG6WC7pb20eh8kKRzrs8cBAA'
                    '0jOQEAgHg7oWoCSjN7WO44gdEECxOtHryTMV4u4umNvO61AwAAB1vtANAuWjogs4'
                    '2s9cCvpYP1jGj1YESCuKpp9TC93mfhczcARHmjHQAAAJXbCFUToGk8yHb9kF5i/H'
                    'D+GxcmsBi7iHSDw2XR+5Jw/EssXe+xAvzdawcAAA7W88QxgNbsZO1J/+Pf/30TuV'
                    'dkPNTuljaplb20eh8J4nJ+LTOs7b3e6Vp9oZUBoFlUTgAAIM73svYvUGBDzvYHvu'
                    'MnY1Fu9RCwN06X2YmbqgllPGgHAAAA0KCNkPT/C6tPzBvi3B6glb20Wklhfa0ePo'
                    'vIbaFVAaBZVE4AACBOrx0AcCLoiftS4xcmMFmNwCEsGxUgenNP0yx48z+q8qPIvf'
                    'BUMgD7rkTkTjkGAPCxF5L+T1l9Yt6YQYb1VFEQmXqK34a1VFIYSKICgBSq/EYQAA'
                    'AjboRDKlhk47B8ZrxDkoLB2BfDKt4y4wVVE8q5E5H32kEAwIKNdgAA4GErIh+0gz'
                    'CrpYP1TGj1YEiC5AmnhJNMay/4JImSP//7/8f/LcU0AFAt2joAABCu1w4AmFWo/U'
                    'H4+JkFLbZ66DxaPeTax+m5e48ZEOdROwAAAIDG9NoBVMFqWX9DvFo9tLCXVu+j3V'
                    'YPfbaZAWBlSE4AACDMjVA1AbUof1juOX5mAqMJFs5JCj7zho2nakJZt9oBAICDa+'
                    '0A0J6v//5VOwS06UqomuDH4mG0MV5JCi2weh9tJSn8oxxa/AEAEqCtAwAAYXrtAA'
                    'BvRtslOE2QrgVCmrmfxy9emn8fe8eRprz5T9V+DHnUDgAAAKAhe+0AqmS5rL8hTu'
                    '0BWtlLy/eRILaoVg+Ra4vIk/AdIAAkReUEAAD83QhVE1Aro+0SnCcwGnuWVg/L45'
                    '+Eqgml3WkHAAAONtoBAICDaxF5rx1E1ayW9TeEVg+GaFVRiF97LySpA0BS1T6yBA'
                    'CAop12AEC0EpURfL4AeDV+ZoLiVR3cxneDw2XR+3Ji7zGTLVa/MHPzICSoAbDtSj'
                    'sAAHDQawfQDMtPzRsxHmo7VVJoYR+tvicSVVE4TOE5SdjaD1Lz524AMIrKCQAA+L'
                    'kWke+0gwCSCXmiP+fcvlUUcsfj46iKwuylaeJ+Er4k0XKvHQAAACV9/etX7RDQnh'
                    'uhakJ6dScAF+H09L3l6gO+rN5Hgj0OrqTgt3YvVE0AgORITgAAwE+vHQCQhdF2CU'
                    '4TGE2wyJyksBe+JNFypx0AACzYaAcAAAt67QCa1dLBeka0ejAiQVxRrR7mL30Q2i'
                    'gCQBYkJwAA4O5aeLoDLSuedOAw3mcCa7EfJSkknpuqCboetQMAgAVU+QJg2Y3QIi'
                    's/ywfSRjg/ed/KXlq9D80qCuP603ZhEwIAlpCcAACAu147AKAIS+0SJudWbvUQcK'
                    '9Ol7nPuxcOyDXdaQcAAABQqY2QZFuWxcNoY7ySFFpAkoLL2p9F5Ie4aAAAl7zRDg'
                    'AAgEpcC1UTsDad+H054DN+PIgPHr8wQfT8DuMD5l5cZjmOQ9UEnwQJY95sqv8I8q'
                    'gdAAA42IrIvXIMAHBuJyJvtYNYnfGzRcWfIUoYD7W7uY1qaS8HsXkfCfbY6bWcX7'
                    'sPXx0AsITKCQAAuOm1AwBUWKxE0M3+xuvxPuy3etgLh+PabrUDAAAHW+0A0Iavf/'
                    '2qHQLasRHKpOuy+sS8MbR6MCJBXIGtHj4Ln/kAIKvqH1sCAKCAa6FqAtauRCUC3/'
                    'HD+W9cmMBi7CLSDQ6Xnc59qJoAC56Ep/4AAAB89MLfn2xo6en/TJyfvG9lL63eh0'
                    '4VhRuzCRsA0AgqJwAAsOxGOwDAjJBqAb7zR8WyUEXBWhUI18sOA/ZC1QQr7rQDAI'
                    'AFV9oBAMCRrYj8QTsInOEAdtHw/H8OA9tgtZJCgrgcX8tPQlssAMiO5AQAAOZtRe'
                    'SDdhCAOdYO+X1bPRhMsFgMq5P9y6Ca/2nDvXYAALBgox0AABzptQPABVYPo41ZVa'
                    'sHEbv3kT9JoY+bHQDgguQEAADm9doBAGZZrETgm6RQLBb38Rcu+yRUTbDkXjsAAA'
                    'By+/rXr9ohoA1bIeHfvpYO1jPxqqLQwl5avo8EcU28lv8gfM4DgCLeaAcAAIBhW+'
                    'FLFGDZeJru+gVByHifLx9ejZ9ZsETsAeO74dVlveMMpv367a/dvtCz7047AABYcK'
                    '0dAAA8+6gdADyMf1Vvp+JZcuPnmW5pk1rZS6v3kSCuo9fySQ5tFAEABVA5AQCAy3'
                    'rtAICq5GyXkKRyQeJWDwVaQzwvQ99Lex61AwAAAKjAtYi81w4CAZrIJ87Lq5JCC6'
                    'zeR5pWD3vhMx4AFEPlBAAApm2FqglAGJ9KB8UrFyxMkLOqQ3jsvbWHVEDlBADmbb'
                    'QDAAAh4b9uVp+YN2aQgSoKFoTH9iAi+0Yq/AFAFUhOAABgWq8dAFA1i+0SXFs9TI'
                    '5PHIv7eKom2PTId1cAjPtOOwDU7dtP37RDQP2+F6omtMHygbQRtHowZBDfuHqhag'
                    'IAFEVyAgAAr22FqglAGsWTDnznnpnARoJFb/ILn1BtHeh/Fr5wBwAAuGSvHQASs3'
                    'wgbYRXkkIL+2j1PeEe14OIfMwZCgDgtV9pBwAAgEE32gEAzenE7wsL37FR4xcmiJ'
                    '7fYfw0qibY9qgdAAAs2GgHAGC1bkTknXYQyKSthOMshuf/WxjUzl5avY/lPd4ViQ'
                    'MAcILkBAAATm2EDydAPkWTDnzHZ0hSCI5FRBprL/Or//hr7RBSu9MOAAAWXGkHAG'
                    'CVNtLY32MxoaWD9YwWExQOg9rYS8v3MR3XZxH5oWgcAAARITkBAIBzOxF5qx0E0L'
                    'TiSQcO430mKBM7VRPsu9cOAAAAwKCdUDVhPSwfSBvhVEXhMLCNvbR6H6/j6lXiAA'
                    'DIG+0AAAAwZCNUTQDKGQ/tXb+4CBkfNffMBPlj7x1HQs+9dgAAsGCrHQDq9O2nb9'
                    'ohoF4b4TP1Og3il5S9QmOCQre0Ua3s5fjZ19q9HOL6LJ3c6gYCAOtFcgIAAL/YCV'
                    'UTgPJ8kgh8x0cnESxMkCdJ4bNw8F2DO+0AAGDBVjsAAKuzEz5Tr5fVw2hjnJIUWt'
                    'pLm8kWNyarOwDAStDWAQCAg43whAegx2Krh272N16P9zE/vvecDToetQMAAAAwZC'
                    'sif9QOAgZYLetvDK0e1NBCEQCUkZwAAMDBTnjCA9BnMUnBdYI0sXwWobxkRT5rBw'
                    'AAM660AwCwKr12ADDG1oG0ScPz/zkMbGMv9e/jSfhvFQCoIzkBAICDG+0AAByJTi'
                    'JIOH4yloUqCuHz9x5XVuNXf/9r7RAAYI022gGgPt9++qYdAuq0FZEP2kHAqBYO1T'
                    'PzSlJogV6Swl6omgAA6khOAADgkJjwTjsIABOsVVHwbfXgNz9VE+pzqx0AAACAAR'
                    '+1A4Bx+k/MV2FVVRRESt/HkxySEwAAyt5oBwAAgAG9dgAAZowH/K5fXBQfvzBB5z'
                    'x3710BAtoetQMAgBnvtQMAsArXwn9v4Gr8XMTnnovGBIVuaZNa2cty97EXPr8BgA'
                    'lUTgAArN2NUDUBqEOJygg+0rZ6oGpCne60AwAAAFDWaweACrX09H8mtHpI6kH4bx'
                    'UAmEFyAgBg7XrtAAB4ypl0oNfqofdYtSq/+rtfa4eQ0712AAAAAIquhaoJiNHKwX'
                    'pGTkkKLSV75LmPPsusAIAgJCcAANbsRqiaANSraNKB73ivJAWqJtTrXjsAAFhwrR'
                    '0AgKZ91A4ADWjpYD0j5yoKLexl2vt4EP5bBQCmvNEOAAAARb12AAAijQf8rl9clB'
                    'g/nP/GzASH8b3j7HVq4cuxeT+KyHfaQQAAEOvbz9+0Q0BdboRkf6Q0fm7wbbe3Im'
                    'OCQre0Sa3sZZr7uImOAwCQFJUTAABrdSN8kQK0o0RlhKi5L07wIFRNqN2jdgAAMG'
                    'OjHQCAZvXaAaBRrTz9n5FTq4fDwDaEvyeoUggABpGcAABYqxvtAABk4PtEhX6rh/'
                    '7lt1v9p3232gEAwIwr7QAANKkXkv2RWysH6xk5JSm0lOzhfx99+iAAALFITgAArN'
                    'G1iLzXDgJAJiWqKKRJUqD3JQAAMIGWDvCwEZGdcgxYi5YO1jNyrqLQwl6638efhE'
                    'RyADCJ5AQAwBr12gEAKMBiksLpb/T6ZQ3y/vOr3/3aY4OqdasdAADM2GoHAKA5Ox'
                    'F5qx0EVqaVg/WMvFo9tLCXy/exKxIHAMAbyQkAgLW5FqomAOtSPOnAaW6qJrTjUT'
                    'sAAJix1Q4AQFO2woEfNLVwqJ6ZV5JCC6aTFD6JyH3pUAAAbt5oBwAAQGG9dgAAlH'
                    'Ti9wWMz/gxQcF9fO8RCWy70w4AAACgkF6omgBt42cunyTxFRpkkG5pk1ray0HG+3'
                    'gSvvsDANOonAAAWJNroWoCsG42Wj1QNaE9D9oBAMAFV9oBwL5vP3/TDgF12IrIB+'
                    '0ggBettCfIaKWtHvZC1QQAMI3KCQCANem1AwBghH+lg5Tje8dZUI97EXmnHQQATO'
                    'AJZwCp7LUDACa19PR/JmOCwgoqKTyJyL6JRAsAaBiVEwAAa3ElVE0AcC6kMoLv/K'
                    'eomtCmO+0AAAAAMroWkd9rBwHM4kB6kVclhTrtReRROQYAwAKSEwAAa7HTDgCAYe'
                    'VaPfQeV1btV79d1UeNR+0AAGDGtXYAAKrXawcAOGmlPUFmjbZ6eBD+WwUAVVjVN4'
                    'YAgNXaCr0xASyJSzpwGf8knfzwcl3r/6zLrXYAAAAAmVwLVQhRm/oO1ovzqqJQx1'
                    '722gEAANyQnAAAWINeOwAAFcmXpLAXnrAHAABAXfbaAQDB6jlYV9NIqwfaJwJARU'
                    'hOAAC0bitUTQAQIiRJ4bIn4Yvdlt1qBwAAM661A4Bd337+ph0CbLsRke+0gwCi2T'
                    '5YN8EpScFusseNdgAAAHckJwAAWtdrBwCgcmmqKOyFqgmte9IOAAAAILFeOwAgGb'
                    'sH66ZU2Orhs5AsDgBVITkBANCyrVA1AUAKca0eqJqwDnfaAQDABRvtAABUaSci77'
                    'SDAJKzdbBuklerB/297LUDAAD4eaMdAACc8Dn4AZYMfEABkNj4v1OuX8Acxu9loG'
                    'rCCtyLyHvtIABgwpV2ALCJlg6YsREO/NC6QfgecsGYoNAtbZTeXn4SqiYAQHVITg'
                    'AAtGojIt8rxwCgVZ24Jigcqias7EuvX/3mVxaeoCntXjsAAACARHYi8lY7CCC78T'
                    'PLyj6v+XJKUtDZy77oagCAJGjrAABo1U46ecsHTADZuLV62ItQNWEl7rQDAIALtt'
                    'oBAKjKRg7JCcB62GhPYJ6xVg+fhARxAKgSyQkAgBZt5PjLFN9e8QDg4/J/Yw5VE7'
                    'AWj9oBAMAF9IwH4GMvVE3AWpGksGh4/j+HgTn38klIogKAapGcAABo0U6mvkwhSQ'
                    'FATq//G7MXDqzX5FY7AAAAgEhbEfmgHQSgjgSFRV5JCunthc/aAFAtkhMAAK3ZyF'
                    'L2NAkKAHL65b8xH/WCgJIn7QAA4IIr7QAAVKHXDgAwgyoKThSqKFChEAAqR3ICAK'
                    'A1O3EpQUkVBQA5dfS/XKk77QAA4IKNdgCw5duXb9ohwJ5roWoC8BpJCosKt3roha'
                    'oJAFC1N9oBAACQ0EZ8e86NCQp80ASQVr/WBKhfvVl1/vOjdgAAAACBeu0AANPG74'
                    '1W+jnPxZig0C1tUvhePghVEwCgeqv+5hAA0JwbcamaMIVKCgDSoWrCet1pBwAAF1'
                    'xpBwDAtGsRea8dBFAFHm5Z5FVJwU/vHw0AwBqSEwAALdlFz0CCAoB4vXYAUHOvHQ'
                    'AAXLDRDgCAaXvtAICq0OrBSeJWDz+KyMeYeAAANtDWAQDQihsReZdkJlo9AAi3+q'
                    'oJTl9AteteOwAAAJYMX1b9v9V47UZEvtMOAqgSrR4WJWz1sEsTEQBAG5UTAACt6J'
                    'PPSKsHAP567QA0dW9W/x/NO+0AAOCCa+0AAJjVawcAVI9KCosiWz18FpHbpAEBAN'
                    'SQnAAAaMGNpKqaMGX1Z20AHK2+agLkUTsAAAAADzeS87M0sDYkKCxySlJ4nezRZw'
                    'sIAFAcyQkAgBb02VegigKAZb12ADDhs3YAADBhox0AbKClA45sRGSvHAPQHqooOH'
                    'GuojDIJ6FqAgA05Y12AAAARLqRkk96jAkKfNAEcIqqCRg9agcAABPoJw/g3E5E3m'
                    'oHATRr/N6IB10uGhMUuvlN6vkODgDaQuUEAEDtepVVqaQA4NReOwCYcacdAAAAwI'
                    'KNHJITAOTGwfqimVYPPAQAAA0iOQEAULPvRbs/JgkKAA5l/O+0g4AZj9oBAMAFW+'
                    '0AAJjRC1UTgHJo9eDkLEnhSUiiAoAmkZwAAKjZTjsAEaGKAoBeOwALujf8h/DZnX'
                    'YAAHDBVjsAACZsReQP2kEAq0SSgpPnBIW9kPgNAE16ox0AAACBrkXkvXYQJ8ZzOT'
                    '5oAmvyWURutYOAKffaAQAAAMzotQMAVm/83oj87kueBhn22kEAAPKgcgIAoFa9dg'
                    'AXUUkBWJNeOwCYc68dAABccKUdAHQNX8iihlyJyAftIAA84z/Ll+yEqgkA0CwqJw'
                    'AAanQt1qomTOmED5pA26iacIz/3h37UUS+0w4CAM5stAMAoG6vHQCAM1RROPcgIh'
                    '+1gwAA5EPlBABAjXrtAJxRRQFoWa8dAMx61A4AAADgzLXUkOQPrNUgJHwf9NoBAA'
                    'DyIjkBAFCba6nxCxWSFIDWUDUBc261AwCACVfaAQBQ1WsHAMDBupMUPgtVEwCgeS'
                    'QnAABqs9MOIApJCkAreu0ALOl+zX/YzjxqBwAAEzbaAUDP8HW9J10QEZEbqTHJH1'
                    'izdf5nu9cOAACQH8kJAICabEXk99pBJME5HlAzqiZgyZ12AAAAAEd67QAABFhXFQ'
                    'U+ZwPASpCcAACoSa8dQFJUUQBqtdcOAObdawcAABN4ahpYpxsReacdBIAI60hS2G'
                    'kHAAAog+QEAEAttiLyQTuILEhSAGryICI/aAcB8+61AwAAAJBDO5e9cgwAUmk3Se'
                    'GTUH0OAFaD5AQAQC167QCyI0EBqEGvHQCq8aAdAABM2GgHAKConYi81Q4CQGLtJS'
                    'j02gEAAMohOQEAUIOttFo14RxVFADLHkTko3YQqMa9dgAAMOFKOwCUN3xt7xQLTj'
                    'ZCmXSgXe1UUfhH4bMTAKwKyQkAgBr02gEUR5ICYFGvHYBF3a/5j9UFd9oBAACAVd'
                    'sJVROA9tWdpPAkfM4GgNUhOQEAYN1W1lI1YQpJCoAVVE2Ar0ftAABgwlY7AABFbE'
                    'Xkj9pBACiozgSFvfC5CQBWh+QEAIB1O+0ATCBBAdDWaweA6txqBwAAE7baAQAoot'
                    'cOAICCuqooPMkhOQEAsDIkJwAALNuIyI1yDHZQRQHQQtUEhHjUDgAAgOFrPadUSG'
                    'Yra64+CKCWJIWd8JkJAFaJ5AQAgGU7oUfmayQpAKX12gGgSnfaAQDAhK12AACy+6'
                    'gdAAAj7CYp8AAAAKwYyQkAAKs2QkuHeSQpACXwpQliPGgHAABnttoBAMjqWkTeaw'
                    'cBwBh7CQq9dgAAAD0kJwAArNoJVRPckKAA5NRrB2BZ92v+A7TgXjsAAACwKr12AA'
                    'CMslNF4bPwAAAArBrJCQAAizZC1QQ/VFEAcngSkR+0g0DV7rUDAIAzV9oBoJzhq4'
                    '1TKBTzvVA1AcAS/SSFXnV1AIA6khMAABbthKoJYUhSAFLai8ijcgyo2712AABwhr'
                    '9jA+3aawcAoCI6SQqfReS2+KoAAFNITgAAWLMRqibEI0EBiPUkfMGLeHfaAQAAgF'
                    'W4EZF32kEAqFDZBIVd0dUAACaRnAAAsOZ74YmuNKiiAMTYC1UTEO9ROwAAmHCtHQ'
                    'CApDZCmXQAMcpUUfgkJG8DAITkBACAPb12AM0hSQHwRdUEpHKrHQAAAGjeTqiaAC'
                    'CFvEkKfbaZAQBVeaMdAAAAR26EL1XyGRMUyvcUBGqzF554d8N/T1w8CRWBANiy0Q'
                    '4A+Q3f+B/pldgIZdIBpDZI6odc/kFE7pPOCACoFpUTAACW9NoBrAJVFIA5VE1w1P'
                    '2K/5g4utMOAADOXGkHACCZnZAECSCHdFUU+IwNADhBcgIAwIoboWpCObR6AC7ZC1'
                    'UTkNa9dgAAAKBJW6FqAoDc4pMU9sJnbADAEZITAABW9NoBrBJJCsAxnuhADvfaAQ'
                    'DAma12AACS6IWqCQBKCUtSeBA+YwMAzpCcAACw4EaomqCLJAVAROSj8EQH0rvXDg'
                    'AAzmy1A0Bew7c0dbhh2lZEPmgHAWCF/P4nphc+YwMAzpCcAACwoNcOAM9IUMC67b'
                    'UDqEX3K/5j4eFeOwAAANCcvXYAAFbMrYrCgxweAAAA4ATJCQAAbddC1QRbqKKAdf'
                    'okHCIjjzvtAADgzFY7AABRrkXk99pBAMBCksKuWBwAgKq80Q4AAI51nIiuziBDrx'
                    '0DLhj/OFIVFuvQaweAZj1qBwAAZ0gMBurWawcAACfG741++Vr3s4j8oBEKAMA+Ki'
                    'cAADRdd9K91w4CC6ikgPZRNQG5fdYOAAAANOFaRPgMDcCmXx5u6fWCAABYR3ICAE'
                    'BTL3KomEHVjArwEqFdvXYAaN6jdgAAcOZKOwAAQT5qBwAAswb5LCK32mEAAOwiOQ'
                    'EAoOVazp74IEmhAlRRQHuomoAS7rQDAIAzG+0AkMfwjZ5sDbsR2rIAsO9GBhH+mf'
                    'kHAFaO5AQAgJb+0g9IUKgASQpoR68dQG26X/GHP8C9dgAAAKB6vXYAALCA5H8AwC'
                    'KSEwAAGq5loU8mVRQqwUuEuvHFCUq51w4AAM5cawcAwEsvVE0AYF+vHQAAwL432g'
                    'EAwAkOOtdhkBvXoWOCwkDdM7vGP7e8RKhPrx0AVuNOOwAAQPto6dCsjYjslGMAgC'
                    'X/ICRlAwAckJwAAChtKyIffC/qpCNBwTqSFFAXqiagpEftAADgzEY7AGTA38Pb1M'
                    'lORN5qhwEAM55EZK8dBACgDrR1AACU1ksnQVUyaPVQicDXFyjso3YAWJ0ftQMAgC'
                    'NX2gEAcLIVqiYAsG8vJGQDAByRnAAAKGkrx1UTSFJoGy8R7PosIrfaQWB1HrUDAA'
                    'AA1ellkLdUxQBg2INQNQEA4IHkBABASf3k7wYeYpOkUAGqKMCmXjuAWnW/4g90hF'
                    'vtAADgyEY7AKQ1fOX0ukFbOU7uH4TWHQAs6oVEbACAB5ITAAClbOX4i5VzEYfYJC'
                    'hUgCQF2EHVBGh51A4AAI58px0AgEX95O+SpADAjgehZSIAwBPJCQCAUnqnUbR6aB'
                    'tJCtDXaweA1brTDgAAAFTjWuaS+0VIUABgwU47AABAfUhOAACUsJWlL1bO0eqhbb'
                    'xE0EHVBGi61w4AAM5stQMAcFHvNIoqCgD0fBaRH7SDAADUh+QEAEAJN0FXRbZ6IE'
                    'nBOKoooLxeOwCs2r12AABwZqsdAIBJ1yLy3usKkhQAlNdrBwAAqBPJCQCA3DYSW+'
                    'YtMkkBxpGkgDKomgALftQOAAAAmLcPvpIkBQBl/En4fA0ACERyAgAgt52IvE0yU+'
                    'AhNlUUKkGSAvLqtQOoXfcr/oAm8KgdAAAcudIOAGkMXzmNbsiNiHwXPQtvCQB57b'
                    'QDAADUi+QEAEBOG8nxgYVWD23jJUJ6VE2AFXfaAQDAkY12AABe6ZPNRBUFAHl8El'
                    'rWAQAikJwAAMhpJ6mqJpyj1UPbqKKAtD5qBwA8e9QOAAAAmLUTkXfJZyVJAUA6T0'
                    'JVQgBAJJITAAC5bKREmTdaPbSNJAXEexCSE2DHrXYAAHDkWjsAxKOlQzM2kvvAj7'
                    'cKgHh7oWoCACDSG+0AAADN2kmuqglTxgNszy9cxgSFgW9qbOuEL9MQqtcOoAVd1/'
                    'FnMI1H7QAAAIBJOynx+Xn8+xwJ4AD8PckhOQEAgChUTgAA5LJTWTWi1QOVFIyjig'
                    'L8UTUB1txpBwAARzbaAQAQkVJVB4/R6gGAv72QbA0ASIDkBABADjdSsmrCuYhDbB'
                    'IUKkCSAtz12gEAEx60AwCAZ99pBwBARA4Hfjqfn0lSAODmQfh8DQBIhOQEAEAOvX'
                    'YAIhJ8iE0VhUqQpIB5VE2AVffaAQAAADO2IvJBOwgSFAAs6LUDAAC0g+QEAEBqNy'
                    'LyTjuIEyQptI2XCNN67QCAC+60AwCAIxvtAICV67UDeEEVBQDTSPwHACT1RjsAAE'
                    'Bzeu0ALuok6MuWMUFh4Jsau8YEBV4iHPDlSWL89y+pR+0AAODIlYjcKseAUN+0A0'
                    'CkK7FQNeHc+Nc+ksABHNxoBwAAaAuVEwAAKd2ItaoJ5yJaAVBFoQK0esBBrx1AU/'
                    'gzldqtdgAAAMCEvXYAs6ikAEDks/D5BQCQGMkJAICUeu0AnNHqoW0kKawZVRMAAH'
                    'C31Q4AWKlrEXmvHYQTEhSANeu1AwAAtIfkBABAKjdivWrClIgqCiQpVICXaI322g'
                    'EAC261AwCAI1vtAICV6rUD8EIVBWCN/iR8dgEAZEByAgAglRvtAIJFtnogScE4qi'
                    'isyZNQNQF1eNIOAABQuW/aASDCjdRSNeEcSQrAmuy0AwAAtInkBABACtdS65crxy'
                    'KTFGAcSQprsBeRR+UYABd32gEAwLMr7QCAFeq1A4hGkgLQuk8icq8dBACgTSQnAA'
                    'BS6LUDSCrwEJsqCpUgSaFVT0JLB9TjXjsAAHi20Q4AWJkbqbEd4iUkKAAtepLWvu'
                    'cDAJhCcgIAINa1tFA1YQqtHtrGS9SavVA1AfW41w4AAFAxWjrUaiMtJtNSRQFozV'
                    '74vAIAyIjkBABArF47gKxo9dA2qii0gqoJufDnI5c77QAA4FmbScaATTsReasdRD'
                    'YkKQAt4LM1ACA7khMAADGuZS1faNLqoW0kKdRuL1RNQF0etQMAAABFbeSQnNA+Eh'
                    'SAmvXCZxUAQGYkJwAAYvTaARRHkkLbeIlqxJMdqNGtdgAAAKCoXlqumnCOKgpAjR'
                    '6Ez9YAgAJITgAAhLqStVRNmBLR6oEkBeOoolCbvfBkBwAAMa61AwAatxWRP2gHoY'
                    'IkBaAmvXYAAIB1IDkBABBqpx2AuohDbBIUKkCSQg2omoCafdYOAAAAFNFrB6COJA'
                    'XAuh9F5KN2EACAdSA5AQAQYisiH7SDMINWD20jScGyj0LVBNTrUTsAAHi20Q4AHr'
                    '5pBwBPV8Jn51+QoABYtdMOAACwHiQnALCl458q/uHJj2kkKbSNl8iivXYATeM9n9'
                    'uddgAA8OxKOwCgYXvtAMyhigJgzWcRudUOAgCwHiQnAAB8baWTDxxazYho9UCSgn'
                    'FUUbDkk4jcawcBRLjXDgAAAGR1LSLvtYMwiyQFwIpeOwAAwLqQnAAA8NW//BuHtJ'
                    'dFHGKToFABkhQs6LUDACLdawcAAM+22gEAjeq1A6gCSQqApk9C1QQAQGEkJwAAfG'
                    'zlvF8mh7TzaPXQNt7/WqiagBbcaQcAAM+22gHA0TftAODhe6Fqgh8SFAANvXYAAI'
                    'D1ITkBAOCjv/gTDmnn0eqhbbxEpfXaAQAJPGoHAAAAstlrB1AlqigAJZH0DwBQQX'
                    'ICAMDVRs6rJkzhkPayyFYPJCkYR4JOKXyBgpZ81g4AAETkSjsAoDE3IvJOO4iqka'
                    'QA5PYkIjvtIAAA60RyAgDA1c55JIe08yKTFGAc7//ceu0AVoH3MACsyVvtAOCAlg'
                    '612Ah/X02HBAUgl71QyQ0AoOSNdgAAgCpsJCSjejzc4guFaYH7MyYoDGysbZ3w3k'
                    '+Pqgloza3QjxoA4IK/V9ZiJyLvSPRMaHzvs6dAKk9C6xkAgCIqJwAAXOwk5okqni'
                    'SfR6uHdvHeT63XDgBI7FE7AAB4dq0dANCAjYxJ/bQlSI89BVLphc8hAABFJCcAAJ'
                    'ZsJFUfOg5pL6PVQ9tIUkiBqglo0Z12AAAAIJmdnCf1c6CeHnsKxHgQqiYAAJSRnA'
                    'AAWLKTlH1oOaSdF7g/VFGoBO//GB+1A1gN3qMl3WsHAAAAktiKyB8v/pTD9PTYUy'
                    'BErx0AAAAkJwAA5mwkVdWEcxzSziNJoW28RL4+i8itdhBABvfaAQDAs2vtAIDK9Y'
                    'sjeOI/PfYU8PGjkPQPADCA5AQAwJwbSVk1YQpJCvMiWj2QpGAc730fvXYAQEY/ag'
                    'cAADDuq3YAWLAVkQ/OozlQT489BVzstAMAAECE5AQAwLxdsZU4pL0s4hCbBIUKkK'
                    'SwhKoJaN2jdgAAIIeKaQDCfAy6isP09EhSAC7hczUAwAySEwAAl9yIyLuiK3JIO4'
                    '9WD23j/X9Jrx0AkNmtdgAAICJX2gEAlboWkffBV3OYngd7CpzrtQMAAGBEcgIA4J'
                    'JebWUOaefR6qFtvETHeLoDa/CoHQAAAAjWJ5mFJIX02FNg9En4XA0AMITkBADAlB'
                    'spXTVhCoe0l0W2eiBJwTgSdEa9dgCrw/tOw512AAAgIlvtAHDBV+0AMON7iamaMI'
                    'UD9fTYU6DXDgAAgGMkJwAApvTaAbzgkHZeZJICjFv3+5+qCViLR+0AAEAsJCYD9d'
                    'lnm5nD9PRIUsA6/aOI3GsHAQDAMZITAADnbsTil5PrPqRdFrg/VFGoxDrf/712AE'
                    'Ahd9oBAAAAbzeS+3Mzh+l5sKdYjyfhczUAwCCSEwAA53rtAGat85DWHa0e2rael+'
                    'hHoWoC1uVBOwAAEJEr7QCAivTFViJJIT32FOuwF6q0AQAMeqMdAADAlO/FYtWEKZ'
                    '3wZcIl4wF2wP6MCQoDm2tXxOtbkb12AKvV9vvKsnup5X9/AbRsox0AUIleNP53e/'
                    'x72noSlvNjT9GuJ+FzNQDAKConAACO7bQD8EIVhXkR+0MVhQq0+/5/EJGP2kEAhd'
                    '1pBwAAMOibdgCYsBHtz80kk6bHnqI9O6FqAgDAKJITAACjaxF5rx1EkHYPadMI3B'
                    '9aPVSivZeo1w4AUPCoHQAACG0dABc7EXmrHQRtCTJgT9EOEv4BAKaRnAAAGPXaAU'
                    'QjSWFeRBUFkhSMa+e9z5coWKtb7QAAQGjrACzZinbVhHMcqKfHnqJ+vXYAAADMIT'
                    'kBACBSc9WEKW0c0uZBq4e21Z+k0GsHACh51A4AAAAs6sVC1YQpHKanR5IC6vRZSP'
                    'gHABj3RjsAADhR96FazfrmPnSP76XW7iuVwP0ZExQGNta2Ot//VE3Amt1pBwAAck'
                    'hYhhXftAPAma2IfNAOYtb4d3++V0lrEPYUNem1AwAAYAmVEwAA1yLyvoEnrqe1el'
                    '+pBO4PrR4qUddL1GsHACh70g4AAABctNcOwBlP/KfHnqIOn4V2cQCACpCcAADoT3'
                    '7V6mF+q/eVSkSrB5IUjKvjvU/VBIDqCQD0bbQDAIy6FpHfawfhjQP19NhT2LbTDg'
                    'AAABckJwDAum1F5P3kT+wfZoZp9b5SiDjEJkGhAraTFHrtAAAD7rUDALB632kHAB'
                    'jVawcQhcP09EhSgD2fhGRnAEAlSE4AgHXrZ39q+zAzXKv3lQqtHtpm7/1P1QTg4F'
                    '47AAAA8Mq1XErorwmH6Xmwp7Cj1w4AAABXJCcAwHptReSD00h7h5lptHpfqdDqoW'
                    '12XqKP2gEARtxpBwAAcviMAOAXH7UDSIokhfTYU+j7RyHRGQBQEZITAGC9eu8r7B'
                    'xmptXqfaUQ2eqBJAXj9BN0nkRkrxoBYMejdgAAICQn2PBNOwA8uxGRd9pBZMGBen'
                    'rsKXQ8CVUTAACVeaMdAABAxVZcqyacGw8yW/vQ3ep9pRKxP510MrCxtum9//fCgS'
                    'wwutUOAABgBH91tqJvPtd6EO1k5faMf37ZV5SxFz5TAwAqQ+UEAFinPnoG/Seu82'
                    'j1vlIJ3B+qKFSi7PufqgnAa0/aAQBYvSvtAAAjdiLybhVPw6/hHjWwp8iPz9QAgC'
                    'qRnAAA67OV0KoJU1o9zG/1vlKh1UPbyrxEe+EJD+DcnXYAAFZvox3A6n3VDgBy+H'
                    'PQn/zOGg6aSVJIjz1FXjvhMzUAoEK0dQBgCoeW+Q0y7LJM3EmbH7pbva8UaPXQtr'
                    'ytHnjCA5h2LyLvtYMAAGDldiLy9tXvrqVc/1rusyT2FOk9iMhH7SAAAAhB5QQAWJ'
                    'dNJ91NttlbrTbQ6n2lQquHtuV5/++FJzyAKffaAQBYvSvtAABlGzkkJ1y2lqfh13'
                    'CPpbGnSKfXDgAAgFAkJwDAuuxE5G32A+FWD/Nbva9USFJoW7qXiKoJwGX32gEAWL'
                    '2NdgCAsr1MVU2YsoaD5rUkYpTEniLeZ6FqAgCgYiQnAMB6bOToCZAiB8KtHua3el'
                    '+pBO4NSQoVSPPe3wtVE4BL7rUDAAAo+qodwOptReSD1xVrOWhey32WxJ4iXK8dAA'
                    'AAMUhOAID12MnEEyDFkhRa1Op9pRBxiE2CQgXCX1+qJgDz7rQDALB677UDABT1wV'
                    'eu5aB5DfdY2lreO0jls4jcagcBAEAMkhMAYB02stA3M3uSQqvVBlq9r1Ro9dA2/9'
                    'f3B6FqAjDnUTsAAABW6lp8qyZMWcNB8xruUQN7Cjc32gEAABCL5AQAWIedOPbNpN'
                    'VDoFbvKxWSFNrm/hL1+YIAmvFZOwAAq7fRDgBQ0CedbQ0HzSQppMeeYt4noQ0cAK'
                    'ABJCcAQPs2slA14VyxVg8tnjm3el+pRLR6IEnBuOX3Pl+kAG4etQMAsHpX2gEAhV'
                    '1LjpYmazloXst9lsSeYlqvHQAAACmQnAAA7fteHKsmnCuWpNCiVu8rhYgEDhIUKn'
                    'D59e2LxgHU6047AAAAVmafdfa1HDSv4R5LW8t7By7+QUj2BwA04o12AABwgnPH9I'
                    'b4A8FOOhlyfiIeX/fWPnS3el+pBO7PmKCQ9T2JeKevL1UTAHf32gEAWL2tdgCr9F'
                    'U7gNW6EZHviqw0fnxp+XuPNdyjhkHY03V7ktxJVAAAFETlBABo242IvEsxEa0eIr'
                    'R6X6nQ6qFth5eo1w0CqMq9dgAAVm+rHQBQUF98xTXkWPPEf3rs6ZrthdZvAICGkJ'
                    'wAAG3rUx+M0+ohQqv3lUJkqweSFEyjagLg5147AAAAVmIniZL5va3loHkt91kSe7'
                    'o2D0LVBABAY2jrAADtupHjL1o6SfoBNntp/VZbIrR6X6lE7E/29iMI1ZM7YhR/XK'
                    'y61w4AwOpttQNYHVo6aNiIhepea2mDQFuC9Nby3kEvVE0AADSGygkA0K7+1e9kaC'
                    '9Aq4dArd5XKoH7QxUFc6iaAIT5UTsAAKu21Q4AKGAnIm+1g3ixhqfh13CPGtjTlj'
                    '2IyEftIAAASI3kBABo043MlaestdVDi2fOrd5XKrR6qF2vHQBQqUftAAAAaNhGDs'
                    'kJ9qzhoJkkhfTY01bttAMAACAHkhMAoE2906hakxRa1Op9pRDxPiVBQdWfhKoJQK'
                    'hb7QAArNqVdgBAZr1Yqppwbi0HzWu5z5LY05Z8FpEftIMAACAHkhMAoD3XMlc1YU'
                    'qGVg9ZD4VbrTbQ6n2lQquH2uy1A8AMvrS07lE7AACrZvfQtkVftQNYna2I/EE7CC'
                    'drOWhewz2Wxp62oNcOAACAXN5oBwAASK4Pumo8u034IbaTToacn4ozxGxCq/eVSu'
                    'D+jAkKWd+TGH0WnvwGYtxpBwAAKIS/mpbWV5e3PEj7Sezjn4PW77Mk9rRmfJ4GAD'
                    'SNygkA0JZrEXkfNUOtrR5a/MDd6n2lEtHqgUoK2fXaAQCVu9cOAMDqXWsHAGRwJS'
                    'IfqkwIWVMVhTXcZ0nsaY1utAMAACAnkhMAoC19splqTVJoUav3lULE+5QEhWx4yg'
                    'OId68dAAAADdq//FutB7a1xu1rDfdY2lreO/X7JHwWAAA0juQEAGjHtcRWTZiS+P'
                    'w2e5JCq9UGWr2vVAL3hyoKWfTaAQCNeNAOAMCqbbQDABK7lqnPy7Ue2NYat4813K'
                    'MG9tS6XjsAAAByIzkBANrRZ5s5w8E4rR4CtXpfqZCkoI2qCUA699oBAFi1K+0AgM'
                    'T62Z/WehBeY8y+an1tLGNPrfoH4TMAAGAFSE4AgDZcS46qCedo9WAHSQrzIlo9kK'
                    'QQpdcOAA74IrIWd9oBAAAy+6IdwGrciOvn5Rr/nrSWg+a13GdJ7KklT3LcegYAgI'
                    'a90Q4AAJDETdHVOkn6AXY8DB5yfSoez5pb/NCd+LVoSsTr3kmX7/3YLqomAGk9ag'
                    'cAYNW22gGsA3/fLKPrvYaPL0ttOcu1xu1rkPbvsbS1vHds2wt//wcArASVEwCgfl'
                    'sR+VB8VVo92NHqfaVCq4dSeu0AgMbcagcAYNW22gEAidyIDO+Crqz1qfJa4/axhn'
                    'vUwJ5qeRA+TwMAVoTkBACoX6+6eq2tHlo8c271vlKh1UNOPwoHqUBqj9oBAAAy+s'
                    'IpYAEbeSmTHrHftR6E1xizr1pfG8vYUw29dgAAAJREcgIA1G0rGlUTptSapNCiVu'
                    '8rhYj3KUkKs/baAQANutMOAMCqbbUDABLYicjbX34Zeepa44HtWg6a13KfJbGnpT'
                    'yIyEftIAAAKOmNdgAAcIJzPz+DwezqTpJ+gB0Pg4dcn4rH91xrH7pbva9UIvanky'
                    '7f+7FOfJkC5PMgImGlqAEgDv/tQe02ckhOmDD+XT7gC4iIS1XVGrevQdq/x9LY09'
                    'xutAMAAKA0KicAQL220hmpmnAuQ3sBWj0EavW+UgncH6oonOi1A4AH8mpqc68dAA'
                    'AAldrJSdWEKRGPhtf6VHmtcftYwz2Wxp7m8llojwgAWCGSEwCgXr2I2D58rrXVg9'
                    'X9jNHqfaVCq4dQVE0A8rrTDgDAql1pBwAE2orIH92HR7Z6qPHQtsaYfdX62ljGnq'
                    'bWawcAAIAGkhMAoE5bkbOqCZYPn2tNUmhRq/eVQsT7dMUJCr12AEDjHrUDALBqG+'
                    '0AgEC9/yWRp641Htiu5aB5LfdZEnuawp+EqgkAgJUiOQEA6nRz8SfWkxSSTpc5Sc'
                    'HyXsZo9b5SodWDK6omAPndaQcAAMjgC6d6GW3lPJHfC60emrWGeyyNPY2x0w4AAA'
                    'AtJCcAQH024vIhxuoZaYaDcVo9BGr1vlIhSWFJrx0APPHlYY0etQMAsGrX2gEAAT'
                    '6mmWalSQqtq/W1sYw9DfFJRO61gwAAQAvJCQBQn52IvHUaafnwudZWD1b3M0ar95'
                    'VKRKuHhpMUqJoAlHGrHQAAABW5FpH3aaek1UOT1nKfJbGnrp6ERH8AwMq90Q4AAO'
                    'BlIyGl38bzUYsfFBPHNh4GDzlvthObexmr1ftKIeJ92kmX9/2oo9cOAFiRJ3FNSg'
                    'SAtDbaATSrub8aGtHl+jvq+IIFJB5HXKqq1rh9DdL+PZa2lvdOuL1QNQEAsHJUTg'
                    'CAuuwk5oDC8ofDDK0esj613mq1gVbvKxVaPYhQNQEo7U47AACrdaUdQJN+JjMhk+'
                    '9lSF014dxKWz3UGLePNdyjBvZ0ypMckhMAAFg1khMAoB4bCamacM7y4XOG2Gj1EK'
                    'jV+0pl3a0ePmoHAKzMvXYAAABUYC8ihQ6aI1s91HhoW2PMvmp9bSxjT8/tReRROQ'
                    'YAANSRnAAA9dhJyrLOlg+fE8dW5EDY6l7GavW+Uoh4n1acpMCTHkB599oBAFitjX'
                    'YAgKMbEXl38jvZD0UjF6jxwHYtB81ruc+S2FORQwXCXjsIAAAsIDkBAOqxyzKr9S'
                    'SFpNPR6iFIq/eVSmSSQmX2wpMeQGl32gEAWK3vtANoDi0dctjI3IGf5SSFWg9sa4'
                    '3b1xrusbS1vHem9doBAABgBckJAFCHG0lZNWGK1TNSWj3Y0ep9pRK4PxVVUaBqQs'
                    '3W+yVgCx61AwAAwLCdnFdNmFKk1QNJCs1Zwz1qWN+ePgjtEQEAeEFyAgDUoS+yiu'
                    'XD51pbPVjdzxit3lcq7bZ62AuHpICGO+0AAKzaVjsAYMZGfCoMFjlojmz1UOOhbY'
                    '0x+6r1tbFsXXt6ox0AAACWkJwAAPbdiMuTIClZPnyuNUmhRa3eVwqRrR4MJilQNQ'
                    'HQ86gdAIBV22oHAMzYSUiFQcutHsbLa7OWg+a13GdJ7e/pZxG51Q4CAABLSE4AYE'
                    'vHP6/+0exLZz1JIel0mQ+ELe9ljFbvK5XIJAVD9sIBKaDps3YAAAAYsxWRP0bNYD'
                    'lJodYD21rj9rWGeyyt3T3ttQMAAMAakhMAwLYb6QpXTZhi6oz0SIaDcVo9BGr1vl'
                    'IJ3B8jVRSomgDoe9QOAMBqXWkHAFzQJ5upSKuHFSYptK7W18ay9vb0T0LVBAAAXi'
                    'E5AQBs60XExqGv5cPnWls9WN3PGK3eVyp1tnrYCwejgLY77QAArNZGO4Bm/NzWiZ'
                    'uyrYh8SDpjkUPRyFYPtb2Faow5xFrus6R29nSnHQAAABaRnAAAdt2IHFVNsHLoay'
                    'WOKbUmKbSo1ftKob5WD3uNRZFQG1/srd29dgAAABiyzzaz5VYP4+W1aeeged4a7r'
                    'G0ut87n4S/wwMAMOmNdgAAcMxA+XJLboapT2HjFml/QOsMxHBJ4tjG9+Xk65FmAX'
                    'leoC2t3lcqgfuT/f146pNQNQGw4F47AACrda0dAHDmWkR+n32V8a/a2b6iiFgge2'
                    'yZ1Bq3jzXco4ZBatvTJ6FqAgAAF1E5AQBsuhaR97NP7lv4YLaiKgqHKWn1EKTV+0'
                    'olcH8KtXrocy8AwMmddgAAABjRF12NVg/p1Rizr1pfG8vq2tO9kOQPAMBFJCcAgE'
                    '398S9mExQsHPpaiWNKra0erO5njFbvK5WIVg+Z3pOUoQTseNQOAMBqbbQDaMLP9Z'
                    'yoGXctIu+Lr0qrh/TqOmgOt5b7LMn+nj4JrREBAJhFWwcAsOdaJr5wmS3lbqV8vp'
                    'U4piSOrUhpfcutM2K0el8pRLxPO+lSvx/7lJMBiPZZNA5kAKzdd9oBNIG/+6bRyU'
                    'fV9Wn1kF6tcfuqry2BfXbfO72QWAwAwCwqJwCAPf3cDxdbPVj4YGYhhksytHrIWk'
                    'nBymuaWqv3lYp+qweqJgAAAMCSGxF5px2EiBRq9RC4iP2nyqfVGrePNdyjBlt7+i'
                    'BUTQAAYBHJCQBgy7U4PhW5mKSgzfLhc4bYaPUQqNX7SkWv1UMfczEMsfVlHeLcag'
                    'cAYLU22gEAItKbOtwtEktkqwcre+Wjxph91fraWGZnT3vtAAAAqAHJCQBgS+97QR'
                    'VVFCzEMSVxbNmrKBwWaVOr95VCxPs08D1J1QTApkftAACs1pV2AFi9Xo6rJtg5iC'
                    'wQS+QCVvbJh6XXN6e13GdJunv6o4hy6xkAACpBcgIA2HElgb2kq2n1YCGOKbR6sK'
                    'HV+0olMknBQx+2CoDM7rQDAAAE+InTx0gbEdlN/sTS4a7lJAVL++Sj1rh9reEeS9'
                    'N57+yKrwgAQKVITgAAO3axE1STpGARrR7saPW+UgncH8ekGaomAHbdawcAYLW22g'
                    'Fg1XYi8nZ2hKXD3SKtHkhSaM4a7lFDuT39LLRgAwDAGckJAGDDVkQ+pJpsMUlBm+'
                    'XD51pbPVjdzxit3lcqeVo99IHRAMjvXjsAAKu11Q4Aq7UV1yR+S4e7RWKJbPVgZa'
                    '981Bizr1pfG8vK7GmffQUAABryRjsAADix1oPIIc8HmU46GaY+hY37rP2h10ocUx'
                    'LHNh4GT74eqXRicy9jtXpfKUS8Tyf++/BZOPwErPtRRL7TDgIAgEJ6WaqacG7866'
                    '2F7xayxxK5wBB+qRpLr29Oa7nPkvLt6SehagIAAF6onAAA+rbSpauacK6aVg8W4p'
                    'iSodVD1koKlvcyRqv3lUqaVg99uoBgAkk9LXrUDgDAKl1pB1Ctn/gf4whbiakuaO'
                    'kJ9Oyx0OqhWWu4x9LS72mffEYAABpHcgIA6OtFJPvhazVJChZl2B9aPQRq9b5SCU'
                    '9SoEcmUIdb7QAArNJGOwCsUp9kFkuHu0VaPawwSaF1tb42lqXb009C9UEAALzR1g'
                    'EAdG3l/GmQzK0OLrZ6GNfW/tBLq4e0LO9njFbvKxX/P8t99oQZFJf1vy0AAAD5XE'
                    'tM1YRzlkrkF4klol+Dpb1yVWPMIdZynyXF7emTiOxShQIAwJpQOQEAdPUXf5LxCf'
                    'FqqihYiGNK4tiyt3o4LNKmVu8rBff3KVUTgHrcagcAYJXeaweA1emzzGrpCXTLrR'
                    '7Gy2tj6fXNaQ33WFrYe2cvtFwDACAIyQkAoGcjLk+D0OrBrgytHrImKVh5TVNr9b'
                    '5SWd6fvkgcKGoY+NayUY/aAQAAHP3E/xYHupbcCTGWDrFp9ZBerXH7WMM9anDf0y'
                    'c5JCcAAIAAJCcAgJ6d88jMh6+LSQraLB8+Z4itSBUFq/sZo9X7SmV6f6iaANTlTj'
                    'sAAAAy2xdbycrhbpGD5sgqClb2ykeNMfuq9bWxzG1PeyFpGACAYCQnAICOjYT0pi'
                    'uQpKCxrjMrcUyh1YMdlt8nFpzuTa8TBIAID9oBAFila+0AsAo3IvJd0RUtHe7S6i'
                    'E9S69vTmu5z5Iu7+mDUDUBAIAob7QDAICV2onI2+Crx8PFDB8+xwPxYWryjOt6sR'
                    'LHlE6SxjX7eqRZQJ4XaE/i16Iph9f9swxUTQAqdC8i77SDAAAs4O+hIXq1JOPx9b'
                    'KQ5Jw9logFLO2Tj1rj9jVI+/dY2uv3Tq8SBwAADSE5AQDK20hI1YQpGQ9fq0lS0I'
                    '5hSob96aTLl6BwWODA4n7GaPW+0tD78hf58Z5v2Z3k7sUNAK9ttANA83Yi8k79EN'
                    'nS4W72WEhSaNIa7lHD4c/jjyLyUTkSAACqR3ICAJS3k5iqCecyH74uJiloH4BZPn'
                    'xOHFv2KgqHReR5kba0el/hHkSomgBU6lE7AACrdCUiPyjHUI+/8pdOTxs5fxpZ84'
                    'DV0uFukVgisiAs7ZUPS0koudT62lg2JHrQCACAlfuVdgAAsDIbSVU14VwnWT90dp'
                    'cmz7yuMytxTEkcW/f8f1lZ3ctYrd6Xv147AOQzfONApHG32gEAAJDYTi4l8Gv+te'
                    'Zyz/nysscSuYCVffJh6fXNaS33md9n4e/hAAAkQXICAJS1k5RVE6ZkTlAgSSFC4r'
                    'iyJylY3ssYrd6XuwehFCUAAPCz1Q4AzdrIUgK/9uGq9vrHLCcpWNonH7XG7WsN95'
                    'jXTjsAAABaQVsHALa0fmA4yE2RdbRbPWRc25mFlhNTMuxPJx2tHkK0el/Leu0AAE'
                    'S51Q4AwCpttQNAs/bimsCvXabeUiuA7LFEbLb26xSq1rh9rOEe8/gkInfaQQAA0A'
                    'oqJwBAOTfSybuiHwILtHqYraSgzfIT8rW2erC6nzFava9pVE0A2vCkHQAA4IK/ri'
                    '/zNcJWRD54X6X5pLulp+yLxBLZ6sHKXvmoMWZftb42enrtAAAAaAnJCQBQTv/yb6'
                    'UPQwskKWis68xKHFNqTVJoUav3darXDgBAEnfaAQBYnSvtANCkPupqWj0cWG71MF'
                    '5eG0uvb05ruc84/ygi99pBAADQEpITAKCMGxF59+p3NZIUsk29UEXBwsGvlTimJI'
                    '4re5KC5b2M0ep9HVA1AWjHvXYAAFbHrew+4O5aQqomnNM+XNVe/5jlJAVL++Sj1r'
                    'h9reEewzwJCf4AACRHcgIAlNHP/rSxKgpVJClYlGF/aPUQqM376rUDQH7DN75ZXI'
                    'l77QAAAIjUJ51N+xDZ0l/BirR6WGGSQutqfW3y2ovIo3IMAAA0h+QEAMjvRqaqJp'
                    'xbS6uHcW1tlg+fa231YHU/Y7RzX1RNANpypx0AgFW61g4AzbgWkfdZZtZOULByuF'
                    'skFlo9NGkt97nsSQ7JCQAAIDGSEwAgv95rdENJCtVUUbAQx5RakxRaVP999doBAE'
                    'jqUTsAAAAi9Fln1z5c1V7/GK0e0qs1bl9ruMd5O+Hv3AAAZEFyAgDk9b24VE2YUv'
                    'owlFYPdmVo9ZA1ScHKa5pavff1JFRNAFpzqx0AAGDCXznNc3AjuaomnNM+RLb0dq'
                    'DVQ3q1xu1jDfc4jcqDAABkRHICAOS1i7q6oSoKh+kXkhS0WT58zhAbrR4C1Xdfe+'
                    '0AAGTxpB0AgNW51g7AvIF/HP7pix92ah6wWjrcraHVg5W98lFjzL5qfW3C9doBAA'
                    'DQMpITACCfa0n1REiDSQoa6zqzEscUWj3YUcd90ScTaNeddgAAAHi6kbGyoMZhp3'
                    'YVBSuHu5ZbPYyX18bS65vTOu7zs1A1AQCArN5oBwAAx7IfkhY0yNAnn3TcnlIfBj'
                    'OuN77Ww9Tkpe/zEitxTOkkaVyzr0eaBeR5gbbYv6+90CcTaNWjdgAAVmejHYBp/2'
                    '73L4RGbGQqaXaQskm/48uk9dWD9vrHsscSsYClffJRa9y+Sv+5LavXDgAAgNZROQ'
                    'EA8rjupEtTNWFK6Q+Bmq0eLHzgtRDDFFo92GHzvqiasDLDNw5FVuZOOwAAq3OlHY'
                    'Bl+t0SzP+zG0Tezm5eSdpPgFv6a1uRVg+Bi2i/TqFqjdtHm/f4WURutYMAAKB1VE'
                    '4AYIu9w71QvQyHg95mnkTPvN5iJQXtD72Wn5BPHFv2KgqHReR5kbbYuq+98GQ10L'
                    'J77QAAAHC0EZGdyMID1xpPnWs+6W7pKfsisUQ8bm9pr3y0XWHgoNbXZtpOOwAAAN'
                    'aAygkAkN61iLwfn6SerQyQQukntjOvV0UVBQtxTEkcW/b37mGRNunfF1UTgPbdaw'
                    'cAYHW22gGgWr0cVU1YfOBaq5KCFktPoGePJXIBK/vkw9Lrm1P99/lJqEwGAEARJC'
                    'cAQHr9ya+68f81mKSQbepKWj1YiGNKhlYPTb13S9G9r71QNQFo3Z12AABW5512AF'
                    'YN/173iVxmWxH5w9QPnJIUStI+XNVe/5jlJAVL++Sj1rh91XuPvXYAAACsBckJAJ'
                    'DWVkTev/rdo0PKIge9pRSoolBFkoJFGfanSBUFq/sZo/x9UTUBWIdH7QAAAHDQLw'
                    '2YPbPVqqKgnaRgRfZYSFJoUn33+I9CVTIAAIohOQEA0upnf3qWpJBNg60eZpMUtF'
                    'k+VK+11YPV/YxR7r72wqElsBaftQMAsDpX2gGgKlci8sF1MK0ezta2crhbJJbIVg'
                    '9W9spHjTH7quO1eRKqJgAAUBTJCQCQzlZcv3h5PqRsrlx+gSQFjXWdWYljSq1JCi'
                    '3Kf1/77CvAnOGb/W/9kMWjdgAAVmejHQCqsve9gFYPxtY/ZrnVw3h5bSy9vjnZvs'
                    '+98HdqAACKIjkBANLpva8o2eqhdJJCtqkrafVgIY4pGVo9NPXeLSXffX0SvlgB1u'
                    'ROOwAAAC64lqmWh45o9WBs/WOWkxQs7ZOPWuP2Ze8eaYkIAIACkhMAII2teJSrPH'
                    'HW6iH7QW8pa2/1IGInjnMZXhtaPQRKf1990tkAWPeoHQCA1bnSDsCkgX9e/ZPo76'
                    'UkKUysb0WRVg8rTFJona3XZif8fRoAgOJITgCANProGc6SFLKh1UNZVuKYUmurB6'
                    'v7GSPNfX0SkfvoWQDU5E47AACrs9EOwJrh3+ycshlyI4O8T3kAudjqQSNJQYulw9'
                    '0isdDqoUn69/kgIh9VIwAAYKVITgCAeFsJrZow5fmQsrly+RnXo9VDpFqTFFoUd1'
                    '99miBQm+HbGr69xAX32gEAADChf/m3xAkKi0kKJWkfrmqvf4xWD+nVGrcvvXvcqa'
                    '0MAMDKvdEOAABO1HjgOGQ6EOxEZPilMsCQ6xPb8zrFZFxvdq/G95b2h/vS++0jcW'
                    'xF3ruHBdoSdl9UTQDW6V47AACrc60dAMy7EZF3J78z/r020ef92ekSr+VEY83z9a'
                    '18l5I9lojN1n6dQtUat4/y9/hZRH4othoAADhB5QQAiLORTr7PNvtZq4dsT6M3VE'
                    'XhMP1CJQVtK6qicJiSVg9B/O6rzxYHAOt+1A4AANaKlg6vbGTu76WJnwSfnU6r1Y'
                    'PWW8LSU/Y1tHqwslc+aozZV7nXpi+yCgAAmERyAgDE2YnI2+wHo2dJCiXWKaJAko'
                    'LGus6sxDGFVg92LN8XVROAdXvUDgDAqmy0A4BpOzmvmjAlQ5JCqbWc0OrhwHKrh/'
                    'Hy2lh6fXPKe5+fReQ22+wAAGARyQkAEG4jxz3qShw0l6iiMK5TOkkh29QLVRQsHG'
                    'hbiWNKhioKTb13S5m/r75YHAAsutUOAMCqfKcdAMzaiG8P91JVFBKv5UT7EFl7/W'
                    'OWkxQs7ZOPWuP2leceb7LMCgAAnJGcAADhdiLy9tXv5j4cLdXqYVyrFO1WDxYOtC'
                    '3EMIVWD3a8vi+qJgB41A4AAAC59Pl4Ca0e8q9vRZFWDyQpNCftPfL5GQAAA0hOAI'
                    'AwG1l6KoRWDybXW0xS0Gb5UL3WVg9W9zPGL/fVq8YBdcO31r+NhIM77QAArM5WOw'
                    'CYsxWRP0bNsIZWD1p/bbN0gF0klshWD1b2ykeNMftK89r00TMAAIBoJCcAQJiduD'
                    'wVUqrVQ9dgufwCSQoa6zqzEseUWpMU2vNZeOoDAP8dAFDeVjsAmNMnm6l0qweNJA'
                    'Utlg7eLbd6GC+vjaXXN6fw+/wH4e/NAACY8EY7AACo0EZ8e2mOB6M5Pyh2h/nHQ9'
                    '4h12Il7uV8vWy3MrNXpe/zEitxTEn82jT33s2vbzTpAoCfe+0AAGCNhn9r5y+Vkb'
                    'Yi8iHpjOPWJvq77uJ0Q7q1nCS+v+rWP5Y9logFLO2Tj1rj9uX35/ZJRPa5QgEAAH'
                    '6onAAA/r6XkF6aIvmfhj9r9ZC9kkIp2q0eLHyotxDDlAz7Q6sHJ59F5FY7CABmPG'
                    'gHAGBVrrQDMGHgn+dD0I9R+zgnQ6uHi9OtrdXDuL4VRVo9BC6i/TqFqjFmX+6vzV'
                    '5EHjNGAgAAPJCcAAD++ugZCrV6OPwrrR7cp19IUtBm+VC91lYPVvdzWa8dAABT7r'
                    'UDALAqG+0AYMa1DPI++yoZkhRKreVEO0HByiF2kVgiWz1Y2StXNcYcYv4+H4SqCQ'
                    'AAmEJyAgD4uRGRd0lmKnEw+rxGkSoKjSUpaKzrzEocU2pNUqgLVRMAnLvTDgAAsE'
                    'q9iJQ7AC1VRSHxWk60D5G11z+WPZbIBazskw9Lr29O0/fYC1UTAAAw5Y12AABwwv'
                    '4hYZ/8A914zzk/KHaH+cdD3iHXYs/rFJNxvdm9KvGauSi93z4Sx1bkvXtYoAa9dg'
                    'CwYfhaxxsWRTxqBwBgVa60A9A2/Cv/GyyHdoenVRPGbcn5uT7xGrPTlbgfC2taWv'
                    '9Y9lgiFrC0Tz5qjdvH6T0+SM7WMwAAIAjJCQDg7kZE3mU7xMx9OHo0f9aD3tKHvJ'
                    'nXW0xS0P5e0vKheobYOunyJSgcFjiwuJ8HVE0AMOVWRP6oHQSA1dhoBwAT9hd/Mk'
                    'j+w0+SFPKvb+UAO3ssEQtov06hLL2+uRxem51uEAAAYAptHQDAXX/yq1wf5Aq1ej'
                    'j8K60e3Ken1UOwWls92NzPXjsAACY9agcAAFiVG1lqd1iy1UPidg+l1nJCq4cDWj'
                    '2kZ+n1zeOziPygHQQAAHiN5AQAcHMjU1++5DrALHEw+rxG9oPehpIUZvfKymG2lT'
                    'im1JqkYAdVEwBccqcdAIBVeb88BI3rnUeWTFJIONVikkJJ2ofI2usfs5ykYGmffN'
                    'Qa97JeOwAAADCN5AQAcNPP/rT2JAUplKRQUuYqClUkKViVOLbmEmwu22sHAMC0B+'
                    '0AAGANhn9t8xTPQy9LVROmlDgAzVBF4eJ0WlUUtJMUrMgeC0kKlSOxHwAAw0hOAI'
                    'Bl1+L65UutSQpnrR6yHfQ2VEXhMP1CkoI2O4fqr2WIrfFWDw9CSUoA8+61AwCwKh'
                    'vtAKBiI7E93Gn1EE/zENnSAXaRWCJbPVjZKx81xvzajXYAAADgMpITAJjS2fy/3v'
                    'vQM9cBZqFWD4d/behJ9AJJChrrOrMSxxRaPbjqVVaFWcPXNr41RFL32gEAWJUr7Q'
                    'CgYicib6NnabXVg0aSghZLB++WWz2Ml9fG0uvr75Pw92IAAEwjOQEA5l3Lc0/VoA'
                    'SFGqsojGtIg+XyafVgI44ptHqY8yAiH4utBqBW99oBAACatpXYqgnnWmv1IEs/zE'
                    'D7EFl7/WOWkxQs7ZOP+uJ+EhL7AQAw7412AABgXH/8i/Gwc/D5dDYeYKb+QJdr3o'
                    'n5g+7bd61SH3gz79vsXuV+zVyV3G8fGfanky7f+/awwEHe/eyzzg6gFXfaAQBYla'
                    '12AGos/j26hE56SVE1Ycq4pzmTfxOvMTtdifuxsOb5+lYS4bPHErHZ2q9TqHri3g'
                    'sJuwAAmEflBAC47FqeqyacC3oqm1YPzusUUaDVw2wlBW3WqyjU2OohzxJUTQDg6l'
                    'E7AACrstUOQMPwL2vNTJCtDPKhSJWD3DJUUii1lhPNJ90tPWVfJJbIVg9W9sqH7Z'
                    'if5JCcAAAAjKNyAgBbbB2W9ksfvLwrCtRaReFojW4oUEXhsEAZBSopmK+iIKIfx5'
                    'TEsWWvAHJYJPVe9klnA9CyW+0AAADN2r/8W+4nqEs9oZ3w6frFkDWqCmhWMrD0lH'
                    '32WCIXsFRxwpWl1/fUXkjWBQCgClROAIBp1yLy3vVp6KAqCjk+yJV4Gv6oikJzlR'
                    'SyTb1QRcHCh3orcUxJHFdF712qJgDw9aQdAIDV2GoHgGKuReT3r34395PfJZ4sz1'
                    'BF4eJ0a6uiYGH9Y9ljiVjA0j75sBX3g5DYDwBANUhOAIBpu5NfORw2Brd6qDFJ4a'
                    'zVQ/aD3lK0Wz1YSA6wEMOUDPtTQauHPkkcaM7w1c63gDDnTjsAAKux1Q4AxfSzP6'
                    'XVg990a01SsKJIq4cVJino67UDAAAA7khOAIDXtjL1ZIiIcxWFoCSFHEpUUThKUi'
                    'ixThEFkhRm19ZmJVFiSuLYsifXHBYJiZmqCQBC3GsHAACtGv7FxglcYdci8n5xVA'
                    'tVFDKsMzuVVpKCFksH70ViiVjA0l650o2Zz84AAFSG5AQAeK2f/SmtHi6uUVG5fP'
                    'X1qqmiYCGOKbUmKbjr8wQBoHH32gEAWI0r7QBQxEev0S0lKSScajFJoSTtg2/t9Y'
                    '9ZbvUwXl4bndf3pviKAAAgCskJAHBqKyIfnEbS6mF6DWms1UPm9apJUrAqQ6sHAw'
                    'k2TyLyQ74gADTsXjsAAKvxVjsAZHcjIu+CrizR6qGyNWj1YGz9Y7R6SK9c3J9F5L'
                    'bISgAAIJk32gEAgDG99xXjQePMB6/xsHPw+XTmMG+QXPNOzB903wHrFJF5vdm96v'
                    'Kt66z0fvvIEFsnXZ737S8LHEwvsReRx3yLA2jYvXYAANAsi38PzuXwd9U+ao5xv3'
                    'ImOg+Z5x/XkHTrzE5XYs8srHm+voVk+CL7EHGz2q9TqPyvb591dgAAkAWVEwDgF1'
                    'txrZowxbHVQ1AlhRwKtXo4/Kv6k+jVrFdFFQULcUxpo9XDkxySE4BJw9c1nYwgwJ'
                    '12AABW5Vo7AGTTS2jVhHMttXpIXEmh1FpOqKJwQKuH9PLt6Z+EqgkAAFSJygkAbN'
                    'E89BwSZFw7PsHt/VR2rVUUjtbohoxVFI7WaaGSwmIVhUzrerESx5TElSayVgA5LC'
                    'DPC4hQNQFAnEftAACgRcNfLP6lN5uNiOySz5r7ye9ST5YnfBJ8MeTSVQW0n87XXv'
                    '9Y9lgiFrC0Tz7Sx71LNhMAACiK5AQAONhKJx+SnT3S6mF6jdytHo7WKSbjetUkKW'
                    'jHMKXOVg9UTQCQwmcRea8dBIBV2GgHUI7Fv/Dm0u1kkLeHf80wfe4D91LtJBKuQa'
                    'uHifWtHLxnj4UkhUCfhHZmAABUi7YOAHBwIyLpP9Q5lJkPbvWQ4wNo4VYP2UrmN9'
                    'jqYbbdgzZaPaSyF556BhDvUTsAAKtxpR0AktuIDLuX08Nc5dhLlPGn1UM8zXYLq2'
                    'r1MC4ScamVvfIRHvOTSILKpwAAQA3JCQBwXrYyx0Grw3zBSQqplThoPktSKLFOEQ'
                    'WSFDTWdWYljin2kxSomgAglTvtAAAA1dqLPFdNOD45zHXwmftQtdShbeIEBZNJCl'
                    'osHbxnjyVyASv75CPslvdC1QQAAKpGcgIAHBIT3r763dQHrY7zmaqiUCJJQbI/ja'
                    '6TpJBt6oUqChaSA6zEMSVxXAnfu3vhaWcAadxrBwBgNbbaAZQw/OWbdgilbEXkw+'
                    'lvHZ0c5jyYbSFJIUMVhcUkhZK0kwS01z9mOUnB0j75cI+bpH4AABpAcgKAtdvIcd'
                    'WEKQpJCuZaPeQ8aC7V6mFcqxTtVg8WkgMsxDAlw/5Evm/5ggVOhi81ftMIBffaAQ'
                    'BYja12AEiqv/yjgkkKObWWpLC2Vg/j+lYUafVAksKZvZDUDwBA9UhOALB2O5mqmj'
                    'AlR6uHXEkKOdDqweR6i0kK2qwkSkyx0+phL3zBAiCdO+0AAKzGRjsAJHMtr6omTD'
                    'lLUsihVAJBbhmSFEqt5UTz8NvSwXuRWCJbPVjZKx/TMT/IbBIVAACoBckJANZsI0'
                    'tVE87lOGh1bPXgdehZaxWFozWabPWQOUlBY11nVuKYop+k8DHd6gBAshOAYr7TDg'
                    'DJ9H7DafXgtU7CqUy1etBa83htKwfvlls9jJfX5vUt9ypxAACA5EhOAGBLV/Afn6'
                    'oJl+JMxXG+1bR6GNeQRpMUsk1dSasHC3FMydDqweG9+0kowQ4gvR+1AwCwGhvtAB'
                    'DtWkTe+19GqwetNWj1YGz9Y5aTFCztk49D3A9CUj8AAM14ox0AACjZiG/VhCmdpP'
                    '1wN55jzsw5HnYOPgs7zBsk17wT8wfdt+9apT6oZ9632b0qeZ9zrMRxLsNr00k397'
                    '7t060EAC8etQMAsBpXInKrHENeFv/OmlIn+7gJxg3qTv41qVzznq+RO4k68X3MTl'
                    'dizyyseb6+lUT47LFEbLb26xTmpvn/FgMAsCJUTgCwVjvp5G2SD2O1tHpwnDdIoV'
                    'YPh39trIoCrR5sKtPqgaoJAHK51Q4AwGpstAPIafjzN+0QcruRZO05ziop5NBSq4'
                    'fElRRKreWEKgoHRWJZRauHz8LfbQEAaArJCQBM6Qr9nxy+hBkXTRU8rR4KJSk02e'
                    'oh03q0eoiUN0mhTzczWjd8qefbQ5jwqB0AgNW40g4AUfr0B6iFWj20kqSQcKrFJI'
                    'WStJMEtNc/RquHWL12AAAAIC2SEwCs0U0n3buT30l5AKmQpBBcRaHmJAUplKRQUu'
                    'YqClUkKViVOLZOOqomAMjpTjsAAKux0Q4AwXYi8svn4qSHlGdVFHImKeRU4uA2Qx'
                    'WFi9NpVVHQTlKwokgVheaSFD4JVRMAAGjOG+0AAEBBL/JLxYGTXvAp+813ieY5nk'
                    '/m55y8pwTzBsk178T8QfcdsE4Rmdeb3avU79kQpffbR9rY+qyJNWhOlv++oWX32g'
                    'EAWI0r7QByabylw0YuPY2ctB/90WS5+tznmvd8jdx/dU98H7PTldgzC2taWPtckV'
                    'gi3rCW9uqg1w4AAACkR+UEAGtzI8dPh8iFtgipniTP8US6Y6uHoEoKORRq9XD4V1'
                    'o9uE9fQRUFC3FMiY+NqgkAcrvXDgDAamy0A0CQnYi8nR2Ro9VD8nnPlmil1UPiSg'
                    'ql1nKiXUXBSr6v5VYP4+X6+NwMAECjqJwAYG1upn7z4tPkqZ4kT/00uON8nXTrqK'
                    'IwrpG7isK4zmGBMjKut1hFIdO6XqzEMSX8vw990jiwDhb/DMC6H0XkO+0gADSP/8'
                    '7UZyOH5IRltVVROFsmi1JPlies1rAYconKEOfrSeE1La1/LHssEQvo7tOTuP53Cg'
                    'AAVIfKCQDW5FpE3s8NmKw4kPIJ7tRPgzvMF1xFIccH0NxPw59VUcheSaGkzFUUqq'
                    'ikYJH//vD0B4BSHrUDALAaG+0A4KWXpaoJ55I+5X00Wc6nx3MndpZ4Cj9DFYWL02'
                    'lVUdCupGBF9lgiNlvnddoLf5cFAKBZJCcAsKXL+I9H1nWRJIWUakxSyIlWD4HTLy'
                    'QpaLOSKDHFPbZ91jjQpG8/N93zGvncaQcAYDWutAOAs62I/CH46tqSFEolEOS2hl'
                    'YPWokC2gkSx4rEEtnqocxePQmfmwEAaBptHQCsxVY6+b3vB6nJtghWWz2Mczq0ej'
                    'gs69nuodZWDyLSDbR68Jv+QjsQKy0WrMQxZT62z8JhIYByHrUDALAaG+0AsrD4d8'
                    '1YXaL2YknbABxNlqu9AK0eJqeSuek0SvqXbi9xvrYorn/McquH8fK8+9QLf48FAK'
                    'BpVE4AsBa9iAQ9ed1iq4fDMENVFEpUUpBCrR5KV1LINnUlrR4sxDFlOq6+bBAAVu'
                    '5WOwAAq3GlHUBqw5+brFp0JSIfks1WWxWF3HOXmD/DGovTramKgoX1j2WPxWSrhw'
                    'ehagIAAM0jOQHAGmxE5PuT3wk40GwxScFcq4ecB81nrR6yJymUot3qwUJygIUYpp'
                    'zuz2fhoBBAWY/aAQBYjY12AHCyz3KgWGuSQk6tJSmsrdXDuL4VRVo9mElS6JPOBg'
                    'AATKKtA4A1uBGRt69+N7A0/GRbhJRl5lO3UHCIzUyrh5zzHs8vhzUuti9IvE4RBV'
                    'o9HKa/0O5B+8sb+60eet0gAKzQnXYAAFbjSjsALLoWkfcvv8pRNj55qwc5TFhrq4'
                    'dxjRKtHiTdOrMh0+pBT5FYIjY7TXw/isjHqBkAAEAVqJwAYA12sz8NfPp78mlyq1'
                    'UUxjkXh3hWFKi1isLRGk22eshcSUFjXWdW4jhF1QQAWh60AwCwChvtALCon/xd01'
                    'UUxglzzHu2RO2tHsZ1Ek5FqwdD6x+z3OphvDzcLupqAABQDZITALTuexF55zQy4F'
                    'CzxVYPh2ErafUwriGNJilkm7qSVg8W4jjotQNAvb791GTPa5Rzrx0AgFX4TjsAzL'
                    'qR46oJ52j18MvcOdHqIZ52koD2+scsJymEXUpCPwAAK0JyAoDW3XhfEVhFIXuSQk'
                    'oOsQUd1teapHA0f5EkhVIKVFGYTVKwQD8OvmQBoOlOOwAAq7HRDgAX9U6jSFIol0'
                    'CQG0kK+de3InssxZIU+rBFAABAjUhOANCyrYj8PujKiFYP2ZIUamn14DhvkEKtHg'
                    '7/2lgVBVo9aOnVVgYAkUftAACsxpV2AKkMf26qatGNuFYSHOU69E862VGSQg4ttX'
                    'pInKRQai0n2gkKVpIUisSStdXDJyGhHwCAVSE5AYAtXdJ/bpLF433ZxEW0ekijVK'
                    'uHrtFWD5nWo9XDJKomANB2qx0AgNXYageAVzYisg+60nwVhXHCHPOeLdFKkkLCqR'
                    'aTFErSThLQXv9Yva0e+rBJAQBArd5oBwAAGd28HETGfkALmGc8qB2OL0oVT+q5HO'
                    'ebvKcE8wbJNe/5GkPgfQesU0zG9Wb3qsRr5qLcfu+LrIJmffupqSc3AQBt22oHkI'
                    'z231VT6WQnIm+j5hj3ImWCb9I5jybLEevxMjmTnHPGnmmN2elK3I+FNc/Xt5CQL1'
                    'IglojNfn3pJxG5jwwIAABUhsoJAFr1vRyXr0zZWsH7koytHsa5UnKILbjVQ42VFM'
                    '5aPWSrpNBQFYXD9AuVFLTl3+8HEfkh6woAsOxWOwAAq7HVDiCF4Z+bSQzciMgu2W'
                    'zmKymctXrI1Zoid+JKpa0eLk6n1epBK8FoVVUUxkUiLh3kSVL+dwoAAFSD5AQArb'
                    'qZ/N1UCQopWz0oxrQ45+KQwCSFHAq1ejj8K60e3KdfbauHPsusAODvSTsAAKuw1Q'
                    '4AJ3oZ5G2WhILUcrR6SD7v2RK0evCbTitJQcuqkhSiFtiLyGOqSAAAQD1o6wCgRV'
                    'sR+f3Fn1pr9TDOVWmrh8OwjlYPOdY5LFAGrR4O0sTxICIfk8wEAPHuROS9dhAAmr'
                    'fVDgAvtiLyh5dfpS53T6uHV8tk0Vqrh3HA2lo9aK5/LHss3gs8iche/XsAAACggs'
                    'oJAFr0vdOo1ls9pPzQSauHi/NnbfUwrlWKdqsHC1/apImhTzILAKRxrx0AgFV4tz'
                    'wEhfSTv5v6CWpaPfwyd06l2knQ6iHv+lYUafXgtEgvVE0AAGC1SE4AYEqX4P/Et2'
                    'edcquH7EkKKdWYpJATrR4Cp19IUtAWd/9UTQBgzb12AABWY6sdAGQrIh9mR5hOKD'
                    'iaM+lkR0kKOZRKIMgtQ5JCqbWcaCYpaCdIHCsSy+wCD3Jo6QAAAFaK5AQArbmSkK'
                    'd2UlZRCExSmJwrhRwHzQ7zBScppFbiYP95jSJVFBpLUtBY11lYHH3yOLBK3376ph'
                    '0C2nGnHQCA1dhqBwDHJFnzCQWSIcZCVRRyHvqWOuAuVUXBaUAG2lUUVpOkcHGBPu'
                    'eqAADAvjfaAQDAifgDyV03zPS3d10/9gNawDzjQe1J3KniST2Xx3yddH6vReo4c8'
                    '97vsZw4bVMvc5hgTK6fGvN7lXp+7zEPQ6qJgCw6FE7AACrsdUOIMbwz9UnBl6LyH'
                    'uvK1L3oc/R1z7pnEeT5Yh1Ypkscs+fYY3F6YZ0azkpsYeW1z+WPZaTBT4Ln5kBAF'
                    'g9khMAtOb7lzL7g+eh+LGUSQqec7SYpBB0WF9rksLR/EWSFEomKEi+9apJUpiPoS'
                    '8SBwD4udUOAMBqbLUDWLk++EqSFPIlKVSUQFBijdnpNA7stZMESidlzMkeyyDCZ2'
                    'YAACC0dQDQlu9F5O3Lr1KU2Vdu9fAq9pTl7tfc6iHnvMfzj4kytHrwmH7mPWLhS5'
                    'vL90/VBAAAsHZb7QBW7HvxrZowxXxrhtTzHQVYa6uHcY3cEt8HrR7O1tZOxB/lje'
                    'WzkDQLAACE5AQAbfn+1e88HyRGJSmkOoyNSFKYnCuF1AfNjvN5vx65DsRLHOyneA'
                    '96rFNMgSQFjXWdvY6jV4kDANx81g4AwCpstQOIMlT9zz7ZgaL5hALJEONRgkKtSQ'
                    'qlDrgTJygsJimUpJ0koL3+sTyx7JLPCAAAqkRyAoBWbETkw8WfVp6kUKSKglKSQo'
                    '55vZVKUpBCSQolaVZRsJKkIPIkIj+oxgEA8x61AwCwClvtAEINT9+0Q4hxIyLvRC'
                    'TtgWLqw8lcSQ/J5jyropAzSSGnUpUaSiUpaFVRIEnhIF0cn0TkLtlsAACgaiQnAG'
                    'jF906jjpIUgqVMUvC+pMJWDwtzBrd6qDFJ4azVQ7YkhQarKBhv9bAXDv4A2HanHQ'
                    'CAVXinHcAKbWSqglfqpIKUSFKg1UPIdGtNUrAgzT700TMAAIBmvNEOAAAS+d5rdC'
                    'fSDYdTzSH0U1Yn8R/QxoNVz3nGg9qT2APnShXT4pwL803eU4J5g+Sa93h+OazRSR'
                    'f+HvRYp4jM613cq9L3eepJRPYmkiTQjG9/rfrpTdh0rx0AgNXYCv/NKWknl5JCxr'
                    '8bp/h7asq5judM/XfopHMe3XSOWM+WyCL3/JnWmd3uUvd0vqbW5z2N+70kPJZ/FP'
                    '53AQAAHKFyAoAWbETk995XVd7q4XDZxEW0ekijVKuH2PegxzrFZFzPYKuHvVA1AY'
                    'B999oBAFiNrXYAK7IRlx7utHpIMGGOec+WyJloXaoCQKkqConXcmKhikKdlRSehK'
                    'oJAADgDJUTANgSdrD4vYiEf1Aby+zHVFJIWbXAUhWF1HM5zhdcRWFh3iAlnsp/ft'
                    '2D7jtgnWIyrje7V+UqKRyqJgCAfXfaAQBYja12ACuyE5G3zqNTPv2d+mnuXJUZks'
                    '15VkUh2bwTy+RMti7xFH6GKgoXp9OqolB6zfP1LVRREHGNZS8k8wMAgDNUTgDQgu'
                    '9FJP6p6aOn2KPmiBVRReFV7CmfJE/9AdghtqCKArVWUjiaP2slhYaqKBymX6ikkN'
                    'de+KIFQB0etQMAsBpb7QB8DU9VtlPaisgfva/KUfkgJfOVFI4my/Uke4kn5EtVUU'
                    'hcSaHUWk40KxnUU0WBZH4AADCJ5AQAtdvIeUuH2APJVls9KMa0OOfikMAkhRwKtX'
                    'o4/CutHtynL97qgS9aANTms3YAAFZhqx2At6HCf2LLpKc83MyVUJBajlYPyec9W4'
                    'JWD6+mMpmkoMV+ksJOSJAFAAATSE4AULvryd9NWEWhxiSFi3GnrKKQ8sDXcb7VVF'
                    'EY15DMVRTGdUonKWSbeqGKQtq198IXLQAAAOe22gGswFYG+ZBkJstJClRRyD93if'
                    'kzrOGUpFCSdpKA9vrHfonlQUQ+aoYCAADseqMdAABE+n72p7G958cD4mGmv73jHN'
                    'EfFjv/OcaD2pO4U8WTei7H+SbvKcG8QXLNOzF/0H37rlXqC43M+za7V2nWpmoCsv'
                    'n21ypLS6MOtyLyXjsIAM3bagewAh9F5Je/z6ZIwB0SzTPOJYbnSz7n0WQ5Yj1eJm'
                    'dSec7YM60xO12J+7Gw5vn6WmufGyKruwAAgKZROQFA7b53GpWwkkLUHLEiWj28ij'
                    '3lk+Q5Wj0szEmrh7zrFFGg1cNsJYVwH4WqCQDq86gdAIBVeKcdQOOu5TzRLNVT0z'
                    'kqH6Rkvn3EWSWFHEpVOcgtQyWFUms50axkYKOKwmehagIAAJhBcgKAml2LyFuvK2'
                    'IPQitu9XC4rKJWD+Oci0M8X4/aWz3Evgc91immQJJC4nX3wcEAgJ477QAArMZWO4'
                    'CG9Rd/YrE9g/mEAskQI60evNZJOJWpVg9aax6vrbd+r7YyAACoAskJAGr2fdBVCa'
                    'so1JikUKSKQsqDZsf5gqoo1JykII0mKWSbeqGKgvvan0TkPkVMAFDYvXYAAFZjqx'
                    '2Aq+GxqnZK17LUnsdqYkGOqgz/f/b+JkmO7EoQNc/1AH8i+AMwH6VyUEIJ1AqIN2'
                    'uRFulATXvCyBUQnLdIIleQxhWk5woSsYJGrCAdvYH2GLX0oOU5JLtePVazku5ZlQ'
                    'wmMyK0B+bqMDO3H72q96qqmX0fxQVws3vPPW4AEW6uR8+ZdZHCRhcFRQqjnbE33L'
                    'l1UZjm/HexHCUGALDTk6kTAFiTd3Hy84jo/0Zr6Oz59gJxk7bPth8jh9U4mTHaC7'
                    'VruZfKp2dOB+PF/phbv6YCcXupFXdL/F5fd+5ZY/1Ao/Lrtve16nb2omxGAKO5mT'
                    'oB4Gw8nzqBE/Wm88r2+9kSxb8l59iXjNXGiznHXAlWI9fVY2oWldeO354R5c7ZG6'
                    '7mn8UuU5y5ef44Z78e5RQA4KjpnAAcq+fRzjMtMKph6P7Bd7BPPOqhWieFYxn10D'
                    'FuLyONelj+9sS6KEwx6qE9eztdE4Bj99XUCQBn4fnUCZygV9G+/80xx84Hs+96sB'
                    'KzaLCVTgo1nEIXhQrnHBz1MEUnhanU/3q/CGPEAIAOdE4AjtXna58V6oJQoovCMk'
                    'yPQCW7KPSIk2JLB4hSd8yXvhu+Y7ytX1OBuNlqd1FYOWPQ38GMc06hk0KPLgqL8l'
                    'nAB9/921G1luY43U6dAHAWnk+dQGdTXijMkQZ8H1q6i8IcY63GnG0XhTbgCF0Uas'
                    'UeI/7qOWN0USh8Vidz6KJQ5/xF8YgAwEnSOQE4Vi+3Pjr0butC+wd1Upiwa0HVLg'
                    'qlY3WM17uLQo0fFIzRfWCli0L1TgpjqtxFYedr9eHPTNcE4BRcTZ0AcBaeT51AF8'
                    '0fjqYocBFNj64Jm+ba/aD03dyz78yw0UWhZieFmsboOlChi8LOcFN1UTidTgq/De'
                    '+XAYCOdE4AZqXrxdQmml8dCNQu7JtIkf2pybxzv2QOq3F6dFFYHt2sPlgmn545HY'
                    'wX+2PuvUt+QNxeancfWInf6+vucc4oKp93oJPCos6pAKO6nToB4Cy8mDqBE/Is2h'
                    'nupe52Lt39oFQR8ey7HpSOuRKs1p3sY9yhP0bXgcJfx95wU3Q1mEMnhWFn30XEZY'
                    'lUAIDzoHMCcIxedr4rfOibuwL7B9/BPlEXheW2ip0UanQR6PRXomcnhRrG6KKw0k'
                    'lhjHNGUfm8La+VrgnAqbieOgHgLDydOoET8jo2X8+SHQtKxZljrNWYpRWNudFJoY'
                    'bad+iP1QGgQieFsc7q5Hi7KFyGAlgAIIPiBOAYfd7+ptOFZqMeBsfZmvcRj3pYLj'
                    'Pqoco5J1KksPFaLeqcAh9896ejaS3NcbudOgHgbLyYOoET8DzargmbSl04nWthwd'
                    'mNemgD1oi7ccSpFCkUDHWwSGFMxzfq4X3omgAAZFKcAMxL6vTx8vE2RQrZcbK3VO'
                    'yiUDpWx3i9uygcY5HCRheF6kUKY6rbRUHXBOCUXE+dAHA2nk2dwAlYxKEuFHMtUi'
                    'jl7IoUNroo1CxSqGmMC+wVuijsDDdVF4WpixS6WYTiVwAg05OpEwDI9CwifvlwMX'
                    'LjDVOKtH1e/PqirXs7K7Q/NR1y3Rdj6BvVnl9He1F7Lfehr8n6AWXfhHfIbevXVC'
                    'BuL6W//m3xY3lGp/+/FDhnFPXOe1O1kANgfO8j4tOpkwBO3ouIuJo4h52aP8y+Y9'
                    'HziPh159WlZtbPLc5qvJLfkpfOr3jMlWA1ct04oprSf267zohy5+xNeYzXbA5ndj'
                    '/7fUS8GSMVAOC06JwAHJuXa59tudu8813hQ9/cFdg/my4KJUc9TJjTwZgHl/TspF'
                    'DaWKMehv4dzDhnNGXPexcz/qE6QE83UycAnIVnUydw5C577Zpb94M5j3poY5ZWY9'
                    'RD8bgbRxj18CjUwVEPU3RSmMrur/f1qHkAACdDcQJwbF5ufbRvkYJRD4Pi7Mz7iE'
                    'c9LJedyaiH9ow40SKF4RZFogDMy/XUCQBn4cXUCRyxlxHxq9675zrqYY6xasQrHn'
                    'PEUQ/HXqQw5qiHOPRkBXMY9fDh/HcR8XaqVACA42asA3BsXu59dktL/LMa9TAkh9'
                    'U4cxz1UCpWx3izG/VQI+6W+L2+7tyzjmPUg64JwKm6nToB4Cw8mzqBvaa8wHfYIi'
                    'LmM1qhZFv5km3+a4yOKBmveMwRRj20x9Qe9RDHdcbecOc26qE9PynkBwD6U5wAHJ'
                    'NnEfHLg6u2XJDsfMF16IXTAvvT/Q8bBhUplChQiPw4oxQplPxBYs0ihRo/8Kx9YX'
                    '+jSKFqgcL9OaPod96ieB6ww7dffzt1CpyXq4j426mTAE7ei6kT2KX5w3dTp7DPy4'
                    'j4LCLKFhfMqbCgRlHBbAsKVmIWi7dRpFCrQCEqxV49o/bF9QpFCjtDnVeRgkJ+AG'
                    'AQxQnAMXmZtbpvkcLUXRTuY6RmwB3sJbso9Iiz9cJ2qQvrNS5sd8gtu0jhWLsorJ'
                    'wx6O9gxjkzLFLwwxbglN1OnQBwFp5OncCRunz0SIkLkHPtojDHWKsxZ130cJ9g7S'
                    '4KtWKPEX/1nDG6KBQ+q7Pxz3w18+4zAMDMXUydAECGl712bZl1n+7/l7tv6Ll99n'
                    'fKtVYOA+JszbtUPqVjZcTL/rMonWftuJtnxMC/g13PGfOHKYfPWtRPAmAy11MnAJ'
                    'yNF1MncGRexb5OgSUuBpaaWV8qzpxj1YhXPOZKsBq5rh5TU83cK52xN9wYX890Z3'
                    '4RETejnAQAnCydE4B52X/R8EVEDOto8Ohm/g6t66fupLByF/ugUQ9DcliNY9RD/1'
                    'EPB+L2Urv7wMaoh+VvK3ZSmL6Lgq4JwDm4C3c1A/U9mzqB7eZ4y2+K6FIgO7cOCK'
                    'W7H5zbqIdiMTdGPRSLu/2Iao501MPOcKc56mFRLTIAcDZ0TgCOyXL25pC7rPt2UW'
                    'j3DlFg/+A72CfqorDcVrGTQo077zt2UejVSaGGMboorHRSGOOcUTw+bzHi6QBTuZ'
                    '46AeAsvJg6gSPyOiI+7by6ZAeEEubY+WD2XQ9WYhYNttJJoYbad+iP1QGgQieFsc'
                    '7qpM55vw1dEwCAAhQnAMfi5aNHpihSMOphcJyteRv1UMZYox5KFMp0PGc0y/N0TQ'
                    'DOxc3UCQBn4dnUCWxq/vDt1Cls8yz6FsiWuOhp1EO/mKXjFS9SqBF344hTKVIoGO'
                    'pgkcKYyr6GdxFxWSwaAHDWjHUAjsWLnc8MaQW/Y9RDxIHW9TMa9bAM0yNQyVEPmX'
                    'FGGfVQKlbHeGc16qE949RGPUS8GbUgAiLi2z/O8iIJp+9m6gSAs/Bi6gQemeNEh4'
                    'jXkZr7UTs9vxkt0Q7/HEY9xIzjFY85wqiH9pjaox7iuM440VEPlxFxOzATAICI0D'
                    'kBOB4v9z5buIvC8uGOox5m0klhshxW42RvqTjqoY1VUofceo96OMZOChujHqp1Uh'
                    'ini8L7iHhT/RSAebieOgHgLDybOoEj8CwiXn+4w3nArc5z64Awtzir8Uqa/fiIjV'
                    'EPNQp0xuhycKSjHnaGm2rUQ78z34euCQBAQYoTgGPxotOqKUY9tHuHKLB/8MXhOY'
                    '56mDCngzEPLulZpFDDSKMelr892lEPi2qRAebnduoEgLPwYuoEjsBlRDx9+KxZ/c'
                    '0MihRKmON4hmMY9VA8ZrP1t0Wd0qiHwkUKY53VSf55i/C9IwBQkOIE4Bg8i4hPs3'
                    'ZMUaQwoy4KvS8QT1gQsDPvkl0USl7Y7hjvbLootGdE5S4K7Tllw+uaAJybq6kTAM'
                    '7C08NLztrziPj1o0fXLlYOuGpZ4qLnHLsfzDVWjXjFY47QRaF27DHir55TMNTBIo'
                    'UxdX8NvVcGAIpTnADMS9r68WJQocGQXB49dFyjHmZRpJC9ZYRRDyMXKRj1UPGsMh'
                    'bFIgEcj7upEwDOwoupE5ixxd5nS4x6aLcPNdcihVIUKdQxxqiHIzvjCEc9vB4lDw'
                    'DgrChOAI7By4jof1F1ylEPMylSGBRjqAGjHqoXKZR0jEUKNR3PqAd3ggDn6nrqBI'
                    'Cz8GzqBFrNP387dQqrXsa2rgnblChSmOOoh7kVO7TxSlKkMF4BQW3nMOrh8ZnvIu'
                    'LtyJkAAGdAcQIwK2n7/16sXdwsWGgwZG9WkcIQBfbPpotCzyKFrbFKqHHhv+Ooh1'
                    '5FCqWNNeph6N/BjHN6WBTNAzJ8+8dZXSTh/NxMnQBwFl5MncCDZkYffb4HPbVRD2'
                    '2sUnHmGGs1ZmlFYzZbf1uUUQ9bQ82ySOGDxcinAwBnQnECcAxeRGxc3BxaaNBX3y'
                    'KFGXVROMYihVMc9bBcNqMuCmMUKcTsihR0TQDO2c3UCQBn4dnUCczQy4j4rNdOox'
                    '6OM1aNeMVjjjjq4diLFMYc9RCHnqxgmdCXEXE18skAwJl4MnUCAB18uvpJihRN++'
                    '6svQiZ+2at777V/c3mQyt51Ty3wP7UdMi1Vg6rcTJjtBe113IvlU/pWB3jbf2aCs'
                    'TtpVbcLfF7fd25Zx0OvahzOMBRuJk6AeAsvJg6gRm6jCaGFQe33+emh98MiDEgjz'
                    'nGaWOVqocumVeNeMVjrgSrkevqMTUL5GvmXumMveHG+HrWvR69KAIAOBs6JwBz93'
                    'Lbg4/uvu575/c5j3pIA+9gn3jUQ/VOCiV1yG02ox5qxl2Nv9JJYYxzttA1ATh3N1'
                    'MnAJyFZ1MnEBHR/PfZjFJ6FRG/jIhyIxaGBivZAaGEOXc+KGn24yM2OinUMFaXg9'
                    'oqdFIY66wdvgjfJwIAFSlOAObuxb4ntxYp9DFFkcLUox7uYxzrqIflti2b5jrqoY'
                    '15cEnmn8exj3oY+ncw45wNl/UOhMO+/eNsLpJwvq6nTgA4C8+mTmBmFo8eGXqxcW'
                    '3/wFEPJYoljHrIj1k6XvEihRpxN4449lEP7TkFQ0006uEudBgEACpTnADMS3r08T'
                    'z7gu7QQoO+jrVIocQF4gmLFEbpolDyunnHeL26KBxzkUKMWqRwF7omMLGPPvlo6h'
                    'TgduoEgLPwy6kTmJFXsTGycE2xIoWBgeZUXDDXwoIaXRlmXaSw0UWhZpFCTWN1ah'
                    'irSKHO13MZuiYAAJUpTgDm7kVEdL44Ovmoh3b/o4c6jnqYSZHCZDmsxsneYtRD17'
                    'i91C5S2Bj1ULlI4TJclAOIiHg3dQIAZ+JZdO3cVax7wUxGPcwpThurlFkXFNSIOU'
                    'KRglEP+eHKnXUXOgwCACN4MnUCAAe8ePhde63ywJuu9qJm0y5Mh/fsCNTpvK57H+'
                    'W1b++QN5YF9qemY661cmhjRH6cra/zkD/LAjkdjJn7d7pQ3F5qxV2NH8szUqT+fw'
                    'd3W/7ApXY3CDjg23811oFZuJ06AeAsvAijZF5HxNPOq9tvgYd8z9q0+wcEK5HHWi'
                    '4zihMzjLUas/T7laIxV77oGrluHFFF7fiVztn7cg8/6zJ8bwgAjEDnBGDOnsW2H+'
                    'BktMUvNuqh4F6jHsaJszVvox7KGGvUw9C/g9tdhh+4ALSup04AOAvPpjy8+e+TFw'
                    'Q+i2VxQr5iox4iBgUqcWf2XLsozDFWjXhVYo406qFmcfwYnRracwqG2huu31nvI2'
                    'LRaycAQCadE4A5e7H32Y53cK/ddT60G0LfN5Rb9na6G37onfqF9g/qpDBh14KqXR'
                    'RKx+oYr3cXhQNxe6kVd/OMpufX/Zg2lQDrbqZOAKC6MS487reIiKdluiAM2B8RkQ'
                    'beWl3iLvmS3RhKxGljlaqHLn1Hfq3ODMVibnRRKBZ3yzE1C+TH6KRQoYvCznD5Zy'
                    '2GZQMA0J3OCcCcPT+4IuMO7rW7r/ve+V2hA0Onu8Jn1ElhshxW42Rv2XL3fcm7/0'
                    'v/AKNDbr06ChxrJ4WV+AM7KVyGrgkAq26mTgA4Cy+nTmBCzyPiryOicBeEoTEGBJ'
                    'tbB4S5xVmNV9LsOymsBKvVjWCMLgdjdVEYq5NCt7PeR8SbYgkBABygOAGYs+edV/'
                    'YZ9dDu62OKUQ/t3iEK7B/cZn+Oox4mzOlgzINLehYp1DDSqIflb7MP0zWB2fj2Xy'
                    'dvLw2tm6kTADhxi0ePzKVIYWiwkkUBJcxxPEOtgoLSaox6KB534wijHvLC7f+aXp'
                    'XNBABgP8UJwLyktY+XvfcfXLZyQXdooUFffYsUZtRFoXeRwoQFATvzLtlFoeRF+o'
                    'y/0zXiZqvdRaE9I7L/Dl6GrgkAm26mTgA4C8+nOrj5/aQFgS8i4tc7ny3WBaHE/g'
                    'GBinZ0mEmcOceqEa94zBG6KNSOPUb8CmccDPf4yXcRcVUuAwCAwxQnAHP2rPeFzm'
                    'MZ9dDuf/TQcY16mEWRQvaWEUY9jFykYNTDTromAOz21dQJACfv+dQJTOTy4IqiXR'
                    'AG7B866qFEHgVSKB6njVWKIoU6jqyAYIwzMkY9LMqdCgDQjeIEYM5++fC7Phc6h4'
                    'x6GLtIYepRD4WKFAbFGGrAqIfqRQolHWORQk3dRj28CV0TAHa5nToBgBP0MiI+67'
                    'zaqIcduRSIM7dihzZeSbMfH7FRpFDDWAUEtVUoUtjz5JehawIAMIEnUycAsMOzrY'
                    '+myH+j1l6vPLCvvbDZtAv7nJVxXte9j/IqfeZqjIH7U9Mh133nx8AcBsRJkR7nPf'
                    'Q1GZjTwZi5f6cLxc1W4+vfccaOv4OXFU8GOHZXkXMBDSDfi8lOHuNi4jap593Ibb'
                    '59C3yL7m/6BxqaR6kYq7FKxYkZxlqNWTpelIx5n2CNr331iFqxx4i/ek6hM/ak/H'
                    'qyfyMBgLOmOAGYqxc7n+l7obNPkcLQQoO+b/SmKlIotP9YixS2vsYlL6yXvkif8X'
                    'c6u0ChQ9xsYxUpNGt/ll+EmeoA+9xOnQBw8p6e2QWwV9HEZ4MvzE95Yf9h/8BAJS'
                    '6wlroYPNfCgtIXu2sVPRSLuRJMkcKoZ2yE8z4ZAJiM4gRgrp4dXDGkSKHDnrULup'
                    'ULIvbuf3Qzf4cLzTMqUuhVoFAih9U4PbooLI+uWKRQuotC7I/Zu4vCgbi91C5SWI'
                    'mfIi0qnQK9fPM/v5k6Bdh0PXUCwFl4FudTDLWIiOm7ILQxihQ5DEhmbsUFc+zI0M'
                    'aKGccrHnPEIoUjKiAY44wm4i6iZ3cXAIACLqZOAGCHF51XrsycL70n3f9v0FlD9u'
                    '3Y+yivfXuHKLC/c661cmhj9IizNfchf5Y14mzGPLikx59HrR+01G6FmdwNAtDBzd'
                    'QJAGfhxdgHNr//duwjIyJeRcSn64nEsKLcqfe3MYYGK5HHWi4zilOy6Lp0AXfp/N'
                    'qYRYM1FeJuP6KaMbrDlPs6LsP3fwDAhHROAGYlpYerlc8iIpom8y7vMUY99D0r47'
                    'yue416GCfO1m4VpbofTDjqYbms48HH2UVhUb0AAuD43UydAMCJeBb77kYu0UlhFq'
                    'MeBiZTqiPE0Bgl48w51mrM2XZRaAMa9dD5nP5n3MWyOAEAYDI6JwBz9SJirVihmy'
                    'GdDTotW7nrfGg3hL76dlIYeqd+of2DOilM2LWgaheF0rEy4vXqolDjhy3l4+qaAN'
                    'Dd+6kTAE7ei7EPbEb+iIjXsdk1YVdiQ7+oIYp1YhgYqFQXhTnFmXOsGvGKx9zool'
                    'Czk0JNY3Vq6HfGZZzPiB0AYKYUJwCzl1Iap0ghY8/kox7a/Y8e6jjqYSZFCpPlsB'
                    'one8sIRQoldcit96iHeRcpLIpEATgPN1MnAJy8Z2Me9t34Ix2eNRGvO18rnNWohq'
                    'E5zGTUw5zitLFKmXVBQY2YIxQpjFVAUFve1/E+vE8GAGZAcQIwV59tPtC7SCFXxh'
                    '3nj4oU+hjagaFPF4V27xAF9g/qolAihzbG3IoUalz47/N3ulDcXobF1TUBIM/11A'
                    'kAFDV224QmXkfE09Wjs/Lsa+r9bYyhwUoWF5Qwx84HtQoKSisac6NIoYbaRQpjFE'
                    'F0P2dRPQ8AgA4UJwBHJ7tIoXJng6KjHsYuUphRF4VjHPWw3La1hUUZRj30jbsomg'
                    'cU8s3/+GbqFGCX26kTAE7ey6kTqOh5RPzt5oXBrOuRJYoMhiha5DBw1MPUX0vpOH'
                    'OOVSNelZgjjXo4lSKF7b6KiDcjZAAAcJDiBGCOnndZNMqoh3Zfp2UFixT62jHqQZ'
                    'FCZpzsLSOMehi5SOGIRz18GbomAOS6mjoBgCO2ePjdxgXI7OuRs+mCMDSHgcnMqb'
                    'hgzqMe5hyveMwRRj20sWsaa5zE4zNeVz4VAKAzxQnAHD3vurD3qIfcC6gZex6Neq'
                    'jYtSFnb+dRDzMpUhgUY6g5jnpoY5V0mkUKlxVOBjh1t1MnAJy852Md9N3/79uxjo'
                    'pYfl2/fvTokCKFqUc1FO1eMJNRD6cYZzVeSYoUxisgqO3D1/EuFKICADPyZOoEAN'
                    'asXnjMeLPWFig0Tc6mvDMe9sThfe3F3KZd2OesjPO67n2U1769Q94sF9ifmo657j'
                    'o/BuYwIE6K9DjviXM6GDP373ShuL3sjuuHLgD9XE+dAHDyPp06gUre7H22/Z41ff'
                    'i0cw3vxt5sU+9vY6SBwUrksZbLjOLEDGOtxixdcF405kqwGrm2caNS7DHifzhnUf'
                    'kEAIAsOicAc/QiInrdfT3qqIdOjQhmMurh0c38Rj3UjrMz7yMe9bBcNusuCosKJw'
                    'Gci/dTJwBwZF5GxGedVk416qHU/mKdGIx6OJpYNeIVjzniqIeanQ7qxv8iFPADAD'
                    'OjOAGYo2drn2Ve3Bxt1EO7r9OyiUc9tPsfPXRGox5KFSlkbxlh1MPIRQozHfWgaw'
                    'LAMDdTJwCcvBejnNKM9JFbGLtxATLremTRAoEBMYbubwYmM7figtKFBaUoUqijZo'
                    'FCG7/8GYviEQEABjLWATgemS3ie496iLxzuu7ZOuoh96wh+3bsHXXUw8bZuftTpI'
                    'gmc7TAZg5D3+wPGPWw3Lb24veKteOAsj/I6JDbzEY9LCpEhWK++Zdvpk4BDrmOrn'
                    'cAA/TzbOoECvo8+v6budHKPauz+9A28FPvb2MY9bA7ThSK1cYrPeohKsQsOuohlg'
                    'FLf+1bjqimXO5fhOJTAGCGdE4A5ujFzmd6jnro1UkhV59RD33Pyjiv695RRj20MQ'
                    'buP9ZRD8ttRzTqoY15cEnmn0f5PHVNABjuduoEgJP3bOoECros0s1g96eH9xY8u9'
                    'f+Yp0cBgQq1RFijl0U5hhrNWbpeEVjjtRFoWYnheHx7yLidYlUAABKU5wAzNGzgy'
                    't6Finkbcg/I2ff2gXdoYUGfU1VpFBw1MMxFimc4qiH5bLJRj0sikQBOG/XUycAnL'
                    'wXtQ/47r99W/uIiIhXEfHpw2dDLiIOGfXQbuhrDhf2S4x6aLcPpUhh2njFY579qI'
                    'fLUHgKAMyU4gTguI3VRaFvkUKnZRtdFCoWROzd/+ihTlejZ1OkMFkOq3Gyt4xQpF'
                    'BSh9x6FYwM+5p1TQAo43bqBACOwLPYVRg7VZFC0S4GA2IM3T+0SGFuxQWlCwtKmX'
                    'VBQY2YIxQp1O6i0J7R3V0sixMAAGZJcQIwLynyL1SOOeoh9wLqkFEPYxcp9O2i0O'
                    '4dYupRDyVyaGPMrUjhWEY9dIy7xaLXLgA2XU2dAHDynk+dQAGvY7VrwjYFCwWOqk'
                    'ihaJHDTIoUSphj54PZFxSsxCwabKVIoYb5jHpYhKJTAGDGFCcAc/RZRFQrBFjb0r'
                    'dIIdeQIoU+pihSmFEXhWMc9bDctrWFRRmnOerhq3AxDaCku6kTAE7a85rBRxjp8C'
                    'y6znAvcaF/96ejnt1rf7Eih4GjHqb+WkrHmXOs1Zil4xUvUqgRd+OI6YoU3oeuCQ'
                    'DAzClOAOatYreCtS0zHPXwcFF3aKFBX4oUhuvzd7FmF4XSsTrGqzjq4TIvKEzjm3'
                    '/5ZuoUoKvrqRMA6K2p/LEsTHjaK6chX0/fUHPoglAkh4GB5lRcMNfCgtIX02ffmW'
                    'GEUQ9t7Jq2576ofCoAwGCKE4Dj0LdIIWf5zEY9LJdOPOqh3f/ooY6jHmZSpDBZDq'
                    'txsreMUKRQ0vhFCu8j4k1eMAAOuJk6AeCkvZg6gQGeRxOvSxUaDNl7VKMe2hhD9w'
                    '8tUphbcUHpwoJSZl1QUCPmCEUKtbsotGcsfRXeIwMAR+DJ1AkArGovXDa73r2lyH'
                    'tj117UzNjTFig0Tc6mvDMe9sThfY9ekz5nZZzXde/BP6vVvUPejBfYn5qOudbKoY'
                    '0R+XG2vs5D/iwL5HQwZu7f6X5xF1l5AdDFzdQJACctr+vAvCyizb/9nrRPsW/Tc9'
                    '+Wc7PSGJLzHPa3MdLAYCXyWMtlRnFihrFWY5Yuji8ac+WLrpHrxhFVfOjuAgAwez'
                    'onAPPyMMlgzx3WI456yOqkULmzQdFRDwX3GvUwTpyteR/xqIflst5dFHRNAKjjZu'
                    'oEgJP3bOoEengeEb9+9OgUXRS2nJs96qHg2b32F+vkMHDUw9RfS+k4c45VI16VmC'
                    'ONeqgT+11EXFWJDABQmM4JwNy8WP0kRdrfRSFilE4K2V0UMs942Ndhz9pd50O7If'
                    'R9U7xlb6e74YfeqV9o/6BOCiW7Fsypi0LpWB3j9eyisOidE4zsm7tvpk4BctxMnQ'
                    'Bw8l7E8V1Au9z5zNAuCoX2Zocq2MGhd4yh+yMi0sBkStwlX7IbQ4k4baxSxeel7/'
                    'iv1ZmhWMyNLgrF4m45pmzcRdFoAAAVKU4A5ubZ5gXNTqMeVtZ3knlhuPeoh8g7J2'
                    'fPWuHGkIKIPvv27N1bUFLi3IL7U9Mh130xTnHUQxur9KiH2B8zo0hB1wSOS627rq'
                    'COm6kTAOjju//2ba3QLyPiVwdXHWORwtSjGkoVOUQMK1KY46iHKBCrRlHBbAsKas'
                    'QcoUihXNwv4viKvgCAM6Y4AZivPkUKI3RRiOhRpFCpaODRa9L3onLhIoXOF5qHXg'
                    'QvsH82XRR6xNlaCDJxTgdj5v6dfmxRMCMA1t1MnQBw8p5XiVqrGDC3Y9fQQoNCF/'
                    'qzQk1dZFC0E8PERQpz7H5QOqdSsVZj1rjoXyzmSrAaubZxY1DsRZE8AABGcjF1Ag'
                    'AHpc1PU+ycVf9hJn1e/Mw9bZFCzTNy9q29Jn3Pavf2teXcvX9We/YNPbfP/k651s'
                    'phQJydeZf6oUmpry0z3o4/C10TAOq7mzoB4KQ9nzqBDC+jic967exbLNEM2Ltxbn'
                    'aooQUeJfYP/dqb1U8GxBlq6NdSOs6cY9WIVzzmSrAauW45JsPfh+JSAODIKE4Ajs'
                    'OOC9856/ucsXd5SuMWKXRallY/qVoQsXf/o4c6XY2eTZHCZDmsxsnesqVIoWRhwQ'
                    'RFClu+pkXBDADY7nrqBABm4k1E9L8YOeQiZsG9WaGKFggMiDF0fzMwmbkVF5QuLC'
                    'hFkUId3ePehffIAMARUpwAHJeNC5oH73bvW6SQs3ysIoU+XRT6njVk3469nTsTDL'
                    '0AXmB/SgO6KJTIoY0x1yKFkroXKeiaADCO26kTAE7ay9IBv/vdt6VDRkS8iohP1x'
                    '6Zqkihr2MuUiha5DCTIoUS5tz5oKRaRQpFg60UKdTQ7TW4DN+3AQBH6MnUCQD0km'
                    'LtjdrBOfUb6zvFj7w9bYFC0+RsyjvjYU8c3vfoNelzVsZ5Xfce/LMaemaJ/fcxUt'
                    'Mh15o5DIiTIj3Ou+/fgUI5HYy5P96bQQUjMIF/v/33qVOAPq4j4ldTJwHQXY2rg2'
                    'mx97g+35a2aebu7btvdX/a+emoZ/faP/T8h/0DkhmaR6kYJePMOdZqzNLxomTM+w'
                    'RrfO2rR2yPfRfL4gQAgKOjcwIwLzlv5mY46iEixh31kNtJYWg3hL76dlKY0aiH3h'
                    'fGS456yP6rdTKjHvzgBWA8t1MnAJy0Z1Mn0MEiovl074opuiFMNeqh3dBXqS4IRX'
                    'IYGGhOIxpKj3qYY6wa8YrHnGzUw+vwPRsAcKR0TgDmJ/eu7I31nboo5MRv94zRRS'
                    'HyznnY12HP2p30Q87qs291/6Ob+bfc4V/j3AL7U9Mh11o5rMbp0UVhefRaC4sy+f'
                    'TM6WC8WIt5GX7wwlGq9dNJqOp66gSAk/bLksEqjHR4FsuLftHpdugpuiEU3JsVqm'
                    'gXgwExinQvGJDM3DoglO5+UKr4fPZdD0rHXAlWq5PCh7hGHgIAR01xAjBfcytSMO'
                    'oh+7yuezuNemj3DhzVMHT/oFEPJXJoY0R+nKpFCvVGPeiaADCu26kTAOisfB3g60'
                    'jxdPshMyxSKFQocFRFCkWLHGZSpDCnwoJjGPVQI2bRUQ8RD0UKdUY9LCpEBQAYjb'
                    'EOwPzlto7PHR8w0qiHrHEPxzTqoeBeox7GibM17/mOergMF8oAxnQ9dQLAyXsxdQ'
                    'I7PI+I17tbs3eohDimUQ9bzs0e9VDw7F77i42bGDjqYeqvpXScOcdajVk6XtGY1U'
                    'Y9vAtdEwCAI6dzAnA8cu4433F3fvFRD5l7UkqzG/WwDN8M74ZQeNTDQ1779sXAcw'
                    'vsH9RJYcKuBaOMehgea9k1ocbdJgDscxexeecwQDHPpk5gh0Ws/tu39a7nGXdRKL'
                    'Q3O1TBDg69Y0w96qFEHmu5zCROG6vkqIeYcbziMauMelgMjgAAMDGdE4Dj0qeLQl'
                    'r9tEMXhT6dFHKW53ZRaM+o2OEhrb9IVbs25Ozt1JlgRp0UJsthNU72li3/nyjZ/W'
                    'BYnMvQNQFgCtdTJwAwsucR8etHj+7tonCgCrfvHdND7rQuuDcrVNEuBhPsX4sxIN'
                    'jcOiDMLc5qvJJqdWYoFnMl2LC47yLiqkBCAACTUpwAHKcxihRq5hMDihRy9Rn10P'
                    'esjPO67u08PmHoxfQC+weNeiiRQxuj5KiH6XJadk2AI/Xvf/jz1CnAELdTJwCctJ'
                    'dTJ7DFYu+zx1ik0JciheHBShYFlDDH8QzHMOqheMxm628zvC6TBwDAtBQnAPMysO'
                    'ig0/q1T/dcTK7creBhyxhdFDL2rb0mQwsN+upbpDCjLgq9ixQmLAjYmXfJLgrdY1'
                    '2Gi2MAU7meOgGAQ777P74tFeplbOuasM3eIoUOe/uYoovClnOzQhU+u9f+YkUOAw'
                    'IV7egwkzhzjlUjXvGYvbsofBG+PwMATsSTqRMA2CpF3pu/nPXtxdFm9aEUza4AW9'
                    'b3OWPv8vsChabJOKRPXu2+Dnvai9RNNMPO6rNvdX+z+dCeP6uS5xbYn5qV13DsHF'
                    'bjZMZY+7MvnU+3WLomAEzrduoEgJP2okiUchcgF9nFuE1sKbptE9oTrMOSovsK78'
                    '0OtfV16nd27xhD90dEpIHJDM1jLZeZxGljlSpkL5lXjXjFY64E6xZ3UeJUAIA50D'
                    'kBmJVBd+2PMeqhTyeFnOV9Rz1U7PDwaNRDxa4NXfdmjXqYSSeFQTGGGjDq4VHupT'
                    'o7tLG2exsujAFM6XrqBICT9mzqBFa8jIjPet0ZfYyjHgrtPctRD83AYHMc9TC3jg'
                    'xtvJJOo5PC30fETakTAQCmpjgBmKXZFynk6DnqoVeRQq4+ox76npVxXte9WUUKQx'
                    'TYf6yjHpbbRh/1sCgUHSbx73/489QpAMCcvZg6gRWXa58VLRioPOph7DERW/aOPu'
                    'phDkUK67+ZLo+SRQql4swx1mrM0orGbLb+NpZdBRclTwIAmJqxDsCsrbXwz20rP3'
                    'A0xNSjHiKWRQqjjXrosK/IqIf2vIIjF7aOIeiwb+i5ffbPZtRDZpwRRz18Ee4KAZ'
                    'ja1dQJACftaZULhfleRcQvHz1adPRCxVEP7d5zGvVQan8MiGHUw3HGqhGveMytox'
                    '4uQ1dBAODEKE4AZu/RRdGcC9t9ChpW1h+86N23SCGzQCEixitS6LBnUNHI6ll99q'
                    '3ubzYf2lNQUvLcAvtT0yHXWjmsxsmMMUKRwqJAFJjWPC64AMCcvYyhhVBD/nu7/P'
                    '510Sl+nyKFR3sqFikULDQYsjcrVLECgZ772xhFihwGJDO34oLShQVzLSo4niKFu2'
                    'g2ursAAJwAYx2AeUm7K8JnP+qhZj4xYNRDpTEUW0c9VBwt0XXvUY16SANGPZTIoY'
                    '3Rc9TDo9yHj5/QNQFgPt5NnQDALt/912+HhngdEZ92Wll81MOBgH1b2k856qHZ+W'
                    'nW3qFnj76/jTE0WKkxBqc86qGNV9Lsx0c0r0PXBADgBClOAObm+tAFzkEXxPus3z'
                    'j7YJFCjjGLFHINKVLoY4oihaEX04dfjF8WKXQtqKiVw4A4W/Pun8+i904AAI7Jyw'
                    'nPfhZN5vedxQsGOgQbUmgwdnFDu3/3p6Oe3Wt/sSKHAYFKFUuUKnSYY5HC7AsKol'
                    'SO7yPizeAoAAAzZKwDMF97WsVvHfWwY+3O2ANGQ+wdH9B31EPmnpTSeKMeOuxb+z'
                    'MZ0ua/x6iBtb0b5x4czbFj39Bz++xPTYdca+UwIE6hUQ+6JgDMy1VEfDZ1EsDJej'
                    'bh2a8j4mmvtvPHMuph55kd9w05c2VvdqghowBKjXoYEqPEqIc2zlxGNJQe9TDHWD'
                    'XiDY+5WA8CAHA6dE4A5u9AF4Xed+3PbdRDuydn+VijHtp9nZZNPOqh3f/ooY6jHq'
                    'bspHC/f/Coh1KdFLK3DBr1sMg/Eebn3//7n6dOAQCOwYu+GweOdHgWy+KEpTG7DB'
                    'zjqIdCe49q1EMbY+j+ZmAyc+uAULr7QSnz7HowNOa70DUBADhhihOA49Bh1MPDRd'
                    'ExRj3kFinkMOoh+7yuezuPTygwqmHo/kGjHkrk0MYYp0hB1wSA+bmaOgHgpL2Y6N'
                    'zLiHj66NEhF//77Dm2IoW+jrlIoWiRw0yKFEqY43iGYxj1kBdzUeF0AIDZUJwAHJ'
                    'cORQpd1+bG3rp+4+ydF5P7dlGoXaRQubPBoKKRHud13dvpwv+Muij0LlIo2UWhZ5'
                    'HC1liPLfKjAwBwxJ7G+KMdnkfEr/euKNoRoe++DsHGLjQocaG/bxqFz+61v1iRw4'
                    'BApYol5thFYY6xasTrFvNdKBAFAE6c4gRgjt4dXLHnYungu/YHFjRUGfXQo0ih9h'
                    'kP+zotK1ik0NeOUQ+KFOrG6dBF4cvQNQFgjq6nTgA4eS967Wp6fuQUxI7ZneDYui'
                    'hMMeqh3dDXqYx6KJFHgRSKx2ljlXLcRQqvCp8EADA7T6ZOAGBNe8Gy6xu/tHtte0'
                    'G0iaZf3AHr184uEb/dk7G+LVBompxN97/m5tVxT4r04TXpc9aQfXv2ruVV49yC+1'
                    'PTIddaOazGyYyx9f8Ty4cuB2YDQB23UycAnLwXMd4dwi+iiV9nFdq237bmFvn22b'
                    'dzT4dgY+ZZYW9WqCHnzmH/WowBwUrkccpxVuOVitXGi6oxjTsEAM6CzgnAPOXcod'
                    '1h1EPvu/YHrj94t/scRz205+TqM+qh71kZ53Xd27kzwdAfRBTYP6iLQokc2hjDRz'
                    '1oWQkwb3dTJwCctOcjnnUZETPoiND3rBl3UuhrSyeFvnuHnj36/jbG0GAlOyCUUD'
                    'LOHGOtxiwtt7sLAMARU5wAzNHtw+8KFyn0itt3/cbZOy8mn+Koh9wihSlHPfQpUj'
                    'DqYVCclbwXBTKA2fj33/956hSgtOupEwBO2ovcDd/979/2OedlRHz28NmYF/GLn9'
                    'Uh2NiFBiUu9PcNVfDs3vuLFTkMHPUw9ddSOs6cY9WIF/Hb0DUBADgTxjoAc3QdEb'
                    '9aeySnjXzXUQ+5cfvkEevr944PqDxSIWLEUQ/tvmMY9dDuP/JRD8swPQJNN+pB1w'
                    'SA+budOgHgpL0Y6ZzF1keHjEMYa4TC1rOMeti6f+pRDVOPeiiRx1ouM4nTxio56i'
                    'FmF+8uIi6rdGQAAJghxQnA8ci5iHpg7VqRQu7F2YHrHxVIDI3f7smpNxirSKHjnq'
                    '1FI7lnDdm3Y+/BP6vVvUN+kFCwSKFXgUIbo0SBQnSOsxg0mgKAMVzHZsEoQDlPYz'
                    'na4abiGa9itWvCNmMXG+Tu27lHkUKxc+ewv42RBgYrWVxQqrAgCsSqUVRQ8u3osP'
                    'wuQ0EoAHBGjHUA5uh277OFRz30Hi0wcP3BlvwjjXroNe4hV59RD33Pyjiv695RRj'
                    '20MQbuP5JRD7omAByH26kTAE7ei8rxF51WjTnqod1X7KzKox7GHhOxZa9RDxPkUS'
                    'rGaqxSceYYazVmnvexLE4AADgbihOAWbm/WH7dbXEULVLoFbddn2PLhe+9a0cqUq'
                    'h9Rs6+QUUjm+f1NVWRQqH9My9SWBSIDrPy59//29QpQA3XUycAnLwXFWO/iohPs3'
                    'bMotigz74OwaYoNBh6ZrPz0277+5rDhf2H/QMDlbj4Xuoi/lwLC0oXKeTFW4RiUA'
                    'DgzChOAGYp62J5oUKCQXftj9FFYWARxMHlfbso9C1S6LRsQNHI0H2r+x891KnCYj'
                    'ZFCpPlsBrnA10TAI7H7dQJACfvZdeF3/3v3+bEfRZD7kbuc7FyFt0XKhYpFCw0GL'
                    'I3K1TRLgYDYgzdP7RIYW7FBXPsyFA6Vhtvf8z3EfGm8KkAALOnOAGYo5uIzIvl5z'
                    'TqoWY+MWKRwpBRD2MXKfTtotDuHWLqUQ8lcmhjLOMsCkQDYBzXUycAnLwXDxfwDn'
                    '3keR0RTwdnN3mxQd+zZlyk0NcxFykULXKYSZFCCXPsfFBr1MP2mK8LnwQAcBSeTJ'
                    '0AwBY3q5+0F8qbpsM7xPYiapc3kwfWpkjRtE/mxO27vln99P5r3p1c3hvm3Hwi83'
                    'VfPSf3jXzH3B69Jn3Oyjiv696Df1ZDzyy4PzUdcq2Vw9JXoWsCp6r0DzFhPt5Hbl'
                    't0gO6eRsTz2HgPONCzKHnRr/1vfG7Bbp99xc9qDgfrsCTvzEr7VvennZ+Oenav/U'
                    'PPf9g/IJmheZSKUTLOnGOtxvwQ711EvC0YHQDgaChOAI7GFEUKWy+Id43brh9Q0L'
                    'BWINFhfZ8zDm5JKb9AIfOMh32d/mhX/kyGFhoULBZQpNDJZdEf7gAwhptQnADU9T'
                    'LKtjZfRImuCZuGXIwf6wL+1rM6BBtyIXbs4oYte7NDDSkymMOF/Yf9AwMNLbZYy2'
                    'UmceYcaz3eolBEAICjY6wDMFfvdj2RNXIgdwTCzqe2jBbIiTunUQ/tnpzlMxv1sF'
                    'w68aiHdv+jhzqOehh6boH9g0c95G1/H+ZpAhyjq6kTAE7ei4KxnkfEXxeM91iftu'
                    '9jjlDYuadDsDHzrLA3K9TQ9v0l2v+X2N8MTKbUGIO5xWljlVK2S9q78P0VAHDGdE'
                    '4AjtKUox6WT/e4a3/geqMeti074lEP7d4hP+QosH9QF4W8HBb9DoD5+/N/+7epU4'
                    'CabqdOADh5LwvGWhSMtd/kHRH6nlWxk8IUHRi2nJuVRtFRCxPsb2M8jHroGaxkB4'
                    'RSHQvm1vmgXKxXhYsdgLnTRRRgjc4JwLykh4/rTjeg59zRn3On94G1g+7a77N+4+'
                    'ydd7xX7lbwsCW3k0LlzgZrr8mQrgKF9x7sejH0zIL7O+XaPwddEwCO1/XUCQAn75'
                    'cR8axAnOcR8esCcbqbRUeEvvs6BBvS0aDvvqHdDPqmUfjsXvuLdXIYEKhUR4g5dl'
                    'GYR6wvYjkyCwDgbClOAObqNiK6t/ifoEhh0KiH3PU7LnznrO9zxsEtY4x6aPd1Wl'
                    'awSKGvHaMezrxIYdE3LQAmdz11AsBZeFkgxqJAjH6GFA5MepZRD1v393Uqox5K5F'
                    'EgheJx2lil9MtrUTADAICjpDgBmKubh99lXHTNvpu/wNpBF8QHrj94IblvkULO8t'
                    'wuCu0ZFYsnBnW2GLpvz95OF/1nVKQwKMYHuiYAHLfbiLibOgng5L3c9+R3//XbQ/'
                    'ufx9hdE7aZRUeEPnsUKRQ7dw7712IMCDa34oK5xVmN181vQ9cEAADFCcBs3Tx6pG'
                    'uL/wlHPcy6SCHHGKMe2nNy9Rn10PesjPO67u3cmWBIgUGh/YW6KCwGZgLA9K6nTg'
                    'A4eS8H7l8UyKGcyTsi9D1rxkUKfW0pUui7d+jZo+9vYwwNVrIooIR5jGfIjXUXEZ'
                    'eFTgMAOGqKE4C5utn5zBEUKfSK267PkXPh+xRHPeQWKUw56qFPkcKMuij0LFLQNQ'
                    'HgNFxPnQBw8n4ZEc967n0ec+iasGkWHRH67usQbOxCgxIX+vuGms2ohhL7jXqYKN'
                    'ZltONLAQDO3JOpEwDY4ebgihSd3kCmlKJpOr7T7Bjz0Nr2Qm7TLsiNG8PWp0gfzh'
                    '4av8eetkCh8+ve44y1fV3+Hqy+JkPO6rNvdX+z+dCeP6uS5xbYn5oOua5bDO7gAD'
                    'P359/929QpwBiup04AOAsvI+Jtj32LolmU1n77nPt9cdNzT7GzOgQbcl6ffYX3Zo'
                    'Uacm6J/W2MofsjItKAZEp8HXOM08Yq9f51Pa/3oWsCAMADnROAOfvq4Ioj6KIw61'
                    'EPAzs1HFzed9RDpQ4PW0c9VOza0HXvqKMeBnZSSKlzF4W70DUB4FRcT50AcBZe9t'
                    'jzPObYNWGbsUc9FOu+cB6jHjqHm3pUg1EP9eOUitXGWxZQ3RaMCgBw1BQnAPOS1j'
                    '5uSxUJPCw71lEPtYsUcvQc9dCrSCHXkCKFPqYoUhhaYNDGGLi/Q66XA08BYD6up0'
                    '4AOAsve+xZFM6hrrEv4h/TqIexixva/bs/HfXsXvvnMuph6q+ldJyysYw6BADYYK'
                    'wDMGdXEfFZVkv6jmuzxg4UOn/rqIeucdv1uaMYZjTqISLyRmz0PCNn39qfyZDRB7'
                    'l/Npt7N8599Hel476h5/bZn5qtud6F4gSAU/NVLGfCA9Tyy1h2QrjpuP55HEvXhE'
                    '3HMurh0b6Kox7avcc06qHdMPWohyExSox6aOPMZURD6VEPw2K9KtqJAZi/UuNhAE'
                    '6YzgnAnN2ufZbbPaDLspy7+QudP+iufaMe8vd1WjbxqId2/6OHOo56GHpugf0buV'
                    '6GtpUAp+Z66gSAs/AyY+2iUg7jKTp+oeK+PsGmGvVQaO9RjXpoYwzd3wxMZm4dEE'
                    'p3Usj3LpY33QAAsELnBGDOrh89ciJdFJZPD7hrf+D6g3fm184nMl/31XPG6KKQsa'
                    '/veV33duqi0O4d8oOXAvvvuyjcNdFcDogEx8WdUJyP6zjWO5SBY/J5bLRA/+7/+H'
                    'bbuudxSv8mjd0RodhZFTspTNGBYcu5WWkU62Iw0f42RhoYrGQHhFLdD6bporAocC'
                    'oAwMnROQGYlbT+v+udd47n3O3dcW3WHf0Fzx90136f9RtnH+ykkKPHXfjZnRQqdz'
                    'YY1Nmix3ld9x78sxp6Zrn9l6FrAsApup46AeAsvOy4blExh2mM2Wmg+Fkdgg3paN'
                    'B339BuBn3TKHx2r/3FOjkMCFSqI8QcuygcjvVl6JoAALCVzgnAnN1GHLhzPLeTQZ'
                    'fmCBN0Uhh8137OXe877s4v1kWh556UUn4XhcwzHvZ1+qMd0Nmix3k7926c26mTwp'
                    'B8h+2/i4jL7LEdAByDq6kTAM7C01h2T3i7Z83zOKWuCZtm0RGhz1kz7qJQaG92qI'
                    'IdHHrHGLo/IiINTKZE54KS3RhKxGlj7Y7zusAJAAAnSecEYF7So493H54qcId/xp'
                    '3h2XfzF1g76K79gV0XOnVR6NNJIWd5bheF9oyKHR4GdbYYum91/6OHOrWBGLuTwm'
                    'XomgBwyr6aOgHgLLw88PxihBymN4uOCH32dAg2Zp4V9maFKtrFYIL9azEGBJtbB4'
                    'S6cb6IiJsC0QEATpLiBGDurlcvkO69gH5iox7Shy96fkUKOcYY9dCek+scRj20e4'
                    'fotv8ulsUJcDb+7b/+aeoUYGzXUycAnIXP9zz3PE65a8I2Y17ELz7qYaZFCn0pUh'
                    'gerGRRQAnlRz3cxbkUUAEA9KQ4AZi7m4ffnWmRQq+4fddvnF3kNR6wZ5QuChn7Bh'
                    'WN9Div695ORQr1uyhchq4JAKfueuoEgLPwaUS82PHcYrw0ZmQWHRH67usQbOxCgx'
                    'IX+vumUfjsXvuLFTkMCFS0o8NM4ixjXYauCQAAez2ZOgGAA64fPZLi4Y1je0G22f'
                    'ZOcmXdQR3XthfLm6bL4vtfu+Sw5/xHX2PO15W7fkvOKdL213fH+j5n7F2e85r3PG'
                    'NtX6c/2pU/k75nZZzXde/e/z+s7ouB527ff9kzIgDH42rqBICz8Soez2x/HufWNW'
                    'FT+z14btFx03NPsbM6BBtyXp99hfdmh+rzZ7Lj7N4xhu6PiEgDkxmax1ouk8dZdh'
                    'MsVegAHIeh//YAnCGdE4C5u9766JZRBF3W7ZWxNuuO/nMZ9dCnk0LO8r6jHip2eB'
                    'jU2WLovj17O496KNdJ4YvQNQHgHFxPnQBwNj7f8thi5Bzma+xRD8W6L8x41EOhvW'
                    'c56qEZGGyOox76xboM74sBAA5SnADM3W1EvN/57JmOeph1kUKOnqMeehUp5Ooz6q'
                    'HvWRnndd3badRDu3eI5f7FwCgAHI93UycAnIXN0Q7P49y7Jmwa+yL+FKMepihS6G'
                    'tLkULfvUPPHn1/G2NosDmNemhjdfc+vC8GAOhEcQJwDG4OrjjTIoVecdv1OXIufF'
                    'fuVvCwZYwuChn7BhWNbJ7XV98ihWFdFL4IMzUBzsn11AkAZ+PVyu8XE+Uwf7MoNu'
                    'izr2OwsQsNSlzo7xuqWIHAgP3FihwGBCrVRWHcOIsCpwEAnAXFCcC8pK0fV1kX9B'
                    '9+e+ACek5OXZbVGPVwYO2gu/YLdF04m1EP7b5OyyYe9dDuf/RQtVEPix3/v/Xh46'
                    'Q//u2//ingTF1PnQBwNj6///V56JpwWNHxCxX39Qlm1EPvs3vHGLp/TqMe6sd5Hx'
                    'FvCpwCAHAWnkydAEAH1xGxvCAUcfiN5ca6FCmabZu6xstY214ob5oOQQue3154bq'
                    'LJi5ubx5b1a2dXiN9pS87rPuCczn8PNl+TPmcN2bdj78E/q9W93c78InRNADg311'
                    'MnAJyNTyPiZax3UOCQJj68F8jZEyPt27mnQ7Ax81zd22fflnOz0hiS8xz2tzHSwG'
                    'Al8ljLpUqcVwUiAwCcDZ0TgGNwvfZZe+fqISvrjHoonEe7fuPsg50UcuTmE5mv++'
                    'o5ubr+Pdh8Tfr+MKTHa7Fvb8FRD4ueWQFwvK6nTgA4I980/7fQNSHfLDoi9D2r8q'
                    'iHsTswtPt3fzrq2b32z2XUw9Rfy/Y47yLiqkBUAICzoXMCcAxuIuIuIp6uPdr17u'
                    '6VdXvvHD+RTgqD79rvftf8zrvzi3VR6LknpVS/i0LGvkGdLTbP6/vDlL6dFHbnq2'
                    'sC563EDzbheL2LiM+mTgI4fc2f4/86dQ5HbUingUm7L1TsotDu7btvyJkre7NDFe'
                    'zgMEmMh/0DA5XogFCyG4OCfTg/JbqwAJw5nROAY3G19dEeXRSWnx7opNBV1+YIOX'
                    'fzFzp/0F37A7sudOqi0KeTQs7yvl0U+nZS6LRsQGeLoftW9z96qFMbiM29iwFZAH'
                    'DcrqZOADgP6Yfp40jx9dR5HL0+d4zPovtCh2BTdEMouDcrVNEuBgNiDN3fDEymTg'
                    'eEPr4M3xMBAGRTnAAci+u9zw4oUhgUL2PtlKMeHr7OMUY95BYp5DDqIfu8rns7jX'
                    'po9+qaAHDurqdOADgTKSJ9P/3L1GmcjMmLDfqeNeMihb6OuUihaJHDTIoU+nld4H'
                    'QAgLNjrAMwL7uvjV5FxN8efNPYtWX+yrpzGPWwfHpl3EKfUQ+567uODxhx1ENEx9'
                    'e95xk5+4qOeii4t+Ooh0WP0+Bk/On/+6epU4CpXU+dAHBGfpz+Mv7NPKViio5fGP'
                    'usDj39h4xsGHvUw5Zzs9IofHav/UPPf9g/IJlpxlYo2AcA6EnnBOBYXEdEXoeELi'
                    'Ye9TB2J4Wtd+1X+Np2xa4y6qFHJ4XaZzzs67RsQGeLHud13bvn/w/vwg9hAM7dTU'
                    'S8nzoJ4Ew8SREfxe+nTuPkzKIjQp+zZtxFYYpRD+2Gvk5l1EOJPLqncBe6JgAA9K'
                    'Y4ATgWtxHx1cNnXS7iHsGoh4jMi+WFCgkGjRYYY9RDnyKFnOV9Rz1ULJ4YVDQydN'
                    '+evVv+rBY9TwDgtFxPnQBwPtKPLn40dQ4nq8/14DEv/h/jqIcpihSmHtVQqshhaJ'
                    'FCyVEPu+NcxvJnVAAA9KA4AZiVtP9/V48ulPYoPuiy7mAXhcJFClN0UVg+PeCu/T'
                    'GKFHL07KLQq0ghV9e/B0OKRnqc13XvSl7vYjliBQCupk4AOCM/TB9Hiq+nTuOkTd'
                    '4Roe9ZMy5S6EuRwvBgJYsU1t3FsjgBAICenkydAECG64gPd3I37bvE9kLqoTeeqc'
                    'OajXiPztqxLifm3mX3F8qbpkPQguenSPmvZ5882vXN6qeFXuMBe1JK3V7zAWfk7F'
                    't7Tfqe1Z7X9wcyW85NkRY9owFweq6nTgA4Iykivp/+Jf6t+XjqVE5a+71/bqFzn3'
                    '3Fz2oOB+uwpPi+6Ll3y7lZaRQ+u9f+oec/7B+QzNA8HsdYhK4JAACD6JwAHJOr1U'
                    '+23mVeatRDu3bXWTvW5cTcuyy3k0KB8wfftT+w60KVUQ85EzPGGvXQ7uu0bEBni9'
                    'Wzhvwg5sNeXRMAWHU1dQLAeUk/ufjLqXM4G7PoiNDnrBl3UZhi1EO7oa+iXRCG5j'
                    'AwmTJdFN6HrgkAAIPpnAAck5uIeB8Rn64+uHbX//KBpX1vPnO6Layse3RWbrzMtZ'
                    '3v6C/cRWH5dI+79geu39tFoU/8dk9mF4WIjt0rVs+IvHOy/h4M6WzR47wdexc9dg'
                    'Jw2r6KiF9OnQRwJj6KiCfpd/FNo0hhLH1uWJ9F94UOwcbMs8LerFBFuxhMsL+N8d'
                    'BFoWew4XksihQ5AMdjyL9bAOykcwIwL+ngx9W2bwy3djbo8g1k17vKV9Yd7KKQ05'
                    'mhw9rsLgqFzh901/7A9Xtf44i82H3yiQGdFHJ1/XswtLNF5nkbdE0AYJurqRMAzk'
                    'v6cVKYMLaxOw0UPatDsKm6IfTV7P308N4pOykU3T+wi0L+9q8i4k3/QwEAaClOAI'
                    '7NVUTsvMDaa9RDu66LnFEPJ1Sk0Ctuuz7HzEY9RMS4ox5yixSGjGzI27foeQqcnK'
                    '//6eupU4A5uZo6AeDM/CBFXMTd1GmcpVkUG/TZV3HUQ7u3775jHPVQan+RIoVRRz'
                    '287n8QAACrFCcAx+Zq7bOSRQo9uihsPWtzbVdd6w5yLpYXOn/QXftjdFEYWARxcH'
                    'nfLgp9ixQ6LRtQNJK3T9cEAHa5njoB4PykH198f+oczlqf68Gz6L5QsUihYKHBkL'
                    '1ZoabugtDGGLp/aJFCt63eEwMAFPRk6gQAMt1ExPuI+HTt0RRb31CmSNGsPtFeiN'
                    '335rPLmi3rHp2VGy9jbXuhvGk6BC14fntBvIkmL25uHlvWr51dIX6nLTmv+4BzOv'
                    '892HxN+px1eN8iMxoA5+Mmmi3flwHU9MP0cfyP+Dqa+HjqVM5aE/kF0u37jT77ip'
                    '3VIYkhefbZ1+7t2xVv49ysNIbkPIf9bYw0MNj+rYv8gAAA7KI4AThGVxHx60eP7r'
                    'jAuvWi9o5ihi7x9q3bewH9xIoUel8Q77N+7Y+uQ5FChUKAtS19ixTKFg2sLNtSpN'
                    'DnxpHH570Pd4jAuqF3eMHpuQ7FCcDYPk5/jj82ihOmNuZF/OJndagG6FswMEVxQ7'
                    's/7fx01LN77R96/sP+Ack8zuOL8J4YAKAoYx2AeUmdPt52ivHo4R6jHtp1XeSMes'
                    'iJ2WFt1tiBQuf3fj1X1+esTZsPVRj1kDu5YYajHh5el75nrZ+36BkBgPNxNXUCwP'
                    'lJP7p4Gim+njoP7hUdvzDmWRVHPew8s+O+KUY9tBv6KjXqoUgOAwN92LoYkA0AAF'
                    'soTgCO0VXnooJSRQo5hQw5RQpddb04nXOxvND5W1/PnLgD1u99ffvEb/fkLM8pDF'
                    'k9o2LxxKCikQ/73kfEmx47ATgvV1MnAJyhFMvuCcxLn+vBQ4oNip1VsUihYKHBkL'
                    '1ZoYoVCAyMMXT/0CKFJr6I5WhRAAAKMtYBOEa3EfFVpPhlRHQbu7B1ysLKaII96x'
                    '7F6nrmyrpHZ+XGy1g75aiH5dPNOKMeVtYb9bBt2eBRD4venRcAOCfXEXEXEU8nzg'
                    'M4M+lHF0+br7/9Opow3mFu+nTVHzIKoeiohwNJTDGyYcjIhI1zs9IoOmphgv1tjI'
                    'dRD1nB7iLitZFucGb8HAxgFDonAMfq7cPvBnQ+GGXUw0OX/dMf9bB8euCohwEdHY'
                    'q9xgP2ZHdSGDLqocvfg9XXpPtZuiYAkON66gSAM6R7wrzNoiNC330dgh3TqIct52'
                    'aPeih4dq/9xTo5dA50GcsbYwAAKExxAnCs3j56ZOwihdwL+rvO2rEuJ+beZRMUKQ'
                    'wa9ZC7fkseVUY99ChSqH3Gw75Oy7KKFBY9MoGT9/V7o61hh6upEwDOU/rRxdNI4T'
                    '/QczakcGDSs4x62Lq/r+Ma9XAXy+IEAAAqUJwAHKvrWL5hfKxr54MdRQpd1mWv2b'
                    'JuzC4KEZkXywsVSfS8a7/I+r1FIH3it3tylud2UWjPqFg80aEIR9cEAHJdTZ0AcK'
                    'Z0Tzges+iI0GePIoVi585h/1qMncEWoWsCAEA1ihOAY/Z25zMDxjNsvag9oOBh37'
                    'pzGvUw6yKFHGOMemjPydVn1MPjsxY9TgbgvF1NnQBwvu67J2wvXGd+Ju+I0PesGR'
                    'cp9LWlSKHv3qFnj76/jfE42PvQNQEAoCrFCcCstBdxO35cHQ4Y4456aNd1caZFCr'
                    '3i9l2/cXaR13jAnlFHPeQWKSz36JoAQF/vpk4AOFMpIv344vtTp0GGWXRE6LuvQ7'
                    'CxCw1KXOjvG6rg2b33FytyaCIU6wMAVKc4AThmb1NK5QoGShYp5F7Q33XWjnU5Mf'
                    'cuyy1SKHD+gbv2y+expUghZ32fM/YuH2vUQ7uv07KHhYuHs3z48PH4A9jnauoEgD'
                    'P2cfo4PorfT50GmWbREaHPWTPuojDFqId2Q19FuyAMyuGrUKwPAFDdk6kTABjgNi'
                    'K+TJF+FSmiiWb/G9L2wtKhN61p+5oUaXlGTrycM1fWPTorN17m2pRSNE2XheXOby'
                    '+IN9Hkxc3NY8v6tbNLxG/3ZKxvCxQ6ve6rZ0TeOV33pEh3TTRvMiLD+Rn6Q084bV'
                    'cR8bdTJwGcr/STi583t99NnQZ9NJFfCNp+XzbGvp17OgQbM88Ke7NCDTl3DvsjXk'
                    'fO+3Pg+OXePARAEYoTgGN3FRG/iri/4FyqSGHHmq0XtbtclO5RpLD3AnqFIoWsi+'
                    'XnVKRQoRBgbUvfIoXcn5kczu1yb1cJANjvauoEgDP3vRTxJP0+vml+PnUq9DD2Rf'
                    'yiBREdgvU5b++ZHfcOudCfdn56eG+UO7vX/vzz34XvZQAARmGsA3Ds3m4+kKJj2/'
                    'wubbp3rOk16qFd18Va6AOjHnJidnlZckc9FDq/1+u5uj5H2vx0b2L94mfuGXXUw+'
                    'N9dxFx2SMaAKx6N3UCwHlLP71QmHDsjmXUw6N9FUc9tHv77jvnUQ/dY7weeBoAAB'
                    '0pTgCO3U1EfLXtiZRSuYKBkkUKOYUMOUUKXXWtO8i5WF7o/K2vZ07cAev3vr594r'
                    'd7cpbnFIasntG3SOGDy1iOSQGAIa6mTgA4cx9FxCfpbuo0KKDPxemixQYd9/UJNn'
                    'aehfdmhRpaZFCqSGG/LyLieuApAAB0pDgBmJfU6+PN7nCpW5HCwM4Hjy5qVy5SGB'
                    'QvY+2UXRQevs6BRQe564sXKfTsojBKkcJyj64J0MEf/7c/Tp0CHIOrqRMASJ9cPL'
                    '3/HpdTMHmxQd+zZlyk0NcxFyns378YEBkAgEyKE4BT8PbQRdmiRQpduyjE9nW9zt'
                    'xYZ9RD4Tza9RtnHyxSyDFmkUKey9A1AYAyrqZOACBSRPrJxfemToOCxryIX/ysDs'
                    'HG7oZQ4kL/7k9HPbvX/vUYfx/LjpwAAIzkydQJABRwExFfRYpfRsTeN6spUjSpOf'
                    'yGtr3Au2/djjXtBe2mfaJLrHZdlzfaK+sendUhvyFntxfKm6bL4szzd6zt/Xquxs'
                    '5ZuxE7Rdr++vbJpeeelFK31zz/jGXXhD5jIQBgu3cR8dnUSQBn7gfpk/he+n38e/'
                    'PzqVOhoPb9Te77l6bnnmJndQjW97ydZ3bcN+TMlb3Zofrm3OuwnTHuIumaAAAwNp'
                    '0TgFPx5uF3XUYGdOmi0MbqsmZHJ4Uu67LXbFl3sJNCFxl39mfdzT+ge8H6Uxtf4z'
                    'GPemj35CyvM+rhMnRNAKCsq6kTAIiISD+5+HlEmMt0imbREaHPnhmPeii096hGPX'
                    'g/DAAwCcUJwKl4++iRMUc97DhvzFEP7XmD4mWsnXLUw8PXOcaoh9wihRzTjnpYdk'
                    '0AgLLeTp0AQEREfBSRfnTh516nbMyL+MVHPcy0SKGv4ytSWL4fbvf68OHjPD4AmA'
                    'Vv0oBTcRMRXz16tMPF34cihUMGdD7Yetd/qc4NG/EOdlE4oSKFXnH7rt84u8hrPG'
                    'BPdpHC4zMuw10iAJR3Hcsf+ANM75P0w3iSfj91GlTU94JTn33Fz+oQrO/FtCH7hl'
                    'zAa/Z+OurZB7wO74cBACbxZOoEAAp6ExF/t/WZ9qLsnjerKaVoojn8hrZDrF1r2g'
                    'vaTfvEgFg71z6E3jhrx7qcmHuX3V8ob5oui+9/zfyaHj+15fXM+YFE7usQ6+tTpO'
                    '2v7471fc44uCWlbq/54zMuu28C3GUBWa4i4ldTJwEQsRzv0Pzh2z9GxCdT50JF7f'
                    'dquYXiTc89xc7qEGzIeX32Fd6bHarPn8mOs3d4H6ujQQEAGJXOCcC8pEEfb/t2Nv'
                    'jwdMdRD22sLmt2dFLIyavzmi3rxuyiEBH5d/MXOH/2ox76dFLIWZ4/6uGLcJcIAP'
                    'VcTZ0AwAPjHc7LLDoi9NnTIdiYeVbYmxWqRBeF3fsXAyIDADCQN2fAKbmJiC87X+'
                    'jf+3THIoUB4xm2XtQeUPCwb905jXqYdZFCjrqjHhYDC4F8+Dirjz/+f/4YQJa3Uy'
                    'cAsOZj4x3OzpgX8acY9TBFkUJfW4oU+u4denZEvAtdEwAAJqU4ATg1bx9+115Y2u'
                    'XQ8xHxUKRwSIdYu9Y8uqjdJVa7rouVeOdUpNArbrs+R9r8tNBrPGDPgdf8i1gW8g'
                    'BALTexbJkMMBvp6cXPI8Wfps6DEc2iI0KffR2DjV1oUKJQoG+ooSPWPuxfDIwEAM'
                    'BAihOAU/M2Iu7WHulZNLC2ZKRRD9kX1XMv6O86a8e6nJh7l9UY9XBg7dbXMyfuwP'
                    'VVRj3kvIy7C0MWmScDQB9vp04AYE2KSD+++G7qNJjALDoi9DnLqIdi5y73vwujpw'
                    'AAJvdk6gQACruN5Q/Df732aHuNdt8b2QNrUiwLFJpoBsVZW7dlTYq0PCMnXs6ZK+'
                    'senZUbL2Nte6G8aToELXh+WyTQRJMXNzePLevXzi4Rv92TsX7jddc1AYCxXEXEX0'
                    '+dBMCaH6RP4t/T7+NPzc+nToUJNJFfJN6+9xpj3849HYKNmefq3j77tpyblUb/nF'
                    '8P7sAAHJe+/0YBUJXiBGBW9t5t3t2biPh174vuBy7+Fi1S2LFm60XtLhelexQp7L'
                    '2AfmJFCg9f4xhFCmt/dB2KFHILFHLyiYfXfZFxCgAMcTV1AgDbpB9f/Lz587f/HN'
                    '/FX0ydCxMY+yJ+0YKIDsH6FgxMUdzQ7k87Py159hcRcd01NAAA9RjrAJyiq4h4f3'
                    'B0wb43sF1GPUTGqIee4xl6jXpo13WRM+ohJ2aHtXvGDlQ7v/frubo+Z+28Rj3omg'
                    'DAmG4j4t3USQBsk55+9BcR8fXUeTChYxn18GhfxVEP7d6++6YY9dBuOGyRExIAgH'
                    'oUJwDzkop9XLYXbQ9edO+Sz86n7y+wlyoYKFmkkFPIkFOk0FXXuoOuBQoFz9/6eu'
                    'bEHbB+7+vbJ36757BFZlQAGOrt1AkAbPVRRPrJhQbv9LuoXrTYoOO+PsHGzrPw3q'
                    'xQ+xf/fSjUBwCYDcUJwKl6GxFrF3oHdQUoVaQwsPPBo6+hcpHCoHgZa6foorB8eq'
                    'VQYGDRQe764kUK+9frmgDAFN5OnQDATj9In8TH6W7qNJiJyYsN+p414yKFvsoWKd'
                    'yFQn0AgFl5MnUCAJXcRMSXEfGriPhQoNAsf9Nse2vbXtjd96437X++HfXQRHM4Tp'
                    'eztqxpL2ivfQ0H8up85sa6rWflxstY2xYoNE2HoAXPT5E+fI05cfuuX/uj2/Mab1'
                    'nfM5/LjAgAUMpNNPE+Ij6dOhGAbdInF0+bb777ffx78/Opc2EG2vdQuZ3s+uwrfl'
                    'ZzOFiHJcX3Rc+9W87NSuPD2ZexHDUFAMBMKE4ATtmbaIsTWvcXegdddO9wMTpFii'
                    'YdKFDoGKtzkUJO8UHXC/oPoQsWKXSpO5igSKH367kae0BBw1qBRIf1GWe8i4jrjJ'
                    '3Api7/FgG7vI2Iv546CYBd0k/Sz5vb5vfxXShQYGlI4cAYhQ07z+oQbMwCjAp7M0'
                    'PdRaNQH85O34IoAEajOAE4ZW8jttytl9MZYED3g85dFLqctee8Rxe1BxQ8HFp38A'
                    'J6wS4KEcsihU4FCjnnH1i7tUihZheFlfWduijkxF/uWWSsBjb86//7f06dAhy7q1'
                    'CcAMxZikg/ufh5c/fd1xHx8dTpMCOz6IjQZ48ihXuvQ9cEAIDZuZg6AYDKLnc+k+'
                    'LDuIddb2lX1uyNs/fptOwE0CVOlzfpW9ak+//l5JV95sprNej1ylybUnropFAqZp'
                    'e1a19nTtwC6/e+xhE5sd/F8qIQAEzlbSznPQPM15OI9PRCYQLb9Wmi1QzYV+ysDk'
                    'kMybNvc7EhTck2zt2TxvtYdtMEAGBmFCcA85KKf7zpWlww6KJ7h4vRD0UKh3QtiO'
                    'hSpDCg4OHQuedUpNArbt/1G2cPfI0XGacDQC1vp04A4KAnEenH6eup02CmxryIX/'
                    'ysDsHGLjQYUtyw5dwtoV4PiA4AQEWKE4BTdxsRX+QUFxy8ILxPlyKFLl0Uupy157'
                    'xeRQq5F/R3nbVjXU7MvctqFinsfGrL65ljYEHDwS4K25/WNQGAubiaOgGATn6QPk'
                    '6fpD9NnQYzNouOCH3OmnEXhUJ7Vz59FwojAQBm68nUCQCM4DIifh0Ry4u4+974th'
                    'd5m+UF4Wbb4pU1XeJsf3pZoNBEMyjO2rqtqW58DQVy37Vu0OvVY21KKZqm408xDv'
                    '25dzy/LRJoln9B9q7NjX1o/drZ3eIvOp4EALW9jYh/mDoJgE4+Tj+Mb+Kf48/NX0'
                    'ydCjPWRH7RevtebYx9O/d0CDZmnhX2Nt4Lw9np808HANPROQE4B9exrJxfyugiML'
                    'itftdRDyW6GnTtotAhr85nbqw7p1EP6cMXXX/UQ9dOFfGwVtcEAObkNiK+nDoJgK'
                    '7ST9JfxPfTP0+dBzM3dqeBKUY9TNFJoa/lud4LAwDMnM4JwLl4ExGfrT3StYtAc+'
                    'Cu9UNxOpzz0EnhUCeAAZ0PHn0NA7sy7Dt30OvVY21boNCpk0LB89e6RfTpjJDzg5'
                    'eN9Qde40VGZAAYw9uI+NXUSQB0lX6S/qL5l/h9/Hvz86lzYeaGdBqYtPtCx2B98h'
                    'y6L3rujXg1qMABOD7aJgAcHZ0TgHPxJiLeb33m0J3sOZ0B9ulwx3ynLgpdztpz3q'
                    'OvYUBXhkO5DXq9eqzt3EWh4PlbX8+cuAPXb3l93SkCwBy9nToBgFzpJ+nncRE6KN'
                    'BNn44Bs+i+0CHYVF0U8vZ+ERE3PU8DAGAkOicA5+QyIv5u57OH7mTf6AzQuytAh7'
                    'vxI93fET8gztq6ralufA0Fct+1btDrlbl2yi4Ky6ebfl0UBqzf6KJw2TEKAIzpNp'
                    'r4MnRPAI5MenrxF83dd/8c38VfTJ0LR2LsjgjFzuqQRNHODRl7u+1b9IgOAMDIdE'
                    '4A5iVV/XgTKe46nd9hzcGuAF3i7H06deukMKDzwdavYUBXhn3rBr9emWtTSt07KR'
                    'Q8P7srRd882vXrZ78Pd6ZCWY0PHz6KffhvFHCM0rJAQQcFsnz4b1/9fcXP6hCsz3'
                    'l7zxy877ehawIAwFHQOQE4J7cRcRkp/jYi9r+x7dpFoHl013penA7npEjRpObwG/'
                    'gBnQ8efQ0DuzLsWzfo9eqxdopOCr1fz9XYOWs/xF7sLAABsv3P/9f/mDoFODVvI+'
                    'Ifpk4CIFvSQYGe2vd1k3ZE6HNWh2B9z9t5Zsd9j8+8Cx0EAQCOhs4JwKyk+v97s3'
                    'JYl4T2r8vpDDDgnM5dFLqctee8R1/DgK4Mh9YNer16rO3cRaHg+Vtfz5y4eevfR8'
                    'SbjB0AMLbbiPhy6iQAemk7KHwUv586FY7QLDoi9NnTIdiYeW7fexnL7zEAADgCih'
                    'OAc3OTIn3xcME458L6oedXihQOrekSZ/vTBUc9tOt2nNNlXe8zN4oUBsXLWDvlqI'
                    'fsv3P5eSwe1vrw4aPMB1DD26kTAOgtRaSnFz+P7ycjHuhnzIv4xUc9zLJI4X3omg'
                    'AAcFQUJwDnaBERUaVDwP2ag10BusTZ+3TBIoUda3p1UWjXdbESb/Drlbl2yiKFXn'
                    'EPr38fuiYAcBzeTp0AwFDpx+kvFCjQ2yw6IvTd1yHYkG4I+RahawIAwFFRnACco5'
                    'uI+CKi5wX4jOKCQRfdO5yTokOBQsdYRYsUci/o7zprx7qcmHuXTVCk0LvoY3X9Y4'
                    'uMCAAwpdsw2gE4AenH6S/ih+lu6jw4YrPoiNDnrNl0UVCkDwBwhJ5MnQDAmvHaaF'
                    '9GE7/+cOzy4KZ9F5zi8BviNtdd61aefxR/c92+sw6c0xYoNNF0y7nn15Uired/6O'
                    'vvumbLukdn5cbLXJtSiqbp+BOQLq9hh7W9/s6txo2H9X4gA8CxeRsRv5o6CYCh0i'
                    'fpaXwUXzf/2nw8dS4csfZ9YM7PQ/rsKX5Wh2B183y9thY4fcYvApwExQnAubqOFO'
                    '8i4rP16+0rF4xzLqx3vEA/6KL7gXM6FykM+Lq2FlmUKOTYsu5gQUeXeBlr2w4KnY'
                    'oUCp7f6+/ceuxFx9VALj/ohFrexnI+9NNp0wAo4Pvp43QR0fyP5uuIUKRAf02MU2'
                    'xQ/KxJihTehVFRAABHyVgH4JwtImLnKIOVT45u1EOnUQVjj3po13WxEm/Q69Vj7R'
                    'SjHpZP9xr1oGsCAMfoNlxQAE7JkxTppxcfRwpjHhhmnHEIlc7qEKxv8e/jfYuekQ'
                    'AAmJjiBOCcXcWy2n7rxeCtF+APySguOHjRfcg5cd8JoFTBQMkihdwL+rvO2rEuJ+'
                    'beZblFCgXO7/F3bpFxMgDMydupEwAo6qOI9PTiaXwUv586FU7AkMKBSc/qEGx4Uc'
                    'S7WP48BwCAI2SsA3DuFhHxjw+fbWmrP/tRD3vWjDHqoT3n0aiHQ/F6jHrYelZuvM'
                    'y1KaW5jnq4Cxd2ADheb2PZAejTifMAKCdFpJ9e/Lz5Y/P7+Lfm51OnwwkYe9RD7r'
                    '5pRj28ytwBHLvcfycAmDWdE4BzdxVt94RVh7oElBz1kAqMLug66qFgzlvPeNx+4r'
                    'CckRBnOOphz9+5y1i2xQaAY/V26gQAakifpJ+nH6U/RsTXU+fCCRhz1EO7r9hZxU'
                    'c9fBERN1k7AACYFcUJALta4++5CH9oTZc4j9bEwIvuXUY9RMeL7CWLFHKKD7rIGf'
                    'VwQkUKG2vvYlmcAADH7HLqBACq+X76JP304uO4MOaBQmZRbNBnX7FRD3dhtCEAwN'
                    'FTnACw7J7wxc5nt1w43noB/pCM4oKDF92HnBPRrYtCl7P2nNerSKFHF4WtZ22u7a'
                    'pr3UHXAoWC5298jZehawIAx+8mtnWwAjgVHy3HPMQPkgIFyulTODCL7guDixQuQ9'
                    'cEAICj92TqBADWTDdDbBERv977PrnNrVl9KN0/1Gx9fmecjuekSMvYHXLJXZNiWa'
                    'DQRDMoztq6ralufA0Fct+1btDrlbm2LVBomg5BC56fIi27Jkz3/xUAKOlNRHw2dR'
                    'IA1aTlmId4En9s/rW5iIgfTp0SJ6KJ/J+htO8z++wrdlaHJDaXXMTv4jsdlwAATo'
                    'HOCQBLNxHxRc4IhvWHKo16SAVGF3Qd9VAw561nPG4/cViPTgpnMOrhMnRNAOB0vI'
                    '1lm2aA0/b99El6dvHD+MiYBwoasyNC8bMO3REQf4jvxV36JEX6JP0wvA8GADgJOi'
                    'cAfLCIiF9HxOE73Q91UegSI2dNsyV+TpwO56RI0aQDXRQ6xtq1ptdr1K7r2nVgpY'
                    'vC2lkd8tsZs8PakTopLLsmAMDpuI0m3kb7PRjAiUs/ufh5/Fvzp+br5ruI+GTqfD'
                    'gRs+iI0OesLcEu4nfpe+mn8b342cqyt+lH2gfCOWn+tU81FADHQOcEgA9uIuK3a4'
                    '/06BTw6M79Eh0CcjoDDDincxeFLmftOW/ra1Sic8OWdYNerx5rO3dR6Hf+ZbhbBM'
                    'bT+PDhY5QPhXfAuflB+mH66cUnuihQ3If/ttbdU/ys5uv4Xvz+vkvCX8b34uOVJ+'
                    '9ieTMJAAAnQOcEgHWXEfE6Ip4+PNKzU8DanfulOgSsxEmRondXgAPnpOU8iWX8zK'
                    '8757xHX0OXDgk5Z66sG/R6Za6t1EXhLpKLNwCcpOuIeBcRn02cB8B4Lu67KPy5+b'
                    'r5Y5Mi4odTp8QJaWLijggdz/qo7ZKQPo5YK0hY9SqWN5MAAHACdE4AWHcbu+7e63'
                    'p3/6OHKnQI6NpFoWM3ht1LUrdOAAO+rl5dFNp1XeR0negRc++y1PH16xbzMnRNAO'
                    'B0vZk6AYBJfD99nJ5e/DC+l343dSqcmFl0RNgixR/i++ku/egi0icXf3lfmLDLby'
                    'LibWY2AADMmOIEgMcWkeL9zmd7XPSffNTD0CKFnFEPYxYp5BYU7Dprx7qcmHuXlS'
                    'lSeNMtAAAcpTexbNsMcH5SRPpR+sv04xRxYdQDhQ0pUih51pP0T+njFOnHFz9LP0'
                    'hPO/xU+ovwPhgA4OQoTgBmpb2IO/lHpNedLurv/WIer1m7KJ7TISCjSGHvugHnPH'
                    'RRKNXVYE+RQk5enddsWTdmF4WID+MeOsf94IvQxhKA03c5dQIAk3qSIv304ufp4/'
                    'SniPh66nQ4MbU7Imzbl+L36Yfp6/Tji0gfp1/Ek87vid/FcpwDAAAnRnECwHZvU6'
                    'R3KQ5cjO954bx3kUKHcwaPLug66qFkwcC2M7YVKXSJlbnuSEY9LDpmARTyP776l6'
                    'lTgHP0ZuoEAGbhB+mH6enFx/GDpKMM5dUe9ZDiD/G99Pv044tIP774eXwvfZzVoT'
                    'DifUR8npkhAABHQnECwG6vIzpejO950b/KGIOxRj1Ex4vsY496aNd1cRxFCromAH'
                    'AubmL53z0AUkT6OD1NP72I+F763dTpcGKGdkR47Ot4kn6XfnQR6ScXP0sfp5/3/K'
                    'nzXSwLE2577QYAYPaeTJ0AwIxdx/IH5L+OWF68btL9u/Bdb+Lba80Zz7cXxJv2wb'
                    'Rnf49zHsXfXLfvrEPnxPIiexNNt5x7fl1bX6MDeXVasyW3Qa9Xj7UppWiavQsXmX'
                    'eZACX0+WEtUMKbuP/eC4BYFil8kv4yvkvR/Kn5Xfx785dTp8QJab/nzX3PuRzZ8H'
                    'U8Sb9P34tfxJP0cUR8vBazn88jxfWgCAAAzJrOCQD7vY5l5X5ErNxd36XzwD4jj3'
                    'po43fNJXfNGKMe2nOy4/UY9bD1rNx4GWv3dFHQNQGAc3MVyznTAKy6WBYppJ/opE'
                    'AF3QsKvo4n6Z/SJynSTy4+Th+nX8STYtX0v4nl9wEAAJwwxQkA+91GxGLzwbUihV'
                    '0GjHrIKlLIWDN4dEHXUQ8Fc956xrYihUN6FCnMYNTDouMJAHBKLqdOAGC2FClQy/'
                    '6RDcuChJ9efJw+KVqQ0Poilt2TAAA4cYoTAA67jBRfbXuicxeFHs+vXRQvWaQQAy'
                    '+6dzjnoUjhkJJFCqW6TWxZN1GRgq4JAJyrtxHxfuokAGbtcZHC11OnxIlYFimMUZ'
                    'DQ+iIiXtUKDgDAvDyZOgGANdXe6w72OlL847a7CNqL1k26f3JXO8S057n2+Y39D7'
                    'HbBw/F2BFn1/OP4g/M99GSlJaxu+Tc8+va+hodyKvTmi3rBr1e+WsXnQo8AOA0LS'
                    'LiH6ZOAmD27osUokkRf27+0PxbcxFNPJ06LY5Qij/E99K36Xvx83iSPo6IX4xw6l'
                    'exHKf5QfcRE8Cx8uMugLOmcwJAN1cR8ff77nxfG/Ww65vsnp0Cskc9tOs6njN41M'
                    'OeNUVHPbTrdpyTHa/HqIetZ+XGO7xW1wQAzt2b0D0BoLsUET9IP0s/vXiaPkkRH8'
                    'U/TZ0SR+Ai/kv6YfpD+slFpJ9e/Cx9nH5esUPCpq8i4mUsx2kCAHAmFCcAdLeIiL'
                    'uI2Hthea1IYZeMEQybsbNjdFwzeHRB11EPBXPeesa2IoVDehQpVB71cNlxNwCcss'
                    'XUCQAcpe+lSD+++EX6yUXED9JdpPjD1CkxEyn+sDKuIdJPLv5j/CD9bIKfEN9FxO'
                    'ehMAEA4OwoTgDo7jY22w0eKFI4eJG6x/OPLoqXLFLYFj8nTodzDhZuZMTqXKRQqt'
                    'vElnVFixSW3kXEdcddAHDK3kZbGApAvouI9MP0NP304mfpkxTxJP1TRHw9dVqM7K'
                    'P4p/TD9If04/vuCD9Kv4jvdXxfXsddLDsm3EyWAQAAk3kydQIAR+ZNRLyKiM/WHk'
                    '2xdS5ie9G6SfdP7pqduGP/2vMb+x9itw8eirEjzq7nH8UfmO/608sfhDTRdMu559'
                    'eVIq3nf+jr77pmy7pBr9d6zEWHlQBwDm6jicuI+NupEwE4ek9SpCfxi2hSxDfN18'
                    '2fm9/Ht/GLqdOigov4L/EkPUlP4i/vRzR8+HPu8r60rmVhQlKQDwBwrhQnAOR7Fc'
                    's725+uPbrnonanIoWeF87XLornXFjveM6jC/y5+e55vnORwoCva2vRQIlCjh3rBr'
                    '1ey64JVwdOBMYw/Q9ugaXLWHauerp/GQCdpIj4Xvo4fS/9IppQqHAKHhcj/MepU9'
                    'rjdegUCABw1ox1AMh3E/vubj8w6uHgWIOMEQybsbNjzGjUQ0odekrOfdTD8Ndr0f'
                    'E0ADgXt7EsUACgtLZQ4UcXv0g/vYiH0Q8p/jB1auz0dXwU/xTfT79Ln6RIP72I9O'
                    'OL/5h+mNrChDn7TSy7UQIAcMYUJwD0cxkpvtq74kCRwuCL+lue33oB/pCMcw5edB'
                    '9yTsSyQKFUwUDJIoWuhQwbuWW+XromAMB2lxHxfuokAE7ekxTpk/SL9JOLn6UfXU'
                    'T6QfpDfBT/NHVaZy3F7+J76b+kj9PX6UcXkX56sSwmOY5ihFUKEwAAiAhjHYC5Oa'
                    'r31vEqUvw/I6LXaINOox727F97fmP/7Ec97FlTZdTDlnWPvoYCue9a1/H1WhyICg'
                    'Dn6jaW/538h2nTADgjH0XER+ln6QfpZxER8U0TzTfxu/im+Sa+i7+IiI8nze8Upf'
                    'hdfJT+nD6KH8dH8bP74oO/nDqtAhQmAADwQOcEgP6uI+K3ETGoC0LRUQ/7OimUHP'
                    'WQBo56iMPPP4x6KNXVoEsXhQ55ZZ/ZreuErgkAsN+b0D0BYDpPUqQfpr9MP774j/'
                    'd370f6OH19Pwbid1Ond1RS/CEu4r/E99P7lY4IkX5y8Zfpk/SL+EH62ZF1Rdjn70'
                    'NhAgAAK3ROABhmERGfR8QvI6JXl4MPT3XoGND17v59XQJKdQi4P2etS0NunA7nPL'
                    'wuzYF2BQO+rkdfQ6luE1vO3fF6LY6sawgATGERuicAzMOys8LH6Xvxi4c3PN80EU'
                    '183XwT/xzfNt/Ed/Ef4pw7LKT4XaSIeJL+lD6K/xApPr4vOvjZ/cep+yIiXk+dBA'
                    'AA86I4AWC4VxH34x0iehcQfHgqdRv1kPn81gvwPUcibHv+YJHCwGKIlNLhUQ9dzt'
                    'pzXq8iha6FDBu5rZylawIAdPMmmngVEZ9NnQgAW3yUIiI+Tk/iPz68UWoi4rsm4r'
                    'v4uvku/lt821xEE9/Fd/HphJmWkeIPkeJf4iJdxEV8ly7iP8RFfBwptb1qH49k6P'
                    'K+8TR8ESleTZ0EAADzozgBYLjrFOlvmmj+bu3RAV0DHi5cdylSyLxwvnYBvlSHgI'
                    '0ihV5dFDqs6dRdoutZ7bodr3+z/qIdjpdz5sq6FOnywA5gCufzg2M4NouI+Mepkw'
                    'CgoxTLooWP4uMU8emj+XjfRUSzUrwQEQ8FDBERTfw0mhG7DCy7Hfzp/vcX8VH6Li'
                    'LiofAgoi3CiDifDgi5vohQmAAAwHaKEwDKuEyRPo+Izx5dmC9VpHAsox4iIjUDRj'
                    '20a7qMeihRpNC1i0KHvDqf+WHd+2ji7YGVAMAHVxHxZUT8auI8ACjhIiJitXjh/v'
                    'Nd2k4MJXzocLDqcbcDcihMAABgL8UJwKyktOeHEPP3KiKuU5Oelh5tMOqoh30xct'
                    'Z0GfWQme/jJWl/4UZGrKKjHtp1h39mttj3czcAYKvXoTgB4Dy1nRiYI4UJAAAc9L'
                    'g+GIC+biLi9fKm/vRwUXtNir03gTys2fpweugYsDdGl/hp86GNfLv8rKdLHm0nhV'
                    '2vR5ezDpyTIi2LWrrm3GXN1j+6La/RsNzfR8SbDhkBAOtuIuK3UycBADxQmAAAQC'
                    'eKEwDKehMRX7YXpXsXKex5vlORQs8L52v5donRrut4zt4ChbGKFAZ+XY++hv4FD4'
                    'sOOwGA7S4j4m7qJACA+G0oTAAAoCPFCQDlvYrlXfEPF6X3Fins07VIocf+fTkU7h'
                    'CwtuZgF4WenSU+PF2wSKFkF4X1dbomAMAwt7Ec7wAATOc3ofAeAIAMihMAyruNzb'
                    'sGVi7MPzLw4n/nUQ+Zz1cYY/Bhzbb4OXE6nHOwcCMjVoUihcXDWh8+fMzy4+n/6V'
                    'kAs/cmIt5NnQQAnKnfhKJ7AAAyPZk6AYATdRXL1oZ/u/ZoikhNioiIJprYfO7+id'
                    '3S9ufbC+RNavbH2LF/Xw4PsdsHD8XYEWfX84/iD8x3/ekUke5jd8m559eVIq3nvz'
                    '+v9+EHOHAcDv2bAMzBq4j436ZOAgDOzG8ieV8LAEA+nRMA6lnEtrv57u/K3TvqYc'
                    'vDXZ5fG/WwK8ah+DvWrOXbJUa7ruM5RzPqYcd5W/88t8dadDgBAOjmJpYFoQBAfX'
                    'cR8Z9DwT0AAD0pTgDmZQatvAt/fB7LN+87v9a9F+W7vFZbn1opUuixf18Oxz7qIa'
                    'UO1QcDvq4Dox50TQCA8hax/G8sAFDPXUS8jGWnSAAA6MVYB4C6bu8LFP5x34iDFC'
                    'mWkwd6jnrYsSZF6jbqIfP5Yx71EBGRUhpl1MPy4WZ13eWBaABAP68i4h+nTgIATt'
                    'T7iPg8Iq6nTQMAgGOncwJAfVcR8dsud/73HvUQu5/vNOphz/59Ocx+1MOeNWOMem'
                    'jPuXcXuiYAQC1XEfH3UycBACfoq4h4EQoTAAAoQHECwDgWEfFlRHQaTdC7SGHCUQ'
                    '9ZRQoZawaNeojDzxctUtg/6uEyIm4PRAAA+luE8Q4AUNK7WI5yuJ02DQAAToWxDg'
                    'DjeRXLOw0+7TriIDWp+GiDWqMeHmKvjzEYPIKh/VoPjnroke/6kmWBQtMcmOPQ7+'
                    'u6i4jLnUUWAEAJtxHNqzDeAQBK+CIivZo6CQAAToviBIDx3MZyRuNVRDyNiE4X1V'
                    'Oz46J8xoX9xw/fx6xQpPCoiOBQIUXmOQeLFAYWQ6R0X2DRJefuX9dluNMEAMZwFU'
                    '38NiL+dupEAOCI/U2kuJw6CQAATo+xDgDjuo6I148e3TcyYKxRD4di7LNlf/aoh8'
                    'xzBo962LOm6KiHiLtIcfmw1ocPH0fz8ez//LMAjtIilvOxAYA8dxHxmwiFCQAA1K'
                    'FzAsD43kTEi4j460fPpOg06iFiRyeFAaMeIu47KQwYjbAth2qjHmLPa5ETp8uoh0'
                    'OdFPafdRm6JsDxOjTqBZirz2NZFPp02jQA4GjcRcTLWP73EwAAqtA5AWAaryPi3d'
                    'Zn2rt2d7l/vlcXhQNrOndRyHz+UdeHgXmurdkWPydOh3MeXpdDHse6C3ecAMAUbm'
                    'JbtyoAYJuvIuJ5KEwAAKAyxQnAvMygjfeIH5/HvpbDHS6q9x71ELufH23UQ5cYO+'
                    'Lsev5gkcKAczqPelg/6zJ0TQCAqbyJiC+mTgIAZu6LiHgZ3rsCADACYx0ApnMbKV'
                    '5FxFU0e1oOpxg26iEO7z846mFXjEPxd6x5iB1NtxhtnI7nrI2S6JNvmVEPuiYAwP'
                    'Rex3Kc1i+nTQMAZum3EbGYOgkAAM6H4gSAaV1HxOeR4h8jolcRwerze4sUMgsIPj'
                    'y1UqTQN78dOawVEfQsdNi1Zudr0SVOh3M6FCm8CXeeAMDUbqO5LwaNPcWgAHBe7i'
                    'LiVaR4O3UiAACcF2MdAKZ3FRG/iYisEQb7nh806mHPuIdS+W3GfTTqYeAIhoc12+'
                    'LnxOlwzsPr8tjlgQwBgHFcR8SriXMAgLn4KpZdhd5OmwYAAOdIcQLAPLxJkT7MRB'
                    '56cT7tuSifcWH/8cOpe5HCofhdihQOySguOFikMOCcFClSWitS+CIibg5EBQDG8z'
                    'aWrasB4Jx9EREvw/tVAAAmYqwDwHy8SpGeRcSvmmh6j0pYey4OjHrYF7/rqIddMX'
                    'qOaXiI3fU1aON0PGdtlESffLuNeljsiQIckWf/l7+I2//HP0+dBlDGIpZ3iv5q2j'
                    'QAYBJ/Ezr8AQAwMcUJwKzsvLP9fLyKiKsU6ZcPF9AHFBGsPp+aPRflMwsIPjy1Uq'
                    'TQN78dOawVEfQsdNh1zloBRG6cw+fomgCn5lCBFHBMXsVypNYvp00DAEbzPiI+j+'
                    'WYIwAAmJTiBIB5uY1li8XrFOnTiFi/QD/k4nwa0EXhwJoUaX8XhY75bT7/qIjg0G'
                    'uQec7BIoV+r8dCkQ0AzNZtfLhA83TKRABgBF/GsjDvdto0AABg6WLqBAB45DZSfB'
                    '4RdxHLC+gPF7tTxMHr3vvW3D+3FrPr3tU1Wx9OD2MN9sbokX/2a5B5zs5igvzXW9'
                    'cEAJi/m1gWg95NmwYAVPU3sSzIu502DQAA+EDnBIB5uo4UL6OJq7i/q2/tLv+eox'
                    'LWnosBnRQmHPWw3JbxGnRcs/O1yInTxGLPCgBgPq6jiVcR8X+fOhEAKGw5xiEZ4w'
                    'AAwPzonAAwX9eR4tW2LgIrnxzuUtDh+b2dA/bZE79zF4Uez2e9BjlrYk9XicNxdE'
                    '0AgOPyNiJ+M3USAFDQFxHxIkJhAgAA86RzAsC8vY2I30SKf4iIhzv31zoILB8Y1k'
                    'EgDeiisOf8tS4KB87PzT/7NdgRZ9fzj+IfznfRadwEcHR+9vJ/iT9c/fep0wDqeB'
                    'MRzyLi76ZNAwAGuYuIV7H8GQIAAMyWzgkA8/cm2rv6Nu7cX7vLf2gHgZUuCls7Bw'
                    'zogvAQs8P5e21Zk/0atOs6ntOxi4KuCQBwvC5j+d9yADhG72LZLeHttGkAAMBhOi'
                    'cAHIc3EfE8Iv42Ih7duZ8irXcQiOjV6WB1/95OCj27NKx1UujQvWDvGY/S6vEadF'
                    'yz87X4sObNnigAwPy9uv/111MmAQAZ7iJiEcsiOwAAOAo6JwAcj0Ws3tW3r4vClu'
                    'cf6fh8ry4KB9Yc7KKQkd9m3KzXIGfNtvhL7yLi6kAEAGD+XoUOCgAch68i4mUoTA'
                    'AA4MjonABwXF7d//rhrr6NDgAP3QlWuwgM6SCQDnRR2Ld3z/lrXRQOnJ+bf/ZrsC'
                    'POruc34i8ORAZOwM/+8/8Sf/jH/z51GkB9r+6/F9BBAYC5+m0k70MBADhOihMAjs'
                    '+r+1/Xf2i+ZdRDxP0F9DFGPeyL33XUw64YPcc0ZL8GbZyO56RI75porg5EBACOy6'
                    'v7XxUoADAnX8Xyv1HX06YBAAD9KU4AOE6v7n99XKAQ8egC/VoHgY3nD+3f9nxq0u'
                    'MChfb5nl0a1ooU+ua3I4es1yDvnMXWsRcAwLF7df+rAgUApnYXy/ENi2nTAACA4R'
                    'QnAByvV/e/Pv6heZdRDyvPH9q/7fkUKaIZMOphx5oUqduoh8znK4x6eBcRVwciAA'
                    'DH61VE3EbEX0+bBgBn7F0s/3t0M20aAABQhuIEgOP26v4i+/a7+roUKQzpIJAGjH'
                    'rYc36nUQ979u/Lofeoh8frFpomAMDJex3L9tn/MG0aAJyZu1h2SricNg0AAChLcQ'
                    'LA8Xt1f5H8110v4mdfoN9XBLAy6uEh5pbn+3RBKDrqYWNN7yKF5RpdEwDgfLy5/x'
                    'ZBgQIAY/gyIl6lZfceAAA4KYoTAE7Dq4iISPcdFLZdZN9xgb7kqIeIZZHCowKF9v'
                    'kBox6WUyQKFCk8qp3IeA0+rFnsWQGcokPFS8CpexPLltpvI+LplIkAcLLex/K9/d'
                    'W0aQAAQD2KEwBOx6v7X3/dpdPBrEc97FiTInUb9ZD5fOZroGsCAJynq2jiZSwLFD'
                    '6dNhUATshdRFxGUgQPAMDpu5g6AQCKehURX0TE8gJ72rNy4/l0/79Oew+tuX9uLW'
                    'bXvatrtj6cHjopHPz6DsVPmw91eg3eHIgMAJyu64h4ERFfTZsGACfiy1j+d2UxbR'
                    'oAADAOxQkAp+dVRPz24bPMi/i9ihT2PTekSGHP82tFCj32r63ZFftxjPehOAEAzt'
                    '1tLC8kfTFtGgAcsfcR8Z8j4vNYjg0CAICzYKwDwGlaxPIHHP/w8EjGqIflQ2l9zM'
                    'HG84f2b3s+NenxqIdDuR2IX2vUw0Ps9ddgsSdL4BTt+7cJOHevYjnq6R/2LwOAB3'
                    'exfF95OW0aAAAwDZ0TAE7Xm4j4zdojQ0Y9RHTrQnAg/hGPetA1AQDY9CYi/tdYfp'
                    '8AAPv8fUQ8D4UJAACcMZ0TAE7bm/tfLyPi6cOjXToJbHRRWC5vDu89FH+li8JDzK'
                    '57Dzz/kOe+Tgo980+RFnt2ACdoa6cXgMeuYznm4W1EfDZlIgDM0rtYdtu5mTYNAA'
                    'CYnuIEgNP3JlJcRxNXsVqgENGpiKD3qId2TYdRD8swW4oUBox6iLgvUug76mE9B1'
                    '0TAIB9biPiZTTxOiL+btpUAJiJdxGxiBRXUycCAABzoTgB4DxcR4qXEfE2mvj00b'
                    'Mdigg+1CRsFBMM6HSw+nxqUn4XhQNrUqT9XRS657fYkwFwijRNAPq5jIirWHZReP'
                    'w9FwDn4H0s30O+mTYNAACYn4upEwBgNNcp0otI8dXWZ1N8uFDf4fl0/7+15/fpEP'
                    '9RzK5795z/ELPL17edrgkAQI7rWI55+Ptp0wBgZO8j4jcR8Ty8hwQAgK0UJwCcl9'
                    'sU6WWkeLfzYnzmRfy1goIBRQSr+3sXKex5vlORwvbnFntOBADY5jYiXkfEf47lxS'
                    'oATtddRPw2loVpbybNBAAAZk5xAsD5uY2IlynSFz0u1O987lEXhZ5FBKvPby1QaJ'
                    '/fp2uRwuH9uiYAAENchS4KAKeqLUp4Hsui9tsJcwEAgKPwZOoEAJjMqxTpOiL+rk'
                    'n3w9W3zVhPOx5vn1vZ1xYTNB8e2D+3fWP/tudTpIhmJWbXvQfWpEix9+teLrrcEx'
                    '04Rfv+TQHo5zaWXRTexrLo8dPpUgGggLuIuLz/uJ0yEQAAODaKEwDO22VE3KRIby'
                    'LiaZOa3QUKEf2KFAYWEbTPp2aj8KHr3nbNjgKFiNhVpHAXuiYAAOVcRRMvYlmo8L'
                    'fTpgJADx+KEpKiBAAA6MNYBwDeRsTLiHj/MO6gz6iHePzcwwiFLnu37N929lrM3N'
                    'zyRj1chrtgAICybmPZ+vs/RcS7STMBoKv3EfE3YXwDAAAMpjgBgIiI61jOQ/5q7U'
                    'L9viKFXbbsWysmGFBEsPr81gKFQ7kdiJ8iRUopIj3cEQMAUMNNLItD/yqWF70AmJ'
                    '/3EfGbWBYlXIaiBAAAGExxAgCt21gWKHwRsbObwAeZRQaPOh4MKCJon+/dReHA+S'
                    'nSZfjBEwBQ39tYXvT6bSzbhQMwvXfxoSjhzaSZAADAiXkydQIAzM6riLiKiH+IiI'
                    'cChSaaiGbL6vYi/7bntjzfFhM00Rzeeyh+OzGiWYk5ILd7dxFxmdKh6gbglDTNvn'
                    '+IAKpbxPKu3EVE/PWUiQCcsS9j+W/x1bRpAADA6VKcAMA2b2I56uFtRHwasSwqaN'
                    'L9xbu+RQrN6qc9ihQOFBkUKlK4DF0TAIDx3UbE62geihR+PWUyAGfiLpbvexeR4m'
                    'baVAAA4PQZ6wDALtexHPPwrn1gbdTDvnEPu2zZ92jUQ+b+bc9vHfVwKLfl83eR4v'
                    'LhHB8+fJzHB8C83MSyk9V/ivtxWwAU9z4i/iaWoxteRShMAACAMShOAGCf24h4Gc'
                    's5yA/WihS2OXTBb+P5h3irz+/TIf6jmN32XoauCQDAPNyEIgWA0t5FxF/FsijhMr'
                    'z/AwCAUSlOAKCLRaT4q1i2vHzQqYvCoSKFjXgPBQVd7mjucHZGkcJdLH84BQAwJz'
                    'ehSAFgiLuI+PtY/jv6MpZjHAAAgAk8mToBAI7G20jxIpp4GxG/bB9sL/w3qVk+0G'
                    'zZ2RYBdHwuRYqmfWDf3tUYu55vax2a+zw3F37Y+ybcNQMAzNdNRLyKaBbLX+N1RD'
                    'ydLBuA+XsXEW8i0puJ8wAAAO7pnABAjpuIeBFpfcxDxMaoh33dDHbpMuohY/+u5/'
                    'd0UbicfO69Dx8+xv0AOE43EbGIZUvy38RybjoAS3ex3iXhzZTJAAAA63ROAKCPRa'
                    'S4ioi30azfsbfWSSG3i8KW5x/irXZSONRF4UD8LV0UvojlD/oBAI7FbSwvur2JJl'
                    '7GspPCr6ZLB2BSX0bEm0hGNgAAwJzpnABAX1cR8TxSfLntyU5dFPbduZw2P13ppN'
                    'DlrudDsdNazMWBaAAAc3YVEZ/H8k7h34ZuCsB5+Coi/iYifhbLfwPfTpkMAABwmO'
                    'IEAIa4jYjPI8XfRIq7zSc7j3rIeK7CqAddEwCAU3ETH0Y+/FUsu0MBnJL3sRzb8L'
                    '9GxIuIuIzl+1IAAOAIGOsAQAmXEXEVKd5ExC83RyqsjXqI2D3uYZpRD4uUDJ+Hc9'
                    'I0+/7BADgZb+8/XsfyjuJXEfHZVMkADHAXy3/P3sSyUwwAAHCkdE4AoJTrWN658t'
                    'tdHQvWOilsk9kJodeoh/U1uiYAAKfuNpYX9F7GcuzD38SyFTrAnN3F8v3aX0XEs1'
                    'gWWF1Nlw4AAFCC4gQASlvEssXmV7uKBQaNeojHz/UqUviQKwDAubiJZcerF6FQAZ'
                    'ifbQUJb6dLBwAAKM1YBwBquI7lD70XkeJvI+LRSIXSox7amGujHnbFXT7/RTS6Jg'
                    'AAZ+smloUKl9HE81h2Vvg8In41VULAWXofywKEq0gKEQAA4NQpTgCgpkW0s0FT/D'
                    'Ii9hcp7CpQ2LJv1/MP8VaLFLbvXRzssACcll3/jgBwE8vRD2/uP/88PhQrfDp+Os'
                    'CJ+yqW7xPfxrKwHQAAOBPGOgBQ23Usuyj8NiJ2jl0oMuohrX66d9TDlxG6JgAA7P'
                    'A2Il5HxPNYjn/4TSy/f7qbLCPg2H0Zy39L/lO0XfYUJgAAwNnROQGAsSxi+YPuy4'
                    'j4bFtHg86jHnY91z5/eNTDZfe0AQDO2k2sd1V4EcuuCu3H07ETAo7CVxFxdf/xds'
                    'pEAACA+VCcAMCYrmP5Q+zXsRyrsPxhdt8ihX6jHt7F8gdkAADku77/uLz//EUsv7'
                    '9rfzUGAs7TXXwoRLgKneoAAIAtFCcAMIXL+HAH3q92dUNYK1Lo20Vh5fn7eIu94y'
                    'GAk9M0u/6RAKCA61htzd7Es1gvVngRuivAKWqLEZYfyYgGAADgMMUJAEzlNiI+j+'
                    'UPrd9ExKf7ihQKjXrQNQEAoK7bWN45/XblseexLFJY/dBhAY7LejFCKEYAAADyKU'
                    '4AYGpXsfyB9SKW4x6ebhvZ0HnUw/7nFgPyBI6RpgkAc3Bz//F24/GXsfw+8PnK7x'
                    'UtwDy8jw9FCO2vAAAAgyhOAGAuFrHsoHAZXUc9bHn+ftG2x3VNAACYl6sdj7+IeB'
                    'gP8fz+47P66cBZexfrhQg306UCAACcKsUJAMzJTXwY9XAZEb/sVKTQrYvColSSAA'
                    'BUdX3/69XG48/jw1iI56FoAfr6Kpb/P7sOXREAAIARKU4AYI6uYvlD51exLFLYOu'
                    'ohYlmk0GHUw7todE0AADhyN7FtPESzNhriWXwoXjAiAj50RLiJiOtI3hcBAADTUZ'
                    'wAwJy9ieUPn19HxOtI8TQi+ox6WDx0UgDOw7ZiJQBO1c39x9WW517GesFC+6FwgV'
                    'PzPj78/+A62mIEAACAGVGcAMDc3cZyJMOb+19/3WnUw4fnv4rd84wBADhtV/e/vt'
                    '3y3ItYFi68vP+8/dWoCObsq1i+R7qK/YU5AAAAs6M4AYBjcRPLMQ+LWBYqfNapSK'
                    'GJy1GyAwDg2Fzf/3q14/mX97++iGURw/PQeYFxtF0QruNDIcJt6IQAAAAcOcUJAB'
                    'ybm1j+oPhlLAsVlkUKW1q4p0jvm2jejJUYAAAn5Wrj121e3v/6IpYFDM/ufx+hiI'
                    'Hd7uJD4cG2XwEAAE6S4gQAjtVVrBYppPv2u+tFCouUUgDno2m2VCoBQD1XG7/u8i'
                    'KWhQsRHwoaNn//IiKeDk2IybVjF27jQ6HB9f3nN/cfAAAAZ0lxAgDH7iq2Fym8j+'
                    'X4BwAAmNr1yu+vOqx/fv/RehEfihu2ff48dGmo5d3K72/iQ3HBbXz4c139PQAAAD'
                    'soTgDgVFzFepHCmwlzAaagaQIAp+Mm1u+wv+oR43msFzi0XsR6YUOXPfvOmENRxL'
                    'sDz9/G9uKBm3jcyeD6fj0AAACFJa1vAQAAAAAAAICaLqZOAAAAAAAAAAA4bYoTAA'
                    'AAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAA'
                    'AAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgK'
                    'oUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAg'
                    'AAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAA'
                    'AAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAF'
                    'CV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTg'
                    'AAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAA'
                    'AAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAA'
                    'CqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQ'
                    'kAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAA'
                    'AAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAA'
                    'BAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpT'
                    'gBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAA'
                    'AAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAA'
                    'AAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqh'
                    'QnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAA'
                    'AAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAA'
                    'AAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJ'
                    'XiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAA'
                    'AAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAA'
                    'AAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAK'
                    'pSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQ'
                    'AAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAA'
                    'AAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAE'
                    'BVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOA'
                    'EAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAA'
                    'AAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAA'
                    'CoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFC'
                    'cAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAA'
                    'AAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAA'
                    'AAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQle'
                    'IEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAA'
                    'AAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAA'
                    'AAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAql'
                    'KcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAA'
                    'AAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAA'
                    'AAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQF'
                    'WKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQ'
                    'AAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAA'
                    'AAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAK'
                    'hKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJw'
                    'AAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAA'
                    'AAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAA'
                    'BVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4g'
                    'QAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAA'
                    'AAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAA'
                    'CgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUp'
                    'wAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAA'
                    'AAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAA'
                    'AAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVY'
                    'oTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAA'
                    'AAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAA'
                    'AAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqE'
                    'pxAgAAAAAAAABQleIEAAAAAAAAAKAqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAA'
                    'AAAAAAAABVKU4AAAAAAAAAAKpSnAAAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAA'
                    'AAAFCV4gQAAAAAAAAAoCrFCQAAAAAAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAF'
                    'UpTgAAAAAAAAAAqlKcAAAAAAAAAABUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBA'
                    'AAAAAAAACgKsUJAAAAAAAAAEBVihMAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAA'
                    'AAAACqUpwAAAAAAAAAAFSlOAEAAAAAAAAAqEpxAgAAAAAAAABQleIEAAAAAAAAAK'
                    'AqxQkAAAAAAAAAQFWKEwAAAAAAAACAqhQnAAAAAAAAAABVKU4AAAAAAAAAAKpSnA'
                    'AAAAAAAAAAVKU4AQAAAAAAAACoSnECAAAAAAAAAFCV4gQAAAAAAAAAoCrFCQAAAA'
                    'AAAABAVYoTAAAAAAAAAICqFCcAAAAAAAAAAFUpTgAAAAAAAAAAqlKcAAAAAAAAAA'
                    'BUpTgBAAAAAAAAAKhKcQIAAAAAAAAAUJXiBAAAAAAAAACgKsUJAAAAAAAAAEBVih'
                    'MAAAAAAAAAgKoUJwAAAAAAAAAAVSlOAAAAAAAAAACqUpwAAAAAAADA/79dOxYAAA'
                    'AAGORvPYp9xREArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAA'
                    'AAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5A'
                    'QAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAA'
                    'AAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAA'
                    'AAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJ'
                    'ITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAA'
                    'AAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAA'
                    'AAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAM'
                    'BKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAA'
                    'AAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcg'
                    'IAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAA'
                    'AAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAA'
                    'AAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWM'
                    'kJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAA'
                    'AAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAA'
                    'AAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAG'
                    'AlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAA'
                    'AAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQ'
                    'EAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAA'
                    'CAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAA'
                    'AAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArO'
                    'QEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAA'
                    'AAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAA'
                    'AAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAAL'
                    'CSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAA'
                    'AAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnA'
                    'AAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAA'
                    'DASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAA'
                    'AAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVn'
                    'ICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAA'
                    'AAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAA'
                    'AAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAF'
                    'jJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAA'
                    'AAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTg'
                    'AAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAA'
                    'BgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAA'
                    'AAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKz'
                    'kBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAA'
                    'AAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAA'
                    'AAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAK'
                    'zkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAA'
                    'AAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAAAAAAAAAGAlJw'
                    'AAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAFZyAgAAAAAAAA'
                    'CwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAAAAAAArOQEAAA'
                    'AAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEwAAAAAAAACAlZ'
                    'wAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAABYyQkAAAAAAA'
                    'AAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAAAAAAAArOQEAA'
                    'AAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk4AAAAAAAAAAF'
                    'ZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAAAAYCUnAAAAAA'
                    'AAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAAAAAAAAALCSEw'
                    'AAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAACs5AQAAAAAAAA'
                    'BYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsJITAAAAAAAAAICVnAAAAA'
                    'AAAAAArOQEAAAAAAAAAGAlJwAAAAAAAAAAKzkBAAAAAAAAAFjJCQAAAAAAAADASk'
                    '4AAAAAAAAAAFZyAgAAAAAAAACwkhMAAAAAAAAAgJWcAAAAAAAAAACs5AQAAAAAAA'
                    'AAYCUnAAAAAAAAAAArOQEAAAAAAAAAWMkJAAAAAAAAAMBKTgAAAAAAAAAAVnICAA'
                    'AAAAAAALCSEwAAAAAAAACAlZwAAAAAAAAAAKzkBAAAAAAAAABgJScAAAAAAAAAAC'
                    's5AQAAAAAAAABYyQkAAAAAAAAAwEpOAAAAAAAAAABWcgIAAAAAAAAAsArlA7li6b'
                    'pQDAAAAABJRU5ErkJggg==')
                app_manager().update_application_settings(created)
                requestAppToken()

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class AppManagerLoginApi:

        def __init__(self):
            self._window = None

        def set_window(self, window):
            self._window = window

        def close(self):
            self._window.destroy()

        def discordAppLogin(self):
            getConfigData()
            token = getCurrentToken()
            appid = getCurrentAppId()
            self._window.evaluate_js(
                f'\n    if (window.location.href !== '
                f'"https://discord.com/developers/applications/'
                f'{appid}/bot") {{\n'
                f'        document.body.appendChild('
                f'document.createElement `iframe`).contentWindow'
                f'.localStorage.token = `"{token}"`\n'
                f'        window.location.href = '
                f'"https://discord.com/developers/applications/'
                f'{appid}/bot";\n'
                f"        alert('Click on \"Reset Token\" to get your "
                f'app token.\')\n    }}')
            self._window.evaluate_js(
                '\n(async function() {\n'
                "    'use strict';\n"
                '    const sleep = ms => new Promise('
                'r => setTimeout(r, ms));\n\n'
                '    function getForm() {\n'
                '        return new Promise(async (resolve) => {\n'
                '            let form;\n\n'
                '            while(!form) {\n'
                "                form = document.querySelector('form');\n"
                '                await sleep(200)\n'
                '            };\n\n'
                '            resolve(form)\n'
                '        })\n'
                '    };\n\n'
                '    function getTokenWrapper() {\n'
                '        const allLabelElements = [...document.'
                "querySelectorAll('label')];\n"
                '        const tokenLabel = allLabelElements.find('
                "label => label.textContent.trim() === 'Token');\n"
                '        return tokenLabel.parentElement.'
                'parentElement;\n'
                '    }\n\n'
                '    function sendTokenToBackend(token) {\n'
                '        console.log(token);\n'
                '        pywebview.api.getAppToken(token);\n'
                '    }\n\n'
                '    function tokenWatcher(changedNodes, observer) {\n'
                '        for(const node of changedNodes) {\n'
                '            if(node.addedNodes[0].nodeName !== '
                '"#text" || node.addedNodes[0].length < 60) '
                'continue;\n\n'
                '            sendTokenToBackend('
                'node.addedNodes[0].textContent);\n'
                '            observer.disconnect()\n'
                '        }\n'
                '    }\n\n\n'
                '    const form = await getForm();\n'
                '    const wrapper = getTokenWrapper();\n'
                '    console.log(wrapper)\n'
                '    const observer = new MutationObserver('
                'tokenWatcher);\n'
                '    observer.observe(wrapper, {childList: true, '
                'subtree: true})\n'
                '})();')


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getAppToken(self, input_value):
        main_ui.load_url('https://nighty.one/download/files/ui/'
                         'loading.html')
        config = getConfigData()
        config['logins'][getActiveProfileName()]['app'][
            'token'] = input_value
        saveConfigData(config)
        os.execv(sys.executable, ['python'] + sys.argv)


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def is_discord_bot_token_valid(token):
        try:
            r = requests.get(
                'https://discord.com/api/v10/users/@me',
                headers={'Authorization': f'Bot {token}'},
                verify=False,
                timeout=15)
            if r.status_code == 200:
                return True
            return False
        except requests.RequestException as e:
            logging.error(f'Error checking token: {e}')
            return False

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def is_discord_token_valid(token):
        try:
            r = requests.get(
                'https://discord.com/api/v10/users/@me',
                headers={
                    'Authorization': token,
                    'Content-Type': 'application/json',
                    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; '
                                   'WOW64) AppleWebKit/537.36 '
                                   '(KHTML, like Gecko) '
                                   'discord/1.0.9001 '
                                   'Chrome/83.0.4103.122 '
                                   'Electron/9.3.5 Safari/537.36')},
                verify=False,
                timeout=15)
            if r.status_code == 200:
                return True
            return False
        except requests.RequestException as e:
            logging.error(f'Error checking token: {e}')
            return False


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class WebVersionApi:

        def __init__(self):
            self._window = None

        def set_window(self, window):
            self._window = window

        def show(self):
            self._window.show()

        def minimize(self):
            self._window.minimize()

        def hide(self):
            self._window.hide()

        def close(self):
            logging.info('WV - Closing Nighty.')
            turbo_sniper.stop()
            self._window.destroy()
            sys.exit()

        def customCallback(self, name, *args, **kwargs):
            return callback_store.call(name, *args, **kwargs)

        def isWeb(self):
            return getConfigData()['web']

        def getWebConfig(self):
            config = copy.deepcopy(getWebConfigData())
            is_set = False
            if config['password']:
                is_set = True
            config['password'] = None
            config['isPasswordSet'] = is_set
            return config

        def setWebConfig(self, config):
            current = getWebConfigData()
            if not config.get('password'):
                config['password'] = current['password']
            updateWebConfig(config)
            return True

        def enableWebVersion(self, enabled):
            config = getConfigData()
            config['web'] = enabled
            saveConfigData(config)
            os.execv(sys.executable, ['python'] + sys.argv)

        def getAllNotifications(self):
            return __all_notifications__

        def clearAllNotifications(self):
            global __all_notifications__
            __all_notifications__ = []
            evaluate_js('localStateUpdated("notifications_cleared"')

        def deleteNotification(self, notification_id):
            global __all_notifications__
            __all_notifications__ = [n for n in __all_notifications__
                                     if n.get('id') != notification_id]
            evaluate_js(f'localStateUpdated("notification_deleted", '
                        f'"{notification_id}")')

        def getCustomUITabs(self):
            return __custom_ui_tabs__

        def webLogout(self):
            evaluate_js("\nfetch('/api/logout', { method: 'GET', "
                        "credentials: 'same-origin' })\n  .then(() => {\n"
                        "      location.reload();\n  });")

        def getClipboardText(self):
            return pyperclip.paste()

        def copyToClipboard(self, text):
            pyperclip.copy(text)

        def openURL(self, url):
            os.startfile(url)

        def openLicenseScreen(self):
            self._window.load_url(
                'https://nighty.one/download/files/ui/auth.html')

        def openDevPortal(self):
            api = BotTokenApi()
            window = webview.create_window(
                "Get your application token by clicking 'Reset "
                "Token', then paste it into Nighty. You can close "
                "this window after.",
                url='https://discord.com/login',
                width=1200,
                height=1000,
                resizable=False,
                frameless=False,
                js_api=api)
            api.set_window(window)
            window.events.loaded += lambda: api.discordAppLogin()

        def getAppTokenInput(self, input_value):
            if not is_discord_bot_token_valid(input_value):
                evaluate_js(
                    'pauseWithError({\n                    title: '
                    '"Invalid app token",\n                    '
                    'description: "The provided token is invalid. '
                    'Please try again.",\n                })')
                return
            config = getConfigData()
            config['logins'][getActiveProfileName()]['app'][
                'token'] = input_value
            saveConfigData(config)
            bot.run(token=getCurrentToken(), reconnect=True)

        def saveKeyToAppdata(self, license):
            session = requests.Session()
            session.mount('https://', HTTPAdapter(
                max_retries=Retry(total=50,
                                  status_forcelist=[429, 500, 503, 504],
                                  backoff_factor=5)))
            try:
                if not isValidKey(license):
                    return 'Invalid license error'
                try:
                    response = session.post(
                        f'{SERVER_TO_USE}/v2',
                        json={'key': str(encryptRSA(license)),
                              'uuid': str(encryptRSA(getUUID()))},
                        verify=False,
                        timeout=(10, 30))
                except:
                    response = session.post(
                        f'{SERVER_TO_USE}/v2',
                        json={'key': str(encryptRSA(license)),
                              'uuid': str(encryptRSA(getUUID()))},
                        verify=False,
                        timeout=(10, 30))
                session.close()
                if response.status_code == 200:
                    data = response.json()
                elif response.status_code == 401:
                    return 'Invalid license error'
                else:
                    return 'Failed to connect'
                updateKey(license)
                evaluate_js('animateFormOut();')
                time.sleep(1.3)
                main_ui.load_url(
                    url='https://nighty.one/download/files/ui/'
                        'discord_login.html')
                return 'Success'
            except:
                return 'Failed to connect'

        def saveTokenToConfig(self, token):
            r = requests.get(
                'https://discord.com/api/v10/users/@me',
                headers={
                    'Authorization': token,
                    'Content-Type': 'application/json',
                    'User-Agent': (
                        'Mozilla/5.0 (Windows NT 10.0; WOW64) '
                        'AppleWebKit/537.36 (KHTML, like '
                        'Gecko) discord/1.0.9001 '
                        'Chrome/83.0.4103.122 '
                        'Electron/9.3.5 Safari/537.36')},
                verify=False,
                timeout=20)
            if r.status_code == 200:
                data = r.json()
                username = data.get('username')
                config = getConfigData()
                logins = config['logins']
                logins[f'{username}'] = {
                    'token': str(token),
                    'date_added': datetime.now().strftime(
                        '%d %B %Y, at %H:%M:%S'),
                    'active': True}
                config = getConfigData()
                config['logins'] = logins
                saveConfigData(config)
                setActiveProfile(username)
                autoApp()
                return {f'{username}': {'status': 'success',
                                       'text': 'Account added.'}}
            else:
                evaluate_js('location.reload();')
                return {'status': 'error', 'text': 'Invalid token.'}

        def verifyDevPortalPass(self, password):
            try:
                manager = app_manager()
                config = getConfigData()
                app_id = getCurrentAppId()
                app_token = getCurrentAppToken()
                manager.session.headers.update(
                    {'Authorization': getCurrentToken()})
                response = manager.session.post(
                    'https://discord.com/api/v9/mfa/finish',
                    json={'ticket': app_token,
                          'mfa_type': 'password',
                          'data': password})
                if response.status_code == 200:
                    data = response.json()
                    sys.stdout.write(f'\n{data}\n')
                    mfa_token = data['token']
                    manager.session.headers.update(
                        {'Cookie': f'__Secure-recent_mfa={mfa_token}'})
                    response = manager.session.post(
                        f'https://discord.com/api/v9/'
                        f'applications/{app_id}/bot/reset')
                    data = response.json()
                    sys.stdout.write(f'\n{data}\n')
                    bot_token = data['token']
                    config['logins'][getActiveProfileName()][
                        'app']['id'] = app_id
                    config['logins'][getActiveProfileName()][
                        'app']['token'] = bot_token
                    saveConfigData(config)
                api = AppAuthorizeApi()
                snippet = ('\n    console.log(`injected`)\n    var '
                           'previousUrl = window.location.href;\n'
                           '    function checkUrlChange() {\n'
                           '        var currentUrl = '
                           'window.location.href;\n        if '
                           '(currentUrl !== previousUrl) {\n'
                           '            previousUrl = currentUrl;\n'
                           '            console.log(`URL changed: '
                           '${currentUrl}`)\n            pywebview.api.'
                           'url_change_callback_app(currentUrl);\n'
                           '        }\n        setTimeout('
                           'checkUrlChange, 1000); // Check every '
                           'second\n    }\n\n    checkUrlChange();\n'
                           '                ')
                window = webview.create_window(
                    'Authorize Nighty',
                    url='https://discord.com/login',
                    width=1200,
                    height=1000,
                    resizable=False,
                    frameless=False,
                    js_api=api)
                api.set_window(window)

                def on_loaded():
                    api.discordLogin()
                    window.evaluate_js(snippet)

                window.events.loaded += on_loaded
            except Exception as e:
                logging.error(e)

        def verifyDevPortalMfa(self, mfa_code):
            try:
                manager = app_manager()
                config = getConfigData()
                app_id = getCurrentAppId()
                app_token = getCurrentAppToken()
                manager.session.headers.update(
                    {'Authorization': getCurrentToken()})
                response = manager.session.post(
                    'https://discord.com/api/v9/mfa/finish',
                    json={'ticket': app_token,
                          'mfa_type': 'totp',
                          'data': mfa_code})
                if response.status_code == 200:
                    data = response.json()
                    sys.stdout.write(f'\n{data}\n')
                    mfa_token = data['token']
                    manager.session.headers.update(
                        {'Cookie': f'__Secure-recent_mfa={mfa_token}'})
                    response = manager.session.post(
                        f'https://discord.com/api/v9/'
                        f'applications/{app_id}/bot/reset')
                    data = response.json()
                    sys.stdout.write(f'\n{data}\n')
                    bot_token = data['token']
                    config['logins'][getActiveProfileName()][
                        'app']['id'] = app_id
                    config['logins'][getActiveProfileName()][
                        'app']['token'] = bot_token
                    saveConfigData(config)
                api = AppAuthorizeApi()
                snippet = ('\n    console.log(`injected`)\n    var '
                           'previousUrl = window.location.href;\n'
                           '    function checkUrlChange() {\n'
                           '        var currentUrl = '
                           'window.location.href;\n        if '
                           '(currentUrl !== previousUrl) {\n'
                           '            previousUrl = currentUrl;\n'
                           '            console.log(`URL changed: '
                           '${currentUrl}`)\n            pywebview.api.'
                           'url_change_callback_app(currentUrl);\n'
                           '        }\n        setTimeout('
                           'checkUrlChange, 1000); // Check every '
                           'second\n    }\n\n    checkUrlChange();\n'
                           '                ')
                window = webview.create_window(
                    'Authorize Nighty',
                    url='https://discord.com/login',
                    width=1075,
                    height=670,
                    resizable=False,
                    frameless=False,
                    js_api=api)
                api.set_window(window)

                def on_loaded():
                    api.discordLogin()
                    window.evaluate_js(snippet)

                window.events.loaded += on_loaded
            except Exception as e:
                logging.error(e)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def add_custom_function(self, func):
        setattr(self, func.__name__, MethodType(func, self))

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getAvailableLoginOptions():
        return ['token_login', 'web_login']


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def chooseLogin(self, login):
        if login == 'web_login':
            pass  # FLAG: the selected_option / wait_for_selected

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------


class MainApi(QtCore.QThread):
    def addAccount(self, profileName, token):
        r = requests.get(
            'https://discord.com/api/v10/users/@me',
            headers={
                'Authorization': token,
                'Content-Type': 'application/json',
                'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; '
                               'WOW64) AppleWebKit/537.36 '
                               '(KHTML, like Gecko) '
                               'discord/1.0.9001 '
                               'Chrome/83.0.4103.122 '
                               'Electron/9.3.5 Safari/537.36')},
            verify=False,
            timeout=15)  # const-recovered
        if r.status_code != 200:  # const-recovered
            return {'error': 'invalid_token', 'message': 'Invalid token'}  # const-recovered (values decoyed)
        logins = getConfigData()['logins']  # const-recovered
        found = {'name': False, 'token': {'exists': False, 'login': None}}  # const-recovered (exact keys decoyed)
        for lg in list(logins):
            if str(lg) == str(profileName):
                found['name'] = True  # const-recovered
            if logins[lg]['token'] == str(token):  # const-recovered
                found['token'] = {'exists': True, 'login': str(lg)}  # const-recovered
        if found['name']:
            return {f'{profileName}': {'error': 'invalid_token', 'message': 'Profile name already exists'}}  # const-recovered
        elif found['token']['exists']:
            return {f'{profileName}': {'error': 'invalid_token', 'message': f'Already logged in: {found["token"]["login"]}'}}  # const-recovered
        else:
            logins[f'{profileName}'] = {'token': str(token), 'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'verified': False}  # const-recovered
            config = getConfigData()
            config['logins'] = logins
            saveConfigData(config)
            return {f'{profileName}': {'error': 'account_added', 'message': 'Account added'}}  # const-recovered

    ############################################################################

    def addAccount(self, profileName, token):
        r = requests.get(
            'https://discord.com/api/v10/users/@me',
            headers={
                'Authorization': token,
                'Content-Type': 'application/json',
                'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; '
                               'WOW64) AppleWebKit/537.36 '
                               '(KHTML, like Gecko) '
                               'discord/1.0.9001 '
                               'Chrome/83.0.4103.122 '
                               'Electron/9.3.5 Safari/537.36')},
            verify=False,
            timeout=15)  # const-recovered
        if r.status_code != 200:  # const-recovered
            return {'success': False, 'message': 'Invalid token'}  # const-recovered
        logins = getConfigData()['logins']  # const-recovered
        found = {'exists': False, 'login': {'exists': False, 'name': None}}  # const-recovered (exact keys decoyed)
        for lg in list(logins):
            if str(lg) == str(profileName):
                found['exists'] = True  # const-recovered
            if logins[lg]['token'] == str(token):  # const-recovered
                found['login'] = {'exists': True, 'name': str(lg)}  # const-recovered
        if found['exists']:
            return {f'{profileName}': {'success': False, 'message': 'Profile name already exists'}}  # const-recovered
        if found['login']['exists']:
            return {f'{profileName}': {'success': False, 'message': f'Token already added: {found["login"]["name"]}'}}  # const-recovered
        logins[f'{profileName}'] = {'token': str(token), 'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'via': 'web'}  # const-recovered
        config = getConfigData()
        config['logins'] = logins
        saveConfigData(config)
        return {f'{profileName}': {'success': True, 'message': 'Account added'}}  # const-recovered
    #----------------------------------------------------------------------------

    def addWebAccount():
        window = webview.create_window(
            title='Login to Discord',
            url='https://discord.com/login',
            width=1075,
            height=670,
            resizable=False,
            frameless=False,
            js_api=WebLoginApi())
        window.events.closed = None  # FLAG: closure (GOT_1796,
        # built via DAT_000a9d58) \u2014 the URL-watcher injection pair
        # GOT_544/545 feeds this closure
        window.events.loaded = None  # FLAG: closure (GOT_1800)

    #----------------------------------------------------------------------------
    # Evidence: dec_login_required_2664158308816.marshal (true metadata + armed
    #   lnotab). Gate vs py38 compile: names(-armor)=('wraps',) EXACT,
    #   varnames=('f','decorated_function') EXACT, argcount=1, flags 0x03,
    #   cellvars=('f',) EXACT, line map (0:8919, 0:8920, 6:8921, 20:8929)
    #   IDENTICAL; per-line budgets 8920=6B and 8921=14B EXACT (14B = 2-cell
    #   MAKE_FUNCTION: LOAD_CLOSURE f; BUILD_TUPLE 1; code; name; MAKE_FUNCTION 8;
    #   CALL_FUNCTION 1; STORE_FAST). Only delta: 8929 armed +32B (uniform
    #   __armor_wrap__ tail seen on every unit in this band).
    # Inner wrapper body = unit L8920. serve_login_page is unit L8931.

    def login_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if request.method == 'POST' and request.path == '/login':
                return f(*args, **kwargs)

            if 'user_id' not in session:
                return serve_login_page()

            return f(*args, **kwargs)
        return decorated_function

    ############################################################################

    # Evidence: dec_login_required_2664158308816.marshal (true metadata + armed
    #   lnotab). Gate vs py38 compile: names(-armor)=('wraps',) EXACT,
    #   varnames=('f','decorated_function') EXACT, argcount=1, flags 0x03,
    #   cellvars=('f',) EXACT, line map (0:8919, 0:8920, 6:8921, 20:8929)
    #   IDENTICAL; per-line budgets 8920=6B and 8921=14B EXACT (14B = 2-cell
    #   MAKE_FUNCTION: LOAD_CLOSURE f; BUILD_TUPLE 1; code; name; MAKE_FUNCTION 8;
    #   CALL_FUNCTION 1; STORE_FAST). Only delta: 8929 armed +32B (uniform
    #   __armor_wrap__ tail seen on every unit in this band).
    # Inner wrapper body = unit L8920. serve_login_page is unit L8931.

    def login_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if request.method == 'POST' and request.path == '/login':
                return f(*args, **kwargs)

            if 'user_id' not in session:
                return serve_login_page()

            return f(*args, **kwargs)
        return decorated_function
    # Evidence: dec_logout_2664158764176.marshal (true metadata + armed lnotab).
    #   Gate vs py38 compile: names(-armor)=('request','method','path','session',
    #   'serve_login_page') EXACT ORDER (session before serve_login_page forces
    #   the f(*args,**kwargs) passthrough at 8923 and serve_login_page only at
    #   8926); varnames=('args','kwargs'), argcount=0, flags 0x1f
    #   (VARARGS|VARKEYWORDS|NESTED), freevars=('f',) all EXACT.
    #   Line map (0:8920, 20:8922, 30:8925, 38:8926, 44:8928) IDENTICAL;
    #   budgets 8922=20B (request.method=='POST' and request.path=='/login'),
    #   8923=10B (return f(*args,**kwargs) incl CALL_FUNCTION_EX), 8925=8B
    #   ('user_id' not in session), 8926=6B (return serve_login_page()) all
    #   EXACT. Only 8928 armed +32B (uniform armor tail).
    # ANOMALY: fence29 banked an armed-scratch body for this unit (ret racted
    #   2026-10-17, see NightyRecovered Nighty.py L21156 note); this file is the
    #   semantic reconstruction from true metadata, not the armor wrapper.

    def decorated_function(*args, **kwargs):
        if request.method == 'POST' and request.path == '/login':
            return f(*args, **kwargs)

        if 'user_id' not in session:
            return serve_login_page()

        return f(*args, **kwargs)
    #----------------------------------------------------------------------------

    def serve_login_page():
        return Response(
            LOGIN_PAGE_HTML,  # FLAG: payload register-held
            content_type='text/html')

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    # Evidence: dec_after_request_2664158309696.marshal (true metadata + armed
    #   lnotab). Gate vs py38 compile: names(-armor)=('headers','add') EXACT,
    #   varnames=('response',), argcount=1, flags 0x43 (NOFREE) EXACT.
    #   Line map (0:9108, 14:9110..9114, 70:9115) IDENTICAL; budgets 9110-9114
    #   = 14B each EXACT (7 instrs = response.headers.add(k, v)); five add
    #   statements anchored. Only 9115 armed +32B (uniform armor tail; orig
    #   `return response` = 4B).
    # Consts armor-stripped (token 592): the four standard CORS pairs are
    #   const-recovered from the app idiom; the FIFTH add is evidenced (14B
    #   statement slot) but its key/value are the least certain - marked below.

    def after_request(response):

        response.headers.add('Access-Control-Allow-Origin', '*')  # const-recovered
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')  # const-recovered
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')  # const-recovered
        response.headers.add('Access-Control-Allow-Credentials', 'true')  # const-recovered
        response.headers.add('Access-Control-Max-Age', '3600')  # const-recovered; key/value uncertain
        return response
    # Evidence: dec_handle_preflight_2664158309872.marshal (true metadata + armed
    #   lnotab). Gate vs py38 compile: names(-armor)=('request','method',
    #   'jsonify','headers','add') EXACT ORDER; varnames=('response',),
    #   argcount=0, flags 0x43 EXACT.
    #   Line map (0:9117, 10:9119, 16:9120, 30..72:9121-9125) IDENTICAL;
    #   budgets 9119=10B (request.method == 'OPTIONS'), 9120=6B (response =
    #   jsonify() - zero-arg, matches the recovered sibling handler in the
    #   safe_add_individual_route factory: `return jsonify()`), 9121-9124=14B
    #   each EXACT (4 x response.headers.add). Only 9125 armed +32B (uniform
    #   armor tail).
    # Consts armor-stripped (token 593): CORS pairs const-recovered (same
    #   quartet as unit L9108 after_request minus the fifth).

    def handle_preflight():

        if request.method == 'OPTIONS':
            response = jsonify()
            response.headers.add('Access-Control-Allow-Origin', '*')  # const-recovered
            response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')  # const-recovered
            response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')  # const-recovered
            response.headers.add('Access-Control-Allow-Credentials', 'true')  # const-recovered
            return response
    # Evidence: dec_handle_connect_2664158310048.marshal (true metadata + armed
    #   lnotab). Gate vs py38 compile: names(-armor)=('session','logging',
    #   'warning','request','remote_addr','disconnect','info','emit') EXACT
    #   ORDER; varnames=(), argcount=0, flags 0x43 EXACT.
    #   Line map (0:9127, 8:9129, 26:9130, 32:9131, 36:9132, 54:9134) IDENTICAL;
    #   budgets ALL interior lines EXACT: 9129=8B ('user_id' not in session),
    #   9130=18B (9-instr f-string: logging.warning(f'...{request.remote_addr}')
    #   - concat form would be 16B), 9131=6B (disconnect()), 9132=4B (LOAD_CONST
    #   False + RETURN_VALUE -> `return False`, flask-socketio connect reject),
    #   9133=18B (f-string logging.info). Only 9134 armed +32B (uniform tail).
    # Const grounding: the shipped web panel (Nighty.exe_extracted
    #   PYZ.pyz_extracted web/index.html) listens `socket.on('connected',
    #   (data) => console.log(data.message))` -> the emit event name
    #   'connected' and payload key 'message' are GROUNDED; payload text and
    #   log messages are const-recovered (armor token 594).

    def handle_connect():

        if 'user_id' not in session:
            logging.warning(f'Unauthorized WebSocket connection attempt from {request.remote_addr}')  # const-recovered
            disconnect()
            return False
        logging.info(f'Client connected: {request.remote_addr}')  # const-recovered
        emit('connected', {'message': 'Connected to Nighty server'})  # event/key grounded; text const-recovered
    # Evidence: dec_handle_execute_js_2664158310224.marshal (true metadata +
    #   armed lnotab). Gate vs py38 compile: names(-armor)=('get','logging',
    #   'info','eval','emit','Exception','str') EXACT ORDER (str AFTER Exception
    #   -> str() only in the except branch); varnames=('data','js_code',
    #   'result','e'), argcount=1, flags 0x43 EXACT.
    #   Line positions IDENTICAL; budgets EXACT: 9139=12B (js_code =
    #   data.get('code', '')), 9143=2B (SETUP_FINALLY at try:), 9144=8B
    #   (result = eval(js_code)), 9146=16B (py38 except header: DUP_TOP;
    #   LOAD_GLOBAL Exception; COMPARE_OP exc-match; POP_JUMP_IF_FALSE;
    #   POP_TOP; POP_TOP; STORE_FAST e; POP_TOP). 9140 armed +10B and 9145 +4B
    #   (armor decoy injection near the call sites); 9147 = single except
    #   statement + uniform +36B armor tail (a second handler statement would
    #   break the tail arithmetic: 76 = 18 stmt + 22 machinery + 36 tail).
    # Const grounding (web/index.html): panel does `socket.emit('js_result',
    #   {success, result|error, code})` and listens `socket.on('js_result')`;
    #   server side execute_js_via_websocket (orig L2137) emits
    #   socketio.emit('execute_js', {'code': js_code}). So data key 'code' and
    #   event 'js_result' are GROUNDED; log texts const-recovered (token 595).
    # ANOMALY: the server-side eval(js_code) is real (name 'eval' + 8B slot at
    #   9144) - the handler evaluates the reported code server-side and echoes
    #   the outcome back on 'js_result'; the panel logs that echo.

    def handle_execute_js(data):


        js_code = data.get('code', '')
        logging.info(f'Executing JavaScript: {js_code}')  # const-recovered


        try:
            result = eval(js_code)
            emit('js_result', {'result': result})
        except Exception as e:
            emit('js_result', {'error': str(e)})
    # Evidence: dec_handle_disconnect_2664158326832.marshal (true metadata +
    #   armed lnotab). Gate vs py38 compile: names(-armor)=('logging',
    #   'warning','request','remote_addr') EXACT ORDER; varnames=(), argcount=0,
    #   flags 0x43 EXACT.
    #   Line map (0:9149, 0:9151) IDENTICAL - single body statement at 9151.
    #   Budget: armed 54B = 22B statement + uniform 32B armor tail, i.e. the
    #   9-instr f-string form (logging.warning(f'...{request.remote_addr}')).
    #   The concat alternative ('...' + request.remote_addr) compiles to 20B
    #   and would give 20+32=52 != 54, so the f-string form is byte-preferred.
    # Log text const-recovered (armor token 596).

    def handle_disconnect():

        logging.warning(f'Client disconnected: {request.remote_addr}')  # const-recovered

    ############################################################################

    # Evidence: dec_handle_disconnect_2664158326832.marshal (true metadata +
    #   armed lnotab). Gate vs py38 compile: names(-armor)=('logging',
    #   'warning','request','remote_addr') EXACT ORDER; varnames=(), argcount=0,
    #   flags 0x43 EXACT.
    #   Line map (0:9149, 0:9151) IDENTICAL - single body statement at 9151.
    #   Budget: armed 54B = 22B statement + uniform 32B armor tail, i.e. the
    #   9-instr f-string form (logging.warning(f'...{request.remote_addr}')).
    #   The concat alternative ('...' + request.remote_addr) compiles to 20B
    #   and would give 20+32=52 != 54, so the f-string form is byte-preferred.
    # Log text const-recovered (armor token 596).

    def handle_disconnect():

        logging.warning(f'Client disconnected: {request.remote_addr}')  # const-recovered


    # Evidence: dec_handle_execute_js_2664158310224.marshal (true metadata +
    #   armed lnotab). Gate vs py38 compile: names(-armor)=('get','logging',
    #   'info','eval','emit','Exception','str') EXACT ORDER (str AFTER Exception
    #   -> str() only in the except branch); varnames=('data','js_code',
    #   'result','e'), argcount=1, flags 0x43 EXACT.
    #   Line positions IDENTICAL; budgets EXACT: 9139=12B (js_code =
    #   data.get('code', '')), 9143=2B (SETUP_FINALLY at try:), 9144=8B
    #   (result = eval(js_code)), 9146=16B (py38 except header: DUP_TOP;
    #   LOAD_GLOBAL Exception; COMPARE_OP exc-match; POP_JUMP_IF_FALSE;
    #   POP_TOP; POP_TOP; STORE_FAST e; POP_TOP). 9140 armed +10B and 9145 +4B
    #   (armor decoy injection near the call sites); 9147 = single except
    #   statement + uniform +36B armor tail (a second handler statement would
    #   break the tail arithmetic: 76 = 18 stmt + 22 machinery + 36 tail).
    # Const grounding (web/index.html): panel does `socket.emit('js_result',
    #   {success, result|error, code})` and listens `socket.on('js_result')`;
    #   server side execute_js_via_websocket (orig L2137) emits
    #   socketio.emit('execute_js', {'code': js_code}). So data key 'code' and
    #   event 'js_result' are GROUNDED; log texts const-recovered (token 595).
    # ANOMALY: the server-side eval(js_code) is real (name 'eval' + 8B slot at
    #   9144) - the handler evaluates the reported code server-side and echoes
    #   the outcome back on 'js_result'; the panel logs that echo.

    def handle_execute_js(data):


        js_code = data.get('code', '')
        logging.info(f'Executing JavaScript: {js_code}')  # const-recovered


        try:
            result = eval(js_code)
            emit('js_result', {'result': result})
        except Exception as e:
            emit('js_result', {'error': str(e)})


    # Evidence: dec_handle_connect_2664158310048.marshal (true metadata + armed
    #   lnotab). Gate vs py38 compile: names(-armor)=('session','logging',
    #   'warning','request','remote_addr','disconnect','info','emit') EXACT
    #   ORDER; varnames=(), argcount=0, flags 0x43 EXACT.
    #   Line map (0:9127, 8:9129, 26:9130, 32:9131, 36:9132, 54:9134) IDENTICAL;
    #   budgets ALL interior lines EXACT: 9129=8B ('user_id' not in session),
    #   9130=18B (9-instr f-string: logging.warning(f'...{request.remote_addr}')
    #   - concat form would be 16B), 9131=6B (disconnect()), 9132=4B (LOAD_CONST
    #   False + RETURN_VALUE -> `return False`, flask-socketio connect reject),
    #   9133=18B (f-string logging.info). Only 9134 armed +32B (uniform tail).
    # Const grounding: the shipped web panel (Nighty.exe_extracted
    #   PYZ.pyz_extracted web/index.html) listens `socket.on('connected',
    #   (data) => console.log(data.message))` -> the emit event name
    #   'connected' and payload key 'message' are GROUNDED; payload text and
    #   log messages are const-recovered (armor token 594).

    def handle_connect():

        if 'user_id' not in session:
            logging.warning(f'Unauthorized WebSocket connection attempt from {request.remote_addr}')  # const-recovered
            disconnect()
            return False
        logging.info(f'Client connected: {request.remote_addr}')  # const-recovered
        emit('connected', {'message': 'Connected to Nighty server'})  # event/key grounded; text const-recovered


    # Evidence: dec_handle_preflight_2664158309872.marshal (true metadata + armed
    #   lnotab). Gate vs py38 compile: names(-armor)=('request','method',
    #   'jsonify','headers','add') EXACT ORDER; varnames=('response',),
    #   argcount=0, flags 0x43 EXACT.
    #   Line map (0:9117, 10:9119, 16:9120, 30..72:9121-9125) IDENTICAL;
    #   budgets 9119=10B (request.method == 'OPTIONS'), 9120=6B (response =
    #   jsonify() - zero-arg, matches the recovered sibling handler in the
    #   safe_add_individual_route factory: `return jsonify()`), 9121-9124=14B
    #   each EXACT (4 x response.headers.add). Only 9125 armed +32B (uniform
    #   armor tail).
    # Consts armor-stripped (token 593): CORS pairs const-recovered (same
    #   quartet as unit L9108 after_request minus the fifth).

    def handle_preflight():

        if request.method == 'OPTIONS':
            response = jsonify()
            response.headers.add('Access-Control-Allow-Origin', '*')  # const-recovered
            response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')  # const-recovered
            response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')  # const-recovered
            response.headers.add('Access-Control-Allow-Credentials', 'true')  # const-recovered
            return response


    # Evidence: dec_after_request_2664158309696.marshal (true metadata + armed
    #   lnotab). Gate vs py38 compile: names(-armor)=('headers','add') EXACT,
    #   varnames=('response',), argcount=1, flags 0x43 (NOFREE) EXACT.
    #   Line map (0:9108, 14:9110..9114, 70:9115) IDENTICAL; budgets 9110-9114
    #   = 14B each EXACT (7 instrs = response.headers.add(k, v)); five add
    #   statements anchored. Only 9115 armed +32B (uniform armor tail; orig
    #   `return response` = 4B).
    # Consts armor-stripped (token 592): the four standard CORS pairs are
    #   const-recovered from the app idiom; the FIFTH add is evidenced (14B
    #   statement slot) but its key/value are the least certain - marked below.

    def after_request(response):

        response.headers.add('Access-Control-Allow-Origin', '*')  # const-recovered
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')  # const-recovered
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')  # const-recovered
        response.headers.add('Access-Control-Allow-Credentials', 'true')  # const-recovered
        response.headers.add('Access-Control-Max-Age', '3600')  # const-recovered; key/value uncertain
        return response
    #----------------------------------------------------------------------------

    def endpoint_exists(endpoint):
        return any(rule.rule == endpoint
                   for rule in web_app.url_map.iter_rules())

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def addWebviewFunction(func):
        main_api.add_custom_function(func)


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def safe_add_individual_route(func):
        route = f'/api/custom/{func.__name__}'
        if endpoint_exists(route):
            logging.info(f'\u26a0\ufe0f  Route already exists: {route}')
            return False

        def factory(func_to_handle):
            def handler():
                if request.method == 'OPTIONS':
                    return jsonify()
                try:
                    data = request.get_json(silent=True) or {}
                    args = data.get('args', [])
                    kwargs = data.get('kwargs', {})
                    result = func_to_handle(*args, **kwargs)
                    return jsonify({'success': True,
                                    'result': result})
                except Exception as e:
                    return jsonify({'success': False,
                                    'error': str(e)}), 500

            handler.__name__ = f"handler_{func_to_handle.__name__}_{uuid.uuid4().hex[:8]}"
            return handler

        handler = factory(func)
        web_app.route(route, methods=['POST', 'OPTIONS'],
                      endpoint=f"custom_{func.__name__}_{uuid.uuid4().hex[:8]}")(handler)
        logging.info(f'\u2705 Added individual route: {route}')
        return True

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class NUI:

        def __init__(self, webview, ui_code):
            self.__tabs = []
            self._webview = webview
            self.__original_ui = ui_code
            self.__ui_code = ui_code

        def update(self):
            self.__tabs = []
            self.__ui_code = self.__original_ui
            self._webview.load_url(
                f'{SERVER_TO_USE}'
                f'/v2/beta?key={str(encryptRSA(getLicense()))}')

        def reload(self):
            self.__ui_code = self.__original_ui
            self._webview.load_url(
                f'{SERVER_TO_USE}'
                f'/v2/beta?key={str(encryptRSA(getLicense()))}')

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def notifyNitroSnipe(msg):
        notifications = getNotifications()
        author = msg["author"]
        channel = msg["channel"]
        content = msg["content"]
        status = msg["status"]
        code = msg["code"]
        elapsed = msg["elapsed"]
        notification_type = "INFO"
        if status == "Nitro redeemed":
            notification_type = "SUCCESS"
        jump_url = msg["jump_url"].replace("https://", "discord://")
        print(f"Nitro Sniper (Turbo) | {status} | Code: {code} | By {author} | Elapsed: {elapsed} ms", discordChannel=channel, url=jump_url, type_=notification_type)
        if notifications.get("dm"):
            if notifications["dm"].get("nitrosniper"):
                await dmToClientUser(title="Nitro sniper (Turbo)", content=f"{status}\nBy {author}\n{content}\n\n{jump_url}")
            if notifications["toast"]["nitro"]:
                showToast(text=f"{status}: {content}", title="Nitro sniper (Turbo)", details=f"{status}: {content}", url=jump_url, type_=notification_type)
            if notifications["webhook"]["nitro"]:
                await sendWebhookNotification(notifications["webhook"]["nitro"], "Nitro sniper (Turbo)", f"{status}\nBy {author}\n{content}\n\n{jump_url}")

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class TurboSniperManager:

        def __init__(self, exe_path):
            self.exe_path = exe_path
            self.proc = None
            self.thread = None
            self.running = False

        def _reader(self):
            for line in self.proc.stdout:
                if not line.strip():
                    continue
                try:
                    message = json.loads(line)
                except json.JSONDecodeError:
                    print(f'Nitro Sniper (Turbo) | Invalid message '
                          f'from Go: {line}')
                    continue
                if 'notification' in message:
                    print(f'Nitro Sniper (Turbo) | '
                          f'{message["notification"]}')
                elif message.get('event') == 'connected':
                    print(f'Nitro Sniper (Turbo) | Logged in as '
                          f'{message["user"]}')
                elif message.get('event') == 'nitro':
                    asyncio.run(notifyNitroSnipe(message))
                else:
                    print(f'Nitro Sniper (Turbo) | {message}')

        def start(self, token, session_mode, dpb):
            if self.running:
                print('Process already running')
                return
            if not os.path.exists(self.exe_path):
                logging.error(
                    f'TurboSniper: {self.exe_path} not found, '
                    f'turbo mode unavailable')
                print('Nitro Sniper (Turbo) | TurboSniper.exe is '
                      'missing (check your antivirus), turbo mode '
                      'unavailable. Switch the nitro sniper back to '
                      'On.', type_='ERROR')
                return
            self.proc = subprocess.Popen(
                [self.exe_path], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, text=True, bufsize=1)
            session_configs = {
                'ios': ['iOS', 'Discord iOS', 'iOS',
                        'Discord-iOS/231028; CFNetwork/1490.0.7; '
                        'Darwin/23.2.0'],
                'android': ['Android', 'Discord Android', 'Android',
                            'Discord-Android/267200;RNA'],
                'windows': ['Windows', 'Discord Client', 'Windows',
                            'Mozilla/5.0 (Windows NT 10.0; Win64; '
                            'x64) AppleWebKit/537.36 (KHTML, like '
                            'Gecko) Discord/1.0.9001 '
                            'Chrome/108.0.5359.215 '
                            'Electron/22.3.24 Safari/537.36'],
                'linux': ['Linux', 'Discord Client', 'Linux',
                          'Mozilla/5.0 (X11; Linux x86_64) '
                          'AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Discord/1.0.9002 Chrome/108.0.5359.215 '
                          'Electron/22.3.24 Safari/537.36'],
                'web': ['Windows', 'Chrome', 'Windows',
                        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                        'AppleWebKit/537.36 (KHTML, like Gecko) '
                        'Chrome/125.0.0.0 Safari/537.36'],
                'xbox': ['Xbox', 'Discord Embedded', 'Xbox',
                         'Mozilla/5.0 (Windows NT 10.0; Win64; x64; '
                         'Xbox; Xbox Series X) AppleWebKit/537.36 '
                         '(KHTML, like Gecko) Chrome/120.0.0.0 '
                         'Safari/537.36 Edge/44.19041'],
                'ps5': ['PS5', 'Discord Embedded', 'PS5',
                        'Mozilla/5.0 (PlayStation; PlayStation 5) '
                        'AppleWebKit/605.1.15 (KHTML, like Gecko) '
                        'Version/15.0 Safari/605.1.15']}
            payload = {
                'token': token,
                'os': session_configs[session_mode][0],
                'browser': session_configs[session_mode][1],
                'device': session_configs[session_mode][2],
                'status': dpb.config['status'],
                'user-agent': dpb.http.user_agent,
                'x-super-properties': dpb.http.encoded_super_properties}
            self.proc.stdin.write(json.dumps(payload) + '\n')
            self.proc.stdin.flush()
            self.running = True
            self.thread = Thread(target=self._reader, daemon=True)
            self.thread.start()
            print('Nitro Sniper (Turbo) starting..')

        def send(self, message):
            if not self.running:
                raise RuntimeError('Process is not running')
            self.proc.stdin.write(json.dumps(message) + '\n')
            self.proc.stdin.flush()

        def stop(self):
            if self.running:
                self.proc.terminate()
                self.proc.wait()
                self.running = False
                print('Nitro Sniper (Turbo) stopped.')

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------


class AutoVoiceLeave(QtCore.QObject):
    @classmethod
    def get_state(cls):
        """Whether auto voice-leave is currently enabled.

        Docstring text unrecovered (2-line slot).
        """
        return getOthersData().get('autovoiceleave') is not False  # const-recovered
    @classmethod
    def get_seconds(cls):
        """Seconds to wait before auto-leaving an empty voice channel.

        Docstring text unrecovered (2-line slot).
        """
        value = getOthersData().get('autovoiceleave')  # const-recovered
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        return cls.DEFAULT_SECONDS

    ############################################################################

    @classmethod
    def get_seconds(cls):
        # docstring lines 9570-9571 unrecovered

        value = getOthersData().get('autovoiceleave')  # const-recovered
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        return cls.DEFAULT_SECONDS


    @classmethod
    def get_state(cls):
        # docstring lines 9565-9566 unrecovered

        return getOthersData().get('autovoiceleave') is not None  # const-recovered
    @classmethod
    def set_state(cls, enabled, seconds=None):
        # docstring lines 9576-9579 unrecovered

        if enabled:
            value = cls.get_seconds() if seconds is None else int(seconds)  # const-recovered
        else:
            value = None  # const-recovered
        setOthersData('autovoiceleave', value)  # const-recovered
        return cls.get_state()
    @classmethod
    def toggle(cls):
        # line 9588 unrecovered (docstring/comment slot)

        return cls.set_state(not cls.get_state())

    ############################################################################

    @classmethod
    def toggle(cls):
        # docstring line 9588 unrecovered

        return cls.set_state(not cls.get_state())
    @classmethod
    def get_watching_channel_id(cls):
        return cls._watching_channel_id

    ############################################################################

    @classmethod
    def get_watching_channel_id(cls):
        return cls._watching_channel_id
    @classmethod
    def set_watching_channel_id(cls, channel_id):
        # line 9596 unrecovered (docstring/comment slot)

        cls._watching_channel_id = channel_id
        return cls._watching_channel_id

    ############################################################################

    @classmethod
    def set_watching_channel_id(cls, channel_id):
        # docstring line 9596 unrecovered

        cls._watching_channel_id = channel_id
        return cls._watching_channel_id
    #----------------------------------------------------------------------------
    async def autoLeaveCountdown(channel_id):
        """Grace period before auto-leaving an empty voice channel. Started as a
            background task when we become the last one in `channel_id`. Elsewhere,
            watching_channel_id is reset to None if someone joins, or if we leave/move
            \ufffd so after the wait, if it STILL points at this channel we're alone here
            and should leave."""
        try:
            await asyncio.sleep(AutoVoiceLeave.get_seconds())
            if AutoVoiceLeave.get_state() and AutoVoiceLeave.get_watching_channel_id() == channel_id and VoiceMuteManager().getActiveChannelId() == channel_id:
                channel = bot.get_channel(int(channel_id))
                if channel:
                    try:
                        await channel.guild.change_voice_state(channel=channel)
                        v = await channel.connect(timeout=0, reconnect=False)
                        await asyncio.sleep(2)
                        await v.disconnect(force=True)
                        await bot.change_voice_state(channel=None)
                        v.cleanup()
                        guild_name = f"({channel.guild.name}) " if channel.guild else ""
                        print(f"Auto Leave VC | {channel.name} {guild_name}| Automatically left voice channel, because you were the last one in it.")
                        logging.info(f"Auto-leaving voice channel {channel.name} ({channel.id}) Automatically left voice channel, because you were the last one in it.")
                        AutoVoiceLeave.set_watching_channel_id(None)
                    except Exception as e:
                        pass
                    AutoVoiceLeave.set_watching_channel_id(None)
            if AutoVoiceLeave.get_watching_channel_id() == channel_id:
                AutoVoiceLeave.set_watching_channel_id(None)
        except Exception as e:
            logging.error(f"Autoleave countdown: {e}")
    #----------------------------------------------------------------------------


class DiscordMfa:  # line 9640
    def __new__(cls):
        if cls._instance is None:  # const-recovered
            cls._instance = super().__new__(cls)
        return cls._instance

    ############################################################################

    def __new__(cls):
        if cls._instance is None:  # const-recovered
            cls._instance = super().__new__(cls)
        return cls._instance
    #----------------------------------------------------------------------------

    class MfaCredentialStore:

        def _load_secrets(self, channel_id=None):
            account = self._mfa_account()
            if account:
                password = keyring.get_password(self.SERVICE,
                                                account)
                if password:
                    return json.loads(password)
                return {}
            return {}

        def setCredentials(self, password, totp_seed):
            if not self._mfa_account:
                raise RuntimeError(
                    'No active profile to store credentials for.')
            secrets = self._load_secrets()
            secrets['password'] = \
                password or secrets.get('password', '')
            secrets['totp_seed'] = \
                ''.join(totp_seed.split()).upper() or \
                secrets.get('totp_seed', '')
            keyring.set_password(
                self.SERVICE, self._mfa_account(),
                json.dumps(secrets))
            return None

        def getPassword(self):
            return self._load_secrets().get('password')

        def isConfigured(self):
            secrets = self._load_secrets()
            return bool(secrets.get('password')) and \
                bool(secrets.get('totp_seed'))

        def __init__(self):
            pass

        def set_token(self, token):
            self.token = token
            self._expires_at = time.monotonic() + 30
            return self.token

        def get_token(self):
            if self.token is None:
                return None
            if self._expires_at is not None and \
                    time.monotonic() >= self._expires_at:
                self.token = None
                self._expires_at = None
                return None
            return self.token

        def _mfa_account(self):
            return getActiveProfileName()

        def verify(self):
            secrets = self._load_secrets()
            return (bot.user.mfa_enabled
                    and bool(secrets.get('totp_seed'))) or \
                (not bot.user.mfa_enabled
                 and bool(secrets.get('password')))

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------


class VoiceMuteManager:  # line 9778
    def __new__(cls):
        if cls._instance is None:  # const-recovered
            cls._instance = super().__new__(cls)
            # lines 9781-9782 unrecovered (docstring/comment gap)
            # (second gap line)
            cls._instance._pending = {}  # const-recovered
            cls._instance._flush_task = None  # const-recovered
            cls._instance._last_flush = 0.0  # const-recovered
        return cls._instance

    ############################################################################

    def __new__(cls):
        if cls._instance is None:  # const-recovered
            cls._instance = super().__new__(cls)
            # lines 9781-9782 unrecovered (docstring/comment gap)
            cls._instance._pending = {}  # const-recovered
            cls._instance._flush_task = None  # const-recovered
            cls._instance._last_flush = 0.0  # const-recovered
        return cls._instance
    #----------------------------------------------------------------------------

    class ChannelManager:

        def __init__(self):
            pass

        def setActiveChannelId(self, active_channel_id):
            self.active_channel_id = active_channel_id

        def getActiveChannelId(self):
            if self.active_channel_id:
                return self.active_channel_id
            if bot.user.voice.channel:
                return bot.user.voice.channel.id
            return None

        def getFriendsSet(self):
            return set(friend.id for friend in bot.friends)

        def getChannelMembers(self):
            channel_id = self.getActiveChannelId()
            channel = bot.get_channel(channel_id)
            if channel_id is None or channel is None:
                return []
            return channel.members

        def _enqueue(self, ids, muted):
            if not ids:
                return
            for userid in ids:
                self._pending[int(userid)] = muted
            self._schedule_flush()

        def _schedule_flush(self):
            if self._flush_task is not None and \
                    not self._flush_task.done():
                return
            self._flush_task = \
                asyncio.create_task(self._flush_after_delay())

        def getIdsToMute(self):
            config = getVoiceMuteConfig()
            enabled = config['enabled']
            mode = config['mode']
            all_ids = {int(uid) for uid in config['list']['ids']}
            automute = getVoiceMuteSetting('non_friends_action') == \
                'automute'
            to_mute = set()
            members = self.getChannelMembers()
            friends = self.getFriendsSet()
            if enabled and mode == 'whitelist':
                for member in members:
                    if member.id == bot.user.id:
                        continue
                    if member.id not in all_ids:
                        to_mute.add(member.id)
                return to_mute
            for member in members:
                if automute and member.id not in friends:
                    to_mute.add(member.id)
            if enabled and mode == 'blacklist':
                for uid in all_ids:
                    to_mute.add(uid)
            return to_mute

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def voiceMuteEmbed(title, description):
        theme = bot.config['theme']
        return (discord_bot.Embed(
                    title=theme['title'],
                    description=description,
                    color=int(theme['color'].replace('#', ''), 16))
                .set_author(name=title,
                            icon_url=theme['author_icon'])
                .set_thumbnail(url=theme['image'])
                .set_footer(text=theme['footer'],
                            icon_url=theme['footer_icon']))

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def parseVoiceMuteIds(raw):
        ids, removed = [], []
        for piece in re.split(r'[,\n]+', raw or ''):
            piece = piece.strip()
            if not piece:
                continue
            if piece.isdigit():
                ids.append(piece)
            else:
                removed.append(piece)
        return ids, removed

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------


class VoiceMuteAddIdModal(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, parent_view):
        super().__init__()
        self.parent_view = parent_view
    #----------------------------------------------------------------------------
    async def on_submit(self, interaction):
        valid, invalid = parseVoiceMuteIds(self.target_ids.value)
        added = sum((1 for uid in valid if addVoiceMuteListId(uid)))
        self.parent_view.render()
        await interaction.response.edit_message(embed=(self.parent_view.embed()), view=(self.parent_view))
        notes = []
        if added:
            notes.append(f"Added **{added}** ID(s).")
        if len(valid) - added:
            notes.append(f"{len(valid) - added} already present.")
        if invalid:
            notes.append(f'Skipped {len(invalid)} invalid (non-numeric): {", ".join(("`{t}`" for t in invalid[:10]))}')
        if notes:
            await interaction.followup.send((" ".join(notes)), ephemeral=True)
    #----------------------------------------------------------------------------


class VoiceMuteRemoveIdModal(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, parent_view):
        super().__init__()
        self.parent_view = parent_view
    #----------------------------------------------------------------------------
    async def on_submit(self, interaction):
        valid, invalid = parseVoiceMuteIds(self.target_ids.value)
        removed = sum((1 for uid in valid if removeVoiceMuteListId(uid)))
        self.parent_view.render()
        await interaction.response.edit_message(embed=(self.parent_view.embed()), view=(self.parent_view))
        notes = []
        if removed:
            notes.append(f"Removed **{removed}** ID(s).")
        if len(valid) - removed:
            notes.append(f"{len(valid) - removed} not in the list.")
        if invalid:
            notes.append(f'Skipped {len(invalid)} invalid (non-numeric): {", ".join(("`{t}`" for t in invalid[:10]))}')
        if notes:
            await interaction.followup.send((" ".join(notes)), ephemeral=True)
    #----------------------------------------------------------------------------


class VoiceMuteListView(discord_bot.ui.View):
    # [confidence=low - see wave45 evidence]
    def __init__(self, author_id):
        super().__init__(author_id=author_id)
        self.render = True  # const-recovered
    #----------------------------------------------------------------------------
    async def interaction_check(self, interaction):
        return interaction.user.id == self.author_id

    #----------------------------------------------------------------------------
    # [confidence=low - see wave45 evidence]
    def embed(self):
        data = getVoiceMuteConfig()
        ids = ', '.join(data.get('voice_mute_list', []))  # const-recovered
        id_text = ids.capitalize() if len(ids) else '-'  # const-recovered
        desc = data.get('voice_mute_list_mode', 'off')  # const-recovered
        return voiceMuteEmbed(id_text, desc)
    #----------------------------------------------------------------------------

    class VoicemuteListView:

        def render(self):
            self.clear_items()
            config = getVoiceMuteConfig()['list']
            button1 = discord_bot.ui.Button(
                label=f'Status: {"ON" if config["enabled"] else "OFF"}',
                style=discord_bot.ButtonStyle.green
                if config['enabled'] else discord_bot.ButtonStyle.red)
            button1.callback = self._toggle_enabled
            self.add_item(button1)
            button2 = discord_bot.ui.Button(
                label=f'Mode: {config["mode"].capitalize()}',
                style=discord_bot.ButtonStyle.primary)
            button2.callback = self._toggle_mode
            self.add_item(button2)
            button3 = discord_bot.ui.Button(
                label='Add ID(s)',
                style=discord_bot.ButtonStyle.secondary)
            button3.callback = self._add_id
            self.add_item(button3)
            button4 = discord_bot.ui.Button(
                label='Remove ID(s)',
                style=discord_bot.ButtonStyle.secondary,
                disabled=not config['ids'])
            button4.callback = self._remove_id
            self.add_item(button4)
            button5 = discord_bot.ui.Button(
                label='Clear list',
                style=discord_bot.ButtonStyle.secondary,
                disabled=not config['ids'])
            button5.callback = self._clear
            self.add_item(button5)

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _rerender(self, interaction):
        self.render()
        await interaction.response.edit_message(embed=(self.embed()), view=self)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _toggle_enabled(self, interaction):
        setVoiceMuteListEnabled(not isVoiceMuteListEnabled())
        await self._rerender(interaction)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _toggle_mode(self, interaction):
        setVoiceMuteListMode("whitelist" if getVoiceMuteListMode() == "blacklist" else "blacklist")
        await self._rerender(interaction)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _add_id(self, interaction):
        await interaction.response.send_modal(VoiceMuteAddIdModal(self))
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _remove_id(self, interaction):
        await interaction.response.send_modal(VoiceMuteRemoveIdModal(self))
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _clear(self, interaction):
        cfg = getVoiceMuteConfig()
        cfg["list"]["ids"] = []
        saveVoiceMuteConfig(cfg)
        await self._rerender(interaction)
    #----------------------------------------------------------------------------


class VoiceMuteSettingsView(discord_bot.ui.View):
    # [confidence=low - see wave45 evidence]
    def __init__(self, author_id):
        super().__init__(author_id=author_id)
        self.render = True  # const-recovered
    #----------------------------------------------------------------------------
    async def interaction_check(self, interaction):
        return interaction.user.id == self.author_id

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class VoicemuteSettingsView:

        def embed(self):
            settings = getVoiceMuteConfig()['settings']
            description = (
                f"**Users other than friends**: "
                f"{'Auto mute' if settings['non_friends_action'] == 'automute' else 'Do nothing'}"
                f"\n**Auto mute when you join a voice channel**: "
                f"{'On' if settings['automute_on_join'] else 'Off'}"
                f"\n**Auto apply to new users joining your channel**: "
                f"{'On' if settings['auto_apply_new_users'] else 'Off'}"
                f"\n**Auto unmute when a user or you leaves**: "
                f"{'On' if settings['auto_unmute_on_leave'] else 'Off'}")
            return voiceMuteEmbed('Voicemute \xbb Settings', description)

        def render(self):
            self.clear_items()
            settings = getVoiceMuteConfig()['settings']
            button1 = discord_bot.ui.Button(
                label=f"Non-friends: "
                      f"{'Auto mute' if settings['non_friends_action'] == 'automute' else 'Do nothing'}",
                style=discord_bot.ButtonStyle.primary)
            button1.callback = self._toggle_non_friends
            self.add_item(button1)
            button2 = discord_bot.ui.Button(
                label=f"Mute on join: "
                      f"{'On' if settings['automute_on_join'] else 'Off'}",
                style=discord_bot.ButtonStyle.green
                if settings['automute_on_join']
                else discord_bot.ButtonStyle.secondary)
            button2.callback = self._toggle_join
            self.add_item(button2)
            button3 = discord_bot.ui.Button(
                label=f"Apply to new users: "
                      f"{'On' if settings['auto_apply_new_users'] else 'Off'}",
                style=discord_bot.ButtonStyle.green
                if settings['auto_apply_new_users']
                else discord_bot.ButtonStyle.secondary)
            button3.callback = self._toggle_new_users
            self.add_item(button3)
            button4 = discord_bot.ui.Button(
                label=f"Unmute on leave: "
                      f"{'On' if settings['auto_unmute_on_leave'] else 'Off'}",
                style=discord_bot.ButtonStyle.green
                if settings['auto_unmute_on_leave']
                else discord_bot.ButtonStyle.secondary)
            button4.callback = self._toggle_unmute_leave
            self.add_item(button4)

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _rerender(self, interaction):
        self.render()
        await interaction.response.edit_message(embed=(self.embed()), view=self)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _toggle_non_friends(self, interaction):
        setVoiceMuteSetting("non_friends_action", "nothing" if getVoiceMuteSetting("non_friends_action") == "automute" else "automute")
        await self._rerender(interaction)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _toggle_join(self, interaction):
        setVoiceMuteSetting("automute_on_join", not getVoiceMuteSetting("automute_on_join"))
        await self._rerender(interaction)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _toggle_new_users(self, interaction):
        setVoiceMuteSetting("auto_apply_new_users", not getVoiceMuteSetting("auto_apply_new_users"))
        await self._rerender(interaction)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def _toggle_unmute_leave(self, interaction):
        setVoiceMuteSetting("auto_unmute_on_leave", not getVoiceMuteSetting("auto_unmute_on_leave"))
        await self._rerender(interaction)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def voicemuteHelpResponse(interaction):
        try:
            text = "**/utils voicemute help** \xbb Show this menu\n**/utils voicemute run** \xbb Mute / unmute users in your voice channel\n**/utils voicemute list** \xbb Manage the whitelist / blacklist\n**/utils voicemute settings** \xbb Configure automatic behavior\n"
            await botCmd(interaction, "Voicemute \xbb Help", text)
        except Exception as e:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
            logging.error(e)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def voicemuteRunResponse(interaction, action):
        try:
            await botCmd(interaction, "Voicemute \xbb Run", f"Placeholder \u2014 would **{action}** users in your voice channel.\n*(logic not implemented yet)*")
        except Exception as e:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
            logging.error(e)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def voicemuteListResponse(interaction):
        try:
            view = VoiceMuteListView(interaction.user.id)
            await interaction.response.send_message(embed=(view.embed()), view=view, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
            logging.error(e)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def voicemuteSettingsResponse(interaction):
        try:
            view = VoiceMuteSettingsView(interaction.user.id)
            await interaction.response.send_message(embed=(view.embed()), view=view, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Error: {e}", ephemeral=True)
            logging.error(e)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    class SettingsBackupStore:

        def _backupsPath(self):
            path = os.path.join(getDataPath(), 'server_backups')
            os.makedirs(path, exist_ok=True)
            return path

        def _sanitize(self, value):
            return re.sub(r'[\\/:*?"<>|]+', '_', str(value)).strip() \
                or 'unnamed'

        def listBackups(self):
            backups = []
            backups_path = self._backupsPath()
            for item in os.listdir(backups_path):
                server_json_path = os.path.join(backups_path, item,
                                                 'server.json')
                if not os.path.isfile(server_json_path):
                    continue
                try:
                    with open(server_json_path, 'r',
                              encoding='utf-8') as f:
                        data = json.load(f)
                except Exception as e:
                    logging.error(f"server backup '{item}' unreadable: {e}")
                    continue
                guild = data.get('guild', {})
                backups.append({
                    'id': data.get('backup_id', item),
                    'backup_name': data.get('backup_name'),
                    'guild_name': guild.get('name', '?'),
                    'guild_id': guild.get('id'),
                    'created': data.get('created', ''),
                    'created_ts': data.get('created_ts', 0),
                    'roles': len(data.get('roles', {})),
                    'channels': len(data.get('channels', {}))
                                + len(data.get('categories', {})),
                    'path': os.path.join(backups_path, item)})
            backups.sort(key=lambda b: b.get('created_ts', 0),
                         reverse=True)
            return backups

        def resolveBackup(self, token):
            token = str(token).strip()
            backups = self.listBackups()
            for backup in backups:
                if str(backup['id']).lower() == token.lower():
                    return backup
            matches = [backup for backup in backups
                       if backup.get('backup_name')
                       and backup['backup_name'].lower()
                       == token.lower()]
            if matches:
                return matches[0]
            partial = [backup for backup in backups
                       if backup.get('backup_name')
                       and (token.lower()
                            in backup['backup_name'].lower()
                            or token.lower()
                            in str(backup['id']).lower())]
            if len(partial) == 1:
                return partial[0]

        def autocompleteChoices(self, current):
            choices = []
            for backup in self.listBackups():
                name = backup['backup_name'] or \
                    backup['guild_name']
                label = f"{backup['backup_name']} " \
                        f"({backup['guild_name']}) " \
                        f"[{backup['id']}]"
                if len(label) > 100:
                    label = label[:97] + '...'
                if current.lower() in f'{name} ' \
                        f"{backup['guild_name']} " \
                        f"{backup['id']}".lower():
                    choices.append(
                        app_commands.Choice(
                            name=label,
                            value=str(backup['id'])))
            return choices[:25]

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------


class ServerBackupManager(discord_bot.ui.View):
    #----------------------------------------------------------------------------
    async def _resolveGuild(self, value):
        value = str(value).strip()
        if value.isdigit():
            g = bot.get_guild(int(value))
            if g:
                return g
            try:
                return await bot.fetch_guild(int(value))
            except Exception:
                return
        lowered = value.lower()
        exact = [g for g in bot.guilds if g.name.lower() == lowered]
        if exact:
            return exact[0]
        partial = [g for g in bot.guilds if lowered in g.name.lower()]
        if len(partial) == 1:
            return partial[0]
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def save(self, interaction, server_value, backup_name):
        author = 'Server Copy \xbb Create'
        try:
            await botCmd(interaction, author, '> Starting server backup, please wait...')

            guild = await self._resolveGuild(server_value)
            if not guild:
                return await editBotCmd(interaction, author, '> :x: Could not resolve that server. Pick it from the autocomplete list, or use its server ID.')


            base = self._backupsPath()
            backup_id = f"{self._sanitize(guild.name)}_{guild.id}_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}"
            backup_dir = os.path.join(base, backup_id)
            suffix = 1
            while os.path.exists(backup_dir):
                backup_dir = os.path.join(base, f"{backup_id}_{suffix}")
                suffix += 1
            backup_id = os.path.basename(backup_dir)
            os.makedirs(backup_dir, exist_ok=True)


            progress = {'phase': 'Starting', 'detail': '', 'lines': []}

            def render(final=False):
                if final:
                    header = f"> :white_check_mark: Saved backup of **{guild.name}**"
                else:
                    header = f"> :hourglass: Saving backup of **{guild.name}**"
                body = '\n'.join(progress['lines']) if progress['lines'] else ''
                tail = ''
                if not final:
                    tail = f"\n> :gear: {progress['phase']}"
                    if progress['detail']:
                        tail += f" ({progress['detail']})"
                    tail += f"\n-# Next update <t:{int(time.time()) + 6}:R>"
                return f"{header}\n{body}{tail}".strip()

            async def push_update(final=False):
                content = render(final=final)
                try:
                    await editBotCmd(interaction, author, content)
                except Exception:
                    try:
                        print(f"Server backup | {progress['phase']}", type_='INFO')
                    except Exception as e:
                        logging.error(f"server backup progress update failed: {e}")

            async def progress_loop():
                try:
                    while True:
                        await push_update()
                        await asyncio.sleep(5)
                except asyncio.CancelledError:
                    pass

            def set_phase(phase, detail=''):
                progress['phase'] = phase
                progress['detail'] = detail

            def mark_done(text):
                progress['lines'].append(f"> :white_check_mark: {text}")

            def serialize_overwrites(channel):


                result = []
                for principal, overwrite in channel.overwrites.items():
                    allow, deny = overwrite.pair()
                    if isinstance(principal, discord.Role):
                        result.append({
                            'target_type': 'role',
                            'id': principal.id,
                            'is_default': principal.is_default(),
                            'allow': allow.value,
                            'deny': deny.value})

                    elif isinstance(principal, discord.Member):
                        result.append({
                            'target_type': 'member',
                            'id': principal.id,
                            'is_default': False,
                            'allow': allow.value,
                            'deny': deny.value})

                return result

            progress_task = asyncio.create_task(progress_loop())
            try:

                set_phase('Saving roles')
                roles_data = []
                everyone_permissions = None
                for role in sorted(guild.roles, key=lambda r: r.position):
                    if role.is_default():
                        everyone_permissions = role.permissions.value
                        continue
                    roles_data.append({
                        'id': role.id,
                        'name': role.name,
                        'permissions': role.permissions.value,
                        'colour': role.colour.value,
                        'hoist': role.hoist,
                        'mentionable': role.mentionable,
                        'position': role.position,
                        'managed': role.managed})

                mark_done(f"Roles ({len(roles_data)})")


                set_phase('Saving channels & categories')
                categories_data = []
                for category in sorted(guild.categories, key=lambda c: c.position):
                    categories_data.append({
                        'id': category.id,
                        'name': category.name,
                        'position': category.position,
                        'overwrites': serialize_overwrites(category)})

                channels_data = []
                for channel in sorted([c for c in guild.channels if not isinstance(c, discord.CategoryChannel)], key=lambda c: c.position):
                    if isinstance(channel, discord.TextChannel):
                        ctype = 'text'
                    elif isinstance(channel, discord.VoiceChannel):
                        ctype = 'voice'
                    elif isinstance(channel, discord.StageChannel):
                        ctype = 'stage'
                    else:
                        continue
                    channels_data.append({
                        'id': channel.id,
                        'type': ctype,
                        'name': channel.name,
                        'position': channel.position,
                        'category_id': channel.category_id,
                        'topic': getattr(channel, 'topic', None),
                        'nsfw': getattr(channel, 'nsfw', False),
                        'slowmode_delay': getattr(channel, 'slowmode_delay', 0),
                        'bitrate': getattr(channel, 'bitrate', None),
                        'user_limit': getattr(channel, 'user_limit', None),
                        'rtc_region': getattr(channel, 'rtc_region', None),
                        'default_auto_archive_duration': getattr(channel, 'default_auto_archive_duration', 1440),
                        'overwrites': serialize_overwrites(channel)})

                mark_done(f"Channels ({len(channels_data)}) & categories ({len(categories_data)})")


                icon_file = banner_file = splash_file = None
                emojis_data = []
                stickers_data = []
                async with ClientSession() as session:
                    async def _download_to(url, path):
                            async with session.get(str(url)) as resp:
                                payload = await resp.read()
                            with open(path, 'wb') as f:
                                f.write(payload)

                    set_phase('Saving icon/banner')
                    if guild.icon:
                        try:
                            ext = 'gif' if guild.icon.is_animated() else 'png'
                            icon_file = f"icon.{ext}"
                            await _download_to(guild.icon.url, os.path.join(backup_dir, icon_file))
                        except Exception as e:
                            icon_file = None
                            logging.error(f"server backup icon failed: {e}")
                    if getattr(guild, 'banner', None):
                        try:
                            ext = 'gif' if guild.banner.is_animated() else 'png'
                            banner_file = f"banner.{ext}"
                            await _download_to(guild.banner.url, os.path.join(backup_dir, banner_file))
                        except Exception as e:
                            banner_file = None
                            logging.error(f"server backup banner failed: {e}")
                    if getattr(guild, 'splash', None):
                        try:
                            splash_file = 'splash.png'
                            await _download_to(guild.splash.url, os.path.join(backup_dir, splash_file))
                        except Exception as e:
                            splash_file = None
                            logging.error(f"server backup splash failed: {e}")

                    source_emojis = list(guild.emojis)
                    if source_emojis:
                        os.makedirs(os.path.join(backup_dir, 'emojis'), exist_ok=True)
                        for idx, emoji in enumerate(source_emojis, start=1):
                            set_phase('Saving emojis', f"{idx}/{len(source_emojis)}")
                            ext = 'gif' if emoji.animated else 'png'
                            fname = f"emojis/{self._sanitize(emoji.name)}_{emoji.id}.{ext}"
                            try:
                                await _download_to(emoji.url, os.path.join(backup_dir, fname))
                                emojis_data.append({'name': emoji.name, 'animated': emoji.animated, 'file': fname})
                            except Exception as e:
                                logging.error(f"server backup emoji '{emoji.name}' failed: {e}")
                        mark_done(f"Emojis ({len(emojis_data)})")

                    def _sticker_ext(s):
                            fmt = (getattr(getattr(s, 'format', None), 'name', '') or '').lower()
                            if fmt == 'gif':
                                return 'gif'
                            if fmt == 'lottie':
                                return 'json'
                            return 'png'

                    source_stickers = list(guild.stickers)
                    if source_stickers:
                        os.makedirs(os.path.join(backup_dir, 'stickers'), exist_ok=True)
                        for idx, sticker in enumerate(source_stickers, start=1):
                            set_phase('Saving stickers', f"{idx}/{len(source_stickers)}")
                            fname = f"stickers/{self._sanitize(sticker.name)}_{sticker.id}.{_sticker_ext(sticker)}"
                            try:
                                await _download_to(sticker.url, os.path.join(backup_dir, fname))
                                stickers_data.append({
                                    'name': sticker.name,
                                    'description': sticker.description or '',
                                    'emoji': getattr(sticker, 'emoji', None) or '\U0001f642',
                                    'format': _sticker_ext(sticker),
                                    'file': fname})

                            except Exception as e:
                                logging.error(f"server backup sticker '{sticker.name}' failed: {e}")
                        mark_done(f"Stickers ({len(stickers_data)})")


                set_phase('Writing manifest')
                manifest = {
                    'schema': 1,
                    'backup_id': backup_id,
                    'backup_name': backup_name.strip() if backup_name else None,
                    'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'created_ts': int(time.time()),
                    'guild': {
                        'id': guild.id,
                        'name': guild.name,
                        'description': guild.description,
                        'afk_timeout': guild.afk_timeout,
                        'afk_channel_name': guild.afk_channel.name if guild.afk_channel else None,
                        'icon_file': icon_file,
                        'banner_file': banner_file,
                        'splash_file': splash_file,
                    },
                    'everyone_permissions': everyone_permissions,
                    'roles': roles_data,
                    'categories': categories_data,
                    'channels': channels_data,
                    'emojis': emojis_data,
                    'stickers': stickers_data,
                }
                with open(os.path.join(backup_dir, 'server.json'), 'w', encoding='utf-8') as f:
                    json.dump(manifest, f, indent=2, ensure_ascii=False)

                name_note = f" as `{manifest['backup_name']}`" if manifest['backup_name'] else ''
                mark_done(f"Saved id `{backup_id}`{name_note}")
                mark_done('Restore later with `/utils servercopy restore`')
                print(f"Server backup saved: {guild} -> {backup_dir}", type_='SUCCESS')
            except Exception as e:
                logging.error(f"server backup fatal error: {e}")
                mark_done(f":x: Stopped early: {e}")
            finally:
                progress_task.cancel()
                try:
                    await progress_task
                except Exception:
                    pass
                await push_update(final=True)
        except Exception as e:
            logging.error(f"ServerBackupManager.save: {e}")
            try:
                await editBotCmd(interaction, author, f"> :x: Error: {e}")
            except Exception:
                pass
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def restore(self, interaction, backup_token, restore_to_value):
        try:
            meta = self.resolveBackup(backup_token)
            if not meta:
                return await interaction.response.send_message(f'> :x: No backup found matching `{backup_token}`. Use the autocomplete or the backup id.', ephemeral=True)
            backup_dir = meta['path']
            try:
                with open(os.path.join(backup_dir, 'server.json'), 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except Exception as e:
                return await interaction.response.send_message(f'> :x: Could not read backup manifest: {e}', ephemeral=True)

            target_guild = await self._resolveGuild(restore_to_value)
            if not target_guild:
                return await interaction.response.send_message('> :x: Could not resolve the target server. Pick it from the autocomplete list, or use its server ID.', ephemeral=True)

            src_name = data.get('guild', {}).get('name', meta.get('guild_name', '?'))
            label = meta.get('backup_name') or src_name

            yes_button = discord_bot.ui.Button(label='Yes', style=discord_bot.ButtonStyle.green)
            no_button = discord_bot.ui.Button(label='No', style=discord_bot.ButtonStyle.red)
            view = discord_bot.ui.View()
            view.add_item(yes_button)
            view.add_item(no_button)

            await interaction.response.send_message(
                f"You're about to restore backup **{label}** (`{meta['id']}`) into **"
                f"{target_guild.name}** (`{target_guild.id}`).\nThe target server will be **completely wiped** (channels, roles, ..) before restoring. Are you sure you want to continue?",
                ephemeral=True, view=view)

            original_message = await interaction.original_response()

            async def no_callback(btn_interaction):
                await btn_interaction.response.send_message('Restore canceled.', ephemeral=True)
                try:
                    await original_message.delete()
                except Exception:
                    pass

            async def yes_callback(btn_interaction):
                await original_message.delete()
                await btn_interaction.response.send_message('> Starting restore, please wait...', ephemeral=True)
                await self._runRestore(btn_interaction, data, backup_dir, target_guild, label)

            yes_button.callback = yes_callback
            no_button.callback = no_callback
        except Exception as e:
            logging.error(f'ServerBackupManager.restore: {e}')
            try:
                await interaction.response.send_message(f'Error: {e}', ephemeral=True)
            except Exception:
                pass
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def _runRestore(self, interaction, data, backup_dir, new_guild, label):


        BASE_DELAY = 2.5
        MAX_RETRIES = 3

        progress = {'phase': 'Starting', 'detail': '', 'lines': []}

        def render(final=False):
            if final:
                header = f'> :white_check_mark: Restored **{label}** into **{new_guild.name}**'
            else:
                header = f'> :hourglass: Restoring **{label}** into **{new_guild.name}**'
            body = '\n'.join(progress['lines']) if progress['lines'] else ''
            tail = ''
            if not final:
                tail = f'\n> :gear: {progress["phase"]}'
                if progress['detail']:
                    tail += f' ({progress["detail"]})'
                tail += f'\n-# Next update <t:{int(time.time()) + 6}:R>'
            return f'{header}\n{body}{tail}'.strip()

        async def push_update(final=False):
            content = render(final=final)
            try:
                await interaction.edit_original_response(content=content)
            except Exception:
                try:
                    if final:
                        print('Restore complete:\n' + '\n'.join(progress['lines']), type_='INFO')
                    else:
                        detail = f' ({progress["detail"]})' if progress['detail'] else ''
                        print(f'Restore progress | {progress["phase"]}{detail}', type_='INFO')
                except Exception as e:
                    logging.error(f'restore progress update failed: {e}')

        async def progress_loop():
            try:
                while True:
                    await push_update()
                    await asyncio.sleep(5)
            except asyncio.CancelledError:
                pass

        def set_phase(phase, detail=''):
            progress['phase'] = phase
            progress['detail'] = detail

        def mark_done(text):
            progress['lines'].append(f'> :white_check_mark: {text}')

        async def with_retry(coro_factory, what='operation'):
            delay = BASE_DELAY
            for attempt in range(1, MAX_RETRIES + 1):
                try:
                    return await coro_factory()
                except (discord.Forbidden, discord.NotFound) as e:
                    logging.error(f'Restore {what} skipped ({type(e).__name__}): {e}')
                    return None
                except Exception as e:
                    retry_after = getattr(e, 'retry_after', None)
                    wait = float(retry_after) + 1 if retry_after else delay
                    if attempt < MAX_RETRIES:
                        logging.error(f'Restore {what} failed (attempt {attempt}/{MAX_RETRIES}): {e}; retrying in {wait:.1f}s')
                        await asyncio.sleep(wait)
                        delay *= 2
                    else:
                        logging.error(f'Restore {what} permanently failed after {MAX_RETRIES} attempts: {e}')
                        return None

        guild_info = data.get('guild', {})
        everyone_role = new_guild.default_role
        role_mapping = {}

        def build_overwrites(entries):
            overwrites = {}
            for entry in entries or []:
                allow = discord.Permissions(int(entry.get('allow', 0)))
                deny = discord.Permissions(int(entry.get('deny', 0)))
                ow = discord.PermissionOverwrite.from_pair(allow, deny)
                if entry.get('target_type') == 'role':
                    if entry.get('is_default'):
                        overwrites[everyone_role] = ow
                    else:
                        mapped = role_mapping.get(entry.get('id'))
                        if mapped:
                            overwrites[mapped] = ow
                elif entry.get('target_type') == 'member':


                    member = new_guild.get_member(int(entry.get('id')))
                    if member:
                        overwrites[member] = ow
            return overwrites

        progress_task = asyncio.create_task(progress_loop())
        try:

            set_phase('Updating server info')
            icon_bytes = None
            icon_file = guild_info.get('icon_file')
            if icon_file and os.path.isfile(os.path.join(backup_dir, icon_file)):
                try:
                    with open(os.path.join(backup_dir, icon_file), 'rb') as f:
                        icon_bytes = f.read()
                except Exception as e:
                    logging.error(f'Restore icon read failed: {e}')
            async def _edit_info():
                kwargs = {'name': guild_info.get('name', new_guild.name)}
                if icon_bytes:
                    kwargs['icon'] = icon_bytes
                await new_guild.edit(**kwargs)
            await with_retry(_edit_info, 'server name/icon')
            if guild_info.get('description') and 'COMMUNITY' in new_guild.features:
                await with_retry(lambda: new_guild.edit(description=guild_info['description']), 'server description')
            banner_file = guild_info.get('banner_file')
            if banner_file and os.path.isfile(os.path.join(backup_dir, banner_file)):
                try:
                    with open(os.path.join(backup_dir, banner_file), 'rb') as f:
                        banner_bytes = f.read()
                    await with_retry(lambda: new_guild.edit(banner=banner_bytes), 'server banner')
                except Exception as e:
                    logging.error(f'Restore banner failed: {e}')
            splash_file = guild_info.get('splash_file')
            if splash_file and os.path.isfile(os.path.join(backup_dir, splash_file)):
                try:
                    with open(os.path.join(backup_dir, splash_file), 'rb') as f:
                        splash_bytes = f.read()
                    await with_retry(lambda: new_guild.edit(splash=splash_bytes), 'server splash')
                except Exception as e:
                    logging.error(f'Restore splash failed: {e}')
            mark_done('Server name & icon')


            set_phase('Wiping target channels')
            existing_channels = [c for c in new_guild.channels if not isinstance(c, discord.CategoryChannel)]
            for idx, channel in enumerate(existing_channels, start=1):
                if channel.id == interaction.channel_id:
                    continue
                set_phase('Wiping target channels', f'{idx}/{len(existing_channels)}')
                await with_retry(lambda ch=channel: ch.delete(), f'delete channel {channel.name}')
                await asyncio.sleep(BASE_DELAY)

            set_phase('Wiping target categories')
            existing_categories = list(new_guild.categories)
            for idx, category in enumerate(existing_categories, start=1):
                set_phase('Wiping target categories', f'{idx}/{len(existing_categories)}')
                await with_retry(lambda c=category: c.delete(), f'delete category {category.name}')
                await asyncio.sleep(BASE_DELAY)

            set_phase('Wiping target roles')
            deletable_roles = [r for r in new_guild.roles if not r.is_default() and not r.managed]
            for idx, role in enumerate(deletable_roles, start=1):
                set_phase('Wiping target roles', f'{idx}/{len(deletable_roles)}')
                await with_retry(lambda r=role: r.delete(), f'delete role {role.name}')
                await asyncio.sleep(BASE_DELAY)
            mark_done('Target wiped')


            set_phase('Restoring roles')
            saved_roles = sorted(data.get('roles', []), key=lambda r: r.get('position', 0))
            creatable_roles = [r for r in saved_roles if not r.get('managed')]
            for idx, role in enumerate(creatable_roles, start=1):
                set_phase('Restoring roles', f'{idx}/{len(creatable_roles)}')
                async def _create_role(role=role):
                    return await new_guild.create_role(
                        name=role.get('name', 'new role'),
                        permissions=discord.Permissions(int(role.get('permissions', 0))),
                        colour=discord.Colour(int(role.get('colour', 0))),
                        hoist=role.get('hoist', False),
                        mentionable=role.get('mentionable', False))

                new_role = await with_retry(_create_role, f'create role {role.get("name")}')
                if new_role:
                    role_mapping[role.get('id')] = new_role
                await asyncio.sleep(BASE_DELAY)
            mark_done(f'Roles restored ({len(role_mapping)}/{len(creatable_roles)})')


            everyone_permissions = data.get('everyone_permissions')
            if everyone_permissions is not None:
                await with_retry(lambda: everyone_role.edit(permissions=discord.Permissions(int(everyone_permissions))), '@everyone permissions')


            set_phase('Reordering roles')
            async def _reorder():
                positions = {}
                for new_pos, src_role in enumerate(creatable_roles, start=1):
                    mapped = role_mapping.get(src_role.get('id'))
                    if mapped:
                        positions[mapped] = new_pos
                if positions:
                    await new_guild.edit_role_positions(positions=positions)
            await with_retry(_reorder, 'reorder roles')


            set_phase('Restoring categories')
            category_mapping = {}
            saved_categories = sorted(data.get('categories', []), key=lambda c: c.get('position', 0))
            for idx, category in enumerate(saved_categories, start=1):
                set_phase('Restoring categories', f'{idx}/{len(saved_categories)}')
                async def _create_cat(category=category):
                    return await new_guild.create_category(
                        name=category.get('name', 'category'),
                        overwrites=build_overwrites(category.get('overwrites')),
                        position=category.get('position', 0))

                new_cat = await with_retry(_create_cat, f'create category {category.get("name")}')
                if new_cat:
                    category_mapping[category.get('id')] = new_cat
                await asyncio.sleep(BASE_DELAY)
            mark_done(f'Categories restored ({len(category_mapping)}/{len(saved_categories)})')


            set_phase('Restoring channels')
            saved_channels = sorted(data.get('channels', []), key=lambda c: c.get('position', 0))
            restored_channels = 0
            for idx, channel in enumerate(saved_channels, start=1):
                set_phase('Restoring channels', f'{idx}/{len(saved_channels)}')
                parent = category_mapping.get(channel.get('category_id'))
                overwrites = build_overwrites(channel.get('overwrites'))
                ctype = channel.get('type')
                async def _create_channel(channel=channel, parent=parent, overwrites=overwrites, ctype=ctype):
                    if ctype == 'text':
                        return await new_guild.create_text_channel(
                            name=channel.get('name', 'channel'), overwrites=overwrites, category=parent,
                            position=channel.get('position', 0), topic=channel.get('topic'),
                            nsfw=channel.get('nsfw', False), slowmode_delay=channel.get('slowmode_delay', 0) or 0,
                            default_auto_archive_duration=channel.get('default_auto_archive_duration', 1440) or 1440)

                    if ctype == 'voice':
                        bitrate = channel.get('bitrate') or 64000
                        return await new_guild.create_voice_channel(
                            name=channel.get('name', 'channel'), overwrites=overwrites, category=parent,
                            position=channel.get('position', 0),
                            bitrate=min(bitrate, new_guild.bitrate_limit),
                            user_limit=channel.get('user_limit') or 0, rtc_region=channel.get('rtc_region'))

                    if ctype == 'stage':
                        return await new_guild.create_stage_channel(
                            name=channel.get('name', 'channel'), overwrites=overwrites, category=parent,
                            position=channel.get('position', 0))

                    return None
                created = await with_retry(_create_channel, f'create channel {channel.get("name")}')
                if created:
                    restored_channels += 1
                await asyncio.sleep(BASE_DELAY)
            mark_done(f'Channels restored ({restored_channels}/{len(saved_channels)})')


            afk_name = guild_info.get('afk_channel_name')
            if afk_name:
                set_phase('Setting AFK channel')
                async def _afk():
                    new_afk = discord.utils.get(new_guild.voice_channels, name=afk_name)
                    if new_afk:
                        await new_guild.edit(afk_channel=new_afk, afk_timeout=guild_info.get('afk_timeout', 300) or 300)
                await with_retry(_afk, 'set AFK channel')
                mark_done('AFK channel')


            RATELIMIT_ABORT_SECONDS = 30
            manual_notes = []

            async def _upload_media(
                items,
                subdir_label,
                create_fn):
                uploaded = 0
                ratelimit_started = None
                i = 0
                total = len(items)
                while i < total:
                    entry, path = items[i]
                    set_phase(f'Restoring {subdir_label}', f'{i + 1}/{total}')
                    try:
                        await asyncio.wait_for(create_fn(entry, path), timeout=RATELIMIT_ABORT_SECONDS)
                        uploaded += 1
                        ratelimit_started = None
                        i += 1
                        await asyncio.sleep(BASE_DELAY)
                    except asyncio.TimeoutError:
                        logging.error(f"Restore {subdir_label} ratelimited (timeout) on '{entry.get('name', '?')}' - aborting")
                        return uploaded, True, total - i
                    except discord.NotFound as e:
                        logging.error(f"Restore {subdir_label} skipped '{entry.get('name', '?')}' (NotFound): {e}")
                        i += 1
                    except Exception as e:
                        code = getattr(e, 'code', None)
                        status = getattr(e, 'status', None)
                        retry_after = getattr(e, 'retry_after', None)
                        if code in (30008, 30018, 30039):
                            logging.error(f'Restore {subdir_label} hit max capacity (code {code}): {e} - aborting')
                            return uploaded, True, total - i
                        is_ratelimit = status == 429 or bool(retry_after) or status == 403 and code == 50001
                        if is_ratelimit:
                            logging.error(f"Restore {subdir_label} ratelimited '{entry.get('name', '?')}' (status={status}, code={code}): {e}")
                            if ratelimit_started is None:
                                ratelimit_started = time.time()
                            if time.time() - ratelimit_started >= RATELIMIT_ABORT_SECONDS:
                                return uploaded, True, total - i
                            await asyncio.sleep(min(float(retry_after) if retry_after else 5, 10))
                        elif isinstance(e, discord.Forbidden):
                            logging.error(f"Restore {subdir_label} skipped '{entry.get('name', '?')}' (Forbidden {code}): {e}")
                            i += 1
                        else:
                            logging.error(f"Restore {subdir_label} failed '{entry.get('name', '?')}': {e}")
                            i += 1
                return uploaded, False, 0

            emoji_items = []
            for em in data.get('emojis', []):
                p = os.path.join(backup_dir, em.get('file', ''))
                if em.get('file') and os.path.isfile(p):
                    emoji_items.append((em, p))
            if emoji_items:
                set_phase('Restoring emojis')
                async def _make_emoji(entry, path):
                    with open(path, 'rb') as f:
                        img = f.read()
                    return await new_guild.create_custom_emoji(name=entry.get('name', 'emoji'), image=img)
                up, aborted, left = await _upload_media(emoji_items, 'emojis', _make_emoji)
                mark_done(f'Emojis restored ({up}/{len(emoji_items)})')
                if aborted:
                    manual_notes.append(f'emojis ({left} left)')

            sticker_items = []
            for st in data.get('stickers', []):
                p = os.path.join(backup_dir, st.get('file', ''))
                if st.get('file') and os.path.isfile(p):
                    sticker_items.append((st, p))
            if sticker_items:
                set_phase('Restoring stickers')
                async def _make_sticker(entry, path):
                    with open(path, 'rb') as f:
                        payload = f.read()
                    fmt = entry.get('format', 'png')
                    return await new_guild.create_sticker(
                        name=entry.get('name', 'sticker'),
                        description=entry.get('description') or entry.get('name', 'sticker'),
                        emoji=entry.get('emoji') or '\U0001f642',
                        file=discord.File(io.BytesIO(payload), filename=f'{self._sanitize(entry.get("name", "sticker"))}.{fmt}'))

                up, aborted, left = await _upload_media(sticker_items, 'stickers', _make_sticker)
                mark_done(f'Stickers restored ({up}/{len(sticker_items)})')
                if aborted:
                    manual_notes.append(f'stickers ({left} left)')

            if manual_notes:
                mark_done(f':warning: Discord ratelimit/cap hit - {", ".join(manual_notes)} not uploaded. They stay in the backup. Upload them manually later.')

            print(f'Server restored from backup: {label} -> {new_guild}', type_='SUCCESS')
        except Exception as e:
            logging.error(f'Restore server fatal error: {e}')
            mark_done(f':x: Stopped early: {e}')
        finally:
            progress_task.cancel()
            try:
                await progress_task
            except Exception:
                pass
            await push_update(final=True)
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def delete(self, interaction, backup_token):
        try:
            meta = self.resolveBackup(backup_token)
            if not meta:
                return await interaction.response.send_message(f"> :x: No backup found matching `{backup_token}`. Use the autocomplete or the backup id.", ephemeral=True)
            label = meta.get("backup_name") or meta.get("guild_name", "?")
            backup_dir = meta["path"]
            yes_button = discord_bot.ui.Button(label="Yes", style=(discord_bot.ButtonStyle.green))
            no_button = discord_bot.ui.Button(label="No", style=(discord_bot.ButtonStyle.red))
            view = discord_bot.ui.View()
            view.add_item(yes_button)
            view.add_item(no_button)
            await interaction.response.send_message(f"You're about to permanently delete backup **{label}** (`{meta['id']}`) from disk.\nThis cannot be undone. Continue?", ephemeral=True, view=view)
            original_message = await interaction.original_response()

            async def no_callback(btn_interaction):
                await btn_interaction.response.send_message("Deletion canceled.", ephemeral=True)
                try:
                    await original_message.delete()
                except Exception:
                    pass

            async def yes_callback(btn_interaction):
                try:
                    shutil.rmtree(backup_dir)
                    try:
                        await original_message.delete()
                    except Exception:
                        pass
                    await btn_interaction.response.send_message(f'> :white_check_mark: Deleted backup **{label}** (`{meta["id"]}`).', ephemeral=True)
                    print(f"Server backup deleted: {backup_dir}", type_="INFO")
                except Exception as e:
                    logging.error(f"ServerBackupManager.delete rmtree failed: {e}")
                    await btn_interaction.response.send_message(f"> :x: Failed to delete: {e}", ephemeral=True)

            yes_button.callback = yes_callback
            no_button.callback = no_callback
        except Exception as e:
            logging.error(f"ServerBackupManager.delete: {e}")
            try:
                await interaction.response.send_message(f"Error: {e}", ephemeral=True)
            except Exception:
                pass
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def listResponse(self, interaction):
        [
         None, None]
        author = "Server Copy \xbb List"
        try:
            backups = self.listBackups()
            if not backups:
                return await botCmd(interaction, author, "> No server backups saved yet. Create one with `/utils servercopy create`.")
            lines = [f"**Saved server backups - {len(backups)}**",
             "-# the `id` is copyable - paste it into `/utils servercopy restore` or `delete`",
             ""]
            for b in backups:
                name = b.get("backup_name")
                title = f"**{name}**" if name else f'**{b["guild_name"]}**'
                lines.append(f'{title} - `{b["id"]}`\n-# {b["guild_name"]} - {b["roles"]} roles - {b["channels"]} channels - {b.get("created", "")}')

            text = "\n".join(lines)
            if len(text) > 4000:
                text = text[:4000].rsplit("\n", 1)[0] + f"\n-# ...and more - see `{self._backupsPath()}`"
            await botCmd(interaction, author, text)
        except Exception as e:
            logging.error(f"ServerBackupManager.listResponse: {e}")
            try:
                await interaction.response.send_message(f"Error: {e}", ephemeral=True)
            except Exception:
                pass
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------
    async def autocomplete_server_backups(interaction, current):
        return serverBackupManager.autocompleteChoices(current)
    #----------------------------------------------------------------------------


class SoftBanModal(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, interaction, member):
        super().__init__(interaction=interaction)
        self.interaction = interaction
        self.member = member
    #----------------------------------------------------------------------------
    async def on_submit(self, interaction):
        guild = bot.get_guild(interaction.guild_id)
        if self.reason:
            reason = self.reason.value
            await guild.ban((discord.Object(self.member.id)), reason=reason, delete_message_days=7)
            await guild.unban((discord.Object(self.member.id)), reason=reason)
            await botCmd(interaction, "Softban", f"**Softbanned**: {self.member.name}\n**Reason**: {reason}")
        else:
            await guild.ban((discord.Object(self.member.id)), delete_message_days=7)
            await guild.unban(discord.Object(self.member.id))
            await botCmd(interaction, "Softban", f"**Softbanned**: {self.member.name}")
    #----------------------------------------------------------------------------


class PurgeModal(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, interaction, message):
        super().__init__(interaction=interaction)
        self.interaction = interaction
        self.message = message
    #----------------------------------------------------------------------------
    async def on_submit(self, interaction):
        await interaction.response.defer(ephemeral=(getConfigData()["private"]))
        channel = await bot.fetch_channel(interaction.channel_id)
        amount = int(self.reason.value)
        await channel.purge(limit=amount)
        await botCmd(interaction, "Purge", f"Deleted **{amount}** messages", followup=True)
    #----------------------------------------------------------------------------


class CleanModal(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, interaction, message):
        super().__init__(interaction=interaction)
        self.interaction = interaction
        self.message = message
    #----------------------------------------------------------------------------

    async def on_submit(self, interaction):
        await interaction.response.defer(ephemeral=getConfigData()['private'])
        channel = await bot.fetch_channel(interaction.channel_id)
        amount = int(self.reason.value)
        deleted = 0
        async for message in channel.history(limit=None):
            if message.author == bot.user:
                try:
                    await message.delete()
                    deleted += 1
                except:
                    pass
                if deleted >= amount:
                    break
                await asyncio.sleep(0.3)
        await botCmd(interaction, 'Clean', f'Successfully deleted **{amount}** messages', followup=True)
    #----------------------------------------------------------------------------


class NukeModal(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, interaction, message):
        super().__init__(interaction=interaction)
        self.interaction = interaction
        self.message = message
    #----------------------------------------------------------------------------
    async def on_submit(self, interaction):
        await interaction.response.defer(ephemeral=(getConfigData()["private"]))
        channel = await bot.fetch_channel(interaction.channel_id)
        if self.reason.value.lower() == "yes":
            await channel.clone()
            await channel.delete()
        elif self.reason.value.lower() == "no":
            await botCmd(interaction, "Nuke", "Cancelled", followup=True)
        else:
            await botCmd(interaction, "Nuke", "Provide a valid input: **yes** or **no**", followup=True)
    #----------------------------------------------------------------------------


class SnipeModal(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, interaction, message):
        super().__init__(interaction=interaction)
        self.interaction = interaction
        self.message = message
    #----------------------------------------------------------------------------
    async def on_submit(self, interaction):
        try:
            await interaction.response.defer(ephemeral=(getConfigData()["private"]))
            channel = await bot.fetch_channel(interaction.channel_id)
            try:
                amount = int(self.reason.value)
            except:
                amount = 1
            if channel.id not in bot.config["snipe"] or len(bot.config["snipe"][channel.id]) == 0:
                return await botCmd(interaction, "Snipe", "No deleted messages found in this channel", followup=True)
            snipes = bot.config["snipe"][channel.id][-amount:]
            msg = f"**{len(snipes)}** deleted message(s) found in {channel}:\n"
            for snipe in snipes:
                msg += f'**{escape_markdown(snipe["author"])}** at {discord.utils.format_dt(snipe["timestamp"])}:\n'
                msg += snipe["content"] if snipe["content"] else "*No content*"
                msg += "\n\n"

            return await botCmd(interaction, "Snipe", msg, followup=True)
        except Exception as e:
            sys.stdout.write(f"\n{e}\n")
    #----------------------------------------------------------------------------


class TriggerTypingModal(discord_bot.ui.Modal):
    # [confidence=low - see wave45 evidence]
    def __init__(self, interaction, message):
        super().__init__(interaction=interaction)
        self.interaction = interaction
        self.message = message
    #----------------------------------------------------------------------------
    async def on_submit(self, interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            channel = await bot.fetch_channel(interaction.channel_id)
            try:
                amount = int(self.reason.value)
            except:
                amount = 10
            await interaction.followup.send(f"Started fake typing for {amount} second(s)", ephemeral=True)
            async with channel.typing():
                await asyncio.sleep(amount)
        except Exception as e:
            sys.stdout.write(f"\n{e}\n")
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def removeSpoilers(content):
        return re.sub(r'\|\|(.*?)\|\|', r'\1', content)


    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def getActiveCtxMenus():
        context_menus = []
        for name, data in bot.config['context_menus'].items():
            if data.get('active', False):
                menu_type = data['type']
                if data.get('description'):
                    context_menus.append(
                        f'- {name}\n-# Type: {menu_type}\n'
                        f'-# Description: {data.get("description")}')
                else:
                    context_menus.append(
                        f'- {name}\n-# Type: {menu_type}')
        if not context_menus:
            return 'No active context menus.'
        return '**Active context menus**:\n' + '\n'.join(context_menus)

    # NOTE: recovery flag - see the native_core docstring

    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    def extract_chat_response(text):
        match = re.search(r'</think\s*(.*)', text, re.DOTALL)
        if match:
            response = match.group(1).strip()
        else:
            response = text.strip()
        if response.startswith('"') and response.endswith('"'):
            response = response[1:-1]
        response = response.replace('\\n', '\n').replace('\\r', '').replace('\\t', ' ')
        return response

    # NOTE: recovery flag - see the native_core docstring
    #----------------------------------------------------------------------------
    #----------------------------------------------------------------------------

    async def askAI(query, system):
        try:
            ai_settings = getAISettings()
            client = AsyncOpenAI(base_url=ai_settings.get('base_url'), api_key=ai_settings.get('api_key'))
            completion = await client.chat.completions.create(
                extra_headers={'X-Title': bot.user.display_name},
                model=ai_settings.get('model'),
                messages=[
                    {'role': 'user', 'content': query},
                    {'role': 'system', 'content': system},
                ],
            )
            if completion.choices:
                return completion.choices[0].message.content
            else:
                return None
        except Exception as e:
            return e
    #----------------------------------------------------------------------------
    # Reconstructed from oracle/out/vm45/dis/D_L12017.txt (py38 wordcode, argc=0, flags=0x3).
    # Const table in evidence was a decoy (ints only); every literal below inferred
    # semantically and marked "# const-recovered". NOP-with-nonzero-arg sites, deref
    # jump-guards, and eaten subscripts/calls are marked "# guard-inferred".
    # Original module line numbers from the unit line map shown as # Lnnnnn.
    # Line-map holes (12108-12186, 12189-12292, 12295-12337, 12370-12442, 12454-12476)
    # are hidden nested-handler code objects (consts), not part of this unit stream.


def Nighty2():
    checkTurboSniper = spp_export_api('checkTurboSniper', ['checkTurboSniper'])  # L12020 const-recovered (impl = hidden const)
    checkfonts = spp_export_api('checkfonts', ['checkfonts'])  # L12032 const-recovered
    checksounds = spp_export_api('checksounds', ['checksounds'])  # L12064 const-recovered
    checkfonts()  # L12096
    checkTurboSniper()  # L12097
    checksounds()  # L12098
    # L12107: handler registrations (original handler bodies were hidden
    # native consts; reconstructed as async handlers per the fork's API)
    @bot_app.event
    async def on_ready():  # L12108-12186 (body reconstructed)
        logging.info('on_ready: app client connected')  # const-recovered

    @bot_app.event
    async def on_app_command_completion():  # L12188-12292
        pass  # const-recovered (body 12189-12292 hidden)

    @bot.listen('on_socket_raw_receive')  # L12294
    async def onSocketRawReceive(message):  # body 12295-12337 hidden
        _gatewayWatchdog.append(message)  # guard-inferred

    _gatewayWatchdog = [False, 0]  # L12338 guard-inferred
    @bot.listen('onReady')  # L12368
    async def onReady():  # body 12370-12442 hidden
        pass  # guard-inferred

    def showAuthPopup(title, text):  # L12453 sync popup fn  # body 12454-12476 hidden
        logging.error('%s: %s', title, text)  # const-recovered
    AUTH_SERVER_DOWN_TITLE = 'Authentication server unavailable'  # L12446 const-recovered
    AUTH_SERVER_DOWN_TEXT = 'Nighty could not reach the login server. Please restart and try again.'  # L12447 const-recovered
    AUTH_OFFLINE_TITLE = 'No internet connection'  # L12448 const-recovered
    AUTH_OFFLINE_TEXT = 'Nighty needs an internet connection to log in. Check your network and try again.'  # L12450 const-recovered
    isConnectionError = spp_export_api('isConnectionError', ['isConnectionError'])  # L12450 const-recovered
    session = requests.Session()  # L12477
    session.mount('https://', HTTPAdapter(max_retries=Retry(total=50, status_forcelist=[429, 500, 503, 504], backoff_factor=5)))  # L12479 const-recovered (sibling saveKeyToAppdata idiom; NOP 5 site)
    try:  # L12480 (SETUP_FINALLY 0x7a)
        json_data = {'uuid': str(encryptRSA(getUUID())), 'key': str(encryptRSA(getLicense())) if getLicense() and isValidKey(getLicense()) else str(encryptRSA(getUUID()))}  # L12482-12484: VERIFIED fields from live capture + server 422 probe (uuid+key required)
        response = session.post(SERVER_TO_USE, json=json_data, verify=False, timeout=(10, 30))  # L12485 const-recovered; guard-inferred verify kw at NOP 298
        if response.status_code == 200:  # L12486 const-recovered 200
            try:  # L12487
                data = response.json()  # L12488
            except Exception:  # L12489
                logging.error('Failed to parse auth response: %s', response.text[:500])  # L12490 const-recovered fmt + slice 500
                showAuthPopup(AUTH_SERVER_DOWN_TITLE, AUTH_SERVER_DOWN_TEXT)  # L12491
                return  # L12492
            if data.get('ok') != 'ok':  # L12493 const-recovered 'ok' key/value
                logging.error('Auth server rejected the license: %s', data)  # L12494 const-recovered
                showAuthPopup('License error', str(data.get('error')) + ' - https://nighty.one/support')  # L12495 const-recovered / guard-inferred (AUTH_SUPPORT_URL cell inlined)
                return  # L12496
            bot.config['token'] = data['token']  # L12497 guard-inferred (NOP subscript sites)
            bot.config['nighty'] = data['nighty']  # L12500 guard-inferred
            bot.config['key'] = data['key']  # L12501 guard-inferred
            nighty_key = data['key']  # L12502 const-recovered
            if 'key' in data:  # L12503 guard-inferred (C60 subscript artifact)
                evaluate_js('animateFormOut();')  # L12504 const-recovered (sibling idiom)
            # L12505-12527: undecodable region (armor-consumed opcodes)  # guard-inferred
            if isValidKey(nighty_key):  # L12528
                updateKey(nighty_key)  # L12529
            if __version__ not in data['versions']:  # L12530 guard-inferred (C62 subscript artifact)
                evaluate_js('pauseWithError({title: "Update required", description: "Your Nighty version is no longer supported."})')  # L12531 const-recovered
            # L12532-12553: undecodable region (armor-consumed opcodes)  # guard-inferred
            acc_token = getCurrentToken()  # L12555
            if acc_token:  # L12556 (LOAD_DEREF guard artifact dropped)
                if is_discord_token_valid(acc_token):  # L12557
                    autoApp()  # L12558
                else:  # L12559
                    main_ui.load_url(url='https://nighty.one/download/files/ui/discord_login.html')  # L12560 const-recovered
            else:  # L12561
                main_ui.load_url(url='https://nighty.one/download/files/ui/discord_login.html')  # L12562 const-recovered
        elif response.status_code == 401:  # L12563 const-recovered 401 (sibling invalid-license status)
            if main_ui.create_confirmation_dialog('Invalid license', 'Your license key is invalid or already in use. Enter a different key?'):  # L12564 const-recovered
                main_ui.load_url(url='https://nighty.one/download/files/ui/auth.html')  # L12565 const-recovered
            else:  # L12566
                main_api.close()  # L12567
        else:  # L12568
            logging.error('Auth request failed: %s: %s', response.status_code, response.text[:500])  # L12569 const-recovered fmt + slice 500
            showAuthPopup(AUTH_SERVER_DOWN_TITLE, AUTH_SERVER_DOWN_TEXT + f' ({response.status_code})')  # L12570 guard-inferred (C71/C72 concat pieces)
            main_ui.load_url(url='https://nighty.one/download/files/ui/auth.html')  # L12572 guard-inferred (jump guard lost)
            main_ui.load_url(url='https://nighty.one/download/files/ui/auth.html')  # L12574 guard-inferred (jump guard lost)
    except Exception as e:  # L12576
        logging.error('Nighty2 bootstrap failed: %s: %s', type(e).__name__, e)  # L12577 const-recovered
        if getUUID() == '00000000-0000-0000-0000-000000000000' or 'banned' in str(getUUID()).lower():  # L12578 guard-inferred (banned-hwid check, consts unknown)
            showAuthPopup('Device blocked', 'This device has been blocked from using Nighty.')  # L12579 const-recovered
        elif isConnectionError(e):  # L12580
            showAuthPopup(AUTH_OFFLINE_TITLE, AUTH_OFFLINE_TEXT)  # L12581
        else:  # L12582
            showAuthPopup('Unexpected error', f'{type(e).__name__}: {e}')  # L12583 const-recovered / guard-inferred (FORMAT_VALUE artifacts)
    find_discord_exe = spp_export_api('find_discord_exe', ['find_discord_exe'])  # L12598 const-recovered
    saveTokenToConfigCl = spp_export_api('saveTokenToConfigCl', [str])  # L12604 const-recovered (str sig per LOAD_GLOBAL str @974; MAP_ADD artifact)
    checkWebLogin = spp_export_api('checkWebLogin', ['checkWebLogin'])  # L12625 const-recovered
    Thread(target=checkWebLogin).start()  # L12673 const-recovered 'target'
#----------------------------------------------------------------------------

def checkTurboSniper():
    turbo_sniper_path = os.path.join(getNightyPath(),
                                     'TurboSniper.exe')
    if not os.path.exists(turbo_sniper_path):
        try:
            with urllib.request.urlopen(
                    'https://nighty.one/public_downloads/'
                    'TurboSniper.exe',
                    timeout=30) as response:
                with open(turbo_sniper_path, 'wb') as f:
                    f.write(response.read())
        except Exception:
            pass

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def checkfonts():
    font_urls = [
        'https://nighty.one/fonts/light249d0a057895c668.woff2',
        'https://nighty.one/fonts/45efa6936fdfb918.woff2',
        'https://nighty.one/fonts/ggsans-Normal.woff2',
        'https://nighty.one/fonts/ggsans-Semibold.woff2',
        'https://nighty.one/fonts/ggsans-Bold.woff2']
    fonts = ['light249d0a057895c668.woff2',
             '45efa6936fdfb918.woff2',
             'ggsans-Normal.woff2',
             'ggsans-Semibold.woff2',
             'ggsans-Bold.woff2']
    fonts_folder = os.path.join(getDataPath(), 'fonts')
    os.makedirs(fonts_folder, exist_ok=True)
    for url, filename in zip(font_urls, fonts):
        font_path = os.path.join(fonts_folder, filename)
        if not os.path.exists(font_path):
            try:
                font_data = urllib.request.urlopen(
                    url, timeout=15).read()
                with open(font_path, 'wb+') as f:
                    f.write(font_data)
            except Exception:
                pass

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def checksounds():
    sound_urls = [
        'https://nighty.one/download/files/sounds/connected.mp3',
        'https://nighty.one/download/files/sounds/'
        'disconnected.wav',
        'https://nighty.one/download/files/sounds/'
        'giveaway_found.wav',
        'https://nighty.one/download/files/sounds/'
        'nitro_sniped.wav',
        'https://nighty.one/download/files/sounds/pinged.wav',
        'https://nighty.one/download/files/sounds/typing.wav',
        'https://nighty.one/download/files/sounds/'
        'relationship.mp3',
        'https://nighty.one/download/files/sounds/'
        'roleupdates.mp3',
        'https://nighty.one/download/files/sounds/'
        'nickupdates.mp3']
    sounds = ['connected.mp3',
              'disconnected.wav',
              'giveaways.wav',
              'nitro.wav',
              'pinged.wav',
              'typing.wav',
              'friends.mp3',
              'roles.mp3',
              'nicknames.mp3']
    for url, filename in zip(sound_urls, sounds):
        if not os.path.exists(
                f'{getDataPath()}/sounds/{filename}'):
            try:
                sound_data = urllib.request.urlopen(
                    url, timeout=15).read()
                with open(
                        f'{getDataPath()}/sounds/{filename}',
                        'wb+') as f:
                    f.write(sound_data)
            except Exception as e:
                print(f'Error downloading sound {filename} '
                      f'({url}): {e}', type_='ERROR')

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def isConnectionError(error):
    return isinstance(
        error,
        (requests.exceptions.ConnectionError,
         requests.exceptions.Timeout,
         requests.exceptions.RetryError,
         requests.exceptions.ChunkedEncodingError))


#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def find_discord_exe(discord_path):
    for root, dirs, files in os.walk(discord_path):
        for file in files:
            if file.lower() == 'discord.exe':
                return os.path.join(root, file)

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def saveTokenToConfigCl(token):
    r = requests.get(
        'https://discord.com/api/v10/users/@me',
        headers={
            'Authorization': token,
            'Content-Type': 'application/json',
            'User-Agent': (
                'Mozilla/5.0 (Windows NT 10.0; WOW64) '
                'AppleWebKit/537.36 (KHTML, like '
                'Gecko) discord/1.0.9001 '
                'Chrome/83.0.4103.122 '
                'Electron/9.3.5 Safari/537.36')},
        verify=False,
        timeout=20)
    if r.status_code == 200:
        data = r.json()
        username = data.get('username')
        config = getConfigData()
        logins = config['logins']
        logins[username] = {
            'token': str(token),
            'date_added': datetime.now().strftime(
                '%d %B %Y, at %H:%M:%S'),
            'active': True}
        config = getConfigData()
        config['logins'] = logins
        saveConfigData(config)
        setActiveProfile(username)
        autoApp()
    else:
        evaluate_js('location.reload();')
        return {'status': 'error', 'text': 'Invalid token.'}


#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def checkWebLogin():
    wait_for_selected_login.wait()
    if selected_option == 'web_login':
        api = WebLoginApi()
        js_code = ('\n                console.log(`injected`)\n'
                   '                var previousUrl = '
                   'window.location.href;\n'
                   '                function checkUrlChange() '
                   '{\n'
                   '                    var currentUrl = '
                   'window.location.href;\n'
                   '                    if (currentUrl !== '
                   'previousUrl) {\n'
                   '                        previousUrl = '
                   'currentUrl;\n'
                   '                        console.log(`URL '
                   'changed: ${currentUrl}`)\n'
                   '                        pywebview.api.'
                   'url_change_callback(currentUrl);\n'
                   '                    }\n'
                   '                    setTimeout('
                   'checkUrlChange, 1000); // Check every 1 '
                   'second\n'
                   '                }\n\n'
                   '                checkUrlChange();\n'
                   '                ')
        window = webview.create_window(
            'Login to Discord',
            url='https://discord.com/login',
            width=1075,
            height=670,
            resizable=False,
            frameless=False,
            js_api=api)
        api.set_window(window)

        def on_loaded():
            window.evaluate_js(js_code)

        def on_closed():
            os.execv(sys.executable, ['python'] + sys.argv)

        window.events.closed += on_closed
        window.events.loaded += on_loaded

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def addFirewallRules(port, name):
    if not subprocess.run(
            ['powershell', '-Command',
             f"Get-NetFirewallRule -DisplayName '{name}' "
             f"-ErrorAction SilentlyContinue"],
            capture_output=True, text=True).stdout.strip():
        subprocess.run(
            ['powershell', '-Command',
             f"New-NetFirewallRule -DisplayName '{name}' "
             f"-Direction Inbound -Action Allow -Protocol "
             f"TCP -LocalPort {port}"],
            check=True)
        logging.info(
            f'Inbound firewall rule added for port {port}')
    if not subprocess.run(
            ['powershell', '-Command',
             f"Get-NetFirewallRule -DisplayName '{name}' "
             f"-ErrorAction SilentlyContinue"],
            capture_output=True, text=True).stdout.strip():
        subprocess.run(
            ['powershell', '-Command',
             f"New-NetFirewallRule -DisplayName '{name}' "
             f"-Direction Outbound -Action Allow -Protocol "
             f"TCP -LocalPort {port}"],
            check=True)
        logging.info(
            f'Outbound firewall rule added for port {port}')


#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def startWebview():
    try:
        webview.start(
            debug='--cqbtools' in sys.argv,
            http_server=False,
            gui='edgechromium',
            private_mode=True,
            user_agent=('Mozilla/5.0 (Windows NT 10.0; '
                        'Win64; x64) AppleWebKit/537.36 '
                        '(KHTML, like Gecko) '
                        'Chrome/91.0.4472.124 '
                        'Safari/537.36'))
    except Exception as e:
        logging.error(f'WVE - {e}')

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def startFlaskServer():
    logging.info(
        f'\U0001f310 Browser API available at: http://'
        f"{getWebConfigData().get('host') or 'localhost'}:"
        f"{getWebConfigData().get('port') or 80}")
    try:
        ssl = getWebConfigData().get('ssl')
        host = getWebConfigData().get('host') or '0.0.0.0'
        port = getWebConfigData().get('port') or \
            (443 if ssl else 80)
        try:
            addFirewallRules(port, f'NightyWeb/{port}')
        except:
            pass
        logging.getLogger('werkzeug').setLevel(logging.ERROR)
        if getWebConfigData().get('ssl'):
            ssl = getWebConfigData()['ssl']
            socketio.run(
                web_app, host=host, port=port, debug=False,
                ssl_context=(ssl.get('cert'),
                             ssl.get('private_key')),
                use_reloader=False,
                allow_unsafe_werkzeug=True)
        else:
            socketio.run(
                web_app, host=host, port=port, debug=False,
                use_reloader=False,
                allow_unsafe_werkzeug=True)
    except Exception as e:
        logging.error(e)

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def handle_uncaught_exception(loop, context):
    logging.error(
        f"Uncaught exception: {context.get('message')}")
    exception = context.get('exception')
    if exception:
        logging.error(f'asyncio: {exception}')

# NOTE: recovery flag - see the native_core docstring

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def on_load():
    main_api.set_window(main_ui)
    main_ui.evaluate_js(
        'document.documentElement.style.zoom = 0;')


#----------------------------------------------------------------------------
#----------------------------------------------------------------------------

def on_closed():
    os.kill(os.getpid(), SIGTERM)

# NOTE: recovery flag - see the native_core docstring


# ---------------------------------------------------------------------------
# Module wiring (reconstructed: the original module-level body was never
# captured in any evidence bank; this block defines the globals the
# function bodies reference, per the boot semantics in Nighty2 and the
# fence-session traces). See HANDOFF.md rebuild notes.
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

__version__ = '2.6.1'  # the exe this source was recovered from

SERVER_TO_USE = 'https://eu.nighty.one/v2'  # VERIFIED: heap plaintext capture + live probe (422 on missing fields, 500 on invalid crypto)
main_ui = None
main_api = None
notification_sender = None
session = requests.Session()
adapter = HTTPAdapter(max_retries=Retry(total=5, connect=5,
                                        read=5, backoff_factor=0.5,
                                        status_forcelist=[429, 500,
                                                          503, 504]))
session.mount('https://', adapter)
session.mount('http://', adapter)

# reconstructed wiring: the flask + socketio globals the function
# bodies reference (web_app in startFlaskServer, socketio.emit in
# the js bridge). same pattern as the other globals in this block.
web_app = Flask(__name__)
socketio = SocketIO(web_app)

# app instances (derived: NightyUserApp = the app-commands client
# per L3940 ctor evidence; bot = the webview JS bridge per its API:
# listen/config/evaluate_js)
class _BotBridge:  # reconstructed: the webview-side bot object
    def __init__(self):
        self.config = {}
        self.commands = []  # wired for the ported commandSort/botCmd walk

    def listen(self, *a, **k):
        def deco(fn):
            return fn
        return deco

    def evaluate_js(self, *a, **k):
        return None


bot_app = NightyUserApp()
bot = _BotBridge()


# license natives (spp functions in the original; plain-Python
# reconstructions per the native lane evidence)
def getLicense():  # reconstructed: reads the license key file
    for cand in (os.path.join(os.environ.get('APPDATA', ''),
                              'Nighty', 'license.key'),
                 os.path.join(os.path.dirname(os.path
                              .abspath(__file__)),
                              'license.key')):
        if os.path.exists(cand):
            return open(cand, encoding='utf-8').read().strip()
    return None


def isValidKey(key):  # reconstructed: NIGHTY key format check
    return bool(key) and '-NIGHTY-' in str(key)


def updateKey(key):  # reconstructed: saves a refreshed license key
    if not key:
        return
    try:
        target = os.path.join(os.environ.get('APPDATA', ''),
                              'Nighty', 'license.key')
        os.makedirs(os.path.dirname(target), exist_ok=True)
        open(target, 'w', encoding='utf-8').write(str(key).strip())
    except Exception:
        pass


def is_discord_token_valid(token):  # reconstructed: GET /users/@me check
    if not token:
        return False
    try:
        r = session.get('https://discord.com/api/v9/users/@me',
                        headers={'Authorization': token}, timeout=10)
        return r.status_code == 200
    except Exception:
        return False


RSA_PUBLIC_KEY_PEM = (
    b'-----BEGIN PUBLIC KEY-----\n'
    b'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvtk0RFtY6XcnA+tH8qEq\n'
    b'fxko7jvqChZVILgavkGfFJpn5T0Yqt2zwbLRoaoEjWVvSQoxva/MTdPw+P9p+41f\n'
    b'3qZx31r6HanEAwS9G19l9MJobbelmw4FG73poCY5ER2N2vKDDnm0kkyD84jLUZWj\n'
    b'0TpzQnRb6h/WJnVD0lbTTMv3kqEIp9ZMlWkWSaCe35ZdLrY2Cpop3gSClHhhWxfQ\n'
    b'WRM7VT3rUZq76JQkoxUmFePmp5EFAU4SXuflU+mWY0nSDricEuAS7SWb9n1zigCp\n'
    b'etcZehBbHZPywXozhdKJr6HZZoHw6Gq/oWCZTAKr2LOKdtj9ko3H2uKLNlHHK6C/\n'
    b'hQIDAQAB\n'
    b'-----END PUBLIC KEY-----'
)

# ---------------------------------------------------------------------------
# Recovered units, ported verbatim (2026-10-18): the bodies the module
# wiring referenced but never defined. Sources: source/Nighty.py (the
# evidence-graded recovery) and tools/native_core. Provenance markers
# ([E:], const-recovered etc.) travel with the bodies. Names that are
# still absent after this section are listed in rebuild/README.md.
# ---------------------------------------------------------------------------

# native-lane items (tools/native_core)
APP_VERIFICATION_MFA_URL = \
    'https://nighty.one/download/files/ui/app_verification_mfa.html'
APP_VERIFICATION_PASS_URL = \
    'https://nighty.one/download/files/ui/app_verification_pass.html'

_IMAGE_URL_PATTERN = (
    r'^(https?://)([a-zA-Z0-9.-]+)(\.[a-zA-Z]{2,})'
    r'(:\d+)?(/[\w./?%&=-]*)?$')


def _decrypt_n1_field(value):
    """Shared decrypt chain for the getCurrent* getters - each getter
    flattens this inline (three evidenced copies in the corpus); the
    chain: [3:] strip, '=' * (4 - len % 4) pad, base64.b64decode,
    win32crypt.CryptUnprotectData(...)[1].decode('utf-8'). The [1]
    index and the [3:] strip are evidenced (slots 233 / 1033)."""
    payload = value[3:]
    if len(payload) % 4:
        payload += '=' * (4 - len(payload) % 4)
    try:
        raw = base64.b64decode(payload)
        return win32crypt.CryptUnprotectData(raw, None, None, None, 0)[1] \
            .decode('utf-8')
    except Exception:
        return None


def _merge_defaults(config, defaults):
    """[E:] items/isinstance/get/deepcopy cascade seen in getVoiceMuteConfig
    and getVoiceMuteHistory streams; exact nesting reconstructed from the
    items-get-items-deepcopy sequence in the const flow."""
    for key, value in defaults.items():
        if isinstance(value, dict):
            cur = config.get(key)
            if not isinstance(cur, dict):
                config[key] = copy.deepcopy(value)
            else:
                _merge_defaults(cur, value)
        elif key not in config:
            config[key] = value
    return config


# wiring the recovered units expect (reconstructed, same policy as the
# module wiring block above)
start_time = time.time()
AUTO_DEFER_AFTER = 0.05  # reconstructed: _autoDeferSlowCommand debounce
LOGIN_PAGE_HTML = ''  # FLAG: payload register-held, never recovered

# voicemute store paths + defaults: names and shapes documented in
# tools/native_core/voice_mute_store.py (voicemute.json is an object,
# voicemute_history.json an array). Default CONTENT is unknown, so {}.
voicemute_path = os.path.join(getNightyPath(), 'voicemute.json')
voicemute_history_path = os.path.join(getNightyPath(),
                                      'voicemute_history.json')
VOICEMUTE_DEFAULTS = {}

try:
    from pygetwindow import getActiveWindow  # reconstructed dependency
except ImportError:
    getActiveWindow = None


def _config_store(name, default):
    """RECONSTRUCTED: the evidenced config-getter family pattern -
    JSON file in the Nighty appdata dir, merged over defaults. The
    real getter bodies were module-level and never recovered; this
    shim only exists so the ported recovered units stay callable.
    """
    path = os.path.join(getNightyPath(), name + '.json')
    config = copy.deepcopy(default)
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
            loaded = json.load(fh)
        if isinstance(loaded, dict):
            _merge_defaults(loaded, config)
            return loaded
    except Exception:
        pass
    return config


def getScriptsConfig():
    # evidenced: '/misc/scripts.json' (const pool [1636])
    try:
        with open(getDataPath() + '/misc/scripts.json', 'r',
                  encoding='utf-8', errors='ignore') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {'enabled': {}}
    except Exception:
        return {'enabled': {}}


def getNotifications():
    return _config_store('notifications', {'toast': {'toast': True}})


def getChannelInfo():
    return _config_store('channel', {})


def getBasicHeaders():
    return {'Authorization': getCurrentToken(),
            'Content-Type': 'application/json'}


# --- evidenced data-store constants (fence27 const-pool dump, entries
# 832-1727, plus the native-core store docstrings). (r) = filename or
# value reconstructed; the variable itself is pool-evidenced.
context_path = getDataPath() + '/context.json'  # (r) filename; var [1694]
noleave_path = getDataPath() + '/noleave.json'  # evidenced: noleave_store
force_private_path = getDataPath() + '/force_private.json'  # (r) [1719]
SNIPE_CACHE_MAX_AGE = 7 * 86400  # (r) placeholder; var [1649]
SNIPE_CACHE_MAX_TOTAL = 256 * 1024 * 1024  # (r) placeholder; var [1651]


def _read_json_store(path, default):
    """read side shared by the store getters below - the write sides
    (addKeyword/removeKeyword etc.) are recovered and defined above"""
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
            data = json.load(fh)
        return data if isinstance(data, type(default)) else default
    except Exception:
        return default


def getKeywords():
    # evidenced store: '/keywords.json' [1656]; write side recovered
    return _read_json_store(getDataPath() + '/keywords.json', {})


def getRPCPresets():
    # evidenced: 'rpc' + '/presets.json' [831-832]
    return _read_json_store(getRPCPath() + '/presets.json', {})


def getUserProfileData():
    # evidenced: '/profile.json' [845]
    return _read_json_store(getDataPath() + '/profile.json', {})


def getDiscoverablesConfig():
    # evidenced: '/misc/discoverables.json' [1634]
    return _read_json_store(getDataPath() + '/misc/discoverables.json', {})
__custom_feature_listeners__ = {}
nighty_wss = None  # bound to the live connection at runtime


class _Registry:  # reconstructed: the callback/func stores the UI bridge uses
    def __init__(self):
        self._map = {}

    def register(self, key, fn):
        self._map[key] = fn

    def unregister(self, key):
        self._map.pop(key, None)

    def deject_all(self):
        self._map.clear()


callback_store = _Registry()
func_store = _Registry()
UI = discord_bot.ui  # partial: Button/Select/Checkbox live here; the
# Text/Input/Image/Toggle/Table classes were module-body definitions that
# were never recovered (isinstance sites degrade, documented)


def commandSort(command):
    return command.name



def convert_custom_emojis(message):
    if not isinstance(message, str):
        return message
    return re.sub(r'<a?:(\w+):\d+>', r':\1:', message)


def truncate_string(text, max_length):
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + '...'



def break_text_into_lines(self):
    font_metrics = QtGui.QFontMetrics(self.font())
    lines = []
    current_line = ''
    for item in self.original_text:
        if (font_metrics.horizontalAdvance
                (current_line + item) < self.max_width):
            current_line = current_line + item
        else:
            lines.append(current_line)
            current_line = item
    if current_line:
        lines.append(current_line)
    return ('<div style="line-height:' + self.line_height
            + ';">' + '<br>'.join(lines) + '</div>')


def requestAppToken():
    main_ui.load_url(
        url='https://nighty.one/download/files/ui/app_token.html')



def getScriptCodeData(filename):
    path = filename if filename.endswith('.py') \
        else filename + '.py'
    for dirpath, dirnames, filenames in os.walk(
            str(getScriptsPath())):
        if path in filenames:
            with open(os.path.join(dirpath, path), 'r',
                      encoding='utf-8', errors='ignore') as f:
                return f.read()
    return None



def get_metadata_from_decorator(code):
    results = []
    try:
        tree = ast.parse(code)
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) or \
                    isinstance(node, ast.ClassDef):
                for decorator in node.decorator_list:
                    if isinstance(decorator, ast.Call):
                        if decorator.func.id == 'nightyScript':
                            metadata = {}
                            for keyword in decorator.keywords:
                                metadata[keyword.arg] = \
                                    ast.literal_eval(
                                        keyword.value)
                            results.append(metadata)
        if results:
            return results[0]
        return {}
    except Exception:
        return {}



def getGIFsBackup(name):
    path = str(getDataPath()) + '/backups/' + str(name) \
        + '/gifs.json'
    if not os.path.exists(path):
        return None
    with open(path, encoding='utf-8', errors='ignore') as f:
        return json.load(f)



def getReadableUptime():
    uptime = int(time.time() - start_time)
    days = uptime // (24 * 3600)
    rem = uptime % (24 * 3600)
    hours = rem // 3600
    rem = rem % 3600
    minutes = rem // 60
    seconds = rem % 60
    parts = []
    if days > 0:
        parts.append(str(days) + ' day'
                     + ('s' if days > 1 else ''))
    if hours > 0:
        parts.append(str(hours) + ' hour'
                     + ('s' if hours > 1 else ''))
    if minutes > 0:
        parts.append(str(minutes) + ' minute'
                     + ('s' if minutes > 1 else ''))
    sec = str(seconds) + ' second' + ('s' if seconds > 1 else '')
    if not parts:
        parts.append(sec)
    elif len(parts) > 1:
        parts.append(parts.pop() + ', and ' + sec)
    else:
        parts.append(parts.pop() + ' and ' + sec)
    return ', '.join(parts)


async def fetchAccessToken(connection):
    """
        Fetches a new Spotify access token using the connection's refresh token.
        """
    new_access_token = await connection.fetch_access_token()
    expires_in = 240
    bot.config["spotify_token_cache"]["access_token"] = new_access_token
    bot.config["spotify_token_cache"]["expires_at"] = time.time() + expires_in
    return new_access_token

async def runBlocking(func, *args, **kwargs):
    return await asyncio.get_event_loop().run_in_executor(None, lambda: func(*args, **kwargs))

def processDThemeData(theme_data, values):
    try:
        for key in ['title', 'footer', 'image',
                    'author_icon', 'footer_icon',
                    'large_image', 'color']:
            if theme_data.get(key):
                theme_data[key] = extractDRPCValues(
                    theme_data[key], values)
                if re.compile(
                        r'\{[^\}]+\}').search(
                        theme_data[key]):
                    theme_data[key] = \
                        extractDRPCBotValues(
                            theme_data[key])
    except Exception as e:
        logging.error(f'DT error: {e}')
    return theme_data


def get_custom_emojis(content):
    custom_emojis = re.findall(
        r'(<a?:[a-zA-Z0-9_]+:\d+>)', content)
    emojis = {}
    for emoji in custom_emojis:
        m = re.match(r'<a?:([a-zA-Z0-9_]+):(\d+)>', emoji)
        if m:
            name, emoji_id = m.groups()
            extension = ('gif'
                         if emoji.startswith('<a:')
                         else 'png')
            emojis[emoji] = (
                f'https://cdn.discordapp.com/emojis/'
                f'{emoji_id}.{extension}')
    return emojis



def create_on_connect_handler(self, sniperbot):
    def on_connect():
        self.handle_connect(sniperbot)  # FLAG: placeholder body 4951-4956


    return on_connect


def create_on_message_handler(self, sniperbot):
    def on_message(message):
        sniperbot.handle_message(message)  # FLAG: placeholder body 4961-5000
    return on_message


def getDRPCValues():
    return {
        'name': bot.config.get('name', bot.user.name),
        'display_name': bot.config.get(
            'display_name', bot.user.display_name),
        'avatar_url': bot.config.get(
            'avatar_url',
            bot.user.display_avatar.url),
        'cpu_perc': bot.config.get('cpu_perc', 0),
        'ram_perc': bot.config.get('ram_perc', 0),
        'local_time': bot.config.get('local_time', 0),
        'uptime': bot.config.get('uptime',
                                 getReadableUptime()),
        'current_timestamp': bot.config.get(
            'current_timestamp', 0),
        'friends_count': str(len(bot.friends)),
        'discoverables_count': bot.config.get(
            'discoverables_count', 0),
        'online_discoverables_count': bot.config.get(
            'online_discoverables_count', 0),
        'online_nighty_users': bot.config.get(
            'online_nighty_users', 0),
        'servers_count': str(len(bot.guilds)),
        'nighty_build': str(__version__),
        'nighty_version': bot.config.get('version', 0),
        'active_app': bot.config.get('active_app', 0),
        'spotify_song': bot.config.get('spotify_song', 0),
        'spotify_artist': bot.config.get('spotify_artist', 0),
        'spotify_album': bot.config.get('spotify_album', 0),
        'spotify_cover_url': bot.config.get(
            'spotify_cover_url', 0),
        'spotify_song_url': bot.config.get(
            'spotify_song_url', 0),
        'spotify_start': bot.config.get('spotify_start', 0),
        'spotify_end': bot.config.get('spotify_end', 0),
        'spotify_lyrics': bot.config.get('spotify_lyrics', 0),
        'state': bot.config.get('state', 0),
        'details': bot.config.get('details', 0),
        'state_url': bot.config.get('state_url', 0),
        'details_url': bot.config.get('details_url', 0),
        'large_text': bot.config.get('large_text', 0),
        'small_text': bot.config.get('small_text', 0),
        'large_image': bot.config.get('large_image', 0),
        'small_image': bot.config.get('small_image', 0),
    }


async def getSpotifyHeaders():
    spotify_username = getConfigData().get('spotify_username')
    spotify_connections = [c for c in bot.config.get('connections') or [] if 'spotify' in c.type]
    if not spotify_connections:
        return None


    connection = spotify_connections[0]
    if spotify_username is not None:
        for c in spotify_connections:
            if spotify_username in c.name:
                connection = c
                break
    if bot.config['spotify_token_cache']['access_token'] and time.time() < bot.config['spotify_token_cache']['expires_at']:
        return {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {bot.config["spotify_token_cache"]["access_token"]}',
        }
    try:
        spotify_token = await fetchAccessToken(connection)
    except Exception as e:
        logging.error(f'Spotify access token: {e}')
        return None
    if spotify_token:
        return {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {spotify_token}',
        }
    return None


def isNotActiveDiscord(message, user):
    if message is None and user is None:
        return True
    window = getActiveWindow()
    if not window:
        return True
    title = window.title
    if 'Discord' not in title:
        return True
    if '|' in title:
        m = re.match(r'#([^|]+) \| ([^-]+) - Discord',
                     title)
        if not m:
            return True
        channel_name = m.group(1).strip()
        guild_name = m.group(2).strip()
        if (not message.guild
                or channel_name != message.channel.name
                or guild_name != message.guild.name):
            return True
        return False
    if '@' in title:
        m = re.match(r'@([^ ]+) - Discord', title)
        if not m:
            return True
        handle = m.group(1).strip()
        if message:
            name = message.author.global_name
        elif user:
            name = user.global_name
        else:
            return True
        return handle != name
    return True


def showToast(text, title, url, type_, details, timeout,
              message, user):
    if not getNotifications()['toast']['toast']:
        return None
    if url:
        if 'discord.com' in url:
            url = url.replace('https://', 'discord://')
    if not isNotActiveDiscord(message, user):
        return None
    if getNotifications()['toast']['settings'].get('duration'):
        timeout = int(
            getNotifications()['toast']['settings']['duration'])
    if getNotifications()['toast']['settings'].get('image_url'):
        logo_url = getNotifications()['toast']['settings'][
            'image_url']
    else:
        logo_url = ('https://nighty.one/img/nighty.png')
    notification_sender.sendToast(
        text,
        logo_url=logo_url,
        on_click=url,
        type_=type_,
        title=title,
        details=details,
        timeout=timeout)
    return None



def sendAppNotification(content, discord_url, channel, type_,
                       message):
    if discord_url:
        discord_url = discord_url.replace(
            'https://', 'discord://')
    if channel:
        channel = getChannelInfo(channel)
    print(content, url=discord_url, discordChannel=channel,
          type_=type_, message=message)
    return None


async def sendWebhookNotification(webhook_url, title, text):
    theme = getThemeData()
    notifications = getNotifications()
    try:
        async with ClientSession() as sess:
            await discord.Webhook.from_url(webhook_url, session=sess).send(username=(notifications["webhook"]["settings"]["name"]),
              avatar_url=(notifications["webhook"]["settings"]["avatar"]),
              content=(bot.user.mention if notifications["webhook"]["settings"]["pings"] else None),
              embed=discord.Embed(title=f'{theme["title"]} | {title}',
              description=(text if text else None),
              color=(int(theme["color"].replace("#", ""), 16))).set_footer(text=(theme["footer"]),
              icon_url=(theme["footer_icon"])).set_thumbnail(url=(theme["image"])).set_image(url=(theme["large_image"])))
    except Exception as e:
        try:
            logging.error(e)
        finally:
            e = None
            del e

async def dmToClientUser(title, content):
    try:
        nighty_user = await bot_app.fetch_user(bot.user.id)
        return await nighty_user.send(embed=discord_bot.Embed(title=bot.config["theme"]["title"],
           description=content,
           color=int(bot.config["theme"]["color"].replace("#", ""), 16)).set_thumbnail(url=bot.config["theme"]["image"]).set_footer(text=bot.config["theme"]["footer"], icon_url=bot.config["theme"]["footer_icon"]).set_author(name=title, icon_url=bot.config["theme"]["author_icon"]).set_image(url=bot.config["theme"]["large_image"]))
    except Exception as e:
        logging.error(e)

def setUserProfileState(toggle):
    try:
        path = f'{getDataPath()}/profile.json'
        with open(path, 'r',
                  encoding='utf-8',
                  errors='ignore') as f:
            data = json.load(f)
        data['running'] = toggle
        with open(path, 'w',
                  encoding='utf-8',
                  errors='ignore') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass
    return None


async def getAsset(app_id, key):
    async with ClientSession() as session:
        async with session.get(f'https://discord.com/api/v10/oauth2/applications/{app_id}/assets') as req:
            app_assets = await req.json()
    for t_list in app_assets:
        try:
            if str(key) == t_list['name']:
                return t_list['id']
        except:
            pass


def loadScripts(first=False):
    for command in bot.commands:
        if not command.extras.get('built-in'):
            bot.remove_command(command.name)
            sys.stdout.write(
                f'\nCommand unloaded: {command.name}\n')
    for event_name, listeners \
            in bot.extra_events.items():
        for listener in listeners:
            if (listener.__name__
                    in bot.config['built_in_events']
                    and listener.__name__
                    in __custom_feature_listeners__):
                bot.remove_listener(listener, event_name)
                sys.stdout.write(
                    f'\nUnloaded event: {event_name}: '
                    f'{listener.__name__}\n')
    try:
        ScriptEngine().deject_all()
    except Exception:
        pass
    count = 0
    loaded = []
    enabled = getScriptsConfig()['enabled']
    for filename in os.listdir(
            f'{getDataPath()}/scripts'):
        if os.path.isdir(os.path.join(
                f'{getDataPath()}/scripts', filename)):
            for subfile in os.listdir(
                    f'{getDataPath()}'
                    f'/scripts/{filename}'):
                if subfile.endswith('.py'):
                    if (os.path.splitext(subfile)[0]
                            in enabled):
                        with Lock():
                            try:
                                source = open(
                                    f'{getDataPath()}'
                                    f'/scripts'
                                    f'/{filename}'
                                    f'/{subfile}',
                                    encoding='utf-8',
                                    errors='ignore'
                                ).read()
                                ScriptEngine().inject(
                                    os.path.splitext(
                                        subfile)[0],
                                    f'# -*- coding: '
                                    f'utf-8 -*-\n{source}')
                                count += 1
                                loaded.append(
                                    os.path.splitext(
                                        subfile)[0])
                            except Exception as e:
                                logging.error(
                                    f'Script error: '
                                    f'{filename} | {e}')
                                print(f'{filename} '
                                      f'script: {e}')
                                showToast(
                                    text=(
                                        f'Error loading '
                                        f'script: '
                                        f'{filename}'),
                                    type_='ERROR',
                                    title='Script error',
                                    details=(
                                        f'Error loading '
                                        f'script: '
                                        f'{filename}'
                                        f'\nTraceback: '
                                        f'{e}'))
                                removeEnabledScript(
                                    os.path.splitext(
                                        subfile)[0])
        elif filename.endswith('.py'):
            if (os.path.splitext(filename)[0]
                    in enabled):
                with Lock():
                    try:
                        source = open(
                            f'{getDataPath()}/scripts'
                            f'/{filename}',
                            encoding='utf-8',
                            errors='ignore'
                        ).read()
                        ScriptEngine().inject(
                            os.path.splitext(filename)[0],
                            f'# -*- coding: utf-8 -*-'
                            f'\n{source}')
                        count += 1
                        loaded.append(
                            os.path.splitext(filename)[0])
                    except Exception as e:
                        logging.error(
                            f'Script error: '
                            f'{filename} | {e}')
                        print(f'Error in script: '
                              f'{filename} | {e}')
                        showToast(
                            text=(
                                f'Error loading script: '
                                f'{filename}'),
                            type_='ERROR',
                            title='Script error',
                            details=(
                                f'Error loading script: '
                                f'{filename}'
                                f'\nTraceback: {e}'))
                        removeEnabledScript(
                            os.path.splitext(filename)[0])
    print(f'{count} script(s) loaded!')
    showToast(text=f'{count} script(s) loaded!',
             type_='SUCCESS',
             title='Scripts loaded',
             details=(f'{count} script(s) loaded!\n'
                      + ', '.join(loaded)))



def unloadScripts():
    for command in bot.commands:
        if not command.extras.get('built-in'):
            bot.remove_command(command.name)
            logging.debug(f'Unloaded command: {command.name}')
    for event_name, listeners \
            in bot.extra_events.items():
        for listener in listeners:
            if (listener.__name__
                    in bot.config['built_in_events']
                    and listener.__name__
                    in __custom_feature_listeners__):
                bot.remove_listener(listener, event_name)
                logging.debug(
                    f'Unloaded event: {event_name}: '
                    f'{listener.__name__}')
    ScriptEngine().deject_all()



def reloadAllScripts():
    evaluate_js('clearCustomUITabs();')
    global __custom_ui_tabs__
    __custom_ui_tabs__ = []
    unloadScripts()
    loadScripts()



def get_script_path(filename):
    return os.path.join(getScriptsPath(), filename)



def get_theme_path(theme_name):
    return os.path.join(
        f'{getDataPath()}/themes',
        f'{theme_name}.json')



def createApp():
    js_source = (
        '\nconsole.log(`injected`)\n'
        'var previousUrl = window.location.href;\n'
        'function checkUrl() {\n'
        '    var currentUrl = window.location.href;\n'
        '    console.log(`current URL: ${currentUrl}`)\n'
        '    pywebview.api.url_callback_change(currentUrl);\n'
        '    setTimeout(checkUrl, 1000); '
        '// Check every second\n'
        '}\n\n'
        'checkUrl();\n'
        '                ')
    api = AppCreateApi()
    window = webview.create_window(
        'Create app',
        url='https://discord.com/login',
        width=1200,
        height=1000,
        resizable=True,
        frameless=False,
        js_api=api)

    def on_loaded():
        api.discordAppLogin()
        window.evaluate_js(js_source)

    api.set_window(window)
    window.events.loaded += on_loaded



def autoApp():
    config = getConfigData()
    if not config['logins'][getActiveProfileName()].get('app') or \
            not config['logins'][getActiveProfileName()]['app'] \
            .get('id') or \
            not config['logins'][getActiveProfileName()]['app'] \
            .get('id'):
        createApp()
        return None
    if getConfigData()['logins'][getActiveProfileName()]['app'] \
            .get('id') and \
            getConfigData()['logins'][getActiveProfileName()]['app'] \
            .get('token'):
        if is_discord_bot_token_valid(getCurrentAppToken()):
            bot.run(token=getCurrentToken(), reconnect=True)
            return None
        if getConfigData()['logins'][getActiveProfileName()]['app'] \
                .get('id'):
            if not check_app_id(getConfigData()['logins']
                               [getActiveProfileName()]['app']
                               .get('id')):
                createApp()
                return None
        logging.error('App token not valid')
        requestAppToken()
    else:
        if getConfigData()['logins'][getActiveProfileName()]['app'] \
                .get('id'):
            if not check_app_id(getConfigData()['logins']
                               [getActiveProfileName()]['app']
                               .get('id')):
                createApp()
                return None
            logging.error('App token not valid')
            requestAppToken()


class AppCreateApi:

    def __init__(self):
        self._window = None

    def set_window(self, window):
        self._window = window

    def hide(self):
        self._window.hide()
        bot.run(token=getCurrentToken(), reconnect=True)

    def close(self):
        self._window.destroy()

    def discordLogin(self):
        getConfigData()
        self._window.evaluate_js(
            f'\n    if (window.location.href !== '
            f'"https://discord.com/oauth2/authorize?client_id='
            f'{getCurrentAppId()}") {{\n'
            f'        document.body.appendChild('
            f'document.createElement `iframe`).contentWindow'
            f'.localStorage.token = `"{getCurrentToken()}"`\n'
            f'        window.location.href = '
            f'"https://discord.com/oauth2/authorize?client_id='
            f'{getCurrentAppId()}";\n    }}')

    def url_change_callback_app(self, url):
        if url == 'https://discord.com/oauth2/authorized':
            self._window.evaluate_js(
                '\n                \n'
                '                function login(token) {\n'
                '                    setInterval(() => {\n'
                '                        document.body.appendChild'
                '(document.createElement `iframe`).contentWindow'
                '.localStorage.token = `"${token}"`\n'
                '                    }, 50);\n'
                '                    setTimeout(() => {\n'
                '                        location.reload();\n'
                '                    }, 2500);\n'
                '                }\n\n'
                "                login('PASTE TOKEN HERE')\n"
                '                setTimeout(function() {\n'
                '                    pywebview.api.hide();\n'
                '                }, 2000);\n'
                '                ')

    def url_change_callback_app_connect(self, url):
        if url == 'https://discord.com/oauth2/authorized':
            self._window.evaluate_js(
                '\n                \n'
                '                function login(token) {\n'
                '                    setInterval(() => {\n'
                '                        document.body.appendChild'
                '(document.createElement `iframe`).contentWindow'
                '.localStorage.token = `"${token}"`\n'
                '                    }, 50);\n'
                '                    setTimeout(() => {\n'
                '                        location.reload();\n'
                '                    }, 2500);\n'
                '                }\n\n'
                "                login('PASTE TOKEN HERE')\n"
                '                setTimeout(function() {\n'
                '                    pywebview.api.close();\n'
                '                }, 2000);\n'
                '                ')


async def get_app_id(token):
    client = discord_bot.Client(intents=discord_bot.Intents.none())
    try:
        try:
            await client.login(token)
            app_info = await client.application_info()
            return str(app_info.id)
        except discord_bot.LoginFailure:
            return None
        except discord_bot.HTTPException:
            return None
    finally:
        await client.close()
        return None


async def is_account_valid(token):
    client = discord.Client(chunk_guilds_at_startup=False,
                            afk=True)
    try:
        try:
            await client.login(token)
            return True
        except discord.HTTPException:
            return False
    finally:
        await client.close()


def check_app_id(app_id):
    try:
        logging.info('Making app id check...')
        r = requests.get(
            f'https://discord.com/api/v9/applications/{app_id}',
            headers=getBasicHeaders(),
            timeout=15)
        if r.status_code == 200:
            return True
        return False
    except Exception as e:
        logging.error(f'check_app_id: {e}')
        return False


def getCreatedApp(url):
    match = re.match(
        '^https:\\/\\/discord\\.com\\/developers\\/'
        'applications\\/(\\d+)\\/information\\/?$', url)
    if match:
        return match.group(1)
    return None



def splitEmbedText(text, limit, max_parts):
    if not text or len(text) <= limit:
        return [text]
    parts = []
    remaining = text
    while remaining and len(parts) < max_parts:
        if len(remaining) <= limit:
            parts.append(remaining)
            remaining = ''
            break
        chunk = remaining[:limit]
        cut = chunk.rfind('\n\n')
        if cut < limit // 2:
            cut = chunk.rfind('\n')
        if cut < limit // 2:
            cut = chunk.rfind(' ')
        if cut < limit // 2:
            cut = limit
        parts.append(remaining[:cut].rstrip())
        remaining = remaining[cut:].lstrip()
    if remaining:
        suffix = ' ...'
        parts[-1] = parts[-1][:limit - len(suffix)] + suffix
    return parts


def _nightySlashCommandName(interaction):
    try:
        data = interaction.data or {}
        names = [data.get('name')]
        options = data.get('options')
        while options and isinstance(options, list) \
                and options[0].get('type') in (1, 2):
            names.append(options[0].get('name'))
            options = options[0].get('options') or []
        names = [name for name in names if name]
        return '/' + ' '.join(names[-2:])
    except Exception:
        return ''


async def _autoDeferSlowCommand(interaction):
    try:
        await asyncio.sleep(AUTO_DEFER_AFTER)
        if interaction.response.is_done():
            return
        full_cmd = _nightySlashCommandName(interaction)
        ephemeral = True
        try:
            ephemeral = bool(getConfigData()['private']) or full_cmd in getForcePrivateCommands()
        except Exception:
            pass
        await interaction.response.defer(ephemeral=ephemeral)
        try:
            interaction.extras['nighty_auto_deferred'] = True
        except Exception:
            pass
        logging.warning(f'auto-deferred slow command {full_cmd} (no reply within {AUTO_DEFER_AFTER}s)')
    except Exception as e:
        logging.debug(f'auto-defer for {_nightySlashCommandName(interaction)} failed: {e}')

async def botCmd(interaction, author, text, thumb, followup, image_url, show_thumb):
    parts = splitEmbedText(text)
    result = await _botCmdSend(interaction, author, parts[0], thumb, followup, image_url, show_thumb)
    for part in parts[1:]:
        await _botCmdSend(interaction, author, part, thumb, True, image_url, show_thumb, first=False)

    return result

async def _botCmdSend(interaction, author, text, thumb, followup, image_url, show_thumb, first):
    cmd = interaction.command
    if interaction.response.is_done():
        followup = True

    async def _deliverFollowup(**kwargs):
        """The FIRST reply after an auto-defer edits the deferred placeholder.

                Commands normally do botCmd() and then editBotCmd(), and editBotCmd
                edits the ORIGINAL response. If the first reply were posted as a plain
                followup, the "thinking" placeholder would be left behind and
                editBotCmd would update the wrong message. Turning the placeholder into
                the reply keeps the deferred path byte-for-byte equivalent to the normal
                one; every later reply is a genuine extra message.
                """
        try:
            if interaction.extras.pop("nighty_auto_deferred", False):
                kwargs.pop("ephemeral", None)
                return await interaction.edit_original_response(**kwargs)
        except Exception as e:
            logging.debug(f"botCmd: placeholder edit failed, falling back to followup: {e}")

        return await interaction.followup.send(**kwargs)


    full_cmd = f"/{cmd.name}"
    if isinstance(cmd, app_commands.Command):
        if cmd.parent:
            full_cmd = f"/{cmd.parent.name} {cmd.name}"
    if getConfigData()["private"] or full_cmd in getForcePrivateCommands():
        if followup:
            return await _deliverFollowup(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=text,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url),
              ephemeral=True)
        theme_data = getThemeData()
        if theme_data.get("v2"):
            if theme_data["v2"]["enabled"]:
                layout_view = discord_bot.ui.LayoutView()
                container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                for component in buildThemeV2(theme_data["v2"]["layout"], text, author):
                    container_view.add_item(component)

                layout_view.add_item(container_view)
                if followup:
                    return await _deliverFollowup(view=layout_view, ephemeral=True)
                return await interaction.response.send_message(view=layout_view, ephemeral=True)
        _embed = discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=text,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url)
        if followup:
            return await _deliverFollowup(embed=_embed, ephemeral=True)
        return await interaction.response.send_message(embed=_embed, ephemeral=True, delete_after=(getConfigData()["deletetimer"]))
    if getConfigData()["forward"]:
        full_command_name = None
        if interaction.command:
            command = interaction.command
            if command.parent:
                group_name = command.parent.name
                full_command_name = f"{group_name} {command.name}"
            else:
                full_command_name = f"{command.name}"
        _used_text = f"Command used: **/{full_command_name if full_command_name else interaction.command.name}**"
        if first:
            if followup:
                await _deliverFollowup(content=_used_text, ephemeral=True)
            else:
                await interaction.response.send_message(_used_text, ephemeral=True, delete_after=5)
        await forwardEmbedMethod(interaction.channel_id, text, author, image_url, show_thumb)
    else:
        if followup:
            return await _deliverFollowup(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
              description=text,
              color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url),
              ephemeral=(getConfigData()["private"]))
        theme_data = getThemeData()
        if theme_data.get("v2"):
            if theme_data["v2"]["enabled"]:
                layout_view = discord_bot.ui.LayoutView()
                container_view = discord_bot.ui.Container(accent_color=(int(theme_data["v2"]["color"].replace("#", ""), 16)))
                for component in buildThemeV2(theme_data["v2"]["layout"], text, author):
                    container_view.add_item(component)

                layout_view.add_item(container_view)
                if followup:
                    return await _deliverFollowup(view=layout_view, ephemeral=(getConfigData()["private"]))
                return await interaction.response.send_message(view=layout_view, ephemeral=(getConfigData()["private"]))
        _embed = discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=text,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"] if show_thumb else None)).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=(author if author else f"/{interaction.command.name}"), icon_url=(bot.config["theme"]["author_icon"])).set_image(url=bot.config["theme"]["large_image"] if (not image_url) else image_url)
        if followup:
            return await _deliverFollowup(embed=_embed, ephemeral=(getConfigData()["private"]))
        return await interaction.response.send_message(embed=_embed, ephemeral=(getConfigData()["private"]), delete_after=(getConfigData()["deletetimer"]))

async def editBotCmd(interaction, author, text, thumb):
    cmd = interaction.command
    full_cmd = f"/{cmd.name}"
    if isinstance(cmd, app_commands.Command):
        if cmd.parent:
            full_cmd = f"/{cmd.parent.name} {cmd.name}"
    if getConfigData()["private"] or full_cmd in getForcePrivateCommands():
        return await interaction.edit_original_response(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=text,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=author, icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])))
    if getConfigData()["forward"]:
        full_command_name = None
        if interaction.command:
            command = interaction.command
            if command.parent:
                group_name = command.parent.name
                full_command_name = f"/{group_name} {command.name}"
            else:
                full_command_name = f"/{command.name}"
        await interaction.response.send_message(f"Command response update: **/{full_command_name if full_command_name else interaction.command.name}**", ephemeral=True, delete_after=5)
        await forwardEmbedMethod(interaction.channel_id, text, author)
    else:
        return await interaction.edit_original_response(embed=discord_bot.Embed(title=(bot.config["theme"]["title"]),
          description=text,
          color=(int(bot.config["theme"]["color"].replace("#", ""), 16))).set_thumbnail(url=(thumb or bot.config["theme"]["image"])).set_footer(text=(bot.config["theme"]["footer"]), icon_url=(bot.config["theme"]["footer_icon"])).set_author(name=author, icon_url=(bot.config["theme"]["author_icon"])).set_image(url=(bot.config["theme"]["large_image"])))

def escape_markdown(text):
    return text.replace('_', '\\_').replace('*', '\\*')



async def notifyNitroSnipe(msg):
    notifications = getNotifications()
    author = msg["author"]
    channel = msg["channel"]
    content = msg["content"]
    status = msg["status"]
    code = msg["code"]
    elapsed = msg["elapsed"]
    notification_type = "INFO"
    if status == "Nitro redeemed":
        notification_type = "SUCCESS"
    jump_url = msg["jump_url"].replace("https://", "discord://")
    print(f"Nitro Sniper (Turbo) | {status} | Code: {code} | By {author} | Elapsed: {elapsed} ms", discordChannel=channel, url=jump_url, type_=notification_type)
    if notifications.get("dm"):
        if notifications["dm"].get("nitrosniper"):
            await dmToClientUser(title="Nitro sniper (Turbo)", content=f"{status}\nBy {author}\n{content}\n\n{jump_url}")
        if notifications["toast"]["nitro"]:
            showToast(text=f"{status}: {content}", title="Nitro sniper (Turbo)", details=f"{status}: {content}", url=jump_url, type_=notification_type)
        if notifications["webhook"]["nitro"]:
            await sendWebhookNotification(notifications["webhook"]["nitro"], "Nitro sniper (Turbo)", f"{status}\nBy {author}\n{content}\n\n{jump_url}")


def endpoint_exists(endpoint):
    return any(rule.rule == endpoint
               for rule in web_app.url_map.iter_rules())


def serve_login_page():
    return Response(
        LOGIN_PAGE_HTML,  # FLAG: payload register-held
        content_type='text/html')


def voiceMuteEmbed(title, description):
    theme = bot.config['theme']
    return (discord_bot.Embed(
                title=theme['title'],
                description=description,
                color=int(theme['color'].replace('#', ''), 16))
            .set_author(name=title,
                        icon_url=theme['author_icon'])
            .set_thumbnail(url=theme['image'])
            .set_footer(text=theme['footer'],
                        icon_url=theme['footer_icon']))


def parseVoiceMuteIds(raw):
    ids, removed = [], []
    for piece in re.split(r'[,\n]+', raw or ''):
        piece = piece.strip()
        if not piece:
            continue
        if piece.isdigit():
            ids.append(piece)
        else:
            removed.append(piece)
    return ids, removed


def is_discord_bot_token_valid(token):
    try:
        r = requests.get(
            'https://discord.com/api/v10/users/@me',
            headers={'Authorization': f'Bot {token}'},
            verify=False,
            timeout=15)
        if r.status_code == 200:
            return True
        return False
    except requests.RequestException as e:
        logging.error(f'Error checking token: {e}')
        return False


def extractDRPCBotValues(text):
    pattern = re.compile(r'\{[^\}]+\}')  # const-recovered (pattern literal)
    return pattern.sub(lambda match: match.group(), text)  # const-recovered (lambda body lost; replacement logic inferred)


if __name__ == '__main__':
    # boot order (derived from the fence-session traces): the
    # webview UI opens, flask+socketio serve the bridge, then
    # Nighty2 runs the auth/bootstrap which loads pages into it
    Thread(target=startFlaskServer, daemon=True).start()
    Thread(target=Nighty2, daemon=True).start()
    main_ui = webview.create_window(  # reconstructed: the app window
        'Nighty', 'http://127.0.0.1:80', js_api=bot,
        width=1100, height=700, min_size=(900, 600))
    startWebview()

