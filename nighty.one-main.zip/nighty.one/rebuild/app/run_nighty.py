# run_nighty.py - launcher for the rebuilt Nighty app.
#
# repo-relative: needs nothing outside this repo. the discord stack
# comes from ../lib (the exe's original bytecode), not pip.
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(HERE))
LIB = os.path.join(REPO, 'lib')

sys.path.insert(0, HERE)
sys.path.insert(0, LIB)

# his discord fork talks through curl_cffi. stock pip 0.9.0 works,
# it just lacks one export his build added - patch it in.
try:
    import curl_cffi
    if not hasattr(curl_cffi, 'WebSocketError'):
        class WebSocketError(curl_cffi.CurlError):
            pass
        curl_cffi.WebSocketError = WebSocketError
except ImportError:
    print('curl_cffi missing. run: pip install curl_cffi==0.9.0')
    input('press enter to exit...')
    sys.exit(1)

# the armor called a native module (spp_export_api). the rebuilt source
# still has those call sites, so seed a permissive fake - see spp_fake.py
import spp_fake  # noqa: E402
import types as _t  # noqa: E402

sppmod = _t.ModuleType('spp_export_api')
sppmod.spp_export_api = spp_fake.Rec()
sys.modules['spp_export_api'] = sppmod

src = open(os.path.join(HERE, 'Nighty_source.py'),
           encoding='ascii', errors='replace').read()
code = compile(src, 'Nighty_source.py', 'exec')
gns = {'__name__': '__main__',
       '__file__': os.path.join(HERE, 'Nighty_source.py'),
       '__package__': None,
       '__doc__': None,
       'spp_export_api': spp_fake.Rec()}
exec(code, gns)
