"""
spp_fake.py - a permissive fake for PyArmor's spp_export_api module.

Pre-seeding sys.modules['spp_export_api'] with this module makes
`import spp_export_api` succeed instantly (sys.modules is checked before
any meta_path finder, so pytransform's failing spp loader is bypassed).

The recorder objects are:
  * chainable (attributes/calls return recorders)
  * storable (values written are remembered and read back)
  * safely falsy/empty/str-able (bool->False, len->0, iter->(), str->'')
  * comparable (==/!= sane results, >,< raise TypeError caught by caller)
"""
import sys
import types


class Rec:
    __slots__ = ("_store",)

    def __init__(self):
        object.__setattr__(self, "_store", {})

    # -------------------------------------------------- attribute access
    def __getattr__(self, name):
        store = object.__getattribute__(self, "_store")
        if name in store:
            return store[name]
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        r = Rec()
        store[name] = r
        return r

    def __setattr__(self, name, value):
        object.__getattribute__(self, "_store")[name] = value

    # -------------------------------------------------- calling / representing
    def __call__(self, *args, **kw):
        r = Rec()
        store = object.__getattribute__(self, "_store")
        key = ("__results__", len(store))
        store[key] = (args, kw, r)
        return r

    def __str__(self):
        return ""

    def __repr__(self):
        return "<spp-fake>"

    def __format__(self, spec):
        return ""

    # -------------------------------------------------- containers / truth
    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0

    def __bool__(self):
        return False

    def __getitem__(self, k):
        return Rec()

    def __setitem__(self, k, v):
        pass

    def __delitem__(self, k):
        pass

    def __contains__(self, k):
        return False

    # -------------------------------------------------- comparisons / numbers
    def __eq__(self, other):
        return isinstance(other, Rec)

    def __ne__(self, other):
        return not isinstance(other, Rec)

    def __lt__(self, other):
        return False

    def __gt__(self, other):
        return False

    def __le__(self, other):
        return False

    def __ge__(self, other):
        return False

    def __hash__(self):
        return 0

    # arithmetic -- return more recorders
    def __add__(self, o):
        return Rec()

    def __radd__(self, o):
        return Rec()

    def __sub__(self, o):
        return Rec()

    def __rsub__(self, o):
        return Rec()

    def __mul__(self, o):
        return Rec()

    def __rmul__(self, o):
        return Rec()

    def __mod__(self, o):
        return Rec()

    def __neg__(self):
        return Rec()

    def __int__(self):
        return 0

    def __float__(self):
        return 0.0

    def __index__(self):
        return 0

    # -------------------------------------------------- context manager
    def __enter__(self):
        return Rec()

    def __exit__(self, *a):
        return False

    # -------------------------------------------------- async protocol glue
    def __await__(self):
        return iter(())

    def send(self, *a):
        raise StopIteration

    def throw(self, *a):
        raise StopIteration

    def close(self):
        pass

    # -------------------------------------------------- misc protocols
    def split(self, *a, **k):
        return []

    def strip(self, *a, **k):
        return ""

    def join(self, *a, **k):
        return ""

    def items(self):
        return []

    def keys(self):
        return []

    def values(self):
        return []

    def get(self, *a, **k):
        return Rec()

    def append(self, *a):
        pass

    def pop(self, *a):
        return Rec()


def make_fake_module(name="spp_export_api"):
    m = types.ModuleType(name)
    rec = Rec()

    def _mod_getattr(attr):
        # module-level __getattr__: return a fresh/stable recorder
        try:
            store = object.__getattribute__(rec, "_store")
            if attr in store:
                return store[attr]
        except Exception:
            pass
        r = Rec()
        try:
            object.__getattribute__(rec, "_store")[attr] = r
        except Exception:
            pass
        return r

    m.__getattr__ = _mod_getattr
    m.__all__ = []
    m.__path__ = []
    m.__file__ = name + ".py"
    sys.modules[name] = m
    return m
