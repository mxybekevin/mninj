# main_noauth.py - Byte X Selfbot (ZERO API version)
# Talks to NOTHING external except Discord's gateway.
# No update checks. No telemetry. No nighty.one. Nothing.
#
# CREDITS: Byte X / gang.baby
# Fully offline-capable. Even the embeds use no external URLs.
#
# pip install curl_cffi==0.9.0 aiohttp
# Runs on the discord fork bundled in lib/, same as main.py.

import asyncio
import json
import logging
import os
import re
import sys
import time

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE, 'lib'))

try:
    import curl_cffi
    if not hasattr(curl_cffi, 'WebSocketError'):
        class WebSocketError(curl_cffi.CurlError):
            pass
        curl_cffi.WebSocketError = WebSocketError
except ImportError:
    print('curl_cffi is not installed. run: pip install curl_cffi==0.9.0')
    input('press enter to exit...')
    exit(1)

try:
    import aiohttp  # noqa: F401
except ImportError:
    print('aiohttp is not installed. run: pip install aiohttp')
    input('press enter to exit...')
    exit(1)

import discord
from discord.ext import commands

# ============================================================
#  CONFIG
# ============================================================
TOKEN = "PASTE_YOUR_DISCORD_TOKEN_HERE"
PREFIX = "."

# ============================================================
#  SETUP - explicitly ZERO external HTTP calls
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [ByteX-ZeroAPI] %(levelname)s: %(message)s'
)
log = logging.getLogger('bytex-zero')

bot = commands.Bot(command_prefix=PREFIX, help_command=None)

# Track that we make ZERO external requests
EXTERNAL_REQUESTS = 0  # this stays 0. forever. that's the point.


@bot.event
async def on_ready():
    log.info(f'✅ Logged in as {bot.user}')
    log.info(f'✅ Prefix: {PREFIX}')
    log.info(f'✅ External API calls made: {EXTERNAL_REQUESTS} '
             '(this will never change)')
    log.info('✅ Credits: Byte X / gang.baby')


# ============================================================
#  COMMANDS (all self-contained, zero external calls)
# ============================================================

@bot.command(name='help')
async def help_cmd(ctx):
    embed = discord.Embed(
        title='🩸 Byte X Selfbot (Zero-API Mode)',
        description=(
            '*Nighty but it actually respects your privacy*\n'
            '*External requests: 0* ✅'
        ),
        color=0x000000
    )
    embed.add_field(name='Commands', value=(
        f'`{PREFIX}ping` - latency\n'
        f'`{PREFIX}whoami` - account info\n'
        f'`{PREFIX}embed <json>` - send embed\n'
        f'`{PREFIX}purge <n>` - delete messages\n'
        f'`{PREFIX}spam <n> <msg>` - spam\n'
        f'`{PREFIX}hypesquad <house>` - change house\n'
        f'`{PREFIX}credits` - show credits'
    ), inline=False)
    embed.set_footer(text='Zero external requests | Byte X / gang.baby')
    await ctx.send(embed=embed)


@bot.command(name='ping')
async def ping_cmd(ctx):
    start = time.perf_counter()
    msg = await ctx.send('🏓')
    ms = (time.perf_counter() - start) * 1000
    await msg.edit(content=f'🏓 `{ms:.0f}ms` | ext requests: '
                  f'{EXTERNAL_REQUESTS}')


@bot.command(name='whoami')
async def whoami_cmd(ctx):
    u = bot.user
    embed = discord.Embed(title='👤 You', color=0x000000)
    embed.add_field(name='User', value=str(u))
    embed.add_field(name='ID', value=u.id)
    embed.add_field(name='Verified', value=str(u.verified))
    embed.add_field(name='External APIs contacted', value='**0**')
    embed.set_footer(text='Byte X | gang.baby | privacy first')
    await ctx.send(embed=embed)


@bot.command(name='embed')
async def embed_cmd(ctx, *, json_str: str = ''):
    try:
        data = json.loads(json_str)
        # strip any URLs from the embed (zero external policy)
        for key in ('thumbnail', 'image', 'author', 'footer'):
            if key in data and isinstance(data[key], dict):
                data[key].pop('icon_url', None)
                data[key].pop('url', None)
        await ctx.send(embed=discord.Embed.from_dict(data))
    except json.JSONDecodeError as e:
        await ctx.send(f'❌ `{e}`')


@bot.command(name='purge')
async def purge_cmd(ctx, count: int = 10):
    deleted = 0
    async for msg in ctx.channel.history(limit=200):
        if msg.author.id == bot.user.id:
            await msg.delete()
            deleted += 1
            if deleted >= min(count, 100):
                break
            await asyncio.sleep(0.5)


@bot.command(name='spam')
async def spam_cmd(ctx, count: int = 5, *, message: str = ''):
    if not message:
        return
    for _ in range(min(count, 20)):
        await ctx.send(message)
        await asyncio.sleep(0.8)


@bot.command(name='hypesquad')
async def hypesquad_cmd(ctx, house: str = ''):
    houses = {'bravery': 1, 'brilliance': 2, 'balance': 3}
    if house.lower() not in houses:
        return await ctx.send('bravery/brilliance/balance')
    await bot.http.change_hypesquad_house(houses[house.lower()])
    await ctx.send(f'✅ {house.title()}')


@bot.command(name='credits')
async def credits_cmd(ctx):
    embed = discord.Embed(
        title='🩽 Credits',
        description=(
            '**[Byte X](https://gang.baby/)** reversed Nighty\'s '
            'entire PyArmor super mode:\n'
            '• 3 cipher tiers cracked\n'
            '• Opcode substitution reversed\n'
            '• Auth endpoint captured\n'
            '• 771/771 sections recovered\n\n'
            'This version makes **zero** external API calls.\n'
            'Your data stays yours.\n\n'
            'Credits: **Byte X / gang.baby**'
        ),
        color=0x000000
    )
    await ctx.send(embed=embed)


# ============================================================
#  NITRO SNIPER (gateway-only, no extra HTTP calls)
# ============================================================
@bot.event
async def on_message(message):
    codes = re.findall(
        r'(?:discord\.gift/|discord\.com/gifts/)([A-Za-z0-9]+)',
        message.content)
    for code in codes:
        log.info(f'🎁 {code}')
        try:
            await bot.http.post(
                '/entitlements/gift-codes/' + code + '/redeem')
        except Exception:
            pass
    await bot.process_commands(message)


# ============================================================
#  MAIN
# ============================================================
if TOKEN == "PASTE_YOUR_DISCORD_TOKEN_HERE":
    print("""
    ╔══════════════════════════════════════════╗
    ║  🩸 Byte X Selfbot — ZERO API MODE        ║
    ║                                          ║
    ║  This version talks to NOTHING           ║
    ║  except Discord's gateway.               ║
    ║                                          ║
    ║  No telemetry. No updates. No phone      ║
    ║  home. Nighty could never.               ║
    ║                                          ║
    ║  Credits: Byte X / gang.baby             ║
    ╚══════════════════════════════════════════╝
    """)
    TOKEN = input("  Paste token: ").strip().strip('"')

if TOKEN:
    bot.run(TOKEN)
