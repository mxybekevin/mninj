"""
fence_sniffer2.py - locate pyarmor fence regions by marker, spin-sweep them.

Fence layout observed in-process:
    ... [u64 size = length of armed buffer] ff*8 90 03 74 08 83 00 90 00 ...
(the 8-byte 0xff scratch prefix + EXTENDED_ARG 3 / LOAD_GLOBAL 776 /
 CALL_FUNCTION 0 / EXTENDED_ARG 0 trampoline header)

This sniffer:
  * walks the target's address space with VirtualQueryEx
  * scans readable pages for the marker
  * tracks each fence (addr, size) and spin-sweeps it at full speed,
    storing every distinct version of the content
  * periodically rescans for NEW fences (functions get their own fence)
  * saves everything to fence_snaps/fences.marshal
usage: python fence_sniffer2.py <pid>
"""
import ctypes
import marshal
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
os.makedirs(SNAPS, exist_ok=True)
STORE = os.path.join(SNAPS, "fences.marshal")

pid = int(sys.argv[1])
k32 = ctypes.WinDLL("kernel32", use_last_error=True)

PROCESS_VM_READ = 0x0010
PROCESS_QUERY_INFORMATION = 0x0400

h = k32.OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, False, pid)
if not h:
    print("[-] OpenProcess failed:", k32.GetLastError())
    sys.exit(1)
print("[+] target pid %d" % pid)

MARKER = b"\xff" * 8 + bytes.fromhex("9003740883009000")
MARK_ATREST = bytes.fromhex("900374088300900053009000")

class MBI(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p),
        ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", ctypes.c_ulong),
        ("RegionSize", ctypes.c_size_t),
        ("State", ctypes.c_ulong),
        ("Protect", ctypes.c_ulong),
        ("Type", ctypes.c_ulong),
    ]

def rpm(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t()
    ok = k32.ReadProcessMemory(h, ctypes.c_void_p(addr), buf, ctypes.c_size_t(size),
                              ctypes.byref(got))
    if not ok:
        return None
    return buf.raw[:got.value]

def regions():
    out = []
    addr = 0
    mbi = MBI()
    while addr < 0x7FFFFFFEFFFF:
        r = k32.VirtualQueryEx(h, ctypes.c_void_p(addr), ctypes.byref(mbi),
                               ctypes.sizeof(mbi))
        if r == 0:
            break
        base = mbi.BaseAddress or addr
        size = mbi.RegionSize
        if mbi.State == 0x1000:  # MEM_COMMIT
            out.append((base, size, mbi.Protect, mbi.Type))
        addr = base + size
        if size == 0:
            break
    return out

fences = {}          # addr -> {"size": int, "versions": [bytes], "last": bytes}
page_cache = {}

def scan_for_fences():
    found = []
    t0 = time.time()
    nread = 0
    for base, size, prot, rtype in regions():
        # guard/noaccess pages can't be read anyway; try everything
        off = 0
        while off < size:
            chunk = min(0x10000, size - off)
            data = rpm(base + off, chunk)
            nread += 1
            if data:
                for m in (MARKER, MARK_ATREST):
                    idx = data.find(m)
                    while idx >= 0:
                        found.append((base + off + idx, m == MARKER))
                        idx = data.find(m, idx + 1)
            off += chunk
    print("[scan] %.2fs reads=%d hits=%d regions=%d" % (
        time.time() - t0, nread, len(found), len(regions())))
    for addr, is_live in found:
        if addr in fences:
            continue
        # size field: u64 right before the marker (may be ff-prefixed)
        hdr = rpm(addr - 8, 8)
        n = 0
        if hdr:
            (n,) = struct.unpack("<Q", hdr)
            if n == 0 or n > 20_000_000:
                n = 0
        if n == 0:
            n = 16384  # fallback; will self-correct from versions length diffs
        fences[addr] = {"size": n, "versions": [], "last": None, "live": is_live}
        print("[+] fence at %#x size=%d live=%s" % (addr, n, is_live))
    return len(found)

def sweep(addr, ent):
    size = ent["size"]
    if size <= 0:
        return False
    data = rpm(addr, size)
    if data is None:
        return False
    if data != ent["last"]:
        ent["last"] = data
        vers = ent["versions"]
        if not vers or vers[-1] != data:
            vers.append(data)
            if len(vers) > 3000:
                vers.pop(0)
        # self-correct size if reads got truncated
        if len(data) != size:
            ent["size"] = len(data)
        return True
    return False

def save():
    try:
        payload = {a: {"size": e["size"], "versions": e["versions"],
                       "live": e["live"]} for a, e in fences.items()}
        tmp = STORE + ".tmp"
        with open(tmp, "wb") as f:
            marshal.dump(payload, f, 2)
        os.replace(tmp, STORE)
    except Exception as ex:
        print("[!] save fail %r" % ex)

# ---------------------------------------------------------------- main loop
t0 = time.time()
last_scan = -10.0      # force a scan only after the target warms up a beat
first_scan_at = 0.35
last_save = 0.0
changes = 0
alive = ctypes.c_ulong()
while True:
    now = time.time()
    if now >= first_scan_at and now - last_scan >= 2.0:
        scan_for_fences()
        last_scan = now
    for addr, ent in list(fences.items()):
        try:
            if sweep(addr, ent):
                changes += 1
        except Exception as e:
            pass
    if now - last_save >= 3.0:
        save()
        total_v = sum(len(e["versions"]) for e in fences.values())
        print("[%7.2fs] fences=%d versions=%d" % (now - t0, len(fences), total_v),
              flush=True)
        last_save = now
    if k32.GetExitCodeProcess(h, ctypes.byref(alive)) and alive.value != 259:
        # process dead
        break
    if not fences:
        time.sleep(0.005)
    else:
        time.sleep(0)

print("[*] target gone; final save")
save()
total_v = sum(len(e["versions"]) for e in fences.values())
print("[done] fences=%d total versions=%d changes=%d" % (len(fences), total_v, changes))
