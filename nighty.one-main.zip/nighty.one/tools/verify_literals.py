"""verify_literals.py v2 — byte-exact audit of every long string
literal embedded in the native_core modules against the LIVE
const pool (got_snatch/const_reprs.json).

Checks:
- plain (non-f) string constants >= 60 chars: must BE a pool
  value, or a substring of one (hand-wrapped ships fold to whole
  consts at parse time; corpus-lane legacy pieces may be const
  fragments).
- f-string (JoinedStr) constant segments >= 20 chars, with the
  doubled braces unescaped: must be a substring of some pool
  value (const pieces split at interpolation points are
  fragments, not whole consts).
- docstrings (Expr-statement strings) are excluded.
Any MISMATCH is a transcription error to triage.
"""
import ast
import glob
import json
import os
import sys

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
MODULES = r'C:\Users\brian\Downloads\Nighty\NightyRecovered\native_core'
D = json.load(open(os.path.join(ORACLE, 'out', 'got_snatch',
                                'const_reprs.json'), encoding='utf-8'))

LIVE_SET = set()
LIVE_VALS = []
for k, v in D.items():
    r = v.get('repr')
    if not isinstance(r, str):
        continue
    try:
        val = ast.literal_eval(r)
    except (ValueError, SyntaxError):
        continue
    if isinstance(val, str):
        LIVE_SET.add(val)
        LIVE_VALS.append(val)


def in_pool_sub(s):
    if s in LIVE_SET:
        return True
    return any(s in v for v in LIVE_VALS)


bad = 0
checked = 0
for path in sorted(glob.glob(os.path.join(MODULES, '*.py'))):
    src = open(path, encoding='utf-8').read()
    tree = ast.parse(src)
    name = os.path.basename(path)
    doc_ids = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Expr) and isinstance(
                node.value, (ast.Constant, ast.JoinedStr)):
            doc_ids.add(id(node.value))
    for node in ast.walk(tree):
        if isinstance(node, ast.JoinedStr):
            if id(node) in doc_ids:
                continue
            for seg in node.values:
                if isinstance(seg, ast.Constant) and isinstance(
                        seg.value, str):
                    s = seg.value.replace('{{', '{').replace('}}', '}')
                    if len(s) < 20:
                        continue
                    checked += 1
                    if not in_pool_sub(s):
                        bad += 1
                        print('MISMATCH-SEG %s: %r'
                              % (name, seg.value[:70]))
        elif (isinstance(node, ast.Constant) and isinstance(
                node.value, str) and id(node) not in doc_ids):
            s = node.value
            if len(s) < 60:
                continue
            checked += 1
            if not in_pool_sub(s):
                bad += 1
                print('MISMATCH %s: %r' % (name, s[:70]))
print('checked %d long literals / fragments; mismatches: %d'
      % (checked, bad))
sys.exit(1 if bad else 0)
