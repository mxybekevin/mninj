// hook47i.js - v8: raw memory scan for the URL bytes. No
// object walking - just find 'eu.nighty.one' (and 'SERVER'
// ascii) in readable memory and dump context.
var OUT = 'C:\\Users\\brian\\Downloads\\Nighty\\oracle\\out\\netprobe47\\';

function dumpAround(addr, span, tag, fh) {
    try {
        var b = new Uint8Array(addr.readByteArray(span));
        var s = '';
        for (var j = 0; j < b.length; j++) {
            var c = b[j];
            s += (c >= 32 && c < 127) ?
                String.fromCharCode(c) : '.';
        }
        fh.write(tag + ' @' + addr + ': ' + s + '\n');
    } catch (e) {}
}

var results = {};
var fh = new File(OUT + 'memscan.log', 'w');

function scanPattern(pat, tag) {
    var ranges = Process.enumerateRanges('r--');
    var n = 0;
    for (var i = 0; i < ranges.length; i++) {
        var r = ranges[i];
        if (r.size > 64 * 1024 * 1024) continue;
        if (r.file && (r.file.path.indexOf('python38') >= 0 ||
                       r.file.path.indexOf('.dll') >= 0)) {
            // still scan, modules can hold literals
        }
        try {
            Memory.scanSync(r.base, r.size,
                            pat).forEach(function (m) {
                var key = '' + m.address;
                if (results[key]) return;
                results[key] = 1;
                n++;
                if (n <= 60) {
                    dumpAround(m.address.sub(120), 360,
                               tag, fh);
                }
            });
        } catch (e) {}
    }
    fh.write('== ' + tag + ' matches: ' + n + '\n');
}

// 'eu.nighty.one' ascii
scanPattern('65 75 2e 6e 69 67 68 74 79 2e 6e 65 6f',
            'euhost');
// 'SERVER_TO_USE' ascii (the global name itself in the dict)
scanPattern('53 45 52 56 45 52 5f 54 4f 5f 55 53 45',
            'servername');

fh.close();
send({t: 'scan-done'});
