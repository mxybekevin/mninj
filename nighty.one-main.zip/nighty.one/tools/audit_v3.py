# audit_v3.py - THE UNIFIED AUDIT. Grades every shipped section
# against ALL evidence classes:
#   A: whole-marshal safe evidence (original audit)
#   B: VM-stream evidence (gate45 bytecode comparison)
#   C: semantic-family (names/arity/line-map law)
# Emits one table with class labels.
import ast
import dis
import glob
import io
import json
import marshal
import os
import py_compile
import re
import struct
import types as _t
import opcode as _op

REPO = (r'D:\SSD-Offload\brian\Downloads\Nighty'
        r'\NightyRecovered')
NY = os.path.join(REPO, 'Nighty.py')
ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
WAVE = os.path.join(ORACLE, 'out', 'wave45')
VM = os.path.join(ORACLE, 'out', 'vm45')

VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}
JREL = set(_op.hasjrel)
JABS = set(_op.hasjabs)

# VM opcode equivalence (proven by gate45)
VM2STD = {0xc6: 0x6a, 0x76: 0xa0, 0xf8: 0xa1, 0x10: 0x01,
          0x23: 0x53, 0x41: 0x44, 0x87: 0x6b, 0x12: 0x17,
          0x0c: 0x38, 0x0e: 0x37, 0xe5: 0x5f, 0xbc: 0x88,
          0xf1: 0x6e, 0x8d: 0x67, 0xc8: 0x7c, 0xc9: 0x66,
          0xb1: 0x67, 0x00: 0x09, 0xf4: 0x83, 0xce: 0x67,
          0xea: 0x9d, 0xc4: 0x5f, 0xe6: 0x5c, 0x54: 0x47,
          0x4c: 0x18, 0xf6: 0x9b, 0x93: 0x8d, 0x15: 0x3c}


def vmize(std):
    out = []
    i = 0
    ext = 0
    while i < len(std):
        o, a = std[i], std[i + 1]
        if o == 0x90:
            ext = (ext << 8) | a
            i += 2
            continue
        ea = (ext << 8) | a
        ext = 0
        # reverse map: std -> vm
        vo = o  # identity ops stay
        for k, v in VM2STD.items():
            if v == o:
                vo = k
                break
        out.append((vo, ea, o in JREL or o in JABS))
        i += 2
    return out


def parse_vm(stream):
    out = []
    i = 0
    while i < len(stream):
        o, a = stream[i], stream[i + 1]
        out.append((o, a, o in JREL or o in JABS))
        i += 2
    return out


def vm_gate(src_path, stream_path):
    """Compile src, vmize, compare vs live stream."""
    src = open(src_path, encoding='ascii',
               errors='replace').read()
    try:
        co = compile(src, '<g>', 'exec')
    except SyntaxError:
        return None
    fn = None
    for k in co.co_consts:
        if isinstance(k, _t.CodeType):
            fn = k
            break
    if fn is None:
        return None
    stream = open(stream_path, 'rb').read()
    mine = vmize(fn.co_code)
    theirs = parse_vm(stream)
    match = total = 0
    ti = mi = 0
    while mi < len(mine) and ti < len(theirs):
        mo, ma, mj = mine[mi]
        to, ta, tj = theirs[ti]
        # skip decoy triplets in theirs
        if to == 0xf4 and ti + 2 < len(theirs):
            n1 = theirs[ti + 1][0]
            n2 = theirs[ti + 2][0]
            if n1 in (0x7c, 0xc8) and n2 in (0x6a, 0xc6):
                ti += 3
                continue
        total += 1
        ok = vm_equiv(mo, to)
        if ok and not mj and mo != 0x64:
            ok = (ma == ta)
        if ok:
            match += 1
        mi += 1
        ti += 1
    return (match * 100 // max(1, total)) if total else 0


def vm_equiv(a, b):
    EQ = [
        {0x7c, 0xc8}, {0x83, 0xf4}, {0xa0, 0x76, 0xc9},
        {0x67, 0x8d, 0xce, 0xea, 0xb1},
        {0x5f, 0xe5, 0xc4}, {0x66, 0xc9}, {0x47, 0x54},
        {0x18, 0x4c}, {0x9b, 0xf6}, {0x9d, 0xea},
    ]
    for s in EQ:
        if a in s and b in s:
            return True
    return a == b


def main():
    # load sections from Nighty.py
    txt = open(NY, encoding='utf-8').read()
    hdr_re = re.compile(
        r'^# (.+?)\s+\(original line (\d+)\)$')
    lines = txt.split('\n')
    sections = []
    for i, l in enumerate(lines):
        m = hdr_re.match(l)
        if m:
            sections.append({'name': m.group(1),
                             'line': int(m.group(2)),
                             'hdr': i})

    # vm-stream evidence files
    live_streams = {}
    for f in glob.glob(os.path.join(
            WAVE, 'live_L*.stream')):
        m = re.match(r'live_L(\d+)', os.path.basename(f))
        if m:
            live_streams[int(m.group(1))] = f

    # agent sources (for semantic-class grading)
    src_files = {}
    for f in glob.glob(os.path.join(WAVE, 'src_L*.py')):
        m = re.match(r'src_L(\d+)', os.path.basename(f))
        if m:
            src_files[int(m.group(1))] = f

    # safe-evidence marshals
    safe = {}
    for p in glob.glob(os.path.join(
            ORACLE, 'out', 'decrypted', 'dec_*.marshal')):
        try:
            t = marshal.load(open(p, 'rb'))
        except Exception:
            continue
        if isinstance(t, _t.CodeType):
            st = [t]
            while st:
                c = st.pop()
                for k in c.co_consts:
                    if isinstance(k, _t.CodeType):
                        st.append(k)
                if c.co_name != '<module>':
                    key = (c.co_firstlineno, c.co_name)
                    if key not in safe or \
                            len(c.co_code) > len(safe[key].co_code):
                        safe[key] = c

    # grade each section
    results = []
    for s in sections:
        ln = s['line']
        name = s['name']
        grade = 'UNKNOWN'
        detail = ''

        # class B: vm-stream gate
        if ln in live_streams and ln in src_files:
            pct = vm_gate(src_files[ln], live_streams[ln])
            if pct is not None and pct >= 95:
                grade = 'VM-VERIFIED'
                detail = '%d%%' % pct
            elif pct is not None and pct >= 60:
                grade = 'VM-PARTIAL'
                detail = '%d%%' % pct
            elif pct is not None:
                grade = 'VM-LOW'
                detail = '%d%%' % pct

        # class C: semantic (src exists, marked medium/low)
        if grade == 'UNKNOWN' and ln in src_files:
            src = open(src_files[ln], encoding='ascii',
                       errors='replace').read()
            if 'semantic-family' in src:
                grade = 'SEMANTIC'
                conf = 'low'
                if 'confidence=medium' in src:
                    conf = 'medium'
                detail = conf
            elif 'vm-stream' in src:
                grade = 'VM-STREAM'
                detail = 'no live gate'

        # class A: safe-evidence (original audit logic)
        if grade == 'UNKNOWN':
            key = (ln, name)
            if key in safe:
                grade = 'SAFE-EVID'
                detail = '%dB' % len(safe[key].co_code)

        results.append((ln, name, grade, detail))

    # report
    from collections import Counter
    counts = Counter(r[2] for r in results)
    print('AUDIT v3 - %d sections' % len(results))
    for g, n in counts.most_common():
        print('  %-14s %d' % (g, n))
    print()
    for ln, name, grade, detail in sorted(results):
        if grade in ('UNKNOWN', 'VM-LOW', 'SEMANTIC'):
            print('  L%-6d %-28s %-12s %s'
                  % (ln, name[:28], grade, detail))


if __name__ == '__main__':
    main()
