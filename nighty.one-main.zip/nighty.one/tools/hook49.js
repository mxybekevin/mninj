// hook49.js - THE DELAYED SSL CAPTURE. Attach to a process
// that has been running for 3+ minutes (python38.dll loaded,
// _ssl.pyd loaded, auth flow active). Scan for SSL_write
// pattern inside _ssl.pyd, hook it, capture plaintext HTTP.
var OUT = 'C:\\Users\\brian\\Downloads\\Nighty\\oracle\\out\\netprobe48\\';
var fh = new File(OUT + 'sslcapture.log', 'w', 1);
var captured = false;

// Step 1: find _ssl.pyd (or the ssl module) in loaded modules
var mods = Process.enumerateModules();
var sslMod = null;
var pyMod = null;
for (var i = 0; i < mods.length; i++) {
    var n = mods[i].name.toLowerCase();
    if (n.indexOf('_ssl') >= 0) {
        sslMod = mods[i];
        fh.write('FOUND _ssl module: ' + mods[i].name +
                 ' base=' + mods[i].base +
                 ' size=' + mods[i].size + '\n');
    }
    if (n === 'python38.dll') {
        pyMod = mods[i];
        fh.write('FOUND python38: base=' + mods[i].base + '\n');
    }
}

if (!sslMod) {
    // _ssl.pyd might be loaded but not as a "module" in frida's
    // enumeration (it's a Python extension loaded via import).
    // Search for it in the process's loaded ranges.
    var ranges = Process.enumerateRanges('r-x');
    for (var i = 0; i < ranges.length; i++) {
        var r = ranges[i];
        if (r.file && r.file.path &&
                r.file.path.indexOf('_ssl') >= 0) {
            fh.write('SSL RANGE: ' + r.base + '-' +
                     r.base.add(r.size) + ' ' +
                     r.file.path + '\n');
            sslMod = { base: r.base, size: r.size };
            break;
        }
    }
}

if (!sslMod) {
    // Alternative: scan all executable memory for the OpenSSL
    // version string, then find SSL_write near it.
    fh.write('No _ssl module found directly. Scanning for OpenSSL markers...\n');
    var ranges = Process.enumerateRanges('r--');
    for (var i = 0; i < ranges.length; i++) {
        var r = ranges[i];
        if (r.size > 256 * 1024 * 1024) continue;
        try {
            var hits = Memory.scanSync(
                r.base, r.size, 'OpenSSL');
            for (var j = 0; j < hits.length &&
                     j < 3; j++) {
                fh.write('OpenSSL marker @' +
                         hits[j].address + '\n');
            }
        } catch (e) {}
    }
}

// Step 2: if we have the ssl module, scan for SSL_write.
// SSL_write signature: int SSL_write(SSL *ssl, const void *buf, int num)
// In OpenSSL/BoringSSL, SSL_write is typically a short function
// that calls ssl3_write_bytes / tls13_write_bytes.
// We find it by scanning for the function's call pattern.
if (sslMod) {
    fh.write('Scanning for SSL functions in ssl module...\n');
    // SSL_do_handshake is often near SSL_write
    try {
        var exps = sslMod.enumerateExports ?
            sslMod.enumerateExports() : [];
        for (var j = 0; j < exps.length; j++) {
            fh.write('  export: ' + exps[j].name + '\n');
        }
    } catch (e) {
        fh.write('  no exports\n');
    }
}

// Step 3: FALLBACK - hook WSASend/send and capture plaintext
// that contains HTTP (before TLS). Python's http.client sends
// the request via socket.sendall() which goes through
// WSASend. The data at that point is ALREADY TLS-encrypted
// if the socket is SSL. BUT: the HTTP request string is
// BUILT as a Python string first. So scan the heap.
//
// THE PRACTICAL WIN: scan heap for 'POST /' pattern in a
// process that has already made the auth request.

function heapScanForPost() {
    fh.write('=== HEAP SCAN FOR POST ===\n');
    var seen = {};
    var total = 0;
    var ranges = Process.enumerateRanges('rw-');
    for (var i = 0; i < ranges.length; i++) {
        var r = ranges[i];
        if (r.size > 256 * 1024 * 1024) continue;
        try {
            // 'POST /' as raw bytes
            var ms = Memory.scanSync(
                r.base, r.size, '50 4f 53 54 20 2f');
            for (var j = 0; j < ms.length; j++) {
                var addr = ms[j].address;
                try {
                    var b = new Uint8Array(
                        addr.readByteArray(400));
                    var s = '';
                    for (var k = 0; k < b.length; k++) {
                        var c = b[k];
                        s += (c >= 32 && c < 127) ?
                            String.fromCharCode(c) : '.';
                    }
                    // filter: must look like HTTP (has Host or HTTP/)
                    if (s.indexOf('HTTP') >= 0 ||
                            s.indexOf('Host') >= 0 ||
                            s.indexOf('Content-') >= 0) {
                        if (!seen[s.substring(0, 60)]) {
                            seen[s.substring(0, 60)] = 1;
                            total++;
                            fh.write('POST #' + total + ' @' +
                                     addr + ':\n' +
                                     s.substring(0, 380) +
                                     '\n===\n');
                        }
                    }
                } catch (e) {}
            }
        } catch (e) {}
    }
    fh.write('heap scan done: ' + total +
             ' unique POST patterns\n');
    return total;
}

// run the heap scan immediately (process is mature)
var posts = heapScanForPost();
send({t: 'scan-done', posts: posts});

// also scan for any 'eu.nighty' or 'nighty.one/' strings
function scanForUrls() {
    fh.write('=== URL SCAN ===\n');
    var seen = {};
    var ranges = Process.enumerateRanges('rw-');
    for (var i = 0; i < ranges.length; i++) {
        var r = ranges[i];
        if (r.size > 256 * 1024 * 1024) continue;
        try {
            // 'nighty.one' pattern
            var ms = Memory.scanSync(
                r.base, r.size,
                '6e 69 67 68 74 79 2e 6f 6e 65');
            for (var j = 0; j < ms.length; j++) {
                var addr = ms[j].address;
                try {
                    var b = new Uint8Array(
                        addr.sub(30).readByteArray(200));
                    var s = '';
                    for (var k = 0; k < b.length; k++) {
                        var c = b[k];
                        s += (c >= 32 && c < 127) ?
                            String.fromCharCode(c) : '.';
                    }
                    if (!seen[s.substring(0, 80)]) {
                        seen[s.substring(0, 80)] = 1;
                        fh.write('URL: @' + addr + ': ' +
                                 s + '\n');
                    }
                } catch (e) {}
            }
        } catch (e) {}
    }
    fh.write('url scan done: ' +
             Object.keys(seen).length + ' unique\n');
}

scanForUrls();
fh.write('ALL SCANS DONE\n');
fh.close();
send({t: 'all-done'});
