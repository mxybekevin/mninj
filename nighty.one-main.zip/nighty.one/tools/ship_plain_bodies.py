# ship_plain_bodies.py - integrate verified hand-decoded bodies into the
# repo: insert blocks into Nighty_base.py at their original-line slots,
# remove the matching PENDING tail rows, update the pending-count header,
# rebuild Nighty.py v6, gate (compile + audit + coverage), and commit.
# Mirrors build_v6.py's exact block layout conventions.
import json
import os
import re
import subprocess
import sys

BASE = r'C:\Users\brian\Downloads\Nighty'
REPO = r'D:\SSD-Offload\brian\Downloads\Nighty\NightyRecovered'
VBASE = os.path.join(REPO, 'Nighty_base.py')
VER = os.path.join(BASE, 'oracle', 'out', 'vsrc39', 'verified')
PY = os.path.join(BASE, 'py38', 'python.exe')
AUDIT = (r'C:\Users\brian\AppData\Local\Temp\opencode'
         r'\verify_literals.py')

HEAD_RE = re.compile(r'^# (\S+)\s+\(original line (\d+)\)\s*$')
BANNER = '#' + '-' * 76
PEND_ROW = re.compile(
    r'^#   - (\S+) \(line (\d+), (\d+) bytes\) '
    r'\[(STILL-ARMED|NO-BODY)[^]]*\]\s*$')
PEND_HEAD = '# PENDING UNITS (3 still-armed, {N} no-body):'

# ------------------------------------------------- collect verified rows
rows = []
for p in sorted(os.listdir(VER)):
    m = re.match(r'(.+)_L(\d+)\.py$', p)
    if not m:
        continue
    name, line = m.group(1), int(m.group(2))
    body = open(os.path.join(VER, p), encoding='utf-8').read()
    if not body.rstrip('\n'):
        continue
    rows.append((name, line, body.rstrip('\n')))
if not rows:
    sys.exit('no verified bodies yet')
rows.sort(key=lambda r: r[1])
print('verified bodies to ship: %d' % len(rows))
for name, line, _ in rows:
    print('  L%-7d %s' % (line, name))

# ---------------------------------------------------- insert into the base
with open(VBASE, encoding='utf-8', newline='') as f:
    text = f.read().replace('\r\n', '\n')
lines = text.split('\n')

# map every existing block header to its file index
heads = []          # (orig_line, header_idx)
for i, ln in enumerate(lines):
    m = HEAD_RE.match(ln)
    if m and i > 0 and lines[i - 1].startswith('#---'):
        heads.append((int(m.group(2)), i))

# pending tail rows
pend_idx = {}
head_row = None
for i, ln in enumerate(lines):
    if ln.startswith('# PENDING UNITS ('):
        head_row = i
    m = PEND_ROW.match(ln)
    if m:
        pend_idx[(m.group(1), int(m.group(2)))] = i

if head_row is None:
    sys.exit('pending header not found')

# build the insertion plan; work BACKWARD so indexes stay valid
insertions = []   # (insert_before_idx, block_text)
for name, line, body in rows:
    if any(hline == line for hline, hi in heads):
        print('SKIP (already present in base): %s L%d' % (name, line))
        continue
    if (name, line) not in pend_idx:
        print('WARN: %s L%d not in the pending tail rows' % (name, line))
        continue
    after = [hi for hline, hi in heads if hline > line]
    if after:
        at = min(after) - 1        # the banner line before that header
        while at > 0 and lines[at - 1].strip() == '':
            at -= 1
        at += 1                    # keep one blank separator
    else:
        at = head_row              # append right before the tail header
    block = ('%s\n# %s   (original line %d)\n%s\n\n%s\n\n'
             % (BANNER, name, line, BANNER, body))
    insertions.append((at, block, name, line))

for at, block, name, line in sorted(insertions, reverse=True):
    lines[at:at] = block.split('\n')
    print('inserted %s L%d before header slot idx %d'
          % (name, line, at))

# ------------------------------------------------------------ tail cleanup
shipped = {(name, line) for name, line, _ in rows}
n_removed = 0
for (name, line), idx in sorted(pend_idx.items(),
                                key=lambda kv: kv[1],
                                reverse=True):
    if (name, line) in shipped:
        if lines[idx].startswith('#   - '):
            del lines[idx]
            n_removed += 1
print('pending rows removed: %d' % n_removed)

# recount the tail for the header update
remaining_no_body = 0
remaining_armed = 0
for i, ln in enumerate(lines):
    m = PEND_ROW.match(ln)
    if m:
        if m.group(4) == 'STILL-ARMED':
            remaining_armed += 1
        else:
            remaining_no_body += 1
pattern = re.compile(
    r'^# PENDING UNITS \((\d+) still-armed, (\d+) no-body\):\s*$')
for i in range(len(lines)):
    m = pattern.match(lines[i])
    if m:
        lines[i] = '# PENDING UNITS (%d still-armed, %d no-body):' \
            % (remaining_armed, remaining_no_body)
        break
print('tail now: %d still-armed, %d no-body'
      % (remaining_armed, remaining_no_body))

with open(VBASE, 'w', encoding='utf-8', newline='\n') as f:
    f.write('\n'.join(lines))

# ---------------------------------------------------------------- gates
r = subprocess.run([PY, os.path.join(REPO, 'build_v6.py')],
                   cwd=REPO)
if r.returncode:
    sys.exit('BUILD V6 FAIL')
r = subprocess.run([PY, '-m', 'py_compile',
                    os.path.join(REPO, 'Nighty.py')])
if r.returncode:
    sys.exit('COMPILE FAIL')
print('compile gate: PASS')
r = subprocess.run([PY, AUDIT],
                   cwd=r'C:\Users\brian\AppData\Local\Temp\opencode')
if r.returncode:
    sys.exit('AUDIT FAIL')
print('audit gate: PASS')
r = subprocess.run([PY, os.path.join(BASE, 'oracle',
                                     'build_coverage.py')],
                   cwd=BASE)
if r.returncode:
    sys.exit('COVERAGE FAIL')

# ---------------------------------------------------------------- commit
manifest = {'shipped': [{'name': n, 'line': l} for n, l, _ in rows],
            'still_armed': remaining_armed,
            'no_body': remaining_no_body}
with open(os.path.join(BASE, 'oracle', 'out', 'vsrc39',
                       'ship_manifest.json'), 'w') as f:
    json.dump(manifest, f, indent=1)


def git(*args):
    return subprocess.run(['git', '-C', REPO] + list(args))


git('add', '-A')
git('commit', '-m',
    'Ship hand-decoded plain-lane bodies from the verified round-trip'
    ' gate')
subprocess.run(['git', '-C', REPO, 'log', '--oneline', '-3'])
print('SHIP PLAIN BODIES DONE')
