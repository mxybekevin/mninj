# analyze29.py - the fence29 after-action: classify every post-call
# marshal (did pyarmor restore co_code in place at call time?), then
# run the byte-keyed whole-body matcher over the new scratch stream for
# every pending target. Produces the final accounting + the list of
# newly-decodable units (ready for dossier + hand-decode).
import collections
import glob
import json
import marshal
import os
import struct
import types

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out')
RTP = os.path.join(OUT, 'fence29')
V5D = os.path.join(OUT, 'v5')

import opcode
VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}
NAME_OPS = {'LOAD_GLOBAL', 'STORE_GLOBAL', 'LOAD_NAME', 'STORE_NAME',
            'DELETE_NAME', 'LOAD_ATTR', 'STORE_ATTR', 'IMPORT_NAME',
            'IMPORT_FROM', 'LOAD_METHOD'}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)


def is_armed(code):
    return (len(code) >= 6 and code[0] == 0x74 and
            code[2:4] == b'\x83\x00' and code[4:6] == b'\x09\x00')


def utf16ish(b):
    s = b[:256]
    if not s:
        return False
    nulls = s.count(0)
    printable = sum(1 for x in s if 32 <= x < 127)
    return (nulls + printable) / len(s) >= 0.80 and nulls > len(s) * 0.25


def soupish(code):
    # zero-arg opcode soup: almost every arg byte is 0 and the ops,
    # though valid, are stack-noise chains (POP_TOP/ROT_TWO rows)
    if len(code) < 16:
        return False
    args_zero = sum(1 for i in range(1, len(code), 2)
                    if code[i] == 0)
    if args_zero < (len(code) // 2) * 0.9:
        return False
    popcount = sum(1 for i in range(0, min(len(code), 64), 2)
                   if code[i] in (0x01, 0x02, 0x1b, 0x10, 0x48))
    return popcount >= 8


def plain_ok(co):
    code = co.co_code
    L = len(code)
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nd = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    offs = {0}
    start = 0
    for i in range(0, len(co.co_lnotab or b''), 2):
        start += co.co_lnotab[i]
        offs.add(start)
    for i in range(0, L, 2):
        op = code[i]
        if op not in VALID:
            return False
        arg = code[i + 1] if i + 1 < L else 0
        nm = opcode.opname[op]
        if op < opcode.HAVE_ARGUMENT and arg != 0:
            return False
        if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == 'LOAD_CONST' and arg >= nconst:
            return False
        if nm in ('LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                  'LOAD_CLOSURE') and arg >= nd:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


# ------------------------------------------------ 1. post-call census
rows = []
for p in sorted(glob.glob(os.path.join(RTP, 'post_*.marshal'))):
    b = os.path.basename(p)
    try:
        co = marshal.load(open(p, 'rb'))
    except Exception as e:
        rows.append({'file': b, 'state': 'LOAD-FAIL',
                     'err': repr(e)[:60]})
        continue
    if not isinstance(co, types.CodeType):
        rows.append({'file': b, 'state': 'NOT-CODE'})
        continue
    if is_armed(co.co_code):
        st = 'ARMED'
    elif utf16ish(co.co_code):
        st = 'UTF16'
    elif soupish(co.co_code):
        st = 'SOUP'
    elif plain_ok(co):
        st = 'PLAIN!!'
    else:
        st = 'OTHER'
    rows.append({'file': b, 'name': str(co.co_name),
                 'line': co.co_firstlineno, 'size': len(co.co_code),
                 'state': st,
                 'head': co.co_code[:8].hex()})
cnt = collections.Counter(r['state'] for r in rows)
print('post-call marshals: %d' % len(rows))
print('states:', dict(cnt))
new_plain = [r for r in rows if r['state'] == 'PLAIN!!']
print('NEWLY PLAIN (in-place restore observed at call):')
for r in new_plain:
    print('   L%-7d %-28s %d B head=%s'
          % (r['line'], r['name'][:28], r['size'], r['head']))

# ------------------------------------- 2. byte-keyed matcher on the stream
sp = os.path.join(RTP, 'fence29_stream.bin')
if not os.path.exists(sp):
    print('no stream file')
    raise SystemExit(0)
size = os.path.getsize(sp)
print('stream: %d bytes' % size)

# targets: all pending units' code objects (metadata for hard_ok)
census_path = os.path.join(OUT, 'pending_census.json')
census = json.load(open(census_path))
target_keys = {(e['name'], e['line']) for k in census
               for e in census[k]}
targets = []
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        top = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(top, types.CodeType):
        continue
    stack = [(top, 0)]
    while stack:
        c, d = stack.pop()
        if d > 20:
            continue
        if (str(c.co_name), c.co_firstlineno) in target_keys:
            targets.append((str(c.co_name), c.co_firstlineno, c))
        for k in c.co_consts:
            if isinstance(k, types.CodeType):
                stack.append((k, d + 1))
print('matcher targets: %d' % len(targets))
by_len = collections.defaultdict(list)
for nm, fl, co in targets:
    by_len[len(co.co_code)].append((nm, fl, co))
lens = sorted(by_len)
MINLEN = lens[0] if lens else 16


def lnotab_offsets(lnotab):
    offs = {0}
    start = 0
    for i in range(0, len(lnotab or b''), 2):
        start += lnotab[i]
        offs.add(start)
    return offs


def hard_ok(win, co, L, offs):
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nd = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    for i in range(0, L, 2):
        op = win[i]
        if op not in VALID:
            return False
        arg = win[i + 1] if i + 1 < L else 0
        nm = opcode.opname[op]
        if op < opcode.HAVE_ARGUMENT and arg != 0:
            return False
        if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == 'LOAD_CONST' and arg >= nconst:
            return False
        if nm in ('LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                  'LOAD_CLOSURE') and arg >= nd:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


cands = collections.defaultdict(collections.Counter)
n = 0
with open(sp, 'rb') as f:
    while True:
        head = f.read(16)
        if len(head) < 16:
            break
        addr, ln_, t_ms = struct.unpack('<QII', head)
        if ln_ == 0 or ln_ > 2 * 1024 * 1024:
            break
        payload = f.read(ln_)
        if len(payload) < ln_:
            break
        n += 1
        for parity in (0, 1):
            pos = parity
            pl = len(payload) & ~1
            while pos < pl - 4:
                if payload[pos] not in VALID:
                    pos += 2
                    continue
                q = pos
                while q < pl and payload[q] in VALID:
                    q += 2
                run_len = q - pos
                if run_len >= MINLEN:
                    data = bytes(payload[pos:pos + run_len])
                    for L2 in (x for x in lens if x <= run_len):
                        for off2 in range(0, run_len - L2 + 1, 2):
                            run = data[off2:off2 + L2]
                            for nm, fl, co in by_len.get(L2, ()):
                                if hard_ok(run, co, L2,
                                           lnotab_offsets(
                                               co.co_lnotab or b'')):
                                    cands[(nm, fl)][run] += 1
                pos = q if q > pos else pos + 2
print('stream records processed: %d' % n)
verdicts = []
for (nm, fl), ctr in sorted(cands.items()):
    best = ctr.most_common(1)[0]
    verdicts.append({'name': nm, 'line': fl, 'len': len(best[0]),
                     'count': best[1], 'distinct': len(ctr),
                     'head': best[0][:8].hex()})
    print('%s L%d: distinct=%d best-count=%d len=%d head=%s'
          % (nm, fl, len(ctr), best[1], len(best[0]),
             best[0][:8].hex()))
with open(os.path.join(RTP, 'analyze29_report.json'), 'w') as f:
    json.dump({'post_census': rows, 'stream_verdicts': verdicts},
              f, indent=1)
print('-> analyze29_report.json')
print('ANALYZE29 DONE')
