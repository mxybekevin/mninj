# prune_tail.py - generic: remove every pending tail row whose
# (name, line) exists in the verified bank, recount, rebuild v6,
# gate, commit. Idempotent; safe to run after every ship.
import os
import re
import subprocess

REPO = r'D:\SSD-Offload\brian\Downloads\Nighty\NightyRecovered'
VBASE = REPO + r'\Nighty_base.py'
VER = (r'C:\Users\brian\Downloads\Nighty\oracle\out\vsrc39'
       r'\verified')
PY = r'C:\Users\brian\Downloads\Nighty\py38\python.exe'
AUDIT = (r'C:\Users\brian\AppData\Local\Temp\opencode'
         r'\verify_literals.py')

banked = set()
for p in os.listdir(VER):
    m = re.match(r'(.+)_L(\d+)\.py$', p)
    if m:
        banked.add((m.group(1), int(m.group(2))))

with open(VBASE, encoding='utf-8', newline='') as f:
    lines = f.read().replace('\r\n', '\n').split('\n')

PEND_ROW = re.compile(
    r'^#   - (\S+) \(line (\d+), (\d+) bytes\) '
    r'\[(STILL-ARMED|NO-BODY)[^]]*\]\s*$')

keep = []
removed = []
for ln in lines:
    m = PEND_ROW.match(ln)
    if m and (m.group(1), int(m.group(2))) in banked:
        removed.append((m.group(1), int(m.group(2))))
        continue
    if re.match(r'^# PENDING UNITS \(', ln):
        continue
    keep.append(ln)
lines = keep

armed = sum(1 for ln in lines if PEND_ROW.match(ln)
            and PEND_ROW.match(ln).group(4) == 'STILL-ARMED')
no_body = sum(1 for ln in lines if PEND_ROW.match(ln)
              and PEND_ROW.match(ln).group(4) == 'NO-BODY')

# insert the header right above the first pending row
pend_head = None
for i, ln in enumerate(lines):
    if re.match(r'^#   - (\S+) \(line ', ln):
        pend_head = i
        break
if pend_head is None:
    raise SystemExit('no pending rows found at all')
lines.insert(pend_head,
             '# PENDING UNITS (%d still-armed, %d no-body):'
             % (armed, no_body))
print('pruned %d rows: %s' % (len(removed), removed))
print('tail now: %d still-armed, %d no-body' % (armed, no_body))

with open(VBASE, 'w', encoding='utf-8', newline='\n') as f:
    f.write('\n'.join(lines))

r = subprocess.run([PY, REPO + r'\build_v6.py'], cwd=REPO)
if r.returncode:
    raise SystemExit('BUILD V6 FAIL')
r = subprocess.run([PY, '-m', 'py_compile', REPO + r'\Nighty.py'])
if r.returncode:
    raise SystemExit('COMPILE FAIL')
print('compile gate: PASS')
r = subprocess.run([PY, AUDIT],
                   cwd=r'C:\Users\brian\AppData\Local\Temp\opencode')
if r.returncode:
    raise SystemExit('AUDIT FAIL')
print('audit gate: PASS')
subprocess.run(['git', '-C', REPO, 'add', '-A'])
subprocess.run(['git', '-C', REPO, 'commit', '-m',
                'Prune shipped plain-lane units from the pending tail'])
subprocess.run(['git', '-C', REPO, 'log', '--oneline', '-2'])
print('PRUNE DONE')
