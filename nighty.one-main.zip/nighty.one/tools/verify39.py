# verify29d.py - the round-trip gate for the fence39 candidate finals:
# hand files in oracle/out/fence39/hand/<name>_L<line>.py are compiled
# (padded), matched to their candidate-armed code objects in
# fence39/dec/, and accepted only on instruction-stream identity
# (roundtrip_v3 normalize + nested lockstep, with the packaging-context
# canonicalizations).
import dis
import marshal
import os
import re
import types
import glob
import json

RTP = r'C:\Users\brian\Downloads\Nighty\oracle\out\fence39'
DEC = os.path.join(RTP, 'dec')
HAND = os.path.join(RTP, 'hand')
VER = os.path.join(RTP, 'verified')
os.makedirs(VER, exist_ok=True)

units = {}          # (filebase) -> co
for p in glob.glob(os.path.join(DEC, '*.marshal')):
    base = os.path.basename(p)[len('dec_'):-len('.marshal')]
    units[base] = marshal.load(open(p, 'rb'))


def normalize(co):
    instrs = list(dis.get_instructions(co))
    ordinal = {ins.offset: i for i, ins in enumerate(instrs)}
    out = []
    for ins in instrs:
        nm = ins.opname
        if nm.startswith('JUMP') or nm.startswith('SETUP') or \
                nm == 'FOR_ITER' or nm.startswith('POP_JUMP') or \
                nm == 'GET_ITER' or nm == 'CALL_FINALLY' or \
                nm == 'POP_FINALLY':
            t = ins.argval
            if isinstance(t, int) and t in ordinal:
                arg = 'J%d' % ordinal[t]
            else:
                arg = 'J?%r' % (t,)
        elif nm in ('LOAD_CONST', 'LOAD_FAST', 'STORE_FAST',
                    'DELETE_FAST', 'LOAD_GLOBAL', 'STORE_GLOBAL',
                    'LOAD_NAME', 'STORE_NAME', 'DELETE_NAME',
                    'LOAD_ATTR', 'STORE_ATTR', 'LOAD_METHOD',
                    'LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                    'LOAD_CLOSURE', 'IMPORT_NAME', 'IMPORT_FROM',
                    'COMPARE_OP'):
            if nm == 'LOAD_CONST' and \
                    isinstance(ins.argval, types.CodeType):
                c2 = ins.argval
                arg = '<code %s L%d +%d>' % (c2.co_name,
                                              c2.co_firstlineno,
                                              len(c2.co_code))
            elif nm == 'LOAD_CONST' and \
                    isinstance(ins.argval, str) and \
                    '<locals>' in ins.argval:
                s = ins.argval
                m2 = re.match(r'^(?:\w+\.)*(\w+\.<locals>\..*)$', s)
                arg = ('<qualname-local> ' + m2.group(1)) if m2 \
                    else repr(s)[:70]
            else:
                arg = repr(ins.argval)[:70]
        else:
            arg = ins.argrepr[:40] or repr(ins.argval)[:40]
        out.append((nm, arg))
    return out


def pairs_lockstep(orig, new, sink, path=''):
    sink.append((path, orig, new))
    seen = set()
    for i, c in enumerate(orig.co_consts):
        if not isinstance(c, types.CodeType):
            continue
        nc = None
        if i < len(new.co_consts) and \
                isinstance(new.co_consts[i], types.CodeType):
            nc = new.co_consts[i]
        else:
            for c2 in new.co_consts:
                if isinstance(c2, types.CodeType) and \
                        (c2.co_name, c2.co_firstlineno) == \
                        (c.co_name, c.co_firstlineno) and \
                        id(c2) not in seen:
                    nc = c2
                    break
        if nc is None:
            sink.append((path + '/' + str(c.co_name), c, None))
            continue
        seen.add(id(nc))
        pairs_lockstep(c, nc, sink, path + '/' + str(c.co_name))


def tree_identical(orig, new):
    if normalize(orig) != normalize(new):
        return False
    sink = []
    pairs_lockstep(orig, new, sink)
    for path, o, n in sink:
        if n is None or normalize(o) != normalize(n):
            return False
    return True


rows = []
for p in sorted(glob.glob(os.path.join(HAND, '*.py'))):
    m = re.match(r'(.+)_L(\d+)\.py$', os.path.basename(p))
    if not m:
        continue
    base = '%s_L%s' % (m.group(1), m.group(2))
    co = units.get(base)
    if co is None:
        print('NO-DEC %s' % base)
        continue
    src = open(p, encoding='utf-8').read()
    try:
        mod = compile('\n' * (co.co_firstlineno - 1) + src,
                      '<hand29>', 'exec')
    except SyntaxError as ex:
        print('SYNTAX-FAIL %s: %s' % (base, str(ex)[:70]))
        rows.append({'base': base, 'verdict': 'SYNTAX'})
        continue
    got = None
    for k in mod.co_consts:
        if isinstance(k, types.CodeType) and \
                str(k.co_name) == str(co.co_name):
            got = k
            break
    if got is None:
        print('NO-NESTED %s' % base)
        rows.append({'base': base, 'verdict': 'NO-NESTED'})
        continue
    if tree_identical(co, got):
        with open(os.path.join(VER, base + '.py'), 'w',
                  encoding='utf-8', newline='\n') as f:
            f.write(src)
        print('IDENTICAL %-32s (%d B)' % (base, len(co.co_code)),
              flush=True)
        rows.append({'base': base, 'len': len(co.co_code),
                     'verdict': 'IDENTICAL'})
    else:
        no, ng = normalize(co), normalize(got)
        d = sum(1 for a, b in zip(no, ng) if a != b) + \
            abs(len(no) - len(ng))
        print('DIFFERS   %-32s ndiff=%d lens=%d/%d'
              % (base, d, len(no), len(ng)), flush=True)
        rows.append({'base': base, 'verdict': 'DIFFERS',
                     'ndiff': d,
                     'lens': (len(no), len(ng))})

json.dump(rows, open(os.path.join(RTP, 'verify29d_report.json'),
                     'w'), indent=1)
print('VERIFY29D DONE')



