"""
theme_and_keywords.py — Nighty's theme loader + fallback cascade, the
others.json key/value store, and the keyword add/remove pair, from the
SPP native core with evidence chains.
"""

import json
import logging
import os


def _loadThemeFile(theme_name):
    """Registry L1297. Content: chunk labeled L1304.

    [E:] signature tuple ('theme_name',).
    [E:] open(getDataPath() + '/themes/' + theme_name + '.json',
              encoding='utf-8', errors='ignore') — NO explicit 'r'
              mode const in the stream (default read mode as-is).
    [E:] json.load; on failure the except machinery clears the error
         and the theme slot holds None (const None then
         PyErr_Fetch/PyErr_Clear in the dossier).
    [E:] not isinstance(theme, dict) -> raise ValueError('theme root
         is not an object') (exact message in stream).
    """
    try:
        with open(getDataPath() + '/themes/' + theme_name + '.json',
                  encoding='utf-8', errors='ignore') as f:
            theme = json.load(f)
    except Exception:
        theme = None
    if not isinstance(theme, dict):
        raise ValueError('theme root is not an object')
    return theme


def getThemeData(theme_name):
    """Registry L1304. Content: chunk labeled L1353.

    [E:] signature tuple ('theme_name',); head None/IsTrue/False guard
         on the argument (dossier 0x11bcc-0x11c7c) before the try.
    [E:] primary: processDThemeData(_loadThemeFile(theme_name),
         getConfigData(), getDRPCValues()).
    [E:] except Exception: error log with the exact string pieces
         "Theme '", "' unavailable (",
         "); falling back to the default theme."
         staged via logging + 'nighty' + GetAttr('error').
    [E:] second try: processDThemeData(_loadThemeFile('nighty'),
         getConfigData(), getDRPCValues()).
    [E:] except Exception: os.makedirs(getDataPath() + '/themes',
         exist_ok=True); atomicJsonDump(dict(DEFAULT_THEME),
         getDataPath() + '/themes/nighty.json'); config reload via
         getConfigData(); a 'get'/'theme'/'nighty'/IsTrue/False guard
         (events 110-120), then config['theme'] = 'nighty' (SetItem)
         + saveConfigData(config) — translated as a != 'nighty' guard,
         exact predicate partially resolved, flagged.
    [E:] the deep fallback returns dict(DEFAULT_THEME) — a second
         dict/DEFAULT_THEME pair (events 65/74) with NO third
         processDThemeData staging anywhere in the stream.
    [E:] REFINED via the force-private family evidence: the sibling
         getForcePrivateCommands stream uses logging + GetAttr('error')
         with NO 'getLogger' const — logging.error(...) direct. The two
         extra 'nighty' stagings here (events 37/50, each with an
         IsTrue) read as theme_name != 'nighty' guards: one around the
         error log, one around the 'nighty' retry. All five 'nighty'
         consts are now accounted: 37/50 guards, 57 retry-arg,
         116/122 config-fix.
    [E:] still flagged: the 'get'/'theme'/IsTrue cluster at events
         23-33 (possibly a pre-log theme-config check), and whether the
         two guards were a single combined guard in source form.
    """
    try:
        return processDThemeData(_loadThemeFile(theme_name),
                                 getConfigData(), getDRPCValues())
    except Exception as e:
        if theme_name != 'nighty':
            logging.error(
                f"Theme '{theme_name}' unavailable ({e}); "
                f"falling back to the default theme.")
            try:
                return processDThemeData(_loadThemeFile('nighty'),
                                         getConfigData(), getDRPCValues())
            except Exception:
                pass
        os.makedirs(getDataPath() + '/themes', exist_ok=True)
        atomicJsonDump(dict(DEFAULT_THEME),
                       getDataPath() + '/themes/nighty.json')
        config = getConfigData()
        if config.get('theme') != 'nighty':
            config['theme'] = 'nighty'
            saveConfigData(config)
        return dict(DEFAULT_THEME)


def getOthersData():
    """Registry L1353. Content: chunk labeled L1359.

    [E:] no signature tuple (0 args); json.load staged first, then
         open(getDataPath() + '/others.json', encoding='utf-8',
         errors='ignore') — again no explicit 'r' const.
    [E:] the except clause names BOTH FileNotFoundError and
         json.JSONDecodeError (both consts + GetAttr staged before the
         handler machinery) — a specific except-tuple, not bare.
    [E:] the except return value is dispatcher-built (no const in
         events); {} per the setOthersData SetItem usage — inferred.
    """
    try:
        with open(getDataPath() + '/others.json', encoding='utf-8',
                  errors='ignore') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def setOthersData(key, value):
    """Registry L1359. Content: chunk labeled L1374.

    [E:] signature tuple ('key', 'value').
    [E:] data = getOthersData(); data[key] = value via PyObject_SetItem
         (event 10) BEFORE the write.
    [E:] write-back: open(getDataPath() + '/others.json', 'w',
         encoding='utf-8', errors='ignore') + json.dump(..., indent=2).
    [E:] PyErr_Fetch machinery right after the dump call — a real try
         sits there; translated around the write block, bounds flagged
         approximate.
    """
    data = getOthersData()
    data[key] = value
    try:
        with open(getDataPath() + '/others.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


def addKeyword(keyword):
    """Registry L1374. Content: chunk labeled L1383.

    [E:] signature tuple ('keyword',).
    [E:] kws = getKeywords() (result stored); membership guard
         (IsTrue/False pair, events 10-15); 'append' staged twice
         (attr + invoke); write-back open(getDataPath() +
         '/keywords.json', 'w', encoding='utf-8', errors='ignore') +
         json.dump(..., indent=2); return True (final const, event 64).
    [E:] PyErr_Fetch machinery after the dump — try around the write;
         silence has no logging consts — translated as except/pass,
         flagged.
    """
    kws = getKeywords()
    if keyword not in kws:
        kws.append(keyword)
        try:
            with open(getDataPath() + '/keywords.json', 'w',
                      encoding='utf-8', errors='ignore') as f:
                json.dump(kws, f, indent=2)
        except Exception:
            pass
    return True


def removeKeyword(keyword):
    """Registry L1383. Content: chunk labeled L1428.

    [E:] signature tuple ('keyword',).
    [E:] identical shape to addKeyword (chunk L1383) but with
         'remove' GetAttr (event 16) instead of 'append'; the same
         write-back and the same final return True (event 64).
    """
    kws = getKeywords()
    if keyword in kws:
        kws.remove(keyword)
        try:
            with open(getDataPath() + '/keywords.json', 'w',
                      encoding='utf-8', errors='ignore') as f:
                json.dump(kws, f, indent=2)
        except Exception:
            pass
    return True
