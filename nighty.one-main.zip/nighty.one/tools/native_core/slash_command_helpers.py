"""
slash_command_helpers.py — the slash command metadata family
from the SPP native core (registry L7434-L7596), recovered from
the corpus event streams plus island dumps.

  commandSort(command)               — the sort key
  NightyCommand.__init__             — the name/description
                                        instance ctor
                                        (class name inferred,
                                        flagged below)
  _nightySlashCommandName(interaction) — the qualified-name
                                        unwrapper: walks the
                                        interaction payload's
                                        subcommand chain and
                                        returns '/'-prefixed
                                        names with the two
                                        Nighty wrapper levels
                                        stripped, '' on any
                                        failure
"""

import logging  # noqa: F401


def commandSort(command):
    """Registry L7434. Content: chunk L7443 — recovered from the
    island bytes of chunk 7443 (dump file
    chunk7443_commandSort_L7434.txt, @0x741c0 +304, alignment
    +1, 12 events, 79 insns, read complete through the
    __init__ entry at 0x742b0), cross-checked against the
    complete stream section (function@L7434, corpus lines
    20507-20518, read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[825]
        ('command',) staged 0x741c5 with the GOT_000 binder
        (r8d=1) at 0x741f1 — def commandSort(command):.
    [E:] THE BODY — the single-expression return: GetAttr over
        [rsp+0x58] with the 'name' GOT_273 (staged 0x7421a,
        resolved 0x7422e) wrapped kind-1 count-1 (0x7425f-
        0x7426c) and returned through the carried-value gate
        (test rsi at 0x7427d with the ret-disp 0x74287) —
        `return command.name`; corpus events 25-36.
    """
    return command.name


class NightyCommand:
    """Registry L7443 (the ctor). Content: chunk L7596 — the
    island bytes of chunk 7596 (dump file
    chunk7596_init_L7443.txt, @0x742f0 +304?? per the dump
    header alignment +0, 22 events, 133 insns, read complete
    through the _nightySlashCommandName entry at 0x744 b0),
    cross-checked against the complete stream section
    (function@L7443, corpus lines 20519-20535, read complete).

    CLASS NAME FLAG: no live const in this span carries the
    class name and no streamed caller names it; NightyCommand
    is a mechanical inference from the members (a .name /
    .description holder sorted by commandSort), flagged
    rather than guessed; rename when a caller or decorator
    const surfaces.
    """

    def __init__(self, name, description):
        """Registry L7443. Signature ('self', 'name',
        'description') [E:] — the names-tuple CONST[824]
        staged 0x742fe with the GOT_000 binder (r8d=3) at
        0x7432a, the [rsp+0x58]/[rsp+0x60]/[rsp+0x68] binder
        targets.

        [E:] THE BODY — the two attribute stores: SetAttr
            (GOT_020 call 0x74382: rcx = self [rsp+0x58],
            rdx = 'name' GOT_273 staged 0x74344, r8 = the
            name [rsp+0x60]) — `self.name = name` — then the
            mirror SetAttr at 0x7440e (rcx = self, rdx =
            'description' GOT_249 staged 0x743db, r8 = the
            description [rsp+0x68]) — `self.description =
            description`; the frame tail is the slot DecRefs,
            the r14b error check and the implicit None
            return; corpus events 31-72.
        """
        self.name = name
        self.description = description


def _nightySlashCommandName(interaction):
    """Registry L7596. Content: chunk L7657 — recovered from
    the island bytes of chunk 7657 (dump file
    chunk7657__nightySlashCommandName_L7596.txt, @0x744f0
    +2028?? per the dump header alignment +0, 157 events, 797
    insns, read complete through the splitEmbedText entry at
    0x750c0), cross-checked against the complete stream
    section (function@L7596, corpus lines 20536-20697, read
    complete).

    [E:] THE SIGNATURE — the names-tuple CONST[821]
        ('interaction',) staged 0x74510 with the GOT_000
        binder (r8d=1) at 0x7453c.
    [E:] THE DATA — GetAttr(interaction [rsp+0x58], 'data'
        GOT_568, resolved 0x7456a) through IsTrue (0x745a7):
        the TRUTHY side stores the data, the FALSY side
        releases and builds the kind-3 edx=0 empty dict
        (0x74604) then rejoins — the or-emission —
        `data = interaction.data or {}`.
    [E:] THE NAME LIST — [data.get('name')]: the .get
        GetAttr (GOT_47, 0x7464c) over the kind-1 ('name'
        GOT_273, 0x7467a) call, the result wrapped kind-2
        count-1 (the a9d18 build 0x746b4-0x746c1 — the
        single-element LIST) binding [rsp+0x68].
    [E:] THE WHILE WALK — options = data.get('options') (the
        kind-1 'options' GOT_822 call 0x74778) into
        [rsp+0x70]; the loop head at 0x747c6 drives through
        IsTrue([rsp+0x70]) and the a9d30 sel-6 membership of
        options[0].get('type') against the live CONST[823]
        (1, 2) tuple (edx=6 at 0x749b5) with the isinstance
        gate (GOT_168 'isinstance' staged 0x747ef with the
        'list' GOT_344 staged 0x74832, kind-1 count-2) —
        the SPP re-optimizer merges the three condition
        tails into one IsTrue gate at 0x749fd whose falsy
        edge exits to the post-loop at 0x74e73, so the
        compact form
        `while options and isinstance(options, list) and
        options[0].get('type') in (1, 2):` is shipped (the
        break-per-condition form is emission-equivalent and
        noted here rather than hidden); the body —
        names.append (GOT_250 GetAttr 0x74a4a) over the
        options[0].get('name') kind-1 wrapper (the GetItem of
        options with CONST[277] 0 at 0x74aad, the 'get'+name
        call 0x74b58) called 0x74b86 — then options =
        options[0].get('options') or [] (the mirrored
        GetItem + get-call with the kind-2 edx=0 falsy-side
        build 0x74c9f, converging 0x74cba and rebinding
        [rsp+0x70]); corpus events 141-291.
    [E:] THE FILTER — the comprehension over [rsp+0x68]:
        the PyList_New(xor ecx, 0x74e75) fresh list, the
        GetIter over the names (CONST[27] call 0x74e9a),
        the iternext loop 0x74ec6-0x74f23 whose IsTrue gate
        (0x74eed) sends falsy items to the back-edge and
        appends the truthy (PyList_Append GOT_018 0x74f0f)
        — `[name for name in names if name]` — rebinding
        [rsp+0x68] (0x74f68).
    [E:] THE TAIL — the '/'+join: the ' ' GOT_243 staged
        0x74fa1 with the .join GetAttr (GOT_166, resolved
        0x74fc4), the names sliced [-2:] — the GOT_003
        negative-materializer dispatch over the int-2
        CONST[478] staged 0x75011-0x7502b (the GOT_003/0x1e
        unary-negative reading, established for
        removeRandomChars@L6832 and corroborated by
        before@L7949's find == -1 gate) feeds the PySlice
        START slot with the stop/step slots NULL (the
        CONST[26] PySlice-family call 0x75030-0x75038; the
        rcx=start/rdx=stop operand order is locked by
        maskString@L7857's [:5] mirror where the NULL sat in
        rcx and the 5 in rdx), the GetItem over [rsp+0x68]
        at 0x75054 — wrapped kind-1 and joined (0x7509c),
        then the a9d10 selector-7 plain plus over ('/'
        GOT_813 staged 0x74f8c, the join result) —
        `return '/' + ' '.join(names[-2:])` (0x750ae), the
        qualified-name capped to its last two path
        components; corpus events 435-477.
    [E:] THE GUARD — the whole body flows its error paths
        into 0x74d0e: the DAT_a9d40 exception fetch with the
        a9d30 selector-0xa match against the live CONST[77]
        'Exception' (staged 0x74d3c, kind-check edx=0xa at
        0x74d7e, cmp edi, 1), the matched path returning the
        CONST[241] '' staged 0x74daa, the unmatched path
        through GOT_002 (0x74df8) with the error flag —
        `except Exception: return ''`; corpus events
        488-517.
    """
    try:
        data = interaction.data or {}
        names = [data.get('name')]
        options = data.get('options')
        while options and isinstance(options, list) \
                and options[0].get('type') in (1, 2):
            names.append(options[0].get('name'))
            options = options[0].get('options') or []
        names = [name for name in names if name]
        return '/' + ' '.join(names[-2:])
    except Exception:
        return ''
