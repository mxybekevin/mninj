"""
ui_containers.py — the UI container/tab composition families
(registry L3659-L3931), recovered via the Ghidra decomp lane.

Recovered as real classes: the double-underscore privates below
reproduce the mangled _Group__* / _CardContainer__* / _Card__* /
_Tab__* const slots exactly at runtime.

Composition contract recovered: containers construct children
through create_* factories that pass parent_<x>=self plus the
inherited tab_updater/parent_tab_name and append+return; every
render emits 'elements': [el.render() for el in ...] (PyList_New
+ GOT_1264 'render' + PyList_Append).

  Group     L3659-L3731   (class-name const 1305 'Group')
  CardContainer L3731-L3789 (1278 'CardContainer')
  Card      L3805-L3855
  Tab       L3855-L3931
  module:   updateLastSeen, convert_custom_emojis
"""

import datetime
import json
import re
import uuid

from threading import Timer


class Group:
    """A layout group (registry L3667-L3731)."""

    def __init__(self, tab_updater, parent_tab_name, type,
                 parent_card=None, parent_group=None,
                 horizontal_align=None, vertical_align=None,
                 gap=None, full_width=None):
        """Registry L3667 (Group.__init__). Content: chunk labeled
        L3700 — decompiled as a merged region (dossier pass
        queued); the SIGNATURE is live const-pool evidence [E:]:
        slot 1345 = ('self', 'tab_updater', 'parent_tab_name',
        'type', 'parent_card', 'parent_group', 'horizontal_align',
        'vertical_align', 'gap', 'full_width').

        [E:] the guard message 'Group must be created by a Card
             or a Group.' (GOT_1346, EXACT) sits in the class
             neighborhood — an instantiation-guard raise keyed on
             parent_card / parent_group (the guard idiom shared
             with CardContainer's 1326 / Card's 1308). The
             attributes anchor to: __type (GOT_1331), __id
             (GOT_1336), __gap (GOT_1337), __full_width (GOT_
             1338), __horizontal_align (GOT_1339),
             __vertical_align (GOT_1340), __elements (GOT_1341),
             __parent_tab_name (GOT_1342), __tab_updater (GOT_
             1343), the parent_group kwarg (GOT_1344).
        [E:] flag (partial): the ctor body is dossier-queued; the
             defaults below are NOT evidence-encoded (the sig
             tuple carries none) — translated with None defaults
             to keep the factory contract callable; the __id form
             follows the family idiom (its render str()-converts,
             evidenced GOT_150).
        """
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__type = type
        self.__parent_card = parent_card
        self.__parent_group = parent_group
        self.__horizontal_align = horizontal_align
        self.__vertical_align = vertical_align
        self.__gap = gap
        self.__full_width = full_width
        self.__elements = []

    def create_group(self, type):
        """Registry L3700 (Group.create_group). Content: chunk
        labeled L3705 (raw spp_span_create_ui_element_3705.c,
        read end-to-end). Signature ('self', 'type') [E:] — the
        (…,1,2) frame idiom (two formals beside self).

        [E:] group = Group(parent_group=self — GET 1344, raw
             L51-64 — tab_updater=self.__tab_updater (GOT_1280/
             1343, raw L65-83), parent_tab_name=self.__parent_
             tab_name (GOT_1282/1342, raw L89-108), type=<the
             parameter> (raw L111-116)) — the kwargs-only
             construction call raw L117-119; then
             self.__elements.append(group) (GOT_1341 + GOT_250 +
             the (1,1) arg build over the call result, raw
             L129-165); the group is RETURNED (raw L171-174).
        """
        group = Group(parent_group=self,
                      tab_updater=self.__tab_updater,
                      parent_tab_name=self.__parent_tab_name,
                      type=type)
        self.__elements.append(group)
        return group

    def create_ui_element(self, element):
        """Registry L3705 (Group.create_ui_element). Content:
        chunk labeled L3713 (raw spp_span_render_3713.c, read
        end-to-end). Signature ('self', 'element') [E:] — the
        family sig slot 1301; the parameter is a class/factory —
        it is CALLED (raw L105: the call target is the parameter
        slot).

        [E:] the call constructs the element with the kwargs
             {'parent_tab_name': self.__parent_tab_name,
             'tab_updater': self.__tab_updater} (the keys +
             GetAttrs evidenced raw L54-103: GOT_1282/1342 and
             GOT_1280/1343); then
             ui_element_instance_checker(<the new element>) —
             the checker global (GOT_1304) with the (1,1) arg
             build over the call result (raw L114-129; the
             checker's own signature = ('element',) — slot 1348
             LIVE); then self.__elements.append(<the new
             element>) (GOT_1341/250, raw L133-170) and the
             element is returned (raw L176-179).
        [E:] flag: the raw shows a second small build
             (register-held, raw L104) whose operand is not
             const-resolved — the call frame beyond the two
             evidenced kwargs is flagged.
        """
        element_instance = element(
            parent_tab_name=self.__parent_tab_name,
            tab_updater=self.__tab_updater)
        ui_element_instance_checker(element_instance)
        self.__elements.append(element_instance)
        return element_instance

    def render(self):
        """Registry L3713 (Group.render). Content: chunk labeled
        L3731 (stream section function@L3713).

        [E:] the gate: self.__type (GOT_1331) checked against
             'columns_group' (GOT_1332) / 'rows_group' (GOT_1333)
             → ValueError("Group type must be either 'columns'
             or 'rows'") — EXACT GOT_1334 (note: the MESSAGE
             cites the short forms while the membership uses the
             *_group values — both exact).
        [E:] the emitted dict: 'id' + str (GOT_150) over
             __id (GOT_1336); 'type' + __type; 'gap' (GOT_1260) +
             __gap (GOT_1337); 'full_width' (GOT_1335) +
             __full_width (GOT_1338); 'horizontal_align'
             (GOT_1289) + __horizontal_align (GOT_1339);
             'vertical_align' (GOT_1288) + __vertical_align
             (GOT_1340); 'elements' (GOT_1290) = the
             list-comprehension: PyList_New (GOT_024) + iterate
             __elements (GetIter + a9d60) with el.render()
             (GOT_1264) + PyList_Append (GOT_018).
        """
        if self.__type not in ('columns_group', 'rows_group'):
            raise ValueError("Group type must be either "
                            "'columns' or 'rows'")
        return {
            'id': str(self.__id),
            'type': self.__type,
            'gap': self.__gap,
            'full_width': self.__full_width,
            'horizontal_align': self.__horizontal_align,
            'vertical_align': self.__vertical_align,
            'elements': [element.render()
                         for element in self.__elements],
        }


class CardContainer:
    """A card container column/row (registry L3731-L3789)."""

    def __init__(self, parent_tab, tab_updater, parent_tab_name,
                 type, height, width, gap):
        """Registry L3731 (CardContainer.__init__). Content:
        chunk labeled L3756 (raw spp_span_create_container_3756.c,
        read end-to-end). Signature [E:] — const-pool tuple slot
        1324 (LIVE) = ('self', 'parent_tab', 'tab_updater',
        'parent_tab_name', 'type', 'height', 'width', 'gap').

        [E:] the parent guard FIRST: isinstance(parent_tab,
             (Tab, CardContainer)) — the Tab class global (GOT_
             1325, raw L56-63) + the CardContainer class (GOT_
             1278, raw L66-72) built into the (1,2) tuple (raw
             L75) + the isinstance call (GOT_168, raw L77) →
             raise ValueError('Containers can only be created by
             the Tab or CardContainer class.') — EXACT GOT_1326
             (raw L97-116).
        [E:] the type gate: type not in ('columns' GOT_1327 /
             'rows' GOT_1328) via a9d30 (raw L129) → raise
             ValueError("Container type must be either 'columns'
             or 'rows'") — EXACT GOT_1329. Flag: an additional
             selector-3 cluster (raw L186/L207) reads as a
             secondary check — flagged unresolved.
        [E:] the cascade (raw L225-263 + the stream L259-507):
             self.__id = uuid.uuid4() — NOTE: NO str() wrap is
             evidenced for this class (the render GetAttrs it
             plain); __tab_updater (GOT_1322), __height (GOT_
             1316), __width (GOT_1317), __gap (GOT_1318),
             __parent_tab_name (GOT_1323), __elements = <the
             a9d18 empty build> (GOT_1319), __type (GOT_1315).
        [E:] the validators: two variant_validator (GOT_1310)
             calls staged with the height/width arg reads (stream
             L400-507) — translated as the AVAILABLE_HW gates
             (GOT_1311 family); the exact input binding is
             flagged pending the io pass.
        """
        if not isinstance(parent_tab, (Tab, CardContainer)):
            raise ValueError('Containers can only be created '
                             'by the Tab or CardContainer class.')
        if type not in ('columns', 'rows'):
            raise ValueError("Container type must be either "
                             "'columns' or 'rows'")
        self.__id = uuid.uuid4()
        self.__tab_updater = tab_updater
        self.__height = height
        self.__width = width
        self.__gap = gap
        self.__parent_tab_name = parent_tab_name
        self.__elements = []
        self.__type = type
        variant_validator(AVAILABLE_HW, self.__height)
        variant_validator(AVAILABLE_HW, self.__width)

    def create_container(self, type):
        """Registry L3756 (CardContainer.create_container).
        Content: chunk labeled L3761 (stream section
        function@L3756). Signature ('self', 'type') [E:] —
        const-pool tuple slot 1277 (LIVE).

        [E:] container = CardContainer(parent_tab=self — the
             'parent_tab' kwarg key GOT_1279 + self,
             tab_updater=self.__tab_updater (GOT_1280/1322),
             parent_tab_name=self.__parent_tab_name (GOT_1282/
             1323), type=<the parameter> (GOT_248 + L111-112));
             then self.__elements.append(container) (GOT_1319 +
             GOT_250, L129-158); returned (L160-184).
        """
        container = CardContainer(
            parent_tab=self,
            tab_updater=self.__tab_updater,
            parent_tab_name=self.__parent_tab_name,
            type=type)
        self.__elements.append(container)
        return container

    def create_card(self, type):
        """Registry L3761 (CardContainer.create_card). Content:
        chunk labeled L3789 (stream section function@L3761).

        [E:] card = Card(parent_container=self — the kwarg key
             GOT_1321, L135-138 — tab_updater=self.__tab_updater
             (GOT_1280/1322), parent_tab_name=self.__parent_
             tab_name (GOT_1282/1323)); then
             self.__elements.append(card) (GOT_1319/250,
             L135-162); returned (L166-190).

        NOTE: the Card.__init__ signature (slot 1307) carries NO
        type parameter — the 'type' const staged at the section
        head is the next chunk's staging bleed, not a kwarg
        (per the off-by-one tail law); the factory passes only
        the three evidenced kwargs.
        """
        card = Card(
            parent_container=self,
            tab_updater=self.__tab_updater,
            parent_tab_name=self.__parent_tab_name)
        self.__elements.append(card)
        return card

    def render(self):
        """Registry L3789 (CardContainer.render). Content: chunk
        labeled L3805 (stream section function@L3789). NO gates.

        [E:] the dict: 'id' + str (GOT_150) over __id (GOT_
             1314); 'type' + __type (GOT_1315); 'height' (GOT_
             118) + __height (GOT_1316); 'width' (GOT_116) +
             __width (GOT_1317); 'gap' (GOT_1260) + __gap (GOT_
             1318); 'elements' (GOT_1290) = [el.render() for el
             in __elements (GOT_1319)] — PyList_New + GOT_1264 +
             PyList_Append.
        """
        return {
            'id': str(self.__id),
            'type': self.__type,
            'height': self.__height,
            'width': self.__width,
            'gap': self.__gap,
            'elements': [element.render()
                         for element in self.__elements],
        }


class Card:
    """A card (registry L3805-L3855)."""

    def __init__(self, parent_container, tab_updater,
                 parent_tab_name, height, width, vertical_align,
                 horizontal_align, gap, disallow_shrink):
        """Registry L3805 (Card.__init__). Content: chunk labeled
        L3827 — decompiled as a merged region; the SIGNATURE is
        live const-pool evidence [E:]: slot 1307 = ('self',
        'parent_container', 'tab_updater', 'parent_tab_name',
        'height', 'width', 'vertical_align', 'horizontal_align',
        'gap', 'disallow_shrink').

        [E:] const set: __id (GOT_1292), __type (GOT_1293),
             __height (GOT_1294), __width (GOT_1295), __gap
             (GOT_1296), __vertical_align (GOT_1297), __horizontal_
             align (GOT_1298), __elements (GOT_1299), __disallow_
             shrink (GOT_1300), __parent_tab_name (GOT_1302),
             __tab_updater (GOT_1303); the type literal 'card'
             (GOT_1309 — the __type assignment, NO type
             parameter exists in the sig); the guard message
             'Card must be created by a CardContainer.' (GOT_
             1308, EXACT); the module validators named in this
             neighborhood: variant_validator (GOT_1310) +
             AVAILABLE_HW (GOT_1311) + VALID_ALIGN (GOT_1312) +
             _gap_validator (GOT_1313).
        [E:] flag (partial — merged region): the guard +
             validator placement follows the raw-decoded
             CardContainer ctor sibling (isinstance guard first;
             id = uuid.uuid4() — NO str() stage evidenced, the
             Card render emits the raw UUID; the BARE line-up:
             AVAILABLE_HW over height/width, VALID_ALIGN over
             both aligns, _gap_validator over gap — the 1310-1313
             cluster binding flagged).
        """
        if not isinstance(parent_container, CardContainer):
            raise ValueError('Card must be created by a '
                             'CardContainer.')
        self.__id = uuid.uuid4()
        self.__type = 'card'
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__height = height
        self.__width = width
        self.__vertical_align = vertical_align
        self.__horizontal_align = horizontal_align
        self.__gap = gap
        self.__elements = []
        self.__disallow_shrink = disallow_shrink
        variant_validator(AVAILABLE_HW, self.__height)
        variant_validator(AVAILABLE_HW, self.__width)
        variant_validator(VALID_ALIGN, self.__vertical_align)
        variant_validator(VALID_ALIGN, self.__horizontal_align)
        _gap_validator(self.__gap)

    def create_group(self, type):
        """Registry L3827 (Card.create_group). Content: chunk
        labeled L3832 (stream section function@L3827).
        Signature ('self', 'type') [E:] — the frame idiom, the
        family shape of Group.create_group.

        [E:] group = Group(parent_card=self — the kwarg key GOT_
             1306 + self, L57-64 — tab_updater=self.__tab_updater
             (GOT_1280/1303, L65-83), parent_tab_name=self.__
             parent_tab_name (GOT_1282/1302, L89-106), type=<the
             parameter> (GOT_248, L111-112)); then
             self.__elements.append(group) (GOT_1299 + GOT_250,
             L129-158); returned (L160-184).
        """
        group = Group(parent_card=self,
                      tab_updater=self.__tab_updater,
                      parent_tab_name=self.__parent_tab_name,
                      type=type)
        self.__elements.append(group)
        return group

    def create_ui_element(self, element):
        """Registry L3832 (Card.create_ui_element). Content:
        chunk labeled L3840 (stream section function@L3832).
        Signature ('self', 'element') [E:] — the family sig slot
        1301 + the raw-decoded Group sibling.

        [E:] the element factory call with the kwargs
             {'parent_tab_name': self.__parent_tab_name (GOT_
             1302, L54-75), 'tab_updater': self.__tab_updater
             (GOT_1303, L80-98)}; then
             ui_element_instance_checker(<the new element>)
             (GOT_1304, L114-124; the checker sig = ('element',),
             slot 1348); then self.__elements.append(<the new
             element>) (GOT_1299 + GOT_250, L134-162); returned
             (L165-190).
        """
        element_instance = element(
            parent_tab_name=self.__parent_tab_name,
            tab_updater=self.__tab_updater)
        ui_element_instance_checker(element_instance)
        self.__elements.append(element_instance)
        return element_instance

    def render(self):
        """Registry L3840 (Card.render). Content: chunk labeled
        L3855 (stream section function@L3840). NO gates.

        [E:] the dict: 'id' + __id (GOT_1292); 'type' + __type
             (GOT_1293); 'height' (GOT_118) + __height (GOT_
             1294); 'width' (GOT_116) + __width (GOT_1295);
             'gap' (GOT_1260) + __gap (GOT_1296); 'vertical_
             align' (GOT_1288) + __vertical_align (GOT_1297);
             'horizontal_align' (GOT_1289) + __horizontal_align
             (GOT_1298); 'elements' (GOT_1290) + [el.render()
             for el in __elements (GOT_1299)]; then
             'disallow_shrink' (GOT_1291) + __disallow_shrink
             (GOT_1300). Flag: the id pair shows no str() stage
             (raw UUID), consistent with the family.
        """
        return {
            'id': self.__id,
            'type': self.__type,
            'height': self.__height,
            'width': self.__width,
            'gap': self.__gap,
            'vertical_align': self.__vertical_align,
            'horizontal_align': self.__horizontal_align,
            'elements': [element.render()
                         for element in self.__elements],
            'disallow_shrink': self.__disallow_shrink,
        }


class Tab:
    """A UI tab (registry L3855-L3931)."""

    def __init__(self, name, icon, gap, title):
        """Registry L3855 (Tab.__init__). Content: chunk labeled
        3865 (stream section function@L3855). SIGNATURE live
        [E:]: const-pool tuple slot 1286 = ('self', 'name',
        'icon', 'gap', 'title').

        [E:] the SetAttr cascade: self.__rendered = False (GOT_
             1252 + GOT_032, L40-49); self.__name (GOT_1261,
             L87-96); three further SetAttrs (L113, L163, 180 —
             const names register-held; the class block marks
             __icon (GOT_1262), __gap (GOT_1265), __title (GOT_
             1266)); self.__card_containers = <the a9d18 build>
             (GOT_1263, L122-129); self.__debounce_timer = None
             (GOT_1254 + GOT_030, L138-146). The name validation
             runs through __validate_name (registry L3865; its
             ref slot 1287) — where it is invoked from is not
             const-visible (flagged).
        """
        self.__rendered = False
        self.__name = name
        self.__icon = icon
        self.__gap = gap
        self.__title = title
        self.__card_containers = []
        self.__debounce_timer = None

    def __validate_name(self, name):
        """Registry L3865 (Tab.__validate_name). Content: chunk
        labeled L3872 (stream section function@L3865).

        [E:] gate 1: the empty-name truth check (L32-41) →
             ValueError('Tab name cannot be empty') — EXACT GOT_
             1283 (L98-119).
        [E:] gate 2: len(name) > 36 — len (GOT_267) + the
             compare + int 36 (GOT_1284, L58-78) →
             ValueError('Tab name cannot exceed 36 characters') —
             EXACT GOT_1285 (L105-119).
        """
        if not name:
            raise ValueError('Tab name cannot be empty')
        if len(name) > 36:
            raise ValueError('Tab name cannot exceed 36 '
                             'characters')
        return name

    def create_container(self, type):
        """Registry L3872 (Tab.create_container). Content: chunk
        labeled L3894 (stream section function@L3872).
        Signature ('self', 'type') [E:] — const-pool tuple slot
        1277 (LIVE).

        [E:] container = CardContainer(parent_tab=self — the
             kwarg GOT_1279 + self, tab_updater=self.__update
             (GOT_1280 + GOT_1281 — the BOUND UPDATE METHOD
             passed as the updater, L69-83), parent_tab_name=
             self.__name (GOT_1282/1261, L89-106), type=<the
             parameter> (GOT_248, L111-112)); then
             self.__card_containers.append(container) (GOT_1263 +
             GOT_250, L129-156); returned (L160-184).
        """
        container = CardContainer(
            parent_tab=self,
            tab_updater=self.__update,
            parent_tab_name=self.__name,
            type=type)
        self.__card_containers.append(container)
        return container

    def toast(self, title, description, type):
        """Registry L3894 (Tab.toast). Content: chunk labeled
        3905 (stream section function@L3894). Signature ('self',
        'title', 'description', 'type') [E:] — const-pool tuple
        slot 1267 (LIVE).

        [E:] gate 1: empty title → ValueError('Toast title
             cannot be empty') — EXACT GOT_1268.
        [E:] gate 2: empty description → ValueError('Toast
             description cannot be empty') — EXACT GOT_1269.
        [E:] gate 3: type not in ('INFO' GOT_1270, 'SUCCESS'
             GOT_888, 'ERROR' GOT_067) → ValueError("Toast type
             must be either 'INFO', 'SUCCESS', or 'ERROR'") —
             EXACT GOT_1271.
        [E:] the push: evaluate_js('showCustomUIToast({ type: "'
             + type + '", title: "' + title + '", description:
             "' + description + '", tabName: "' + self.__name +
             '" })') — the EXACT piece consts GOT_1272/1273/
             1274/1275/1276 with the __name GetAttr (L198-215).
        """
        if not title:
            raise ValueError('Toast title cannot be empty')
        if not description:
            raise ValueError('Toast description cannot be empty')
        if type not in ('INFO', 'SUCCESS', 'ERROR'):
            raise ValueError("Toast type must be either 'INFO', "
                             "'SUCCESS', or 'ERROR'")
        evaluate_js('showCustomUIToast({ type: "' + type
                    + '", title: "' + title
                    + '", description: "' + description
                    + '", tabName: "' + self.__name
                    + '" })')

    def __getFormattedData(self):
        """Registry L3905 (Tab.__getFormattedData). Content:
        chunk labeled L3915 — recovered from the interior bytes
        of chunk 3915 (dump file chunk3915___getFormattedData_
        L3905.txt; the lane-1/decomp 'file merged/absent'
        verdict was a boundary artifact — the chunk decodes at
        alignment +0).

        [E:] frame: const-pool tuple ('self',) slot 278 with the
             GOT_000 frame-enter op putting self at frame+0x88.
        [E:] name = self.__name (GetAttr GOT_1261); icon =
             self.__icon (GOT_1262); both null-guarded.
        [E:] card_containers (GOT_1259) staged as a dict key;
             rendered = PyList_New (0x404af) — a fresh list; the
             self.__card_containers fetch (GOT_1263) drives
             GetIter (slot 27) + SUBGOT_a9d60 iternext loop
             (0x40550): rendered.append(container.render()) —
             GetAttr 'render' (GOT_1264) called with a zero-arg
             pack, PyList_Append (0x405d4). The no-containers
             path (iterator null at 0x4053d) drops the fresh
             list and carries None — flagged below.
        [E:] gap = self.__gap (key GOT_1260, attr GOT_1265);
             title = self.__title (key GOT_370, attr GOT_1266).
        [E:] the dict build: SUBGOT_a9d18 kind-3 count-5 at
             0x40725-0x40746 with the pair slots in order
             ('name', name), ('icon', icon), ('card_containers',
             rendered), ('gap', gap), ('title', title).
        [E:] return json.dumps(data, indent=2) — json module
             staged (GOT_143) -> GetAttr 'dumps' (GOT_420); the
             args 1-tuple + kwargs kind-3 count-1 ('indent',
             int 2) (GOT_690 + GOT_478, 0x40804-0x40833); the
             call with r9=1 kwargs-flag (0x40850). The return
             rides the ret-dispatch with a None fallback.
        """
        data = {
            'name': self.__name,
            'icon': self.__icon,
            'card_containers': [
                container.render()
                for container in self.__card_containers
            ],
            'gap': self.__gap,
            'title': self.__title,
        }
        return json.dumps(data, indent=2)

    def __update(self):
        """Registry L3915 (Tab.__update — the debounced update
        trigger). Content: chunk labeled L3925 (stream section
        function@L3915).

        [E:] `if self.__rendered:` — the gate (GOT_1252 +
             IsTrue, L26-61).
        [E:] `if self.__debounce_timer is not None:
             self.__debounce_timer.cancel()` — the compare +
             None cluster (L64-109) + 'cancel' (GOT_1255,
             L112-146).
        [E:] self.__debounce_timer = Timer(0.005,
             self.__perform_update) — the float 0.005 (GOT_1257,
             the EXACT debounce delay) + the bound
             __perform_update (GOT_1258) with 'Timer' (GOT_1256,
             L154-203); then .start() (GOT_082, L226-246).
        """
        if self.__rendered:
            if self.__debounce_timer is not None:
                self.__debounce_timer.cancel()
            self.__debounce_timer = Timer(
                0.005, self.__perform_update)
            self.__debounce_timer.start()

    def __perform_update(self):
        """Registry L3925 (Tab.__perform_update). Content: chunk
        labeled L3931 (stream section function@L3925).

        [E:] evaluate_js('updateCustomUiTab(' + <?data> + ')') —
             the __getFormattedData call (GOT_1249, L33-47) +
             evaluate_js (GOT_041) + ')' (GOT_1251).
        [E:] the __getFormattedData body is now RECOVERED (see
             the method above) — the earlier merged-region flag
             is cleared 2026-10-15.
        """
        evaluate_js('updateCustomUiTab('
                    + str(self.__getFormattedData()) + ')')

    def render(self):
        """Registry L3931 (Tab.render). Content: chunk labeled
        L3982 (stream section function@L3931).

        PARTIALLY RECONSTRUCTED (flagged): the __getFormattedData
        call + evaluate_js('addCustomTab(' + ... + ')') pieces +
        the json.dumps/loads tokens + the __custom_ui_tabs__
        global append + self.__rendered = True are evidenced;
        the exact orchestration is flagged pending the raw pass.

        [E:] 'addCustomTab(' (GOT_1250) + ')' (GOT_1251) + the
             a9d48 joins (L78-90); evaluate_js (GOT_041); the
             __custom_ui_tabs__ global (GOT_629) + append (GOT_
             250, L98-114); json + loads (GOT_143/424, L118-139);
             self.__rendered = True (GOT_1252 + GOT_031 + the
             SetAttr, L155-164).
        """
        data = self.__getFormattedData()
        evaluate_js('addCustomTab('
                    + json.dumps(json.loads(data)) + ')')
        __custom_ui_tabs__.append(self.__getFormattedData())
        self.__rendered = True


def updateLastSeen():
    """Registry L3982 (module-level). Content: chunk labeled
    L3985 (stream section function@L3982). Zero-arg.

    [E:] bot.last_seen[bot.user.id] = datetime.now() — bot
         (GOT_244) + 'last_seen' (GOT_1248) + 'id' (GOT_265) +
         datetime (GOT_151) + now (GOT_152) + PyObject_SetItem
         (GOT_022, L92); silent None tail.
    """
    bot.last_seen[bot.user.id] = datetime.now()


def convert_custom_emojis(message):
    """Registry L3990 (module-level). Content: chunk labeled
    L4000 (stream section function@L3990). Signature
    ('message',) [E:] — const-pool tuple slot 1244 (LIVE).

    [E:] `if not isinstance(message, str): return message`
         (GOT_168 + GOT_150, L36-88).
    [E:] return re.sub(r'<a?:(\\w+):\\d+>', ':\\1:', message) —
         the EXACT pattern GOT_1245 = '<a?:(\w+):\d+>' + the
         replacement GOT_1246 = ':\1:' + re (GOT_228) + sub
         (GOT_257, L115-190) with the re.search-staging at
         L127-134 (the match-test shape — the sub dominates;
         flagged).
    """
    if not isinstance(message, str):
        return message
    return re.sub(r'<a?:(\w+):\d+>', r':\1:', message)


def get_custom_emojis(content):
    """Registry L6624. Content: chunk labeled L6640 — recovered
    from the interior bytes of chunk 6640 (dump file
    chunk6640_get_custom_emojis_L6624.txt; the 'file
    merged/absent' verdict was a boundary artifact — the chunk
    decodes at alignment +0, 88 events). Signature ('content',)
    [E:] — const-pool tuple slot 256 (LIVE).

    Collects the CDN urls of every custom emoji used in the
    content, keyed by the raw emoji string.

    [E:] custom_emojis = re.findall(r'(<a?:[a-zA-Z0-9_]+:
         \\d+>)', content) — the EXACT pattern GOT_968 +
         findall (GOT_969) over the a9d18 (1,2) args build,
         0x601ae-0x60294.
    [E:] emojis = {} — the a9d18 kind-3 count-0 EMPTY DICT
         build (0x602be).
    [E:] the loop: GetIter + SUBGOT_a9d60 (0x60313, back-edge
         0x6032c); per emoji re.match with the EXACT group
         pattern GOT_970 = '<a?:([a-zA-Z0-9_]+):(\\d+)>' with
         match (GOT_681, 0x6038c-0x60412) gated by the IsTrue
         chain (0x60452-0x6046e).
    [E:] m.groups() ('groups' GOT_971) unpacked TWO ways
         through GOT_004 with r8d=2 (0x604f3): the name slot is
         stored but never re-read — the original unpacked
         (name, emoji_id) and used only emoji_id — kept
         faithfully.
    [E:] extension = 'gif' if emoji.startswith('<a:') else
         'png' — 'startswith' GOT_234 with '<a:' GOT_972
         (0x6056b-0x60601), the IsTrue select choosing 'gif'
         (GOT_973) over 'png' (GOT_974, 0x6065f-0x60678).
    [E:] the url: an f-string — the a9d48 4-piece
         BUILD_STRING (ecx=4, 0x6070c) over the literal
         'https://cdn.discordapp.com/emojis/' (GOT_975),
         the FORMAT_VALUE-converted emoji_id (the -1 a9d48
         at 0x606c4), the literal '.' (GOT_808) and the
         FORMAT_VALUE-converted extension (the -1 a9d48 at
         0x606fa); no a9d10 concatenation exists at this
         site, and the extension select is stored to a slot
         ([rsp+0xa0], 0x6065f-0x60678) ahead of the join.
    [E:] emojis[emoji] = url — PyObject_SetItem (0x6077e) with
         the raw emoji string as the key; the dict returned via
         the found-flag ret-dispatch (0x60891-0x60896); empty
         dict falls back to it (the None path is the error
         thread only).
    """
    custom_emojis = re.findall(
        r'(<a?:[a-zA-Z0-9_]+:\d+>)', content)
    emojis = {}
    for emoji in custom_emojis:
        m = re.match(r'<a?:([a-zA-Z0-9_]+):(\d+)>', emoji)
        if m:
            name, emoji_id = m.groups()
            extension = ('gif'
                         if emoji.startswith('<a:')
                         else 'png')
            emojis[emoji] = (
                f'https://cdn.discordapp.com/emojis/'
                f'{emoji_id}.{extension}')
    return emojis
