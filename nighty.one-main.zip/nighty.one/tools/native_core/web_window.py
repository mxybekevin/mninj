"""
web_window.py — the webview window wrapper class from the
SPP native core (registry L7397-L7434), recovered from the
corpus event streams plus island dumps. The class wraps a
pywebview-style window object (hide / destroy / evaluate_js
are the wrapped API) that hosts the Discord web client —
connect injects the current token through a localStorage
iframe shim and force-navigates to the friends view.

  __init__(self)          — self._window = None
  set_window(self, window)— the wrapper binding
  hide(self)              — self._window.hide()
  close(self)             — self._window.destroy()
  connect(self)           — token injection + navigate
  disconnect(self)        — paste-token re-injection + hide

CLASS NAME FLAG: no live const in this span carries the
class name and no streamed caller names it — the name
WebWindow is a mechanical inference from the members
(_window / evaluate_js / the login-token JS), flagged
rather than guessed; rename when a caller or decorator
const surfaces.

RE-SNATCH LANDED: the 16 truncated-at-rest long consts are
fully live in got_snatch/const_reprs.json after the
raised-cap fence session — disconnect's 503-byte CONST[826]
is quoted verbatim above. The remaining deferred material in
the registry is the 2 ARMED spans' key material (the armed
fence session) plus the labor tier.
"""

import json  # noqa: F401  (module-family import parity)


class WebWindow:

    def __init__(self):
        """Registry L7397. Content: chunk L7400 — recovered
        from the island bytes of chunk 7400 (dump file
        chunk7400_init_L7397.txt, @0x73790 +352,
        alignment +2, 17 events, 89 insns, read complete
        through the set_window entry at 0x738b0),
        cross-checked against the complete stream section
        (function@L7397, corpus lines 20376-20389, read
        complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x73794 with the GOT_000
            binder at 0x737c0 (r8d=1 — the param count) and
            the [rsp+0x58] target; test eax, eax / jne
            0x73892 = the arity-mismatch silent None-return
            shim.
        [E:] THE BODY — the single statement: the '_window'
            CONST[620] staged 0x737da with the CONST[30]
            None staged 0x737e8, the SetAttr dispatch
            (GOT_020, coroutine 0x7380f: rcx = self
            [rsp+0x58], rdx = '_window', r8 = None) —
            `self._window = None`; the tail PyErr checks and
            the implicit None return complete the frame;
            corpus events 26-58.
        """
        self._window = None

    def set_window(self, window):
        """Registry L7400. Content: chunk L7403 — recovered
        from the island bytes of chunk 7403 (dump file
        chunk7403_set_window_L7400.txt, @0x738f0 +336,
        alignment +0, 14 events, 92 insns, read complete
        through the hide entry at 0x73a00),
        cross-checked against the complete stream section
        (function@L7400, corpus lines 20391-20402, read
        complete).

        [E:] THE SIGNATURE — the names-tuple CONST[651]
            ('self', 'window') staged 0x738ff with the
            GOT_000 binder at 0x7392b (r8d=2) — the
            parameter names live-pinned.
        [E:] THE BODY — the SetAttr dispatch (0x73978: rcx
            = self [rsp+0x58], rdx = '_window' GOT_620
            staged 0x73945, r8 = the second binder target
            [rsp+0x60] the window) — `self._window =
            window`; the frame tail releases the triple and
            returns None implicitly; corpus events 29-39.
        """
        self._window = window

    def hide(self):
        """Registry L7403. Content: chunk L7406 — recovered
        from the island bytes of chunk 7406 (dump file
        chunk7406_hide_L7403.txt, @0x73a40 +400,
        alignment +3, 19 events, 109 insns, read complete
        through the close entry at 0x73b90),
        cross-checked against the complete stream section
        (function@L7403, corpus lines 20404-20423, read
        complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x73a45 with the GOT_000 binder
            (r8d=1) at 0x73a71.
        [E:] THE BODY — the chain: GetAttr(self [rsp+0x58],
            '_window') resolved 0x73aa6, then GetAttr over
            the CONST[648] 'hide' staged 0x73ad7 (resolved
            0x73af0), the method zero-Argument CALLED
            (r8d=0 / r9d=0 at 0x73b22) with the result
            released through the bookkeeping pair —
            `self._window.hide()`; corpus events 21-47.
        """
        self._window.hide()

    def close(self):
        """Registry L7406. Content: chunk L7409 — recovered
        from the island bytes of chunk 7409 (dump file
        chunk7409_close_L7406.txt, @0x73bd0 +400,
        alignment +3, 18 events, 108 insns, read complete
        through the connect entry at 0x73d20),
        cross-checked against the complete stream section
        (function@L7406, corpus lines 20425-20444, read
        complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x73bd5 with the GOT_000 binder
            (r8d=1) at 0x73c01.
        [E:] THE BODY — the chain: GetAttr(self [rsp+0x58],
            '_window') resolved 0x73c36, then GetAttr over
            the CONST[646] 'destroy' staged 0x73c67
            (resolved 0x73c80), the method zero-argument
            called (r8d=0 / r9d=0 at 0x73cb2) with the
            result released — `self._window.destroy()`; the
            frame tail is the PyErr checks and the implicit
            None return; corpus events 21-47.
        """
        self._window.destroy()

    def connect(self):
        """Registry L7409. Content: chunk L7417 — recovered
        from the island bytes of chunk 7417 (dump file
        chunk7417_connect_L7409.txt, @0x73d60 +672,
        alignment +0, 32 events, 172 insns, read complete
        through the disconnect entry at 0x73fc0),
        cross-checked against the complete stream section
        (function@L7409, corpus lines 20446-20480, read
        complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x73d73 with the GOT_000
            binder (r8d=1) at 0x739f... the binder call at
            0x73d9f, target [rsp+0x58].
        [E:] THE TOKEN — the getCurrentToken module global
            LOAD (GOT_563 staged 0x73db4, r8d=1) zero-arg
            called (r8d=0 / r9d=0 at 0x73df9) binding
            [rsp+0x60].
        [E:] THE INJECTION — GetAttr(self [rsp+0x58],
            '_window' GOT_620, resolved 0x73e40) then
            GetAttr(window, 'evaluate_js' GOT_041 staged
            0x73e71, resolved 0x73e8a) — the f-string
            BUILD_STRING(3) at 0x73ef7 (ecx=3): the
            GOT_827 literal staged 0x73eb7 — '\\n    if
            (window.location.href !== "https://discord.com/
            channels/@me") {\\n        document.body.
            appendChild(document.createElement `iframe`).
            contentWindow.localStorage.token = `"' (180
            bytes, LIVE) — the FORMAT_VALUE over the token
            [rsp+0x60] (the -1 a9d48 at 0x73ee6) — and the
            GOT_828 literal staged 0x73ee8 — '"`\\n
            window.location.href = "https://discord.com/
            channels/@me";\\n    }' (79 bytes, LIVE); the
            kind-1 count-1 wrapper (0x73f05-0x73f12) and
            the call at 0x73f30 (r8d=1) —
            self._window.evaluate_js(f'{GOT_827}{token}
            {GOT_828}'); corpus events 83-90.
        [E:] THE TAIL — the result release, the PyErr checks
            and the implicit None return (0x73f41-0x73f9b);
            corpus events 107-121.
        """
        token = getCurrentToken()
        self._window.evaluate_js(
            f'\n    if (window.location.href !== '
            f'"https://discord.com/channels/@me") {{\n'
            f'        document.body.appendChild('
            f'document.createElement `iframe`).contentWindow'
            f'.localStorage.token = `"{token}"`\n'
            f'        window.location.href = '
            f'"https://discord.com/channels/@me";\n'
            f'    }}')

    def disconnect(self):
        """Registry L7417. Content: chunk L7434 — recovered from the
        island bytes of chunk 7434 (dump file
        chunk7434_disconnect_L7417.txt, per the dumper +0 align, 21
        events, 118 insns, read complete through the commandSort
        prologue at 0x7423f), cross-checked against the complete
        stream section (function@L7417, corpus lines 20481-20506,
        read complete). The connect mirror: re-inject the
        paste-token login shim then flip the window away.

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x74005 with the GOT_000 binder (r8d=1) at
            0x74031.
        [E:] THE CHAIN — GetAttr(self [rsp+0x58], '_window'
            CONST[620] staged 0x74052, resolved through the 0x74071
            staging pair) then GetAttr over 'evaluate_js'
            CONST[41] staged 0x4097... staged 0x74097 — the kind-1
            wrap over the full 503-byte CONST[826] staged 0x740d6
            (the literal is LIVE-quoted post re-snatch: the token
            re-injection loop with the 50ms iframe-localStorage
            shim, the 2500ms location.reload, the
            login('PASTE TOKEN HERE') seed and the 2000ms
            pywebview.api.hide() dismissal) — the one-positional
            call — self._window.evaluate_js(<CONST[826]>) — with
            the implicit None return staged 0x7413d through the
            ret-disp (a9d28) at 0x74159; corpus events 17-93.
        """
        self._window.evaluate_js(
            '\n            function login(token) {\n'
            '                setInterval(() => {\n'
            '                    document.body.appendChild'
            '(document.createElement `iframe`).contentWindow'
            '.localStorage.token = `"${token}"`\n'
            '                }, 50);\n'
            '                setTimeout(() => {\n'
            '                    location.reload();\n'
            '                }, 2500);\n'
            '            }\n\n'
            "            login('PASTE TOKEN HERE')\n"
            '            setTimeout(function() {\n'
            '                pywebview.api.hide();\n'
            '            }, 2000);\n'
            '            ')
