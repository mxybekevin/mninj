"""
file_store.py — the theme/script file-store bridge callbacks from the
SPP native core (registry L8008-L8025), recovered from the corpus
event streams plus island dumps.

  get_theme_path(theme_name)      — os.path.join over two f-strings
  rename_theme(old_name, new_name)— the pywebview bridge rename
  get_script_path(filename)       — the scripts-folder join
  rename_script(old_name, new_name)— the mirror rename

BRIDGE-PROTOCOL NOTE: the rename callbacks return the
(None, None) JSON-bridge failure pair when the source is missing
or anything raises, and the (old_name, new_name) names on
success — the JS side keeps its stores name-keyed, so the
callback answers with the logical names, not the disk paths
(the paths stay in the try scope and feed os.rename via the
[rsp+0x78]/[rsp+0x80] work slots while the names live in the
[rsp+0x68]/[rsp+0x70] binder slots the final tuple re-loads).

LAW REFINEMENT (locked on get_theme_path): the a9d48 string
builder = the BUILD_STRING machinery of the F-STRING LAW — a
build opens with the first piece in rdx and the r8d = -1 start
flag, then each subsequent piece appends with ecx = 2 + the
piece in r8; pieces stage in source order. Two two-piece builds
compile f'{getDataPath()}/themes' and f'{theme_name}.json'.
"""

import os


def get_theme_path(theme_name):
    """Registry L8008. Content: chunk L8011 — recovered from the
    island bytes of chunk 8011 (dump file
    chunk8011_get_theme_path_L8008.txt, per the dumper +0 align,
    26 events, 162 insns, read complete through the rename_theme
    prologue at 0x78240), cross-checked against the complete
    stream section (function@L8008, corpus lines 21248-21276,
    read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[727]
        ('theme_name',) staged 0x77fdb with the GOT_000 binder
        (r8d=1) at 0x78007.
    [E:] THE CHAIN — the os name load (CONST[34] through the
        a9d50 stage 0x78042), GetAttr 'path' (CONST[165], resolved
        through the 0x78054-0x7806f chain), GetAttr 'join'
        (CONST[166], 0x7808c) binding rsi — os.path.join.
    [E:] THE FIRST BUILD — f'{getDataPath()}/themes': the
        getDataPath global (CONST[194]) loaded by name
        (0x780d9-0x780f5) and called ZERO-ARGUMENT (r13, r8d=0)
        at 0x7811e; the a9d48 builder opens with that result in
        rdx and the r8d = -1 start flag (0x78121-0x7812f), then
        appends the '/themes' piece (CONST[728] staged 0x78132,
        append ecx=2 at 0x78141-0x78149) — pieces in source
        order per the F-STRING LAW.
    [E:] THE SECOND BUILD — f'{theme_name}.json': the builder
        reloaded 0x7814f, opened with the [rsp+0x58] parameter
        and the r8d = -1 flag (0x78156-0x7816d), then the
        '.json' piece (CONST[729] staged 0x7816f, append at
        0x7817e-0x78186).
    [E:] THE JOIN — the kind-1 two-item build (ecx=1, edx=2,
        r8 = the first built string, r9 = the second) at
        0x78188-0x78198 feeding the os.path.join call (rdx=rsi,
        r8d=1) at 0x781b7, returned via the ret-disp (a9d28) at
        0x781d2; corpus events 23-91. CORPUS LABEL NOTE: the
        censored '/themes' label in the stream resolves live —
        the const-table slot 728 carries '/themes' with NO
        trailing slash (lookup_consts), the separator coming
        from the runtime join.
    """
    return os.path.join(
        f'{getDataPath()}/themes',
        f'{theme_name}.json')


def rename_theme(old_name, new_name):
    """Registry L8011. Content: chunk L8022 — recovered from the
    island bytes of chunk 8022 (dump file
    chunk8022_rename_theme_L8011.txt, per the dumper +0 align, 70
    events, 373 insns, read complete through the get_script_path
    prologue at 0x78810), cross-checked against the complete
    stream section (function@L8011, corpus lines 21277-21341,
    read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[720]
        ('old_name', 'new_name') staged 0x78258 with the GOT_000
        binder (r8d=2) at 0x78284 — the parameters live in the
        [rsp+0x68]/[rsp+0x70] binder slots (the first-call wrap
        loads [rsp+0x68] at 0x782d2).
    [E:] THE FIRST PATH — the get_theme_path global (CONST[726])
        name-loaded 0x78299-0x782b5, the kind-1 [old_name] wrap
        (0x782cb-0x782e9), the call at 0x78307 storing old_path
        to [rsp+0x78] (0x78312-0x78317).
    [E:] THE GUARD — os.path.exists(old_path): the os load
        0x7832e, GetAttr 'path' 0x78360, GetAttr 'exists'
        (CONST[193]) 0x78398, the kind-1 wrap over [rsp+0x78]
        (0x783d0-0x783ee) with the call at 0x7840c and the
        IsTrue at 0x7841e; the FALSY side lands on the
        materialized TRUE const at 0x7844a (the NOT-SWAP
        EMISSION law) and the re-IsTrue at 0x7845f routes it
        through jne 0x784ab to the (None, None) return —
        the CONST[722] probe staged 0x784b3 — i.e.
        `if not os.path.exists(old_path): return (None, None)`;
        corpus events 58-105.
    [E:] THE SECOND PATH — the get_theme_path global reloaded
        0x78484-0x784a0, the kind-1 [new_name] wrap (the
        [rsp+0x70] binder slot; the exact load line sits in the
        0x784d5-0x784e4 window, slot-locked by the
        rename_script mirror at 0x78cbc and the final tuple's
        r9), the call at 0x78511 storing new_path to [rsp+0x80]
        (0x7851c-0x78524).
    [E:] THE RENAME — the os reload 0x78537 with GetAttr
        'rename' (CONST[723]) 0x78570-0x78589, the kind-1
        two-item build (ecx=1, edx=2, r8 = [rsp+0x78] old_path,
        r9 = [rsp+0x80] new_path) 0x785a8-0x785d6, the call at
        0x785f4 — os.rename(old_path, new_path).
    [E:] THE SUCCESS RETURN — the kind-1 two-item build over
        the BINDER slots (r8 = [rsp+0x68] old_name, r9 =
        [rsp+0x70] new_name) at 0x7860d-0x78638, carried to the
        epilogue at 0x78642 → 0x7873d and the ret-disp
        (a9d28) at 0x787a5 — `return (old_name, new_name)`.
    [E:] THE GUARD-RETURN SCOPE — the except-machinery catches
        the whole body: the DAT_a9d40 fetch 0x78659 with the
        a9d30 selector-0xa exception match (the except-match
        law; CONST[77] 'Exception' staged 0x78672, edx=0xa
        mirror at rename_script 0x78e89), the matched arm
        returning CONST[722] (None, None) staged 0x7870b, the
        unmatched arm through GOT_002 (0x78753) — the return-
        inside-try and return-after-try forms are
        emission-identical here; the compact in-try form is
        shipped and noted; corpus events 226-246.
    """
    try:
        old_path = get_theme_path(old_name)
        if not os.path.exists(old_path):
            return (None, None)
        new_path = get_theme_path(new_name)
        os.rename(old_path, new_path)
        return (old_name, new_name)
    except Exception:
        return (None, None)


def get_script_path(filename):
    """Registry L8022. Content: chunk L8025 — recovered from the
    island bytes of chunk 8025 (dump file
    chunk8025_get_script_path_L8022.txt, per the dumper +0 align,
    22 events, 133 insns, read complete through the rename_script
    prologue at 0x78a30), cross-checked against the complete
    stream section (function@L8022, corpus lines 21342-21364,
    read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[724]
        ('filename',) staged 0x78829 with the GOT_000 binder
        (r8d=1) at 0x78855.
    [E:] THE CHAIN — the os name load 0x78874, GetAttr 'path'
        (CONST[165]) 0x788a2, GetAttr 'join' (CONST[166])
        0x788da binding rsi.
    [E:] THE ARGUMENTS — the getScriptsPath global (CONST[725])
        name-loaded 0x78920-0x7893c and called ZERO-ARGUMENT
        (r12, r8d=0) at 0x78965; the kind-1 two-item build
        (ecx=1, edx=2) with r8 = the getScriptsPath() result and
        r9 = the [rsp+0x58] filename at 0x78968-0x78982 — the
        argument ORDER is operand-locked: (getScriptsPath(),
        filename); the os.path.join call (rdx=rsi, r8d=1) at
        0x789a1 and the ret-disp (a9d28) at 0x789bc; corpus
        events 21-77.
    """
    return os.path.join(getScriptsPath(), filename)


def rename_script(old_name, new_name):
    """Registry L8025. Content: chunk L8035 — recovered from the
    island bytes of chunk 8035 (dump file
    chunk8035_rename_script_L8025.txt, per the dumper +0 align,
    69 events, 370 insns, read complete), cross-checked against
    the complete stream section (function@L8025, corpus lines
    21365-21429, read complete). This is the byte-mirror of
    rename_theme@L8011 (same corpus event structure, same const
    slots) with get_script_path in place of get_theme_path; the
    mirror-verified zones carry the rename_theme citations.

    [E:] THE SIGNATURE — the names-tuple CONST[720]
        ('old_name', 'new_name') staged 0x78a38 with the GOT_000
        binder (r8d=2) at 0x78a64.
    [E:] THE FIRST PATH — the get_script_path global (CONST[721])
        staged 0x78a79, the kind-1 [old_name] wrap and call
        storing old_path to [rsp+0x78] at 0x78af2-0x78af7 (the
        0x782cb-0x78317 mirror).
    [E:] THE GUARD — os.path.exists (GetAttr CONST[193] at
        0x78b78) over the old_path wrap, the FALSY side landing
        on the TRUE const at 0x78c2a (0x78c19 = the False-slot
        for the exists-truthy fold; the NOT-SWAP EMISSION law),
        routing to the (None, None) return — the CONST[722] probe
        staged 0x78c93; corpus events 58-105.
    [E:] THE SECOND PATH — the get_script_path global reloaded
        0x78c64 with the kind-1 [new_name] wrap (the [rsp+0x70]
        load READ at 0x78cbc — the anchor locking the binder
        slot map for the whole family), the call storing
        new_path to [rsp+0x80] (the 0x7851c-0x78524 mirror).
    [E:] THE RENAME — the os reload 0x78d1e with GetAttr
        'rename' (CONST[723]) 0x78d50 and the kind-1 two-item
        call over the [rsp+0x78]/[rsp+0x80] paths (the
        0x785a8-0x785f4 mirror zone).
    [E:] THE SUCCESS RETURN — the kind-1 two-item build over the
        binder slots (r8 = [rsp+0x68], r9 = [rsp+0x70]) at
        0x78ded-0x78e18 — `return (old_name, new_name)` —
        carried to the epilogue at 0x78e22 → 0x78f1d.
    [E:] THE GUARD-RETURN SCOPE — the a9d30 selector-0xa
        exception match (edx=0xa READ at 0x78e89, the except-
        match law) over the CONST[77] 'Exception' staged
        0x78e52, the matched arm returning CONST[722] (None,
        None) at 0x78eeb, the unmatched arm through GOT_002;
        corpus events 226-246.
    """
    try:
        old_path = get_script_path(old_name)
        if not os.path.exists(old_path):
            return (None, None)
        new_path = get_script_path(new_name)
        os.rename(old_path, new_path)
        return (old_name, new_name)
    except Exception:
        return (None, None)


def open_file_in_explorer(file_path):
    """Registry L8332. Content: chunk L8336 — recovered from the
    island bytes of chunk 8336 (dump file
    chunk8336_open_file_in_explorer_L8332.txt, per the dumper +0
    align, 38 events, 200 insns, read complete through the
    showWelcome prologue), cross-checked against the complete
    stream section (function@L8332, corpus lines 21993-22032,
    read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[692]
        ('file_path',) staged 0x7e703 with the GOT_000 binder
        (r8d=1) at 0x7e72f.
    [E:] THE PATH — the os name load (CONST[34], 0x7e744) with
        GetAttr 'path' (CONST[165], 0x7e776) and GetAttr
        'abspath' (CONST[693], 0x7e7ae), the kind-1
        [file_path] wrap and the zero-arg-result call —
        os.path.abspath(file_path).
    [E:] THE COMMAND — the os reload (0x7e84a) with GetAttr
        'system' (CONST[694], 0x7e87c); the three-piece
        f-string through the a9d48 builder (start at 0x7e8bb
        start over the 'explorer /select,"' CONST[695] staged
        0x7e8c2, the abspath result piece, and the '"'
        CONST[235] staged 0x7e8f3) — f'explorer
        /select,"{os.path.abspath(file_path)}"' — wrapped
        kind-1 and passed to the os.system call (corpus events
        94-116); the implicit None return; corpus events 27-130.
    """
    os.system(f'explorer /select,"{os.path.abspath(file_path)}"')


def showWelcome(show):
    """Registry L8336. Content: chunk L8352 — recovered from the
    island bytes of chunk 8352 (dump file
    chunk8352_showWelcome_L8336.txt, per the dumper +0 align,
    122 events, 640 insns, read complete through the next
    registry entry prologue at 0x7f3f0), cross-checked against
    the complete stream section (function@L8336, corpus lines
    22033-22120, read complete). The once-welcome flag store:
    a None argument reads, anything else writes and rewrites.

    [E:] THE SIGNATURE — the names-tuple CONST[682] ('show',)
        staged 0x7ea26 with the GOT_000 binder (r8d=1) at
        0x7ea52.
    [E:] THE WITH — the 'open' CONST[201] global name (a9d50
        stage 0x7ea83), the two-piece f-string through the
        a9d48 builder (start over the getDataPath zero-arg
        result, the '/misc/welcome.json' CONST[683] append
        0x7eb07), the 'r+' CONST[684] staged 0x7eb21, the
        kwargs-kind-3 encoding='utf-8' (284/285 at 0x7eb4a-
        0x7eb59) and errors='ignore' (685/686 at 0x7eb68) with
        PyCallFunction 0x7ec15 — with open(f'{getDataPath()}'
        '/misc/welcome.json', 'r+', encoding='utf-8',
        errors='ignore') as f: — the CONST[1857] + DAT_a9d40 +
        GOT_002 tail at 0x7f0af-0x7f19b is the __exit__ half of
        the WITH emission law.
    [E:] THE LOAD — json.load(f): the json CONST[143] global
        and 'load' CONST[286] 0x7ed2e with the kind-1 [f] wrap;
        corpus events 37-136.
    [E:] THE READ GATE — the a9d30 with edx=8 (the IS-family
        selector — 8 = is, 9 = is not, completing the
        richcompare table) binding r8 = the [rsp+0x78] show
        against r9 = None at 0x7edf5 — `if show is None:` —
        the truthy side running data.get('welcome') (the
        'welcome' CONST[687] staged 0x7eec8, the kind-1 wrap
        and call 0x7eeff) whose result binds [rsp+0x90] and
        rides the 0x7efa7 exit — `return data.get('welcome')`
        (the not-swap inversion triple 0x7ee19-0x7ee4c);
        corpus events 148-220.
    [E:] THE WRITE GATE — the mirror a9d30 with edx=9 (is
        not) at 0x7ef4e — `show is not None` — the truthy side
        running SetItem over the data container with the
        'welcome' key and the show value at 0x7f02f —
        data['welcome'] = show — then f.seek(0) (the
        CONST[277] int-0 staged 0x7f205, kind-1 wrap and call
        0x7f23c), json.dump(data, f, indent=2) (the kind-1
        two-item [data, f] build 0x7f2c3-0x7f2f4, the
        kwargs-kind-3 {'indent': CONST[690] 2} 0x7f2f9-0x7f328,
        the r8d=1/r9d=1 positional+kwargs call form 0x7f345),
        f.truncate() (CONST[691] staged 0x7f370, zero-arg call
        0x7f3c9), and the shared 0x7efa7 exit returning None —
        the implicit write-arm return; corpus events 221-504.
    """
    with open(f'{getDataPath()}/misc/welcome.json', 'r+',
              encoding='utf-8', errors='ignore') as f:
        data = json.load(f)
        if show is None:
            return data.get('welcome')
        data['welcome'] = show
        f.seek(0)
        json.dump(data, f, indent=2)
        f.truncate()
