"""
app_boot.py — the application boot and runtime-support tail of
the SPP native core (registry L12020-L12763), recovered from the
island bytes of chunks 12032-12763, cross-checked against the
complete stream sections. This block is the original file's
tail: the asset checks, the web-login window boot, the firewall
provisioner, the server/webview starters and the exit handlers —
ending at on_closed@L12763, the LAST registry function (recovered
from the post-span executor bytes).

  checkTurboSniper()      — the TurboSniper.exe download guard
  checkfonts()            — the five webfont downloads
  checksounds()           — the nine sound downloads
  isConnectionError(err)  — the requests exception probe
  find_discord_exe(p)     — the os.walk discord.exe finder
  saveTokenToConfigCl(t)  — the plain client token saver
  checkWebLogin()         — the web-login window boot
  addFirewallRules(p, n)  — the PowerShell provisioner pair
  startWebview()          — webview.start with the fixed profile
  startFlaskServer()      — the socketio.run server
  handle_uncaught_exception(l, c) — the asyncio error hook
  on_load()               — the window-loaded zoom reset
  on_closed()              — SIGTERM self-kill (registry tail)
"""

import datetime  # noqa: F401
import json  # noqa: F401
import logging  # noqa: F401
import os  # noqa: F401
import requests  # noqa: F401
import subprocess  # noqa: F401
import sys  # noqa: F401
import urllib.request  # noqa: F401
import webview  # noqa: F401

from signal import SIGTERM  # noqa: F401  # the bare-name load


def checkTurboSniper():
    """Registry L12020. Content: chunk L12032 — recovered from the
    island bytes of chunk 12032 (dump file
    chunk12032_checkTurboSniper_12020.txt, span +2128, alignment
    +0), cross-checked against the complete stream section
    (function@L12020, corpus lines 27622-27750).

    [E:] THE SIGNATURE — zero parameters: the chunk starts
        with only the frame stage; NO GOT_000 binder and no
        names-tuple const.
    [E:] THE PATH — os (CONST[34]), GetAttr 'path' (CONST[165]),
        GetAttr 'join' (CONST[166]); the getNightyPath
        (CONST[222]) name-load + zero-arg call, the 2-tuple
        with CONST[223] 'TurboSniper.exe' —
        os.path.join(getNightyPath(), 'TurboSniper.exe') ->
        the turbo_sniper_path local (a STORE_FAST: read by the
        exists probe and the open arg).
    [E:] THE GATE — os.path.exists (CONST[193]) over the path:
        IsTrue -> the exists arm returns the implicit None
        (jmp the shared tail); the not-exists falls to the
        download block <=> `if not os.path.exists(...)`.
    [E:] THE DOWNLOAD — urllib.request (CONST[196]/[197])
        urlopen (CONST[198]) over CONST[224]
        'https://nighty.one/public_downloads/TurboSniper.exe'
        with kwargs ('timeout': CONST[225] 30).
    [E:] WITH #1 / WITH #2 — the with-protocol stages (the
        a9d50 r8d=4/5 ramps + the enter-call) over the urlopen
        result and over open(path, 'wb') (CONST[201]/[202]) —
        `with ... as response:` / `with open(...) as f:`;
        the exit halves at the CONST[1857] corpus events
        (LAW 10).
    [E:] THE BODY — f.write(response.read()) (the write
        CONST[203] + the read CONST[200]).
    [E:] THE EXCEPT — every download-statement failure routes
        to the exc fetch (DAT_a9d40 + the a9d30 sel-0xa +
        CONST[77] 'Exception'); the matched arm contains NO
        further const staging = `except Exception: pass`; the
        unmatched arm re-raises via GOT_002.

    FLAG: the turbo_sniper_path local is name-inferred.
    """
    turbo_sniper_path = os.path.join(getNightyPath(),
                                     'TurboSniper.exe')
    if not os.path.exists(turbo_sniper_path):
        try:
            with urllib.request.urlopen(
                    'https://nighty.one/public_downloads/'
                    'TurboSniper.exe',
                    timeout=30) as response:
                with open(turbo_sniper_path, 'wb') as f:
                    f.write(response.read())
        except Exception:
            pass


def checkfonts():
    """Registry L12032. Content: chunk L12064 — recovered from the
    island bytes of chunk 12064 (dump file
    chunk12064_checkfonts_12032.txt, span +2768, alignment +0),
    cross-checked against the complete stream section
    (function@L12032, corpus lines 27751-27933).

    [E:] THE SIGNATURE — zero parameters.
    [E:] THE LISTS — the kind-2 LIST builds edx=5 over the LIVE
        CONST[209]-[213] font URLs and CONST[214]-[218]
        filenames (pool-verified).
    [E:] THE SUBFOLDER — os.path.join over the getDataPath
        (CONST[194]) name-load + zero-arg call with CONST[219]
        'fonts'; os.makedirs with kwargs ('exist_ok'
        CONST[221]: True).
    [E:] THE LOOP — the zip (CONST[192] name-load) over the two
        lists, GetIter + the a9d60 iternext, the 2-unpack via
        GOT_004 (LAW 11).
    [E:] PER-ITERATION — os.path.join(fonts_folder, filename)
        -> font_path; os.path.exists with the LAW-8
        not-materialization <=> `if not os.path.exists(...)`.
    [E:] THE DOWNLOAD — urllib.request.urlopen(url, timeout=15)
        (the 'timeout' key with CONST[199] 15); the read BEFORE
        the with/open in address order => font_data is its own
        statement.
    [E:] THE WRITE — open(font_path, 'wb+') with the
        with-protocol over the file (LAW 10) ->
        f.write(font_data).
    [E:] THE TRY — BOTH the urlopen and the open failure paths
        route to the exc fetch (CONST[77] 'Exception'); the
        matched arm is EMPTY = `except Exception: pass`, then
        the loop continues; unmatched -> GOT_002.

    FLAG: the font_urls/fonts/fonts_folder/font_path/font_data
        locals are name-inferred.
    """
    font_urls = [
        'https://nighty.one/fonts/light249d0a057895c668.woff2',
        'https://nighty.one/fonts/45efa6936fdfb918.woff2',
        'https://nighty.one/fonts/ggsans-Normal.woff2',
        'https://nighty.one/fonts/ggsans-Semibold.woff2',
        'https://nighty.one/fonts/ggsans-Bold.woff2']
    fonts = ['light249d0a057895c668.woff2',
             '45efa6936fdfb918.woff2',
             'ggsans-Normal.woff2',
             'ggsans-Semibold.woff2',
             'ggsans-Bold.woff2']
    fonts_folder = os.path.join(getDataPath(), 'fonts')
    os.makedirs(fonts_folder, exist_ok=True)
    for url, filename in zip(font_urls, fonts):
        font_path = os.path.join(fonts_folder, filename)
        if not os.path.exists(font_path):
            try:
                font_data = urllib.request.urlopen(
                    url, timeout=15).read()
                with open(font_path, 'wb+') as f:
                    f.write(font_data)
            except Exception:
                pass


def checksounds():
    """Registry L12064. Content: chunk L12450 — recovered from the
    island bytes of chunk 12450 (dump file
    chunk12450_checksounds_12064.txt, span +3680, alignment +0),
    cross-checked against the complete stream section
    (function@L12064, corpus lines 27934-28132).

    [E:] THE SIGNATURE — zero parameters.
    [E:] THE LISTS — the kind-2 LIST builds edx=9 over the LIVE
        CONST[174]-[182] sound URLs and CONST[183]-[191]
        filenames (pool-verified; the URL tails and the local
        names genuinely differ).
    [E:] THE LOOP — the zip over the lists, GetIter + the
        a9d60 iternext, the GOT_004 2-unpack into the url /
        filename slots (LAW 11).
    [E:] THE GATE — the inline path f-string f'{getDataPath()}/
        sounds/{filename}' (the dynamic getDataPath piece +
        CONST[195] '/sounds/' + the filename piece, the
        ecx=3 finalize); os.path.exists with the LAW-8 NOT-SWAP
        (falsy -> materialize True) — `if not
        os.path.exists(f'{getDataPath()}/sounds/{filename}'):`.
    [E:] THE DOWNLOAD — urllib.request.urlopen(url, timeout=15)
        + the read into sound_data (its own statement, read
        before the open).
    [E:] THE WRITE — the path f-string REBUILT inline for the
        global open (CONST[201]) with 'wb+' (CONST[202]);
        the with-protocol (LAW 10) — f.write(sound_data).
    [E:] THE EXCEPT ARM — CONST[77] 'Exception'; the alias
        bound; the arm body: the print staged via a9d50
        (CONST[204] — the module SHADOWS print, cf. the
        registry print@L6640); the 6-piece a9d48 finalize
        (ecx=6): 'Error downloading sound ' (CONST[205]) + the
        filename + ' (' (CONST[206]) + the url + '): '
        (CONST[207]) + the alias — then the kwargs kind-3
        {'type_' (CONST[208]): 'ERROR' (CONST[67])} —
        print(f"Error downloading sound {filename} ({url}): "
        f"{e}", type_='ERROR'); unmatched -> GOT_002.

    FLAG: the sound_urls/sounds/url/filename/sound_data locals
        are name-inferred; the except alias 'e' is
        slot-inferred.
    """
    sound_urls = [
        'https://nighty.one/download/files/sounds/connected.mp3',
        'https://nighty.one/download/files/sounds/'
        'disconnected.wav',
        'https://nighty.one/download/files/sounds/'
        'giveaway_found.wav',
        'https://nighty.one/download/files/sounds/'
        'nitro_sniped.wav',
        'https://nighty.one/download/files/sounds/pinged.wav',
        'https://nighty.one/download/files/sounds/typing.wav',
        'https://nighty.one/download/files/sounds/'
        'relationship.mp3',
        'https://nighty.one/download/files/sounds/'
        'roleupdates.mp3',
        'https://nighty.one/download/files/sounds/'
        'nickupdates.mp3']
    sounds = ['connected.mp3',
              'disconnected.wav',
              'giveaways.wav',
              'nitro.wav',
              'pinged.wav',
              'typing.wav',
              'friends.mp3',
              'roles.mp3',
              'nicknames.mp3']
    for url, filename in zip(sound_urls, sounds):
        if not os.path.exists(
                f'{getDataPath()}/sounds/{filename}'):
            try:
                sound_data = urllib.request.urlopen(
                    url, timeout=15).read()
                with open(
                        f'{getDataPath()}/sounds/{filename}',
                        'wb+') as f:
                    f.write(sound_data)
            except Exception as e:
                print(f'Error downloading sound {filename} '
                      f'({url}): {e}', type_='ERROR')


def isConnectionError(error):
    """Registry L12450. Content: chunk L12598 — recovered from the
    island bytes of chunk 12598 (dump file
    chunk12598_isConnectionError_12450.txt, span +1072, alignment
    +0, 281 insns; the header comment '(find_discord_exe)' is the
    documented next-entry mislabel), cross-checked against the
    complete stream section (function@L12450, corpus lines
    28133-28191).

    [E:] THE SIGNATURE — the names-tuple CONST[167] ('error',)
        staged 0xa3f42 with the GOT_000 binder r8d=1 at
        0xa3f6e. PARAM error = the isinstance first operand.
    [E:] THE PROBE — 'isinstance' CONST[168] name-loaded via
        the a9d50 stage (staged 0xa3f92, stage-call 0xa3fae,
        cached [rsp+0x70]); the four exception-class chains,
        each requests (CONST[130]) + GetAttr 'exceptions'
        (CONST[169]) + GetAttr <class>, generation-locked in
        this order: ConnectionError (CONST[170] 0xa4054),
        Timeout (CONST[171] 0xa40fc), RetryError (CONST[172]
        0xa41a7), ChunkedEncodingError (CONST[173] 0xa4251).
    [E:] THE CALL — the classes 4-TUPLE built a9d18 kind-1
        edx=4 (r8=ConnectionError/r9=Timeout, frame
        RetryError+ChunkedEncodingError); the call args 2-tuple
        (the error param, the classes tuple); isinstance
        through the a9d20 cache with r8d=1.
    [E:] THE RETURN — the result rides rsi (LAW 14) -> the
        a9d28 ret-dispatch returning the isinstance bool; no
        try/except in this function.
    """
    return isinstance(
        error,
        (requests.exceptions.ConnectionError,
         requests.exceptions.Timeout,
         requests.exceptions.RetryError,
         requests.exceptions.ChunkedEncodingError))


def find_discord_exe(discord_path):
    """Registry L12598. Content: chunk L12604 — recovered from the
    island bytes of chunk 12604 (dump file
    chunk12604_find_discord_exe_12598.txt, span +1504, alignment
    +0, 364 insns; the header comment '(saveTokenToConfigCl)' is
    the next-entry mislabel), cross-checked against the complete
    stream section (function@L12598, corpus lines 28192-28249).

    [E:] THE SIGNATURE — the names-tuple CONST[161]
        ('discord_path',) staged 0xa437c with the GOT_000
        binder r8d=1 at 0xa43a8. PARAM = the os.walk arg.
    [E:] THE OUTER LOOP — os (CONST[34]) + GetAttr 'walk'
        (CONST[162]), the 1-tuple over the param; GetIter + the
        a9d60 iternext; the GOT_004 3-target unpack into
        root/dirs/files (LAW 11; FLAG: the canonical os.walk
        triple names).
    [E:] THE INNER LOOP — GetIter over files + the a9d60
        iternext binding the per-iteration file (FLAG: the
        name 'file' inferred).
    [E:] THE MATCH — GetAttr 'lower' (CONST[163]) over the file,
        zero-arg call, the a9d30 sel=2 vs CONST[164]
        'discord.exe' — `if file.lower() == 'discord.exe':`
        (the not-swap materialization pair).
    [E:] THE RETURN — os.path.join (CONST[165]/[166]) over the
        (root, file) 2-tuple -> return os.path.join(root,
        file); the no-match exhaustion returns the implicit
        None. No try/except.
    """
    for root, dirs, files in os.walk(discord_path):
        for file in files:
            if file.lower() == 'discord.exe':
                return os.path.join(root, file)


def saveTokenToConfigCl(token):
    """Registry L12604. Content: chunk L12625 — recovered from the
    island bytes of chunk 12625 (dump file
    chunk12625_saveTokenToConfigCl_12604.txt, span +3136,
    alignment +0, 804 insns; the header comment '(checkWebLogin)'
    is the documented next-entry mislabel — the body addresses
    are the authority), cross-checked against the complete stream
    section (function@L12604, corpus lines 28250-28421). A
    near-mirror of the SHIPPED saveTokenToConfig
    (add_account_window.py, registry L8263, sig ('self',
    'token')) — the one registry-visible DELTA is the signature:
    the Cl variant is a PLAIN ONE-ARG client helper, not the
    js_api method.

    [E:] THE SIGNATURE — the names-tuple CONST[129] ('token',)
        staged 0xa4968 with the GOT_000 binder r8d=1 at
        0xa4994.
    [E:] THE VERIFICATION GET — requests (CONST[130]) + GetAttr
        'get', the one-positional 'https://discord.com/api/v10/
        users/@me' CONST[131]; kwargs: headers (CONST[132]) —
        the kind-3 edx=3 dict: 'Authorization' (CONST[133])
        = the token param, 'Content-Type'
        ('application/json') and 'User-Agent' (CONST[135])
        against the LIVE client UA CONST[137] — plus verify=
        False and timeout=20 (CONST[140]).
    [E:] THE GATE — GetAttr 'status_code' (CONST[141]) vs
        CONST[142] 200 — `if r.status_code == 200:`.
    [E:] THE 200 ARM — r.json() -> data; data.get('username')
        (CONST[144]) -> username; getConfigData() (CONST[145])
        -> config; config['logins'] (CONST[146] GetItem) ->
        logins; the SetItem key rides the a9d48 one-piece wrap
        of the username; the entry dict kind-3: 'token'
        (CONST[147]) = str(token) (the 'str' CONST[150] chain),
        'date_added' (CONST[148]) = datetime.now().strftime(
        '%d %B %Y, at %H:%M:%S') (CONST[151]/[152]/[153]/
        [154]), 'active' (CONST[149]) = True; the SetItem
        logins[username] = {entry}; then config =
        getConfigData() AGAIN + config['logins'] = logins;
        saveConfigData(config) (CONST[155]); setActiveProfile(
        username) (CONST[156]); autoApp() (CONST[157], zero-arg
        — NO args builder).
    [E:] THE ELSE ARM — the 'evaluate_js' CONST[41] name-loaded
        as a module global, called one-positional over
        'location.reload();' CONST[158]; then the kind-3 edx=2
        dict {'status': 'error', 'text': 'Invalid token.'}
        (CONST[159]/[45]/[97]/[160]) RETURNED.
    [E:] Epilogue — `test bpl,bpl`: the return dict rides rsi
        (LAW 14); otherwise the implicit None.
    """
    r = requests.get(
        'https://discord.com/api/v10/users/@me',
        headers={
            'Authorization': token,
            'Content-Type': 'application/json',
            'User-Agent': (
                'Mozilla/5.0 (Windows NT 10.0; WOW64) '
                'AppleWebKit/537.36 (KHTML, like '
                'Gecko) discord/1.0.9001 '
                'Chrome/83.0.4103.122 '
                'Electron/9.3.5 Safari/537.36')},
        verify=False,
        timeout=20)
    if r.status_code == 200:
        data = r.json()
        username = data.get('username')
        config = getConfigData()
        logins = config['logins']
        logins[username] = {
            'token': str(token),
            'date_added': datetime.now().strftime(
                '%d %B %Y, at %H:%M:%S'),
            'active': True}
        config = getConfigData()
        config['logins'] = logins
        saveConfigData(config)
        setActiveProfile(username)
        autoApp()
    else:
        evaluate_js('location.reload();')
        return {'status': 'error', 'text': 'Invalid token.'}


def checkWebLogin():
    """Registry L12625. Content: chunk L12675 — recovered from the
    island bytes of chunk 12675 (dump file
    chunk12675_checkWebLogin_12625.txt, span +3616, alignment +1,
    908 insns), cross-checked against the complete stream
    section (function@L12625, corpus lines 28422-28563). The
    stale census that once deferred this span noted CONST[111]

    [E:] THE SIGNATURE — zero parameters: the frame stage + TWO
        PyCell_New (the [rsp+0xa0]/[rsp+0xa8] cells); NO GOT_000
        binder and no names-tuple const anywhere.
    [E:] THE WAIT — 'wait_for_selected_login' (CONST[106])
        + GetAttr 'wait', ZERO-ARG call —
        wait_for_selected_login.wait().
    [E:] THE GATE — the 'selected_option' CONST[108] staged
        via a9d50, the a9d30 sel=2 vs CONST[109] 'web_login' —
        `if selected_option == 'web_login':`; the falsy arm
        jumps the epilogue (implicit None).
    [E:] api + js — WebLoginApi (CONST[110]) staged, zero-arg
        CALL -> the api local (a PLAIN local, never a cell);
        CONST[111] (the 626-char URL-watcher JS) staged ->
        PyCell_Set into the [rsp+0xa8] cell — js_code = <the
        CONST[111] literal>.
    [E:] THE WINDOW — webview (CONST[81]) + create_window
        (CONST[112]); the title positional over CONST[113]
        'Login to Discord'; kwargs kind-3 edx=6: url=
        'https://discord.com/login' (CONST[115]), width=1075
        (CONST[117]), height=670 (CONST[119]), resizable=
        False, frameless=False, js_api=api; -> PyCell_Set into
        the [rsp+0xa0] cell.
    [E:] THE BIND — api.set_window(window) (CONST[39] GetAttr
        over the api local, the 1-tuple over the window cell
        fetch).
    [E:] CLOSURE #1 — the meta writes (slot1776 <- ctx,
        slot1777 <- the embedded body LOWGOT_a5f40, slot1778 <-
        3); the a9d58 factory with TWO freevar cells (window,
        js); the EMBEDDED BODY (read complete): the two cell
        fetches, PyCell_Get window, GetAttr 'evaluate_js'
        (CONST[41]), the 1-tuple over PyCell_Get(js cell), the
        call — `window.evaluate_js(js_code)`.
    [E:] CLOSURE #2 — the meta writes (slot1780-1782, the body
        LOWGOT_a6100); the a9d58 with NO freevars; the
        EMBEDDED BODY (read complete): os.execv +
        sys.executable + ['python'] + sys.argv —
        `os.execv(sys.executable, ['python'] + sys.argv)`.
    [E:] THE SUBSCRIPTIONS — window.events (CONST[126]) ->
        'closed' (CONST[127]): the a9d10 sel-0xE IN-PLACE +=
        with the addend closure #2 + the SetAttr store-back =
        window.events.closed += <closure 2>; then 'loaded'
        (CONST[128): the += with closure #1 = window.events.
        loaded += <closure 1>. No try in this function.

    FLAG: the nested-handler names (on_loaded / on_closed) and
        the outer locals (api, js_code, window) are
        name-inferred; the freevar structure (2 cells: window +
        js) and both bodies are byte-locked; the createApp
        precedent uses `on_loaded` for this exact family.
    """
    wait_for_selected_login.wait()
    if selected_option == 'web_login':
        api = WebLoginApi()
        js_code = ('\n                console.log(`injected`)\n'
                   '                var previousUrl = '
                   'window.location.href;\n'
                   '                function checkUrlChange() '
                   '{\n'
                   '                    var currentUrl = '
                   'window.location.href;\n'
                   '                    if (currentUrl !== '
                   'previousUrl) {\n'
                   '                        previousUrl = '
                   'currentUrl;\n'
                   '                        console.log(`URL '
                   'changed: ${currentUrl}`)\n'
                   '                        pywebview.api.'
                   'url_change_callback(currentUrl);\n'
                   '                    }\n'
                   '                    setTimeout('
                   'checkUrlChange, 1000); // Check every 1 '
                   'second\n'
                   '                }\n\n'
                   '                checkUrlChange();\n'
                   '                ')
        window = webview.create_window(
            'Login to Discord',
            url='https://discord.com/login',
            width=1075,
            height=670,
            resizable=False,
            frameless=False,
            js_api=api)
        api.set_window(window)

        def on_loaded():
            window.evaluate_js(js_code)

        def on_closed():
            os.execv(sys.executable, ['python'] + sys.argv)

        window.events.closed += on_closed
        window.events.loaded += on_loaded


def addFirewallRules(port, name):
    """Registry L12675. Content: chunk L12692 — recovered from the
    island bytes of chunk 12692 (dump file
    chunk12692_addFirewallRules_12675.txt, span +3328, alignment
    +0, 847 insns), cross-checked against the complete stream
    section (function@L12675, corpus lines 28564-28776).

    [E:] THE SIGNATURE — the names-tuple CONST[90] ('port',
        'name') staged 0xa63cc with the GOT_000 binder r8d=2 at
        0xa63f8.
    [E:] CHECK #1 — the 3-piece f-string CONST[91]
        "Get-NetFirewallRule -DisplayName '" + {name} +
        CONST[92] "' -ErrorAction SilentlyContinue";
        subprocess (CONST[93]) + run with the args LIST
        ['powershell', '-Command', <the f-string>] and kwargs
        capture_output=True/text=True; the .stdout GetAttr +
        'strip' + zero-arg call; the strip result rides the
        registers only -> INLINE if-condition.
    [E:] IF #1 — the not-swap (falsy -> materialize True);
        `test edi; jne 0xa67a3`.
    [E:] INBOUND CREATE — the 4-piece f-string CONST[100]
        "New-NetFirewallRule -DisplayName '" + {name} +
        CONST[101] "' -Direction Inbound -Action Allow
        -Protocol TCP -LocalPort " + {port}; subprocess.run
        with kwargs ('check': True); then logging.info over
        CONST[103] 'Inbound firewall rule added for port ' +
        {port}; the branch MERGES back into the shared second
        check.
    [E:] CHECK #2 — the SAME Get f-string rebuilt; the same
        run/stdout/strip/is-true plumbing.
    [E:] OUTBOUND CREATE — the 4-piece CONST[100] + {name} +
        CONST[104] "' -Direction Outbound -Action Allow
        -Protocol TCP -LocalPort " + {port}; run(check=True);
        logging.info over CONST[105] 'Outbound firewall rule
        added for port ' + {port}.
    [E:] Epilogue — `test bpl,bpl` (the error carrier, LAW 14):
        the ret-disp or the PyErr_Occurred/Clear + None ->
        implicit return None. No try/except.
    """
    if not subprocess.run(
            ['powershell', '-Command',
             f"Get-NetFirewallRule -DisplayName '{name}' "
             f"-ErrorAction SilentlyContinue"],
            capture_output=True, text=True).stdout.strip():
        subprocess.run(
            ['powershell', '-Command',
             f"New-NetFirewallRule -DisplayName '{name}' "
             f"-Direction Inbound -Action Allow -Protocol "
             f"TCP -LocalPort {port}"],
            check=True)
        logging.info(
            f'Inbound firewall rule added for port {port}')
    if not subprocess.run(
            ['powershell', '-Command',
             f"Get-NetFirewallRule -DisplayName '{name}' "
             f"-ErrorAction SilentlyContinue"],
            capture_output=True, text=True).stdout.strip():
        subprocess.run(
            ['powershell', '-Command',
             f"New-NetFirewallRule -DisplayName '{name}' "
             f"-Direction Outbound -Action Allow -Protocol "
             f"TCP -LocalPort {port}"],
            check=True)
        logging.info(
            f'Outbound firewall rule added for port {port}')


def startWebview():
    """Registry L12692. Content: chunk L12702 — recovered from the
    island bytes of chunk 12702 (dump file
    chunk12702_startWebview_12692.txt, span +1408, alignment +0,
    339 insns), cross-checked against the complete stream
    section (function@L12692, corpus lines 28777-28861).

    [E:] THE SIGNATURE — zero parameters.
    [E:] debug VALUE — the [rsp+0x78] slot init'd False
        (CONST[32]), then the a9d30 sel=6 ('in', LAW 5) with
        r8=CONST[78] '--cqbtools' against r9=sys.argv —
        '--cqbtools' in sys.argv; the SPP boolean
        materialization lands True on the truthy side; the
        value is consumed as the first kwargs pair —
        debug='--cqbtools' in sys.argv.
    [E:] THE CALL — webview (CONST[81]) + GetAttr 'start'
        (CONST[82]); kwargs kind-3 edx=5: debug, http_server=
        False, gui='edgechromium' (CONST[85]), private_mode=
        True, user_agent=the LIVE CONST[87]
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64)
        AppleWebKit/537.36 (KHTML, like Gecko)
        Chrome/91.0.4472.124 Safari/537.36' (CONST[88]); the
        call with r8d=0 (ZERO positional) r9d=1 (kwargs).
    [E:] THE EXCEPT — the exc fetch + CONST[77] 'Exception'
        match; the alias bound; the arm = logging.error over
        the 2-piece f-string 'WVE - ' (CONST[89]) + {alias};
        the exception swallowed; unmatched -> GOT_002 re-raise.

    FLAG: the alias 'e' is slot-inferred; the debug kwarg is
        inline (FLAG: inline-kwarg-vs-named-local not
        slot-resolvable; consumed only by this call's kwargs).
    """
    try:
        webview.start(
            debug='--cqbtools' in sys.argv,
            http_server=False,
            gui='edgechromium',
            private_mode=True,
            user_agent=('Mozilla/5.0 (Windows NT 10.0; '
                        'Win64; x64) AppleWebKit/537.36 '
                        '(KHTML, like Gecko) '
                        'Chrome/91.0.4472.124 '
                        'Safari/537.36'))
    except Exception as e:
        logging.error(f'WVE - {e}')


def startFlaskServer():
    """Registry L12702. Content: chunk L12730 — recovered from the
    island bytes of chunk 12730 (dump file
    chunk12730_startFlaskServer_12702.txt, span +5328,
    alignment +0, 1294 insns), cross-checked against the
    complete stream section (function@L12702, corpus lines
    28862-29144).

    [E:] THE SIGNATURE — zero parameters.
    [E:] BANNER — logging (CONST[44]) + 'info' (CONST[51) over
        the 4-piece f-string: CONST[52] (the LIVE 35-char
        banner, the U+1F310 globe) + the dynamic
        `getWebConfigData().get('host') or 'localhost'` (the
        not-swap fallback CONST[55]) + ':' (CONST[56]) + the
        dynamic `getWebConfigData().get('port') or 80`
        (CONST[57]/[58]).
    [E:] THE TRY — the outer try starts at the ssl statement:
        ssl = getWebConfigData().get('ssl') (stashed
        [rsp+0x98]); host = ...get('host') or '0.0.0.0'
        (CONST[60]); port = ...get('port') or (443 if ssl
        else 80) (CONST[61] 443 / CONST[58] 80; the or-ternary
        evaluation order is address-locked).
    [E:] INNER BARE EXCEPT — addFirewallRules (CONST[62]) over
        (port, f'NightyWeb/{port}') (the 2-piece build over
        CONST[63]); its failure routes to an inline exc path
        with NO match const staged (law 9) -> `except: pass`
        around exactly this call.
    [E:] WERKZEUG — logging.getLogger('werkzeug')
        (CONST[64]/[65]) .setLevel(logging.ERROR)
        (CONST[66]/[67]).
    [E:] THE IF — the fresh getWebConfigData().get('ssl')
        test; falsy arm: socketio.run(web_app) with the 5-pair
        kwargs (host, port, debug=False, use_reloader=False,
        allow_unsafe_werkzeug=True); truthy arm: RE-REBIND the
        ssl local via GetItem — ssl = getWebConfigData()[
        'ssl'] (the same FAST slot = the same name) — then the
        6-pair kwargs add ssl_context=(ssl.get('cert'),
        ssl.get('private_key')) (CONST[73]/[74], the 2-tuple
        build).
    [E:] OUTER EXCEPT ARM — the exc fetch + CONST[77]
        'Exception' match; the alias bound ([rsp+0xb8]);
        logging.error over the PLAIN alias 1-tuple (NO
        f-string, no message const) — logging.error(e);
        unmatched -> GOT_002 + the ret-disp.

    FLAG: the ssl/host/port local names are inferred from the
        slots/usage; the alias 'e' is slot-inferred.
    """
    logging.info(
        f'🌐 Browser API available at: http://'
        f"{getWebConfigData().get('host') or 'localhost'}:"
        f"{getWebConfigData().get('port') or 80}")
    try:
        ssl = getWebConfigData().get('ssl')
        host = getWebConfigData().get('host') or '0.0.0.0'
        port = getWebConfigData().get('port') or \
            (443 if ssl else 80)
        try:
            addFirewallRules(port, f'NightyWeb/{port}')
        except:
            pass
        logging.getLogger('werkzeug').setLevel(logging.ERROR)
        if getWebConfigData().get('ssl'):
            ssl = getWebConfigData()['ssl']
            socketio.run(
                web_app, host=host, port=port, debug=False,
                ssl_context=(ssl.get('cert'),
                             ssl.get('private_key')),
                use_reloader=False,
                allow_unsafe_werkzeug=True)
        else:
            socketio.run(
                web_app, host=host, port=port, debug=False,
                use_reloader=False,
                allow_unsafe_werkzeug=True)
    except Exception as e:
        logging.error(e)


def handle_uncaught_exception(loop, context):
    """Registry L12730. Content: chunk L12759 — recovered from the
    island bytes of chunk 12759 (dump file
    chunk12759_handle_uncaught_exception_12730.txt, span
    0xa8af0 +1216, alignment +1), cross-checked against the
    complete stream section (function@L12730, corpus lines
    29145-29206).

    [E:] THE SIGNATURE — the names-tuple CONST[43] ('loop',
        'context') staged 0xa8b07, the GOT_000 binder r8d=2 at
        0xa8b33. PARAMS: loop ([rsp+0x68]), context
        ([rsp+0x70]).
    [E:] logging.error over the f-string CONST[46] 'Uncaught
        exception: ' + {context.get('message')} (the GetAttr
        'get' + the 1-tuple over CONST[48] 'message'; the
        2-piece finalize).
    [E:] THE STASHED TEMP — context.get('exception') (the 1-
        tuple over CONST[49]) -> [rsp+0x78] — a named temp
        reused by BOTH the truth test and the f-string piece
        (FLAG: the temp name 'exception' inferred); the plain
        IsTrue gate (no a9d40 family -> no try).
    [E:] TRUE BRANCH — the fresh logging.error stage + the
        f-string #2: the literal CONST[50] 'asyncio: ' + the
        dynamic piece from the temp — logging.error(f'asyncio:
        {exception}').
    [E:] Epilogue — the DecRefs, PyErr_Occurred/Py Err_Clear,
        CONST[30] None, the a9d28 ret-dispatch = the implicit
        return None. No re-raise, no with.
    """
    logging.error(
        f"Uncaught exception: {context.get('message')}")
    exception = context.get('exception')
    if exception:
        logging.error(f'asyncio: {exception}')


def on_load():
    """Registry L12759. Content: chunk L12763 — recovered from the
    island bytes of chunk 12763 (dump file
    chunk12763_on_load_12759.txt, span 0xa8fb0 +560, alignment
    +0), cross-checked against the complete stream section
    (function@L12759, corpus lines 29207-29241).

    [E:] THE SIGNATURE — zero parameters: the 0xa8f70-0xa8fa2
        prologue (visible in the chunk12759 island tail)
        contains no GOT_000 binder and no names-tuple const,
        and none appears in the body (the no-binder = 0-arg
        law).
    [E:] CALL 1 — main_api (CONST[38]) + GetAttr 'set_window'
        (CONST[39]), the 1-tuple over the global main_ui
        (CONST[40]) — main_api.set_window(main_ui).
    [E:] CALL 2 — main_ui (CONST[40]) + GetAttr 'evaluate_js'
        (CONST[41), the 1-tuple over CONST[42]
        'document.documentElement.style.zoom = 0;' —
        main_ui.evaluate_js('document.documentElement.style.
        zoom = 0;') (LIVE-verified, the 46-char JS, plain
        string).
    [E:] No exc-fetch family -> no try/with; the standard
        epilogue = the implicit return None.
    """
    main_api.set_window(main_ui)
    main_ui.evaluate_js(
        'document.documentElement.style.zoom = 0;')


def on_closed():
    """Registry L12763. Registry tail — the corpus section has NO
    content chunk (the '<registry tail>' marker); recovered from
    the executor bytes that FOLLOW the last trailer span end
    0xa91e0: the prologue 0xa91a0-0xa91e0 (visible at the tail
    of the chunk12763 island), the body 0xa91e2-0xa9395,
    disassembled in place with the same GOT/CONST annotation
    resolver; chunk 12763 was verified byte-identical (SHA-256)
    to the on_load island (key 12763 IS on_load's content
    chunk, so this function's evidence comes from the tail
    disasm).

    [E:] THE SIGNATURE — zero parameters: the prologue carries
        no GOT_000 binder and no names-tuple; none in the body
        (the no-binder = 0-arg law).
    [E:] THE CHAIN — os (CONST[34] 0xa91eb) + GetAttr 'kill'
        (CONST[35] 0xa921d); os staged again + GetAttr 'getpid'
        (CONST[36] 0xa9295), ZERO-ARG call — os.getpid();
        SIGTERM (CONST[37] 0xa92e9) staged via a9d50 as a BARE
        global name (no preceding module stage+GetAttr ->
        module-level `from signal import SIGTERM`, FLAG:
        import-form inferred); the args 2-tuple (the getpid
        result, SIGTERM); the call — os.kill(os.getpid(),
        SIGTERM).
    [E:] Epilogue — the result test/DecRef, PyErr_Occurred /
        PyErr_Clear, CONST[30] None, the a9d28 ret-dispatch =
        the implicit return None; the next function prologue
        would begin at 0xa93a0.
    """
    os.kill(os.getpid(), SIGTERM)
