"""
snipe_cache.py — Nighty's snipe-cache cleanup routine from the SPP
native core.

Registry L1428: content chunk labeled L1510 (span shouldSkipMimic,
7840B). The 60s throttle + two-tier sweep (age-based deletion, then a
total-size budget pass) is evidenced element-by-element; the fine
dataflow of the budget pass is partially reconstructed — every
uncertain joint is flagged in the docstring.
"""

import logging
import os
import time


def cleanupSnipeCache(remove_paths):
    """Registry L1428. Content: chunk labeled L1510.

    [E:] signature tuple ('remove_paths',).
    [E:] getDataPath() + '/snipes' staged up front (events 7-9).

    Phase 1 — direct removals (events 13-45):
    [E:] GetIter over remove_paths; os.path.isfile; os.remove;
         'Exception' with PyErr machinery (try/except).

    Phase 2 — 60s throttle (events 48-107):
    [E:] time.time(); bot.config .get; consts '_snipe_last_sweep',
         int 0, int 60 (the sweep interval, exact); IsTrue comparison;
         then a REAL try (PyErr_Fetch) around
         bot.config['_snipe_last_sweep'] = time.time() (SetItem).
    [E:] the handler stages logging + GetAttr('error') + the exact
         message prefix 'cleanupSnipeCache: ' (event 102).

    Phase 3 — sweep (events 127-280):
    [E:] os.path.isdir(...); now = time.time() (None + int 0 consts
         nearby are stream machinery).
    [E:] os.walk + nested GetIter (root/dirs/files) + os.path.join +
         os.stat + st_mtime with an 'Exception' guard (events 153-191).
    [E:] age pass: now - st.st_mtime vs SNIPE_CACHE_MAX_AGE ->
         os.remove (second 'remove' GetAttr, events 225-226) with its
         own 'Exception' (event 229).
    [E:] candidates: 'append' with st_mtime + st_size staged
         (events 206-223).
    [E:] budget pass: SNIPE_CACHE_MAX_TOTAL (events 244, 263);
         list sort with the 'key' kwarg (the lambda's varnames tuple
         ('x',) is in the const stream); GetIter over the sorted
         candidates; a per-item IsTrue against SNIPE_CACHE_MAX_TOTAL;
         a third os.remove (events 269-272) inside an 'Exception'
         guard.

    Flagged as reconstructed (elements proven, dataflow not):
      the candidates tuple layout ((path, mtime, size) assumed), the
      sort key's exact index, the total accumulator arithmetic, and
      the exact nesting of the per-item budget condition.
    """
    try:
        for path in remove_paths:
            if os.path.isfile(path):
                os.remove(path)
    except Exception:
        pass
    if time.time() - bot.config.get('_snipe_last_sweep', 0) < 60:
        return
    try:
        bot.config['_snipe_last_sweep'] = time.time()
    except Exception as e:
        logging.error('cleanupSnipeCache: ' + str(e))
    if os.path.isdir(getDataPath() + '/snipes'):
        now = time.time()
        candidates = []
        for root, dirs, files in os.walk(getDataPath() + '/snipes'):
            for name in files:
                path = os.path.join(root, name)
                try:
                    st = os.stat(path)
                except Exception:
                    continue
                if now - st.st_mtime > SNIPE_CACHE_MAX_AGE:
                    try:
                        os.remove(path)
                    except Exception:
                        pass
                candidates.append((path, st.st_mtime, st.st_size))
        candidates.sort(key=lambda x: x[1])
        total = sum(size for _, _, size in candidates)
        if total > SNIPE_CACHE_MAX_TOTAL:
            for path, _, size in candidates:
                if total <= SNIPE_CACHE_MAX_TOTAL:
                    break
                try:
                    os.remove(path)
                    total -= size
                except Exception:
                    pass
