"""
app_authorize_api.py — the applications-REST API class (registry
L5597-L5734), recovered via the Ghidra decomp lane with the raw
decomp files as primary evidence.

  class ApplicationsApi  (NAME FLAG: the class name is NOT
      recovered — see the attribution note below)
    __init__()                    — the websocket/wss/cookie/
                                    header session ctor
                                    (registry L5597, the TWIN
                                    of GuildsApi in
                                    api_client.py)
    get_apps()                    — GET applications?
                                    with_team_applications=false
    create(name)                   — POST applications
                                    {'name', 'team_id': None}
    upload_asset(app_id, name, image) — POST .../assets
                                    {'name','image','type':'1'}
                                    + the CDN url stamp
    get_bot_token(app_id)          — the /bot/reset + MFA
                                    lifecycle
    get_asset(app_id, name)        — the v10 assets name-lookup
    get_assets(app_id)             — the v9 assets list + the
                                    CDN url enrichment
    delete_asset(app_id, asset_id) — the v9 DELETE (204)
    close()                        — session.close()

Every request is gated by
    self.session.headers.update(
        {'Authorization': getCurrentToken()})

ATTRIBUTION note (evidence-locked): this family formerly carried
the class name 'AppAuthorizeApi' (const slot 575) — CORRECTED:
that const's live users are verifyDevPortalPass@L8723 /
verifyDevPortalMfa@L8776 (stream lines 24328-24332 / 24715-
24719), not these bodies. This applications family's class name
stays OPEN; the GuildsApi twin + the guild creator create@L5590
moved to api_client.py.
"""

import random

from tls_client import TLSSession

APP_VERIFICATION_MFA_URL = \
    'https://nighty.one/download/files/ui/app_verification_mfa.html'
APP_VERIFICATION_PASS_URL = \
    'https://nighty.one/download/files/ui/app_verification_pass.html'


class ApplicationsApi:
    """The Discord applications REST client."""

    def __init__(self):
        """Registry L5597 (the applications-REST class ctor — the
        TWIN). Content: chunk labeled L5619 (raw
        spp_span_get_apps_5619.c, read end-to-end). Signature
        ('self',) [E:]-flagged (no further argument slots surface
        in the raw).

        [E:] self.session = TLSSession(client_identifier='chrome'
             + str(random.randint(110, 115)),
             random_tls_extension_order=True) — raw L60-126: the
             TLSSession global (GOT_1106) + the (3,2) kwargs
             build over 'client_identifier' (GOT_1107) +
             'random_tls_extension_order' (GOT_1113) + True —
             the value built by concats over 'chrome' (GOT_1108)
             + random.randint (GOT_1109/1110) with the int
             consts 110 (GOT_1111) and 115 (GOT_1112) + the
             str-convert chain (raw L112-115); SetAttr raw L126.
        [E:] the Cloudflare cookie warm —
             self.session.cookies = self.session.get(
             'https://discord.com').cookies (raw L130-208: the
             session receiver re-GetAttr'd raw L130-148, the
             'get' GetAttr over it + the 'https://discord.com'
             const (GOT_1114), the 1-arg call raw L194, the
             'cookies' GetAttr on the RESULT (GOT_1115, raw
             L195-203), SetAttr(<session>, 'cookies', <result>)
             raw L208).
        [E:] self.session.headers = { ... } — the receiver
             re-GetAttr'd raw L211-231 + the (3,0x10) 16-key
             build over raw L234-355 with every key/value pair
             staged in order (authority GOT_1116 / 'discord.com'
             GOT_938; accept GOT_1117 / '*/*' GOT_1118;
             accept-language GOT_1119 / 'en-GB,en;q=0.5'
             GOT_1120; content-type GOT_1121 /
             'application/json' GOT_136; origin GOT_1122 /
             'https://discord.com' GOT_1114; referer GOT_1123 /
             'https://discord.com/' GOT_1124; sec-ch-ua GOT_1125
             / '"Not?A_Brand";v="8", "Chromium";v="108"' GOT_
             1126 — the live dump's literal; sec-ch-ua-mobile
             GOT_1127 / '?0' GOT_1128; sec-ch-ua-platform GOT_
             1129 / '"Windows"' GOT_1130; sec-fetch-dest GOT_
             1131 / 'empty' GOT_1132; sec-fetch-mode GOT_1133 /
             'cors' GOT_1134; sec-fetch-site GOT_1135 /
             'same-origin' GOT_1136; user-agent GOT_476 / the
             full Discord-desktop UA GOT_1137; x-debug-options
             GOT_1138 / 'bugReporterEnabled' GOT_1139;
             x-discord-timezone GOT_1140 / 'Europe/Prague' GOT_
             1141; x-super-properties GOT_477 / GOT_1142 — the
             full 592-char const, recovered complete from the
             marshal stream); SetAttr(<session>, 'headers',
             <the dict>) raw L357; silent None tail.
        """
        self.session = TLSSession(
            client_identifier='chrome' +
                              str(random.randint(110, 115)),
            random_tls_extension_order=True)
        self.session.cookies = \
            self.session.get('https://discord.com').cookies
        self.session.headers = {
            'authority': 'discord.com',
            'accept': '*/*',
            'accept-language': 'en-GB,en;q=0.5',
            'content-type': 'application/json',
            'origin': 'https://discord.com',
            'referer': 'https://discord.com/',
            'sec-ch-ua':
                '"Not?A_Brand";v="8", "Chromium";v="108"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': ('Mozilla/5.0 (Windows NT 10.0; WOW64) '
                           'AppleWebKit/537.36 (KHTML, like '
                           'Gecko) discord/1.0.9016 '
                           'Chrome/108.0.5359.215 '
                           'Electron/22.3.12 Safari/537.36'),
            'x-debug-options': 'bugReporterEnabled',
            'x-discord-timezone': 'Europe/Prague',
            'x-super-properties': (
                'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxl'
                'YXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDE2'
                'Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDUiLCJvc19hcmNoIjoieDY0Iiwic3lz'
                'dGVtX2xvY2FsZSI6InN2IiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81'
                'LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAo'
                'S0hUTUwsIGxpa2UgR2Vja28pIGRpc2NvcmQvMS4wLjkwMTYgQ2hyb21lLzEwOC4w'
                'LjUzNTkuMjE1IEVsZWN0cm9uLzIyLjMuMTIgU2FmYXJpLzUzNy4zNiIsImJyb3dz'
                'ZXJfdmVyc2lvbiI6IjIyLjMuMTIiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoyMTg2'
                'MDQsIm5hdGl2ZV9idWlsZF9udW1iZXIiOjM1MjM2LCJjbGllbnRfZXZlbnRfc291'
                'cmNlIjpudWxsfQ=='
            ),
        }

    def get_apps(self):
        """Registry L5619. Content: chunk labeled L5624 (raw
        spp_span_create_5624.c).

        [E:] single-argument frame (self only; in_stack 0x58 =
             self, raw L32-53). The same Authorization gate (raw
             L57-101).
        [E:] return self.session.get(<GOT_1105>).json() — the
             .get GetAttr (GOT_047, raw L122-129), the URL const
             resolved by the a9d48 1-piece format (raw L132-139),
             the 1-arg call raw L141; GOT_1105 = the full live
             const 'https://discord.com/api/v9/applications?
             with_team_applications=false'; response.json() raw
             L150-171; the parsed payload returned directly (raw
             L181-182), the None-fallback raw L184-187.
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        return self.session.get(
            'https://discord.com/api/v9/applications'
            '?with_team_applications=false').json()

    def create(self, name):
        """Registry L5624 (the application creator). Content:
        chunk labeled L5630 (raw
        spp_span_add_icon_to_app_5630.c).

        [E:] argument frame: the 2-arg frame (self + name;
             in_stack 0x58 = self, in_stack 0x60 = name, paired
             to the 'name' GOT_273 dict key at raw L142-149).
        [E:] the Authorization gate (raw L30-96: session GOT_
             561, headers GOT_132, update GOT_562, Authorization
             GOT_133, getCurrentToken GOT_563, update-call raw
             L93).
        [E:] return self.session.post('https://discord.com/api/
             v9/applications', json={'name': name, 'team_id':
             None}).json() — the post GetAttr (GOT_564, raw
             L119-127); the URL GOT_1103 via the a9d48 1-piece
             format (raw L129-136); the (3,2) dict build over
             'name'/name-param and 'team_id' (GOT_1104) = None
             (GOT_030, raw L150-157); the (3,1) json-kwarg wrap
             (raw L158) + the post call (1 positional, 1 kwarg,
             raw L160); response.json() raw L162-190 + the direct
             return (the parsed payload).
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        return self.session.post(
            'https://discord.com/api/v9/applications',
            json={'name': name, 'team_id': None}).json()

    def add_icon_to_app(self, app_id, name, icon_data):
        """Registry L5630. Content: chunk labeled L5654 —
        recovered from the interior bytes of chunk 5654 (dump
        file chunk5654_add_icon_to_app_L5630.txt; the 'file
        merged/absent' verdict was a boundary artifact — the
        chunk decodes at alignment +0, 70 events). Signature
        ('self', 'app_id', 'name', 'icon_data') [E:] —
        const-pool tuple slot 1097 (LIVE).

        [E:] the Authorization gate identical to the family:
             session (GOT_561) -> headers (GOT_132) -> update
             (GOT_562) with the kind-3 pair dict
             'Authorization' (GOT_133) = getCurrentToken()
             (GOT_563, zero-arg call 0x4dc0d).
        [E:] self.session.patch (GOT_1093) to
             'https://discord.com/api/v9/applications/' (GOT_
             572) + str(app_id) — the a9d48 str-convert on the
             app_id slot (0x4dd50) + the 2-piece join (0x4dd5d)
             + the (1,1) args pack.
        [E:] the payload: SUBGOT_a9d18 kind-3 with count 8 at
             0x4df37 — eight key/value pairs staged across the
             register window: 'description' (GOT_249) = ''
             (GOT_241), 'icon' (GOT_959) = icon_data, 'name'
             (GOT_273) = name, 'interactions_endpoint_url' (GOT_
             1098) = None, 'privacy_policy_url' (GOT_1099) =
             None, 'role_connections_verification_url' (GOT_
             1100) = None, 'tags' (GOT_1101) = [] (the (2,0)
             empty-list build 0x4dea1), 'terms_of_service_url'
             (GOT_1102) = None.
        [E:] the call: json=<payload> — the kind-3 count-1 kwarg
             pair with 'json' (GOT_143, 0x4df4e-0x4df63); the
             patch call with a9d20 r8=1 (1 positional url) r9=1
             (kwargs, 0x4df94); response.json() 0x4dfd9-0x4e037
             + the direct return (None on null).
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        response = self.session.patch(
            'https://discord.com/api/v9/applications/'
            + str(app_id),
            json={
                'description': '',
                'icon': icon_data,
                'interactions_endpoint_url': None,
                'name': name,
                'privacy_policy_url': None,
                'role_connections_verification_url': None,
                'tags': [],
                'terms_of_service_url': None,
            })
        return response.json()

    def upload_asset(self, app_id, name, image):
        """Registry L5691. Content: chunk labeled L5698 (stream
        section function@L5691).

        PARTIALLY RECONSTRUCTED — the request shape and the CDN
        stamp are fully evidenced; the returned payload (data vs
        None) and the app_id argument position are flagged (the
        raw pass is pending).

        [E:] the Authorization gate (stream L35-107: session
             GOT_561, headers GOT_132, update GOT_562,
             Authorization GOT_133, getCurrentToken GOT_563).
        [E:] self.session.post('https://discord.com/api/v9/
             oauth2/applications' + <app_id> + '/assets',
             json={'name': name, 'image': image, 'type': '1'})
             — the post GetAttr (GOT_564, L130-136); the base URL
             GOT_1080 + the a9d48 concat chain (L140-147) +
             '/assets' (GOT_1084, L152-153); the json dict (3,3):
             'name' GOT_273, 'image' GOT_379, 'type' GOT_248
             with the EXACT string value '1' (GOT_788, L162-181);
             response.json() (L191-209).
        [E:] the CDN stamp: data['url'] =
             'https://cdn.discordapp.com/app-assets/' (GOT_1085)
             + '/' (GOT_813) + <app_id> + data['id'] (GetItem
             GOT_265, L251-268) + '.png' (GOT_1086) — the a9d48
             concat chain L235-273 + PyObject_SetItem (GOT_022,
             L283) storing under 'url' (GOT_114).
        [E:] flag: the tail cluster (L307-316) matches the
             family return shape; translated as returning the
             stamped data.
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        response = self.session.post(
            'https://discord.com/api/v9/oauth2/applications/'
            + str(app_id) + '/assets',
            json={'name': name, 'image': image, 'type': '1'})
        data = response.json()
        data['url'] = ('https://cdn.discordapp.com/app-assets/'
                       + str(app_id) + '/' + data['id'] + '.png')
        return data

    def get_bot_token(self, app_id):
        """Registry L5654 (the bot-token reset + MFA lifecycle).
        Content: chunk labeled L5691 (raw
        spp_span_upload_asset_5691.c, read end-to-end). ONE
        parameter beside self (the app id feeds both the URL
        concat and the str()-stored record).

        [E:] the Authorization gate (raw L48-109: session GOT_
             561, headers GOT_132, update GOT_562, Authorization
             GOT_133, getCurrentToken GOT_563).
        [E:] response = self.session.post('https://discord.com/
             api/v9/applications/' (GOT_572) + <the app-id param
             staged raw L150-154> + '/bot/reset' (GOT_573)) —
             the 3-piece a9d48 join raw L111-163.
        [E:] the 401 gate IS the MFA-required branch:
             response.status_code (GOT_141) vs int 401 (GOT_610)
             via a9d30 selector-2 (raw L162-204) — on equality:
             data = response.json(); ticket = data['mfa']
             ['ticket'] (GOT_1090 + GOT_566, raw L208-273); then
             the app record: getConfigData() → config['logins']
             [getActiveProfileName()]['app'] = {} (the (3,0)
             build + SetItem, raw L277-342) → ['app']['id'] =
             str(<the app-id param>) (GOT_150/265, raw L383-413)
             → ['app']['token'] = <the ticket> (GOT_147, raw
             L466-474) → saveConfigData (GOT_155, raw L478-496).
        [E:] the method dispatch: data['mfa']['methods'][0]
             ['type'] (GOT_530 'methods' + GOT_277 int-0 + GOT_
             248 'type') == 'totp' (GOT_569, raw L498-561) →
             main_ui.load_url(url='https://nighty.one/download/
             files/ui/app_verification_mfa.html' GOT_1091) (raw
             L569-600); else the same chain == 'password' (GOT_
             409, raw L602-663) → main_ui.load_url(url=
             'https://nighty.one/download/files/ui/
             app_verification_pass.html' GOT_1092) (raw L668-
             693); both exits merge silent (flag: the
             non-matching method falls to the early exit,
             LAB_0004fdc0 raw L695-697).
        [E:] the normal branch (status != 401): bot_token =
             response.json()['token'] (raw L699-720 — the slot
             initialized None at the head becomes the token); the
             SAME app-record write-back with ['token'] =
             bot_token (raw L724-930) + saveConfigData (raw
             L934-952).
        [E:] the re-validation cascade: a fresh getConfigData()
             → config['logins'][getActiveProfileName()]['app']
             .get('id') (GOT_047/265, raw L953-1021) and, if
             truthy, the same record's .get('token') (raw L1025-
             1092) — both gates required (the falsy exits run
             silent, raw L1092-1100).
        [E:] the validity verdict + launch:
             is_discord_bot_token_valid(<the app token>) (GOT_
             614, raw L1097 + the args build); the stream tail
             (events 1097-1293) evidences the invalid branch:
             logging.error('App token not valid') (GOT_044/045/
             716) + requestAppToken() (GOT_672), and the valid
             branch: bot.run(token=getCurrentToken(),
             reconnect=True) (GOT_244 bot + GOT_069 run + GOT_
             147 token + GOT_563 getCurrentToken + GOT_616
             reconnect + True GOT_031). Flag: the verdict's arg
             wiring (the record token read vs the local) is
             const-staged in the final raw lines.
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        response = self.session.post(
            'https://discord.com/api/v9/applications/'
            + str(app_id) + '/bot/reset')
        config = getConfigData()
        if response.status_code == 401:
            data = response.json()
            ticket = data['mfa']['ticket']
            config['logins'][getActiveProfileName()]['app'] = {}
            config['logins'][getActiveProfileName()]['app'] \
                ['id'] = str(app_id)
            config['logins'][getActiveProfileName()]['app'] \
                ['token'] = ticket
            saveConfigData(config)
            if data['mfa']['methods'][0]['type'] == 'totp':
                main_ui.load_url(url=APP_VERIFICATION_MFA_URL)
            elif data['mfa']['methods'][0]['type'] == 'password':
                main_ui.load_url(url=APP_VERIFICATION_PASS_URL)
            return None
        bot_token = response.json()['token']
        config['logins'][getActiveProfileName()]['app'] = {}
        config['logins'][getActiveProfileName()]['app']['id'] = \
            str(app_id)
        config['logins'][getActiveProfileName()]['app'] \
            ['token'] = bot_token
        saveConfigData(config)
        if not (getConfigData()['logins'][getActiveProfileName()]
                ['app'].get('id')
                and getConfigData()['logins'][
                    getActiveProfileName()]['app'].get('token')):
            return None
        if not is_discord_bot_token_valid(
                getConfigData()['logins'][getActiveProfileName()]
                ['app']['token']):
            logging.error('App token not valid')
            requestAppToken()
            return None
        bot.run(token=getCurrentToken(), reconnect=True)

    def get_asset(self, app_id, name):
        """Registry L5698 (the v10 assets name-lookup). Content:
        chunk labeled L5710 (raw spp_span_get_assets_5710.c —
        the off-by-one span carries this body). TWO formal
        parameters beside self — the (…,1,2) frame: the app id
        (in_stack 0x70) and the sought name (in_stack 0x78).

        [E:] the Authorization gate (raw L42-107: session GOT_
             561, headers GOT_132, update GOT_562, Authorization
             GOT_133, getCurrentToken GOT_563).
        [E:] response = self.session.get('https://discord.com/
             api/v10/oauth2/applications/' (GOT_1088, the exact
             v10 const) + <the app-id param staged raw L150-153>
             + '/assets' (GOT_1084)) — the 3-piece a9d48 join raw
             L110-161.
        [E:] data = response.json() (raw L163-196); then the
             match loop (GetIter + a9d60, raw L197-204) wrapped
             in the DAT_000a9d40 exception machinery (raw
             L248-273 with the selector-10 isinstance probe +
             the GOT_002 re-raise): per asset — `if str(<the name
             param>) == asset['name']:` (the str() call raw
             L210-226 over the second parameter + the 'name'
             GetItem raw L227-243 + the a9d30 selector-2 compare
             raw L247 + the IsTrue gates raw L274-288) →
             `return asset['id']` (the 'id' GetItem raw L290-308).
        [E:] flag: the no-match fall-out returns None (the
             standard silent-exit cluster at the raw tail).
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        response = self.session.get(
            'https://discord.com/api/v10/oauth2/applications/'
            + str(app_id) + '/assets')
        data = response.json()
        for asset in data:
            if str(name) == asset['name']:
                return asset['id']
        return None

    def get_assets(self, app_id):
        """Registry L5710 (the v9 assets LIST fetch with the CDN
        url enrichment). Content: chunk labeled L5718 (raw
        spp_span_delete_asset_5718.c, read end-to-end).
        Signature [E:]: the (param,1,2) frame = TWO formals
        beside the implicit — self (in_stack 0x68) + the app id
        (in_stack 0x70, str-coerced for both concats at raw
        L147/L238).

        [E:] the gate — self.session.headers.update(
             {'Authorization': getCurrentToken()}) (raw L36-99:
             the (3,1) 1-key dict + the (1,1) args + the update
             call).
        [E:] data = self.session.get('https://discord.com/api/
             v9/oauth2/applications/' (GOT_1080 — EXACT, note
             the V9, vs get_asset's v10 GOT_1088) + str(app_id)
             + '/assets' (GOT_1084)) — the 3-piece a9d48 join raw
             L136-152 + the GET call raw L153; then
             <response>.json() (GOT_143, raw L154-184, the 0-arg
             call raw L184).
        [E:] the enrichment loop (GetIter + a9d60, raw L188-194):
             per asset — asset['url'] = 'https://cdn.discordapp.
             com/app-assets/' (GOT_1085) + str(app_id) + '/'
             (GOT_813) + str(asset['id']) (the GetItem GOT_265 +
             the str-convert raw L266) + '.png' (GOT_1086) — the
             FIVE-piece a9d48 join raw L270 + the SetItem raw
             L277 (the 'url' key GOT_114 staged raw L217).
        [E:] the fall-out returns the enriched data (the
             iterator-empty path hands the data slot to the exit,
             raw L200-206/L286-306).
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        data = self.session.get(
            'https://discord.com/api/v9/oauth2/applications/'
            + str(app_id) + '/assets').json()
        for asset in data:
            asset['url'] = ('https://cdn.discordapp.com/'
                            'app-assets/'
                            + str(app_id) + '/'
                            + str(asset['id']) + '.png')
        return data

    def delete_asset(self, app_id, asset_id):
        """Registry L5718. Content: chunk labeled L5734 (raw
        spp_span_close_5734.c, read end-to-end). Signature [E:]:
        the (param_1,1,2) frame = TWO formals beside self (the
        locked idiom): self (in_stack 0x58) + app_id (0x60) +
        asset_id (0x68), both ids str-coerced into the 4-piece
        join.

        [E:] the gate — the identical Authorization update (raw
             L26-94).
        [E:] response = self.session.delete('https://discord.com/
             api/v9/oauth2/applications/' (GOT_1080, the v9
             const) + str(app_id) (raw L142) + '/assets/' (GOT_
             1081 — the trailing-slash variant of GOT_1084, the
             required slash per the 4-piece join semantics) +
             str(asset_id) (raw L152)) — the FOUR-piece a9d48
             join raw L153 + the .delete call (GOT_1079) raw
             L155.
        [E:] `return response.status_code == 204` — status_code
             (GOT_141) vs int 204 (GOT_1082!) via the a9d30
             selector-2 compare (raw L189-198) + the inverted
             const-select pair (raw L198-218) producing the bool.
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        response = self.session.delete(
            'https://discord.com/api/v9/oauth2/applications/'
            + str(app_id) + '/assets/' + str(asset_id))
        return response.status_code == 204

    def close(self):
        """Registry L5734. Content: chunk labeled L5759 (raw
        spp_span__drpcReplaceValue_5759.c head, read
        end-to-end). Signature ('self',) [E:] (the only touched
        frame slot is the receiver).

        [E:] self.session.close() — the session reload (GOT_561,
             raw L26-41) + 'close' (GOT_603) GetAttr + the 0-ARG
             call (raw L45-56); silent None tail (raw L57-74).
        """
        self.session.close()
