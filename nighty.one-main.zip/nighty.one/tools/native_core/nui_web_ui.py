"""
nui_web_ui.py — the NUI webview-UI manager class from the SPP
native core (registry L9370-L9397), recovered from the island
bytes of chunks 9389/9397/9424, cross-checked against the
complete stream sections.

  __init__(self, webview, ui_code) — the mangled-privates ctor
  update(self)  — reset the tabs, restore the original UI, reload
  reload(self)  — the tabs-free reload variant

CLASS NAME: LIVE — the SetAttr mangling consts ('_NUI__tabs',
'_NUI__original_ui', '_NUI__ui_code') pin the class name NUI and
the source spellings of the privates (__tabs, __original_ui,
__ui_code).
"""

import logging  # noqa: F401


class NUI:

    def __init__(self, webview, ui_code):
        """Registry L9370. Content: chunk L9389 — recovered from the
        island bytes of chunk 9389 (@0x8f190 +704), cross-checked
        against the complete stream section (function@L9370, corpus
        lines 25243-25268 / 30 events).

        [E:] THE SIGNATURE — the names-tuple with the GOT_000
            binder (r8d=3): ('self', 'webview', 'ui_code').
        [E:] THE SETATTRS — in order: the MANGLED '_NUI__tabs' =
            a fresh empty list (SUBGOT_a9d18 ecx=2, edx=0),
            '_NUI__original_ui' and '_NUI__ui_code' (mangled
            consts) against the ui_code param, plus the
            NON-mangled '_webview' against the webview param —
            the mangling locks the class name NUI and the
            private spellings (self.__tabs / __original_ui /
            __ui_code + the plain self._webview).

        FLAG: the parameter names webview/ui_code are inferred
            from the SetAttr values (the names-tuple residue is
            censored; the mangled attribute names are the live
            evidence).
        """
        self.__tabs = []
        self._webview = webview
        self.__original_ui = ui_code
        self.__ui_code = ui_code

    def update(self):
        """Registry L9389. Content: chunk L9397 — recovered from the
        island bytes of chunk 9397 (@0x8f450 +1328), cross-checked
        against the complete stream section (function@L9389,
        corpus lines 25269-25332 / 59 events).

        [E:] THE SIGNATURE — the names-tuple ('self',) with the
            GOT_000 binder (r8d=1).
        [E:] THE RESET — SetAttr '_NUI__tabs' = a fresh empty
            list (a9d18 ecx=2, edx=0), then SetAttr '_NUI__ui_code'
            = the LoadStore of GetAttr '_NUI__original_ui'.
        [E:] THE RELOAD — self._webview.load_url(...) over the
            a9d48 build f'{SERVER_TO_USE}/v2/beta?{
            str(encryptRSA(getLicense()))}' — SERVER_TO_USE,
            encryptRSA, getLicense are a9d50 name-loads; the
            str() conversion is a pre-built f-string piece.
        """
        self.__tabs = []
        self.__ui_code = self.__original_ui
        self._webview.load_url(
            f'{SERVER_TO_USE}'
            f'/v2/beta?key={str(encryptRSA(getLicense()))}')

    def reload(self):
        """Registry L9397. Content: chunk L9424 — recovered from the
        island bytes of chunk 9424 (@0x8f980, 53 events); the
        stream section (function@L9397, corpus lines 25333-25334)
        is a merged region (decomp file absent), so the island
        carries the whole decode.

        [E:] THE SIGNATURE — the names-tuple ('self',) with the
            GOT_000 binder (r8d=1).
        [E:] THE DELTA vs update@L9389 — the identical SetAttr
            ('_NUI__ui_code' = GetAttr '_NUI__original_ui') +
            the load_url over the same
            f'{SERVER_TO_USE}/v2/beta?key={
            str(encryptRSA(getLicense()))}' machinery (a9d48
            build, a9d20 1-arg call); the '_NUI__tabs' reset
            arm is ABSENT — no list build and no '_NUI__tabs'
            const anywhere in the island.
        """
        self.__ui_code = self.__original_ui
        self._webview.load_url(
            f'{SERVER_TO_USE}'
            f'/v2/beta?key={str(encryptRSA(getLicense()))}')
