"""
app_login_window.py — the AppCreateApi window controller from the
SPP native core (registry L8089-L8130), recovered from the corpus
event streams plus island dumps. The class NAME is live: the
createApp booter stages 'AppCreateApi' (CONST[718) as the
webview.create_window js_api — the pywebview bridge object for
the OAuth app-creation window.

  __init__(self)               — self._window = None
  set_window(self, window)     — the wrapper binding
  hide(self)                   — hide + the bot reconnect boot
  close(self)                  — destroy
  discordLogin(self)           — the token/appid JS injection
  url_change_callback_app(self, url) — the authorized-page
      sniffer (hides on fire)
  url_change_callback_app_connect(self, url) — the closing twin

RE-SNATCH LANDED: the twins above ship with their 573/574-byte
CONST[709]/[708] snippets embedded live; disconnect@L7417,
createApp@L8035 and the entire 16-const queue recovered; the
autoApp@L8057 island pass (1415 insns) completes in the sweep.
"""

import logging  # noqa: F401  (module family import parity)


class AppCreateApi:

    def __init__(self):
        """Registry L8089. Content: chunk L8092 — recovered from the
        island bytes of chunk 8092 (dump file chunk8092_init_L8089.txt,
        per the dumper +2 align, 17 events, 89 insns, read complete
        through the set_window prologue), cross-checked against the
        complete stream section (function@L8089, corpus lines
        21536-21551, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x7af14 with the GOT_000 binder (r8d=1) at
            0x7af40.
        [E:] THE BODY — the single SetAttr: '_window' CONST[620]
            staged 0x7af5a with the None CONST[30] staged 0x7af68,
            the SetAttr dispatch storing over the [rsp+0x58] self —
            `self._window = None`; the second None materialization
            (0x7afd2) is the implicit return carried through the
            ret-disp (a9d28) at 0x7b00a. This is the byte-mirror of
            WebWindow.__init__@L7397 (web_window.py) — the family
            emission law reused with the AppCreateApi anchors;
            corpus events 18-58.
        """
        self._window = None

    def set_window(self, window):
        """Registry L8092. Content: chunk L8095 — recovered from the
        island bytes of chunk 8095 (dump file
        chunk8095_set_window_L8092.txt, per the dumper +0 align, 14
        events, 93 insns, read complete), cross-checked against the
        complete stream section (function@L8092, corpus lines
        21552-21564, read complete).

        [E:] THE SIGNATURE — the WebWindow-family mirror signature
            ('self', 'window') with the GOT_000 binder (r8d=2); the
            '_window' CONST[620] SetAttr over the second binder
            target — `self._window = window` (the
            set_window@L7400 emission law); corpus events 20-54.
        """
        self._window = window

    def hide(self):
        """Registry L8095. Content: chunk L8099 — recovered from the
        island bytes of chunk 8099 (dump file chunk8099_hide_L8095.txt,
        per the dumper +0 align, 37 events, 195 insns, read complete),
        cross-checked against the complete stream section
        (function@L8095, corpus lines 21565-21608, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x7b1cb with the GOT_000 binder (r8d=1) at
            0x7b1f7.
        [E:] THE HIDE — GetAttr(self [rsp+0x58], '_window'
            CONST[620] staged 0x7b218, resolved 0x7b22c) then GetAttr
            over 'hide' CONST[648] staged 0x7b25d (resolved 0x7b276),
            the zero-argument call at 0x7b2a8 — self._window.hide()
            (the hide@L7403 emission law); corpus events 25-63.
        [E:] THE RECONNECT BOOT — bot.run(token=..., reconnect=True):
            the 'bot' CONST[244] global load 0x7b2c4-0x7b2e0, the
            'run' CONST[69] GetAttr resolved 0x7b30f; the kwargs
            dict built kind-3 count-2 (a9d18 ecx=3, edx=2 at
            0x7b3b9-0x7b3c9) with the first pair in r8/r9 — 'token'
            CONST[147] staged 0x7b335 against the getCurrentToken
            CONST[563] global (loaded 0x7b34a-0x7b366, called
            zero-arg at 0x7b390) — and the second pair staged through
            the frame ([rsp+0x20] = 'reconnect' CONST[616] staged
            0x7b393, [rsp+0x28] = True CONST[31] staged 0x7b3a1);
            the call at 0x7b3e8 with r8d = 0 AND r9d = 1 — the
            zero-positional, kwargs-present CALL-FORM law —
            `bot.run(token=getCurrentToken(), reconnect=True)`;
            corpus events 64-106.
        """
        self._window.hide()
        bot.run(token=getCurrentToken(), reconnect=True)

    def close(self):
        """Registry L8099. Content: chunk L8102 — recovered from the
        island bytes of chunk 8102 (dump file chunk8102_close_L8099.txt,
        per the dumper +3 align, 18 events, 109 insns, read complete),
        cross-checked against the complete stream section
        (function@L8099, corpus lines 21610-21630, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x7b4a5 with the GOT_000 binder (r8d=1) at
            0x7b4d1.
        [E:] THE BODY — GetAttr(self, '_window' CONST[620] staged
            0x7b4f2) then GetAttr over 'destroy' CONST[646] staged
            0x7b537, the zero-argument call — self._window.destroy()
            (the close@L7406 emission law) with the implicit None
            return (CONST[30] staged 0x7b5b2) through the ret-disp
            (a9d28) at 0x7b5ce; corpus events 19-70.
        """
        self._window.destroy()

    def discordLogin(self):
        """Registry L8102. Content: chunk L8112 — recovered from the
        island bytes of chunk 8112 (dump file
        chunk8112_discordLogin_L8102.txt, per the dumper +0 align,
        46 events, 271 insns, read complete through the
        url_change_callback_app prologue at 0x7ba20), cross-checked
        against the complete stream section (function@L8102, corpus
        lines 21631-21684, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x7b653 with the GOT_000 binder (r8d=1) at
            0x7b67f.
        [E:] THE SIDE-EFFECT FETCH — getConfigData() called bare:
            the global (CONST[145]) loaded 0x7b694-0x7b6b0, called
            zero-arg at 0x7b6d9, the result stored [rsp+0x70]
            (0x7b6e7) and released at 0x7b9a6 WITHOUT ever being
            read — a bare statement in the source (its config-cache
            authoritative side effect precedes the login injection);
            FLAG: why the author forced the fetch here is not
            visible in the emission — the call/store/release chain
            is exactly a discarded expression; corpus events
            30-40.
        [E:] THE VALUES — getCurrentToken() (CONST[563] loaded
            0x7b703-0x7b71f, called 0x7b748, stored [rsp+0x78]) and
            getCurrentAppId() (CONST[559] loaded 0x7b76f-0x7b78b,
            called 0x7b7b4, stored [rsp+0x80]) — both zero-arg;
            corpus events 51-75.
        [E:] THE WINDOW CHAIN — GetAttr(self [rsp+0x68], '_window'
            CONST[620], 0x7b809) then GetAttr(window,
            'evaluate_js' CONST[41] staged 0x7b83a, resolved
            0x7b853) bound at [rsp+0x48]; corpus events 86-113.
        [E:] THE SEVEN-PIECE F-STRING — the a9d48 builder final law
            locked here: the dynamic pieces pre-build through the
            r8d = -1 sub-calls (builder-A over the [rsp+0x80] appid
            0x7b8a1-0x7b8bb, builder-B over the [rsp+0x78] token
            0x7b8d6-0x7b8ed, builder-C over the appid again
            0x7b907-0x7b921 — the appid fetched ONCE and used
            twice, the CSE-visibility of the second
            getCurrentAppId() piece), then the finalize at
            0x7b945-0x7b953: a9d48(ecx = 7, rdx = CONST[710]
            literal, r8 = builder-A, r9 = CONST[711], and the
            frame slots [rsp+0x20..0x38] = builder-B, CONST[712],
            builder-C, CONST[713]) — the seven pieces in exact
            source order:
            [710-lit][appid][711-lit][token][712-lit][appid]
            [713-lit], kind-1 wrapped (0x7b956-0x7b960) and passed
            one-positional to the evaluate_js call at 0x7b984.
            The literals are live-quoted (710/711/712/713); the
            JS braces double-escape in the f-string source.
            corpus events 117-149.
        """
        getConfigData()
        self._window.evaluate_js(
            f'\n    if (window.location.href !== '
            f'"https://discord.com/oauth2/authorize?client_id='
            f'{getCurrentAppId()}") {{\n'
            f'        document.body.appendChild('
            f'document.createElement `iframe`).contentWindow'
            f'.localStorage.token = `"{getCurrentToken()}"`\n'
            f'        window.location.href = '
            f'"https://discord.com/oauth2/authorize?client_id='
            f'{getCurrentAppId()}";\n    }}')

    def url_change_callback_app(self, url):
        """Registry L8112. Content: chunk L8130 — recovered from the
        island bytes of chunk 8130 (dump file
        chunk8130_url_change_callback_app_L8112.txt, per the dumper
        +0 align, 29 events, 155 insns, read complete), cross-checked
        against the complete stream section (function@L8112, corpus
        lines 21686-21714, read complete). The create-window's
        authorized-page handler: on the OAuth success URL re-seed
        the login shim then hide the window.

        [E:] THE SIGNATURE — the names-tuple CONST[622] ('self',
            'url') staged 0x7ba71 with the GOT_000 binder (r8d=2)
            at 0x7ba9d.
        [E:] THE GATE — the a9d30 sel-2 equality over the url
            against the live CONST[707]
            'https://discord.com/oauth2/authorized' staged through
            the 0x7babf-0x7bad8 window — `if url == '...'` — the
            falsy side materializes the False const and exits the
            implicit return; corpus events 37-59.
        [E:] THE BODY — GetAttr(self, '_window' CONST[620] staged
            0x7bb43/0x7bb62) then GetAttr over 'evaluate_js'
            CONST[41] staged 0x7bb88, the kind-1 wrap over the full
            573-byte CONST[709] staged 0x7bbc7 — LIVE post
            re-snatch: the login(token) re-injection loop with the
            50ms iframe-localStorage shim, the 2500ms
            location.reload, the login('PASTE TOKEN HERE') seed and
            the 2000ms pywebview.api.hide() dismissal — the
            one-positional call (corpus events 100-122) with the
            implicit None return staged 0x7bc36 through the
            ret-disp at 0x7bc61; corpus events 62-122.
        """
        if url == 'https://discord.com/oauth2/authorized':
            self._window.evaluate_js(
                '\n                \n'
                '                function login(token) {\n'
                '                    setInterval(() => {\n'
                '                        document.body.appendChild'
                '(document.createElement `iframe`).contentWindow'
                '.localStorage.token = `"${token}"`\n'
                '                    }, 50);\n'
                '                    setTimeout(() => {\n'
                '                        location.reload();\n'
                '                    }, 2500);\n'
                '                }\n\n'
                "                login('PASTE TOKEN HERE')\n"
                '                setTimeout(function() {\n'
                '                    pywebview.api.hide();\n'
                '                }, 2000);\n'
                '                ')

    def url_change_callback_app_connect(self, url):
        """Registry L8130. Content: chunk L8151 — recovered from the
        island bytes of chunk 8151 (dump file
        chunk8151_url_change_callback_app_connect_L8130.txt, per the
        dumper +0 align, 30 events, 157 insns, read complete),
        cross-checked against the complete stream section
        (function@L8130, corpus lines 21715-21745, read complete).
        The connect twin: identical gate and shim, but the dismissal
        closes the window instead of hiding it.

        [E:] THE SIGNATURE — the names-tuple CONST[622] ('self',
            'url') staged 0x7bcd1 with the GOT_000 binder (r8d=2)
            at 0x7bcfd.
        [E:] THE GATE — the a9d30 sel-2 equality over the url
            against CONST[707] staged 0x7bd1f (r9) — the falsy
            False-materialization at 0x7bd59 exiting the implicit
            return; corpus events 26-56.
        [E:] THE BODY — GetAttr(self, '_window' CONST[620] staged
            0x7bda3/0x7bdc2) then GetAttr over 'evaluate_js'
            CONST[41] staged 0x7bde8, the kind-1 wrap over the
            full 574-byte CONST[708] staged 0x7be27 — LIVE post
            re-snatch, the same shim ending in the 2000ms
            pywebview.api.close() dismissal — the one-positional
            call with the implicit None return staged 0x7be96
            through the ret-disp at 0x7bec1; corpus events
            59-132.
        """
        if url == 'https://discord.com/oauth2/authorized':
            self._window.evaluate_js(
                '\n                \n'
                '                function login(token) {\n'
                '                    setInterval(() => {\n'
                '                        document.body.appendChild'
                '(document.createElement `iframe`).contentWindow'
                '.localStorage.token = `"${token}"`\n'
                '                    }, 50);\n'
                '                    setTimeout(() => {\n'
                '                        location.reload();\n'
                '                    }, 2500);\n'
                '                }\n\n'
                "                login('PASTE TOKEN HERE')\n"
                '                setTimeout(function() {\n'
                '                    pywebview.api.close();\n'
                '                }, 2000);\n'
                '                ')
