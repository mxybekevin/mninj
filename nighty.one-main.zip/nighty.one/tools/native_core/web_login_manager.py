"""
web_login_manager.py — the webview login + js_api binding family
(registry L8823-L9370), recovered via the Ghidra decomp lane.

The family binds custom Python functions onto a live js_api
instance (add_custom_function — the MethodType/setattr idiom),
launches the Login-to-Discord webview (WebLoginApi as the
js_api, the URL-change-watcher injection), serves the local
login page, and guards Flask route registration
(endpoint_exists / safe_add_individual_route).

The injection JS (the URL-change watcher) exists in the pool as
paired snippet halves: slots 544+545 (addWebAccount's copy)
plus the GOT_576/GOT_580 copies used by the dev-portal verify
pair.
"""

import webview

from types import MethodType

import logging  # noqa: F401
import uuid  # noqa: F401

from flask import jsonify, request  # noqa: F401


def add_custom_function(self, func):
    """Registry L8829 (add_custom_function — the js_api method
    binder). Content: chunk labeled L8833 (raw
    spp_span_getAvailableLoginOptions_8833.c, read end-to-end).
    Signature ('self', 'func') [E:]-flagged: the frame prologue
    is lost to decomp noise (raw L24-27) but the MethodType
    argument pairing evidences the two-param shape, and the
    addWebviewFunction wrapper calls it with ONE positional
    argument (main_api as the bound receiver).

    [E:] MethodType (GOT_555) loaded raw L30-41 + the (1,2)
         args build with the func slot pushed first (raw
         L43-50) → MethodType(func, self); the result stored
         (raw L54-58).
    [E:] setattr (GOT_556) loaded raw L59-67 + the (1,3) args
         build: self, func.__name__ (the GOT_509 GetAttr raw
         L75-92), <the MethodType result> (raw L95-98) →
         setattr(self, func.__name__, MethodType(func, self))
         raw L100; the success path returns None silently
         (raw L101-116).
    """
    setattr(self, func.__name__, MethodType(func, self))


def getAvailableLoginOptions():
    """Registry L8833 (getAvailableLoginOptions). Content: chunk
    labeled L8836 (stream section function@L8833). Zero arg.

    [E:] the a9d18 list build over 'token_login' (GOT_553) +
         'web_login' (GOT_109) + the return dispatch (events
         24-36).
    """
    return ['token_login', 'web_login']


def chooseLogin(self, login):
    """Registry L8836 (chooseLogin). Content: chunk labeled
    L8869 (stream section function@L8836). Signature
    ('self', 'login') [E:] — const-pool tuple slot 552 (LIVE).

    [E:] the gate: the a9d30 compare vs 'web_login' (GOT_109,
         events 25-46) — `if login == 'web_login':`.
    [E:] flag (partial): the branch body (events 49-94: the
         'selected_option' token (GOT_108) + the
         wait_for_selected_login global (GOT_106) + the set()
         global (GOT_384)) is register-held — the exact
         statements are unresolved; translated as the evidenced
         machinery skeleton with the branch flagged pending a
         raw pass. Silent None tail (events 115).
    """
    if login == 'web_login':
        pass  # FLAG: the selected_option / wait_for_selected
        # _login / set() machinery (events 49-94) is
        # register-held — pending the raw pass


def addWebAccount():
    """Registry L8869 (addWebAccount — the Login-to-Discord
    webview launcher). Content: chunk labeled L8931 (stream
    section function@L8869). Zero-argument (the section opens on
    the WebLoginApi staging with no argument frames).

    [E:] the closure cells (PyCell_New GOT_013, events 48-53)
         + the WebLoginApi class (GOT_110) staged events 58-65.
    [E:] the injection JS assembled: '\nconsole.log(`injected`)
         ...checkUrlChange...' (GOT_544) + '\');...setTimeout(
         checkUrlChange, 1000);...' (GOT_545) — the two halves
         concatenated (the a9d48 joins, events 76-96) and wired
         into a cell (PyCell_Set, event 96).
    [E:] window = webview.create_window (webview GOT_081 +
         create_window GOT_112, events 98-116) with
         title='Login to Discord' (GOT_113), url='https://
         discord.com/login' (GOT_115), width=1075 (GOT_117),
         height=670 (GOT_119), resizable=False, frameless=
         False, js_api=<the WebLoginApi build via cells>
         (events 120-198).
    [E:] window.events.closed = <closure GOT_1796> (the
         'events' (GOT_126) + 'closed' (GOT_127) GetAttrs +
         SetAttr, events 214-308) and window.events.loaded =
         <closure GOT_1800> (the 'loaded' GOT_128 + SetAttr,
         events 221-387) — the closure slots are unlabeled
         (built via the DAT_000a9d58 machinery, events 204/
         221); silent None tail (events 403-412). NOTE: no
         webview.start() is evidenced inside this body.
    """
    window = webview.create_window(
        title='Login to Discord',
        url='https://discord.com/login',
        width=1075,
        height=670,
        resizable=False,
        frameless=False,
        js_api=WebLoginApi())
    window.events.closed = None  # FLAG: closure (GOT_1796,
    # built via DAT_000a9d58) — the URL-watcher injection pair
    # GOT_544/545 feeds this closure
    window.events.loaded = None  # FLAG: closure (GOT_1800)


def serve_login_page():
    """Registry L8931 (serve_login_page — the local login page
    Flask response). Content: chunk labeled L9284 (stream
    section function@L8931). Zero-argument evidenced; the page
    payload is register-held.

    [E:] Response (GOT_540) staged events 28-32 + the args
         build (event 35) + the kwargs dict build (event 40):
         content_type='text/html' (GOT_541/542, events 41-45) →
         return Response(<the login page html — the payload
         const is register-held, flagged>, content_type=
         'text/html') (events 28-54).
    """
    return Response(
        LOGIN_PAGE_HTML,  # FLAG: payload register-held
        content_type='text/html')


def endpoint_exists(endpoint):
    """Registry L9284 (endpoint_exists — the Flask duplicate-
    route guard). Content: chunk labeled L9292 (stream section
    function@L9284). Signature (endpoint,) [E:]-flagged (the
    compare operand is the single parameter).

    [E:] web_app (GOT_070) + url_map (GOT_536) + iter_rules
         (GOT_537) + the GetIter loop (events 29-66); per rule:
         rule.rule (GOT_538 GetAttr) compared (a9d30) against
         the parameter — the any-generator shape with the
         True/False exits (events 93-150); returns a bool.
    """
    return any(rule.rule == endpoint
               for rule in web_app.url_map.iter_rules())


def addWebviewFunction(func):
    """Registry L9292 (addWebviewFunction — the js_api
    registration wrapper). Content: chunk labeled L9295
    (stream section function@L9292). ONE parameter (the function
    object — see add_custom_function's signature note).

    [E:] main_api (GOT_038) + add_custom_function (GOT_534)
         GetAttr + the args build over the parameter (event 42)
         → main_api.add_custom_function(func) (events 20-51);
         silent None tail.
    """
    main_api.add_custom_function(func)


def safe_add_individual_route(func):
    """Registry L9295. Content: chunk L9370 — recovered from the
    island bytes of chunk 9370 (dump file
    chunk9370_safe_add_individual_route_9295.txt, @0x8e3d0
    +3520, alignment +0, 173 events, 899 insns, read complete),
    cross-checked against the stream section (function@L9295).
    The nested handler's code object lives in the TRAILING
    ZONE — decoded from the raw disasm (dump file
    raw_disasm_out.txt; the same raw-address technique that
    decoded the 0x9e530 sort-lambda).

    [E:] THE SIGNATURE — the names-tuple CONST[507] ('func',)
        staged 0x8e3ec with the GOT_000 binder (r8d=1) at
        0x8e418; the parameter rides [rsp+0x58] for the whole
        body.
    [E:] THE ROUTE — the a9d48 two-piece join over
        CONST[508] '/api/custom/' (staged 0x8e42d) + the -1
        format of func.__name__ (CONST[509] GetAttr 0x8e465,
        the format 0x8e4a7, the join 0x8e4b8) —
        route = f'/api/custom/{func.__name__}' ([rsp+0x60]).
    [E:] THE GUARD — the 'endpoint_exists' CONST[510]
        name-load (staged 0x8e4e0) with the (route,) 1-tuple
        build + call 0x8e550 and PyObject_IsTrue 0x8e561; the
        TRUTHY arm walks the logging chain ('logging'
        CONST[44] staged 0x8e60c, 'info' CONST[51] staged
        0x8e63e) over the two-piece a9d48 join of CONST[511]
        staged 0x8e684 ('\u26a0\ufe0f  Route already exists: ') +
        the -1 format of the route (join 0x8e6c2, call
        0x8e6f1) and returns CONST[32] False (staged 0x8e710,
        ebp=0) — `return False`; the FALSY arm falls through
        to the factory make + the registration.
    [E:] THE FACTORY DEF — the a9d58 closure make 0x8e5bb
        (r8d=-1, NO freevars; meta slots 1792/1793/1794; the
        code ptr LOWGOT_8ecd0); the factory body: the
        names-tuple CONST[512] ('func_to_handle',) staged
        0x8ed2b with the GOT_000 binder at 0x8ed57, PyCell_New
        0x8ed6d over the parameter (the handler closes over
        the CELL); the handler closure make 0x8ee03 (meta
        slots 1788/1789/1790; the code ptr LOWGOT_a93a0 = the
        trailing-zone body) with ONE freevar (r8d=1, the
        func_to_handle cell).
    [E:] THE RENAME — inside the factory: the SetAttr over
        '__name__' (CONST[509] staged 0x8ee37) with the
        four-piece a9d48 join: CONST[523] 'handler_' (staged
        0x8ee4c) + the -1 format of func_to_handle.__name__
        (PyCell_Get 0x8ee70, the GetAttr 0x8ee93 — [rsp+0x70])
        + CONST[304] '_' (staged 0x8ef02) + the -1 format of
        the uuid slice; the uuid walk: 'uuid' CONST[524]
        staged 0x8ef24, GetAttr 'uuid4' CONST[525] staged
        0x8ef59, the ZERO-ARG call 0x8efa9, GetAttr 'hex'
        CONST[526] staged 0x8efaf; the CONST[26] slice-maker
        with CONST[527] 8 (staged 0x8efea-0x8f007) = the
        one-sided slice(None, 8) + the PyObject_GetItem
        0x8f022; the join 0x8f064; the SetAttr 0x8f083 —
        handler.__name__ = the f-string over the four pieces;
        then the factory RETURNS [rsp+0x60] (rax→rsi 0x8f0b4,
        bpl=0) — an explicit `return handler`.
    [E:] THE CALL — the (func,) 1-tuple build 0x8e749 + the
        factory call 0x8e773; the handler product lands
        [rsp+0x70] (a stored fastlocal).
    [E:] THE ENDPOINT NAME — the mirror four-piece join:
        CONST[528] 'custom_' staged 0x8e79a + the -1 format
        of func.__name__ ('__name__' GetAttr 0x8e7cc —
        [rsp+0x88]) + CONST[304] '_' staged 0x8e81d + the -1
        format of the SECOND uuid slice ('uuid' 0x8e842 /
        'uuid4' GetAttr 0x8e88f, the ZERO-ARG call 0x8e8c4 /
        'hex' GetAttr 0x8e8e3 / the CONST[26]+CONST[527] slice
        0x8e902-0x8e91f / GetItem 0x8e93a) — the endpoint
        f-string product lands [rsp+0x78] (join 0x8e984).
    [E:] THE REGISTRATION — the 'web_app' CONST[70] name-load
        (staged 0x8e9ac) + the 'route' CONST[529] GetAttr
        (staged 0x8e9de, call 0x8e9f7) — the decorator head;
        the (route,) 1-tuple 0x8ea34; the (2,2) methods list
        over CONST[530] 'methods' staged 0x8ea40 +
        CONST[531] 'POST' staged 0x8ea58 + CONST[514]
        'OPTIONS' staged 0x8ea67 (build 0x8ea80); the (3,2)
        kwargs dict over CONST[532] 'endpoint' staged 0x8ea82
        (build 0x8eab6); the call 0x8ead4 (r8d=1 positional +
        r9d=1 kwargs) — then the (handler,) 1-tuple build
        0x8eaf8 over the [rsp+0x70] fastlocal + the decorator
        invocation 0x8eb18 + DecRef 0x8eb27 — the
        web_app.route(...)(handler) pattern.
    [E:] THE SUCCESS LOG + RETURN — the logging walk
        ('logging' staged 0x8eb34, 'info' staged 0x8eb66) over
        the two-piece join of CONST[533] staged 0x8ebac
        ('\u2705 Added individual route: ') + the -1 format
        of the route (join 0x8ebea, call 0x8ec19); then the
        return arm stages CONST[31] True at 0x8ec34 → rsi
        (ebp=0) — `return True`; the epilogue DecRefs the
        FIVE fastlocals ([rsp+0x58]/[0x60]/[0x68]/[0x70]/
        [0x78] — the func/route/factory/handler/endpoint
        frame) at 0x8ec44-0x8ec75.

    [E:] THE HANDLER BODY (the trailing zone @0xa93a0, past
        the last registry span — the raw-disasm record): the
        OPTIONS preflight gate over the bare-name 'request'
        load + 'method' CONST[513] vs 'OPTIONS' CONST[514] —
        `if request.method == 'OPTIONS': return jsonify()`
        (the ZERO-ARG jsonify return — the Flask CORS
        preflight); the guarded body: the get_json walk
        ('get_json' CONST[516], kwargs {'silent' CONST[517]:
        True}) with the or-fallback onto the empty (3,0) dict
        — data = request.get_json(silent=True) or {}; the
        .get('args', []) over CONST[518] with the empty
        (2,0) list default; the .get('kwargs', {}) over
        CONST[519] with the (3,0) dict default; the call onto
        the PyCell'd func_to_handle (the GOT_009 freevar
        fetch) with the kind-9 flatten + the kind-3 restage —
        result = func_to_handle(*args, **kwargs); the success
        return = the call over 'jsonify' CONST[515] with the
        (3,2) dict: ('success' CONST[520]: True, 'result'
        CONST[521]: the result); the except arm — the a9d30
        sel-0xa match over 'Exception' with the alias bind,
        then the return of the (1,2) tuple over the second
        jsonify call (dict: 'success': False, 'error':
        str(e)) + CONST[522] 500 — the matched arm RETURNS
        (no re-raise; the unmatched arm escapes through
        GOT_002).

    FLAG: the [rsp+0x68] factory + [rsp+0x70] handler locals
        are name-inferred (the frame slots); the except alias
        e is slot-inferred; the handler's zero-arg signature
        carries no names-tuple.
    """
    route = f'/api/custom/{func.__name__}'
    if endpoint_exists(route):
        logging.info(f'\u26a0\ufe0f  Route already exists: {route}')
        return False

    def factory(func_to_handle):
        def handler():
            if request.method == 'OPTIONS':
                return jsonify()
            try:
                data = request.get_json(silent=True) or {}
                args = data.get('args', [])
                kwargs = data.get('kwargs', {})
                result = func_to_handle(*args, **kwargs)
                return jsonify({'success': True,
                                'result': result})
            except Exception as e:
                return jsonify({'success': False,
                                'error': str(e)}), 500

        handler.__name__ = f"handler_{func_to_handle.__name__}_{uuid.uuid4().hex[:8]}"
        return handler

    handler = factory(func)
    web_app.route(route, methods=['POST', 'OPTIONS'],
                  endpoint=f"custom_{func.__name__}_{uuid.uuid4().hex[:8]}")(handler)
    logging.info(f'\u2705 Added individual route: {route}')
    return True
