"""
browser_login_window.py — the embedded webview login window and
profile-viewer page controller from the SPP native core
(registry L6015-L6101), recovered via the corpus event streams
plus the lane-1 Ghidra raws (per the span law, a raw named after
the next function carries the previous function's body):

  spp_span___init___6026.c          -> body of getAppData
  spp_span_set_window_6030.c        -> body of __init__
  spp_span_hide_6033.c             -> body of set_window
  spp_span_discordLogin_6036.c      -> body of hide
  spp_span_url_callback_change_6046.c -> body of discordLogin
  spp_span_restoreFirstFriend_6050.c  -> body of url_callback_change
  spp_span_get_embed_6075.c         -> body of restoreFirstFriend
  spp_span_update_buttons_6101.c    -> body of get_embed
  chunk 6127 island dump            -> body of update_buttons

The controller class name is NOT recovered (NAME FLAG below);
its private attrs are single-underscore in the const pool
('_window', '_logged_in') so no mangling law applies.
"""


def getAppData():
    """Registry L6015 (module-level, zero-arg — stream stub
    argcount=0 varnames=<module>). Content: chunk labeled L6026
    (raw spp_span___init___6026.c, read end-to-end).

    [E:] name: XY.user.name — the receiver rides the entry RSI
         into the first stage (raw 19-46); user (GOT_388) then
         name (GOT_273) GetAttr chains.
    [E:] avatar = bot.user.display_avatar.url if
         bot.user.display_avatar else None — two None slots are
         pre-stored (raw 54-69), then the display_avatar (GOT_
         1020) truth gate (raw 99-104 IsTrue) guards the .url
         (GOT_114) fetch (raw 134-149); the receiver-chain
         re-stages user (GOT_388) each time.
    [E:] banner likewise via banner (GOT_1061) with its own
         IsTrue gate (raw 180-182) and .url fetch (raw 214-229).
    [E:] return (name, avatar, banner) — the kind-1 count-3
         tuple build (raw 242) is the return value; the None
         fallback covers the null-error tail (raw 259-271).
         The receiver global name is register-held from the
         armed head (translated as bot per the family's
         stage('bot') usage in restoreFirstFriend) — flagged.
    """
    name = bot.user.name
    avatar = (bot.user.display_avatar.url
              if bot.user.display_avatar else None)
    banner = bot.user.banner.url if bot.user.banner else None
    return (name, avatar, banner)


class LoginWindowController:
    """The webview login window + profile-viewer page controller
    (registry L6026-L6101).

    NAME FLAG: 'LoginWindowController' is a readability label —
    the class name is not in the const pool; the family members
    are pinned by the ('self', 'url') signature tuple (slot
    622) and the shared _window/_logged_in/button attrs.
    """

    def __init__(self):
        """Registry L6026. Content: chunk labeled L6030 (stream
        section function@L6026).

        [E:] exactly two SetAttrs: self._window = None
             ('_window' GOT_620 + None GOT_030, events 33-41)
             then self._logged_in = False ('_logged_in' GOT_
             1059 + False GOT_032, events 50-58); silent None
             return with the ret-dispatch (event 83).
        """
        self._window = None
        self._logged_in = False

    def set_window(self, window):
        """Registry L6030. Content: chunk labeled L6033 (stream
        section function@L6030).

        [E:] a single SetAttr onto '_window' (GOT_620, events
             29-39) then the silent None tail. The parameter
             name is not const-evidenced (stub polluted) —
             'window' is a neutral carrier, flagged.
        """
        self._window = window

    def hide(self):
        """Registry L6033. Content: chunk labeled L6036 (stream
        section function@L6036).

        [E:] self._window (GOT_620) .hide() — the 'hide'
             GetAttr (GOT_648, events 45-51) with a zero-arg
             call; silent None tail.
        """
        self._window.hide()

    def discordLogin(self):
        """Registry L6036. Content: chunk labeled L6046 (raw
        spp_span_url_callback_change_6046.c, read end-to-end).

        The login bypass: evaluates the token-injection
        JavaScript in the embedded window.

        [E:] data = getConfigData() (GOT_145 staged + the
             zero-arg call, raw 30-51); token = getCurrentToken
             () (GOT_563, raw 52-68); app_id = getCurrentAppId
             (GOT_559, raw 69-85) — all three loaded; only the
             token feeds the JS (data/app_id drop out — kept
             for the side-effect-faithful call order, flagged).
        [E:] self._window (GOT_620) .evaluate_js (GOT_041) —
             raw 86-117.
        [E:] the payload — the EXACT JS consts 827 + 828 with
             str(token) between (the a9d48 str-convert raw
             126-129 + the kind-3 3-piece join raw 134):
             <JS>
                 if (window.location.href !==
                     "https://discord.com/channels/@me") {
                     document.body.appendChild(
                         document.createElement
                         `iframe`).contentWindow
                         .localStorage.token = `"<token>"`
                     window.location.href =
                         "https://discord.com/channels/@me";
                 }
             </JS>
             (const 827 opens with a leading newline; the
             concat shape is 827 + str(token) + 828.)
        [E:] silent None return with PyErr clear (raw 149-159).
        """
        data = getConfigData()
        token = getCurrentToken()
        app_id = getCurrentAppId()
        self._window.evaluate_js(
            '\n    if (window.location.href !== '
            '"https://discord.com/channels/@me") {\n'
            '        document.body.appendChild('
            'document.createElement `iframe`).contentWindow'
            '.localStorage.token = `"' + token + '"`\n'
            '        window.location.href = '
            '"https://discord.com/channels/@me";\n    }')
        return None

    def url_callback_change(self, url):
        """Registry L6046. Content: chunk labeled L6050 (stream
        section function@L6046 + raw spp_span_restoreFirstFriend
        _6050.c header). Signature ('self', 'url') [E:] —
        const-pool tuple slot 622 (LIVE).

        [E:] the a9d30 selector-2 (==) compare against
             'https://discord.com/channels/@me' (GOT_698,
             events 31-34) with the double-IsTrue bool
             normalization (events 38-46); the equal branch
             sets self._logged_in = True ('_logged_in' GOT_
             1059 + True GOT_031 + SetAttr, events 68-81);
             silent None exit both ways (ret-dispatch, event
             93).
        """
        if url == 'https://discord.com/channels/@me':
            self._logged_in = True
        return None

    def restoreFirstFriend(self):
        """Registry L6050. Content: chunk labeled L6075 (stream
        section function@L6050 + raw spp_span_get_embed_6075.c
        header).

        [E:] print('Logged in, loading first friend...') — the
             print global (GOT_204) with the EXACT message
             GOT_1056 (events 26-44).
        [E:] self._window.load_url(...) — _window (GOT_620) +
             'load_url' (GOT_500, events 53-80) called with
             'https://discord.com/users/' (GOT_1057) + the
             str-convert (a9d48) of bot.config['restore_
             friends'][0]['id'] — the 'bot' global (GOT_244),
             'config' (GOT_245), the 'restore_friends' subscript
             (GOT_1058 + GetItem, events 110-116), int-0 index
             (GOT_277) and 'id' subscript (GOT_265, events
             129-134) with the 2-piece a9d48 join; silent None
             tail.
        """
        print('Logged in, loading first friend...')
        self._window.load_url('https://discord.com/users/'
                              + bot.config['restore_friends'][0]
                              ['id'])
        return None

    def get_embed(self):
        """Registry L6075. Content: chunk labeled L6101 (raw
        spp_span_update_buttons_6101.c, read end-to-end).

        [E:] themeData = getThemeData() (GOT_1047 staged + the
             zero-arg call, raw 38-59); user = self.users[self
             .index] — the receiver rides frame slot 0x68 (the
             method self, set by the frame-enter prologue), the
             'users' (GOT_1052) and 'index' (GOT_1040) GetAttrs
             (raw 60-101) + the GetItem (raw 106); themeData
             sits at frame slot 0x70.
        [E:] embed = discord_bot.Embed(**{'title': user
             ['display_name'], 'color': int(themeData['color']
             .replace('#', ''), 16)}) — the discord_bot global
             (GOT_310) -> Embed (GOT_369) staged; the kind-3
             count-2 kwargs build (raw 226): 'title' (GOT_370)
             = user['display_name'] (GetItem GOT_998, raw
             146-162); 'color' (GOT_371) = int (GOT_372 staged)
             of themeData['color'] (GetItem GOT_371, raw
             183-199) .replace('#', '') (GOT_237 + GOT_373/'
             GOT_241 pair, raw 202-218) with base 16 (GOT_374);
             the Embed call r8=0 r9=1 kwargs-flag (raw 227).
        [E:] embed.set_thumbnail(**{'url': user['avatar_url']})
             — 'set_thumbnail' (GOT_378, raw 232-243) with the
             (3,1) kwargs 'url' (GOT_114) = user['avatar_url']
             (GetItem GOT_999, raw 258-283); call r9=1 (raw
             285).
        [E:] embed.add_field(**{'name': 'Username', 'value':
             user['name'], 'inline': False}) — 'add_field' (GOT_
             1048, raw 289-306) with the (3,3) kwargs 'name'
             (GOT_273) = 'Username' (GOT_1054), 'value' (GOT_
             274) = user['name'] (GetItem, raw 324-339),
             'inline' (GOT_1050) = False (GOT_032, raw
             343-350); call raw 351.
        [E:] embed.add_field(**{'name': 'User ID', 'value':
             user['id'], 'inline': False}) — the second
             identical shape with 'User ID' (GOT_1055) and
             user['id'] (GetItem GOT_265, raw 391-406); call
             raw 418.
        [E:] return embed (raw 424-427: the frame-slot check
             sets the success flag and returns the embed
             object); None fallback otherwise.
        """
        themeData = getThemeData()
        user = self.users[self.index]
        embed = discord_bot.Embed(
            title=user['display_name'],
            color=int(themeData['color']
                      .replace('#', ''), 16))
        embed.set_thumbnail(url=user['avatar_url'])
        embed.add_field(name='Username', value=user['name'],
                        inline=False)
        embed.add_field(name='User ID', value=user['id'],
                        inline=False)
        return embed

    def update_buttons(self):
        """Registry L6101. Content: chunk labeled L6127 —
        recovered from the interior bytes of chunk 6127 (dump
        file chunk6127_update_buttons_L6101.txt; the 'file
        merged/absent' verdict was a boundary artifact — the
        chunk decodes at alignment +1, 91 events). Signature
        ('self',) [E:] — const-pool tuple slot 278.

        [E:] self.previous_button.disabled = self.index == 0 —
             previous_button (GOT_1041, 0x571c8) .disabled (GOT_
             358) via SetAttr with the a9d30 selector-2 compare
             of self.index (GOT_1040 GetAttr) vs int 0 (GOT_
             277, 0x57286-0x57293).
        [E:] self.next_button.disabled = self.index ==
             len(self.users) - 1 — next_button (GOT_1043,
             0x5731b); len staged (GOT_267, 0x573eb) called on
             the self.users (GOT_1052 GetAttr) pack; the a9d10
             selector-0x24 subtract by int 1 (GOT_233,
             0x574ab-0x574c2) then the selector-2 compare vs
             self.index (0x574c6-0x574d8) + SetAttr (0x5751e).
        [E:] self.profile_button.url = 'discord://discord.com/
             users/' + str(self.users[self.index]['id']) —
             profile_button (GOT_1046, 0x5754f) with the 'url'
             (GOT_114) SetAttr; the value is the 2-piece a9d48
             join over 'discord://discord.com/users/' (GOT_
             1053, 0x575ea-0x575ff) and the str-convert
             (0x5774b) of self.users[self.index]['id'] (the
             GetItem at 0x576e3 + 'id' GOT_265 GetItem at
             0x5771d); final SetAttr 0x57783, silent None tail
             with PyErr clear (0x577b9-0x577da).
        """
        self.previous_button.disabled = self.index == 0
        self.next_button.disabled = \
            self.index == len(self.users) - 1
        self.profile_button.url = \
            'discord://discord.com/users/' \
            + str(self.users[self.index]['id'])
        return None


class ServerWindowController:
    """The servers-browser page controller (registry
    L6127-L6153) — the sibling of LoginWindowController's user
    browser: identical button/bookkeeping shapes but over
    self.servers with the invite deep-link.

    NAME FLAG: 'ServerWindowController' is a readability label
    — the class name is not recovered; its registry placement
    follows the user-pair (L6075/L6101) and it shares the same
    const family (previous_button/next_button/profile_button/
    index slots plus 'servers' GOT_1042).
    """

    def get_embed(self):
        """Registry L6127. Content: chunk labeled L6153 (stream
        section function@L6127).

        [E:] themeData = getThemeData() (GOT_1047, events
             38-48); server = self.servers[self.index] —
             'servers' (GOT_1042, events 61-77) and 'index'
             (GOT_1040, events 82-98) GetAttrs with the GetItem
             (event 106); the receiver is the method frame's
             self (mirrors the user-pair).
        [E:] embed = discord_bot.Embed(**{'title': server
             ['name'], 'color': int(themeData['color'].
             replace('#', ''), 16)}) — Embed (GOT_310/369,
             events 119-135); 'title' (GOT_370) = server
             ['name'] (GetItem GOT_273, events 145-161);
             'color' (GOT_371) with int (GOT_372), replace
             ('#', '') (GOT_237 with GOT_373/GOT_241) and base
             16 (GOT_374, events 165-222); the kind-3 kwargs
             call shape mirrors the user get_embed.
        [E:] embed.set_thumbnail(**{'url': server['icon']}) —
             set_thumbnail (GOT_378, events 232-250) with
             'url' (GOT_114) = server['icon'] (GetItem GOT_
             959, events 259-280).
        [E:] embed.add_field(**{'name': 'ID', 'value': server
             ['id'], 'inline': False}) — add_field (GOT_1048,
             events 289-306) with 'ID' (GOT_1049) = server
             ['id'] (GetItem GOT_265, events 324-338), inline
             False (GOT_032).
        [E:] embed.add_field(**{'name': 'Invite', 'value':
             server['invite'], 'inline': False}) — 'Invite'
             (GOT_1051, events 383-385) = server['invite']
             (GetItem GOT_1045, events 391-405).
        [E:] return embed — the family tail (None constellation
             + ret-dispatch, events 440-449).
        """
        themeData = getThemeData()
        server = self.servers[self.index]
        embed = discord_bot.Embed(
            title=server['name'],
            color=int(themeData['color']
                      .replace('#', ''), 16))
        embed.set_thumbnail(url=server['icon'])
        embed.add_field(name='ID', value=server['id'],
                        inline=False)
        embed.add_field(name='Invite', value=server['invite'],
                        inline=False)
        return embed

    def update_buttons(self):
        """Registry L6153. Content: chunk labeled L6265 (stream
        section function@L6153).

        [E:] previous/next buttons identical to the user pair:
             previous_button (GOT_1041)/disabled (GOT_358)
             with self.index (GOT_1040) == 0 (GOT_277) via
             a9d30 (events 33-102); next_button (GOT_1043) ==
             len(self.servers) - 1 — len (GOT_267, events
             154-162) over self.servers (GOT_1042) with the
             a9d10 subtract by int 1 (GOT_233, events 190-192).
        [E:] self.profile_button.url = 'discord://discord.com/
             invite/' + str(self.servers[self.index]
             ['invite']) — profile_button (GOT_1046, events
             211-228) with 'url' (GOT_114) SetAttr; the value =
             the 2-piece a9d48 join over 'discord://discord.com/
             invite/' (GOT_1044, events 232-241) and the
             str-converted self.servers[self.index]['invite']
             (GetItem GOT_011 events 289-299); silent None tail
             with the PyErr clear (events 312-320).
        """
        self.previous_button.disabled = self.index == 0
        self.next_button.disabled = \
            self.index == len(self.servers) - 1
        self.profile_button.url = \
            'discord://discord.com/invite/' \
            + str(self.servers[self.index]['invite'])
        return None
