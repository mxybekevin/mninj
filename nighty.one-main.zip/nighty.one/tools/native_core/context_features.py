"""
context_features.py — Nighty's context-file feature pair from the SPP
native core, translated with evidence chains.

Notable recovered behavior: BOTH writers call getContextFileFeatures()
FIRST as a bare side-effect statement — its result is Py_DecRef'd
without ever being stored (dossiers L00895 0xd992-0xd9bf and L01176
0xe2e1-0xe33b) — to make sure context_path exists, then each function
re-reads the file itself and rewrites it atomically-ish.
getContextFileFeatures itself is a plain-shell function (not in the
SPP registry).
"""

import json


def addContextFileFeature(s):
    """Registry L886. Content: chunk labeled L895.

    [E:] signature tuple ('s',).
    [E:] bare getContextFileFeatures() call (result dropped).
    [E:] try: open(context_path, 'r') — NO encoding kwargs in this
         stream (unlike the voicemute/noleave readers) — plus
         json.load; real except machinery (PyErr_Fetch dispatcher)
         with the load-silenced default path.
    [E:] membership guard (IsTrue/False pair, events 39-41), then
         'append' and the write-back open(context_path, 'w') +
         json.dump(feats, f, indent=2).
    [E:] the except-branch default container is dispatcher-built
         (invisible in events); [] inferred from the append/membership
         flow — flagged.
    """
    getContextFileFeatures()
    try:
        with open(context_path, 'r') as f:
            feats = json.load(f)
    except Exception:
        feats = []
    if s not in feats:
        feats.append(s)
        with open(context_path, 'w') as f:
            json.dump(feats, f, indent=2)


def removeContextFileFeature(s):
    """Registry L895. Content: chunk labeled L1176.

    [E:] signature tuple ('s',); PyCell_New at the entry captures s
         for the closure below (dossier 0xe2b4-0xe2c2).
    [E:] bare getContextFileFeatures() call (result dropped), then
         the same guarded read: open(context_path, 'r') + json.load
         with the PyErr_Fetch except machinery.
    [E:] the rebuild: PyList_New + GetIter + PyCell_Get + IsTrue +
         PyList_Append = a filtered list comprehension that keeps
         every element != s.
    [E:] write-back: open(context_path, 'w') + json.dump(...,
         indent=2).
    """
    getContextFileFeatures()
    try:
        with open(context_path, 'r') as f:
            feats = json.load(f)
    except Exception:
        feats = []
    feats = [x for x in feats if x != s]
    with open(context_path, 'w') as f:
        json.dump(feats, f, indent=2)
