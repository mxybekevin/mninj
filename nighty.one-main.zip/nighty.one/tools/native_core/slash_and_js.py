"""
slash_and_js.py — getSlashCommand + the webview JS execution pair,
recovered from the SPP native core via the Ghidra decomp lane.

getSlashCommand(details, cmds, app_id): scans a command list for the
entry whose .name equals details AND whose .application_id casts to
int and equals app_id; returns the matched command or None.

execute_js_via_websocket(js_code): when config['web'] is set, pushes
the code to the React frontend via
socketio.emit('execute_js', {'code': js_code}) and returns True;
returns False otherwise. Failures land in
logging.info('JS execution failed: ' + str(e)) -> False.

evaluate_js(js_code): web mode -> the same socketio emit, returns
None; desktop mode -> main_ui.evaluate_js(js_code) when the main
window exposes it (its return value becomes the function's return),
else None. Failures land in
logging.info('JavaScript execution failed: ' + str(e)) -> None.

New SPP facts established by this family: SUBGOT_a9d30 selector 10 =
isinstance (the `except Exception` filter); DAT_000a9d40 = the SPP
exception-fetch/try machinery (real try-block dispatcher marker);
SUBGOT_a9d48 = the string-concat op ('msg: ' + <expr>).
"""

import logging


def getSlashCommand(details, cmds, app_id):
    """Registry L2051. Content: chunk labeled L2137 (decomp
    spp_span_execute_js_via_websocket_2137.c's head section — the
    stream corpus decoded it; the file carries this body followed by
    the execute_js tail). Signature (details, cmds, app_id) [E:] —
    dossier stub L02051.

    [E:] iterates cmds (GetIter L39 + iterator-next L45);
         command.name staged + GetAttr (L55-64), then the first
         a9d30 compare cluster with IsTrue + bool-False fallback
         (L69-104) — name == details (compare selector not yet
         tabulated, direction/semantics from the flow — flagged);
         command.application_id (GetAttr L127) cast via int()
         ('int' staged L131-138) and compared against app_id
         (the (1,1) args build + the second a9d30/IsTrue cluster,
         L141-157); joint truth (L166) returns the loop command;
         loop exhaustion -> None (L200-205, the exception-machinery
         ring is the iteration check, not a user try).
    """
    for command in cmds:
        if command.name == details and \
                int(command.application_id) == app_id:
            return command
    return None


def execute_js_via_websocket(js_code):
    """Registry L2137. Content: chunk labeled L2149 (decomp
    spp_span_evaluate_js_2149.c). Signature ('js_code',) [E:] —
    dossier stub L02137.

    [E:] web = getConfigData()['web'] (L27-58: getConfigData
         GOT_145 + GetItem 'web' GOT_464); a failed GetItem routes
         to the exception handler (L59 -> the DAT_000a9d40 fetch +
         SUBGOT_a9d30 selector 10 = isinstance(e, Exception), the
         compiled `except Exception` filter, L60-83).
    [E:] web truthy (L139-145): socketio.emit('execute_js',
         {'code': js_code}) — socketio LOAD_GLOBAL (GOT_068),
         'emit' GetAttr (GOT_1591), the ('execute_js') const +
         the (3,1)-built {'code': js_code} dict (GOT_1592/1593 +
         the js_code slot, L154-178); success -> return True
         (GOT_031, L182-183); emit error -> the handler.
    [E:] web falsy (L187-189): return False (GOT_032).
    [E:] handler: logging.info('JS execution failed: ' + str(<e>))
         ('logging' GOT_044, 'info' GOT_051, exact const GOT_1595,
         the a9d48 concat op L107-119; str(e) — the object flows
         from the a9d40 fetch through the concat, flag) ->
         return False (L124-131); non-Exception errors re-raise
         (GOT_002 dispatch L135).
    """
    try:
        if getConfigData()['web']:
            socketio.emit('execute_js', {'code': js_code})
            return True
        return False
    except Exception as e:
        logging.info('JS execution failed: ' + str(e))
        return False


def evaluate_js(js_code):
    """Registry L2149. Content: chunk labeled L2168 (decomp
    spp_span_generate_tailwind_classes_2168.c). Signature [E:] —
    ('js_code',) per the family stub (L02149).

    [E:] identical head/handler to execute_js_via_websocket with
         the exact const 'JavaScript execution failed: ' (GOT_1594)
         and a None return from the handler (L107-133).
    [E:] web truthy (L140-147 else-path -> L207-241): the same
         socketio.emit('execute_js', {'code': js_code}), then
         return None (L242-246).
    [E:] web falsy (L147): hasattr(main_ui, 'evaluate_js') —
         'hasattr' GOT_1174 staged with main_ui (GOT_040) +
         'evaluate_js' (GOT_041), the (1,2) args build + call
         (L148-170); falsy -> return None (L175 -> L242); truthy ->
         main_ui.evaluate_js GetAttr (L185-191) + the (1,1) call
         with the js_code slot (L195-201) and its RESULT returned
         (L202 -> the L250-259 exit); a failed call routes to the
         handler (L205).
    """
    try:
        if getConfigData()['web']:
            socketio.emit('execute_js', {'code': js_code})
            return None
        if hasattr(main_ui, 'evaluate_js'):
            return main_ui.evaluate_js(js_code)
        return None
    except Exception as e:
        logging.info('JavaScript execution failed: ' + str(e))
        return None
