"""
add_account_window.py — the add-account window controller class
from the SPP native core (registry L8151-L8263), recovered from
the corpus event streams plus island dumps. RE-SNATCH LANDED:
the seven members ship complete — the window-wrapper marquees,
the paste-token bridge and the two banner-page token sniffers
(the 705/706 pieces embedded live; the url_change_callback@
L8163 and add_acc_url_change@L8230 sections are merged-region
spans whose islands carry the bodies).

  __init__(self)             — self._window = None
  set_window(self, window)   — the wrapper binding
  hide(self)                 — the plain window hide
  close(self)                — the window destroy
  saveTokenToConfig(token)   — the paste-token bridge
  url_change_callback(self, url) — the banner sniffer
  add_acc_url_change(self, url, profileName) — the mirror

CLASS NAME FLAG: no live const in this span names the class; the
inference AppAddAccountApi follows the add_acc_url_change@L8230
neighbor and the AppCreateApi sibling — flagged, rename when the
booter island (autoApp@L8057's 1415-insn chunk) surfaces the
js_api class const (the createApp precedent: 718 'AppCreateApi'
was staged in ITS booter).
"""

import logging  # noqa: F401  (module family import parity)


class AppAddAccountApi:

    def __init__(self):
        """Registry L8151. Content: chunk L8154 — recovered from the
        island bytes of chunk 8154 (dump file chunk8154_init_L8151.txt,
        per the dumper +2 align, 17 events, 89 insns, read complete
        through the set_window prologue), cross-checked against the
        complete stream section (function@L8151, corpus lines
        21744-21759, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x7bf24 with the GOT_000 binder (r8d=1) at
            0x7bf50.
        [E:] THE BODY — the '_window' CONST[620] staged 0x7bf6a
            with the None CONST[30] staged 0x7bf78, the SetAttr
            over the [rsp+0x58] self — `self._window = None` —
            the tail None materialization 0x7bfe2 and the
            implicit return through the ret-disp (a9d28) at
            0x7c01a. The byte-mirror of WebWindow.__init__@L7397
            and AppCreateApi.__init__@L8089 — the family emission
            law's third member; corpus events 18-58.
        """
        self._window = None

    def set_window(self, window):
        """Registry L8154. Content: chunk L8157 — recovered from the
        island bytes of chunk 8157 (dump file
        chunk8157_set_window_L8154.txt, per the dumper +0 align, 14
        events, 92 insns, read complete), cross-checked against the
        complete stream section (function@L8154, corpus lines
        21760-21772, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[651]
            ('self', 'window') staged 0x7c08f with the GOT_000
            binder (r8d=2) at 0x7c0bb.
        [E:] THE BODY — the '_window' CONST[620] staged 0x7c0d5,
            the SetAttr over the second binder target —
            `self._window = window` with the implicit None return
            (CONST[30] staged 0x7c15d) through the ret-disp at
            0x7c172; the set_window@L7400 emission law; corpus
            events 20-59.
        """
        self._window = window

    def hide(self):
        """Registry L8157. Content: chunk L8160 — recovered from the
        island bytes of chunk 8160 (dump file chunk8160_hide_L8157.txt,
        per the dumper +3 align, 19 events, 109 insns, read complete),
        cross-checked against the complete stream section
        (function@L8157, corpus lines 21773-21793, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x7c1d5 with the GOT_000 binder (r8d=1) at
            0x7c201.
        [E:] THE BODY — GetAttr(self, '_window' CONST[620] staged
            0x7c222) then GetAttr over 'hide' CONST[648] staged
            0x7c267, the zero-argument call — self._window.hide()
            — the PLAIN marquees (no bot boot: the AppCreateApi
            hide@L8095 distinguishes itself with 195 insns and the
            kwargs reconnect; this one is the 109-insn
            WebWindow@L7403 emission law verbatim) with the
            implicit None return through the ret-disp at 0x7c2fe;
            corpus events 19-70.
        """
        self._window.hide()

    def close(self):
        """Registry L8160. Content: chunk L8163 — recovered from the
        island bytes of chunk 8163 (dump file chunk8163_close_L8160.txt,
        per the dumper +3 align, 18 events, 109 insns, read complete),
        cross-checked against the complete stream section
        (function@L8160, corpus lines 21794-21814, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x7c365 with the GOT_000 binder (r8d=1) at
            0x7c391.
        [E:] THE BODY — GetAttr(self, '_window' const staged
            0x7c3b2) then GetAttr over 'destroy' const staged
            0x7c3f7, the zero-argument call —
            self._window.destroy() — the close@L7406 emission
            law with the implicit None return through the
            ret-disp at 0x7c48e; corpus events 19-70.
        """
        self._window.destroy()

    def saveTokenToConfig(self, token):
        """Registry L8263. Content: chunk L8332 — recovered from the
        island bytes of chunk 8332 (dump file
        chunk8332_saveTokenToConfig_L8263.txt, per the dumper +0
        align, 149 events, 804 insns, read complete through the
        open_file_in_explorer prologue at 0x7e7-adjacent), cross-
        checked against the complete stream section
        (function@L8263, corpus lines 21821-21992, read complete).
        The pywebview JS-API bridge target: the sniffer tier's
        JS calls pywebview.api.saveTokenToConfig(token).

        [E:] THE SIGNATURE — the names-tuple CONST[276]
            ('self', 'token') staged 0x7dab4 with the GOT_000
            binder (r8d=2) at 0x7dae0.
        [E:] THE VERIFICATION GET — requests (CONST[130] global
            name load) with .get (CONST[47] GetAttr 0x7db27)
            over the one-positional
            'https://discord.com/api/v10/users/@me' CONST[131]
            staged 0x7db66, the kind-3 count-3 headers dict
            (a9d18 ecx=3, edx=3, first pair r8/r9 =
            'Authorization' CONST[133] staged 0x7dba3 against
            the [rsp+0x58] token, frame pairs:
            'Content-Type' 134 staged 0x7dbbf against
            'application/json' 136 staged 0x7dbcd, and
            'User-Agent' 135 staged 0x7dbdb against the
            full live client UA CONST[137]
            'Mozilla/5.0 (Windows NT 10.0; WOW64)
            AppleWebKit/537.36 (KHTML, like Gecko)
            discord/1.0.9001 Chrome/83.0.4103.122
            Electron/9.3.5 Safari/537.36' staged 0x7dbea), the
            kwargs verify=False ('verify' 138 / False at
            0x7dc19-0x7dc27) and timeout=20 ('timeout' 139 /
            20 at 0x7dc35-0x7dc44) — the zero-positional
            kwargs-present call form finishing the
            requests.get; corpus events 37-104.
        [E:] THE GATE — GetAttr('status_code' CONST[141]) over
            the response with the a9d30 sel-2 equality against
            CONST[142] 200 — `if r.status_code == 200:` — the
            double IsTrue gates at the corpus events 150-158.
        [E:] THE 200 ARM — response.json() (the 'json'
            CONST[143] GetAttr 0x7ddf3, the zero-arg call
            0x7df09 storing [rsp+0x70]); data.get
            ('username' CONST[144] wrapped kind-1 and called
            0x7dfb5-0x7dfd5) binding [rsp+0x78];
            config = getConfigData() (CONST[145], a9d50 name
            load 0x7e018, zero-arg call 0x7e043) with
            config['logins'] (CONST[146] GetItem 0x7e061)
            binding [rsp+0x80]; then the entry dict built
            kind-3 count-3 at 0x7e0eb-0x7e2f3: the 'token'
            CONST[147] first pair against str(token) (the
            'str' CONST[150] global through the a9d50 stage
            0x7e12d, the kind-1 [token] wrap over [rsp+0x60],
            the call 0x7e180 storing [rsp+0x98]), the
            'date_added' CONST[148] pair against
            datetime.now().strftime('%d %B %Y, at %H:%M:%S')
            (the datetime/now/strftime chain 0x7e1a0-0x7e2a4
            with the format CONST[154]), and the 'active'
            CONST[149] pair against True (CONST[31],
            0x7e2b7-0x7e2cd) — then SetItem over the logins
            container with the [rsp+0x78] username key and the
            built entry at 0x7e315:
            config['logins'][username] = the entry dict; corpus
            events 161-388.
        [E:] THE SAVE CASCADE — a fresh getConfigData() global
            call staged 0x7e345-0x7e461 binding [rsp+0x88];
            SetItem#2 at 0x7e4d3: the fresh config's 'logins'
            set to the modified logins container; then
            saveConfigData (CONST[155] a9d50 stage 0x7e523,
            the kind-1 [config] wrap 0x7e553-0x7e574, the call
            0x7e594); then setActiveProfile (CONST[156] stage
            0x7e5cb, the kind-1 [username] wrap over
            [rsp+0x78] 0x7e5e1-0x7e5ff, the call 0x7e61f);
            then the autoApp CONST[157] global load with the
            bare zero-arg call closing the arm (corpus events
            392-504) — the full merge back, the profile
            switch, and the window reopen.
        [E:] THE ELSE ARM — the 'evaluate_js' name loaded
            through the a9d50 stage (0x7ddb9 — the GLOBAL name
            helper family, asyncio/os/re-class; not the
            _window method chain), the kind-1 wrap of
            'location.reload();' CONST[158] and the call
            0x7de4c — evaluate_js('location.reload();') —
            then the bridge error dict built kind-3 count-2
            ({'status': 'error', 'text': 'Invalid token.'},
            consts 159/45/97/160) at 0x7de68-0x7debd and
            RETURNED (carried rsi through the 0x7e390 exit);
            corpus events 161-198.
        """
        r = requests.get(
            'https://discord.com/api/v10/users/@me',
            headers={
                'Authorization': token,
                'Content-Type': 'application/json',
                'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; '
                               'WOW64) AppleWebKit/537.36 (KHTML, '
                               'like Gecko) discord/1.0.9001 '
                               'Chrome/83.0.4103.122 '
                               'Electron/9.3.5 Safari/537.36')},
            verify=False,
            timeout=20)
        if r.status_code == 200:
            data = r.json()
            username = data.get('username')
            config = getConfigData()
            logins = config['logins']
            logins[username] = {
                'token': str(token),
                'date_added': datetime.now().strftime(
                    '%d %B %Y, at %H:%M:%S'),
                'active': True}
            config = getConfigData()
            config['logins'] = logins
            saveConfigData(config)
            setActiveProfile(username)
            autoApp()
        else:
            evaluate_js('location.reload();')
            return {'status': 'error', 'text': 'Invalid token.'}

    def url_change_callback(self, url):
        """Registry L8163. Content: chunk L8230 — recovered from the
        island bytes of chunk 8230 (dump file
        chunk8230_url_change_callback_L8163.txt, per the dumper +0
        align, 127 events, 681 insns, read complete), cross-checked
        against the stream section (function@L8163, corpus lines
        21815-21817 — a merged-region minimal section carrying only
        the header; the island body is the authority). The
        add-account window's token sniffer: on the channels success
        URL, walk the loaded request headers for the Discord API
        Authorization and hand the value to the saveTokenToConfig
        bridge with the login re-injection.

        [E:] THE SIGNATURE — the names-tuple CONST[622] ('self',
            'url') staged 0x7c517 with the GOT_000 binder (r8d=2)
            at 0x7c543.
        [E:] THE GATE — the sel-2 equality over the url against the
            live CONST[698] 'https://discord.com/channels/@me'
            staged 0x7c565 — the falsy False-materialization
            0x7c5a5 exits the implicit return —
            `if url == 'https://discord.com/channels/@me':`.
        [E:] THE LOG — logging.info over the live CONST[699]
            '[WEB LOGIN] Logged in, retrieving token...' staged
            0x7c65a (the 44/51 name-loads, the kind-1 wrap and
            the one-positional call 0x7c699).
        [E:] THE HEADERS — GetAttr(self [rsp+0x68], '_window'
            CONST[620] staged 0x7c6c1, resolved 0x7c6d5) then
            GetAttr 'get_request_headers' CONST[700] staged
            0x7c706 (resolved 0x7c71f), the zero-argument call
            0x7c753 binding [rsp+0x78] —
            self._window.get_request_headers().
        [E:] THE PATTERN — the re CONST[228] name-load
            0x7c777-0x7c797 with GetAttr 'compile' CONST[701]
            staged 0x7c7ad (resolved 0x7c7cc) over the kind-1
            wrapped live CONST[702] staged 0x7c7ec — the
            one-positional call 0x7c82b binding [rsp+0x80] —
            re.compile('https://discord\\\\.com/api/v\\\\d+/'
            'users/@me(?:[/?].*)?$').
        [E:] THE OUTER WALK — GetAttr 'items' CONST[247] staged
            0x7c865 (resolved 0x7c879), the zero-arg call
            0x7c8bf, the GetIter through the CONST[27] slot
            0x7c8d1 binding [rsp+0x48]; the loop head 0x7c8f4
            (a9d60 iternext) unpacking through GOT_004 r8d=2
            into [rsp+0x70]/[rsp+0x88] — `for key, value in
            headers.items():` (FLAG: the key/value receivers are
            slot-inferred names per the rename-loop convention).
        [E:] THE MATCH — GetAttr 'fullmatch' CONST[703] staged
            0x7c9a1 (resolved 0x7c9b7) over the kind-1 [key]
            wrap (a9d18 0x7c9ec, r8 = the [rsp+0x70] key staged
            0x7c9f3), the one-positional call 0x7ca2e, the
            IsTrue 0x7ca3f with the falsy side rolling the loop
            via 0x7cc31 — `if pattern.fullmatch(key):`.
        [E:] THE INNER WALK — the matched side runs GetAttr
            'items' staged 0x7ca77 (resolved 0x7ca8d), the
            zero-arg call 0x7cad2, the GetIter 0x7cae3 and the
            second GOT_004 r8d=2 unpack into [rsp+0x90]/[
            rsp+0x98] — `for k2, v2 in value.items():` (FLAG:
            k2/v2 slot-inferred).
        [E:] THE AUTHORIZATION — the a9d30 sel-2 equality with
            r8 = the [rsp+0x90] k2 (staged 0x7cbb5) against r9 =
            CONST[133] 'Authorization' staged 0x7cbc5 (edx=2
            read 0x7cbd7, the call 0x7cbdc, the IsTrue 0x7cbed,
            the matched jne routing 0x7cd16, the falsy False
            materialization 0x7cc01 rolling the inner loop) —
            `if k2 == 'Authorization':`.
        [E:] THE SAVE — the matched arm logs
            logging.info('[WEB LOGIN] Token found, saving to
            config...') (the 44/51 loads 0x7cd26-0x7cd73, the
            live CONST[704] staged 0x7cd9a, the kind-1 wrap and
            the call 0x7cdd9) then the chain: GetAttr '_window'
            staged 0x7ce02 (resolved 0x7ce17) and 'evaluate_js'
            CONST[41] staged 0x7ce4a (resolved 0x7ce64); the
            f-string = the a9d48 finalize ecx=3 with rdx = the
            live CONST[705] staged 0x7ce92, r8 = the r8d=-1
            sub-built [rsp+0x98] v2 piece (0x7ceb9-0x7cec4), and
            r9 = the full 351-byte CONST[706] staged 0x7cec6
            (LIVE post re-snatch) — the kind-1 wrap 0x7cef6 and
            the one-positional call 0x7cf17 — the JS braces
            double-escape in the f-string source.
        """
        if url == 'https://discord.com/channels/@me':
            logging.info('[WEB LOGIN] Logged in, retrieving token...')
            pattern = re.compile(
                'https://discord\\.com/api/v\\d+/users/@me(?:[/?].*)?$')
            for key, value in (
                    self._window.get_request_headers().items()):
                if pattern.fullmatch(key):
                    for k2, v2 in value.items():
                        if k2 == 'Authorization':
                            logging.info('[WEB LOGIN] Token found, '
                                         'saving to config...')
                            self._window.evaluate_js(
                                f'\npywebview.api.saveTokenToConfig('
                                f'"{v2}")\n\n'
                                'function login(token) {\n'
                                '    setInterval(() => {\n'
                                '        document.body.appendChild('
                                'document.createElement `iframe`)'
                                '.contentWindow.localStorage.token = '
                                '`"${token}"`\n'
                                '    }, 50);\n'
                                '    setTimeout(() => {\n'
                                '        location.reload();\n'
                                '    }, 2500);\n'
                                '}\n\n'
                                "login('PASTE TOKEN HERE')\n"
                                'setTimeout(function() {\n'
                                '    pywebview.api.hide();\n'
                                '}, 2000);\n')

    def add_acc_url_change(self, url, profileName):
        """Registry L8230. Content: chunk L8263 — the byte-mirror of
        url_change_callback@L8163 recovered from the island bytes of
        chunk 8263 (dump file chunk8263_add_acc_url_change_L8230.txt,
        per the dumper +0 align, 128 events, 685 insns, skeleton read
        with the build zone verified), cross-checked against the
        stream section (function@L8230, corpus lines 21818-21820 —
        the merged-region minimal section; the island body is the
        authority). The one-event delta against the 8163 mirror is
        the binder slot.

        [E:] THE SIGNATURE — the names-tuple CONST[697] ('self',
            'url', 'profileName') staged 0x7cfe3 with the GOT_000
            binder (r8d=3) at 0x7d00f — the third parameter binds
            and is NEVER re-loaded: no site in the body consumes
            it (the full const map shows zero further uses) —
            FLAG: the profileName passes through from the JS
            caller and the emission discards it (the backend
            save derives its target itself).
        [E:] THE MIRROR ZONES — the gate CONST[698] staged
            0x7d031 (the False fall 0x7d071); the logging pair
            0x7d0b5/0x7d0e7 with the 699-staging 0x7d126; the
            window chain 0x7d18d/0x7d1ac with 'get_request_
            headers' staged 0x7d1d2; re/compile/702 staged
            0x7d24d/0x7d27f/0x7d2be; the outer walk GetIter
            0x7d3a6 with 'items' stagings 0x7d33a/0x7d359;
            'fullmatch' staged 0x7d476/0x7d497; the inner walk
            GetIter 0x7d5b8 with 'items' stagings 0x7d54c/
            0x7d56d; 'Authorization' staged 0x7d69a (the False
            fall 0x7d6d6); the 704 logging 0x7d809-0x7d87d;
            the window/evaluate_js chain 0x7d8e5/0x7d905/
            0x7d92d; the f-string: the 705-lit staged 0x7d975,
            the r8d=-1 sub-builder over **[rsp+0xa0]** (the
            third-parameter frame difference — READ at
            0x7d98d-0x7d9a7), the 706-lit staged 0x7d9a9, the
            ecx=3 finalize 0x7d9b8-0x7d9c3, the kind-1 wrap
            0x7d9cc-0x7d9d9, the call 0x7d9fa, the None tail
            0x7da15 — the identical JS to the 8163 save.
        """
        if url == 'https://discord.com/channels/@me':
            logging.info('[WEB LOGIN] Logged in, retrieving token...')
            pattern = re.compile(
                'https://discord\\.com/api/v\\d+/users/@me(?:[/?].*)?$')
            for key, value in (
                    self._window.get_request_headers().items()):
                if pattern.fullmatch(key):
                    for k2, v2 in value.items():
                        if k2 == 'Authorization':
                            logging.info('[WEB LOGIN] Token found, '
                                         'saving to config...')
                            self._window.evaluate_js(
                                f'\npywebview.api.saveTokenToConfig('
                                f'"{v2}")\n\n'
                                'function login(token) {\n'
                                '    setInterval(() => {\n'
                                '        document.body.appendChild('
                                'document.createElement `iframe`)'
                                '.contentWindow.localStorage.token = '
                                '`"${token}"`\n'
                                '    }, 50);\n'
                                '    setTimeout(() => {\n'
                                '        location.reload();\n'
                                '    }, 2500);\n'
                                '}\n\n'
                                "login('PASTE TOKEN HERE')\n"
                                'setTimeout(function() {\n'
                                '    pywebview.api.hide();\n'
                                '}, 2000);\n')
