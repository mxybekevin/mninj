"""
profile_store.py — the /profile.json persistence family from
the SPP native core (registry L6846 onward), recovered from
the corpus event streams plus island dumps. Every function
here reads and rewrites the app's profile file through the
getDataPath helper.

  setUserProfileState(toggle)   — the running flag read-
                                  modify-write
  saveUserProfileData(profile_name, new_data)
                                  — the named profile upsert
                                  over the profiles list
  renameUserProfileName(old_name, new_name)
                                  — the named profile rename
                                    with the active-profile
                                    repoint
"""

import json


def setUserProfileState(toggle):
    """Registry L6846. Content: chunk labeled L6895 — recovered
    from the island bytes of chunk 6895 (dump file
    chunk6895_setUserProfileState_L6846.txt, alignment +0, 120
    events, 603 insns @0x64d30 +928) cross-checked against the
    stream section (function@L6846, corpus line 17573).
    Signature ('toggle',) [E:] — const-pool tuple slot 927
    (0x64d52, LIVE; the one-argument frame enter at 0x64d7?).

    The running-flag read-modify-write over /profile.json.

    [E:] the path local: path = f'{getDataPath()}/profile.json'
         — getDataPath is staged exactly once (GOT_194,
         0x64d9a) and called with neither args nor kwargs
         (xor r8d / xor r9d at 0x64dd9-0x64ddf — the
         argumentless getDataPath() of the __init__ law),
         the call result passes the -1 a9d48 FORMAT_VALUE
         (r8d=0xffffffff, 0x64de7) and the two-piece
         BUILD_STRING joins the '/profile.json' literal
         (GOT_845 staged 0x64df2, ecx=2 at 0x64e01) — the
         f-string per the FORMAT_VALUE + BUILD_STRING law;
         the result binds [rsp+0x80] (0x64e1c) and both open
         calls load that slot (the read kwargs at 0x64e6f,
         the write args at 0x65254) — a single evaluation
         consumed twice, the bound-name path local.
    [E:] the read side: open staged (GOT_201, 0x64e36) with
         mode 'r' (GOT_283, 0x64e7f) and the a9d18 kind-3
         count-2 kwargs build (encoding='utf-8': GOT_284
         0x64ea4 / GOT_285 0x64eb3; errors='ignore': GOT_685
         0x64ec2 / GOT_686 0x64ed0; build 0x64ee8), the call
         at 0x64f0f; the with-machinery stages the slot-4 and
         slot-5 enter/exit pair (0x64f2b / 0x64f4b) with
         PyCallFunction at 0x64f6b, and the bound file object
         is stored to [rsp+0x88] (0x64f8e).
    [E:] the load: json staged (GOT_143, 0x64fa8) with the
         .load GetAttr (GOT_286, 0x64ff4) over the bound
         file; the result binds the data slot [rsp+0x90],
         verified by the SetItem target below.
    [E:] data['running'] = toggle — the SetItem at 0x651d2
         with rcx = [rsp+0x90] (the loaded data, loaded
         0x65190), rdi = 'running' (GOT_432, staged 0x6519f)
         and rsi = [rsp+0x78] (the toggle parameter).
    [E:] the write side: open staged again (GOT_201,
         0x65204) reusing the path slot [rsp+0x80] (loaded
         0x65254) with mode 'w' (GOT_833, 0x65264) and the
         same encoding/errors kwargs (0x65289-0x652b5), the
         same with-machinery pair, then json.dump — json
         staged 0x65389, 'dump' GetAttr (GOT_689, 0x6551e)
         with the kind-3 count-1 kwargs build indent=2
         (GOT_690 / GOT_478, 0x65594-0x655a3).
    [E:] the wrapper is a single try/except Exception around
         everything: every error path targets 0x653c5 where
         the a9d40 fetch (0x653d4) feeds the a9d30 selector-
         0xa match against Exception (GOT_77, staged
         0x653ed, call 0x6542f); cmp edi, 1 at 0x6544e —
         the match releases the exception state (DecRefs
         0x65453-0x6546e), sets the handled flag (mov sil, 1
         at 0x65474) and clears any residue
         (PyErr_Occurred/PyErr_Clear at 0x654ca-0x654d5),
         then returns None (the None const staged 0x654db);
         non-matching exceptions restore via GOT_002
         (0x65488) and propagate through ret-disp.
    [E:] the with-exit block dispatcher is the CONST-1857
         slot (lea at 0x65648 with PyCallFunction) — the
         standard block-exit machinery, annotator-invisible
         and recorded per the pydcode-slot law.
    """
    try:
        path = f'{getDataPath()}/profile.json'
        with open(path, 'r',
                  encoding='utf-8',
                  errors='ignore') as f:
            data = json.load(f)
        data['running'] = toggle
        with open(path, 'w',
                  encoding='utf-8',
                  errors='ignore') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass
    return None


def saveUserProfileData(profile_name, new_data):
    """Registry L6895. Content: chunk labeled L6909 — recovered
    from the island bytes of chunk 6909 (dump file
    chunk6909_saveUserProfileData_L6895.txt, alignment +0, 141
    events, 724 insns @0x65718 +2512) cross-checked against the
    full stream section (function@L6895, corpus lines
    17695-17828, read complete). Signature ('profile_name',
    'new_data') [E:] — const-pool tuple slot 926 (0x6572c,
    LIVE; the two-argument frame enter).

    The named-profile upsert: each member of the profiles list
    is a single-name-keyed dict {name: data}; a matching name
    has its entry overwritten in place, a missing name gets a
    fresh {profile_name: new_data} member appended. The whole
    read-modify-write has no except clause — unlike
    setUserProfileState the errors here propagate naturally —
    and the success path is the explicit True return.

    [E:] the read side mirrors setUserProfileState exactly:
         getDataPath staged once (GOT_194, 0x65774), called
         argumentless (xor r8d / xor r9d at 0x657ae-0x657b9),
         the result through the -1 a9d48 FORMAT_VALUE
         (r8d=0xffffffff, 0x657c1) and the two-piece
         BUILD_STRING joining '/profile.json' (GOT_845,
         0x657cc, ecx=2) — path = f'{getDataPath()}/profile
         .json' — bound to [rsp+0x88] (0x657f9); open
         (GOT_201, 0x65813) with 'r' (GOT_283,
         0x6585c), encoding='utf-8' (GOT_284 / GOT_285,
         0x65881 / 0x65890) and errors='ignore' (GOT_685 /
         GOT_686, 0x6589f / 0x658ad), the with-machinery, then
         json (GOT_143, 0x65987) .load (GOT_286, 0x659b9) —
         the result binds the data slot [rsp+0x98], proven by
         the dump argument below.
    [E:] the loop — `for profile in data['profiles']:` — the
         first GetItem ('profiles' GOT_843, 0x65d74 emission
         region const stagings, call near 0x65bad) feeds the
         GetIter (GOT_027, 0x65bcf) whose iterator is driven
         by the a9d60 iternext at 0x65c0d with each item
         stored to [rsp+0xa0] (0x65c27). The [rsp+0x78] and
         [rsp+0x80] slots are the profile_name and new_data
         parameters — verified by the in-test and the SetItem
         below.
    [E:] the membership test — `if profile_name in profile:` —
         the a9d30 selector-6 call at 0x65c3a-0x65c66 (r8 =
         profile_name, r9 = the loop item), the standard
         Bool-release gate (the knowledge IsTrue at 0x65bf1
         with ebp, the False-const arm CONST[32] at 0x65c8b)
         branching on truth to 0x65ca2; corpus events 263-280.
    [E:] the update — `profile[profile_name] = new_data` — the
         PyObject_SetItem at 0x65cf6 (rcx = the loop item
         saved to r14 at 0x65ced, rdx = profile_name in rbx,
         r8 = new_data in rdi), then jmp 0x65e6f past the
         append — the compiled break.
    [E:] the exhaustion — no break taken — the PyErr_Occurred
         filter at 0x65d2f (corpus events 208-210) re-fetches
         data['profiles'] (GetItem, 0x65d74) and appends: the
         'append' GetAttr (GOT_250, 0x65dc5 / 0x65dde) over
         the fresh {profile_name: new_data} dict — the a9d18
         kind-3 count-1 build at 0x65e21-0x65e37 (ecx=3,
         r8 = profile_name, r9 = new_data) — the compiled
         for/else; corpus events 233-243.
    [E:] the write — open (GOT_201, 0x65e76) with mode 'w'
         (GOT_833, 0x65ebf) built kind-1 count-2 over the
         reloaded path slot [rsp+0x88] (loaded 0x65eaf) plus the a9d18 kind-3 count-1 kwargs
         encoding='utf-8' (GOT_284 / GOT_285, 0x65ee4 /
         0x65ef3) — note: NO errors kwarg on the write side
         (island 0x65ece-0x65f0c, corpus events 319-332) —
         then the with-machinery (slot enter/exit 0x65f39 /
         0x65f5e, PyCallFunction 0x65f83) binding the file
         slot [rsp+0x90] (0x65f9e), and json.dump — 'dump'
         GetAttr (GOT_689, 0x6609e) with the kind-1 count-2
         args (data [rsp+0x98] at 0x660de, file [rsp+0x90] at
         0x660ee) plus the kind-3 count-1 kwargs indent=2
         (GOT_690 / GOT_478, 0x66114 / 0x66123), the call at
         0x66159.
    [E:] the block exits run through the CONST-1857 dispatch
         (0x661c8) with the triple-None exit args; the success
         return is the explicit CONST[31] True staged at
         0x6625a (corpus events 423-426) — the evidence basis
         of `return True`.
    [E:] the two with-variables occupy different frame slots
         ([rsp+0x88] read-side, [rsp+0x90] write-side) — the
         symtable would reuse one slot for a same-name
         rebind, so the source names are inferred distinct
         (as f / as file); a minor naming flag, structural
         otherwise.
    [E:] no Exception filter exists anywhere in this function
         (corpus: no GOT_77 events in the whole section) —
         the native error paths (0x65ffc) release the frame
         slots and propagate via ret-disp or return None; the
         except-free structure of the shipped body is
         evidence-locked, not copied from the sibling.
    """
    path = f'{getDataPath()}/profile.json'
    with open(path, 'r',
              encoding='utf-8',
              errors='ignore') as f:
        data = json.load(f)
    for profile in data['profiles']:
        if profile_name in profile:
            profile[profile_name] = new_data
            break
    else:
        data['profiles'].append({profile_name: new_data})
    with open(path, 'w',
              encoding='utf-8') as file:
        json.dump(data, file, indent=2)
    return True


def renameUserProfileName(old_name, new_name):
    """Registry L6909. Content: chunk labeled L6952 — recovered
    entirely from the island bytes of chunk 6952 (dump file
    chunk6952_renameUserProfileName_L6909.txt, alignment +0, 168
    events, 856 insns @0x662d0 +3008) — the stream section for
    this function is a merged/absent casualty (corpus header
    only at lines 17829-17831), so this is the island-only
    recovery the span law prescribes. Signature
    ('old_name', 'new_name') [E:] — const-pool tuple slot 720
    (0x662ea, LIVE; the two-argument frame enter).

    The rename: pops the old name's entry out of the matching
    member dict of the profiles list and reinserts it under
    the new name, then repoints the active_profile marker if
    it referenced the old name. A missing old name is a hard
    False return; the success path returns True.

    [E:] the path local: getDataPath is staged exactly once
         (GOT_194, 0x66332) and called argumentless (xor r8d
         / xor r9d at 0x6636c-0x66377), the result through
         the -1 a9d48 FORMAT_VALUE (r8d=0xffffffff, 0x6637f)
         and the two-piece BUILD_STRING joining
         '/profile.json' exactly once (GOT_845, 0x6638a,
         ecx=2 at 0x66399) — path = f'{getDataPath()}/
         profile.json' per the FORMAT_VALUE + BUILD_STRING
         law — with the result bound to [rsp+0x88]
         (0x663b7); both open calls take that slot as their
         first argument (the write side's kind-1 count-2
         build loads r8 = [rsp+0x88] at 0x66c8e) — the
         single staging proves a single evaluation, the
         bound-name path local.
    [E:] the read: open staged (GOT_201, 0x663d1) with 'r'
         (GOT_283, 0x6641a), encoding='utf-8' (GOT_284 /
         GOT_285, 0x6643f / 0x6644e) and errors='ignore'
         (GOT_685 / GOT_686, 0x6645d / 0x6646b), the with-
         machinery with the CONST-1857 exit dispatch
         (0x66670) over the triple-None args (0x66615), then
         json (GOT_143, 0x66545) .load (GOT_286, 0x66577)
         binding data to [rsp+0x98].
    [E:] found = False [E:] — the [rsp+0xa0] slot is
         initialized to the CONST[32] False at
         0x6672d-0x66747 before the loop.
    [E:] the loop — `for profile in data['profiles']:` — the
         GetItem ('profiles' GOT_843, staged 0x66769 with the
         call 0x6677d over [rsp+0x98]) feeds the GetIter
         (0x667ba, the const-pool 27 / GOT_027 family) and
         the a9d60 iternext loop head (0x667f8 / 0x667fb)
         with each item bound to [rsp+0xa8] (0x66812).
    [E:] the membership gate — `if old_name in profile:` —
         the a9d30 selector-6 call (0x66825-0x66851, r8 =
         old_name [rsp+0x78], r9 = the item), the Bool gate
         (0x667dc, ebp, branch 0x66f2) and the False-const
         arm (0x66876-0x66888) continuing the iteration.
    [E:] the rename — `profile[new_name] = profile.pop(
         old_name)` — the .pop GetAttr (GOT_842, 0x668cb /
         0x668e1) over the item, the kind-1 count-1 args
         (old_name, built 0x66936-0x66954), the pop call
         0x66972, then the SetItem at 0x6699b (rcx = the item
         re-staged from [rsp+0xa8] at 0x66896, rdx = new_
         name from [rsp+0x80] at 0x668a5, r8 = the popped
         value); found = True is the [rsp+0xa0] = CONST[31]
         store at 0x669c6-0x669dc.
    [E:] the exhaustion: the PyErr_Occurred filter at 0x668ec
         jumps cleanly to the post-loop gate 0x669f8 — no
         append arm exists here (the upstream save's for/else
         contrast; a rename adds nothing).
    [E:] `if not found: return False` — the post-loop IsTrue
         over [rsp+0xa0] (0x669f8-0x66a21) feeds the
         swapped-const unary-not emission (found loads
         CONST[32] False at 0x66a29; not-found loads CONST[31]
         True at 0x66a55) whose second gate (0x66a5c-0x66a86)
         sends the not-found branch to 0x66ac4: the CONST[32]
         False staged 0x66ace with r13d = 0 and the jump to
         the return tail — the return False.
    [E:] `data.get('active_profile') == old_name` — the
         'get' GetAttr (GOT_47, 0x66aa5 / 0x66ab9) over the
         data slot with the kind-1 count-1 args ('active_
         profile' GOT_925, built 0x66b11-0x66b31) and the
         call at 0x66b4f with r9d = 0 (no kwargs — a single
         argument, no default), then the a9d30 selector-2
         equality (edx=2 at 0x66b5f-0x66b6c, r8 = the get
         result, r9 = old_name loaded 0x66b52), the IsTrue
         (0x66b7e) and the False-const arm (0x66b8e), the
         match arm branching at 0x66bbd-0x66bf6.
    [E:] the repoint — `data['active_profile'] = new_name` —
         the SetItem at 0x66c3b (rcx = data [rsp+0x98]
         loaded 0x66bf6-0x66c03, rdx = 'active_profile'
         staged 0x66c05, r8 = new_name [rsp+0x80] at
         0x66c13); both arms converge into the write at
         0x66bc1 (the jump 0x66c66).
    [E:] the write: open staged (GOT_201, 0x66bc8) with the
         kind-1 count-2 args (path [rsp+0x88] plus 'w'
         GOT_833 staged 0x66c9e, build 0x66cad-0x66cb7) and
         the kind-3 count-1 kwargs encoding='utf-8' (GOT_284 /
         GOT_285, 0x66cc3 / 0x66cd2) — no errors kwarg — the
         with-machinery (slot pair 0x66d38-0x66d46,
         PyCallFunction 0x66d62) binding the file slot
         [rsp+0x90] (0x66d7d), then json (GOT_143, 0x66d9f)
         .dump (GOT_689, 0x66e8d) over (data [rsp+0x98],
         file [rsp+0x90]) with indent=2 (GOT_690 / GOT_478,
         0x66f03 / 0x66f12), the call after, and the CONST-
         1857 exit dispatch at 0x66fb7.
    [E:] the success return is the CONST[31] True staged at
         0x67049 — `return True`.
    [E:] the error tail releases the full slot roster in
         order at 0x66ddd-0x66e3c — [rsp+0x78] old_name,
         [rsp+0x80] new_name, [rsp+0x88] path, [rsp+0x90]
         file, [rsp+0x98] data, [rsp+0xa0] found, [rsp+0xa8]
         the loop item — the seven-symbol map this recovery
         rests on; the r13b flag then propagates or falls
         back (0x66e3c-0x66e6d).
    [E:] the with-variable naming flag: the read side's
         bound-file slot is released at the with-1 exit
         emission and the write side rebinds [rsp+0x90], so
         scope-slot recycling makes a same-name as f twice
         equally consistent here; the distinct read/write
         names are inferred in parallel with saveUserProfile-
         Data where the two slots are simultaneously alive —
         a naming nuance only, the structure is fully locked.
    """
    path = f'{getDataPath()}/profile.json'
    with open(path, 'r',
              encoding='utf-8',
              errors='ignore') as f:
        data = json.load(f)
    found = False
    for profile in data['profiles']:
        if old_name in profile:
            profile[new_name] = profile.pop(old_name)
            found = True
    if not found:
        return False
    if data.get('active_profile') == old_name:
        data['active_profile'] = new_name
    with open(path, 'w',
              encoding='utf-8') as file:
        json.dump(data, file, indent=2)
    return True
