"""
rpc_backups_uptime.py — the drpc replace helper, the JSON backup
loaders, the themes-dir scanner, and the readable-uptime
formatter. Registry neighborhood L5759..L5800.

Recovered from the corpus event streams (decomp_streams_all.txt
sections function@L5759 through function@L5800) plus the lane-1
Ghidra raws sppDST:
- spp_span_getFriendsBackup_5769.c -> body of _drpcReplaceValue
- spp_span_getServersBackup_5776.c -> body of getFriendsBackup
- spp_span_getAppData_6015.c      -> body of getReadableUptime
(the label on a span file names the NEXT registry function; the
bytes inside are the previous function's body — the established
span law).

Notable live signatures from the stream stubs: _drpcReplaceValue
takes (match, askAI) — the substitute map is literally named
askAI; getThemesData takes zero args.
"""

import json
import os
import time


def _drpcReplaceValue(match, askAI):
    """Registry L5759. Content: chunk labeled L5769.

    [E:] signature (match, askAI) — stream stub argcount=2,
         varnames=('match', 'askAI'); stub names contain the
         __armor_wrap__ marker; const-slot neighbors ('match',
         'values') at slot 1076 belong to this frame family.
    [E:] GetAttr 'get' (slot 47, events 29-49) on the askAI
         mapping; GetAttr 'group' (slot 232, events 54-100) on
         the match object, called with int 1 (slot 233, call
         r8=1) then with int 0 (slot 277) — match.group(1) and
         match.group(0); the 2-args build kind-1 count-2 at
         events 104-106 hands both to the .get call
         (SUBGOT_a9d20, event 123 region in the 5769 raw lines
         49-112): askAI.get(match.group(1), match.group(0)).
    [E:] compare SUBGOT_a9d30 with the None const staged
         (events 123-129, raw 0x51fe0 region; the a9d30 frame
         arg is 8 — the None-compare slot, translated `is None`;
         the == slot is 2 per the established selector law) —
         then a bool-denormalize pair (IsTrue + False const,
         events 136-144).
    [E:] the not-None branch stages the `str` builtin (slot
         150, events 146-156) and calls it with the value (1
         positional); the None branch increfs the empty-string
         const (slot 241, events 167-168) as the result — i.e.
         return '' when the lookup misses to None, else
         str(value).
    """
    value = askAI.get(match.group(1), match.group(0))
    if value is None:
        return ''
    return str(value)


def getFriendsBackup(name):
    """Registry L5769. Content: chunk labeled L5776.

    [E:] argcount=1 (stream stub); the formal's name did not
         survive the stub dump (varnames carry the armor marker)
         — `name` is a neutral carrier, flagged.
    [E:] path build: getDataPath() staged+called (slot 194,
         events 39-50), then the 4-piece join SUBGOT_a9d48
         (event 60) with pieces str(getDataPath()),
         '/backups/' (slot 1072, events 56-58), str(<name>) and
         '/friends.json' (slot 1075, events 65-67) — the
         str-convert stage idiom (0, X, 0xffffffff, 0) on both
         arg pieces (5776 raw lines 53-69).
    [E:] os staged (slot 34) -> .path (165) -> .exists (193)
         (events 79-108), called with the path; the exists
         result is bool-denormalized (True/False slots 31/32,
         events 120-129) and the NOT-exists outcome returns
         None (5776 raw lines 134-144, 293-301).
    [E:] open staged (slot 201, events 131-150) with kwargs
         build kind-3 count-2: encoding='utf-8' (slots
         284/285), errors='ignore' (slots 685/686) — open(path,
         encoding='utf-8', errors='ignore') (5776 raw lines
         145-178).
    [E:] full with-block machinery: a9d50 stage frames 4/5
         fetch __enter__/__exit__ (events 180-182), CallFunction
         on __enter__ gives the handle; json staged (slot 143)
         -> .load (slot 286) called with the handle (events
         197-220); __exit__ called with the GOT_1857 marker and
         three None slots (events 226-233, raw 0x5260x
         region); exception-path ret-dispatch + a9d40 unwind
         (events 222-223). Returns json.load(f).
    """
    path = str(getDataPath()) + '/backups/' + str(name) \
        + '/friends.json'
    if not os.path.exists(path):
        return None
    with open(path, encoding='utf-8', errors='ignore') as f:
        return json.load(f)


def getServersBackup(name):
    """Registry L5776. Content: chunk labeled L5783.

    [E:] argcount=1 (stream stub, armor-polluted varnames —
         name flagged as above); signature and body are the
         identical family shape of getFriendsBackup — the
         corpus section function@L5776 (events 1-113) matches
         the getFriendsBackup stream line for line except the
         filename const.
    [E:] the only deltas: '/servers.json' (slot 1074, events
         65-67) replaces '/friends.json'.
    """
    path = str(getDataPath()) + '/backups/' + str(name) \
        + '/servers.json'
    if not os.path.exists(path):
        return None
    with open(path, encoding='utf-8', errors='ignore') as f:
        return json.load(f)


def getGIFsBackup(name):
    """Registry L5783. Content: chunk labeled L5790.

    [E:] argcount=1 (stream stub L05783); identical family
         shape — corpus section function@L5783 matches the
         getFriendsBackup/Servers streams line for line except
         the filename const.
    [E:] the only delta: '/gifs.json' (slot 1073, events
         65-67).
    """
    path = str(getDataPath()) + '/backups/' + str(name) \
        + '/gifs.json'
    if not os.path.exists(path):
        return None
    with open(path, encoding='utf-8', errors='ignore') as f:
        return json.load(f)


def getThemesData():
    """Registry L5790. Content: chunk labeled L5800.

    Zero-arg (stream stub argcount=0). Scans the themes
    directory and collects the entry names.

    [E:] getDataPath() staged+called (slot 194, events 37-50)
         then '/themes' (slot 728, events 50-51) — the
         directory string built as str(getDataPath()) +
         '/themes' (2-piece join; the exact piece count beyond
         that is not pinned — flagged).
    [E:] os staged -> .listdir (slot 280, events 60-76 with
         GetIter at event 88) and SUBGOT_a9d60 iternext (event
         91) — the loop `for entry in os.listdir(path)`.
    [E:] loop body: os staged -> .path -> .join (slot 166,
         events 99-129) called on the dir + entry; os ->
         .isfile (slot 282, events 149-179) with an IsTrue
         guard (event 186); the entry-name 'endswith' (slot
         236, events 191-208) against '.json' (slot 729,
         events 213-214) with IsTrue (events 218-221).
    [E:] os staged -> .path -> .splitext (slot 875, events
         241-251) called on the entry with PyObject_GetItem
         index 0 (slot 277, event 269) — os.path.splitext(f)[0];
         collected via list 'append' (slot 250, events
         281-302).
    [E:] tail: iternext at event 317, PyErr_Occurred (320),
         None slots (339-348) with ret-dispatch (341) —
         returns the collected list (None on the empty/error
         exit per the standard family tail).
    """
    names = []
    for f in os.listdir(str(getDataPath()) + '/themes'):
        full = os.path.join(str(getDataPath()) + '/themes', f)
        if os.path.isfile(full):
            if f.endswith('.json'):
                names.append(os.path.splitext(f)[0])
    return names


def getReadableUptime():
    """Registry L5800. Content: chunk labeled L6015.

    The readable uptime formatter, e.g. '1 day, 2 hours, and 3
    seconds'.

    [E:] int staged (slot 372, raw 36) ; time staged -> .time
         (slot 427, raw 49-68) called with 0 args (raw 72);
         start_time staged as a global (slot 894, raw 73-77);
         SUBGOT_a9d10 binop selector 0x24 = subtraction: time
         .time() - start_time, then int(...) — raw 71-82.
    [E:] arithmetic, all via DAT_000a9d10 (binary-op) frames:
         0x1d = *, 0xc = //, 0x22 = % — raw 79-172:
         days = uptime // (24 * 3600)  (int slots 1062, 1063)
         rem  = uptime %  (24 * 3600)
         hours = rem // 3600
         rem2 = rem % 3600
         minutes = rem2 // 60   (int slot 1035)
         seconds = rem2 % 60
    [E:] parts = [] — a9d18 build kind-2 count-0 (raw line
         180-186).
    [E:] per unit, a compare a9d30 frame-arg 4 vs int 0
         (slot 277), bool-denormalized, then append via
         'append' (slot 250) with the a9d48 str-convert stage
         (0, X, 0xffffffff, 0) and the 3-piece join: str(n) +
         unit + plural — units ' day' (1064), ' hour' (1066),
         ' minute' (1067); the plural piece = compare
         frame-arg 4 vs int 1 (slot 233) choosing 's' (1065)
         or '' (241) — raw 187-563. Selector-4 translated as
         `>` (selector 2 is == per the established law);
         flagged.
    [E:] seconds piece built the same way with ' second'
         (1069) — raw 592-697, inside the only-seconds
         fallback (the nested chain testing days/hours/minutes
         all == 0, raw 435-484) and re-inlined into the two
         and-branches; on the fallback path the function
         returns ', '.join(parts) directly and bVar16
         (join-null check, raw 730-734) guards the return,
         fallback None (None slot 30, raw 1063-1074).
    [E:] tail junction, raw 735-1029: parts.pop() (slot 842,
         no index — pops the last element), stored and
         str-converted; len staged (slot 267) on the post-pop
         list, compare vs int 0: exactly-one-part originally
         -> re-append as popped + ' and ' (slot 1070) + str
         (seconds) + ' second' + plural via the a9d48 5-piece
         join (raw 982-984); more-than-one -> the same with ',
         and ' (slot 1068, raw 931-934). Final return ',
         '.join(parts) (slots 891 + 166, raw 700-730).
    [E:] the exact condition under which the seconds piece is
         appended standalone (translated `if not parts:`) is
         evidenced by the len-based recheck (raw 997-1029)
         jumping into the seconds block; the branch ordering
         between the three exits is contained in the raw's
         nested compare cascade — flagged where translated.
    """
    uptime = int(time.time() - start_time)
    days = uptime // (24 * 3600)
    rem = uptime % (24 * 3600)
    hours = rem // 3600
    rem = rem % 3600
    minutes = rem // 60
    seconds = rem % 60
    parts = []
    if days > 0:
        parts.append(str(days) + ' day'
                     + ('s' if days > 1 else ''))
    if hours > 0:
        parts.append(str(hours) + ' hour'
                     + ('s' if hours > 1 else ''))
    if minutes > 0:
        parts.append(str(minutes) + ' minute'
                     + ('s' if minutes > 1 else ''))
    sec = str(seconds) + ' second' + ('s' if seconds > 1 else '')
    if not parts:
        parts.append(sec)
    elif len(parts) > 1:
        parts.append(parts.pop() + ', and ' + sec)
    else:
        parts.append(parts.pop() + ' and ' + sec)
    return ', '.join(parts)
