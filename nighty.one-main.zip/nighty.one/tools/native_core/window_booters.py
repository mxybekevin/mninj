"""
window_booters.py — the webview window booter functions from the
SPP native core (registry L8035+), recovered from the corpus event
streams plus island dumps. The booter constructs the create-app
OAuth window around the AppCreateApi controller with a loaded-page
closure that injects the one-second URL watchdog the portal class
answers through pywebview.api.url_callback_change.

  createApp() — the window construction + the loaded subscription

FLAG notes: js_source / api / window / on_loaded and all walk
receivers are slot-inferred names (no name consts exist for
locals); the AppCreateApi class itself, its instance call, the
attribute reads into it and the watchdog literal are all
const-live. The api.discordAppLogin() attribute call is
emission-locked (CONST[619) on the instance cell; the registry
carries discordAppLogin@L8383 and @L8452 on the OTHER window
classes but no such member spans inside the AppCreateApi block
(L8089-L8130) and no plain-shell aliasing survives — flagged
exactly as the evidence reads, not corrected.
"""

import logging  # noqa: F401  (module family import parity)


def createApp():
    """Registry L8035. Content: chunk L8057 — recovered from the
    island bytes of chunk 8057 (dump file
    chunk8057_createApp_L8035.txt, per the dumper +0 align, 117
    events, 632 insns, read complete through the autoApp
    prologue), cross-checked against the complete stream section
    (function@L8035, corpus lines 21430-21533, read complete).

    [E:] THE SIGNATURE — a zero-parameter booter: the corpus
        section opens with the closure scaffolding (no GOT_000
        binder event and no names-tuple const anywhere in the
        span — the 0-param = no binder law) — `def createApp():`.
    [E:] THE CELLS — three PyCell_New at 0x79020/0x7903c/0x79055
        binding [rsp+0x90]/[rsp+0x98]/[rsp+0xa0]; the first PyCell
        _Set 0x79084 stores the live 325-byte CONST[717] staged
        0x7906c into the third cell — the watchdog source; corpus
        events 48-58.
    [E:] THE API — the 'AppCreateApi' CONST[718] name-loaded
        through the a9d50 stage (staged 0x790ac, the stage call
        0x790c8) and CALLED zero-argument through the a9d20 at
        0x790f1 (r8d=0) — the instance — stored into the first
        cell by the PyCell_Set at 0x7910d — api = AppCreateApi();
        corpus events 61-74.
    [E:] THE WINDOW — 'webview' CONST[81] name-loaded 0x791c6
        (stage 0x791e2) with GetAttr 'create_window' CONST[112]
        staged 0x791f8 (resolved 0x79212); the title kind-1
        wrapped ('Create app' CONST[719] staged 0x79247) landing
        [rsp+0xe0]; the kwargs pairs staged in order — 'url'
        CONST[114] 0x79279 with the 'https://discord.com/login'
        CONST[115] staged 0x79296 through the a9d48 one-piece
        form (0x7928f-0x792ab), 'width' CONST[116] 0x792ae with
        the CONST[581] 1200 staged 0x792bc, 'height' CONST[118]
        0x792cc with the CONST[582] 1000 staged 0x792db,
        'resizable' CONST[120] 0x792ea with True CONST[31]
        0x792f8, 'frameless' CONST[121] 0x79306 with False
        CONST[32] 0x79315, and 'js_api' CONST[122] 0x79325 with
        the PyCell_Get of the api cell at 0x7935e — the kwargs
        dict built kind-3 with edx=SIX pairs (a9d18 0x793b8-0x793
        ca) and the create_window call at 0x793f9 (r8d=1 the
        title positional, r9d=1 kwargs-present) — the window,
        stored into the second cell by PyCell_Set 0x79420;
        corpus events 76-153.
    [E:] THE BIND — api.set_window(window): the PyCell_Get of
        the api cell 0x7944d with GetAttr 'set_window' CONST[39]
        staged 0x79456, the kind-1 [window] wrap over the window
        cell's PyCell_Get (0x794ad-0x794d2, kind-1 0x794c8) and
        the call 0x794f0; corpus events 155-177.
    [E:] THE CLOSURE — the a9d58 closure factory at 0x7957b with
        r8d=3 capturing the three cells (r9 = the api cell from
        [rsp+0x90] staged 0x79531; the frame pair slots filled
        from the window 0x79541-0x79564 and the js 0x79550) over
        the native meta writes CONST[1816]/[1817]/[1818]
        (0x79504-0x79520: the context pointer, the LOWGOT_79730
        code slot, and the 3-count) producing the closure at
        [rsp+0x88].
    [E:] THE SUBSCRIPTION — GetAttr(window-cell, 'events'
        CONST[126] staged 0x795b7) then GetAttr 'loaded'
        CONST[128] staged 0x79607, the INPLACE a9d10 with r8d=0xE
        over the loaded attribute and the closure (0x79648-0x79
        667), the events reload GetAttr 0x796a4 and the SetAttr
        store at 0x796fb — window.events.loaded += <the>;
        corpus events 186-253.
    [E:] THE CLOSURE BODY — the LOWGOT_79730 frame prologue at
        0x79730; the GOT_009 cell fetches for indexes 0/1/2 into
        [rsp+0x48]/[rsp+0x50]/[rsp+0x58] (0x7977d-0x797b8); the
        GetAttr over the index-0 content with 'discordAppLogin'
        CONST[619] staged 0x797d7 (resolved 0x797f0) and its
        ZERO-ARGUMENT call at 0x7986a — api.discordAppLogin()
        (the attr literal is const-live; the AppCreateApi block
        holds no discordAppLogin span and no plain-shell alias
        exists — the emission is quoted, not corrected); then the
        GetAttr over the index-1 content with 'evaluate_js'
        CONST[41] staged 0x7989a (resolved 0x798b3), the kind-1
        wrap over the index-2 PyCell_Get (0x798ea-0x79913) and
        the one-positional call 0x79931 — window.evaluate_js
        (js_source); corpus events 264-296.
    """
    js_source = (
        '\nconsole.log(`injected`)\n'
        'var previousUrl = window.location.href;\n'
        'function checkUrl() {\n'
        '    var currentUrl = window.location.href;\n'
        '    console.log(`current URL: ${currentUrl}`)\n'
        '    pywebview.api.url_callback_change(currentUrl);\n'
        '    setTimeout(checkUrl, 1000); '
        '// Check every second\n'
        '}\n\n'
        'checkUrl();\n'
        '                ')
    api = AppCreateApi()
    window = webview.create_window(
        'Create app',
        url='https://discord.com/login',
        width=1200,
        height=1000,
        resizable=True,
        frameless=False,
        js_api=api)

    def on_loaded():
        api.discordAppLogin()
        window.evaluate_js(js_source)

    api.set_window(window)
    window.events.loaded += on_loaded


def autoApp():
    """Registry L8057. Content: chunk L8089 — recovered from the
    island bytes of chunk 8089 (dump file
    chunk8089_autoApp_L8057.txt, +0 align, 291 events, 1415
    insns, read complete end-to-end through the next registry
    prologue at 0x7aed0). CORPUS: the function@L8057 stream
    section is EMPTY (corpus lines 21534-21535, line 21535
    blank) — island-only recovery; every const resolved live
    (30 None, 31 True, 32 False, 44 logging, 45 error, 47 get,
    69 run, 145 getConfigData, 146 logins, 147 token, 244 bot,
    265 id, 425 getActiveProfileName, 560 getCurrentAppToken,
    563 getCurrentToken, 574 app, 614
    is_discord_bot_token_valid, 616 reconnect, 672
    requestAppToken, 714 createApp, 715 check_app_id, 716 'App
    token not valid').

    [E:] THE SIGNATURE — a zero-parameter booter: no GOT_000
        binder and no names-tuple const anywhere in the
        1415-insn span (the 0-param = no-binder law, the
        createApp@L8035 precedent) — `def autoApp():`.
    [E:] THE HEAD CACHE — getConfigData() (CONST[145] name load
        0x79a01, a9d50 stage 0x79a1d, zero-arg a9d20 call
        0x79a46) stored [rsp+0x48] at 0x79a56 — the ONLY write
        of that slot; the X2/X3 operands re-read it 0x79c50/
        0x79e99 — config = getConfigData().
    [E:] THE HEAD GATE — one if over three spell-negated or
        operands (the per-operand NOT-SWAP pairs are the
        JUMP_IF_TRUE_OR_POP + UNARY_NOT emission): X1 =
        config['logins'][getActiveProfileName()].get('app')
        (GetItem 0x79a90, the 425 stage 0x79af4/call 0x79b2d/
        GetItem 0x79b43, the .get GetAttr 0x79b77 with the
        kind-1 CONST[574] build 0x79b96-0x79bb6, call 0x79bd4
        r8d=1); IsTrue 0x79be6, False staged 0x79c01, falsy
        side True 0x79c12, re-IsTrue 0x79c27, jne 0x7ad51 at
        0x79c43. X2 = the cached walk ['app'] (GetItem 0x79d3f)
        .get('id') (build 0x79d9d, call 0x79dd4), the pair
        0x79e01/0x79e0a, const-IsTrue 0x79e1c: falsy je
        0x79e89, truthy falls to the join. X3 = the IDENTICAL
        ['app'].get('id') walk (GetItem 0x79f88, build
        0x79fe6, call 0x7a01d) with the pair 0x7a04a/0x7a09d
        and the value-test jns 0x79e2f at 0x7a0a back-joining
        the same join; the join re-IsTrue 0x79e2f-0x79e32 with
        jne 0x7ad51 at 0x79e4e and the falsy fall 0x79e54 —
        `if not X1 or not X2 or not X3:` (X2===X3 — flagged).
    [E:] THE HEAD BODY — createApp (CONST[714] staged 0x7ad51,
        plain stage 0x7ad68-0x7ad78, the shared zero-arg call
        tail 0x7ae35-0x7ae51) + the explicit return None
        (CONST[30] staged 0x7ae88; reached by the jne edges
        0x79c43/0x79e4e/0x7ad21) — createApp(); return None.
    [E:] THE AND-CHAIN — the join's falsy side 0x79e54 stages
        a FRESH getConfigData() (stage 0x79e7b, call 0x7a073)
        and walks ['app'].get('id') (GetItems 0x7a092/0x7a13d/
        0x7a171, GetAttr 0x7a1a9, build 0x7a1c8, call
        0x7a206) = X4; IsTrue 0x7a218: falsy je 0x7a40e
        KEEPING X4 (re-IsTrue 0x7a411, decref 0x7a41c), truthy
        POPs (DecRef 0x7a22f) into the X5 walk 0x7a235+
        (fresh getConfigData() 0x7a258/0x7a283, chain
        0x7a2a2/0x7a325/0x7a359) .get('token') (build 0x7a3b7,
        call 0x7a3ee), the join's jne 0x7a42d — `if X4 and
        X5:`.
    [E:] THE VALID SIDE — the join-truthy 0x7a45d stages
        is_discord_bot_token_valid (CONST[614] 0x7a464, stage
        0x7a480) over getCurrentAppToken() (CONST[560] 0x7a4f9,
        stage 0x7a515, zero-arg call 0x7a53e, the re-wrap
        0x7a541-0x7a54e, call 0x7a56d r8d=1), result parked
        [rsp+0x50] 0x7a57e; IsTrue 0x7a5a4 with the PLAIN
        truthy jne 0x7a79e at 0x7a5c0 (no not-const) runs
        bot.run (bot CONST[244] stage 0x7a7c5, 'run' GetAttr
        0x7a8e1) with the kwargs kind-3 two-pair build
        0x7a965-0x7a99b (pair 1 'token' 0x7a907 +
        getCurrentToken() 0x7a938/0x7a962; pair 2 'reconnect'
        616/True 31 at 0x7a965/0x7a973 into the frame
        0x7a981/0x7a986) and the call 0x7a9ba r8d=0/r9d=1 —
        bot.run(token=getCurrentToken(), reconnect=True) — then
        jne 0x7ae58 at 0x7a9c0 to the None tail: return None.
    [E:] THE INVALID SIDE — the IsTrue falsy fall 0x7a5c6
        stages the fresh walk (call 0x7a888, chain 0x7a8af/
        0x7abf2, the getActiveProfileName call 0x7abdc/0x7ac26/
        0x7ac5e) .get('id') (build 0x7ac7d, call 0x7acbb) =
        X8; IsTrue 0x7accd: falsy je 0x7ad23 (straight to the
        logging tail), truthy jmp 0x7a770 — the BACKWARD join
        into the check-app-id block (the emitter's dedup of
        the identical second copy — flagged).
    [E:] THE AND-ELSE — the join's falsy fall 0x7a42f stages
        the fresh walk (call 0x7a4ab, chain 0x7a4d2/0x7a65d/
        0x7a6a7/0x7a6df) .get('id') (build 0x7a6fe, call
        0x7a73c) = X6; IsTrue 0x7a74e: falsy je 0x7ae61 — the
        SILENT exit to the cleanup/None epilogue, truthy falls
        inline into the check-app-id block.
    [E:] THE CHECK-APP-ID BLOCK — check_app_id (CONST[715]
        staged 0x7a793) over a FRESH walk's
        ['app'].get('id') (getConfigData() 0x7a808/0x7a833,
        chain 0x7a85a/0x7aa43/0x7aa78/0x7aab1, the ('id')
        build 0x7aad7, inner call 0x7ab0e, re-wrap
        0x7ab11-0x7ab1e, call 0x7ab3d r8d=1) gated by the
        not-swap (IsTrue 0x7ab4f, True staged 0x7acf0 on the
        falsy side, False 0x7ab6e, re-IsTrue 0x7ad05, jne
        0x7ad51 at 0x7ad21) — `if not check_app_id(...):
        createApp(); return None`.
    [E:] THE LOGGING TAIL — logging (CONST[44] stage 0x7ad46)
        .error (CONST[45] GetAttr 0x7adaa) over 'App token not
        valid' (CONST[716], kind-1 wrap 0x7adc9-0x7adeb, call
        0x7ae07, result discarded 0x7ae16) then requestAppToken
        () (CONST[672] staged 0x7ae23, routed 0x7ae2d into the
        shared stage/call tail) — entered by the check-truthy
        fall, the X8-falsy je 0x7ad23 and the else-path's
        in-body fall; then the implicit None (cleanup
        0x7ae58-0x7ae76, the CONST[30] stage 0x7ae88, epilogue
        0x7aebb).
    [E:] THE ERROR EXITS — every raising path routes to
        0x7ae98: the [rsp+0x48]/[rsp+0x50] decrefs
        0x7ae98-0x7aeb3 and the a9d28 ret-dispatch with ecx=1.
        NO DAT_a9d40 fetch and no match const: NO try/except;
        no a9d60 iternext: no loops (the 0x7aceb backward jump
        is a dedup join, not a loop head); no a9d48 builders;
        no a9d30 compares — every gate is truthiness.

    FLAG: config is a name-inferred local ([rsp+0x48] written
        once 0x79a56, re-read by X2/X3, decref'd at both exits).
    FLAG: the X2===X3 head duplication is byte-identical
        ('id' builds 0x79d9d/0x79fe6, 'app' GetItems
        0x79d3f/0x79f88) — likely a copy-paste in the original
        source, emitted as-is.
    FLAG: all .get(...) calls take ONE positional (ecx=1/
        edx=1 builds, r8d=1/r9d=0 calls) — the True/False consts
        are the not-swap materializations, NOT default args.
    FLAG: the is_discord_bot_token_valid gate's truthy jne is
        plain (no not-const): a positive if; whether the
        invalid side is its else-arm or post-return code is
        emission-indistinguishable — the code-after form
        matches the get_bot_token@L5654 sibling.
    FLAG: three source regions share physical blocks (the
        check-app-id block 0x7a770-0x7ad21 entered inline and
        via the backward jmp; the logging tail; the
        createApp/requestAppToken stage-call tail) — 6 physical
        getConfigData() emissions serve 7 source spellings.
    FLAG: the X8-falsy routes to the logging tail while the
        X6-falsy routes silently — the logging sits OUTSIDE the
        X8-if but INSIDE the X6-if, edge-locked.
    """
    config = getConfigData()
    if not config['logins'][getActiveProfileName()].get('app') or \
            not config['logins'][getActiveProfileName()]['app'] \
            .get('id') or \
            not config['logins'][getActiveProfileName()]['app'] \
            .get('id'):
        createApp()
        return None
    if getConfigData()['logins'][getActiveProfileName()]['app'] \
            .get('id') and \
            getConfigData()['logins'][getActiveProfileName()]['app'] \
            .get('token'):
        if is_discord_bot_token_valid(getCurrentAppToken()):
            bot.run(token=getCurrentToken(), reconnect=True)
            return None
        if getConfigData()['logins'][getActiveProfileName()]['app'] \
                .get('id'):
            if not check_app_id(getConfigData()['logins']
                               [getActiveProfileName()]['app']
                               .get('id')):
                createApp()
                return None
        logging.error('App token not valid')
        requestAppToken()
    else:
        if getConfigData()['logins'][getActiveProfileName()]['app'] \
                .get('id'):
            if not check_app_id(getConfigData()['logins']
                               [getActiveProfileName()]['app']
                               .get('id')):
                createApp()
                return None
            logging.error('App token not valid')
            requestAppToken()
