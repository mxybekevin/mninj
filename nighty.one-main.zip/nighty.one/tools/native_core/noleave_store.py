"""
noleave_store.py — Nighty's no-leave (anti-disconnect) family from the
SPP native core, translated with per-statement evidence.

Data shape: noleave.json = { str(group_id): [str(user_id), ...] }

Recovery-method note: the earlier "zero events" reading of chunk L886
was a capstone-stall artifact (the chunk begins mid-instruction); the
resync walker recovers its stream, and clearNoLeaveData ships below.
saveNoLeaveData (registry L816) ships in settings_store.py.
"""

import json


def getNoLeaveData():
    """Registry L820. Content: chunk labeled L832.

    [E:] open(noleave_path, 'r', encoding='utf-8', errors='ignore')
         + json.load ('noleave_path' explicitly staged, dossier L00832).
    [E:] isinstance-dict check and raise ValueError('noleave.json is
         not an object') are INSIDE the try (const order matches the
         getVoiceMuteConfig pattern).
    [E:] except Exception -> saveNoLeaveData(<restore>) then fall
         through and return data.
    [E:] the restore payload is dispatcher-built (no const, no
         PyDict_New in the stream); {} per the isinstance-dict
         invariant — inferred, flagged.
    """
    try:
        with open(noleave_path, 'r', encoding='utf-8',
                  errors='ignore') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError('noleave.json is not an object')
    except Exception:
        data = {}
        saveNoLeaveData(data)
    return data


def isNoLeaveLocked(group_id, user_id):
    """Registry L832. Content: chunk labeled L836.

    [E:] signature tuple ('group_id', 'user_id') — TWO arguments
         (verified by the entry varnames dispatch; earlier drafts
         assumed one arg, the stream is authoritative).
    [E:] consts: 'str' x2, 'getNoLeaveData', 'get'; the IsTrue/False
         pair is the CONTAINS test returned as a bool.
    [E:] no default argument for .go visible in the const stream;
         translated bare like its sibling getNoLeaveUsers (whose
         disasm showed an empty kwargs map + one positional arg) —
         flagged.
    """
    return str(user_id) in getNoLeaveData().get(str(group_id))


def toggleNoLeave(group_id, user_id):
    """Registry L836. Content: chunk labeled L854.

    [E:] signature tuple ('group_id', 'user_id').
    [E:] getNoLeaveData() result stored to a frame slot ([rsp+0x68]);
         then a 2-tuple build + GetIter 2-way unpack of
         str(group_id), str(user_id) (dossier 0xcea4-0xcf25).
    [E:] .get chain, then membership IsTrue and two write-back
         branches: 'remove' + SetItem + saveNoLeaveData + return False,
         vs 'append' + SetItem + saveNoLeaveData + return True
         (bool consts at events 70/74).
    [E:] a ('pop', None) pair in the removal region suggests an
         empty-group cleanup data.pop(gid, None) — partially resolved,
         not translated, noted.
    [E:] .get default not const-visible ([] inferred, flagged).
    """
    data = getNoLeaveData()
    gid, uid = str(group_id), str(user_id)
    group = data.get(gid, [])
    if uid in group:
        group.remove(uid)
        data[gid] = group
        saveNoLeaveData(data)
        return False
    group.append(uid)
    data[gid] = group
    saveNoLeaveData(data)
    return True


def getNoLeaveUsers(group_id):
    """Registry L854. Content: chunk labeled L858.

    [E:] signature tuple ('group_id',).
    [E:] consts: 'getNoLeaveData', 'get', 'str'; the disasm tail
         (0xd729-0xd796) stages the bound .get with an EMPTY kwargs
         map and exactly one positional arg — .get(str(group_id))
         with NO default — and returns the raw result directly
         (mov rax, rsi at 0xd7b6).
    """
    return getNoLeaveData().get(str(group_id))


def clearNoLeaveData():
    """Registry L858. Content: chunk labeled L886.

    [E:] RECOVERED via the resync walker (naive scans stalled on the
         mid-instruction chunk start): const 'saveNoLeaveData' staged
         (0xd813), the call op (0xd82f, the 0xa9d50 pattern),
         Py_DecRef, the dispatcher build (slot 0xa9d18, 0xd845),
         Py_DecRef, guard-epilogue (PyErr_Occurred/PyErr_Clear) with
         const None (0xd8a1), return op (0xd8b6).
    [E:] the payload is dispatcher-built (no const, no PyDict_New
         visible); {} by the noleave.json isinstance-dict invariant —
         inferred, flagged.
    [E:] census correction: the 256B chunk carries 6 window events +
         3 sub-GOT refs — normal SPP code, NOT an armed placeholder.
    """
    saveNoLeaveData({})
