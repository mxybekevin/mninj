"""
script_engine.py - the script engine family from the SPP native
core (registry L4599-L5029), recovered via the Ghidra decomp lane
plus the 2026-10-15 interior-island dumps (chunk keys 4628 and
5040 decode at alignment +0 - the earlier merged/absent verdicts
were boundary artifacts).

  getScriptCodeData(filename)        - module-level: the
                                        os.walk source reader
  getLocalScripts()                  - module-level: the disk scan
  get_metadata_from_decorator(code)  - module-level: the
                                        @nightyScript walker
  class ScriptManager                - the _injected_scripts base
                                        (NAME FLAG: descriptive - the
                                        class name is not recovered;
                                        its subclass ScriptEngine IS
                                        live, GOT_865)
  class ScriptEngine(ScriptManager)  - the evidenced engine
                                        incl. the recovered
                                        deject_all (L5029)


Inheritance note [E:]: the module-level getLocalScripts calls
ScriptEngine.get_running_scripts() (GOT_865 + GOT_1195) while
get_running_scripts reads self._injected_scripts — initialized
by the ScriptManager ctor (L4655), NOT by the ScriptEngine ctor
(L5007, which adds max_injections + _injected_methods). The
hasattr-guarded inits in both ctors + the call site infer the
subclass relation (flagged as inference).
"""

import ast
import os


class ScriptManager:
    """The injected-scripts manager base (registry L4655-L4686).

    NAME FLAG: 'ScriptManager' is a readability label — the
    class name is not recovered from the const pool; the
    subclass name 'ScriptEngine' (GOT_865) is live.
    """

    def __init__(self):
        """Registry L4655 (the script-manager family's ctor —
        shared with the getScriptCodeData / deject family).
        Content: chunk labeled L4672 (raw
        spp_span_deject_4672.c, read end-to-end). Signature
        ('self',) [E:]-flagged (no further argument slots
        surface in the raw).

        [E:] `if not hasattr(self, '_injected_scripts'):` — the
             hasattr global (GOT_1174) + the (1,2) args build
             over (self, '_injected_scripts' GOT_1203, raw
             L36-46) + the inverted const-select pair
             (True/False GOT_031/032, raw L51-58) = the `not`.
        [E:] self._injected_scripts = {} — the (3,0) EMPTY-DICT
             build (raw L82) + SetAttr (raw L89); silent None
             tail (raw L99-101).
        """
        if not hasattr(self, '_injected_scripts'):
            self._injected_scripts = {}

    def deject(self, scriptname):
        """Registry L4672. Content: chunk labeled L4679 (the
        lane-2 resync sppL2_deject_all_4679.c — span labels name
        the NEXT function; this body belongs to deject@L4672).
        Signature ('self', 'scriptname') [E:] — const-pool tuple
        slot 1205.

        [E:] gate: `if scriptname not in self._injected_scripts:
             return None` — the a9d30 selector-6 contains-op
             over (scriptname, self._injected_scripts) (GetAttr
             GOT_1203, raw L38-76) + the silent-None exit.
        [E:] entry = self._injected_scripts[scriptname]
             (GetItem, L96-105); methods = entry['methods']
             ('methods' GOT_530, L106-115); iterate (GetIter +
             a9d60 loop, L116-176): hasattr(self, method)
             ('hasattr' GOT_1174 + the (1,2) args build over
             self + the loop method, L127-149) and on truth
             delattr(self, method) ('delattr' GOT_1206 + the
             same pair, L150-174).
        [E:] finally `del self._injected_scripts[scriptname]` —
             PyObject_DelItem (GOT_016, raw L210) with a second
             reload of the attr; success -> silent None with
             PyErr clear (L214-228).
        """
        if scriptname not in self._injected_scripts:
            return None
        entry = self._injected_scripts[scriptname]
        for method in entry['methods']:
            if hasattr(self, method):
                delattr(self, method)
        del self._injected_scripts[scriptname]
        return None

    def deject_all(self):
        """Registry L4679. Content: chunk labeled L4683 (stream
        section function@L4679).

        [E:] `for scriptname in list(self._injected_scripts.
             keys()): self.deject(scriptname)` — the list() wrap
             (GOT_344 + the (1,1) build, L32-48), the attr (GOT_
             1203, L46-58), 'keys' (GOT_837, L68-74), GetIter +
             loop (L83-125), self.deject GetAttr (GOT_1204,
             L92-109) + the 1-arg call (L113); silent None with
             PyErr clear (L129-142).
        """
        for scriptname in list(self._injected_scripts.keys()):
            self.deject(scriptname)
        return None

    def get_running_scripts(self):
        """Registry L4683. Content: chunk labeled L4686 (stream
        section function@L4683).

        [E:] return list(self._injected_scripts.keys()) — the
             same list/attr/keys chain (GOT_344/1203/837, L23-65)
             feeding a single return-op (L76); no error-clear
             cluster — the result is returned directly.
        """
        return list(self._injected_scripts.keys())

    def get_metadata(self, code):
        """Registry L4686. Content: chunk labeled L4689 (stream
        section function@L4686). Signature ('self', 'code') [E:]
        — const-pool tuple slot 1201.

        [E:] pure pass-through: get_metadata_from_decorator(code)
             — the module-global name (GOT_1202, L27-31) + the
             (1,1) args build over the `code` parameter (L34) +
             the call; the single return-op at L46.
        """
        return get_metadata_from_decorator(code)


class ScriptEngine(ScriptManager):
    """The script engine (registry L5007-L5029).

    NAME [E:]: 'ScriptEngine' is the live const-pool name
    (GOT_865 — used by getLocalScripts below). The inheritance
    is inferred: the engine's ctor does not initialize
    _injected_scripts, yet getLocalScripts calls
    ScriptEngine.get_running_scripts() (which reads it) — the
    base ctor (L4655) provides it.
    """

    def __init__(self):
        """Registry L5007 (ScriptEngine.__init__). Content:
        chunk labeled L5029 (stream section function@L5007).

        [E:] self.max_injections = 64 (GOT_1173/1172 + SetAttr,
             L31-39); `if not hasattr(self, '_injected_methods'):
             self._injected_methods = set()` — the hasattr global
             (GOT_1174) + '_injected_methods' (GOT_1168) in the
             truth-select (L43-74), then the set() global (GOT_
             384) + SetAttr (L95-112); silent None return.
        """
        self.max_injections = 64
        if not hasattr(self, '_injected_methods'):
            self._injected_methods = set()

    def deject_all(self):
        """Registry L5029. Content: chunk labeled L5040 —
        recovered from the interior bytes of chunk 5040 (dump
        file chunk5040_deject_all_L5029.txt; the 'file
        merged/absent' verdict was a boundary artifact — the
        chunk decodes at alignment +0). Signature ('self',)
        [E:] — const-pool tuple slot 278.

        [E:] for name in list(self._injected_methods): — the
             list() global (GOT_344) + the GetAttr chain
             (GOT_1168 '_injected_methods', 0x49dfc) + the
             (1,1) args build + GetIter + the SUBGOT_a9d60
             loop (0x49e90).
        [E:] gate: `if name in globals():` — the globals()
             global (GOT_1169) called zero-arg (0x49f52) + the
             SUBGOT_a9d30 selector-6 contains-compare (0x49f63).
        [E:] body: `del globals()[name]` — globals() staged
             again (0x49fdd, zero-arg call) + Py_DelItem
             (0x4a029).
        [E:] tail: `self._injected_methods.clear()` — the
             attr re-fetched (GOT_1168, 0x4a0d3) + 'clear'
             (GOT_1170) with a zero-arg call (0x4a14f); then
             the module-global `injected_count` (GOT_1171) is
             reset to 0 (int GOT_277) via the stage store
             (0x4a180-0x4a18b); silent None tail with the
             PyErr clear (0x4a1f4-0x4a215).
        """
        for name in list(self._injected_methods):
            if name in globals():
                del globals()[name]
        self._injected_methods.clear()
        globals()['injected_count'] = 0
        return None


def getScriptCodeData(filename):
    """Registry L4599. Content: chunk labeled L4628 — recovered
    from the interior bytes of chunk 4628 (dump file
    chunk4628_getScriptCodeData_L4599.txt; the 'file
    merged/absent' verdict was a boundary artifact — the chunk
    decodes at alignment +0, 113 events). Signature
    ('filename',) [E:] — const-pool tuple slot 724.

    [E:] path = filename if filename.endswith('.py') else
         filename + '.py' — 'endswith' (GOT_236) with '.py'
         (GOT_874, 0x44fe7), IsTrue-gated; the else arm is the
         a9d10 binop selector-7 concat (0x450a2-0x450c9).
    [E:] os.walk staged (GOT_034 + GOT_162) over str
         (getScriptsPath()) (GOT_725; the a9d48 str-convert
         0x451d0), GetIter (slot 27) + SUBGOT_a9d60 loop; the
         3-tuple unpack runs through GOT_004 (r8d=3) with the
         frame slots dirpath/dirnames/filenames (0x4528f).
    [E:] match gate: `if path in filenames:` — SUBGOT_a9d30
         selector-6 contains (edx=6, 0x4535d) over the
         normalized path and the filenames list.
    [E:] found: `with open(os.path.join(dirpath, path), 'r',
         encoding='utf-8', errors='ignore') as f: return
         f.read()` — os.path.join (GOT_165/166, the (1,2) args
         build 0x4545f-0x45490), open (GOT_201) with 'r'
         (GOT_283) + the kind-3 count-2 kwargs encoding/errors
         (GOT_284/285/685/686, 0x4555e-0x45598), the with-
         machinery (stage slots 4/5 = __enter__/__exit__,
         CallFunction 0x4560e), GetAttr 'read' (GOT_200) with
         the zero-arg call (0x456bf).
    [E:] not found: the walk exhausts clean (PyErr_Occurred
         check at 0x457cb) and the function returns None
         (CONST[30] via 0x457f7).
    """
    path = filename if filename.endswith('.py') \
        else filename + '.py'
    for dirpath, dirnames, filenames in os.walk(
            str(getScriptsPath())):
        if path in filenames:
            with open(os.path.join(dirpath, path), 'r',
                      encoding='utf-8', errors='ignore') as f:
                return f.read()
    return None


def getLocalScripts():
    """Registry L4689. Content: chunk labeled L4707 (stream
    corpus section function@L4689). Signature [E:] () — zero-arg
    store scan.

    [E:] local_scripts built with the REAL PyList_New (GOT_024,
         L45) — a list comprehension emission;
         os.listdir(getScriptsPath()) ('os' GOT_034, 'listdir'
         GOT_280, 'getScriptsPath' GOT_725, L46-91) iterated;
         name.endswith('.py') gate ('endswith' GOT_236, '.py'
         GOT_874, L111-128) with PyList_Append (GOT_018, L133).
    [E:] second pass per kept file: os.path.splitext(<file>)[0]
         ('path' GOT_165, 'splitext' GOT_875, the int-0 index,
         L204-238) = the bare filename; `<filename> in
         ScriptEngine.get_running_scripts()` — the a9d30
         contains-op with the ScriptEngine global (GOT_865) +
         get_running_scripts (GOT_1195), L247-292 = isActive;
         getFileCreatedAt(getScriptsPath() + '/' + file)
         (GOT_1198 + the a9d48 concat, GOT_813, L338-367);
         metadata via ScriptEngine.get_metadata(...) +
         getScriptCodeData (GOT_1199/1200, L385-420); the
         (3,1)/dict-builds append {'name': ..., 'created_at':
         ..., 'isActive': ..., 'metadata': ...} (keys GOT_273/
         957/1196/1197, appends L305-322).
    [E:] flag: dict-build emission order is const-staged; the
         exact kwarg-to-value pairing follows the visible key
         order (name, created_at, isActive, metadata).
    """
    local_scripts = []
    for file in os.listdir(getScriptsPath()):
        if file.endswith('.py'):
            filename = os.path.splitext(file)[0]
            local_scripts.append({
                'name': filename,
                'created_at': getFileCreatedAt(
                    getScriptsPath() + '/' + file),
                'isActive': filename
                              in ScriptEngine
                              .get_running_scripts(),
                'metadata': ScriptEngine.get_metadata(
                    getScriptCodeData(file)),
            })
    return local_scripts


def get_metadata_from_decorator(code):
    """Registry L4628 (module-level — the @nightyScript metadata
    extractor). Content: chunk labeled L4655 (raw
    spp_span___init___4655.c, read end-to-end). Signature
    ('code',) [E:] — const-pool tuple slot 1207 (LIVE) — a
    strict 1-arg module function.

    [E:] the results list initialized first — the (2,0)
         empty-list build (raw L41) in a frame slot that
         survives the whole body.
    [E:] the whole body runs inside the exception machinery
         (DAT_000a9d40, raw L44-72): on an Exception-type error
         the empty-dict (3,0) build (raw L60) is returned via
         the common exit; non-Exception errors re-raise (GOT_002,
         raw L69).
    [E:] tree = ast.parse(code) — ast (GOT_1208) + parse
         (GOT_1209) + the (1,1) args build over the parameter
         (raw L79-104).
    [E:] `for node in tree.body:` — 'body' GetAttr (GOT_1210) +
         GetIter + the a9d60 loop (raw L109-139).
    [E:] the node type gate is TWO separate isinstance calls —
         `if isinstance(node, ast.FunctionDef) or isinstance(
         node, ast.ClassDef):` (raw L144-231: GOT_168 +
         ast.FunctionDef GOT_1211, then the falsy branch
         reloads with ast.ClassDef GOT_1212 — the compiled OR).
    [E:] `for decorator in node.decorator_list:` — decorator_list
         (GOT_1213) + GetIter + a9d60 (raw L231-259);
         `if isinstance(decorator, ast.Call):` (GOT_168 +
         ast.Call GOT_1214, raw L264-307);
         `if decorator.func.id == 'nightyScript':` — the 'func'
         GetAttr (GOT_1215) + the 'id' GetAttr (GOT_265) + the
         a9d30 selector-2 equality vs 'nightyScript' (GOT_1216,
         raw L310-363).
    [E:] per match: metadata = {} (the (3,0) build, raw L364);
         `for keyword in decorator.keywords:` (GOT_1217 +
         GetIter, raw L372-396); `metadata[keyword.arg] =
         ast.literal_eval(keyword.value)` — keyword.arg (GOT_
         1219, raw L408-427) + ast.literal_eval (GOT_1208/1218,
         raw L428-472) over keyword.value (GOT_274) with the
         SetItem; then <list>.append(metadata) — 'append'
         (GOT_250) on the list slot + the (1,1) build over the
         metadata dict (raw L480-515).
    [E:] the return: after both loops, if the list is empty →
         return {} (the (3,0) fallback, raw L548-556); else →
         return <list>[0] — the int-0 GetItem (GOT_277, raw
         L558-580).
    """
    results = []
    try:
        tree = ast.parse(code)
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) or \
                    isinstance(node, ast.ClassDef):
                for decorator in node.decorator_list:
                    if isinstance(decorator, ast.Call):
                        if decorator.func.id == 'nightyScript':
                            metadata = {}
                            for keyword in decorator.keywords:
                                metadata[keyword.arg] = \
                                    ast.literal_eval(
                                        keyword.value)
                            results.append(metadata)
        if results:
            return results[0]
        return {}
    except Exception:
        return {}
