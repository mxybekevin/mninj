"""
mimic_guards.py — shouldSkipMimic + isNSFW, the mimic-protection and
NSFW-allowance guards, recovered from the SPP native core via the
Ghidra decomp lane.

shouldSkipMimic returns a PAIR (all four exits evidenced):
    (False, None)              — empty arg, or the age filter is off
    (True, <blocklist entry>)  — a mimic_blocklist entry matched
                                 (the RAW entry object is returned)
    (True, 'age/minor filter') — an age-pattern matched
    None                       — everything screened, no match (the
                                 compiled fall-through stages None)

Screening rules: entries are `(entry or '').lower().strip()`-cleaned;
entries containing a space are matched as plain substrings of the
lowered arg; single-word entries are matched with
re.search('\\b' + re.escape(entry) + '\\b', name). Then, if
config.get('mimic_age_filter', True), every pattern from the module
global MIMIC_AGE_PATTERNS is searched against the same lowered arg.

isNSFW(read) takes a channel-like object: no guild -> True (DMs are
treated as allowed), config['riskmode'] truthy -> True, otherwise
the literal read.is_nsfw() (the compiled form coerces to bool).
"""

import re


def shouldSkipMimic(showToast):
    """Registry L1510. Content: chunk labeled L1533 (decomp
    spp_span_addEnabledScript_1533.c). Signature ('showToast',)
    [E:] — dossier stub.

    [E:] head: `if not showToast: return (False, None)` — IsTrue of
         the raw arg (L48), the negation select (True/False consts
         L51-53), and the (False, None) tuple const GOT_1637 staged
         as the early exit (L63-73).
    [E:] config = getConfigData() (L59-83, GOT_145);
         name = showToast.lower() computed ONCE and reused
         (GetAttr 'lower' GOT_163 + call L91-113; a single stack
         slot is increfed at every later use).
    [E:] `config.get('mimic_blocklist') or []` — .get GetAttr
         (GOT_047), the (1,1)-call with key 'mimic_blocklist'
         (GOT_1638) L121-149, IsTrue, then the dispatcher-built
         empty container at L157-159 for the falsy side of the
         compiled `or` (dispatcher-built [] — inferred container,
         flagged); GetIter + iterator loop L162-165.
    [E:] per entry: the falsy-entry fallback const '' (slot 241,
         L182-192) — `(entry or '')`; .lower().strip() ('lower'
         + 'strip' GOT_099, L193-225); empty-result skip (L227-248).
    [E:] branch on `' ' in entry_clean` — const slot 243 + the
         SUBGOT_a9d30 contains-op (L249-267; selector 6, the same
         op as the CRUD guards).
    [E:] space branch: a second contains-op over (entry_clean,
         name-lowered) (L359-377) — translated needle-first as
         `entry_clean in name` per the family's staging convention;
         direction flagged. Match -> the (1,2)-build with bool True
         + the RAW entry (in_stack_00000070) -> return (True, entry)
         (L378-389).
    [E:] no-space branch: re.search('\\b' + re.escape(entry_clean) +
         '\\b', name) — 're' GOT_228, 'search' GOT_229, the '\\b'
         const (slot 1639) on both sides via binary-op concats
         (DAT_000a9d10), 'escape' GOT_1640 (L269-340); match ->
         return (True, entry) (L341-355).
    [E:] post-loop: config.get('mimic_age_filter', True) — key
         GOT_1641 with the True default staged (L405-436); if falsy
         -> (False, None) (L443 -> the GOT_1637 exit).
    [E:] age loop: the MIMIC_AGE_PATTERNS global name (GOT_1642,
         LOAD_GLOBAL via the call op) + GetIter (L450-454);
         re.search(pattern, name) per iteration — the subject is the
         SAME lowered-arg slot (L491-496); match ->
         return (True, 'age/minor filter') — the exact tuple const
         GOT_1643 (L502-511; note the '/' hidden by label
         sanitization).
    [E:] fall-through: None (L525-537 — the iVar12==1 path stages
         const None into the return op).
    """
    if not showToast:
        return (False, None)
    config = getConfigData()
    name = showToast.lower()
    blocklist = config.get('mimic_blocklist') or []
    for entry in blocklist:
        entry_clean = (entry or '').lower().strip()
        if not entry_clean:
            continue
        if ' ' in entry_clean:
            if entry_clean in name:
                return (True, entry)
        else:
            if re.search('\\b' + re.escape(entry_clean) + '\\b', name):
                return (True, entry)
    if not config.get('mimic_age_filter', True):
        return (False, None)
    for pattern in MIMIC_AGE_PATTERNS:
        if re.search(pattern, name):
            return (True, 'age/minor filter')
    return None


def isNSFW(read):
    """Registry L1808. Content: chunk labeled L2051 (decomp
    spp_span_getSlashCommand_2051.c — the registry-offset gap places
    isNSFW's body in the chunk labeled by the next registry entry).
    Signature ('read',) [E:] — dossier stub.

    [E:] config = getConfigData() (L24-47, GOT_145);
         guild = read.guild (GetAttr GOT_289, L48-68);
         `if not guild: return True` — IsTrue L70, and the
         LAB_00021d48 exit stages const True (L75-78);
         riskmode = config['riskmode'] (GetItem GOT_1599, L88-103);
         riskmode truthy -> return True (L141-144); riskmode falsy
         -> return read.is_nsfw() — GetAttr 'is_nsfw' GOT_1600
         (L130) + the 0-arg call (L136) + the IsTrue-based
         True/False select (L138-147; the compiled form coerces to
         bool — the property/method call is translated verbatim).
    """
    config = getConfigData()
    if not read.guild:
        return True
    if config['riskmode']:
        return True
    return read.is_nsfw()
