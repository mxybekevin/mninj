"""
nighty_curl_compat.py — the Nighty curl-selector compatibility
patches (registry L189-L340), recovered via the Ghidra decomp
lane.

Naming per the const pool: the _nighty_* trio = patched
replacements installed over a curl-based selector class;
_cc_orig_release_curl (a MODULE global, slot 1747) = the saved
original release method (the patching idiom's saved original —
its const name is itself the evidence).

  _nighty_handle_select (L189) — sig slot 1748 ('self','rs','ws')
  _nighty_release_curl  (L246) — sig slot 1745 ('self','curl')
  _nighty_eb_init        (L340) — sig slot 1741 ('self','_orig')
"""

import logging


def _nighty_handle_select(self, rs, ws):
    """Registry L189. Content: chunk labeled L246 (raw
    spp_span__nighty_release_curl_246.c, read end-to-end; the
    off-by-one span law — the file labeled 246 carries this
    body). Signature ('self', 'rs', 'ws') [E:] — const-pool
    tuple slot 1748 (LIVE).

    [E:] the readers loop: GetIter over rs (raw L40-47), per
         item `self._handle_event(<item>, self._readers)` —
         the '_handle_event' GetAttr on self (GOT_1749, raw
         L63-71) + the '_readers' GetAttr on self (GOT_1750,
         raw L81-98) + the 2-element args build (raw L101) +
         the call (raw L102); on call failure the exception
         machinery (DAT_000a9d40, raw L104+) with the
         isinstance(exc, Exception) probe (a9d30 selector-10) →
         logging.exception('[curl selector] reader callback
         failed (ignored)') — logging (GOT_044) + exception
         (GOT_049) + the EXACT message GOT_1751 with a single
         (1,1) message arg (NO exception argument —
         logging.exception auto-captures exc_info).
    [E:] the writers loop mirrors it over ws (GetIter raw
         ~L160-163): `self._handle_event(<item>, self._writers)`
         (GOT_1752) → logging.exception('[curl selector] writer
         callback failed (ignored)') (GOT_1753, EXACT).
    [E:] the re-arm: `if not getattr(self, '_closed', False):`
         — the 3-arg getattr build (GOT_662 getattr +
         '_closed' GOT_1754 + False GOT_032, raw L287-302) +
         the inverted const-select/IsTrue pair (raw L305-315)
         → `self._start_select()` — the 0-ARG call (GOT_1755,
         raw L316-340) in the exception machinery → on
         Exception-type failures
         logging.exception('[curl selector] re-arm skipped')
         (GOT_1756, EXACT, raw L361-395); non-Exception errors
         re-raise (GOT_002 raw L398/L413/L436); silent None
         tail.
    """
    for r in rs:
        try:
            self._handle_event(r, self._readers)
        except Exception:
            logging.exception('[curl selector] reader callback '
                              'failed (ignored)')
    for w in ws:
        try:
            self._handle_event(w, self._writers)
        except Exception:
            logging.exception('[curl selector] writer callback '
                              'failed (ignored)')
    if not getattr(self, '_closed', False):
        try:
            self._start_select()
        except Exception:
            logging.exception('[curl selector] re-arm skipped')
    return None


def _nighty_release_curl(self, curl):
    """Registry L246. Content: chunk labeled L340 (raw
    spp_span__nighty_eb_init_340.c, read end-to-end — the file
    labeled 340 carries this body). Signature ('self', 'curl')
    [E:] — const-pool tuple slot 1745 (LIVE).

    [E:] `if getattr(curl, '_nighty_pooled', False):` — the
         3-arg getattr build (GOT_662 + '_nighty_pooled'
         GOT_1746 + False GOT_032, raw L56-67) + the call (raw
         L68) + IsTrue (raw L71-72); the TRUTHY branch exits
         returning None (raw L76-85) — pooled handles are NOT
         released.
    [E:] `curl._nighty_pooled = True` — the SetAttr on the
         curl frame slot (True GOT_031, raw L87-103).
    [E:] `_cc_orig_release_curl(self, curl)` — the saved
         original loaded as a MODULE global by name (GOT_1747,
         raw L107-116) + the 2-arg args build over the self +
         curl frame slots (raw L118-125) + the call (raw L126).
         The module-level global is the patching idiom's saved
         original (the un-released original method of the
         patched class); silent None tail (raw L143-162).
    """
    if getattr(curl, '_nighty_pooled', False):
        return None
    curl._nighty_pooled = True
    _cc_orig_release_curl(self, curl)
    return None


def _nighty_eb_init(self, _orig):
    """Registry L340. Content: chunk labeled L443 (raw
    spp_span_getUUID_443.c, read end-to-end). Signature
    ('self', '_orig') [E:] — const-pool tuple slot 1741 (LIVE).

    [E:] the forwarding call FIRST: the _orig parameter (the
         frame slot 0x60) is CALLED with a 1-positional +
         1-kwarg frame whose positional piece wraps a 1-tuple
         over self (the (1,1) + kind-9 (9,2) builds, raw
         L46-54) — translated as `_orig(self)`. FLAG: the extra
         1-key kwargs dict (the (3,1) build over further frame
         slots 0x68/0x70, raw L56-59) is const-invisible — the
         exact kwarg name/value stays flagged open.
    [E:] THEN the cap — fully evidenced: `self._max =
         min(self._max, 6)` — the '_max' GetAttr on self
         (GOT_1743, raw L84-105) + min (GOT_1742, raw L74-82)
         + int 6 (GOT_1744) + the 2-arg build (raw L109) + the
         min call (raw L111) + SetAttr(self, '_max', <result>)
         (raw L113-116); silent None tail (raw L125-139).
    """
    _orig(self)
    self._max = min(self._max, 6)
    return None
