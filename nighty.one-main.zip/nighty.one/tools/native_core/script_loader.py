"""
script_loader.py — the script engine loader family from the
SPP native core (registry L7237-L7322), recovered from the
corpus event streams plus island dumps.

  loadScripts(first)     — the full unload/reload cycle:
                           sweep custom commands and feature
                           listeners, deject the engine, then
                           reload every enabled script from
                           the scripts directory and its
                           subdirectories through
                           ScriptEngine.inject
  unloadScripts()        — the unload half only, logging
                           through logging.debug
  reloadAllScripts()     — clear custom UI tabs in the
                           renderer, reset the
                           __custom_ui_tabs__ global, then
                           unload + load
  toggleScriptState(toggle, script) — add or remove one
                           script from the enabled set and
                           reload everything

Live constants pinned this family: 'built-in'(856), ' | '
(787), the '# -*- coding: utf-8 -*-\\n' injection prelude
(877), ', ' loaded-list separator (891), 'Unloaded
command: '(858), 'Unloaded event: '(863) and the names
tuples ('first',)(867) / ('toggle', 'script')(847).
"""

import logging
import os
import sys


def loadScripts(first=False):
    """Registry L7237. Content: chunk labeled L7300 (the
    448B manifest label is a lie; the dump header reads
    +16800) — recovered from the island bytes of chunk 7300
    (dump file chunk7300_loadScripts_L7237.txt, alignment
    +0, 798 events, 4066 insns, read in full through the
    next function's prologue at 0x6f4d0), cross-checked
    against the complete stream section (function@L7237,
    corpus lines 18681-19561, read complete).

    [E:] THE ENTRY — the frame prologue with the argument
        binder: the a9d50 entry stage (mov edx, 1 / r8d=2,
        call 0x6b3b3), then the names-tuple CONST[867]
        ('first',) staged 0x6b3ca with the target area
        [rsp+0xa8] (lea 0x6b3d1) and the binder call GOT_000
        at 0x6b3f9 with r8d=1 (the PARAM COUNT law: the
        binder's r8d carries the expected-args count —
        2 for toggleScriptState's pair); test eax, eax /
        jne 0x6ba44 = the arity-mismatch silent None-return
        shim. The first parameter is NEVER read inside the
        emitted body (the [rsp+0xa8] binder target is never
        loaded again). reloadAllScripts@L7315 calls
        loadScripts() bare (the zero-arg call r8d=0 / r9d=0
        at 0x704dc-0x704ef in chunk 7322), proving `first`
        is OPTIONAL; its default VALUE lives in the
        binder-side pydcode table and is absent from the
        event stream (verified: no bool/None const near the
        binder, corpus events 66-71) — shipped as the
        conventional `first=False` with this flag rather
        than a guess, and inert either way since the body
        never reads it.
    [E:] THE COMMAND SWEEP — `for command in bot.commands:
        if not command.extras.get('built-in'):` — the iter
        over bot.commands (GetIter call 0x6b5a2-era, corpus
        events 66-101), the extras GetAttr (GOT_855) with
        the .get (GOT_47) over the 'built-in' key (GOT_856
        staged 0x6b5ab, kind-1 count-1 args 0x6b5ba-0x6b5c4 —
        no default argument), the not-swap emission (the
        CONST[31]/CONST[32] arms at 0x6b60f/0x6b620 with the
        shared gate continuing the loop at 0x6b4c0); the
        removal arm: bot.remove_command (GOT_857 resolved
        0x6b6ae over the staged bot) with the .name GetAttr
        (GOT_273 at 0x6b6e4) as its kind-1 count-1 argument,
        called 0x6b90c-era and result discarded, then
        sys.stdout.write over the f-string '\\nCommand
        unloaded: {command.name}\\n' (chain: GOT_079 'sys'
        staged 0x6bfe1, GOT_098 'stdout' GetAttr 0x6c02b,
        GOT_203 'write' GetAttr 0x6c068; the GOT_868 literal
        staged 0x6b838, the FORMAT_VALUE pair, the '\\n'
        GOT_239).
    [E:] THE LISTENER SWEEP — `for event_name, listeners in
        bot.extra_events.items(): for listener in
        listeners:` — the .items GetAttr (GOT_247 'items',
        staged 0x6ba??, resolved 0x6bb1x) called 0x6bb22,
        the GetIter 0x6bb34 and the (event_name, listeners)
        unpack through GOT_004 (0x6bb86 with the cmp eax, -1
        — event_name to [rsp+0xb8], listeners to
        [rsp+0xc0]), the inner iternext loop head 0x6bc21
        binding the listener to [rsp+0xc8]; the gates — the
        listener.__name__ GetAttr (GOT_509 at 0x6bcb4)
        tested with the a9d30 selector-7 membership against
        bot.config['built_in_events'] (the GOT_245 config
        GetAttr with the GOT_860 GetItem, edx=7 at
        0x6bd93) and then re-fetched and tested against the
        __custom_feature_listeners__ module global (GOT_861
        staged 0x6be52, edx=7 at 0x6be87), both converging
        into the shared gate 0x6bee0 whose falsy side
        continues the inner loop (je 0x6bc3d) — an AND of
        the two memberships; the removal arm: bot.remove_
        listener (GOT_862, GetAttr resolved 0x6bf55) over
        the kind-1 count-2 args — the listener [rsp+0xc8]
        as the FIRST argument and the event_name [rsp+0xb8]
        SECOND (0x6bf7c mov r8, [rsp+0xc8]; 0x6bf8c mov r9,
        [rsp+0xb8]; the ecx=1 / edx=2 build
        0x6bf9e-0x6bfa3; the call 0x6bfc6) — func-first,
        matching the remove_listener(func, name) API order;
        then sys.stdout.write over f'\\nUnloaded event:
        {event_name}: {listener.__name__}\\n' — BUILD_STRING
        (5) at 0x6c175 over the GOT_869 literal, the
        event FORMAT_VALUE 0x6c14e, the ': ' GOT_864, the
        listener FORMAT_VALUE and the '\\n' GOT_239; corpus
        events 306-764.
    [E:] THE DEJECT — try: ScriptEngine().deject_all()
        except Exception: pass — the engine name staged
        (GOT_865, 0x6c266) and called with r8d=0 / r9d=0
        (0x6c291 — the class bootstrap call), the
        .deject_all GetAttr (GOT_866, resolved 0x6c2b0)
        with the zero-arg call 0x6c2df and the result
        discarded; the failure path fetches the exception
        (a9d40 at 0x6c399), runs the a9d30 selector-0xa
        match, releases the triple and resumes at the
        counter init — the silent catch. unloadScripts'
        deject is UNGUARDED (see below) — the guard lives
        here only.
    [E:] THE STATE — count = 0 (CONST[277] into [rsp+0xd0],
        0x6c2f4 with the catch mirror at 0x6c41e), loaded =
        [] (the a9d18 kind-2 edx=0 empty list into
        [rsp+0xd8], 0x6c328), enabled = getScriptsConfig()
        ['enabled'] — the name staged (GOT_870, 0x6c359),
        called argumentless 0x6c453, the 'enabled' GetItem
        (GOT_346, staged 0x6c458, GetItem 0x6c471) binding
        [rsp+0xe0]; corpus events 396-438.
    [E:] THE DIRECTORY SCAN — `for filename in
        os.listdir(f'{getDataPath()}/scripts'):` — the
        os.listdir GetAttr (GOT_280, resolved 0x6c509) over
        the f-string path (the argumentless getDataPath
        call 0x6c585, the FORMAT_VALUE 0x6c596, the
        '/scripts' GOT_871 staged 0x6c599 with the
        BUILD_STRING ecx=2 at 0x6c5a8), the GetIter at
        0x6c5f1 with the loop item binding [rsp+0xe8]
        (0x6c661); the directory test — os.path.join over
        the same f-string plus the filename (the join
        GetAttr 0x6c70b, kind-1 count-2 args 0x6c7c3, call
        0x6c7ef; the '/scripts' GOT_871 staged 0x6c799 again)
        into os.path.isdir (GOT_872 resolved 0x6c8a4, call
        0x6c902) with the truth gate 0x6c913 — the directory
        arm and the file arm split at 0x6c926; corpus events
        450-903.
    [E:] THE SUBDIRECTORY BRANCH — the nested os.listdir
        over f'{getDataPath()}/scripts/{filename}' — three
        FORMAT_VALUE staging points (0x6cb13, 0x6cb24,
        0x6cb54), the '/scripts/' literal GOT_873 (staged
        0x6cb2a) with the BUILD_STRING ecx=3 at 0x6cb3e, the
        listdir call 0x6cb99, the inner GetIter 0x6cbaa and
        the subfile bound to [rsp+0xf8] (0x6cc18); corpus
        events 781-843.
    [E:] THE PY GATE — subfile.endswith('.py') — the
        endswith GetAttr (GOT_236) over the kind-1 ('.py'
        GOT_874) args 0x6ccbc, the call and the je 0x6cea3
        miss release; the enabled gate — os.path.splitext
        (subfile) (GOT_875 chain) with the GetItem index
        CONST[277] 0 at 0x6ce20, tested through the a9d30
        selector-6 `in` against the enabled list (edx=6,
        call 0x6ce5c, the falsy side continuing the inner
        loop at 0x6cc01); corpus events 941-1046. The
        direct-file mirror repeats both gates against the
        filename and enters the second Lock family at
        0x6e023.
    [E:] THE LOAD — `with Lock():` — the Lock global staged
        (GOT_876 at 0x6cecf) and called argumentless
        0x6cf14, the with-machinery slot-4 / slot-5 stages
        0x6cf33 / 0x6cf56 with the PyCallFunction 0x6cf77;
        inside, the open path built as f'{getDataPath()}/
        scripts/{filename}/{subfile}' — BUILD_STRING(5) at
        0x6d0e0 over the FORMAT_VALUE of the argumentless
        getDataPath (0x6d059 call, 0x6d06a convert), the
        '/scripts/' GOT_873 (restaged 0x6d070), the filename
        FORMAT_VALUE, the '/' GOT_813 (staged 0x6d0a4) and
        the subfile FORMAT_VALUE — as the open kind-1
        count-1 argument (0x6d0f1), then the kind-3 count-2
        kwargs encoding='utf-8' and errors='ignore' (GOT_284
        'encoding' staged 0x6d10a, GOT_285 'utf-8' 0x6d119,
        GOT_685 / GOT_686 for errors/ignore), the open call
        0x6d175 with the .read() GetAttr (GOT_200, 0x6d19a)
        and the call binding the read result [rsp+0x100]
        (0x6d1de); the prelude f-string (the GOT_877
        '# -*- coding: utf-8 -*-\\n' literal with one
        FORMAT_VALUE over the read result, BUILD_STRING
        ecx=2 at 0x6d22c) binding [rsp+0x108]; the inject
        arm — the ScriptEngine bootstrap again (staged
        0x6d264, called with r8d=0 / r9d=0 at 0x6d2a9) and
        the .inject GetAttr (GOT_878, resolved 0x6d2ce), the
        kind-1 count-2 args (a fresh os.path.splitext chain
        of the subfile with [0], 0x6d3a3-0x6d40c, plus the
        preluded source, 0x6d425-0x6d442) and the call
        0x6d460 with the result discarded; the direct-file
        mirror builds the path as f'{getDataPath()}/scripts/
        {filename}' — BUILD_STRING ecx=3 at 0x6e1fb with
        only the filename FORMAT_VALUE (the '/scripts/'
        GOT_873 restaged 0x6e1bc) and follows the identical
        open/read/prelude/inject chain (the GOT_201 'open'
        staged 0x6e0f0, the encoding/utf-8 kwargs 0x6e217 /
        0x6e226); corpus events 1333-1463.
    [E:] THE COUNT — `count += 1` — the a9d10 binop over
        [rsp+0xd0] and CONST[233] 1 with r8d=0xe (0x6d492) —
        THE AUGMENTED-OP SELECTOR, locking the law that
        sel-7 is the plain plus while 0xE is the in-place
        family (the same 0xE startRPCTimer's start arm
        carries, its minus reading reinforced by this
        plus-side datum); then loaded.append(name) — the
        append GetAttr (GOT_250, resolved 0x6d4d5) over the
        kind-1 count-1 args of a THIRD os.path.splitext
        chain with [0] (0x6d583-0x6d5dd) — the emitter
        re-derives the name rather than caching it; corpus
        events 1520-1549.
    [E:] THE FAILURE ARM (both branches, mirrored around
        the Lock try body) — logging.error(f'Script error:
        {filename} | {e}') — the logging LOAD (GOT_44 staged
        0x6d837) with the .error GetAttr (GOT_45, staged
        0x6d86c) and the BUILD_STRING(4) at 0x6d92f over
        [the GOT_879 'Script error: ' literal (staged
        0x6d8b3), the FORMAT_VALUE of [rsp+0xe8], the
        GOT_787 ' | ' literal (staged 0x6d8ea — the
        repr-censored pipe separator resolved live), the
        FORMAT_VALUE exception [rsp+0x110]]; then the app
        print — CONST[204] 'print' staged 0x6d979 with
        BUILD_STRING(3) at 0x6da1c over [the [rsp+0xe8]
        FORMAT_VALUE, the GOT_880 ' script: ' literal
        (staged 0x6d9dc), the exception FORMAT_VALUE] —
        f'{filename} script: {e}' for the subdirectory arm,
        the direct-file mirror substituting the GOT_886
        'Error in script: ' literal (staged 0x6ea76 with
        the pipe composition, the logging/error pair
        0x6e8b9 / 0x6e8ee); then showToast over the kind-3
        count-4 kwargs — text=f'Error loading script:
        {filename}' (the GOT_882 literal with the
        [rsp+0xe8] FORMAT_VALUE, BUILD(2) call 0x6db52),
        type_='ERROR' (GOT_208 staged 0x6da39 / GOT_67
        staged 0x6da48), title='Script error' (GOT_370 /
        GOT_883), details=f'Error loading script: {filename}
        \\nTraceback: {e}' (BUILD(4) at 0x6dc3a over [the
        GOT_882, the [rsp+0xe8] FORMAT_VALUE, the GOT_885
        '\\nTraceback: ' literal staged 0x6dbf5, the
        [rsp+0x110] FORMAT_VALUE]) — the kwargs pairs
        stacked 0x6dc41-0x6dc5d with the build call
        0x6dc62 (ecx=3, edx=4); corpus events 1089-1237;
        NOTE the [rsp+0xe8] operand — in the subdirectory
        arm the messages carry the OUTER filename, i.e. the
        subdirectory name, a quirk of the original that
        this ship preserves; both arms close with
        removeEnabledScript(<the splitext name>) — the
        GOT_849 name staged (0x6dcc1 / 0x6ed57 mirror)
        with its own os.path.splitext(chain)-[0] argument
        build and the call — and the release back into the
        scan; corpus events 1240-1295.
    [E:] THE CLOSE — print(f'{count} script(s) loaded!')
        — the app print over the FORMAT_VALUE count and the
        GOT_887 ' script(s) loaded!' literal (BUILD(2) at
        0x6f1a6; NO '\\n' const exists in the print tail —
        corpus events 2364-2388); then showToast(text=
        f'{count} script(s) loaded!' (the GOT_887 staged
        0x6f2c0 with the count FORMAT_VALUE), type_=
        'SUCCESS' (GOT_888), title='Scripts loaded'
        (GOT_889), details=f'{count} script(s) loaded!\\n' +
        ', '.join(loaded)) — the GOT_890 ' script(s)
        loaded!\\n' literal (staged 0x6f35c) over the count
        FORMAT_VALUE (BUILD(2) at 0x6f373), the ', '
        GOT_891 (staged 0x6f38d) joined over the loaded
        list through GOT_166 'join' (GetAttr 0x6f3b2, args
        0x6f408, call 0x6f426) and the a9d10 selector-7
        plain plus composing the two (r8d=7 at 0x6f438),
        the kwargs built kind-3 count-4 at 0x6f463 and the
        toast called 0x6f4a2; corpus events 2400-2477.
    [E:] THE 0x6dff7 GATE — the shared outer-loop exit the
        file-arm not-.py jump feeds: the IsTrue of the
        carried bool with the je 0x6c64a back into the
        scan — the compiled continue; the inner loop's miss
        side continues at 0x6cc01 and releases through
        0x6cbe0 / 0x6cc01.
    """
    for command in bot.commands:
        if not command.extras.get('built-in'):
            bot.remove_command(command.name)
            sys.stdout.write(
                f'\nCommand unloaded: {command.name}\n')
    for event_name, listeners \
            in bot.extra_events.items():
        for listener in listeners:
            if (listener.__name__
                    in bot.config['built_in_events']
                    and listener.__name__
                    in __custom_feature_listeners__):
                bot.remove_listener(listener, event_name)
                sys.stdout.write(
                    f'\nUnloaded event: {event_name}: '
                    f'{listener.__name__}\n')
    try:
        ScriptEngine().deject_all()
    except Exception:
        pass
    count = 0
    loaded = []
    enabled = getScriptsConfig()['enabled']
    for filename in os.listdir(
            f'{getDataPath()}/scripts'):
        if os.path.isdir(os.path.join(
                f'{getDataPath()}/scripts', filename)):
            for subfile in os.listdir(
                    f'{getDataPath()}'
                    f'/scripts/{filename}'):
                if subfile.endswith('.py'):
                    if (os.path.splitext(subfile)[0]
                            in enabled):
                        with Lock():
                            try:
                                source = open(
                                    f'{getDataPath()}'
                                    f'/scripts'
                                    f'/{filename}'
                                    f'/{subfile}',
                                    encoding='utf-8',
                                    errors='ignore'
                                ).read()
                                ScriptEngine().inject(
                                    os.path.splitext(
                                        subfile)[0],
                                    f'# -*- coding: '
                                    f'utf-8 -*-\n{source}')
                                count += 1
                                loaded.append(
                                    os.path.splitext(
                                        subfile)[0])
                            except Exception as e:
                                logging.error(
                                    f'Script error: '
                                    f'{filename} | {e}')
                                print(f'{filename} '
                                      f'script: {e}')
                                showToast(
                                    text=(
                                        f'Error loading '
                                        f'script: '
                                        f'{filename}'),
                                    type_='ERROR',
                                    title='Script error',
                                    details=(
                                        f'Error loading '
                                        f'script: '
                                        f'{filename}'
                                        f'\nTraceback: '
                                        f'{e}'))
                                removeEnabledScript(
                                    os.path.splitext(
                                        subfile)[0])
        elif filename.endswith('.py'):
            if (os.path.splitext(filename)[0]
                    in enabled):
                with Lock():
                    try:
                        source = open(
                            f'{getDataPath()}/scripts'
                            f'/{filename}',
                            encoding='utf-8',
                            errors='ignore'
                        ).read()
                        ScriptEngine().inject(
                            os.path.splitext(filename)[0],
                            f'# -*- coding: utf-8 -*-'
                            f'\n{source}')
                        count += 1
                        loaded.append(
                            os.path.splitext(filename)[0])
                    except Exception as e:
                        logging.error(
                            f'Script error: '
                            f'{filename} | {e}')
                        print(f'Error in script: '
                              f'{filename} | {e}')
                        showToast(
                            text=(
                                f'Error loading script: '
                                f'{filename}'),
                            type_='ERROR',
                            title='Script error',
                            details=(
                                f'Error loading script: '
                                f'{filename}'
                                f'\nTraceback: {e}'))
                        removeEnabledScript(
                            os.path.splitext(filename)[0])
    print(f'{count} script(s) loaded!')
    showToast(text=f'{count} script(s) loaded!',
             type_='SUCCESS',
             title='Scripts loaded',
             details=(f'{count} script(s) loaded!\n'
                      + ', '.join(loaded)))


def unloadScripts():
    """Registry L7300. Content: chunk L7315 — recovered from
    the island bytes of chunk 7315 (dump file
    chunk7315_unloadScripts_L7300.txt, @0x6f510 +3632,
    alignment +0, 180 events, 909 insns, read complete
    through the reloadAllScripts prologue at 0x70300), plus
    the entry prologue 0x6f4d0-0x6f510 in chunk 7300's tail,
    cross-checked against the complete stream section
    (function@L7300, corpus lines 19563-19752, read
    complete). ZERO parameters — no GOT_000 binder events
    exist in the section (the 0-param signature law: only
    functions with parameters carry the binder + names
    tuple).

    [E:] THE COMMAND SWEEP — `for command in bot.commands:
        if not command.extras.get('built-in'):` — the bot
        LOAD (GOT_244 staged 0x6f52a) with the .commands
        GetAttr (GOT_854, resolved 0x6f575), the GetIter
        (GOT_027 call 0x6f5a2), the iternext loop head
        0x6f5c0/0x6f65d with the command bound [rsp+0x58]
        (0x6f674); per item the .extras GetAttr (GOT_855,
        0x6f6ac) with the .get GetAttr (GOT_47, 0x6f725)
        over the kind-1 count-1 ('built-in' GOT_856, build
        call 0x6f764) and the zero-kwargs call 0x6f782; the
        not-swap gate — IsTrue 0x6f796 with the falsy side
        loading CONST[31] True (0x6f7d0) and the truthy side
        loading CONST[32] False (0x6f7b1), then the shared
        IsTrue 0x6f7e5 whose TRUE side falls into the removal
        arm and whose FALSE side takes the back-edge
        0x6f65a (je) — built-ins continue, customs removed,
        with the cmp -1 error gate at 0x6f7fe; the removal
        arm 0x6f807: bot restaged (0x6f80e) with the
        remove_command GetAttr (GOT_857, resolved 0x6f85b)
        over the .name GetAttr (GOT_273, 0x6f8ad) as the
        kind-1 count-1 argument (build 0x6f8e1-0x6f8ee,
        call 0x6f90c, result discarded), then logging.debug
        — the logging LOAD (GOT_44 staged 0x6f930) with the
        .debug GetAttr (GOT_071 'debug', resolved 0x6f97d)
        and BUILD_STRING(2) at 0x6f604 over the GOT_858
        'Unloaded command: ' literal (staged 0x6f9b2) and
        the .name FORMAT_VALUE (the shared format block
        0x6f5dc-0x6f602), the kind-1 count-1 wrapper
        (0x6f611) and the method call 0x6f63c —
        logging.debug(f'Unloaded command: {command.name}')
        with no trailing newline.
    [E:] THE LISTENER SWEEP — the bot restaged (0x6fa3d)
        with the .extra_events GetAttr (GOT_859, resolved
        0x6fa95) and the .items GetAttr (GOT_247, resolved
        0x6facd), zero-arg called 0x6faff, GetIter (GOT_027
        call 0x6fb11), iternext 0x6fb43 and the GOT_004
        2-way unpack (0x6fb61, r8d=2, cmp eax, -1 at
        0x6fb6a) binding event_name [rsp+0x60] (0x6fb84)
        and listeners [rsp+0x68] (0x6fbaa); the inner
        GetIter over listeners (GOT_027 call 0x6fbd2) with
        the iternext 0x6fbf0 binding the listener
        [rsp+0x70] (0x6fc2e); the gates — the listener.
        __name__ GetAttr (GOT_509, 0x6fc82) through the
        a9d30 selector-7 membership against bot.config
        ['built_in_events'] (the config GetAttr GOT_245 at
        0x6fcfe, the GetItem GOT_860 at 0x6fd3b, edx=7 at
        0x6fd68; the falsy-side CONST[32] False
        materialization 0x6fd96), then re-fetch and the
        second selector-7 membership against the
        __custom_feature_listeners__ module global (GOT_861
        staged 0x6fe24 with r8d=1, edx=7 at 0x6fe61, the
        falsy-side materialization 0x6fe90) — both
        converging at the shared gate 0x6feb4 whose falsy
        side continues the inner loop (je 0x6fc0c): an AND
        of the two memberships, remove only when both
        hold, identical to loadScripts' sweep.
    [E:] THE REMOVAL ARM — bot restaged (0x6fee0) with the
        remove_listener GetAttr (GOT_862, resolved 0x6ff29)
        over the kind-1 count-2 args — the listener
        [rsp+0x70] FIRST, event_name [rsp+0x60] SECOND
        (0x6ff50 mov r8, [rsp+0x70]; 0x6ff5d mov r9,
        [rsp+0x60]; the ecx=1 / edx=2 build 0x6ff6a-0x6ff6f;
        the call 0x6ff92, result discarded) — func-first,
        matching remove_listener(func, name); then
        logging.debug over BUILD_STRING(4) at 0x700f6 —
        [the GOT_863 'Unloaded event: ' literal (staged
        0x70043), the [rsp+0x60] event_name FORMAT_VALUE
        (0x70074), the ': ' GOT_864 literal (staged
        0x70079), the listener.__name__ FORMAT_VALUE
        (re-GetAttr'd 0x700af)] — logging.debug(f'Unloaded
        event: {event_name}: {listener.__name__}').
    [E:] THE DEJECT — the loop tails exhaust (inner
        back-edge 0x6fc0c / outer 0x7015b, the PyErr
        checks 0x70160 / 0x70223) into the ScriptEngine
        LOAD (GOT_865 staged 0x70245, r8d=1) with the
        ZERO-ARG class bootstrap call (0x7028d: rcx=0,
        r8d=0, r9d=0), the .deject_all GetAttr (GOT_866,
        resolved 0x702ac) and the ZERO-ARG call (0x702de:
        r8d=0, r9d=0) with the result released — a PLAIN
        Unguarded call: the section carries NO a9d40
        fetch and NO selector-0xa match events, unlike
        loadScripts' guarded deject.
    [E:] THE TAIL — the slot DecRefs [rsp+0x58] /
        [rsp+0x60] / [rsp+0x68] / [rsp+0x70] (0x701a7-0x701cd),
        the a9d28 ret-dispatch on the error path (ecx=1,
        0x701d7) and the clean path (PyErr_Occurred
        0x701e4, PyErr_Clear 0x701ef, the GOT_030 CONST[30]
        None staged 0x701f5) — the implicit None return.
    """
    for command in bot.commands:
        if not command.extras.get('built-in'):
            bot.remove_command(command.name)
            logging.debug(f'Unloaded command: {command.name}')
    for event_name, listeners \
            in bot.extra_events.items():
        for listener in listeners:
            if (listener.__name__
                    in bot.config['built_in_events']
                    and listener.__name__
                    in __custom_feature_listeners__):
                bot.remove_listener(listener, event_name)
                logging.debug(
                    f'Unloaded event: {event_name}: '
                    f'{listener.__name__}')
    ScriptEngine().deject_all()


def reloadAllScripts():
    """Registry L7315. Content: chunk L7322 — recovered from
    the island bytes of chunk 7322 (dump file
    chunk7322_reloadAllScripts_L7315.txt, @0x70340 +560,
    alignment +0, 27 events, 145 insns, read complete
    through the toggleScriptState prologue at 0x70530),
    plus the entry prologue 0x70300-0x70340 in chunk 7315's
    tail, cross-checked against the complete stream section
    (function@L7315, corpus lines 19755-19783, read
    complete). ZERO parameters — no GOT_000 binder events
    (the 0-param signature law).

    [E:] THE UI CLEAR — the evaluate_js module global LOAD
        (GOT_041, staged 0x7034f with r8d=1) with the kind-1
        count-1 args over the GOT_851 'clearCustomUITabs();'
        literal (the LIVE repr carries the semicolon,
        staged 0x7037c; build 0x70395) and the call 0x703b3
        (r8d=1 — the r8d-as-positional-count call form) —
        evaluate_js('clearCustomUITabs();').
    [E:] THE RESET — the a9d18 kind-2 edx=0 empty list
        build (0x703d5) staged into the a9d50 STORE form
        (0x70400: rcx=[rsp+0x30], rdx=GOT_629
        '__custom_ui_tabs__', r8=the empty list) — the
        global-name stage STORE law (name + value): __custom_ui_tabs__ = [].
    [E:] THE CYCLE — the unloadScripts LOAD (GOT_852
        staged 0x70427) with the ZERO-ARG call (0x70493:
        r8d=0, r9d=0, both stack slots zeroed 0x70480) and
        the loadScripts LOAD (GOT_853 staged 0x704aa) with
        the ZERO-ARG call (0x704ef) — loadScripts() is
        called BARE, the proof that loadScripts' `first`
        parameter is optional.
    [E:] THE TAIL — the error-path a9d28 ret-dispatch
        (ecx=1, 0x70465) and the clean path
        (PyErr_Occurred 0x70503, PyErr_Clear 0x7050e, the
        GOT_030 CONST[30] None staged 0x70514) — the
        implicit None return.
    """
    evaluate_js('clearCustomUITabs();')
    global __custom_ui_tabs__
    __custom_ui_tabs__ = []
    unloadScripts()
    loadScripts()


def toggleScriptState(toggle, script):
    """Registry L7322. Content: chunk L7329 — recovered from
    the island bytes of chunk 7329 (dump file
    chunk7329_toggleScriptState_L7322.txt, @0x70570 +544,
    alignment +0, 25 events, 138 insns, read complete
    through the getRPCPreset prologue at 0x70750), plus the
    entry prologue 0x70530-0x70579 in chunk 7322's tail,
    cross-checked against the complete stream section
    (function@L7322, corpus lines 19785-19805, read
    complete).

    [E:] THE SIGNATURE — the names-tuple CONST[847]
        ('toggle', 'script') staged 0x7057f with the
        binder call GOT_000 at 0x705ab (r8d=2 — the param
        count), target area [rsp+0x58]/[rsp+0x60]; test eax,
        eax / jne 0x7073c = the arity-mismatch silent
        None-return shim — def toggleScriptState(toggle,
        script): with the parameter names live-pinned.
    [E:] THE SWAP — the first parameter [rsp+0x58] through
        PyObject_IsTrue (0x705cc; cmp edi, -1 error gate
        0x705dd): TRUTHY (jne 0x70618) stages the GOT_848
        'addEnabledScript' name, FALSY (fall 0x705ea) stages
        the GOT_849 'removeEnabledScript' name — the two
        arms converge at the shared LOAD joint 0x705fd
        (a9d50 stage, r8d=1) with the kind-1 count-1 args
        over the second parameter [rsp+0x60] (0x7064a build,
        0x70672 call with r8d=1): if toggle: addEnabled_
        script(script) else: removeEnabledScript(script) —
        the else-arc replace-plant emission, both calls
        share the one call site.
    [E:] THE RELOAD — the reloadAllScripts LOAD (GOT_850
        staged 0x7068d) with the ZERO-ARG call (0x706d2:
        r8d=0, r9d=0), result discarded.
    [E:] THE TAIL — the [rsp+0x58]/[rsp+0x60] DecRefs
        (0x706e2/0x706ed), the clean path (PyErr_Occurred
        0x706f8, PyErr_Clear 0x70703, the GOT_030 CONST[30]
        None 0x70709) and the error-path a9d28 ret-dispatch
        (ecx=1, 0x70734) — the implicit None return.
    """
    if toggle:
        addEnabledScript(script)
    else:
        removeEnabledScript(script)
    reloadAllScripts()
