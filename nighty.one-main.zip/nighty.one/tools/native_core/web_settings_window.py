"""
web_settings_window.py — the web-version window controller class from
the SPP native core (registry L8545-L8723), recovered from the corpus
event streams plus island dumps. The 25 members ship complete: the
six window-wrapper marquees, the web-config toggle tier, the custom
UI/notification store bridges, the clipboard/URL openers, the dev-
portal token booter, the web-session key/token savers and the MFA
password verifier (its 484-byte watcher snippet embedded pool-exact;
the two notification stores carry the explicit global declarations
the a9d50 STORE_GLOBAL emission demands).

  __init__(self)             — self._window = None
  set_window(self, window)   — the wrapper binding
  show(self)                 — self._window.show()
  minimize(self)             — self._window.minimize()
  hide(self)                 — the plain window hide
  close(self)                — log, stop the turbo snipe, destroy, exit
  customCallback … verifyDevPortalPass — the 19 JS-API bridge
      members (registry L8569-L8723)

CLASS NAME FLAG: no live const in this span names the class (the block
hosts the web-version config tier, hence the inferred WebVersionApi);
flagged per the family convention — rename when a booter island stages
its js_api class-name const (the createApp precedent: 718 staged live).
"""

import copy  # noqa: F401
import datetime  # noqa: F401
import logging  # noqa: F401
import os  # noqa: F401
import pyperclip  # noqa: F401
import requests  # noqa: F401
import sys  # noqa: F401
import time  # noqa: F401
import webview  # noqa: F401


class WebVersionApi:

    def __init__(self):
        """Registry L8545. Content: chunk L8548 — recovered from the
        island bytes of chunk 8548 (dump file chunk8548_init_L8545.txt,
        per the dumper +2 align, 17 events, 89 insns, read complete
        through the set_window prologue), cross-checked against the
        complete stream section (function@L8545, corpus lines
        22880-22894, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x82fb4 with the GOT_000 binder (r8d=1) at 0x82fe0.
        [E:] THE BODY — the '_window' CONST[620] staged 0x82ffa with
            the None CONST[30] staged 0x83008, the SetAttr over the
            [rsp+0x58] self — self._window = None — with the tail
            None materialization 0x83072 and the implicit return
            through the ret-disp (a9d28) at 0x830aa; the
            WebWindow.__init__@L7397 emission law's sixth member;
            corpus events 18-58.
        """
        self._window = None

    def set_window(self, window):
        """Registry L8548. Content: chunk L8551 — recovered from the
        island bytes of chunk 8551 (dump file
        chunk8551_set_window_L8548.txt, per the dumper +0 align, 14
        events, 92 insns, read complete), cross-checked against the
        complete stream section (function@L8548, corpus lines
        22896-22907, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[651] ('self',
            'window') staged 0x8311f with the GOT_000 binder (r8d=2)
            at 0x8314b.
        [E:] THE BODY — the '_window' CONST[620] staged 0x83165, the
            SetAttr binding the second target — self._window =
            window — the implicit None return (0x831ed) through the
            ret-disp at 0x83202; the set_window@L7400 emission law;
            corpus events 20-59.
        """
        self._window = window

    def show(self):
        """Registry L8551. Content: chunk L8554 — recovered from the
        island bytes of chunk 8554 (dump file chunk8554_show_L8551.txt,
        per the dumper +3 align, 19 events, 109 insns, read complete),
        cross-checked against the complete stream section
        (function@L8551, corpus lines 22909-22929, read complete).
        The show-marquee is new in the family with this class.

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x83265 with the GOT_000 binder (r8d=1) at 0x83291.
        [E:] THE BODY — GetAttr(self, '_window' CONST[620] staged
            0x832b2, resolved through the 0x832d1 chain) then GetAttr
            over 'show' CONST[650] staged 0x832f7, the zero-argument
            call — self._window.show() — with the implicit None return
            (0x83372) through the ret-disp at 0x8338e; corpus events
            19-59.
        """
        self._window.show()

    def minimize(self):
        """Registry L8554. Content: chunk L8557 — recovered from the
        island bytes of chunk 8557 (dump file
        chunk8557_minimize_L8554.txt, per the dumper +3 align, 19
        events, 109 insns, read complete), cross-checked against the
        complete stream section (function@L8554, corpus lines
        22930-22947, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x833f5 with the GOT_000 binder (r8d=1) at 0x83421.
        [E:] THE BODY — GetAttr(self, '_window' CONST[620] staged
            0x83442) then GetAttr over 'minimize' CONST[649] staged
            0x83487, the zero-argument call — self._window.minimize()
            — the show/marquee emission shape verbatim with the
            implicit None return (0x83502) through the ret-disp at
            0x8351e; corpus events 19-70.
        """
        self._window.minimize()

    def hide(self):
        """Registry L8557. Content: chunk L8560 — recovered from the
        island bytes of chunk 8560 (dump file chunk8560_hide_L8557.txt,
        per the dumper +3 align, 19 events, 107 insns, read complete),
        cross-checked against the complete stream section
        (function@L8557, corpus lines 22948-22968, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x83585 with the GOT_000 binder (r8d=1) at 0x835b1.
        [E:] THE BODY — GetAttr(self, '_window' CONST[620] staged
            0x835d2) then GetAttr over 'hide' CONST[648] staged
            0x83617, the zero-argument call — self._window.hide() —
            the plain 107-insn WebWindow@L7403 emission (no bot boot,
            unlike AppCreateApi.hide@L8095's 195-insn variant) with
            the implicit None return (0x83692) through the ret-disp
            at 0x836ae; corpus events 19-70.
        """
        self._window.hide()

    def close(self):
        """Registry L8560. Content: chunk L8569 — recovered from the
        island bytes of chunk 8569 (dump file chunk8569_close_L8560.txt,
        per the dumper +0 align, 56 events, 279 insns, read complete
        through the customCallback prologue), cross-checked against
        the complete stream section (function@L8560, corpus lines
        22969-23022, read complete). The heavyweight close: log the
        shutdown, stop the turbo snipe, kill the window, exit.

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x8371b with the GOT_000 binder (r8d=1) at 0x83747.
        [E:] THE LOG — logging (CONST[44] name load 0x8375c) .info
            (CONST[51] GetAttr 0x8378e) over the kind-1 wrapped
            'WV - Closing Nighty.' CONST[643] staged 0x837cd, the
            one-positional call at 0x83804 and the result release
            0x83813; corpus events 26-51.
        [E:] THE SNIPE STOP — the turbo_sniper CONST[644]
            module-global name-loaded through the a9d50 stage
            0x8383c-0x8383c with GetAttr 'stop' CONST[645] at
            0x8386b, the zero-argument call at 0x8389d —
            turbo_sniper.stop().
        [E:] NO TRY — the null-result fall of the stop call jumps
            0x838a3 → 0x838e0: the DAT_a9d40 fetch with the a9d30
            compare (0x838ef-0x838f5) and the 0x839de propagation
            dispatch — NO match const is staged anywhere in the
            frame (the corpus carries no Exception slot), so this is
            the propagation check, not an except arm — the body is
            try-free per the no-match-const law; corpus events
            81-102.
        [E:] THE DESTROY — GetAttr(self [rsp+0x68], '_window'
            CONST[620], 0x838d5) then GetAttr over 'destroy'
            CONST[646] staged 0x83949 (resolved 0x8395c), the
            zero-argument call — self._window.destroy(); corpus
            events 108-135.
        [E:] THE EXIT — the sys CONST[79] module-global name-loaded
            0x839b0 with GetAttr 'exit' CONST[647] staged 0x83a50,
            the zero-argument call — sys.exit() — and the implicit
            None tail through the ret-disp (a9d28) at 0x83ae8;
            corpus events 143-182.
        """
        logging.info('WV - Closing Nighty.')
        turbo_sniper.stop()
        self._window.destroy()
        sys.exit()

    def customCallback(self, name, *args, **kwargs):
        """Registry L8569. Content: chunk L8572 — recovered from the
        island bytes of chunk 8572 (dump file
        chunk8572_customCallback_L8569.txt, +0 align, 18 events, 119
        insns, read complete through the isWeb entry at 0x83cf0),
        cross-checked against the complete stream section
        (function@L8569, corpus lines 23024-23037, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[640] ('self',
            'name') staged 0x83b5e with the GOT_000 binder (r8d=2,
            the bindable positional count) at 0x83b99; the binder
            got three cell targets 0x83b65-0x83b83 ([rsp+0x58] the
            named area, [rsp+0x68] and [rsp+0x70] the vararg/varkw
            receiver cells), and the tail decrefs all four cells
            0x83ca9-0x83cc5.
        [E:] THE FORWARD — the 'callback_store' CONST[641]
            name-loaded through the a9d50 stage 0x83bb8-0x83bd4,
            GetAttr 'call' CONST[642] 0x83be6-0x83bff; the kind-1
            count-1 build over the second bound param [rsp+0x60]
            (0x83c1e-0x83c3c) = (name,); the kind-9 count-2 helper
            call 0x83c4b-0x83c58 flattening that tuple with the
            [rsp+0x68] cell (the tuple-unpack-with-call form); the
            kind-3 count-1 dict restage 0x83c5d-0x83c81 over the
            [rsp+0x70] cell; the call a9d20 (rcx=0, rdx=the .call
            method, r8d=1/r9d=1 — dispatched pos carrier
            [rsp+0x20] + kwargs carrier [rsp+0x28]) 0x83c8d-0x83c9e;
            the result rides rsi to the epilogue 0x83cd0-0x83ce2
            with the a9d28 error tail 0x83cd5; corpus events 26-71.

        FLAG: the *args/**kwargs spellings — the binder const
            carries only ('self', 'name'); the two extra binder
            cells, the kind-9 unpack, the kwargs-restage and the
            EX-style dispatch are the evidence; the shipped
            CallbackStore.call in func_store.py is the family twin.
        """
        return callback_store.call(name, *args, **kwargs)

    def isWeb(self):
        """Registry L8572. Content: chunk L8576 — recovered from the
        island bytes of chunk 8576 (dump file
        chunk8576_isWeb_L8572.txt, +0 align, 16 events, 114 insns,
        read complete through the getWebConfig entry at 0x83e90),
        cross-checked against the complete stream section
        (function@L8572, corpus lines 23039-23053, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x83d3f with the GOT_000 binder (r8d=1) at
            0x83d6b.
        [E:] THE BODY — the 'getConfigData' CONST[145] name-loaded
            through the a9d50 stage 0x83d80-0x83d9c, the zero-arg
            call a9d20 (r8d=0/r9d=0) 0x83dc7, then the CONST[464]
            'web' GetItem 0x83dcc-0x83de5 —
            getConfigData()['web'] — the value returned through
            the [rsp+0x60] slot and the ret-disp (a9d28) at
            0x83e60; corpus events 22-80.
        """
        return getConfigData()['web']

    def getWebConfig(self):
        """Registry L8576. Content: chunk L8589 — recovered from the
        island bytes of chunk 8589 (dump file
        chunk8589_getWebConfig_L8576.txt, +0 align, 57 events, 321
        insns, read complete through the setWebConfig entry),
        cross-checked against the complete stream section
        (function@L8576, corpus lines 23055-23102, read complete;
        the CONST[639] 'isPasswordSet' staged 0x8424f is live in
        the island but not displayed by the corpus stream).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x83ef1
            with the GOT_000 binder (r8d=1) at 0x83f1d.
        [E:] THE DEEPCOPY — 'copy' CONST[626] name-load 0x83f32-
            0x83f4e, GetAttr 'deepcopy' CONST[638] 0x83f64-0x83f7d,
            the 'getWebConfigData' CONST[53] name-load + zero-arg
            call 0x83faa-0x83ff1, the kind-1 count-1 wrap 0x83ff4-
            0x84004 and the one-positional call 0x84014-0x84020 —
            copy.deepcopy(getWebConfigData()) stored [rsp+0x70].
        [E:] THE SCRUB — the False CONST[32] materialized 0x84044
            into [rsp+0x78]; the raw CONST[409] 'password' GetItem
            over the config 0x8406b-0x84096; the IsTrue gate
            0x840ee-0x840ff with the law-8 not-swap bool pair (the
            False side loads CONST[31] True at 0x8410c) — the
            truthy password stores True into [rsp+0x78]; the
            null-result fall runs the DAT_a9d40 fetch + the a9d30
            sel-0xa self-pair 0x84132-0x84178 whose match-swallow
            continues at 0x841cf — NO match const is staged, so
            per the no-match-const law this is the
            propagation-check family, not an except arm; corpus
            events 112-135.
        [E:] THE ANNOTATION — SetItem config['password'] = None
            0x841e9-0x84218, then SetItem config['isPasswordSet'] =
            the [rsp+0x78] bool 0x8424f-0x84282; the config return
            through [rsp+0x70] + rsi 0x842b3-0x842c2; corpus
            events 171-214.

        FLAG: the config / is_set locals are name-inferred (py38
            locals live in the frame; the live const pins only the
            'isPasswordSet' key).
        """
        config = copy.deepcopy(getWebConfigData())
        is_set = False
        if config['password']:
            is_set = True
        config['password'] = None
        config['isPasswordSet'] = is_set
        return config

    def setWebConfig(self, config):
        """Registry L8589. Content: chunk L8596 — recovered from the
        island bytes of chunk 8596 (dump file
        chunk8596_setWebConfig_L8589.txt, +0 align, 47 events, 271
        insns, read complete through the enableWebVersion entry),
        cross-checked against the complete stream section
        (function@L8589, corpus lines 23104-23149, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[636] ('self',
            'config') staged 0x843d2 with the GOT_000 binder
            (r8d=2) at 0x843fe.
        [E:] THE CURRENT — the 'getWebConfigData' CONST[53]
            name-load + zero-arg call 0x84413-0x8445a stored
            [rsp+0x68].
        [E:] THE GATE — the config param [rsp+0x60], GetAttr 'get'
            CONST[47] 0x84484-0x844a4, the kind-1 (CONST[409]
            'password',) wrap 0x844d5-0x844f5, the one-positional
            call 0x84507-0x84515; the IsTrue gate 0x84527-0x8453a
            with the law-8 not-swap (the falsy password load
            materializes CONST[31] True at 0x84553, the truthy
            side CONST[32] False at 0x84542) — the zero flag falls
            into the updateWebConfig branch, so the source gate is
            `if not config.get('password'):`; corpus events 86-95.
        [E:] THE RESTORE ARM — the config param + CONST[409] pair
            0x845b4-0x845df, the GetItem over the [rsp+0x68]
            current, the SetItem config['password'] =
            current['password'] 0x846d3, then the fall-through
            0x846fa into the shared persist stage.
        [E:] THE PERSIST + RETURN — the 'updateWebConfig'
            CONST[637] name-load 0x84586-0x845af, the kind-1
            (config,) wrap 0x84611-0x8462f, the one-positional
            call 0x8463f-0x8464f; the True CONST[31] staged
            0x8466d carried rsi through the tail decrefs —
            return True (the r12b flag cleared 0x8467f; set
            0x8445c marks the propagate tail through a9d28 at
            0x84747); corpus events 102-189.

        FLAG: the `current` local is name-inferred.
        """
        current = getWebConfigData()
        if not config.get('password'):
            config['password'] = current['password']
        updateWebConfig(config)
        return True

    def enableWebVersion(self, enabled):
        """Registry L8596. Content: chunk L8602 — recovered from the
        island bytes of chunk 8602 (dump file
        chunk8602_enableWebVersion_L8596.txt, +1 align, 60 events,
        300 insns, read complete), cross-checked against the
        complete stream section (function@L8596, corpus lines
        23151-23203, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[635] ('self',
            'enabled') staged 0x847d7 with the GOT_000 binder
            (r8d=2) at 0x84803.
        [E:] THE TOGGLE — the 'getConfigData' CONST[145] name-load
            + zero-arg call 0x84818-0x8485d stored [rsp+0x68]; the
            SetItem config['web'] = the enabled param [rsp+0x60]
            with the CONST[464] 'web' key 0x8487d-0x848c3; the
            'saveConfigData' CONST[155] name-load 0x849c0-0x849e2
            + kind-1 (config,) wrap + one-positional call
            0x84a2e; corpus events 36-110.
        [E:] THE RELAUNCH — the 'os' CONST[34] name-load 0x84a4e-
            0x84a70, GetAttr 'execv' CONST[123] 0x84a80-0x84a99;
            the 'sys' CONST[79] name-load 0x84ab8-0x84adb, GetAttr
            'executable' + kind-2 count-1 list build over
            CONST[125] 'python'; the second sys load + GetAttr
            'argv'
            CONST[80]; the DAT_a9d10 sel-7 plain + concat 0x84bca
            (rcx=['python'], rdx=sys.argv); the a9d20 dispatch —
            os.execv(sys.executable, ['python'] + sys.argv), the
            third os.execv relaunch in the codebase (the
            getAppToken@L8508 and saveKeyToAppdata siblings); the
            silent-None tail through a9d28; corpus events 119-182.

        FLAG: the `config` local is name-inferred.
        """
        config = getConfigData()
        config['web'] = enabled
        saveConfigData(config)
        os.execv(sys.executable, ['python'] + sys.argv)

    def getAllNotifications(self):
        """Registry L8602. Content: chunk L8606 — recovered from the
        island bytes of chunk 8606 (dump file
        chunk8606_getAllNotifications_L8602.txt, +1 align, 9
        events, 59 insns, read complete), cross-checked against the
        stream section (function@L8602, corpus lines 23205-23211,
        read complete).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x84c63
            with the GOT_000 binder (r8d=1) at 0x84c8f.
        [E:] THE BODY — the '__all_notifications__' CONST[631]
            global name-loaded through the a9d50 stage 0x84ca3-
            0x84cbf and returned through the ret-disp (a9d28)
            0x84ce6; corpus events 17-29. The bare global return —
            the store-global family of app_notifications.py /
            script_loader.py.
        """
        return __all_notifications__

    def clearAllNotifications(self):
        """Registry L8606. Content: chunk L8612 — recovered from the
        island bytes of chunk 8612 (dump file
        chunk8612_clearAllNotifications_L8606.txt, +1 align, 22
        events, 120 insns, read complete), cross-checked against
        the stream section (function@L8606, corpus lines
        23213-23233, read complete).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x84d43
            with the GOT_000 binder (r8d=1) at 0x84d6f.
        [E:] THE CLEAR — the '__all_notifications__' CONST[631]
            held 0x84d7d, the kind-2 count-0 empty list build
            0x84d8b-0x84d92, the a9d50 name+value STORE stage
            0x84dab-0x84db6 (the script_loader global-store law) —
            __all_notifications__ = []; a STORE_GLOBAL emission,
            so the py38 source requires the explicit `global`
            declaration line below.
        [E:] THE NOTIFY — the 'evaluate_js' CONST[41] name-load
            0x84ddd-0x84df9 (the global-name helper, not a
            _window chain), the a9d48 1-piece format over the live
            CONST[634] 'localStateUpdated("notifications_cleared"'
            0x84e50-0x84e6a (the f-string single-piece form, the
            exact const repr ends without the closing bracket —
            the emitted JS arg is byte-faithful to CONST[634]),
            the kind-1 wrap and one-positional call
            0x84e6c-0x84e97, the silent-None tail; corpus events
            37-71.
        """
        global __all_notifications__
        __all_notifications__ = []
        evaluate_js('localStateUpdated("notifications_cleared"')

    def deleteNotification(self, notification_id):
        """Registry L8612. Content: chunk L8620 — recovered from the
        island bytes of chunk 8620 (dump file
        chunk8620_deleteNotification_L8612.txt, +0 align, 58
        events, 313 insns, read complete through the
        getCustomUITabs entry), cross-checked against the complete
        stream section (function@L8612, corpus lines 23235-23289,
        read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[630] ('self',
            'notification_id') staged 0x84f38 with the GOT_000
            binder (r8d=2) at 0x84f64; the notification_id param
            captured into a PyCell 0x84f72-0x84f80 (the
            comprehension closes over it).
        [E:] THE COMPREHENSION — the empty PyList_New 0x84fac (the
            accumulator); the '__all_notifications__' CONST[631]
            source name-load 0x84fc0-0x84fe0, the GetIter 0x84ffb;
            the a9d60 iternext loop; per item the GetAttr 'get'
            + the kind-1 (CONST[265] 'id',) one-positional call
            — n.get('id'); the a9d30 sel-3 != compare against the
            PyCell_Get'd notification_id — n.get('id') !=
            notification_id — the truth branch appends
            PyList_Append, the falsy branch skips (law-8
            materialization pair); the exhausted iterator stores
            via the a9d50 name+value stage 0x851cb-0x851d6 —
            __all_notifications__ = the new list (the same
            STORE-GLOBAL law: the `global` declaration below);
            corpus events 40-65.
        [E:] THE NOTIFY — the 'evaluate_js' name-load
            0x851fa-0x85221, the a9d48 build: the CONST[632]
            'localStateUpdated("notification_deleted", "' prefix,
            the -1 FORMAT_VALUE over the PyCell_Get'd
            notification_id, the CONST[633] '")' suffix, the
            three-piece finalize ecx=3 0x85305-0x85313, the kind-1
            wrap + one-positional call 0x85313-0x85341, the
            silent-None tail; corpus events 135-204.

        FLAG: the comprehension variable is name-inferred (the
            closure cells carry no name const).
        """
        global __all_notifications__
        __all_notifications__ = [n for n in __all_notifications__
                                 if n.get('id') != notification_id]
        evaluate_js(f'localStateUpdated("notification_deleted", '
                    f'"{notification_id}")')

    def getCustomUITabs(self):
        """Registry L8620. Content: chunk L8624 — recovered from the
        island bytes of chunk 8624 (dump file
        chunk8624_getCustomUITabs_L8620.txt, +1 align, 9 events, 59
        insns, read complete), cross-checked against the stream
        section (function@L8620, corpus lines 23291-23297, read
        complete).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x853e3
            with the GOT_000 binder (r8d=1) at 0x8540f.
        [E:] THE BODY — the '__custom_ui_tabs__' CONST[629] global
            name-loaded through the a9d50 stage 0x85423-0x8543f
            and returned through the ret-disp (a9d28) 0x85466;
            corpus events 17-29. The exact registry twin of
            getAllNotifications@L8602 over the tabs store.
        """
        return __custom_ui_tabs__

    def webLogout(self):
        """Registry L8624. Content: chunk L8634 — recovered from the
        island bytes of chunk 8634 (dump file
        chunk8634_webLogout_L8624.txt, +1 align, 15 events, 89
        insns, read complete), cross-checked against the stream
        section (function@L8624, corpus lines 23299-23315, read
        complete).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x854c3
            with the GOT_000 binder (r8d=1) at 0x854ef.
        [E:] THE BODY — the 'evaluate_js' CONST[41] name-load
            0x85504-0x85520, the kind-1 wrap over the live
            CONST[628] 121-byte fetch string 0x85536-0x85556 (NO
            a9d48 build — a plain literal, unlike the
            clearAll/deleteNotify f-family), the one-positional
            call 0x85574-0x85580, result released, the
            silent-None tail (PyErr_Occurred/Clear + CONST[30])
            0x85592-0x855b1; corpus events 20-53.
        """
        evaluate_js("\nfetch('/api/logout', { method: 'GET', "
                    "credentials: 'same-origin' })\n  .then(() => {\n"
                    "      location.reload();\n  });")

    def getClipboardText(self):
        """Registry L8634. Content: chunk L8637 — recovered from the
        island bytes of chunk 8637 (dump file
        chunk8637_getClipboardText_L8634.txt, +1 align, 13 events,
        85 insns, read complete), cross-checked against the stream
        section (function@L8634, corpus lines 23317-23328, read
        complete).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x85625
            with the GOT_000 binder (r8d=1) at 0x85651.
        [E:] THE BODY — the 'pyperclip' CONST[625] module
            name-load 0x85670-0x8568c, GetAttr 'paste' CONST[627]
            0x8569e-0x856a7, the zero-argument call, the value
            returned through the ret-disp (a9d28) 0x85704; corpus
            events 19-44.
        """
        return pyperclip.paste()

    def copyToClipboard(self, text):
        """Registry L8637. Content: chunk L8640 — recovered from the
        island bytes of chunk 8640 (dump file
        chunk8640_copyToClipboard_L8637.txt, +1 align, 15 events,
        97 insns, read complete), cross-checked against the stream
        section (function@L8637, corpus lines 23330-23342, read
        complete).

        [E:] THE SIGNATURE — the names-tuple CONST[624] ('self',
            'text') staged 0x85771 with the GOT_000 binder (r8d=2)
            at 0x8579d.
        [E:] THE BODY — the 'pyperclip' CONST[625] name-load
            0x857bc-0x857d8, GetAttr 'copy' , the kind-1
            count-1 wrap over the text param [rsp+0x60]
            0x85822-0x85844, the one-positional call, the result
            released and the implicit None through the ret-disp
            (a9d28) 0x85884; corpus events 20-55.
        """
        pyperclip.copy(text)

    def openURL(self, url):
        """Registry L8640. Content: chunk L8643 — recovered from the
        island bytes of chunk 8643 (dump file
        chunk8643_openURL_L8640.txt, +0 align, 20 events, 113
        insns, read complete through the openLicenseScreen entry),
        cross-checked against the stream section (function@L8640,
        corpus lines 23344-23361, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[622] ('self',
            'url') staged 0x85901 with the GOT_000 binder (r8d=2)
            at 0x8592d.
        [E:] THE BODY — the 'os' CONST[34] module name-load
            0x85942-0x8595e, GetAttr 'startfile', the kind-1
            count-1 wrap over the url param, the one-positional
            call, the result released, the silent-None tail
            and the ret-disp; corpus events 20-66.
        """
        os.startfile(url)

    def openLicenseScreen(self):
        """Registry L8643. Content: chunk L8646 — recovered from the
        island bytes of chunk 8646 (dump file
        chunk8646_openLicenseScreen_L8643.txt, +0 align, 20
        events, 117 insns, read complete), cross-checked against
        the stream section (function@L8643, corpus lines
        23363-23386, read complete).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x85ab5
            with the GOT_000 binder (r8d=1) at 0x85ae1.
        [E:] THE BODY — GetAttr(self, '_window' CONST[620] staged
            0x85b02) then GetAttr over 'load_url' staged 0x85b47;
            the kind-1 count-1 wrap over the live CONST[621]
            'https://nighty.one/download/files/ui/auth.html'
            (plain literal — no a9d48 build); the one-positional
            call; result released, silent-None tail through the
            ret-disp; corpus events 20-77.
        """
        self._window.load_url(
            'https://nighty.one/download/files/ui/auth.html')

    def openDevPortal(self):
        """Registry L8646. Content: chunk L8654 — recovered from the
        island bytes of chunk 8654 (dump file
        chunk8654_openDevPortal_L8646.txt, +0 align, 95 events,
        502 insns, read complete), cross-checked against the
        complete stream section (function@L8646, corpus lines
        23388-23480, read complete).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x85ca2
            with the GOT_000 binder (r8d=1) at 0x85cd1; one
            PyCell opened ([rsp+0xb0], bpl=1 result-flag).
        [E:] THE API — the 'BotTokenApi' CONST[617] name-load
            0x85d01-0x85d20, zero-arg class call 0x85d36-0x85d49,
            the instance stored into the cell (PyCell_Set) —
            js_api's instance; corpus events 48-63.
        [E:] THE WINDOW — the 'webview' CONST[81] name-load,
            GetAttr 'create_window'; the kind-1 title tuple over
            the live 115-byte CONST[618]; the six-pair kwargs
            build ecx=6/edx=6 with the first pair ('url',
            the a9d48 1-piece format over CONST[115]
            'https://discord.com/login') then frame pairs
            width=1200, height=1000, resizable=False,
            frameless=False, js_api=the PyCell instance; the
            call (r8d=1 pos-title, r9d=1 kwargs); corpus events
            81-135.
        [E:] THE BIND + INJECT — instance.set_window(window) via
            the cell (GetAttr 'set_window'); the closure make
            0x8611f-0x86171 (a9d58 with one freevar = the
            instance cell); the inner body at 0x86300 loads the
            freevar cell and GetAttr 'discordAppLogin' CONST[619]
            0x8636b-0x86384, zero-arg call, silent-None tail —
            api.discordAppLogin(); the events.loaded INPLACE add
            (a9d10 sel-0xe) over the window with the SetAttr
            store-back (the py38 x.events.loaded += law); NO
            webview.start() call in the span; corpus events
            143-282.

        FLAG: the api/window locals and the loaded-handler lambda
            form are name-inferred (the a9d58 carries one
            freevar over the instance cell; the body = a single
            zero-arg discordAppLogin() call at 0x86300).
        """
        api = BotTokenApi()
        window = webview.create_window(
            "Get your application token by clicking 'Reset "
            "Token', then paste it into Nighty. You can close "
            "this window after.",
            url='https://discord.com/login',
            width=1200,
            height=1000,
            resizable=False,
            frameless=False,
            js_api=api)
        api.set_window(window)
        window.events.loaded += lambda: api.discordAppLogin()

    def getAppTokenInput(self, input_value):
        """Registry L8654. Content: chunk L8670 — recovered from the
        island bytes of chunk 8670 (dump file
        chunk8670_getAppTokenInput_L8654.txt, +0 align, 80 events,
        429 insns, read complete), cross-checked against the
        complete stream section (function@L8654, corpus lines
        23482-23563, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[613] ('self',
            'input_value') staged 0x86490 with the GOT_000 binder
            (r8d=2) at 0x864bc.
        [E:] THE VALIDATE GATE — the 'is_discord_bot_token_valid'
            CONST[614] name-load 0x864d1-0x864ed, the kind-1 wrap
            over the input_value param and the one-positional
            call 0x86503-0x8653f; the IsTrue gate 0x86578-0x865d5
            with the law-8 not-swap pair (the falsy token side
            materializes True 0x865a4) — the failure path jumps
            0x86605 to the bridge error; corpus events 30-64.
        [E:] THE ERROR ARM — the 'evaluate_js' name-load
            0x8660c-0x8662c, the kind-1 wrap over the live
            173-byte CONST[615] pauseWithError string
            0x866b5-0x866d5, the one-positional call 0x866f3,
            the r15d flag cleared 0x86701 and the early exit
            0x86890 -> the silent-None tail; corpus events
            66-228.
        [E:] THE SAVE — the 'getConfigData' name-load + zero-arg
            call; the ['logins'] GetItem; the
            'getActiveProfileName' name-load + zero-arg call;
            the ['app'] GetItem; the ['token'] SetItem against
            the input_value param; the 'saveConfigData' call
            over the kind-1 (config,) wrap; corpus events
            66-153.
        [E:] THE RELAUNCH — the 'bot' CONST[244] name-load,
            GetAttr 'run'; the kwargs kind-3 count-2 build —
            ('token': the getCurrentToken() zero-arg call) and
            ('reconnect': True) — the zero-positional kwargs
            dispatch (r8d=0/r9d=1) — bot.run(token=
            getCurrentToken(), reconnect=True); silent-None
            tail; corpus events 165-243.

        FLAG: the `config` local is name-inferred; the early
            `return` is evidenced by the invalid path's
            dedicated jump to the release tail (0x86704 ->
            0x86890) rather than falling into the save chain.
        """
        if not is_discord_bot_token_valid(input_value):
            evaluate_js(
                'pauseWithError({\n                    title: '
                '"Invalid app token",\n                    '
                'description: "The provided token is invalid. '
                'Please try again.",\n                })')
            return
        config = getConfigData()
        config['logins'][getActiveProfileName()]['app'][
            'token'] = input_value
        saveConfigData(config)
        bot.run(token=getCurrentToken(), reconnect=True)

    def saveKeyToAppdata(self, license):
        """Registry L8670. Content: chunk L8702 — recovered from the
        island bytes of chunk 8702 (dump file
        chunk8702_saveKeyToAppdata_L8670.txt, +0 align, 244
        events, 1283 insns, read complete), cross-checked against
        the complete stream section (function@L8670, corpus lines
        23565-23871, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[584] ('self',
            'license') staged 0x86b12 with the GOT_000 binder
            (r8d=2) at 0x86b3e.
        [E:] THE SESSION — the 'requests' CONST[130] name-load +
            'Session' GetAttr + zero-arg call storing [rsp+0x88];
            the mount chain: GetAttr 'mount', the 'https://'
            literal, the 'HTTPAdapter' and 'Retry' name-loads
            (bare globals — LOAD_GLOBAL, no module prefix), the
            Retry kwargs kind-3 count-3 — ('total': 50),
            ('status_forcelist': the kind-2 count-4 list over
            429/500/503/504), ('backoff_factor': 5) — the
            HTTPAdapter kwargs kind-3 count-1 ('max_retries'),
            and the kind-1 count-2 mount args; corpus events
            49-194.
        [E:] THE LICENSE GATE — the 'isValidKey' CONST[599]
            name-load 0x86eba-0x86edc, the kind-1 (license,)
            call; the falsy result stages the 'Invalid license
            error' CONST[611] and jumps the shared return;
            corpus events 184-231.
        [E:] THE POST (try) — the post GetAttr; the URL f-string
            over the 'SERVER_TO_USE' name-load + the two-piece
            finalize with CONST[600] '/v2' — f'{SERVER_TO_USE}/
            v2'; the json kwargs kind-3 count-2 — ('key': the
            str chain over encryptRSA(license)) and ('uuid': the
            same str/encryptRSA chain over getUUID()) — then the
            outer kwargs count-3 ('json'/..., 'verify': False,
            'timeout': the (10, 30) tuple const); the call
            (r8d=1, r9d=1); corpus events 234-372.
        [E:] THE RETRY ARM — the post-failure fall fetches the
            exception and matches it via a9d30 sel-0xa with NO
            match const (law 9 — the bare except); the matched
            swallow re-runs the identical post build
            0x8751e-0x87a86 and rejoins the close stage; the
            unmatched arm raises through GOT_002; corpus events
            202-519.
        [E:] THE LADDER — session.close() via GetAttr; the sel-2
            == against 200 over the GetAttr 'status_code'; the
            200 arm takes response.json() (a dead local: stored
            [rsp+0x98] and never read again); the second sel-2
            against 401 — the 401 arm jumps the
            'Invalid license error' return, the final else
            stages the 'Failed to connect' CONST[612]; corpus
            events 572-652.
        [E:] THE SUCCESS ARM — the 'updateKey' CONST[604]
            name-load with the kind-1 (license,) call;
            evaluate_js('animateFormOut();') over CONST[605];
            the 'time' name-load + GetAttr 'sleep' + the kind-1
            (1.3,) call; the 'main_ui' name-load + GetAttr
            'load_url' and the zero-positional kwargs call over
            the kind-3 count-1 ('url': CONST[608] the
            discord_login.html) — main_ui.load_url(url=...);
            the 'Success' CONST[609] staged for the shared
            return; corpus events 685-782.
        [E:] THE OUTER GUARD — every ladder/error fall jumps the
            a9d40 fetch + a9d30 sel-0xa self-pair, NO match
            const (law 9 — the second bare except); the matched
            arm stages the 'Failed to connect' return — return
            'Failed to connect'; the unmatched arm raises
            GOT_002; the returns ride rdi; corpus events
            202-231/795-819.

        FLAG: the session/response/data locals are
            name-inferred; both bare excepts are flagged per
            law 9 (no-match self-pair guards with real arm
            code — the try-form is forced by the retry-arm and
            the 612-arm emission).
        """
        session = requests.Session()
        session.mount('https://', HTTPAdapter(
            max_retries=Retry(total=50,
                              status_forcelist=[429, 500, 503, 504],
                              backoff_factor=5)))
        try:
            if not isValidKey(license):
                return 'Invalid license error'
            try:
                response = session.post(
                    f'{SERVER_TO_USE}/v2',
                    json={'key': str(encryptRSA(license)),
                          'uuid': str(encryptRSA(getUUID()))},
                    verify=False,
                    timeout=(10, 30))
            except:
                response = session.post(
                    f'{SERVER_TO_USE}/v2',
                    json={'key': str(encryptRSA(license)),
                          'uuid': str(encryptRSA(getUUID()))},
                    verify=False,
                    timeout=(10, 30))
            session.close()
            if response.status_code == 200:
                data = response.json()
            elif response.status_code == 401:
                return 'Invalid license error'
            else:
                return 'Failed to connect'
            updateKey(license)
            evaluate_js('animateFormOut();')
            time.sleep(1.3)
            main_ui.load_url(
                url='https://nighty.one/download/files/ui/'
                    'discord_login.html')
            return 'Success'
        except:
            return 'Failed to connect'

    def saveTokenToConfig(self, token):
        """Registry L8702. Content: chunk L8723 — recovered from the
        island bytes of chunk 8723 (dump file
        chunk8723_saveTokenToConfig_L8702.txt, +0 align, 155
        events, 837 insns, read complete), cross-checked against
        the complete stream section (function@L8702, corpus lines
        23873-24055, read complete). The SECOND saveTokenToConfig
        — the web-settings-tier twin of the shipped add-account
        saveTokenToConfig@L8263; the deltas: the f-formatted keys
        and the success return.

        [E:] THE SIGNATURE — the names-tuple CONST[276] ('self',
            'token') staged 0x88084 with the GOT_000 binder
            (r8d=2) at 0x880b0.
        [E:] THE VERIFICATION GET — the 'requests' name-load +
            'get' GetAttr; the kind-1 wrap over the live
            CONST[131] 'https://discord.com/api/v10/users/@me';
            the headers kind-3 count-3 — the first pair
            ('Authorization' staged against the token param),
            frame pairs 'Content-Type'/'application/json' and
            'User-Agent' against the full live client UA
            CONST[137]; the kwargs kind-3 count-3 ('headers'/...,
            'verify': False, 'timeout': the 20 const); the call
            (r8d=1/r9d=1); corpus events 37-115.
        [E:] THE GATE — GetAttr 'status_code' + the a9d30 sel-2
            against 200 with the False materialize — if
            r.status_code == 200; corpus events 115-154.
        [E:] THE 200 ARM — response.json(); data.get('username');
            the f-key build: the -1 a9d48 format over the
            username + the 1-piece finalize; the 'token' pair
            against the str chain over the token param;
            date_added against the datetime/now/strftime chain
            over the format string; 'active' against True; the
            entry kind-3 count-3; the SetItem logins[f-key] =
            entry; the fresh getConfigData + the
            config['logins'] = logins SetItem; the
            saveConfigData call; the 'setActiveProfile' name-load
            + the kind-1 (username,) call; the 'autoApp' name-
            load + zero-arg call; the SECOND username f-build
            and the result dict kind-3 count-1 wrapping the
            success dict (('status': 'success'), ('text':
            'Account added.')) — the return {f'{username}':
            {'status': 'success', 'text': 'Account added.'}};
            corpus events 202-502.
        [E:] THE ELSE ARM — the 'evaluate_js' name-load + the
            kind-1 wrap over CONST[158] 'location.reload();',
            the call, then the error dict kind-3 count-2
            (('status': 'error'), ('text': 'Invalid token.'))
            RETURNED; corpus events 158-193.

        FLAG: the locals follow the shipped L8263 twin's
            spellings; the tier-deltas vs L8263: the f-string key
            (no str-const in the chain) and the final keyed
            success-dict return.
        """
        r = requests.get(
            'https://discord.com/api/v10/users/@me',
            headers={
                'Authorization': token,
                'Content-Type': 'application/json',
                'User-Agent': (
                    'Mozilla/5.0 (Windows NT 10.0; WOW64) '
                    'AppleWebKit/537.36 (KHTML, like '
                    'Gecko) discord/1.0.9001 '
                    'Chrome/83.0.4103.122 '
                    'Electron/9.3.5 Safari/537.36')},
            verify=False,
            timeout=20)
        if r.status_code == 200:
            data = r.json()
            username = data.get('username')
            config = getConfigData()
            logins = config['logins']
            logins[f'{username}'] = {
                'token': str(token),
                'date_added': datetime.now().strftime(
                    '%d %B %Y, at %H:%M:%S'),
                'active': True}
            config = getConfigData()
            config['logins'] = logins
            saveConfigData(config)
            setActiveProfile(username)
            autoApp()
            return {f'{username}': {'status': 'success',
                                   'text': 'Account added.'}}
        else:
            evaluate_js('location.reload();')
            return {'status': 'error', 'text': 'Invalid token.'}

    def verifyDevPortalPass(self, password):
        """Registry L8723. Content: chunk L8776 — recovered from the
        island bytes of chunk 8776 (dump file
        chunk8776_verifyDevPortalPass_L8723.txt, +0 align, 378
        events, 1924 insns, read complete), cross-checked against
        the complete stream section (function@L8723, corpus lines
        24057-24458, read complete). A locked-tier upgrade over
        the shipped pass-tier dev_portal_verification.py draft:
        five deltas are byte-pinned below.

        [E:] THE SIGNATURE — the names-tuple CONST[579] ('self',
            'password') staged 0x88d98 with the GOT_000 binder
            (r8d=2) at 0x88dc7; self is never read — the tail
            releases it and the frame uses app_manager's
            product instead.
        [E:] THE FACTORY (DELTA 1) — three PyCell_New; the
            'app_manager' CONST[558] name-load and the ZERO-ARG
            CALL (a9d20, r8d=0/r9d=0) — app_manager() IS CALLED,
            a factory (the shipped pass-tier draft treated it as
            a bare global); every later .session GetAttr reads
            the instance, NOT self.
        [E:] THE MFA FINISH — getConfigData; getCurrentAppId;
            getCurrentAppToken (the stored ticket); the
            headers.update chain over ('Authorization' =
            getCurrentToken()); the post GetAttr; the kind-1
            wrap over the MFA-finish URL const (plain literal —
            no join); the json dict kind-3 count-3 — ('ticket':
            the ticket), ('mfa_type': 'password'), ('data': the
            password param) — wrapped in the kwargs ('json': ...)
            and the call (r8d=1/r9d=1); corpus events 128-296.
        [E:] THE 200 ARM — the sel-2 == 200 gate;
            response.json(); the first write (DELTA 2): the
            a9d48 three-piece build over '\n' + the -1 format
            of the WHOLE payload + '\n' and the write call —
            sys.stdout.write(f'\n{data}\n'); the data['token']
            GetItem lands AFTER the write; corpus events
            339-451.
        [E:] THE RESET — the second headers.update over the
            Cookie dict: ('Cookie') against the two-piece a9d48
            join of '__Secure-recent_mfa=' + the -1 format of
            the mfa-finish token (DELTA 3: the cookie value =
            the mfa-finish token, not register-held); the
            second post; the URL three-piece join: the literal
            head + the -1 format of the app_id + '/bot/reset' —
            f'https://discord.com/api/v9/applications/{
            app_id}/bot/reset' — one positional, NO kwargs;
            response2.json(); the second f'\n{data}\n' write +
            the after-write data['token'] extraction (DELTA 4:
            distinct from the mfa cookie token); corpus events
            451-680.
        [E:] THE WRITE-BACK — the config ['logins']+
            [getActiveProfileName()]+['app'] chain with the
            ['id'] SetItem against the app_id, the second chain
            with the ['token'] SetItem against the reset token;
            the saveConfigData call; corpus events 682-819.
        [E:] THE RELAUNCH — the 'AppAuthorizeApi' name-load +
            zero-arg class call, the PyCell_Set; the live
            484-byte CONST[580] injection snippet PyCell_Set;
            the webview + create_window chain; the title tuple
            over CONST[577] 'Authorize Nighty'; the url pair
            through the a9d48 1-piece format over
            CONST[115] (the discord.com/login); the six kwargs
            with width=1200, height=1000, resizable=False,
            frameless=False, js_api = the instance; the
            create_window call; the window PyCell_Set; the
            instance set_window(window); the closure make
            (a9d58 with THREE freevar cells: instance, window,
            snippet); the events.loaded INPLACE add a9d10
            sel-0xe with the SetAttr store-back; the closure
            body: the three cell loads, the instance
            .discordLogin() const zero-arg call, then the
            window.evaluate_js kind-1 wrap over the snippet
            cell; corpus events 822-1110. NO webview.start()
            in the span (DELTA 5).
        [E:] THE GUARD — every error fall jumps the DAT_a9d40
            fetch + the a9d30 sel-0xa match over 'Exception'
            (a real match const — law 9); the matched arm binds
            the exc value and calls logging.error over the
            kind-1 wrap — logging.error(e) — then releases the
            triple (DELTA: no re-raise on the matched arm — the
            GOT_002 is the unmatched-arm escape; the function
            ends returning None); corpus events 1153-1245.

        FLAG: all locals are name-inferred; the except alias e
            is slot-inferred per law 9.
        """
        try:
            manager = app_manager()
            config = getConfigData()
            app_id = getCurrentAppId()
            app_token = getCurrentAppToken()
            manager.session.headers.update(
                {'Authorization': getCurrentToken()})
            response = manager.session.post(
                'https://discord.com/api/v9/mfa/finish',
                json={'ticket': app_token,
                      'mfa_type': 'password',
                      'data': password})
            if response.status_code == 200:
                data = response.json()
                sys.stdout.write(f'\n{data}\n')
                mfa_token = data['token']
                manager.session.headers.update(
                    {'Cookie': f'__Secure-recent_mfa={mfa_token}'})
                response = manager.session.post(
                    f'https://discord.com/api/v9/'
                    f'applications/{app_id}/bot/reset')
                data = response.json()
                sys.stdout.write(f'\n{data}\n')
                bot_token = data['token']
                config['logins'][getActiveProfileName()][
                    'app']['id'] = app_id
                config['logins'][getActiveProfileName()][
                    'app']['token'] = bot_token
                saveConfigData(config)
            api = AppAuthorizeApi()
            snippet = ('\n    console.log(`injected`)\n    var '
                       'previousUrl = window.location.href;\n'
                       '    function checkUrlChange() {\n'
                       '        var currentUrl = '
                       'window.location.href;\n        if '
                       '(currentUrl !== previousUrl) {\n'
                       '            previousUrl = currentUrl;\n'
                       '            console.log(`URL changed: '
                       '${currentUrl}`)\n            pywebview.api.'
                       'url_change_callback_app(currentUrl);\n'
                       '        }\n        setTimeout('
                       'checkUrlChange, 1000); // Check every '
                       'second\n    }\n\n    checkUrlChange();\n'
                       '                ')
            window = webview.create_window(
                'Authorize Nighty',
                url='https://discord.com/login',
                width=1200,
                height=1000,
                resizable=False,
                frameless=False,
                js_api=api)
            api.set_window(window)

            def on_loaded():
                api.discordLogin()
                window.evaluate_js(snippet)

            window.events.loaded += on_loaded
        except Exception as e:
            logging.error(e)


    def verifyDevPortalMfa(self, mfa_code):
        """Registry L8776. Content: chunk L8829 — recovered from the
        island bytes of chunk 8829 (dump file
        chunk8829_verifyDevPortalMfa_8776.txt, @0x8ab70
        +7504, alignment +0, 366 events, 1870 insns, read
        complete), cross-checked against the complete stream
        section (function@L8776, corpus lines 24460+). The
        TOTP twin of the shipped verifyDevPortalPass@L8723 —
        the same five-delta-corrected lifecycle with three
        evidenced substitutions, every address below
        chunk-8829-locked.

        [E:] THE SIGNATURE — the names-tuple CONST[557]
            ('self', 'mfa_code') staged 0x8abc8 with the
            GOT_000 binder (r8d=2) at 0x8abf7; self is never
            read (the pass twin's [E:]; the tail releases
            it).
        [E:] THE FACTORY — three PyCell_New; the 'app_manager'
            CONST[558] name-load with the ZERO-ARG call —
            app_manager() IS CALLED, a factory; every
            .session read walks the instance, never self
            (DELTA-1 twin of the pass decode).
        [E:] THE HEAD WALK — the config/getCurrentAppId/
            getCurrentAppToken family + the headers.update
            over ('Authorization': getCurrentToken()); the
            stored-ticket local feeds the json below.
        [E:] THE MFA JSON (DELTA-2) — the kind-3 count-3 dict:
            ('ticket': the stored ticket), ('mfa_type':
            'totp' CONST[569] staged 0x8b0d0 — the TOTP
            substitution), ('data': the mfa_code param); the
            mfa-finish POST with the ('json': ...) kwargs
            (the plain URL literal — no join).
        [E:] THE 200 ARM — the sel-2 == 200 gate; the
            response.json(); the first write = the a9d48
            three-piece over '\n' + the -1 format of the
            WHOLE payload + '\n' — sys.stdout.write(
            f'\n{data}\n'); the data['token'] GetItem lands
            AFTER the write.
        [E:] THE RESET — the headers.update over ('Cookie')
            against the two-piece a9d48 join of
            '__Secure-recent_mfa=' CONST[571] staged
            0x8b4c0 + the -1 format of the mfa-finish token;
            the second post over the three-piece f-string
            head 'https://discord.com/api/v9/applications/'
            CONST[572] staged 0x8b5f7 + the -1 format of
            the app_id + '/bot/reset' CONST[573] staged
            0x8b62b; the second f'\n{data}\n' write + the
            after-write data['token'] extraction.
        [E:] THE WRITE-BACK — the config ['logins']+
            [getActiveProfileName()]+['app'] chains with the
            ['id'] SetItem against the app_id + the
            ['token'] SetItem against the reset token; the
            saveConfigData call.
        [E:] THE RELAUNCH (DELTA-3) — the 'AppAuthorizeApi'
            name-load + zero-arg class call; the live
            484-byte watcher snippet CONST[576] staged
            0x8bd10 (the url_change_callback_app variant,
            byte-identical to the pass variant's CONST[580]
            copy); the webview + create_window chain with
            the title 'Authorize Nighty' CONST[577] staged
            0x8bdef, url=CONST[115] staged 0x8be3f
            ('https://discord.com/login'), width=1075
            CONST[117] staged 0x8be7b, height=670
            CONST[119] staged 0x8be99, resizable=False,
            frameless=False, js_api=the instance; the
            set_window call; the closure make with THREE
            freevar cells (the a9d58 pair); the
            events.loaded INPLACE adds with the SetAttr
            store-back (CONST[126] staged 0x8c151/0x8c175/
            0x8c225/0x8c249; CONST[128] staged
            0x8c1a1/0x8c276); the closure body: the
            instance .discordLogin() + the window
            .evaluate_js over the snippet cell; NO
            webview.start() in the span.
        [E:] THE GUARD — the DAT_a9d40 fetch + the a9d30
            sel-0xa match over 'Exception' CONST[77] staged
            0x8c310; the matched arm binds the alias and
            calls logging.error(e) — swallowed, no re-raise;
            the unmatched arm escapes through GOT_002 at
            0x8c4b3; the epilogues stage CONST[30] None
            (0x8c5cd / 0x8c857) — the function ends
            returning None.

        FLAG: the locals are name-inferred from the pass
            twin's frame; the except alias e is
            slot-inferred.
        """
        try:
            manager = app_manager()
            config = getConfigData()
            app_id = getCurrentAppId()
            app_token = getCurrentAppToken()
            manager.session.headers.update(
                {'Authorization': getCurrentToken()})
            response = manager.session.post(
                'https://discord.com/api/v9/mfa/finish',
                json={'ticket': app_token,
                      'mfa_type': 'totp',
                      'data': mfa_code})
            if response.status_code == 200:
                data = response.json()
                sys.stdout.write(f'\n{data}\n')
                mfa_token = data['token']
                manager.session.headers.update(
                    {'Cookie': f'__Secure-recent_mfa={mfa_token}'})
                response = manager.session.post(
                    f'https://discord.com/api/v9/'
                    f'applications/{app_id}/bot/reset')
                data = response.json()
                sys.stdout.write(f'\n{data}\n')
                bot_token = data['token']
                config['logins'][getActiveProfileName()][
                    'app']['id'] = app_id
                config['logins'][getActiveProfileName()][
                    'app']['token'] = bot_token
                saveConfigData(config)
            api = AppAuthorizeApi()
            snippet = ('\n    console.log(`injected`)\n    var '
                       'previousUrl = window.location.href;\n'
                       '    function checkUrlChange() {\n'
                       '        var currentUrl = '
                       'window.location.href;\n        if '
                       '(currentUrl !== previousUrl) {\n'
                       '            previousUrl = currentUrl;\n'
                       '            console.log(`URL changed: '
                       '${currentUrl}`)\n            pywebview.api.'
                       'url_change_callback_app(currentUrl);\n'
                       '        }\n        setTimeout('
                       'checkUrlChange, 1000); // Check every '
                       'second\n    }\n\n    checkUrlChange();\n'
                       '                ')
            window = webview.create_window(
                'Authorize Nighty',
                url='https://discord.com/login',
                width=1075,
                height=670,
                resizable=False,
                frameless=False,
                js_api=api)
            api.set_window(window)

            def on_loaded():
                api.discordLogin()
                window.evaluate_js(snippet)

            window.events.loaded += on_loaded
        except Exception as e:
            logging.error(e)
