"""
app_manager_windows.py — the app-manager login controller class
from the SPP native core (registry L8443-L8452), recovered from
the corpus event streams plus island dumps — the L8452 tier a
merged-region island-only recovery whose consts are re-snatched
live. The four shipped members: the window-wrapper marquees and
the login injector with its MutationObserver token watcher.
getAppToken@L8508 (shipped separately) is the login bootstrap —
load the loading page, persist the fetched token into
config['logins'][active profile]['app']['token'], save, then
relaunch via os.execv(sys.executable, ['python'] + sys.argv).

  __init__(self)             — self._window = None
  set_window(self, window)   — the wrapper binding
  close(self)                — the window destroy
  discordAppLogin(self)      — the bot-page injector + watcher

CLASS NAME FLAG: no live const names this class (the app_manager
CONST[558] global names the INSTANCE tier); inferred name
AppManagerLoginApi, flagged; rename when the booter islands
surface the js_api consts.
"""

import logging  # noqa: F401


class AppManagerLoginApi:

    def __init__(self):
        """Registry L8443. Content: chunk L8446 — recovered from the
        island bytes of chunk 8446 (dump file
        chunk8446_init_L8443.txt, per the dumper +2 align, 17
        events, 89 insns, read complete through the set_window
        prologue), cross-checked against the complete stream
        section (function@L8443, corpus lines 22558-22573, read
        complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x81324 with the GOT_000 binder (r8d=1) at
            0x81350.
        [E:] THE BODY — '_window' CONST[620] staged 0x8136a with
            the None CONST[30] staged 0x81378, the SetAttr over
            the [rsp+0x58] self — self._window = None — the
            tail None materialization 0x813e2 and the implicit
            return through the ret-disp (a9d28) at 0x8141a;
            the WebWindow.__init__@L7397 emission law's fifth
            member; corpus events 18-58.
        """
        self._window = None

    def set_window(self, window):
        """Registry L8446. Content: chunk L8449 — recovered from the
        island bytes of chunk 8449 (dump file
        chunk8449_set_window_L8446.txt, per the dumper +0 align,
        14 events, 92 insns, read complete), cross-checked
        against the complete stream section (function@L8446,
        corpus lines 22574-22586, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[651]
            ('self', 'window') staged 0x8148f with the GOT_000
            binder (r8d=2) at 0x814bb.
        [E:] THE BODY — the '_window' CONST[620] staged
            0x814d5, the SetAttr binding the second target —
            self._window = window — the implicit None return
            (0x8155d) through the ret-disp at 0x81572; the
            set_window@L7400 emission law; corpus events 20-59.
        """
        self._window = window

    def close(self):
        """Registry L8449. Content: chunk L8452 — recovered from the
        island bytes of chunk 8452 (dump file
        chunk8452_close_L8449.txt, per the dumper +3 align, 18
        events, 109 insns, read complete), cross-checked against
        the complete stream section (function@L8449, corpus
        lines 22587-22607, read complete).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x815d5 with the GOT_000 binder (r8d=1) at
            0x81601.
        [E:] THE BODY — GetAttr(self, '_window' staged 0x81622)
            then GetAttr over 'destroy' staged 0x81667, the
            zero-argument call — self._window.destroy() — the
            close@L7406 emission law with the implicit None
            return through the ret-disp at 0x816fe; corpus
            events 19-70.
        """
        self._window.destroy()

    def discordAppLogin(self):
        """Registry L8452. Content: chunk L8508 — recovered from the
        island bytes of chunk 8508 (dump file
        chunk8508_discordAppLogin_L8452.txt, per the dumper +0
        align, 59 events, 334 insns, read complete through the
        getAppToken prologue), cross-checked against the stream
        section (function@L8452, corpus lines 22608-22609 — a
        merged-region minimal section carrying only the header;
        the island body is the authority). The manager window's
        login injector: re-seed the bot token on the developers
        portal, force the app's bot page, then install the
        MutationObserver token watcher that bridges
        pywebview.api.getAppToken.

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x81783 with the GOT_000 binder (r8d=1) at
            0x817af.
        [E:] THE SIDE-EFFECT FETCH — getConfigData() called bare:
            the global (CONST[145]) staged 0x817c4, loaded
            through the a9d50 stage at 0x817e0, called zero-arg
            at 0x81809, stored [rsp+0x70] (0x8181c) and released
            at 0x81bb9 WITHOUT ever being read — a bare statement
            in the source (the discordLogin@L8102 side-effect
            law: the config-cache refresh preceding the
            injection).
        [E:] THE VALUES — getCurrentToken() (CONST[563] staged
            0x81833, the a9d50 stage 0x8184f, the zero-arg call
            0x81878, stored [rsp+0x78] at 0x81888) and
            getCurrentAppId() (CONST[559] staged 0x8189f, the
            stage 0x818bb, the call 0x818e4, stored [rsp+0x80] at
            0x818f7).
        [E:] THE WINDOW CHAIN — GetAttr(self [rsp+0x68], '_window'
            CONST[620] staged 0x81925, resolved 0x81939) then
            GetAttr over 'evaluate_js' CONST[41] staged 0x8196a
            (resolved 0x81983) bound at [rsp+0x48] (0x81989).
        [E:] THE SEVEN-PIECE F-STRING — the a9d48 finalize with
            ecx=7 at 0x81a75-0x81a83: rdx = the live CONST[656]
            staged 0x819b9, r8 = the r8d=-1 sub-built [rsp+0x80]
            appid piece (0x819d1-0x819eb), r9 = the live
            CONST[657] staged 0x819f0, and the frame slots
            [rsp+0x20..0x38] = the r8d=-1 sub-built [rsp+0x78]
            token piece (0x81a06-0x81a1d), the live CONST[658]
            staged 0x81a22 with its [rsp+0x80] appid sub-build
            (0x81a37-0x81a51), and the live CONST[659] staged
            0x81a53 — the seven pieces in exact source order:
            [656][appid][657][token][658][appid][659], kind-1
            wrapped 0x81a86-0x81a93 and passed one-positional to
            the evaluate_js call at 0x81ab4. The literals are
            live-quoted; the JS braces double-escape in the
            f-string source.
        [E:] THE WATCHER — the second chain: GetAttr(self,
            '_window' staged 0x81ae0, resolved 0x81af4) then
            'evaluate_js' staged 0x81b25 (resolved 0x81b3e), the
            kind-1 wrap over the live CONST[660] staged 0x81b64
            (the async MutationObserver form watcher: it awaits
            the portal form, finds the Token label wrapper,
            watches its child-list mutations and bridges every
            >=60-char text value through
            pywebview.api.getAppToken, then disconnects), the
            one-positional call at 0x81b9b, the DecRef epilogue
            over [rsp+0x68]/[rsp+0x70]/[rsp+0x78]/[rsp+0x80]
            (0x81bae-0x81bd7) with the bpl success flag and the
            implicit None return (CONST[30] staged 0x81c00)
            through the ret-disp (a9d28) at 0x81be7.
        """
        getConfigData()
        token = getCurrentToken()
        appid = getCurrentAppId()
        self._window.evaluate_js(
            f'\n    if (window.location.href !== '
            f'"https://discord.com/developers/applications/'
            f'{appid}/bot") {{\n'
            f'        document.body.appendChild('
            f'document.createElement `iframe`).contentWindow'
            f'.localStorage.token = `"{token}"`\n'
            f'        window.location.href = '
            f'"https://discord.com/developers/applications/'
            f'{appid}/bot";\n'
            f"        alert('Click on \"Reset Token\" to get your "
            f'app token.\')\n    }}')
        self._window.evaluate_js(
            '\n(async function() {\n'
            "    'use strict';\n"
            '    const sleep = ms => new Promise('
            'r => setTimeout(r, ms));\n\n'
            '    function getForm() {\n'
            '        return new Promise(async (resolve) => {\n'
            '            let form;\n\n'
            '            while(!form) {\n'
            "                form = document.querySelector('form');\n"
            '                await sleep(200)\n'
            '            };\n\n'
            '            resolve(form)\n'
            '        })\n'
            '    };\n\n'
            '    function getTokenWrapper() {\n'
            '        const allLabelElements = [...document.'
            "querySelectorAll('label')];\n"
            '        const tokenLabel = allLabelElements.find('
            "label => label.textContent.trim() === 'Token');\n"
            '        return tokenLabel.parentElement.'
            'parentElement;\n'
            '    }\n\n'
            '    function sendTokenToBackend(token) {\n'
            '        console.log(token);\n'
            '        pywebview.api.getAppToken(token);\n'
            '    }\n\n'
            '    function tokenWatcher(changedNodes, observer) {\n'
            '        for(const node of changedNodes) {\n'
            '            if(node.addedNodes[0].nodeName !== '
            '"#text" || node.addedNodes[0].length < 60) '
            'continue;\n\n'
            '            sendTokenToBackend('
            'node.addedNodes[0].textContent);\n'
            '            observer.disconnect()\n'
            '        }\n'
            '    }\n\n\n'
            '    const form = await getForm();\n'
            '    const wrapper = getTokenWrapper();\n'
            '    console.log(wrapper)\n'
            '    const observer = new MutationObserver('
            'tokenWatcher);\n'
            '    observer.observe(wrapper, {childList: true, '
            'subtree: true})\n'
            '})();')
