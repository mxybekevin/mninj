"""
token_crypto.py — Nighty's machine identity + token-protection family,
recovered from the SPP native core via the Ghidra batch-decompilation
lane (oracle/out/ghidra_decomp), with [E:] markers citing the
decompiled lines plus the live const/GOT labels.

Scheme recovered here (all evidenced):
  encryptCurrentToken: for every ACTIVE login in config['logins'],
  each plaintext field (token, app.id, app.token) is protected with
  Windows DPAPI (win32crypt.CryptProtectData(x.encode('utf-8'),
  None, None, None, None, 0)), base64-encoded and stored as
  'N1:' + b64(...); the mutated config is saved with indent=4.
  decryptCurrentToken: the inverse — strips the prefix, pads with
  '=' to a multiple of 4, base64-decodes, and unpacks via
  win32crypt.CryptUnprotectData(..., None, None, None, 0)[1]
  .decode('utf-8') (the [1] tuple index is evidenced), writing all
  three fields back and saving; failures log 'Decrypt failed:'.
  getCurrent*: read-only per-field getters with the same decrypt
  chain; getSniperTokens collects every entry with
  entry.get('active', False) (DEFAULT FALSE — an evidenced quirk
  distinct from the True default of every sibling).
  encryptRSA: hard-coded RSA public key + the cryptography library,
  RSA-OAEP(MGF1(SHA256), SHA256, label=None), hex output.
  getUUID: str(uuid.UUID(int=uuid.getnode())).upper() — the
  machine-fingerprint identity bound to licensing.

Flag RESOLVED post-first-pass: the prefix is the 3-character const
'N1:' (slot 1621 — the label sanitization had hidden the colon), so
startswith('N1:') and the readers' [3:] strip are exactly
consistent. All fields below use the full const.
"""

import base64
import json
import logging
import uuid
import win32crypt
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding


RSA_PUBLIC_KEY_PEM = (
    b'-----BEGIN PUBLIC KEY-----\n'
    b'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvtk0RFtY6XcnA+tH8qEq\n'
    b'fxko7jvqChZVILgavkGfFJpn5T0Yqt2zwbLRoaoEjWVvSQoxva/MTdPw+P9p+41f\n'
    b'3qZx31r6HanEAwS9G19l9MJobbelmw4FG73poCY5ER2N2vKDDnm0kkyD84jLUZWj\n'
    b'0TpzQnRb6h/WJnVD0lbTTMv3kqEIp9ZMlWkWSaCe35ZdLrY2Cpop3gSClHhhWxfQ\n'
    b'WRM7VT3rUZq76JQkoxUmFePmp5EFAU4SXuflU+mWY0nSDricEuAS7SWb9n1zigCp\n'
    b'etcZehBbHZPywXozhdKJr6HZZoHw6Gq/oWCZTAKr2LOKdtj9ko3H2uKLNlHHK6C/\n'
    b'hQIDAQAB\n'
    b'-----END PUBLIC KEY-----'
)


def getUUID():
    """Registry L443. Content: chunk labeled L448 (dossier L00448).

    [E:] argcount=0 (stream stub); consts in order: 'str', 'uuid',
         'UUID' (GetAttr), 'int' (the kwarg name), 'uuid', 'getnode'
         (GetAttr), 'upper' (GetAttr).
    """
    return str(uuid.UUID(int=uuid.getnode())).upper()


def encryptRSA(data):
    """Registry L448. Content: chunk labeled L534 (dossier L00534).

    [E:] signature ('data',) (stream stub).
    [E:] consts: 'serialization' + 'load_pem_public_key' + the full
         450-byte PEM public key (byte const; full text preserved
         above and in out/rsa_public_key.pem, extracted from the
         marshal stream), 'encrypt' (GetAttr on the loaded key),
         'encode' + 'utf-8', 'padding' + 'OAEP', 'mgf' + 'MGF1',
         'algorithm' + 'hashes' + 'SHA256' (twice: MGF1 and OAEP),
         'label' + None, 'hex'.
    """
    public_key = serialization.load_pem_public_key(RSA_PUBLIC_KEY_PEM)
    encrypted = public_key.encrypt(
        data.encode('utf-8'),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None))
    return encrypted.hex()


def encryptCurrentToken():
    """Registry L1562. Content: chunk labeled L1595
    (decomp spp_span_decryptCurrentToken_1595.c). argcount=0.

    [E:] config = getConfigData() (L49-64, GOT_145); logins =
         config.get('logins', {}) (L70-120, 'get' GOT_047,
         'logins' GOT_146); .items() + GetIter + 2-way unpack loop
         (L113-137, 'items' GOT_247, PyObject_GetIter, unpack-2).
    [E:] entry.get('active', True) (L156-203, 'active' GOT_149,
         True GOT_031); if token and not token.startswith('N1:')
         (L320-366, 'startswith' GOT_234, 'N1:' GOT_1621, bool False
         GOT_032 at the 810-813 region of the raw dump).
    [E:] THREE win32crypt.CryptProtectData calls (L368-437, 447-513,
         525-593) over token.encode('utf-8'), app['id'].encode and
         app['token'].encode ('win32crypt' GOT_1623,
         'CryptProtectData' GOT_1628, 'encode' GOT_1629,
         'utf-8' GOT_285, five None args, int 0 = flags); then three
         'N1:' + base64.b64encode(...).decode('utf-8') wraps (L607-640,
         657-712, 725-780; 'b64encode' GOT_1630, 'decode' GOT_1625);
         stored back via SetItem at entry['token'] (L652),
         entry['app']['id'] (L720), entry['app']['token'] (L788).
    [E:] after the loop: open(getConfigPath(), 'w', encoding='utf-8')
         + json.dump(config, f, indent=4) (L833-940, 'open' GOT_201,
         'w' GOT_833, 'json' GOT_143, 'dump' GOT_689, 'indent'
         GOT_690, int 4) then return True (L966-969).
    """
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', True):
            token = entry['token']
            if token and not token.startswith('N1:'):
                app = entry['app']
                enc = win32crypt.CryptProtectData(
                    token.encode('utf-8'), None, None, None, None, 0)
                enc_id = win32crypt.CryptProtectData(
                    app['id'].encode('utf-8'), None, None, None, None, 0)
                enc_token = win32crypt.CryptProtectData(
                    app['token'].encode('utf-8'), None, None, None,
                    None, 0)
                entry['token'] = 'N1:' + base64.b64encode(enc).decode(
                    'utf-8')
                entry['app']['id'] = 'N1:' + base64.b64encode(
                    enc_id).decode('utf-8')
                entry['app']['token'] = 'N1:' + base64.b64encode(
                    enc_token).decode('utf-8')
    with open(getConfigPath(), 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4)
    return True


def decryptCurrentToken():
    """Registry L1595. Content: chunk labeled L1643
    (decomp spp_span_getCurrentAppId_1643.c). argcount=0.

    [E:] same head as encryptCurrentToken (getConfigData ->
         logins.items() -> entry.get('active', True)); fields loaded
         token = entry['token'], app_id = entry['app']['id'],
         app_token = entry['app']['token'] (L239-318, GetItems).
    [E:] gate: if token and token.startswith('N1:') (L327-378).
    [E:] strip: PySlice_New(3, None, None) + GetItem per field
         (L389-449, int 3 GOT_1033, slot GOT_026) — value[3:].
    [E:] pad: if len(x) % 4 (op 0x22 = BINARY_MODULO on the SPP
         binary-op dispatcher, DAT_000a9d10): x = x + '=' *
         (4 - len(x) % 4) (op 0x24 = BINARY_SUBTRACT; '=' GOT_811,
         int 4 GOT_835) (L451-601 for all three fields).
    [E:] unpack: base64.b64decode(x) ('b64decode' GOT_1622,
         L601-655) then win32crypt.CryptUnprotectData(..., None,
         None, None, 0) (L667-708, 'CryptUnprotectData' GOT_1624,
         int 0 GOT_277) and GetItem(result, 1) — the [1] TUPLE INDEX
         IS EVIDENCED (int 1 GOT_233, L709-721) — then
         .decode('utf-8') (L722-733).
    [E:] written back via SetItem to entry['token'] (L900),
         entry['app']['id'] (L938), entry['app']['token'] (L977).
    [E:] real try (DAT_000a9d40 machinery) with except Exception ->
         logging.error('Decrypt failed:' + ...) ('logging' GOT_044,
         'error' GOT_045, 'Decrypt failed:' GOT_1626 — exact string
         WITH colon; the concat operand is not const-visible,
         translated as str(e), flagged) -> return None (L1242-1251).
    [E:] success path: the mutated config is SAVED —
         open(getConfigPath(), 'w', encoding='utf-8') +
         json.dump(config, f, indent=4) (L1077-1163) — then
         return True (L1203-1206).
    """
    config = getConfigData()
    logins = config.get('logins', {})
    try:
        for key, entry in logins.items():
            if entry.get('active', True):
                token = entry['token']
                app_id = entry['app']['id']
                app_token = entry['app']['token']
                if token and token.startswith('N1:'):
                    payload = token[3:]
                    if len(payload) % 4:
                        payload = payload + '=' * (4 - len(payload) % 4)
                    entry['token'] = win32crypt.CryptUnprotectData(
                        base64.b64decode(payload), None, None, None,
                        0)[1].decode('utf-8')
                    payload = app_id[3:]
                    if len(payload) % 4:
                        payload = payload + '=' * (4 - len(payload) % 4)
                    entry['app']['id'] = win32crypt.CryptUnprotectData(
                        base64.b64decode(payload), None, None, None,
                        0)[1].decode('utf-8')
                    payload = app_token[3:]
                    if len(payload) % 4:
                        payload = payload + '=' * (4 - len(payload) % 4)
                    entry['app']['token'] = win32crypt.CryptUnprotectData(
                        base64.b64decode(payload), None, None, None,
                        0)[1].decode('utf-8')
    except Exception as e:
        logging.error('Decrypt failed:' + str(e))
        return None
    with open(getConfigPath(), 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4)
    return True


def _decrypt_n1_field(value):
    """Shared decrypt chain for the getCurrent* getters — each getter
    flattens this inline (three evidenced copies in the corpus); the
    chain: [3:] strip, '=' * (4 - len % 4) pad, base64.b64decode,
    win32crypt.CryptUnprotectData(...)[1].decode('utf-8'). The [1]
    index and the [3:] strip are evidenced (slots 233 / 1033)."""
    payload = value[3:]
    if len(payload) % 4:
        payload = payload + '=' * (4 - len(payload) % 4)
    return win32crypt.CryptUnprotectData(
        base64.b64decode(payload), None, None, None, 0)[1].decode('utf-8')


def getCurrentAppId():
    """Registry L1643. Content: chunk labeled L1672
    (decomp spp_span_getCurrentAppToken_1672.c). argcount=0.

    [E:] same head, then field = entry['app']['id'] (GetItems,
         L210-237); gate `if field and field.startswith('N1:')`
         (L250-308); the [3:]/pad/b64decode/CryptUnprotectData[1]/
         decode chain (L315-466); try/except with return None
         (Exception machinery at L483-547); returns inside the
         first ACTIVE entry whose value carries the prefix;
         falls out to None after the loop.
    """
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', True):
            app_id = entry['app']['id']
            if app_id and app_id.startswith('N1:'):
                try:
                    return _decrypt_n1_field(app_id)
                except Exception:
                    return None
    return None


def getCurrentAppToken():
    """Registry L1672. Content: chunk labeled L1701
    (decomp spp_span_getCurrentToken_1701.c). argcount=0.

    [E:] identical structure to getCurrentAppId but reading
         entry['app']['token'] (GetItem, L210-238) and the same
         evidenced decrypt chain + try/except/return None tail.
    """
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', True):
            app_token = entry['app']['token']
            if app_token and app_token.startswith('N1:'):
                try:
                    return _decrypt_n1_field(app_token)
                except Exception:
                    return None
    return None


def getCurrentToken():
    """Registry L1701. Content: chunk labeled L1730
    (decomp spp_span_getSniperTokens_1730.c). argcount=0.

    [E:] identical structure but reading entry.get('token') — the
         EVIDENCED .get chain (L210-229, 'get' GOT_047 repeated)
         with 'token' as the argument (L233-235) — a read-access
         distinct from the siblings' direct GetItem; same
         startswith('N1:') gate (L259-301), [3:]/pad (L316-374),
         b64decode/CryptUnprotectData[1]/decode (L384-466),
         try/except + return None (L483-548).
    """
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', True):
            token = entry.get('token')
            if token and token.startswith('N1:'):
                try:
                    return _decrypt_n1_field(token)
                except Exception:
                    return None
    return None


def getSniperTokens():
    """Registry L1730. Content: chunk labeled L1738
    (decomp spp_span_getActiveProfile_1738.c). argcount=0.

    [E:] tokens = [] built at the head (dispatcher-built empty list,
         L60); config.get('logins', {}) (L68-105); items/loop
         (L111-115); the gate is entry.get('active', FALSE) —
         default bool FALSE (L157-176, bool_False GOT_032) unlike
         every sibling's True default — flagged as an evidenced
         quirk; tokens.append(entry.get('token')) ('append' GOT_250
         L179-199; the .get('token') value L204-229); returns the
         list after the loop (L256). No decrypt chain is present —
         the raw stored tokens are collected.
    """
    tokens = []
    config = getConfigData()
    logins = config.get('logins', {})
    for key, entry in logins.items():
        if entry.get('active', False):
            tokens.append(entry.get('token'))
    return tokens
