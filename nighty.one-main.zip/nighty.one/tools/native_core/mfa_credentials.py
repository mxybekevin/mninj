"""
mfa_credentials.py — the keyring-backed MFA credential store
(registry L9713-L9766), recovered via the Ghidra decomp lane.

  class MfaCredentialStore   (NAME FLAG: descriptive — the class
      name is not recovered; the evidenced attrs define the
      role: the SERVICE class constant, the _mfa_account hook
      and the keyring/JSON storage)
    _load_secrets(self, channel_id)  — the reader (registry
                                        L9713)
    setCredentials(self, password, totp_seed) — the
                                        profile-locked writer
                                        (registry L9722)
    getPassword(self)                  — the password reader
                                        (registry L9736)
    isConfigured(self)                 — password+totp presence
                                        (registry L9766)

verify(self, ...) (registry L9760) is pending — its stream
shows the bot.get_relationship(int(...)).user +
mfa_enabled/totp_seed verification flow.
"""

import json

import keyring
import time  # noqa: F401


class MfaCredentialStore:
    """The keyring/JSON-backed per-profile credential store."""

    def _load_secrets(self, channel_id=None):
        """Registry L9713 (the secrets reader). Content: chunk
        labeled L9722 (resynced lane-2 decomp
        sppL2_setCredentials_9722.c). Signature ('self',
        'channel_id') [E:] — const-pool tuple slot 406 with the
        function-name const '_load_secrets' at slot 407 (the
        cluster continues into setCredentials' consts at 413+).

        [E:] account = self._mfa_account —
             GetAttr(self, '_mfa_account') (raw L32-55, GOT_413)
             followed by a 0-ARG CALL of the attribute (L58) —
             i.e. a method call: self._mfa_account().
        [E:] gate: the negated-truth select (True/False consts +
             double IsTrue, L66-76); the truthy side runs the
             keyring load (L79-128):
             keyring.get_password(self.SERVICE, account) — the
             keyring LOAD_GLOBAL (GOT_417), 'get_password'
             GetAttr (GOT_423), self.SERVICE GetAttr (GOT_419) +
             the (1,2) args built over (SERVICE, account) at
             L99-124.
        [E:] the result gate (L129-148): falsy password → the
             dispatcher-built empty dict ((3,0) build — dict per
             the json-context invariant, flagged); truthy →
             json.loads(password) (GOT_143/'loads' GOT_424,
             L149-175).
        [E:] the negated-falsy side of the account gate returns
             the same empty-dict build (L178-181); the function
             returns the built dict (the json.loads result or
             {}) — raw L188-205.
        [E:] flag: the channel_id parameter never appears in
             the evidenced body AND verify@L9760's island proves the
             zero-arg caller form ? it carries a default (None is
             the standing convention; the default value itself is
             not const-visible); left default-ed per the call-site
             evidence.
        [E:] flag: the channel_id parameter does not appear in
             the evidenced body (the gate uses the
             _mfa_account() result); left in the signature per
             the evidence — its use may sit in the un-decoded
             prologue zone.
        """
        account = self._mfa_account()
        if account:
            password = keyring.get_password(self.SERVICE,
                                            account)
            if password:
                return json.loads(password)
            return {}
        return {}

    def setCredentials(self, password, totp_seed):
        """Registry L9722. Content: chunk labeled L9736 (stream
        section function@L9722). Signature ('self', 'password',
        'totp_seed') [E:] — const-pool tuple slot 412.

        PARTIALLY RECONSTRUCTED — the gate, totp normalization
        and the keyring write are fully evidenced; the
        default-merge ternaries around the secrets dict are
        cluster-evidenced but their exact operand order is
        flagged (below).

        [E:] gate: `if not self._mfa_account: raise
             RuntimeError('No active profile to store credentials
             for.')` — the _mfa_account GetAttr (GOT_413, L37-57),
             the negated truth select (True/False consts, L70-79),
             RuntimeError staged (GOT_414, L82-93) with the EXACT
             message (GOT_415, L96-99).
        [E:] secrets come from self._load_secrets — the GetAttr
             (GOT_407, L108-122); the a9d30-or clusters at
             L134-175 carry the default-merge ternaries
             (None/IsTrue/False pairs) — flagged: exact merge
             order unresolved.
        [E:] the totp normalization chain — ''.join(totp_seed.
             split()).upper() — totp_seed key (GOT_410), ''
             (GOT_241), 'join' (GOT_166), 'split' (GOT_364),
             'upper' (GOT_416), L183-243; PyObject_SetItem
             (GOT_022, L255) stores under 'totp_seed'.
        [E:] keyring.set_password(self.SERVICE, <account>,
             json.dumps(secrets)) — keyring (GOT_417),
             set_password (GOT_418), self.SERVICE GetAttr (GOT_
             419, L283-300), json.dumps (GOT_143/420, L308-328).
        [E:] flagged fields: has_password (GOT_421) / has_mfa
             (GOT_422) appear with bool() casts (GOT_408) and
             .get (GOT_047) merges at L340-424 with a second
             SetItem under 'password' (GOT_409, L449) — either
             payload members of the dumped dict or merge steps;
             the assembled translation keeps the evidenced
             two-field write + flags the rest.
        [E:] None return (L477-486).
        """
        if not self._mfa_account:
            raise RuntimeError(
                'No active profile to store credentials for.')
        secrets = self._load_secrets()
        secrets['password'] = \
            password or secrets.get('password', '')
        secrets['totp_seed'] = \
            ''.join(totp_seed.split()).upper() or \
            secrets.get('totp_seed', '')
        keyring.set_password(
            self.SERVICE, self._mfa_account(),
            json.dumps(secrets))
        return None

    def getPassword(self):
        """Registry L9736. Content: chunk labeled L9760 (stream
        section function@L9736).

        [E:] return self._load_secrets(<arg-flagged>).get(
             'password') — the _load_secrets GetAttr (GOT_407,
             L26-52), the .get GetAttr (GOT_047, L50-57) with the
             'password' key (GOT_409) in the (1,1) args build
             (L62), single return-op (L71).
        [E:] flag: the _load_secrets call-arg(s) are not
             const-visible in the compressed stream — the
             sibling _load_secrets takes channel_id; translated
             with the arg-flag noted.
        """
        return self._load_secrets().get('password')

    def isConfigured(self):
        """Registry L9766. Content: chunk labeled L9788 (stream
        section function@L9766).

        [E:] secrets = self._load_secrets(<arg-flagged>) —
             GetAttr (GOT_407, L36-56); the bool()-cast chain
             (GOT_408, L74-78) over the .get('password')
             (GOT_047/409, L82-113) with IsTrue (L113), then the
             second .get chain over 'totp_seed' (GOT_410,
             L122-152) with IsTrue (L152); the compound feeds the
             return-op (L170).
        [E:] flag: translated as the and-compound bool(...) —
             the _load_secrets call-arg question is RESOLVED by
             verify@L9760's island (r8d=0: the callers stage
             nothing; corrected to the zero-arg call here and
             across the module); the None cluster is the error
             tail.
        """
        secrets = self._load_secrets()
        return bool(secrets.get('password')) and \
            bool(secrets.get('totp_seed'))

    def __init__(self):
        """Registry L9645. Content: chunk L9648 — recovered from the
        island bytes of chunk 9648 (@0x931a0, 6 events),
        cross-checked against the complete stream section
        (function@L9645, corpus lines 25709-25716).

        [E:] THE EMPTY BODY — the section carries ONLY binder +
            GOT_000 + PyErr_Occurred/Err_Clear + CONST[30] None
            + the a9d28 ret-dispatch: no SetAttrs, no docstring
            const, no other staged consts — the body is exactly
            `pass`.

        FLAG: the instance attributes token/_expires_at (see
            set_token@L9648) are created lazily by set_token —
            not by __init__.
        """
        pass

    def set_token(self, token):
        """Registry L9648. Content: chunk L9653 — recovered from the
        island bytes of chunk 9653 (@0x93260 +784),
        cross-checked against the complete stream section
        (function@L9648, corpus lines 25717-25752).

        [E:] THE SIGNATURE — the names-tuple CONST[276] ('self',
            'token') staged 0x93278 with the GOT_000 binder at
            0x932a4 (r8d=2).
        [E:] THE STORE — SetAttr self.token = token ('token'
            CONST[147] staged 0x932be); SetAttr self._expires_at
            = time.monotonic() + 30 ('_expires_at' CONST[426]
            staged 0x9332f, 'time' CONST[427] + 'monotonic'
            CONST[428] name-load chain, the DAT_a9d10 plain-+
            selector over the int const CONST[225] 30).
        [E:] THE RETURN — GetAttr self.token rides the
            ret-dispatch — return self.token (the freshly set
            value).
        """
        self.token = token
        self._expires_at = time.monotonic() + 30
        return self.token

    def get_token(self):
        """Registry L9653. Content: chunk L9709 — recovered from the
        island bytes of chunk 9709 (@0x93570 +1328),
        cross-checked against the complete stream section
        (function@L9653, corpus lines 25753-25833).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x93578; the GOT_000 binder at
            0x935a4.
        [E:] GATE 1 — the a9d30 over GetAttr 'token'
            (CONST[147]) vs None (staged 0x9360a) with
            CONST[32] False on the far side = `is None`
            (the early arm returns).
        [E:] GATE 2 — the a9d30 over GetAttr '_expires_at'
            (CONST[426]) vs None = `is not None`; then the
            chained time.monotonic() vs GetAttr '_expires_at'
            compare with CONST[32] False at 0x9385c = `>=`.
        [E:] THE EXPIRY ARM — SetAttrs clear token
            (CONST[30] 0x938f8) and _expires_at
            (CONST[30] 0x9396c), then return None through the
            a9d28 ret-dispatch.
        [E:] THE FALLTHROUGH — GetAttr self.token
            (0x93a22) returned.
        """
        if self.token is None:
            return None
        if self._expires_at is not None and \
                time.monotonic() >= self._expires_at:
            self.token = None
            self._expires_at = None
            return None
        return self.token

    def _mfa_account(self):
        """Registry L9709. Content: chunk L9713 — recovered from the
        island bytes of chunk 9713 (@0x93aa0, 9 events),
        cross-checked against the complete stream section
        (function@L9709, corpus lines 25834-25842).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x93aa3 with the GOT_000 binder at
            0x93acf.
        [E:] THE RETURN — the ONLY work event set: the
            'getActiveProfileName' CONST[425] staged through the
            a9d50 stage (call 0x93b06) — a module-level global
            name-load, zero-arg — return getActiveProfileName().
        """
        return getActiveProfileName()

    def verify(self):
        """Registry L9760. Content: chunk L9766 — recovered from the
        island bytes of chunk 9766 (@0x94d20 +1632),
        cross-checked against the complete stream section
        (function@L9760, corpus lines 26017-26099).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x94d40 with the GOT_000 binder.
        [E:] THE SECRETS — GetAttr '_load_secrets' (CONST[407])
            called with r8d=0 — a ZERO-ARG call (no args tuple
            staged); the result binds the dict used by both
            .get probes.
        [E:] ARM 1 — 'bot' (CONST[244]) -> 'user' (CONST[388])
            -> 'mfa_enabled' (CONST[411]); 'bool' CONST[408]
            name-load; GetAttr 'get' + the 'totp_seed'
            CONST[410] key — bool(secrets.get('totp_seed')).
        [E:] ARM 2 — the second bot.user.mfa_enabled walk
            (0x95015/0x95047/0x9507f) carries THE NOT-SWAP:
            CONST[32] False at 0x950de then CONST[31] True at
            0x950ef = `not bot.user.mfa_enabled`; then 'bool',
            'get' + the 'password' CONST[409] key —
            bool(secrets.get('password')). The or-chain result
            rides the ret-dispatch; the CONST[30] None at
            0x952f1 is the epilogue error fallback.

        FLAG: the `secrets` local is name-inferred.
        FLAG: the zero-arg _load_secrets() call here pins the
            caller form — the earlier corpus drafts' (None)
            spellings are corrected across this module in the
            semantic-audit pass.
        """
        secrets = self._load_secrets()
        return (bot.user.mfa_enabled
                and bool(secrets.get('totp_seed'))) or \
            (not bot.user.mfa_enabled
             and bool(secrets.get('password')))
