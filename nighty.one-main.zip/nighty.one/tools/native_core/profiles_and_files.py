"""
profiles_and_files.py — Nighty's active-profile switcher, the
theme-v2 component renderer, and the "file created at"
formatter, from the SPP native core.

Registry boundary L1750/L1787/L1800/L1808. Revised after the
deep byte-rescan of the chunk keyed L1787 (0x1fa60..0x21090):

buildThemeV2 (L1750) is armor-wrapped SPLIT — its slot carries a
1549-byte encrypted head (prologue + loop head; the per-item
dispatch and the iterator setup decrypt at call time — the loop
back-edge targets 0x1fb4f inside the cipher) followed by 4131
bytes of plaintext real-code (1019 instructions, 168 rip-window
events, fully decoded — see buildThemeV2 docstring). The earlier
"armed" and "queued" readings of this function are both
superseded by this partial recovery.

2026-10-16: the armed pair is RECOVERED. fence_target27 (the
in-process armed-fence session, license reseeded; ReadProcessMemory
on the harness process only, never any other process) archived the
loaded core image while the armed chunks decrypted in place at call
time; triage27/stitch28/decode_final assembled both spans 1184/1184
byte-exact from three independent live copies (live bases
0x28a966b6920 / 0x28a96d05f78 / 0x28a96e60040 - all six cross-copy
verdicts true). The last two of the 371 are recovered; the ledger
now reads 371 SHIPPED.
"""

import datetime
import os


def getActiveProfile():
    """Registry L1738. Content: chunk L1744 - recovered LIVE from the
    decrypted span (the armed-fence session fence_target27: the
    harness booted the protected module in-process with the license
    reseeded; the boot's own calls decrypted the armed chunk IN PLACE
    inside the loaded core image, and the window dumps archived it).
    stitch28 + decode_final assembled the span 1184/1184 byte-exact
    from three independent live copies and decoded it at the true
    entry - see out/islands/chunk1744_getActiveProfile_L1738.txt.

    [E:] LIVE SNATCH - the three live image copies (0x28a966b6920 /
        0x28a96d05f78 / 0x28a96e60040) carried the span decrypted and
        byte-identical (all six cross-copy verdicts true,
        out/armed_snatch/stitched/verbatim_report.json); the at-rest
        ciphertext chunk sits at image offset 0x1f120 +1184B and the
        decrypted body decodes cleanly from the chunk start: 294
        insns to the epilogue ret at 0x28a966d5e9d, 54 rip-window
        events (entry 0x28a966d5a40 = live base + 0x1f120).
    [E:] THE SCAN-WALK - 'getConfigData' CONST[145] name-load
        (staged 0x28a966d5a50) with the a9d20 zero-arg call
        0x28a966d5a97 - config = getConfigData() ([rsp+0x58]); the
        'get' CONST[47] GetAttr 0x28a966d5add; the kind-1 count-2
        args build over 'logins' CONST[146] + the (3,0) empty dict
        (0x28a966d5b37-0x28a966d5b77) - logins =
        config.get('logins', {}); the 'items' CONST[247] GetAttr
        0x28a966d5bb5 + the zero-arg call - logins.items()
        ([rsp+0x38] the iterator).
    [E:] THE LOOP - the a9d60 iternext 0x28a966d5c4b with the
        GOT_004 two-unpack 0x28a966d5c6b landing the key at
        [rsp+0x60] and the value at [rsp+0x68]; per turn: the
        value's 'get' method (CONST[47] re-staged 0x28a966d5cdb)
        over the ('active',) kind-1 count-1 build from
        CONST[149] 'active' (0x28a966d5d4f-0x28a966d5d6f), then
        the a9d30 sel-8 IDENTITY compare against True CONST[31]
        (0x28a966d5d9e-0x28a966d5da9; the loop-gate IsTrue
        0x28a966d5db6); the found path sets r14=2 and returns
        rsi = [rsp+0x68] - return data (0x28a966d5ddd-0x28a966d5df9).
    [E:] THE TAIL - the exhaust path falls to the standard
        implicit-None epilogue (PyErr_Occurred 0x28a966d5e09 /
        PyErr_Clear 0x28a966d5e6a, the CONST[30] None stage
        0x28a966d5e75) - no return statement past the loop.

    FLAG: the a9d30 sel-8 compare is the py38 identity compare
        ('is True'); the corpus elsewhere locks sel-2 as '=='.
        The loop's (name, data) fastlocals are name-inferred (the
        MFA write-back's config['logins'][getActiveProfileName()]
        call site proves the Name twin returns the key string).
    """
    config = getConfigData()
    logins = config.get('logins', {})
    for name, data in logins.items():
        if data.get('active') is True:
            return data


def getActiveProfileName():
    """Registry L1744. Content: chunk L1750 - recovered LIVE from the
    decrypted span (the same fence_target27 session; the true entry
    sits at image offset 0x1f580 - the registry chunk-1750 bound
    0x1f5c0 runs 0x40 past the entry, the known chunk-start
    artifact). The key string twin of getActiveProfile: the identical
    scan-walk, only the found path returns the KEY at [rsp+0x60].
    See out/islands/chunk1750_getActiveProfileName_L1744.txt.

    [E:] LIVE SNATCH - the three copies as in the profile twin;
        entry 0x28a966d5ea0 (live base + 0x1f580), 312 insns to the
        ret, 55 rip-window events; the same 1184-byte coverage and
        the byte-identity verdicts.
    [E:] THE SAME WALK - 'getConfigData' CONST[145] staged
        0x28a966d5ef0, the zero-arg call 0x28a966d5f37; the
        ('logins', {}) build 0x28a966d5fd7-0x28a966d6017; the
        items call 0x28a966d6036; the a9d60 iternext
        0x28a966d60eb + the GOT_004 unpack 0x28a966d610b landing
        key=[rsp+0x60], value=[rsp+0x68]; the value's 'active'
        get staged 0x28a966d61f6 with the a9d30 sel-8 identity
        compare against True (0x28a966d6249) and the gate IsTrue
        0x28a966d6256.
    [E:] THE KEY DELTA - the found path loads rax = [rsp+0x60]
        (the loop's key/name), sets r14=2 and rsi = rax - return
        name (0x28a966d627d-0x28a966d6299); this is the return the
        MFA/SPP callers consume as the profile-name string. The
        exhaust path runs the implicit-None epilogue
        (CONST[30] staged 0x28a966d6315).

    FLAG: the loop's (name, data) fastlocals are name-inferred;
        the sel-8 compare = the py38 identity compare.
    """
    config = getConfigData()
    logins = config.get('logins', {})
    for name, data in logins.items():
        if data.get('active') is True:
            return name


def buildThemeV2(layout, showToast, image):
    """Registry L1750. Content: chunk labeled L1787 (0x1fa60..0x21090).

    Builds the "theme v2" Discord components-v2 component list.
    Returns the components list.

    [E:] signature buildThemeV2(layout, showToast, image) — stream
         stub argcount=3, varnames ('layout','showToast','image');
         showToast+image are cellvars (co_cellvars per the stub's
         trailing tuple) — captured by inner code in the armored
         head, usage not statically recoverable — flagged.
    [E:] split body: 0x1fa60+1549B encrypted head, plaintext tail
         0x2006d..0x2101d (168 events) + epilogue to 0x21090.
         Chunk keyed 1787 = buildThemeV2's body by the
         next-function span law (its cipher head still ends the
         getActiveProfileName chunk region contiguously).
    [E:] loop: SUBGOT_a9d60 iternext at 0x2089a over an iterator
         held at frame+0xb8 (set up in the armored head); loop
         back-edge jne 0x1fb4f (inside the encrypted head — the
         per-item entry is armed); loop exit falls to 0x20ffe.
    [E:] per-item key tuple ('layout', 'content', 'title') —
         const slot 1604; the item unpack itself executes in the
         armored head — translated as style/content/title lookups
         below, flagged.
    [E:] return path: on loop exit rax = frame+0x80 (the
         components list), increfed and returned (0x21023..0x21039)
         — the function returns components (None only when the
         list slot is null).
    [E:] error tail: PyErr_Occurred at 0x20ffe, ret-dispatch
         a9d28 at 0x20fc2, DecRef cascade 0x20f38..0x20fb2 covers
         frame slots 0x68..0xa8 — the standard SPP unwind.

    Per-item component branches evidenced in the plaintext tail
    (each ends with a components.append and falls into the
    iternext at 0x20897):

    [E:] SECTION branch (guard at 0x20091 PyObject_IsTrue consumes
         an armed-computed predicate — the dispatch itself is
         armed, flagged): PyObject_GetItem 'section' (slot 1616,
         0x200c7/0x200e0) with a KeyError-fallback into the
         separator branch (0x200ee); the section dict is kept at
         frame+0xa8; PyObject_GetItem 'text' (slot 97, 0x2093d)
         loads the format template; GetAttr 'replace' (slot 237,
         0x20967) with args ('{content}', content@frame+0x70)
         built by SUBGOT_a9d18 kind-1 count-2 (slots 1613 + frame
         ref, 0x209a7..0x209eb); guarded second replace on
         ('{title}', title@frame+0x78): IsTrue at 0x20a24, build
         0x20aac..0x20af0 with slot 1614 — i.e. the template is
         text = text.replace('{content}', content) then, only
         when title is truthy, text = text.replace('{title}',
         title).
    [E:] section components: stage 'discord_bot' (slot 310,
         SUBGOT_a9d50 0x20b99) -> GetAttr 'ui' (slot 311,
         0x20bca) -> GetAttr 'Section' (slot 1617, 0x20c03);
         second chain -> 'TextDisplay' (slot 1615, 0x20ccc) built
         with kwargs ('content', text) (slot 964 + frame+0xa0,
         a9d18 kind-3 count-1 at 0x20d0c..0x20d35, call r9=1
         kwargs-flag 0x20d53) -> 1-tuple (that instance);
         third chain -> 'Thumbnail' (slot 1619, 0x20df0) built
         from PyObject_GetItem thumbnail (slot 1620, receiver =
         the section dict at frame+0xa8, 0x20e5c) with 1
         positional (call r8=1 r9=0 at 0x20eba); then kwargs
         ('accessory', thumbnail-inst) (slot 1618, build kind-3
         0x20d6e..0x20ecc region tail) and the Section call with
         both the positional tuple (the inner TextDisplay) and
         the accessory kwargs (call 0x20ef6, r9=1):
         discord_bot.ui.Section((TextDisplay(content=text),),
         accessory=Thumbnail(section['thumbnail']));
         appended via append-method kept at frame+0x40 (GetAttr
         'append' slot 250 at 0x20b32) with call r8=1 r9=0
         (0x20f2f). Translated below.
    [E:] SEPARATOR branch: ('separator', '') pair built kind-1
         count-2 (slots 1607 + 241, 0x2011d..0x20145) — a
         dict .get('separator', '') fallback frame (const 'get'
         slot 47 rides the same block 0x200ee); GetAttr 'lower'
         (slot 163, 0x20168) + call-no-args (0x201b7) lowers it;
         SUBGOT_a9d30 compare selector-2 == against 'large'
         (slot 1608, 0x201fe..0x20218, IsTrue 0x2022a, False
         slot 32 on the null-out 0x2023a);
         spacing = discord_bot.ui.SeparatorSpacing (slot 1609,
         0x2041b/0x20476) .large (slot 1608) when the compare
         is true else .small (slot 1610) — kept at frame+0x98;
         then 'discord_bot' (310) -> 'ui' (311) -> 'Separator'
         (slot 1611, 0x205e9) with kwargs ('spacing', spacing)
         (slot 1612, build kind-3 0x2062b..0x20827, call r9=1 at
         0x20845), 1-tupled and appended (append method loaded
         0x20524..0x20553, append call 0x20873). The .get
         receiver and the branch entry are armed — receiver
         translated as the item, flagged.
    [E:] TEXT branch: a second, separate .replace('{content}',
         ...) chain (slots 237/1613, build kind-1 count-2 at
         0x2032e..0x20372) and guarded .replace('{title}', ...)
         chain (slots 237/1614, 0x20676..0x206ba, IsTrue at
         0x203ab) writing frame+0xa0, followed by
         'discord_bot' -> 'ui' -> 'TextDisplay' (slots 310/311/
         1615, 0x207bc) built with kwargs ('content', text)
         (slot 964 + frame+0xa0, kind-3 0x207fe..0x20827 call
         r9=1 0x20845) and appended (append method 0x206f7,
         append call 0x20873). Both replace receivers and the
         template source for this branch are armed — translated
         mirrored on the section branch, flagged.
    [E:] showToast / image live only in the armored head; the
         three recovered branches never touch their cells — no
         PyCell_Get appears in the 168-event window.
    """
    components = []
    for item in layout:
        # ARMED-GAP (0x1fa60 head, ~1549B cipher): the iterable
        # source, the ('layout','content','title') unpack (slot
        # 1604), the style dispatch and the IsTrue guard predicate
        # (0x20091) decrypt at call time. The branch routing
        # translated below is the evidenced three-way dispatch of
        # the plaintext tail; the exact dispatch expressions are
        # flagged, not recovered.
        content = item.get('content')
        title = item.get('title')
        if 'section' in item:
            section = item['section']
            text = section['text']
            text = text.replace('{content}', content)
            if title:
                text = text.replace('{title}', title)
            components.append(discord_bot.ui.Section(
                (discord_bot.ui.TextDisplay(content=text),),
                accessory=discord_bot.ui.Thumbnail(
                    section['thumbnail'])))
        elif item.get('text') is not None:
            text = item.get('text')
            text = text.replace('{content}', content)
            if title:
                text = text.replace('{title}', title)
            components.append(discord_bot.ui.TextDisplay(
                content=text))
        else:
            mode = item.get('separator', '').lower()
            spacing = (discord_bot.ui.SeparatorSpacing.large
                       if mode == 'large'
                       else discord_bot.ui.SeparatorSpacing.small)
            components.append(discord_bot.ui.Separator(
                spacing=spacing))
    return components


def setActiveProfile(profilename):
    """Registry L1787. Content: chunk labeled L1800.

    [E:] signature tuple ('profilename',).
    [E:] config = getConfigData(); then 'get' GetAttr with a True
         const staged (event 5) — translated as config.get('logins',
         True); a second 'get' staging (event 9) is flagged here.
    [E:] 'logins' + 'items' + GetIter (events 12-17): the loop over
         the logins mapping.
    [E:] explicit False (event 29) and True (event 41) with a single
         PyObject_SetItem site (event 42) — the loop body sets
         entry['active'] = True for the matching profile and False
         for every other entry (if/else with literal bools, not a
         bare comparison result).
    [E:] saveConfigData(config) (event 48) then the standard exit
         guard (PyErr_Occurred/PyErr_Clear + None).
    """
    config = getConfigData()
    logins = config.get('logins', True)
    for key, entry in logins.items():
        if key == profilename:
            entry['active'] = True
        else:
            entry['active'] = False
    saveConfigData(config)


def getFileCreatedAt(path):
    """Registry L1800. Content: chunk labeled L1808.

    [E:] signature tuple ('path',).
    [E:] lookups in const order: os.path.getmtime (events 2-9) with a
         result IsTrue check (event 12), then os.path.getctime
         (events 14-24), then os.path.getmtime again (events 27-28)
         — a three-lookup chain: getmtime -> getctime -> getmtime.
    [E:] tail: datetime.fromtimestamp(<ts>).strftime(
         '%d %B %Y, at %H:%M:%S') — the exact format const (event 42).
    [E:] the exact nesting of the three lookups is not fully resolved
         (const staging order is proven NOT execution order elsewhere,
         but the first call here is followed by a success check);
         translated as a getctime-first fallback form for the
         "created at" semantics with the stream order documented —
         flagged.
    """
    try:
        ts = os.path.getctime(path)
    except OSError:
        ts = os.path.getmtime(path)
    return datetime.fromtimestamp(ts).strftime('%d %B %Y, at %H:%M:%S')
