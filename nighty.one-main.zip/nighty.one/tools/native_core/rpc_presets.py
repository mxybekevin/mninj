"""
rpc_presets.py — the RPC preset store family from the SPP
native core (registry L7329-L7380), recovered from the
corpus event streams plus island dumps.

  getRPCPreset(preset_name)          — the singleton scan
  renameRPCPreset(name, new_name)     — rename across both
                                        stores + repoint the
                                        profile entries
  deleteRPCPreset(name)               — remove + flush
  getAllRPCPresetNames()              — the key inventory
  setRPCPreset(preset_name, new_data) — the update-or-append
                                        upsert

The presets.json contract this family locks: the file holds
a top-level 'rpc' key whose value is a LIST of name-keyed
singleton dicts — one member per preset, the same house
style the /profile.json store uses (proven live by
getAllRPCPresetNames' keys()-extend and getRPCPreset's
in-then-GetItem pair). The flush idiom throughout is
json.dump(data, f, ensure_ascii=False, indent=4) under
`with open(f'{getDataPath()}/presets.json', 'w',
encoding='utf-8') as f`.
"""

import json


def getRPCPreset(preset_name):
    """Registry L7329. Content: chunk L7336 — recovered from
    the island bytes of chunk 7336 (dump file
    chunk7336_getRPCPreset_L7329.txt, @0x70790 +848,
    alignment +0, 35 events, 227 insns, read complete
    through the renameRPCPreset entry binder at 0x70aa0),
    cross-checked against the complete stream section
    (function@L7329, corpus lines 19807-19840, read
    complete).

    [E:] THE SIGNATURE — the names-tuple CONST[846]
        ('preset_name',) staged 0x707a2 with the GOT_000
        binder call at 0x707ce (r8d=1 — the param count)
        and the [rsp+0x58] target; test eax, eax / jne
        0x70a68 = the arity-mismatch silent None-return
        shim.
    [E:] THE SCAN — getRPCPresets staged (GOT_830,
        0x707e3) and called zero-arg (r8d=0 / r9d=0,
        0x7082a) binding [rsp+0x60]; the 'rpc' GetItem
        (GOT_831, 0x70870); the GetIter (GOT_027 call
        0x708b6) with the iternext loop head 0x708fc
        binding the preset [rsp+0x68] (0x70913); the
        membership test — the a9d30 selector-6 (edx=6 at
        0x70947) over r8 = [rsp+0x58] preset_name and
        r9 = [rsp+0x68] preset — `preset_name in preset`;
        the not-swap materialization (the falsy-side
        CONST[32] load 0x70971 against the keep-object
        truthy arm) converging at the shared gate 0x708e0
        whose FALSE side is the iternext back-edge (the
        compiled continue) and whose TRUE side is the hit
        arm; corpus events 128-148.
    [E:] THE HIT — the loop item [rsp+0x68] and the name
        [rsp+0x58] through PyObject_GetItem at 0x709b6 —
        `return preset[preset_name]` — the value carried
        through the r15b return-flag path (the slot DecRefs
        0x70a35-0x70a50 and the ret-disp 0x70a5b with
        [rsp+0x68] released at 0x6a2c-era bookkeeping;
        corpus event 174).
    [E:] THE MISS — the loop exhaust 0x709c1 with its
        PyErr_Occurred filter, then the CONST[30] None
        staged 0x709e6 — `return None` (corpus events
        107-116, 198-208).
    """
    data = getRPCPresets()
    for preset in data['rpc']:
        if preset_name in preset:
            return preset[preset_name]
    return None


def renameRPCPreset(name, new_name):
    """Registry L7336. Content: chunk L7361 — recovered from
    the island bytes of chunk 7361 (dump file
    chunk7361_renameRPCPreset_L7336.txt, @0x70ae0 +4752,
    alignment +0, 231 events, 1143 insns, read complete
    through the deleteRPCPreset entry at 0x71d30),
    cross-checked against the complete stream section
    (function@L7336, corpus lines 19841-20060, read
    complete).

    [E:] THE SIGNATURE — the names-tuple CONST[840]
        ('name', 'new_name') staged 0x70b1e with the
        GOT_000 binder at 0x70b4a (r8d=2) — def
        renameRPCPreset(name, new_name): with [rsp+0x78] /
        [rsp+0x80] the binder targets, live-pinned by
        their use as the pop key and the SetItem value
        below.
    [E:] THE STATE — getRPCPresets staged (GOT_830,
        0x70b5f) and called zero-arg (0x70ba6) binding the
        data [rsp+0x88]; getUserProfileData staged (GOT_841,
        0x70bd6) and called zero-arg (0x70c1d) binding the
        user data [rsp+0x90]; the flag slot [rsp+0x98]
        loaded with CONST[32] False (0x70c43) — renamed =
        False; the ['rpc'] GetItem (GOT_831, 0x70c93) over
        the data, GetIter (GOT_027 call 0x70cd0) and the
        iternext loop 0x70cee-0x70d16 binding [rsp+0xa0].
    [E:] THE PRESET RENAME — the membership `if name in
        preset:` — the a9d30 selector-6 (edx=6 at 0x70d58)
        over r8 = [rsp+0x78] name, r9 = [rsp+0xa0] preset;
        the not-swap gate whose FALSE side is the iternext
        back-edge 0x70d04; the hit arm — the CONST[842]
        'pop' GetAttr over [rsp+0xa0] (resolved 0x70e01)
        with the kind-1 count-1 name args (r8 = [rsp+0x78],
        0x70e3d-0x70e54) called 0x70e72 → r15, then
        PyObject_SetItem at 0x70e9b (r14 = [rsp+0xa0] the
        preset, rbx = [rsp+0x80] new_name, r8 = r15 the
        popped) — `preset[new_name] = preset.pop(name)` —
        the dict rename idiom; the flag store: the
        CONST[31] True staged 0x70ec9 into [rsp+0x98] —
        renamed = True; corpus events 129-202.
    [E:] THE PROFILE WALK — after the loop exhaust and its
        PyErr filter (0x70eff), the ['profiles'] GetItem
        (GOT_843, 0x70f3d) over [rsp+0x90] with the GetIter
        0x70f7a and the level-one loop binding [rsp+0xa8];
        the per-member .values() GetAttr (GOT_844, resolved
        0x7100b) zero-arg called 0x71045, its result
        GetIter'd 0x71056 with the level-two loop binding
        [rsp+0xb0]; the third GetIter over [rsp+0xb0]
        (0x710b8) with the level-three loop binding
        [rsp+0xb8] — the three-level walk
        `for profile in user_data['profiles']: for value in
        profile.values(): for entry in value:` — the names
        of these loop receivers are slot-inferred
        conventions, flagged; the iteration STRUCTURE is
        island-locked. The gate — the entry's .get GetAttr
        (GOT_47, 0x7116e) over the kind-1 count-1 ('rpc'
        GOT_831, 0x711a0) call — `entry.get('rpc')` —
        through the a9d30 selector-2 equality (edx=2 at
        0x711eb, r8 = the .get result, r9 = [rsp+0x78]
        name): `if entry.get('rpc') == name:`; the hit arm —
        PyObject_SetItem at 0x71296 (rcx = [rsp+0xb8] the
        entry, rdx = 'rpc' GOT_831 staged 0x7125d, r8 =
        [rsp+0x80] new_name) — `entry['rpc'] = new_name` —
        then the CONST[31] True into [rsp+0x98]
        (0x712c7-0x712e9) — renamed = True again; corpus
        events 219-397.
    [E:] THE FLAG GATE — the loop exhaust → PyErr filter →
        the IsTrue of [rsp+0x98] (0x7149e) with the
        swapped True/False consts (CONST[31] armed on the
        falsy edge 0x714be, CONST[32] on the truthy edge
        0x714b5) converging at the second IsTrue —
        the not-swap emission, locking the source form
        `if not renamed: return False` — jne 0x71517 with
        the CONST[32] staged 0x71521 and the ret-disp
        return path; corpus events 402-411.
    [E:] THE FLUSH — inside the truthy fall: open staged
        (GOT_201, 0x714f0) over the path — the
        argumentless getDataPath call 0x715a6, the
        FORMAT_VALUE pair, the '/presets.json' GOT_832
        (staged 0x715ba) with BUILD ecx=2 0x715d1 and 'w'
        GOT_833 (0x715d4), the kind-1 count-2 args plus the
        kind-3-one encoding='utf-8' kwargs (GOT_284 /
        GOT_285, 0x715fd-0x71625) — open(path, 'w',
        encoding='utf-8'), the a9d50 slot stages and the
        PyCallFunction 0x716a1 binding the file
        [rsp+0xc0]; json.dump — 'json'(143, 0x716de) with
        'dump'(689, 0x71710), the kind-1 count-2 args (the
        data [rsp+0x88] 0x71750, the file [rsp+0xc0]
        0x71760) plus the kind-3 count-2 kwargs
        ensure_ascii=False (0x71786-0x7178f) and indent=4
        (GOT_690 / GOT_835, 0x717a4-0x717d4), called 0x717f1;
        the with-exit dispatch (a9d28 0x71823 + a9d40 +
        CONST[1857] + PyCallFunction + IsTrue + GOT_002 +
        PyErr machinery, 0x71805-0x718da); then the mirror
        flush of /profile.json — the open 0x7191d, the
        getDataPath path build with the '/profile.json'
        GOT_845 (staged 0x719c4), 'w', encoding='utf-8',
        the with-machinery 0x73180-binding [rsp+0xc0], and
        json.dump over the kind-1 count-2 with THE USER DATA
        [rsp+0x90] (0x71b6e) — json.dump(user_data, f,
        ensure_ascii=False, indent=4) (the call 0x71c0f);
        corpus events 413-696.
    [E:] THE RETURN — the final with-exit chain delivers
        the CONST[31] True staged 0x71d10 (jne-guarded
        against the null) — `return True` (corpus event
        705).
    """
    data = getRPCPresets()
    user_data = getUserProfileData()
    renamed = False
    for preset in data['rpc']:
        if name in preset:
            preset[new_name] = preset.pop(name)
            renamed = True
    for profile in user_data['profiles']:
        for value in profile.values():
            for entry in value:
                if entry.get('rpc') == name:
                    entry['rpc'] = new_name
                    renamed = True
    if not renamed:
        return False
    with open(f'{getDataPath()}/presets.json', 'w',
              encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    with open(f'{getDataPath()}/profile.json', 'w',
              encoding='utf-8') as f:
        json.dump(user_data, f, ensure_ascii=False, indent=4)
    return True


def deleteRPCPreset(name):
    """Registry L7361. Content: chunk L7371 — recovered from
    the island bytes of chunk 7371 (dump file
    chunk7371_deleteRPCPreset_L7361.txt, @0x71d70 +2192,
    alignment +0, 104 events, 539 insns, read complete
    through the getAllRPCPresetNames entry at 0x725c0),
    cross-checked against the complete stream section
    (function@L7361, corpus lines 20061-20165, read
    complete).

    [E:] THE SIGNATURE — the names-tuple CONST[838]
        ('name',) staged 0x71d96 with the GOT_000 binder
        (r8d=1) at 0x71dc2 — def deleteRPCPreset(name).
    [E:] THE SCAN — getRPCPresets staged (GOT_830,
        0x71dd7), zero-arg called 0x71e1e binding the data
        [rsp+0x80]; the 'rpc' GetItem (GOT_831, 0x71e6e);
        the GetIter 0x71eb4 with the iternext 0x71efa
        binding the preset [rsp+0x88] (0x71f11); the
        membership — the a9d30 selector-6 (edx=6 at
        0x71f4b) over r8 = [rsp+0x78] name and r9 =
        [rsp+0x88] preset, with the not-swap gate (the
        CONST[32] falsy-side arm 0x71f78, the shared IsTrue
        0x71ede) whose FALSE side is the iternext back-edge
        — `if name in preset:`; corpus events 110-128.
    [E:] THE HIT — data['rpc'] re-derived (the GetItem at
        0x71fc1) with the 'remove' GetAttr (GOT_839,
        staged 0x72039, resolved 0x72053) over the kind-1
        count-1 args of the loop item ([rsp+0x88],
        0x72079-0x72093) — `data['rpc'].remove(preset)` —
        called 0x720b3 with the result discarded; corpus
        events 131-165.
    [E:] THE FLUSH — open staged (GOT_201, 0x720d7) over
        the argumentless getDataPath (0x72164) + FORMAT +
        the '/presets.json' GOT_832 (0x72177, BUILD ecx=2)
        plus 'w' (GOT_833, 0x7219c) as the kind-1 count-2
        args and the kind-3-one encoding='utf-8' kwargs
        (0x721b9-0x721e1), called 0x72200; the
        with-machinery (the a9d50 slot stages 0x72221 /
        0x72241 with PyCallFunction 0x7225d) binding the
        file [rsp+0x90] (0x72274); json.dump — 'json'(143,
        0x72296) .dump(689, 0x7230d) with the kind-1
        count-2 (data [rsp+0x80], file [rsp+0x90],
        0x72333-0x72350) plus the kind-3 count-2 kwargs
        ensure_ascii=False (0x72369-0x72384) and indent=4
        (0x72387-0x723a3), called 0x723d4; the with-exit
        dispatch (a9d28 0x72406 + a9d40 0x72420 +
        CONST[1857] 0x72443 + PyCallFunction + IsTrue +
        GOT_002 + the PyErr machinery, 0x723e8-0x724b6);
        corpus events 174-312.
    [E:] THE RETURNS — the with-exit's normal path stages
        the explicit CONST[31] True at 0x72595 with the
        carried value returned through the r15b flag path
        — `return True` INSIDE the hit arm (corpus events
        321-324; the early return is the loop exit — no
        break, no flag variable exists in this function);
        the loop exhaust 0x71fcc with its PyErr filter
        stages the CONST[32] False at 0x71ff4 — `return
        False` (corpus events 96-99).
    """
    data = getRPCPresets()
    for preset in data['rpc']:
        if name in preset:
            data['rpc'].remove(preset)
            with open(f'{getDataPath()}/presets.json', 'w',
                      encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False,
                          indent=4)
            return True
    return False


def getAllRPCPresetNames():
    """Registry L7371. Content: chunk L7380 — recovered from
    the island bytes of chunk 7380 (dump file
    chunk7380_getAllRPCPresetNames_L7371.txt, @0x72600 +928,
    alignment +0, 39 events, 240 insns, read complete
    through the setRPCPreset entry at 0x72960),
    cross-checked against the complete stream section
    (function@L7371, corpus lines 20166-20205, read
    complete). ZERO parameters — no GOT_000 binder events
    (the 0-param signature law).

    [E:] THE COLLECT — getRPCPresets staged (GOT_830,
        0x72612) zero-arg called 0x72659 binding the data
        [rsp+0x48]; names = [] — the a9d18 kind-2 edx=0
        empty-list build (0x72685) into [rsp+0x50]; the
        'rpc' GetItem (GOT_831, 0x726c9), the GetIter
        0x72706 and the iternext loop binding the preset
        [rsp+0x58] (0x72745); per item — the .extend
        GetAttr (GOT_836, resolved 0x7277d) with the
        .keys GetAttr (GOT_837, 0x727f6) zero-arg called
        (r8d=0, 0x72858) and wrapped kind-1 count-1
        (0x7285a-0x72867) — `names.extend(preset.keys())` —
        the extend call 0x72886 (r8d=1, the args-count call
        form), the loop back-edge 0x728a1; corpus events
        82-122. The keys()-extend pair is the proof that
        each 'rpc' member is a name-keyed singleton dict.
    [E:] THE RETURN — the loop exhaust 0x728b0 with its
        PyErr filter, then the [rsp+0x50] list load
        (0x72943-0x72955) returned through the bpl flag
        path — `return names`; corpus events 136-169.
    """
    data = getRPCPresets()
    names = []
    for preset in data['rpc']:
        names.extend(preset.keys())
    return names


def setRPCPreset(preset_name, new_data):
    """Registry L7380. Content: chunk L7397 — recovered from
    the island bytes of chunk 7397 (dump file
    chunk7397_setRPCPreset_L7380.txt, @0x729a0 +3568,
    alignment +0, 171 events, 867 insns, read complete
    through the set_window prologue at 0x73750),
    cross-checked against the complete stream section
    (function@L7380, corpus lines 20206-20374, read
    complete).

    [E:] THE SIGNATURE — the names-tuple CONST[829]
        ('preset_name', 'new_data') staged 0x729c2 with the
        GOT_000 binder (r8d=2) at 0x729ee — def
        setRPCPreset(preset_name, new_data): with the
        [rsp+0x78] / [rsp+0x80] targets.
    [E:] THE SCAN — getRPCPresets staged (GOT_830,
        0x72a03), zero-arg called 0x72a4a binding the data
        [rsp+0x88]; the 'rpc' GetItem (GOT_831, 0x72a9a);
        the GetIter 0x72ae0 with the iternext 0x72b26
        binding the preset [rsp+0x90] (0x72b3d); the
        membership — the a9d30 selector-6 (edx=6 at
        0x72b77) over r8 = [rsp+0x78] preset_name, r9 =
        [rsp+0x90] preset — `preset_name in preset`; the
        not-swap gate whose FALSE side is the iternext
        back-edge (the CONST[32] arm 0x72ba4); corpus
        events 294-330 re-ordered but island-locked.
    [E:] THE HIT — the GetItem([rsp+0x90], [rsp+0x78]) at
        0x72bf3 — `preset[preset_name]` — with the 'update'
        GetAttr (GOT_562, staged 0x72c82, resolved
        0x72c9c) over the kind-1 count-1 new_data args
        ([rsp+0x80], the build 0x72cc2-0x72cdc) —
        `preset[preset_name].update(new_data)` — called
        0x72cfc with the result discarded; corpus events
        348-362.
    [E:] THE FLUSH (mirrored twice, one zone per path) —
        open staged (GOT_201: zone-1 0x72d20 / zone-2
        0x72fec) over the argumentless getDataPath (FORMAT
        + the '/presets.json' GOT_832 + 'w' GOT_833, kind-1
        count-2) with the kind-3-one encoding='utf-8'
        kwargs, the with-machinery (PyCallFunction zone-1
        0x72eaa / zone-2 0x73180) binding the file
        [rsp+0x98], then json.dump — 'json'(143) .dump(689)
        over the kind-1 count-2 (data [rsp+0x88], file
        [rsp+0x98]; zone-1 0x73268-0x73310 / zone-2
        0x73555-0x735f6) with the kind-3 count-2 kwargs
        ensure_ascii=False + indent=4, and the CONST-1857
        with-exit dispatches (0x7337f / 0x73665); corpus
        events 371-509.
    [E:] THE RETURNS — the hit path's with-exit stages the
        CONST[31] True at 0x734ed (r12b cleared, the
        carried-value return) — `return True` INSIDE the hit
        arm (corpus events 294-297; the early return is
        the loop exit); the exhaust path — data['rpc']
        re-derived (the 'rpc' GetItem 0x72c4e) with the
        'append' GetAttr (GOT_250, resolved 0x72f54) and
        the a9d18 kind-3 count-1 dict build (ecx=3, r8 =
        [rsp+0x78] preset_name, r9 = [rsp+0x80] new_data,
        0x72f97-0x72fa1) wrapped kind-1 count-1 —
        `data['rpc'].append({preset_name: new_data})` —
        called 0x72fd0, then the zone-2 flush and the
        CONST[31] True staged 0x73732 — `return True`
        (corpus events 518-521).
    """
    data = getRPCPresets()
    for preset in data['rpc']:
        if preset_name in preset:
            preset[preset_name].update(new_data)
            with open(f'{getDataPath()}/presets.json', 'w',
                      encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False,
                          indent=4)
            return True
    data['rpc'].append({preset_name: new_data})
    with open(f'{getDataPath()}/presets.json', 'w',
              encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    return True
