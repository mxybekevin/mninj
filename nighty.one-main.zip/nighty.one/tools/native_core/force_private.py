"""
force_private.py — Nighty's force-private command family from the SPP
native core, with evidence chains.

Consolidation note: removeForcePrivateCommand was originally committed
in settings_store.py and moved here unchanged (body + evidence as
committed); the README records the move.
"""

import json
import logging
import os


def initialize_forceprivate():
    """Registry L572. Content: chunk labeled L585.

    [E:] no signature tuple (0 args); os.path.exists(force_private_path)
         with IsTrue/False/True branch consts (events 5-21).
    [E:] create branch: open(force_private_path, 'w') + json.dump(<default>,
         f, indent=2) — dump site 1 (events 35-65).
    [E:] read/validate branch: open(force_private_path, 'r') + json.load
         (events 26-53); isinstance(list) check (55/73); raise
         ValueError('Invalid JSON format') (events 84-87, exact msg).
    [E:] except tuple (json.JSONDecodeError, ValueError) — Fetch at 94,
         both type consts staged at 95-101 — then the reset: a second
         open(force_private_path, 'w') + json.dump(<default>, f,
         indent=2) (events 105-129). The reset default is
         dispatcher-built ([] inferred from the list invariant —
         flagged).
    """
    if not os.path.exists(force_private_path):
        with open(force_private_path, 'w') as f:
            json.dump([], f, indent=2)
        return
    try:
        with open(force_private_path, 'r') as f:
            cmds = json.load(f)
        if not isinstance(cmds, list):
            raise ValueError('Invalid JSON format')
    except (json.JSONDecodeError, ValueError):
        with open(force_private_path, 'w') as f:
            json.dump([], f, indent=2)


def getForcePrivateCommands():
    """Registry L585. Content: chunk labeled L600.

    [E:] no signature tuple (0 args).
    [E:] open(force_private_path, 'r', encoding='utf-8', errors='ignore')
         + json.load (events 5-29) inside a real try (Fetch at 36).
    [E:] isinstance(list) check; raise ValueError('force_private root
         is not a list') (events 42-58, exact message).
    [E:] except Exception as e: logging.error('getForcePrivateCommands:
         ' + force_private_path + ' is unreadable (' + <e> +
         ') - resetting it') — logging + GetAttr('error') + the three
         exact string pieces (events 61-71); NOTE: logging.error() is
         DIRECT here (no 'getLogger'/'nighty' consts in this stream).
    [E:] reset via atomicJsonDump(<default>, force_private_path)
         (events 73-75); default dispatcher-built ([] inferred,
         flagged); a second Fetch (event 88) wraps the reset.
    """
    try:
        with open(force_private_path, 'r', encoding='utf-8',
                  errors='ignore') as f:
            cmds = json.load(f)
        if not isinstance(cmds, list):
            raise ValueError('force_private root is not a list')
    except Exception as e:
        logging.error('getForcePrivateCommands: ' + force_private_path +
                      ' is unreadable (' + str(e) + ') - resetting it')
        atomicJsonDump([], force_private_path)
        return []
    return cmds


def save_forceprivate_commands(data):
    """Registry L600. Content: chunk labeled L604.

    [E:] signature tuple ('data',).
    [E:] open(force_private_path, 'w') — NO encoding kwargs (unlike the
         reader) — + json.dump(data, f, indent=2) (events 7-29);
         PyErr_Fetch machinery after the dump = a try around the write;
         handler silent (no logging consts).
    """
    try:
        with open(force_private_path, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


def addForcePrivateCommand(command_name):
    """Registry L604. Content: chunk labeled L618.

    [E:] signature tuple ('command_name',).
    [E:] initialize_forceprivate() then getForcePrivateCommands()
         (events 7-12); isinstance(list) check (events 13-21); a second
         membership condition (IsTrue/False/IsTrue, events 24-26);
         'append' staged twice (attr + invoke, events 28-35);
         save_forceprivate_commands (event 39); return True (event 43).
    [E:] staged False literals (events 19, 34) read as the not-added
         returns; the exact placement of each among the outer/inner
         branches is flagged (four bools staged: 19, 20, 34, 43).
    """
    initialize_forceprivate()
    cmds = getForcePrivateCommands()
    if isinstance(cmds, list):
        if command_name not in cmds:
            cmds.append(command_name)
            save_forceprivate_commands(cmds)
            return True
        return False
    return False


def removeForcePrivateCommand(command_name):
    """Registry L618. Content: chunk labeled L664.

    [E:] signature tuple ('command_name',)
    [E:] consts include: 'initialize_forceprivate', 'getForcePrivateCommands',
                 'isinstance', 'list', 'remove', 'save_forceprivate_commands'
    [E:] flow: ensure init; get list; if isinstance(cmds, list):
             cmds.remove(command_name); save back; return None

    (Moved unchanged from settings_store.py — see README.)
    """
    initialize_forceprivate()
    cmds = getForcePrivateCommands()
    if isinstance(cmds, list):
        if command_name in cmds:
            cmds.remove(command_name)
        save_forceprivate_commands(cmds)
