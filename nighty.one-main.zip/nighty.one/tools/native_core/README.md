# native_core/README.md -- Nighty's SPP native layer (discovered 2026-10-13)

## What this directory is

Nighty.exe was protected with a **pyarmor SPP hybrid**: besides the plain
Python shell (recovered previously) and the still-ciphered super-mode
class, a **third function population** exists: **371 of the app's core
functions compiled to native x86-64** inside a 731,520-byte ELF blob
embedded in the frozen module's const pool (`out/spp_core.elf` in the
oracle workspace).

Functions live there under their original names and source lines:
`spp_<name>_<line>` -- including `getUUID_443`, `encryptRSA_448`,
`getCurrentAppId_1643`, `decryptCurrentToken_1595`, the whole
voice-mute/force-private settings family, `atomicJsonDump_1244`,
`_loadJsonOrRestore_1254`, the tailwind validators, and a large UI
renderer class family (`__init__`/`render` pairs with full 10+ argument
signatures).

## Recovery pipeline (all reproducible from the oracle workspace)

1. **Stream re-parse** -- `full_parse.py` fixed (marshal ref-indices must
   continue across the stream; the original one-line desync broke 207
   entries) -> 384 exact units.
2. **ELF extraction** -- the 731,520-byte core sits in the merged const
   pool (tuple item 1161); PT_LOAD maps 0x40..0xAFB00; trailer carries the
   371-entry symbol registry (`spp_<name>_<line>` + chunk bounds).
3. **Span disassembly** -- capstone over all chunks -> annotated listings
   in `out/spans_asm/ALL_SPANS.txt` (9.4 MB).
4. **Live GOT semantics** -- the core's call slots [elf+0xA9D68..] were
   dumped from a running bootstrap (`fence_target25.py`); they resolve to
   **22 direct CPython API ports + 5 op dispatchers** inside
   `pytransform.pyd` (`got_map.json`).
5. **Live constant pool** -- 1,746 Goslot values were dereferenced in
   process (`fence_target26.py` -> `const_reprs.json`): 1,534 strings,
   162 tuples, 44 ints -- the native layer's literals now read as text.
6. **Re-segmentation & attribution** -- the registry chunks are not
   function-aligned (verified: the "atomicJsonDump" chunk contained the
   global excepthook); `resegment.py` re-bounds functions by true
   prologues and attributes them via their **in-function signature tuples**
   (each function's first dispatcher call loads a const-tuple equal to its
   own varnames), cross-matched against stream-stub metadata by line.

## Files here

- `json_file_layer.py` -- atomicJsonDump, _loadJsonOrRestore (the
  quarantine + atomic-dump core layer).
- `settings_store.py` -- spy/translate reader+writer pairs,
  removeForcePrivateCommand, the voicemute/noleave savers, the config
  store (getConfigData, saveConfigData, updateConfig,
  getWebConfigData, updateWebConfig) and the global excepthook.
- `voice_mute_store.py` -- the full voicemute.json family: reader
  with VOICEMUTE_DEFAULTS deep-merge + double persist, settings/list
  get/set (setters return the written value), id-list add/remove
  (return True), history get/add/remove/is-in, plus
  clearVoiceMuteHistory (recovered via const slot 1702 =
  'saveVoiceMuteHistory': saveVoiceMuteHistory([])).
- `noleave_store.py` -- getNoLeaveData, isNoLeaveLocked(group_id,
  user_id), toggleNoLeave, getNoLeaveUsers, clearNoLeaveData
  (recovered: saveNoLeaveData({})).
- `context_features.py` -- addContextFileFeature /
  removeContextFileFeature, including the bare
  getContextFileFeatures() side-effect call and the
  list-comprehension rebuild (PyCell-captured `s`).
- `theme_and_keywords.py` -- _loadThemeFile, the getThemeData 3-level
  fallback cascade, getOthersData / setOthersData, addKeyword /
  removeKeyword.
- `snipe_cache.py` -- cleanupSnipeCache (60s throttle, age pass,
  size-budget pass).
- `profiles_and_files.py` -- setActiveProfile, getFileCreatedAt.
- `force_private.py` -- initialize_forceprivate (create/validate/reset
  paths with exact error strings), getForcePrivateCommands (validated
  reader with reset-to-default + logging.error), save_forceprivate_
  commands, addForcePrivateCommand; removeForcePrivateCommand moved
  here unchanged from settings_store.py.
- `client_activity.py` -- getClientActivity / saveClientActivity
  (/misc/client_analytics.json pair).
- `token_crypto.py` -- getUUID (uuid.getnode machine id), encryptRSA
  (hard-coded PEM + RSA-OAEP-SHA256, hex output),
  encrypt/decryptCurrentToken (Windows DPAPI via
  win32crypt.CryptProtectData/CryptUnprotectData + base64 with the
  'N1:' version prefix -- the 3-char const, colon was hidden by label
  sanitization; config saved with indent=4), the
  getCurrentAppId/AppToken/Token decrypt getters, getSniperTokens
  (active=False list collector).
- `scripts_discoverables_store.py` -- addEnabledScript /
  removeEnabledScript (script_name), addBlockedDiscoverable /
  removeBlockedDiscoverable (user_id): the identical four-CRUD shape
  (reader -> [not]-in guard -> append/remove -> conditional save
  with indent=2; None return). Establishes the SPP member-check op:
  SUBGOT_a9d30 selector 6 = in, 7 = not in, needle-first.
- `mimic_guards.py` -- shouldSkipMimic(showToast): the (False, None)
  /(True, entry)/(True, 'age/minor filter')/None pair-return
  spectrum; mimic_blocklist screening (space-containing entries as
  substrings, single-word via re.search('\\b'+escape+'\\b')), the
  mimic_age_filter gate (default True) + MIMIC_AGE_PATTERNS loop.
  isNSFW(read): no-guild/riskmode -> True, else read.is_nsfw().
- `slash_and_js.py` -- getSlashCommand (name + int-cast application_id
  match), execute_js_via_websocket / evaluate_js (web-gated
  socketio.emit('execute_js', ...) + the main_ui.evaluate_js
  desktop fallback; 'JS execution failed: ' / 'JavaScript
  execution failed: ' logging.info handlers).
- `manager_internals.py` -- DISSOLVED in the class restructure:
  enqueue_action + the bots-manager __init__ moved into the
  BotsManager class (bots_and_window.py); _load_secrets moved
  into the MfaCredentialStore class (mfa_credentials.py) -- each
  with its original registry cites.
- `script_engine.py` -- now recovered as real classes:
  class ScriptManager (the _injected_scripts base, name-flagged)
  with deject / deject_all / get_running_scripts /
  get_metadata / the hasattr-guarded __init__; class
  ScriptEngine(ScriptManager) (the evidenced name, GOT_865) with
  max_injections=64 + _injected_methods=set(); module-level
  getLocalScripts (the disk scan with isActive = filename in
  ScriptEngine.get_running_scripts()) and
  get_metadata_from_decorator (the raw-decoded @nightyScript ast
  walker, sig 1207 LIVE).
- `func_store.py` -- the complete FuncStore class: __init__
  (functions = {}), register (sig 1194), get, call (the exact
  'No function registered with name' ValueError + the
  iscoroutinefunction/run_coroutine_threadsafe async bridge).
- `bots_and_window.py` -- class BotsManager (name-flagged): the
  ctor (tokens/bots/connected_bots/servers), enqueue_action
  (action_queue.put), process_actions (the guarded deqi),
  run_bots (discord.Client per token + client.event handlers +
  create_task(start) + run_forever); module-level
  show/hide_main_window.
- `discoverables_wss.py` -- class DiscoverablesClient
  (name-flagged): the ctor with the live endpoint
  wss://eu.nighty.one/v2 + the full state field set,
  process_discoverables (nightyOnline diff vs last_status),
  notify_status_change (the two Discoverables toasts).
- `mfa_credentials.py` -- class MfaCredentialStore
  (name-flagged): _load_secrets (the self._mfa_account() gate +
  keyring.get_password(SERVICE, account) + json.loads or {}),
  setCredentials (RuntimeError gate + totp whitespace-strip/upper
  normalization + keyring.set_password with json.dumps -
  partial-merge flags), getPassword, and isConfigured (moved here
  from discord_state_helpers -- it reads the credentials store).
- `discord_state_helpers.py` -- class ChannelManager
  (name-flagged): the empty __init__, setActive/getActiveChannelId
  (voice-channel fallback); module-level getFriendsSet
  (set(friend.id...)).
- `api_client.py` -- class GuildsApi (name-flagged; the twin-class
  correction is documented inside): the tls_client
  Discord-impersonation ctor
  TLSSession(client_identifier='chrome'+str(randint(110,115)),
  random_tls_extension_order=True), the https://discord.com
  cookie-jar warming (session.cookies = session.get(...).cookies),
  the full 16-key hardcoded header set (user-agent
  discord/1.0.9016 Chrome/108 Electron/22.3.12; x-discord-timezone
  Europe/Prague; x-super-properties NOW VERIFIED COMPLETE -- the
  full 592-char base64 recovered from the marshal stream, decoding
  to valid JSON), and the guild creator create (POST
  /api/v9/guilds with the hardcoded empty channels) moved in from
  app_authorize_api.py.
- `tailwind_validators.py` -- generate_tailwind_classes(prefix)
  ([''] + pfx+side+'-'+0..10), _gap_validator (0..10 bounds,
  exact message), variant_validator(valid_variants, value)
  (replace(' ','') + membership + the exact error pair).
- `ui_renderers.py` -- the UI component renderer family, now 7
  classes: Text, Button, Input, Image, Toggle, Checkbox, Select.
  LIVE ctor signatures recovered from the const pool (slots
  1572/1556/1540/1515/1487/1440/1474); render() dicts with the
  exact ValueError gates; str(uuid.uuid4()) ids; the
  callback_store registration idiom with __name__ storage;
  Select's items_validator/keys_validator private methods
  evidenced (bodies queued).
- `table_component.py` -- the Table class: ctor sig slot 1406
  LIVE; the eager column/button validation with the EXACT
  ValueError set (1410/1411/1412/1413/1414/1417/1419/1421);
  rows_validator (Exception family, 1377-1385 incl. the
  cells-vs-columns count); delete/update/insert_rows with the
  evaluate_js updateCustomTableRows contracts; closure sigs
  ('row_id','selected') / ('onClick','row_id') LIVE.
- `ui_containers.py` -- Group/CardContainer/Card/Tab with the
  composition contract (parent_<x>=self factories), the
  isinstance parent-guards (1326/1346/1308), the Tab toast API
  (1267 sig; INFO/SUCCESS/ERROR gate + showCustomUIToast JS),
  the Timer(0.005) debounce, and module-level updateLastSeen +
  convert_custom_emojis (the classic r'<a?:(\w+):\d+>' ->
  ':\1:' normalizer, sig 1244 LIVE).
- `text_and_window_helpers.py` -- truncate_string (sig 1247
  LIVE, the [:max_length-3] + '...' idiom); update_text +
  break_text_into_lines (raw-decoded QFontMetrics pixel-width
  word-wrapper with the '<div style="line-height:' + lh + ';">'
  wrap and '<br>' joins); requestAppToken
  (app_token.html); close_application; toggleNightyDiscoverable
  (Retry(total=50, status_forcelist=[429,500,503,504],
  backoff_factor=5) session + SERVER_TO_USE '/v2/discoverable'
  POST with encryptRSA(getLicense()) keying).
- `app_authorize_api.py` -- the applications-REST family COMPLETE
  as class ApplicationsApi (class name flagged OPEN -- the
  'AppAuthorizeApi' const actually names the verifyDevPortal
  users, see the 2026-10-15 revision): the TWIN session ctor
  (L5597, line-identical to GuildsApi's), get_apps
  (?with_team_applications=false), app creator, upload_asset (CDN
  url stamping), get_bot_token (the FULL MFA lifecycle:
  401-ticket flow, totp/password app_verification pages, the
  id/token re-validation cascade, logging.error/requestAppToken
  vs bot.run(token=getCurrentToken(), reconnect=True)),
  get_asset (v10 name-lookup), get_assets (v9 list + CDN
  enrichment), delete_asset (the 204 contract) and close.
- `nighty_curl_compat.py` -- the Nighty curl-selector patch trio,
  all with LIVE sigs: _nighty_handle_select (slot 1748) -- the
  reader/writer event distributor with the EXACT
  logging.exception set ('[curl selector] reader/writer callback
  failed (ignored)') + the `if not getattr(self, '_closed',
  False): self._start_select()` re-arm ('[curl selector] re-arm
  skipped'); _nighty_release_curl (slot 1745) -- the pooled-handle
  `_nighty_pooled` marker + the _cc_orig_release_curl
  call-through; _nighty_eb_init (slot 1741) -- the _orig-forward
  + the `self._max = min(self._max, 6)` hard cap.
- `dev_portal_verification.py` -- SUPERSEDED (a pointer module):
  the dev-portal MFA completion pair now ships COMPLETE inside
  web_settings_window.py as WebVersionApi members --
  verifyDevPortalPass ('password', window 1200x1000) and
  verifyDevPortalMfa ('totp', sig CONST[557], window 1075x670) --
  with all five corpus-era guesses corrected from the chunk-8723
  and chunk-8829 islands (the app_manager() factory call, the
  whole-payload '\n{data}\n' stdout writes, the
  '__Secure-recent_mfa=' mfa-finish-token cookie, the
  f-string '{app_id}/bot/reset' route, NO webview.start()).
  See the 2026-10-16 revision below.
- `web_login_manager.py` -- the webview login family: the
  MethodType/setattr js_api binder (add_custom_function --
  raw-decoded), getAvailableLoginOptions (['token_login',
  'web_login']), the Login-to-Discord webview launcher
  (WebLoginApi js_api, 1075x670), the local login-page Flask
  Response (text/html), the url_map duplicate-route guard
  (endpoint_exists), the registration wrapper, and
  safe_add_individual_route -- the decorator factory decoded
  full from chunk 9370 plus its TRAILING-ZONE handler (see
  the 2026-10-16 revision).
- `settings_backups.py` -- class SettingsBackupStore (name-flagged):
  the complete backup-store tier L10452-L10508 -- _backupsPath
  (the made-and-returned server_backups folder), _sanitize (the
  re.sub(r'[\\/:*?"<>|]+', '_', str(value)).strip() or
  'unnamed' scrubber), listBackups (the os.listdir/server.json
  scan with the nine-field entry dicts, the unreadable-backup
  logging.error + continue, and the created_ts-descending sort
  whose sort-key lambda body decoded from the trailing zone at
  0x9e530), resolveBackup (the three-tier resolver: exact-id
  scan, exact-name comprehension, unique-substring
  comprehension, implicit None), and autocompleteChoices (the
  app_commands.Choice lister with the label[:97]+'...' cap, the
  name/guild/id match string, and the choices[:25] cap).
- `voice_mute_view.py` -- TWO discord View classes (the split is
  evidence-locked by the callback families): VoicemuteListView
  (render -- five list buttons: Status/Mode/Add ID(s)/Remove
  ID(s)/Clear list) and VoicemuteSettingsView (embed -- the
  voiceMuteEmbed('Voicemute » Settings', description) panel +
  render -- the four settings toggles: non-friends automute,
  mute-on-join, apply-to-new-users, unmute-on-leave).
- `script_loader.py` -- the enable/disable script store with the
  `global __all_notifications__` / `global __custom_ui_tabs__`
  STORE_GLOBAL emissions (the a9d50 name-load + value-store
  pairs outside any function frame).
- `app_boot.py` -- the app boot tail (13 functions,
  checkTurboSniper through on_closed at registry line 12763,
  the last span): the turbo-sniper gate, the startup banner
  toast, the big CONST[111] window watcher, and the
  closed-handler epilogue that fences the trailing zone.
- `nui_web_ui.py` -- class NUI (name LIVE via the _NUI__ name
  mangling in its private method consts): the desktop UI
  surface family of the streaming tier.
- `turbo_sniper_manager.py` -- the five-method turbo-sniper
  manager class (name flagged -- the spp export registration
  names its functions, not the class).
- `web_settings_window.py` -- class WebVersionApi: the web
  settings window tier -- the bridge-tier methods customCallback
  through verifyDevPortalPass plus the streaming tier and the
  MFA twins (pass 1200x1000 / mfa 1075x670) -- the js_api face
  of the settings UI.
- `text_utilities.py` -- the text helpers plus the final pair
  from the registry tail: getActiveCtxMenus (the zero-arg
  module-level active-menu lister with the type/description
  label pieces, the concat + join return, and the empty-list
  fallback) and extract_chat_response (the AI-response
  post-processor: the pool-slot-230 closing-tag search with
  re.DOTALL, the quote unwrap response[1:-1], and the
  hand-unescaping replace chain for the escaped newline,
  carriage-return and tab literals).


All docstrings carry [E:] markers naming the chunk, const stream and
CPython API calls that back each statement.

## Corrections made this revision (2026-10-14)

- settings_store.py previously shipped the
  ('config', '_config_lock', 'atomicJsonDump', 'getConfigPath') stream
  as updateConfig. Per the off-by-one law that stream belongs to
  **saveConfigData (L1280, content chunk L1284)**. The true
  **updateConfig (L1284, content chunk L1290)** is the
  ('key', 'value') stream: config = getConfigData();
  config[key] = value; saveConfigData(config).
- isNoLeaveLocked takes TWO arguments (group_id, user_id) -- its entry
  varnames tuple is authoritative (earlier notes assumed one).
- setVoiceMuteListEnabled / setVoiceMuteListMode return the freshly
  written value (trailing cached-config re-read events); the
  voicemute history savers' removal branch returns True.
- getVoiceMuteConfig persists TWICE (restore branch + post-merge
  save) -- its reader is not read-only.
- CENSUS OVERTURN (byte-resync walker): the earlier "zero-event =
  armed" readings for chunk L886 (clearNoLeaveData) and chunk L1787
  (buildThemeV2) were capstone-stall artifacts -- chunk starts that cut
  mid-instruction make naive linear scans self-sync on garbage bytes.
  Resync extraction recovers their events: clearNoLeaveData
  (= saveVoiceMuteHistory-style save build, now shipped) and
  buildThemeV2 (168 events, normal SPP, queued for decompilation).
  The TRUE cipher placeholders confirmed by the census are chunk L1744
  (-> getActiveProfile) and chunk L1750 (-> getActiveProfileName).

## New evidence facts (2026-10-14)

- The full 371-span registry is now name-mapped (all
  `out/spans_final/L*.txt` dossiers). The off-by-one law reads
  precisely: a function named at line L has its code in the span
  labeled with the NEXT registry line in sorted order.
- Full-span census (zero_event_census.py, byte-resync walker):
  exactly TWO of the 371 spans decode with zero const/API events --
  chunk L1744 (1184B) and chunk L1750 (1184B), both dense cipher
  blobs (5 meaningless rip decodes each, no coherent code) ->
  **getActiveProfile (L1738) and getActiveProfileName (L1744) are
  armed**. All other 369 spans carry resolvable events.
- Alignment-stall law: chunk starts that cut mid-instruction make
  naive capstone linear scans miss or misread the first instructions
  (self-synchronizing garbage). Concrete case: chunk L816's hidden
  const load was slot 1702 = 'saveVoiceMuteHistory' (masked by the
  misaligned start; recovered by aligned re-reading). All future
  extraction uses the resync/multi-alignment walker.
- The const pool is laid out in REGISTRY ORDER -- the slots around a
  function's cluster are its literal neighborhood (e.g. 1698-1704 =
  the noleave/voice-mute-history cluster).
- Batch-decompilation lane (from the REA study): headless Ghidra with
  evidence-injected symbols -- GOT slot names from the live dump,
  const-pool reprs, true function prologues -- to pseudocode all
  remaining spans at once. Portable stack staged in tools/
  (Ghidra 12.1.4, SHA-256 verified + Temurin JDK 21).
- The SPP member-check op: SUBGOT_a9d30 takes a numeric selector --
  6 = `in`, 7 = `not in` -- applied needle-first (raw-evidenced in
  both scripts CRUD functions); the shouldSkipMimic branches reuse
  selector 6 for the space/wildcard checks.
- The everything-register exists in oracle (build_coverage.py ->
  out/coverage.txt): all 371 registry functions tracked as
  SHIPPED / TODO / ARMED so nothing quietly stays unfinished; the
  decomp corpus index is out/decomp_streams_all.txt (all 371
  sections, grep-able).
- The decomp lane is LIVE: 512 functions decompiled in one run
  (oracle/out/ghidra_decomp) with the live evidence injected as
  labels -- every remaining family reads from annotated pseudocode
  instead of hand-traced jumps. First fruit: the full token-crypto
  scheme (token_crypto.py), plus two reusable insights: the SPP
  binary-op dispatcher's op args are CPython binary-op bytecodes
  (DAT_000a9d10: 0x22=MODULO, 0x24=SUBTRACT), and const reprs
  hidden by label sanitization (the b64 pad '=' lived in slot 811
  but read as "____" in the label).
- A sub-GOT slot region BELOW the dumped window (elf+0xA9D68) exists:
  slots 0xa9d18/0xa9d20/0xa9d28/0xa9d30/0xa9d48/0xa9d50 act as op
  helpers (0xa9d50 = const/argument staging with (rcx=&staging,
  rdx=obj, r8=index); 0xa9d20 = the call op; 0xa9d18 = kwargs/map
  builds). They are load-time resolved and were never dumped, so any
  op touching only them is invisible in the event streams. Victim so
  far: clearVoiceMuteHistory (L802) -- only its guard epilogue
  resolves. A future live session should dump elf+0xA9000..0xA9D70.
- Calling-convention findings used in the docstrings: function
  entries load their varnames tuple via the first dispatcher call
  with r8d=argcount; PyCell_New at entry marks a closure capture
  (list comprehensions); a bare result DecRef without a frame-store
  marks a side-effect call (e.g. getContextFileFeatures() invoked only
  to ensure context_path exists); the standard epilogue is
  Py_DecRef -> PyErr_Occurred -> PyErr_Clear -> load None.
- The frozen module's own co_names (777 names) and lnotab (2,442
  bytes) were captured intact -> `out/module_names_lnotab.json` -- the
  module-level statement grid for future attribution work.

## Honesty ledger

- Functions marked `[E:]` are statement-backed by named constants and
  CPython API calls visible in the annotated disassembly.
- Flagged as PARTIALLY reconstructed (details in each docstring):
  the getVoiceMuteConfig defaults-merge helper nesting; the exact
  setVoiceMuteListMode mode-selection predicate; addVoiceMuteHistory's
  loop/counter details; toggleNoLeave's empty-group cleanup
  ('pop'/None pair); getThemeData's logger attainment + interior
  guard clusters; getFileCreatedAt's lookup nesting;
  cleanupSnipeCache's budget-pass dataflow.
- RESOLVED (was: open flag): the token prefix is the 3-char const
  'N1:' (slot 1621 -- the colon was hidden by label sanitization) --
  startswith('N1:') and the readers' [3:] strip are consistent;
  token_crypto.py corrected.
- scripts_discoverables_store.py: the discoverables pair's a9d30
  guard selectors (6/7) are cited by family invariant (both raw-
  evidenced in the scripts twins; streams identical).
- mimic_guards.py: the space-branch contains-op direction
  (entry_clean in name) follows the family's needle-first staging
  convention; the raw staging order cannot fully disambiguate the
  operand roles, flagged in the docstring.
- RECOVERED 2026-10-16 (live fence snatch: fence_target27 +
  stitch28/decode_final): getActiveProfile and
  getActiveProfileName -- the two armed-cipher placeholders --
  ship in profiles_and_files.py with full live-capture [E:]
  evidence (three byte-identical live copies; the chunks
  decrypted in place at call time).
- buildThemeV2: confirmed normal SPP code (chunk L1787: 168 events,
  5680B) but not yet translated -- queued for the Ghidra
  batch-decompilation lane.
- The sub-GOT op-helper region (elf+0xA9000..0xA9D68: slots used as
  staging/call/build/return ops) remains undumped by any live
  session; it gates micro-detail on a few tiny functions.
- The 83-unit armed-cipher class (Nighty2, toast-init,
  getGoogleLanguages, spp_caller, spp_export_api, ...) remains separate
  from the native layer (zero span overlap) and unchanged in status.

## Revision (2026-10-15): the class restructure + evidence locks

- READABILITY RESTRUCTURE: the recovered bodies now ship as REAL
  classes instead of module-level pseudo-methods -- writing the
  double-underscore privates inside their classes reproduces the
  exact mangled _Table__*/_Group__*/... slots at runtime (the same
  evidence, now reading like the original source). Rebuilt:
  ui_renderers (Text/Button/Input/Image/Toggle/Select/Checkbox),
  table_component (Table + the two listener functions whose
  no-self sigs mark them as registered closures), ui_containers
  (Group/CardContainer/Card/Tab), script_engine
  (ScriptManager + ScriptEngine(ScriptManager) -- the inheritance
  inferred from the attr-sharing + the
  ScriptEngine.get_running_scripts() call site), func_store
  (FuncStore complete), bots_and_window (BotsManager absorbing
  manager_internals), mfa_credentials (MfaCredentialStore
  absorbing _load_secrets + isConfigured),
  discord_state_helpers (ChannelManager), discoverables_wss
  (DiscoverablesClient), api_client (GuildsApi + the guild
  creator), app_authorize_api (ApplicationsApi). Classes whose
  names are not const-evidenced carry a NAME FLAG naming the
  descriptive label.
- EVIDENCE LOCKS: (1) the shipped twin ctor was L5597's body
  mislabeled L5568 -- both twins now ship with the SetAttr targets
  corrected to self.session.cookies / self.session.headers (the
  Cloudflare warm = session.get('https://discord.com').cookies);
  (2) the 'AppAuthorizeApi' const (GOT_575) belongs to the
  verifyDevPortalPass/verifyDevPortalMfa users, not the
  applications family -- their full decode (mfa/finish with the
  stored ticket, the __Secure-recent_mfa re-header, the second
  /bot/reset, the authorize-webview relaunch) ships in
  dev_portal_verification.py; (3) the x-super-properties const is
  now VERIFIED COMPLETE -- the full 592-char base64 recovered from
  the marshal stream (full_stream_window.bin), decoding to valid
  JSON (build 218604, native 35236, locale sv). Both client
  classes assert the decoded fields.


## Revision (2026-10-16): the final seven + the 369 ledger

THE LEDGER: **369 SHIPPED / 0 TODO / 2 ARMED / 371** (measured by
`oracle/build_coverage.py`, which counts the per-function registry
cites over the shipped modules; mirror/shared rows credit via
explicit dual-cites). The climb: 303 -> 362 (the bridge tier
L8569-L8723, the streaming tier L9370-L10101 with its mirror
dual-cites, the C-draft boot tail L10452-L12763) -> **369** (the
final seven). Every shipped body carries `[E:]` chunk+address
evidence and passes the `verify_literals.py` byte-audit (113
census literals, 0 mismatches) plus the py38 compile gate; the
merged `Nighty.py` v6 rebuilds (709,324 bytes, 221 native
entries) and compiles clean except the two original-artifact
`is not 345` SyntaxWarnings at L2501/L2504.

THE FINAL SEVEN (commit 59a6296, the v6 rebuild 24faf1f):

- **listBackups L10460 + resolveBackup L10494 + autocompleteChoices
  L10508** (settings_backups.py, the store tier complete): the
  os.listdir/server.json scanner with nine-field entries and the
  created_ts sort; the three-tier resolver; the app_commands.Choice
  lister with the 100-char label rule and the 25 cap.
- **render L10111** (voice_mute_view.py): the registry interleaves
  TWO View classes. The 'Voicemute >> Settings' embed belongs with
  the four-toggle settings render, NOT with the list view; the
  module now ships VoicemuteListView{render} +
  VoicemuteSettingsView{embed, render}, the boundary locked by the
  callback families (_toggle_enabled/_toggle_mode/_add_id/
  _remove_id/_clear vs _toggle_non_friends/_toggle_join/
  _toggle_new_users/_toggle_unmute_leave).
- **getActiveCtxMenus L11951 + extract_chat_response L11966**
  (text_utilities.py): the zero-arg menu lister and the AI-response
  post-processor (the thinking-tag stripper -- its regex slot-230
  value had to be hex-probed after the console mangled the display).
- **safe_add_individual_route L9295** (web_login_manager.py): the
  factory + handler pattern complete -- the '/api/custom/' route
  build, the endpoint_exists guard with its warning log and return
  False, factory(func_to_handle), the handler.__name__ uuid rename,
  the web_app.route registration with methods ['POST','OPTIONS'] and
  the f-string endpoint (the decorator call applied to the FACTORY
  PRODUCT), and the trailing-zone handler (below).
- **verifyDevPortalMfa L8776** (web_settings_window.py): the
  chunk-8829 totp twin of verifyDevPortalPass, all deltas
  address-locked (sig CONST[557] at 0x8abc8, 'totp' CONST[569] at
  0x8b0d0, window 1075x670 via CONST[117]/[119] at 0x8be7b/0x8be99,
  the watcher CONST[576] at 0x8bd10 byte-identical to the pass
  variant's CONST[580] copy); dev_portal_verification.py became the
  SUPERSEDED pointer module.

NEW EMISSION LAWS (this wave):

- **THE TRAILING ZONE**: nested code objects can live PAST the last
  registry span (on_closed's epilogue at 0xa91e0). safe_add's
  handler is a full prologue at **0xa93a0** (the physically-last
  code in the SPP space); the 0xad809 "code ptr" hit by the closure
  meta was data, while the listBackups sort-lambda body = **0x9e530**.
  Raw-address disasm (the dump_island.py preamble + capstone
  resolve()) reaches them.
- **THE CHUNK-KEY LAW**: an island dump is keyed by the NEXT
  registry line, so a function's body lives under its successor's
  key (my 10460 dump held _sanitize; listBackups@L10460's body =
  chunk 10494, resolveBackup's = 10508, autocompleteChoices' =
  11446).
- **STORE_GLOBAL emissions**: a9d50 name-load + value-store pairs
  outside a function frame are `global X` declarations
  (__all_notifications__ / __custom_ui_tabs__).
- **POOL-EXACT F-STRINGS**: a source split that cuts a pool literal
  produces false pieces -- f"server backup '{item}' unreadable: {e}"
  must stay one token (CONST[287] + [288]); the byte-audit catches
  this class of drift.
- **MIRROR DUAL-CITES** are the coverage rule for twin rows (the
  escape_markdown twin, the tailwind mirror rows).

buildThemeV2 (L1750) SHIPPED (profiles_and_files.py) -- that
2026-10-14 honesty-ledger line is resolved. **getActiveProfile
(L1738)** and **getActiveProfileName (L1744)** -- the ARMED pair --
fell to the LIVE FENCE SNATCH on 2026-10-16: fence_target27 (the
in-process armed-fence session, license reseeded, ReadProcessMemory
on the harness process only) caught both chunks decrypted in place
inside the loaded core image; three independent live copies
byte-identical (commits df8787d + the v6 rebuild 1be3e88).

THE LEDGER: **371 SHIPPED / 0 TODO / 0 ARMED / 371** (2026-10-16).
REA xrefs on pytransform's own spp strings resolve to the four
loader sites -- 'Call spp code out of pyarmor'@0x6d604e27,
'Init spp mode failed' @0x6d6060cc, 'Failed to alloc memory for spp
code' @0x6d60979b, '<sppcode>' @0x6d60bcf8 -- recorded for the armor
story.

## REA + the Ghidra lane (2026-10-16)

REA (github.com/morluto/rea, npm `rea-agents` 6.5.0) is deployed as
the native-analysis harness. `rea doctor` reports the Ghidra
provider HEALTHY against the staged portable stack
`tools/ghidra_12.1.4_PUBLIC` + `tools/jdk-21.0.12.1+1` (verified
version 12.1.4, x64 decompile.exe, JDK 21.0.12.1,
Job Object/DACL/reparse controls) -- using the real `D:` paths,
because the `C:` working directory is a reparse (junction) chain
and REA's Windows P0 admission refuses reparse components.

The first import landed: `rea inspect` on
`oracle/pytransform.pyd.orig` (SHA-256 3b522fb7..., PE x86-64,
shared-library role) -- 12 segments, .text 536,064 bytes,
**1027 procedures, 898 strings, image base 0x6d600000**. The goal:
the armed pair getActiveProfile/getActiveProfileName -- decompile
pytransform's armed-blob load/decrypt path. If the key material is
static, the two 1184-byte cipher chunks (L1744/L1750, zero
const/API events) decrypt offline; if runtime-keyed, the pseudocode
becomes the blueprint for the live fence session (the
`fence_target*` harness class, license reseeded,
ReadProcessMemory-only -- never touching the owner's Discord
client).
