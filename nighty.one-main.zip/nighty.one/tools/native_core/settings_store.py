"""
settings_store.py — Nighty's SPP-native settings/persistence family,
translated from the embedded spp_core.elf with full evidence chains.

Attribution note: the registry's chunk labels are off by one relative
to true function contents (verified twice); each function below cites
the chunk where ITS stream was actually found.
"""

import json


# ---------------------------------------------------------------------------
# /misc/spy.json — spy settings pair
# ---------------------------------------------------------------------------

def getSpySettings():
    """Registry L545. Content: chunk labeled L549.

    [E:] consts: 'open', 'getDataPath', '/misc/spy.json', 'r',
                 'json', 'load'
    [E:] return json.load(open(getDataPath() + '/misc/spy.json', 'r'))
    """
    with open(getDataPath() + '/misc/spy.json', 'r') as f:
        return json.load(f)


def saveSpySettings(data):
    """Registry L549. Content: chunk labeled L560.
    [E:] signature tuple ('data',)
    [E:] consts: 'open', 'getDataPath', '/misc/spy.json', 'w',
                 'json', 'dump', 'indent', 2
    """
    with open(getDataPath() + '/misc/spy.json', 'w') as f:
        json.dump(data, f, indent=2)


# ---------------------------------------------------------------------------
# /misc/translate.json — translate settings pair
# ---------------------------------------------------------------------------

def getTranslateSettings():
    """Registry L560. Content: chunk labeled L564.
    [E:] consts: 'open', 'getDataPath', '/misc/translate.json', 'r',
                 'json', 'load'
    """
    with open(getDataPath() + '/misc/translate.json', 'r') as f:
        return json.load(f)


def saveTranslateSettings(data):
    """Registry L564. Content: chunk labeled L572.
    [E:] signature tuple ('data',)
    [E:] consts: ...'/misc/translate.json', 'w', 'json', 'dump',
                 'indent', 2, None
    """
    with open(getDataPath() + '/misc/translate.json', 'w') as f:
        json.dump(data, f, indent=2)


# ---------------------------------------------------------------------------
# force-private commands: the family ships in force_private.py
# (removeForcePrivateCommand moved there unchanged — same evidence).
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# voice-mute persistence (paths are module globals by name)
# ---------------------------------------------------------------------------

def saveVoiceMuteConfig(data):
    """Registry L664. Content: chunk labeled L669.
    [E:] signature tuple ('data',)
    [E:] consts: 'open', 'voicemute_path', 'w', 'encoding', 'utf-8',
                 'errors', 'ignore', 'json', 'dump', 'indent', 2
    [E:] note: 'voicemute_path' is loaded as a module global by name
             (name-dict dispatcher), not built from getDataPath here.
    """
    with open(voicemute_path, 'w', encoding='utf-8', errors='ignore') as f:
        json.dump(data, f, indent=2)


def saveVoiceMuteHistory(ids):
    """Registry L757. Content: chunk labeled L761.
    [E:] signature tuple ('ids',)
    [E:] consts: 'open', 'voicemute_history_path', 'w', 'encoding',
                 'utf-8', 'errors', 'ignore', 'json', 'dump', 'indent', 2
    """
    with open(voicemute_history_path, 'w', encoding='utf-8',
              errors='ignore') as f:
        json.dump(ids, f, indent=2)


def saveNoLeaveData(data):
    """Registry L816. Content: chunk labeled L820.
    [E:] signature tuple ('data',)
    [E:] consts: 'open', 'noleave_path', 'w', 'encoding', 'utf-8',
                 'errors', 'ignore', 'json', 'dump', 'indent', 2
    """
    with open(noleave_path, 'w', encoding='utf-8', errors='ignore') as f:
        json.dump(data, f, indent=2)


# ---------------------------------------------------------------------------
# config store (via the JSON core layer)
# ---------------------------------------------------------------------------

def getConfigData():
    """Registry L1277. Content: chunk labeled L1280.
    [E:] const stream in full: '_loadJsonOrRestore', 'getConfigPath',
         'DEFAULT_CONFIG', '_config_lock'
    """
    return _loadJsonOrRestore(getConfigPath(), DEFAULT_CONFIG, _config_lock)


def saveConfigData(config):
    """Registry L1280. Content: chunk labeled L1284.
    [E:] signature tuple ('config',)
    [E:] consts: '_config_lock', 'atomicJsonDump', 'getConfigPath'
    [E:] correction: previously misattributed to updateConfig; the next
         registry line after 1280 is 1284, so L1280 saveConfigData is
         the owner of this stream (off-by-one law, sorted registry).
    """
    with _config_lock:
        atomicJsonDump(config, getConfigPath())


def updateConfig(key, value):
    """Registry L1284. Content: chunk labeled L1290.
    [E:] signature tuple ('key', 'value')
    [E:] stream (dossier L01290): getConfigData() ->
         PyObject_SetItem -> saveConfigData -> standard exit guard.
    """
    config = getConfigData()
    config[key] = value
    saveConfigData(config)


def getWebConfigData():
    """Registry L1290. Content: chunk labeled L1293.
    [E:] const stream: '_loadJsonOrRestore', 'getWebConfigPath',
         'DEFAULT_WEB_CONFIG', '_web_config_lock'
    """
    return _loadJsonOrRestore(getWebConfigPath(), DEFAULT_WEB_CONFIG,
                              _web_config_lock)


def updateWebConfig(new_config):
    """Registry L1293. Content: chunk labeled L1297.
    [E:] signature tuple ('new_config',)
    [E:] consts: '_web_config_lock', 'atomicJsonDump', 'getWebConfigPath'
    """
    with _web_config_lock:
        atomicJsonDump(new_config, getWebConfigPath())


# ---------------------------------------------------------------------------
# global exception hook
# ---------------------------------------------------------------------------

def handle_exception(exc_type, exc_value, exc_traceback):
    """Registry L1176. Content: chunk labeled L1244 (VA 0xEC30).
    [E:] signature tuple ('exc_type', 'exc_value', 'exc_traceback')
    [E:] if issubclass(exc_type, KeyboardInterrupt): return (bare exit)
    [E:] logging.error('Uncaught exception', exc_info=(...))
    [E:] falls back to sys.__excepthook__(exc_type, exc_value,
             exc_traceback) when present
    [E:] clears any residual error state before returning None
    """
    if issubclass(exc_type, KeyboardInterrupt):
        return
    logging.error('Uncaught exception',
                  exc_info=(exc_type, exc_value, exc_traceback))
    sys.__excepthook__(exc_type, exc_value, exc_traceback)
