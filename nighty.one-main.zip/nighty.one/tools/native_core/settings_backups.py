"""
settings_backups.py — the settings backup store class from the
SPP native core (registry L10452-L10508), recovered from the
island bytes of chunks 10457/10460/10494/10508/11446 with the
raw-disasm of the trailing sort-key lambda, cross-checked
against the complete stream sections. The tier ships COMPLETE:

  _backupsPath(self)         — the server_backups folder
  _sanitize(self, value)     — the filesystem-hostile scrubber
  listBackups(self)          — the server.json scanner/sorter
  resolveBackup(self, token) — the three-tier backup resolver
  autocompleteChoices(self, current) — the app_commands Choices

CLASS NAME FLAG: nothing in this span names the class — the
backups-store role is inferred from the store-helper method
shape (self-receiver + the registry neighborhood).
"""

import json  # noqa: F401
import logging  # noqa: F401
import os  # noqa: F401
import re  # noqa: F401

from discord import app_commands  # noqa: F401  # the bare-name load


class SettingsBackupStore:

    def _backupsPath(self):
        """Registry L10452. Content: chunk L10457 — recovered from
        the island bytes of chunk 10457 (dump file
        chunk10457__backupsPath_10452.txt, +0 align, span +5904),
        cross-checked against the complete stream section
        (function@L10452, corpus lines 27067-27108).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x9c3b6 with the GOT_000 binder r8d=1 at
            0x9c3f8 (corpus 26-28). A store-helper METHOD.
        [E:] THE PATH — os (CONST[34] 0x9c3f7), GetAttr 'path'
            (CONST[165]), GetAttr 'join' (CONST[166]); the
            getDataPath (CONST[194]) name-load + zero-arg call,
            the 2-tuple with r9 = CONST[306] 'server_backups'
            staged 0x9c4ef (the second join arg was NOT
            corpus-listed — an island-only const) —
            os.path.join(getDataPath(), 'server_backups').
        [E:] THE MKDIRS — os staged again, GetAttr 'makedirs'
            (CONST[220]), the 1-tuple over the join result,
            kwargs {'exist_ok' CONST[221]: True} —
            os.makedirs(<the join result>, exist_ok=True).
        [E:] THE RETURN — the join result rides rsi (LAW 14) —
            `return <the path>`; the CONST[30] None at 0x9c6a5
            is only the NULL-fallback. The join local is reused
            by makedirs and the return.

        FLAG: the `path` local is name-inferred.
        """
        path = os.path.join(getDataPath(), 'server_backups')
        os.makedirs(path, exist_ok=True)
        return path

    def _sanitize(self, value):
        """Registry L10457. Content: chunk L10460 — recovered from
        the island bytes of chunk 10460 (dump file
        chunk10460__sanitize_10457.txt, +0 align, span +864),
        cross-checked against the complete stream section
        (function@L10457, corpus lines 27109-27143, read
        complete).

        [E:] THE SIGNATURE — the names-tuple CONST[302] ('self',
            'value') staged 0x9c718 with the GOT_000 binder
            r8d=2 at 0x9c745 (corpus 29-33). A filter METHOD.
        [E:] THE CHAIN — re (CONST[228]) staged, GetAttr 'sub'
            (CONST[257] staged 0x9c791); the 3-tuple args over
            CONST[303] r'[\\/:*?"<>|]+' (staged 0x9c7d0),
            CONST[304] '_', and str(value): the 'str' const
            name-load + the 1-tuple over the value param —
            re.sub(r'[\\/:*?"<>|]+', '_', str(value)); then
            GetAttr 'strip' + zero-arg call — the chained
            .strip().
        [E:] THE OR — IsTrue(stripped): the falsy side stages
            CONST[305] 'unnamed' (the or-operator jump
            materialization, the not-swap family) —
            `.strip() or 'unnamed'`; the a9d28 returns the
            chosen value (LAW 14).

        FLAG: the pattern is the const-repr r'[\\/:*?"<>|]+'.
        """
        return re.sub(r'[\\/:*?"<>|]+', '_', str(value)).strip() \
            or 'unnamed'

    def listBackups(self):
        """Registry L10460. Content: chunk L10494 — recovered from
        the island bytes of chunk 10494 (dump file
        chunk10494_listBackups_10460.txt, @0x9c9c0 +7376, +0
        align, 323 events, 1694 insns, read complete),
        cross-checked against the complete stream section
        (function@L10460, decomp-file merged-region marker —
        the island carries the decode).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x9ca0a with the GOT_000 binder
            (r8d=1) at 0x9ca39.
        [E:] THE ACCUMULATOR + PATH — the kind-2 edx=0 empty
            list build 0x9ca76 (the PyPlace accumulator,
            [rsp+0xe0]); GetAttr '_backupsPath' (CONST[279]
            staged 0x9cab9) zero-arg call —
            backups_path = self._backupsPath() ([rsp+0xe8]).
        [E:] THE LOOP — os.listdir (CONST[34]/[280]) over the
            path, GetIter (the CONST[27] call 0x9cc2d) + the
            a9d60 iternext; the item lands [rsp+0xf8]; the
            3-arg os.path.join(backups_path, item,
            'server.json') (CONST[281]) -> [rsp+0x100]; os.path
            .isfile (CONST[282]) over it with the law-8
            not-materialization 0x9cee0-0x9cf19 = `if not
            os.path.isfile(...): continue` (je 0x9cc64 rearms
            the iternext).
        [E:] THE WITH + LOAD — the with-protocol (LAW 10) over
            open(path, 'r', encoding='utf-8') (CONST[201]/
            [283]/[284]'encoding'/[285]'utf-8'; the a9d50
            r8d=4/5 ramps; the CONST[1857] exit-half at
            0x9d1cc); json.load (CONST[143]/[286]) over the
            file — data = json.load(f) ([rsp+0x110]).
        [E:] THE TRY — every failure routes to the
            DAT_a9d40 fetch at 0x9df7a + the a9d30 sel-0xa
            match over 'Exception' CONST[77] staged 0x9df96;
            the matched arm binds the alias ([rsp+0x118]) and
            calls logging.error over the a9d48 4-piece join:
            CONST[287] "server backup '" + the -1 format of
            the item + CONST[288] "' unreadable: " + the -1
            format of the alias — logging.error(f"server
            backup '{item}' unreadable: {e}") — then the
            continue flag (al=1, jmp 0x9cc64); unmatched ->
            GOT_002 at 0x9e2f9.
        [E:] THE ENTRY — guild = data.get('guild', {}) (the
            (3,0)-empty + the (1,2) tuple over CONST[289]);
            the a9d18 ecx=3 edx=9 dict build 0x9de78 over the
            nine frame pairs: 'id' (CONST[265]) =
            data.get('backup_id', item) (CONST[295] + the
            item as the fallback, 0x9d461), 'backup_name'
            (CONST[262]) = data.get('backup_name')
            (single-arg, 0x9d5a1), 'guild_name' (CONST[263]) =
            guild.get('name', '?') (CONST[273]/[296],
            0x9d5eb), 'guild_id' (CONST[290]) = guild.get('id')
            (0x9d6f5), 'created' (CONST[291]) = data.get(
            'created', '') (CONST[241], 0x9d7c1), 'created_ts'
            (CONST[292]) = data.get('created_ts', 0)
            (CONST[277], 0x9d871), 'roles' (CONST[293]) =
            len(data.get('roles', {})) (the raw len + the
            (3,0) dict default, [rsp+0x148]), 'channels'
            (CONST[294]) = len(data.get('channels', {})) +
            len(data.get('categories', {})) (CONST[297]; the
            a9d10 sel-7 ADD at 0x9dc95 over the two cached
            lens [rsp+0x140] + r13), 'path' (CONST[165]) =
            the 2-ARG os.path.join(backups_path, item) at
            0x9ddb4 (the backup FOLDER, distinct from the
            3-arg server.json probe); the .append GetAttr
            (CONST[250] staged 0x9d38a) + the 1-arg call.
        [E:] THE SORT — the loop-exhaust at 0x9e304: the
            PyErr check, then GetAttr 'sort' (CONST[298]
            staged 0x9e335); the a9d58 closure make 0x9e3a4
            (r8d=-1, NO freevars; meta slot1784 = the 0xad809
            data wheel, slot1785 = the 0x9e530 body, slot1786
            = 3); the kwargs (3,2) build: {'key' (CONST[299]):
            the closure, 'reverse' (CONST[301]): True
            (CONST[31])} — backups.sort(key=..., reverse=True).
        [E:] THE SORT BODY — decoded from the trailing zone
            @0x9e530: the names-tuple CONST[300] ('b',) with
            the GOT_000 binder — lambda b: b.get('created_ts',
            0) (the (1,2) tuple over CONST[292]/[277],
            0x9e5df-0x9e668).
        [E:] THE RETURN — [rsp+0xe0] increfs into rsi 0x9e41b,
            the r15b flag = 0 and the rsi non-null -> the
            epilogue returns rsi — return backups; the
            CONST[30] None is the NULL-fallback.

        FLAG: the backups_path/item/backup/data/guild locals
            are name-inferred (the frame slots).
        """
        backups = []
        backups_path = self._backupsPath()
        for item in os.listdir(backups_path):
            server_json_path = os.path.join(backups_path, item,
                                             'server.json')
            if not os.path.isfile(server_json_path):
                continue
            try:
                with open(server_json_path, 'r',
                          encoding='utf-8') as f:
                    data = json.load(f)
            except Exception as e:
                logging.error(f"server backup '{item}' unreadable: {e}")
                continue
            guild = data.get('guild', {})
            backups.append({
                'id': data.get('backup_id', item),
                'backup_name': data.get('backup_name'),
                'guild_name': guild.get('name', '?'),
                'guild_id': guild.get('id'),
                'created': data.get('created', ''),
                'created_ts': data.get('created_ts', 0),
                'roles': len(data.get('roles', {})),
                'channels': len(data.get('channels', {}))
                            + len(data.get('categories', {})),
                'path': os.path.join(backups_path, item)})
        backups.sort(key=lambda b: b.get('created_ts', 0),
                     reverse=True)
        return backups

    def resolveBackup(self, token):
        """Registry L10494. Content: chunk L10508 — recovered from
        the island bytes of chunk 10508 (dump file
        chunk10508_resolveBackup_10494.txt, @0x9e690 +4192, +0
        align, 203 events, 1077 insns, read complete),
        cross-checked against the stream section
        (function@L10494, decomp-file merged-region marker).

        THE THREE-TIER RESOLVER: the exact id scan, the exact
        name comprehension, the substring comprehension.

        [E:] THE SIGNATURE — the names-tuple CONST[276]
            ('self', 'token') staged 0x9e6bb with the GOT_000
            binder (r8d=2) at 0x9e6e7.
        [E:] THE TOKEN REBIND — PyCell_New over the param
            0x9e6fd; str(cell) + .strip() (CONST[150]/[99])
            PyCell_Set back 0x9e828 — token = str(token).strip()
            — a CELL because the comprehensions below capture
            it (the per-function cell law).
        [E:] TIER 1 — backups = self.listBackups()
            (CONST[261] GetAttr, [rsp+0x78]); the plain loop;
            per backup the str(backup['id']) (the CONST[265]
            GetItem 0x9ea59 + the str 1-tuple) .lower()
            (CONST[163]) vs token.lower() (PyCell_Get +
            .lower) — the a9d30 sel-2 0x9eba4: str(backup['id
            ']).lower() == token.lower(); the truthy arm jumps
            the shared tail 0x9e841 with rdi = the backup —
            return backup (0x9ebd5-0x9ebf5).
        [E:] TIER 2 — the raw PyList_New 0x9ec2e + the loop
            over the SAME [rsp+0x78]; the gate backup.get(
            'backup_name') (CONST[47]/[262] 1-tuple, IsTrue,
            the falsy side skips 0x9eecf) AND the a9d30 sel-2
            0x9ee8a: backup['backup_name'].lower() ==
            token.lower(); the raw PyList_Append 0x9eefc —
            matches = [backup for backup in backups if
            backup.get('backup_name') and
            backup['backup_name'].lower() == token.lower()]
            ([rsp+0x88]).
        [E:] THE MATCH DISPATCH — IsTrue(matches) 0x9ef7d: the
            truthy arm GetItems matches[0] (CONST[277]) at
            0x9f02f — the shared GetItem tail at 0x9f686
            returns rdi = matches[0] (the 0x9f661 len-1 path
            reuses it with rsi = [rsp+0x90]) — return
            matches[0].
        [E:] TIER 3 — the second raw PyList_New 0x9ef9f +
            loop; the same .get gate AND the a9d10 or-pair:
            the sel-6 0x9f25d — token.lower() in backup[
            'backup_name'].lower() — OR the sel-6 0x9f466 —
            token.lower() in str(backup['id']).lower() (the
            str re-walk 0x9f395); the raw PyList_Append
            0x9f4cd — partial = [backup for backup in backups
            if backup.get('backup_name') and (token.lower()
            in backup['backup_name'].lower() or
            token.lower() in str(backup['id']).lower())].
        [E:] THE LEN GATE — the raw len (CONST[267]) over
            [rsp+0x90], the a9d30 sel-2 vs CONST[233] 1 at
            0x9f5e1 — if len(partial) == 1: return partial[0]
            (the shared GetItem flow); the fall-through stages
            CONST[30] None at 0x9f625 — the implicit-None
            tail (sete bpl -> the epilogue returns None).

        FLAG: the backups/matches/partial locals are
            name-inferred from the frame slots.
        """
        token = str(token).strip()
        backups = self.listBackups()
        for backup in backups:
            if str(backup['id']).lower() == token.lower():
                return backup
        matches = [backup for backup in backups
                   if backup.get('backup_name')
                   and backup['backup_name'].lower()
                   == token.lower()]
        if matches:
            return matches[0]
        partial = [backup for backup in backups
                   if backup.get('backup_name')
                   and (token.lower()
                        in backup['backup_name'].lower()
                        or token.lower()
                        in str(backup['id']).lower())]
        if len(partial) == 1:
            return partial[0]

    def autocompleteChoices(self, current):
        """Registry L10508. Content: chunk L11446 — recovered from
        the island bytes of chunk 11446 (dump file
        chunk11446_autocompleteChoices_10508.txt, @0x9f6f0
        +3248, +0 align, 147 events, 806 insns, read complete),
        cross-checked against the stream section
        (function@L10508, decomp-file merged-region marker).

        THE DISCORD AUTOCOMPLETE: builds app_commands.Choice
        objects for the typed prefix, capped at 25.

        [E:] THE SIGNATURE — the names-tuple CONST[260]
            ('self', 'current') staged 0x9f717 with the
            GOT_000 binder (r8d=2) at 0x9f743.
        [E:] THE LOOP — choices = the (2,0) empty list
            ([rsp+0x78]); self.listBackups() (CONST[261]
            GetAttr + zero-arg, [rsp+0x80] = the item); the
            name-or: backup['backup_name'] (GetItem
            CONST[262]) IsTrue, the falsy side falls to
            backup['guild_name'] (GetItem CONST[263]) 0x9f9d5
            — name = backup['backup_name'] or
            backup['guild_name'] ([rsp+0x88]).
        [E:] THE LABEL — the a9d48 6-piece join 0x9fbba: the
            -1 format of backup_name + ' (' (CONST[206]) + the
            -1 format of guild_name + ') [' (CONST[264]) + the
            -1 format of the id (CONST[265]) + ']' (CONST[266])
            — f"{backup['backup_name']}
            ({backup['guild_name']}) [{backup['id']}]" stored
            [rsp+0x90].
        [E:] THE 100-CAP — the raw len (CONST[267]) over the
            label, the a9d30 sel-4 vs CONST[268] 100 at
            0x9fc8e; the truthy arm: the CONST[26] slice-maker
            with stop = CONST[269] 97 (start null) — label
            [:97] — + the a9d10 sel-7 ADD over CONST[270]
            '...' at 0x9fd69 — if len(label) > 100: label =
            label[:97] + '...'.
        [E:] THE MATCH — the a9d48 5-piece 0x9fed0: the -1
            format of the name-or value + ' ' (CONST[243]) +
            guild_name + ' ' + id — f"{name}
            {backup['guild_name']} {backup['id']}" with
            .lower() over the WHOLE join (CONST[163] 0x9fee9);
            current.lower() ([rsp+0x70], CONST[163] 0x9ffac);
            the a9d30 sel-6 at 0x9ffe6: current.lower() in
            <the lowered join> — the match gate.
        [E:] THE CHOICE — the (name-or-append) arm: GetAttr
            'append' (CONST[250]) over choices; app_commands
            (CONST[271] name-load 0x9a0ce... 0xa00ce) GetAttr
            'Choice' (CONST[272]); the kwargs (3,2) dict:
            'name' (CONST[273]) = the label ([rsp+0x90]),
            'value' (CONST[274]) = str(backup['id']) (the
            CONST[150] stage + the GetItem 0xa01df) —
            choices.append(app_commands.Choice(name=label,
            value=str(backup['id']))).
        [E:] THE CAP — the loop-exhaust 0xa02cc: the PyErr
            check; the raw PyList [rsp+0x78]; the CONST[26]
            slice-maker with stop = CONST[275] 25 (start null)
            0xa031c-0xa0337 — return choices[:25].

        FLAG: the choices/name/label locals name-inferred.
        """
        choices = []
        for backup in self.listBackups():
            name = backup['backup_name'] or \
                backup['guild_name']
            label = f"{backup['backup_name']} " \
                    f"({backup['guild_name']}) " \
                    f"[{backup['id']}]"
            if len(label) > 100:
                label = label[:97] + '...'
            if current.lower() in f'{name} ' \
                    f"{backup['guild_name']} " \
                    f"{backup['id']}".lower():
                choices.append(
                    app_commands.Choice(
                        name=label,
                        value=str(backup['id'])))
        return choices[:25]
