"""
rpc_store.py — the RPC profile family from the SPP native core
(registry L6952 onward), recovered from the corpus event streams
plus island dumps. setActiveRPCProfile is the module-level entry;
the RPC profile class block follows it in registry order in this
module. All persistence here goes through the argumentless
getRPCPath() helper.

  setActiveRPCProfile(profile_name)
                                  — the active marker read-
                                    modify-write over the RPC
                                    file, both opens inline
                                    call expressions

The vanity protector class follows, its methods in registry
order (L7012-L7080). The class name is flagged in its
docstring: no live const carries it.
"""

import json
import time

from datetime import datetime, timedelta


def setActiveRPCProfile(profile_name):
    """Registry L6952. Content: chunk labeled L7012 — recovered
    from the island bytes of chunk 7012 (dump file
    chunk7012_setActiveRPCProfile_L6952.txt, alignment +0, 74
    events, 377 insns @0x670b0 +3552) cross-checked against the
    stream section (function@L6952, corpus lines 17832-17920,
    read complete). Signature ('profile_name',) [E:] —
    const-pool tuple slot 923 (0x670bb, LIVE; the one-argument
    frame enter).

    The active-profile marker read-modify-write over the RPC
    store: native json module over an inline-opened file, marker
    overwrite, dump back. Unlike the /profile.json family this
    function has no with statements at all and no except clause —
    both opens are inline call expressions and the errors pass
    through the PyErr cleanup tail, ending in the implicit None
    return.

    [E:] the inline law this function establishes: on the read
         side json (GOT_143, 0x67101) and .load (GOT_286,
         0x67133) stage BEFORE open (GOT_201, 0x67179) and on
         the write side 'dump' (GOT_689, 0x67409) stages
         before the second open (0x67464) — the callee-first
         ordering of an inline open inside the outer call —
         and the with-exit CONST-1857 slot never appears in
         the whole function: no with statements exist, both
         opens are arguments of json.load/json.dump.
    [E:] the read — json.load(open(getRPCPath(), 'r',
         encoding='utf-8', errors='ignore')) — getRPCPath
         staged (GOT_924, 0x671b9) and called argumentless
         (r8d=0 / r9d=0 at the call site, matching the write
         side's zero-arg call at 0x674e1-0x674ec), open with
         'r' (GOT_283) and the kwargs build encoding='utf-8'
         (GOT_284 / GOT_285) plus errors='ignore' (GOT_685 /
         GOT_686, staged 0x67202-0x67256), the load call at
         0x672c4 binding the data slot [rsp+0x60] (0x672d1).
    [E:] the marker overwrite — data['active_profile'] =
         profile_name — the SetItem at 0x6732c with rcx =
         [rsp+0x60] data, rdx = 'active_profile' (GOT_925,
         staged 0x672f6 with the NULL-rematerialization twin at
         0x673e9) and r8 = [rsp+0x58] profile_name (0x67304),
         the standard NULL-guard trio before it
         (0x67310-0x6731e).
    [E:] the write — json.dump(data, open(getRPCPath(), 'w',
         encoding='utf-8', errors='ignore'), indent=2) — the
         json module staged 0x6735f with the .dump GetAttr
         resolved before the argument evaluation, the second
         getRPCPath (0x674a5) called with r8d=0, the open kind-
         1 count-2 args plus the kind-3 count-2 kwargs holding
         BOTH encoding='utf-8' and errors='ignore' (edx=2 at
         0x67560 — note the contrast with the /profile.json
         family where the write drops the errors kwarg), the
         dump args kind-1 count-2 over (data, the open result,
         0x67594) and the kind-3 count-1 kwargs indent=2
         (GOT_690 / GOT_478, 0x675a1); the dump result is
         discarded and the function falls through to the
         implicit None return (CONST[30] staged 0x67625) after
         the PyErr cleanup tail (corpus events 220-228: GOT_025
         PyErr_Occurred, GOT_007 PyErr_Clear, the None pair).
    [E:] no Exception filter exists in this function (no
         GOT_077 event in the corpus section) — the except-free
         structure is evidence-locked.
    """
    data = json.load(open(getRPCPath(), 'r',
                          encoding='utf-8',
                          errors='ignore'))
    data['active_profile'] = profile_name
    json.dump(data, open(getRPCPath(), 'w',
                         encoding='utf-8',
                         errors='ignore'),
              indent=2)


class VanityProtector:
    """Registry L7012. The class block of the SPP native core
    (registry entries L7012-L7080: __init__, _load, _save,
    set_protection, remove_protection, add_log, get_logs,
    get_protected_vanity, get_all), recovered from the corpus
    event streams plus island dumps of chunks 7016/7024/7028/
    7041/7049/7058/7073 as shipped method by method below.

    [E:] the class name flag: no live const carries the class
         name (the const-pool reprs 900-935 hold the member
         names, keys and signatures only, and no streamed
         corpus section stages it); the instantiation lives
         in still-unrecovered or armed territory. The name
         VanityProtector is the evidence-based inference from
         the '/misc/vanity_protector.json' file __init__ owns
         (CONST[920]) and the 'vanity' / 'protected_vanity'
         keys its methods manage — flagged as inferred, never
         guessed silently; the method bodies are name-
         independent.
    """

    def __init__(self):
        """Registry L7012. Content: chunk labeled L7016 —
        recovered from the island bytes of chunk 7016 (dump
        file chunk7016___init___L7012.txt, alignment +0, 33
        events, 190 insns @0x67680 +704) cross-checked against
        the stream section (function@L7012, corpus lines
        17921-17952, read complete). Signature ('self',) [E:]
        — const-pool tuple slot 278 (0x6768a, LIVE; the
        one-argument frame enter).

        The constructor binds the file path through the
        argumentless getDataPath helper (the zero-arg call
        convention this function pins down for the whole
        recovery) and primes the cache through _load.

        [E:] self._path = f'{getDataPath()}/misc/vanity_
             protector.json' — getDataPath staged (GOT_194,
             0x676ec) and called with r8d=0 / r9d=0 (neither
             args nor kwargs, 0x67727-0x67732), the result
             through the -1 a9d48 FORMAT_VALUE
             (r8d=0xffffffff, 0x6773a) and the two-piece
             BUILD_STRING joining '/misc/vanity_protector'
             '.json' (GOT_920, 0x67746, ecx=2 at 0x67755) —
             the f-string per the FORMAT_VALUE +
             BUILD_STRING law; the SetAttr at 0x67787 with
             rcx = [rsp+0x58] self, rdx = '_path' (GOT_918,
             staged 0x676d0) and r8 = the f-string result.
        [E:] self._data = self._load() — the '_load' GetAttr
             (GOT_921, resolved 0x677f4 with the rematerial-
             ization twin at 0x67806) over self, the call
             with r8d=0 / r9d=0 (0x67828-0x6783b — a zero-
             argument call), then the SetAttr at 0x67859
             with rdx = '_data' (GOT_905, staged 0x677be).
        [E:] the tail: the self slot released, the
             PyErr_Occurred/PyErr_Clear residue check
             (0x6788b-0x67896) and the implicit None return
             (CONST[30] staged 0x6789c); no Exception filter
             exists in the corpus section — except-free.
        """
        self._path = (f'{getDataPath()}'
                      f'/misc/vanity_protector.json')
        self._data = self._load()

    def _load(self):
        """Registry L7016. Content: chunk labeled L7024 —
        recovered from the island bytes of chunk 7024 (dump
        file chunk7024__load_L7016.txt, alignment +0, 93
        events, 472 insns @0x67940 +1920) plus the entry
        prologue at 0x67900 inside chunk 7016's tail,
        cross-checked against the stream section
        (function@L7016, corpus lines 17954-18044, read
        complete). Signature ('self',) [E:] — const-pool
        tuple slot 278 (0x6795a; frame width 2 staged at
        0x67940).

        The cache loader: read the JSON, validate it is a
        dict, return it or a fresh empty dict; the FileReader
        failures return the same clean default.

        [E:] the with — `with open(self._path, 'r',
             encoding='utf-8', errors='ignore') as f:` —
             open staged (GOT_201, 0x6799b), the self._path
             GetAttr (GOT_918, resolved 0x679f4 over
             [rsp+0x78]), the kind-1 count-2 args plus the
             kind-3 count-2 kwargs encoding='utf-8' and
             errors='ignore' (GOT_284 / GOT_285 / GOT_685 /
             GOT_686, 0x67a26-0x67a9d), the with-machinery
             (slot-4 / slot-5 stages 0x67ad9 / 0x67af9,
             PyCallFunction 0x67b15) binding the file slot
             [rsp+0x80] (0x67b34).
        [E:] data = json.load(f) — json staged (GOT_143,
             0x67b4e) with the .load GetAttr (GOT_286,
             0x67db7) over the bound file [rsp+0x80]
             (arg build 0x67ddd-0x67df7), the result binding
             [rsp+0x88] (0x67e2c).
        [E:] the shape gate — `if isinstance(data, dict):
             return data` / `return {}` — isinstance staged
             (GOT_168, 0x67e50) with 'dict' (GOT_904,
             0x67e94), the kind-1 count-2 args (data, dict)
             built 0x67ec8-0x67ed8, the call and IsTrue
             (0x67ef6-0x67f1a); the false arm builds the
             empty dict (the a9d18 kind-3 count-0 at
             0x67f1e-0x67f25, ecx=3 with edx=0 — the literal
             {} emission) while the true arm rebinds the
             data slot (0x67f35); both arms converge into
             the single block exit — the CONST-1857 exit
             dispatch with the triple-None args (0x67f44-
             0x67fb6) — which proves the gate lives inside
             the with block: no separate exit emission
             exists between the load and the isinstance. The
             chosen value then flows the return tail
             (0x67d0c-0x67d73, rsi).
        [E:] the except — `except (FileNotFoundError,
             json.JSONDecodeError): return {}` — the exc
             fetch (a9d40, 0x67b9e), FileNotFoundError
             staged (GOT_919, 0x67bbe) plus json.JSONDecode-
             Error resolved through the nested GetAttr
             (GOT_143 / GOT_495, 0x67c3f), the exception
             two-tuple built kind-1 count-2 (0x67c5f-
             0x67c75), the a9d30 selector-0xa match
             (edx=0xa, 0x67c78-0x67c88); the matched arm
             builds the same empty dict (kind-3 count-0,
             0x67cb6-0x67cbd) and jumps the return tail
             (0x67cf2-0x67cf5) skipping the exit dispatch —
             the handler's return; the unmatched arm restores
             via GOT_002 (0x67d06) and propagates.
        [E:] the error tails verify the roster: [rsp+0x78]
             self, [rsp+0x80] the with file, [rsp+0x88] the
             data; the r15d flag picks propagate (ret-disp
             0x67d3e) or the rsi return (0x67d5c-0x67d73).
        """
        try:
            with open(self._path, 'r',
                      encoding='utf-8',
                      errors='ignore') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
                return {}
        except (FileNotFoundError,
                json.JSONDecodeError):
            return {}

    def _save(self):
        """Registry L7024. Content: chunk labeled L7028 —
        recovered from the island bytes of chunk 7028 (dump
        file chunk7028__save_L7024.txt, alignment +0, 71
        events, 339 insns @0x680c0 +1392 with an alignment
        artifact at the head) plus the entry prologue at
        0x68080 inside chunk 7024's tail, cross-checked
        against the stream section (function@L7024, corpus
        lines 18045-18117, read complete). Signature
        ('self',) [E:] — const-pool tuple slot 278 (0x680dd).

        The cache writer: dump the whole _data through the
        same file, nothing else.

        [E:] the with — `with open(self._path, 'w',
             encoding='utf-8', errors='ignore') as f:` —
             open staged (GOT_201, 0x6811e), the self._path
             GetAttr (GOT_918, resolved 0x68177), the
             kind-1 count-2 args plus the kind-3 count-2
             kwargs holding both encoding='utf-8' and
             errors='ignore' (edx=2 at 0x6821b), the
             with-machinery (slots 4/5, PyCallFunction
             0x68296) binding [rsp+0x80] (0x682b5).
        [E:] json.dump(self._data, f, indent=2) — json
             staged (GOT_143, 0x682cf) with the .dump
             GetAttr (GOT_689, 0x68345), the self._data
             GetAttr (GOT_905, resolved 0x6838c over
             [rsp+0x78]), the kind-1 count-2 args
             (self._data, the bound file [rsp+0x80] at
             0x683c0-0x683dd) plus the kind-3 count-1 kwargs
             indent=2 (GOT_690 / GOT_478, 0x683e3-0x68412),
             the call at 0x6842f with the result discarded.
        [E:] the exit dispatch (CONST-1857, the
             triple-None preparation 0x68443-0x6845c) and
             the implicit None return; no Exception filter
             in the corpus section — except-free.
        """
        with open(self._path, 'w',
                  encoding='utf-8',
                  errors='ignore') as f:
            json.dump(self._data, f, indent=2)

    def set_protection(self, id, protected_vanity, action):
        """Registry L7028. Content: chunk labeled L7041 —
        recovered from the island bytes of chunk 7041 (dump
        file chunk7041_set_protection_L7028.txt, alignment
        +0, 94 events, 527 insns @0x68640 +1392) plus the
        entry prologue at 0x68080 inside chunk 7024's tail,
        cross-checked against the stream section
        (function@L7028, corpus lines 18118-18208, read
        complete). Signature ('self', 'id',
        'protected_vanity', 'action') [E:] — const-pool
        tuple slot 916 (0x6864a, LIVE; the four-argument
        frame enter).

        The upsert with a remove sentinel: an empty or None
        protected_vanity clears the id through remove_
        protection and returns None; otherwise the entry is
        created or extended, given its logs list, stored
        back, saved, and returned.

        [E:] id = str(id) — str staged (GOT_150, 0x6868b)
             over the id parameter slot [rsp+0x60], the
             call 0x686fb and the rebind of [rsp+0x60]
             (0x68709-0x6871e) — the frame-slot rebind law.
        [E:] the sentinel — `if protected_vanity is None or
             protected_vanity == '':` — compare one is the
             a9d30 selector-8 None test over [rsp+0x68]
             against CONST[30] (edx=8, call 0x6874b),
             compare two is the selector-2 emptiness test
             against CONST[241] '' (edx=2, call 0x68829),
             the two False-const arms (0x6876c, 0x6884a)
             feeding the shared or-gate at 0x68791 whose
             jne 0x68872 opens the remove arm; corpus
             events 56-101.
        [E:] the remove arm — self.remove_protection(id) —
             the 'remove_protection' GetAttr (GOT_917,
             0x6889b over [rsp+0x58] self) with the kind-1
             count-1 args over the rebound id (0x689c7-
             0x689de), the call 0x689fe whose result is
             released (0x68a0d); the explicit return None —
             the CONST[30] staged 0x68a1d, r14 cleared, rsi
             = the None through the shared guard 0x68a2d
             into the return tail 0x68b69.
        [E:] the create arm — entry = self._data.get(id,
             {}) — the self._data GetAttr (GOT_905,
             0x687e5), the .get (GOT_47, 0x688e8), the
             fresh {} built kind-3 with edx=0 (0x6892c-
             0x68933) and the kind-1 count-2 args (id, {})
             (0x68935-0x68945), the call 0x68964 binding
             the entry slot [rsp+0x78] (0x68975).
        [E:] entry['protected_vanity'] = protected_vanity
             — the SetItem 0x68a7a (rdx = GOT_909, r8 =
             [rsp+0x68]); entry['action'] = action — the
             SetItem 0x68ae8 (rdx = GOT_908, r8 =
             [rsp+0x70]); corpus events 172 / 189.
        [E:] entry.setdefault('logs', []) — the setdefault
             GetAttr resolves over the ENTRY slot (0x68b16-
             0x68b3e), the empty list built kind-2 with
             edx=0 (0x68c2b) and the kind-1 count-2 args
             ('logs', []) (0x68c34-0x68c44), the call
             0x68c63 with the result released (0x68c72) —
             the default-list seeding via the reference-
             holder, discarded and re-read from the stored
             entry by the consumers below; corpus events
             194-221.
        [E:] self._data[id] = entry — the _data GetAttr
             re-staged (0x68c84-0x68c98) and the SetItem
             0x68cfa (rcx = _data, rdx = the id [rsp+0x60],
             r8 = the entry [rsp+0x78]); corpus event 260.
        [E:] self._save() — the GetAttr (GOT_915,
             0x68d38/0x68d4c) and the zero-argument call
             (xor r8d / xor r9d, 0x68dac) with the result
             released.
        [E:] return entry — the entry slot reloaded at
             0x68dcb, its reference taken through the
             shared guard 0x68a2d and returned via rsi —
             the same guard the remove arm reaches with the
             None; corpus events 296-355.
        """
        id = str(id)
        if (protected_vanity is None
                or protected_vanity == ''):
            self.remove_protection(id)
            return None
        entry = self._data.get(id, {})
        entry['protected_vanity'] = protected_vanity
        entry['action'] = action
        entry.setdefault('logs', [])
        self._data[id] = entry
        self._save()
        return entry

    def remove_protection(self, id):
        """Registry L7041. Content: chunk labeled L7049 —
        recovered from the island bytes of chunk 7049 (dump
        file chunk7049_remove_protection_L7041.txt,
        alignment +0, 45 events, 259 insns @0x68e10 +2032)
        plus the entry prologue at 0x68de0 inside chunk
        7041's tail, cross-checked against the stream section
        (function@L7041, corpus lines 18209-18254, read
        complete). Signature ('self', 'id') [E:] — const-pool
        tuple slot 906 (0x68e34, LIVE; the two-argument
        frame enter).

        The deleter: membership tested first, the entry
        dropped and saved on a hit, a hard False on a miss.

        [E:] id = str(id) — str staged (GOT_150, 0x68e75)
             over the id parameter slot [rsp+0x60], the call
             0x68ee5 and the rebind (0x68efb).
        [E:] `if id in self._data:` — the self._data GetAttr
             (GOT_905, resolved 0x68f61) and the a9d30
             selector-6 membership (edx=6 at 0x68f88, r8 =
             the rebound id, r9 = self._data) with the
             False-const inversion arm (0x68fb5); the miss
             arm stages and returns the explicit False
             (CONST[32], 0x68ff2, ebp cleared); corpus
             events 51-98.
        [E:] the hit arm — `del self._data[id]` — the _data
             GetAttr re-staged (0x6901a-0x6902e) and
             Py_DelItem at 0x69076 (rdx = the id [rsp+0x60]);
             then self._save() — the GetAttr (GOT_915,
             0x690ab/0x690c3) with the zero-argument call
             0x69172 and the result released (0x69181);
             then the explicit return True (CONST[31] staged
             0x69191 through the shared 0x69002 guard);
             corpus events 134-165.
        """
        id = str(id)
        if id in self._data:
            del self._data[id]
            self._save()
            return True
        return False

    def add_log(self, id, log):
        """Registry L7049. Content: chunk labeled L7058 —
        recovered from the island bytes of chunk 7058 (dump
        file chunk7058_add_log_L7049.txt, alignment +0, 65
        events, 372 insns @0x691f0 +976 with an alignment
        artifact at the head) plus the entry prologue at
        0x691b0 inside chunk 7049's tail, cross-checked
        against the stream section (function@L7049, corpus
        lines 18255-18323, read complete). Signature
        ('self', 'id', 'log') [E:] — const-pool tuple slot
        913 (0x6920e, LIVE; the three-argument frame enter).

        The appender: a missing id is a hard False; a hit
        appends the stringified log to the entry's lazy
        logs list, saves, and returns True.

        [E:] id = str(id) — str staged (GOT_150, 0x6924f)
             over the id slot [rsp+0x60], the call 0x692bf
             and the rebind (0x692d2).
        [E:] entry = self._data.get(id) — the _data GetAttr
             (GOT_905, 0x69309), the .get GetAttr (GOT_47,
             0x69353) and the kind-1 count-1 args over the
             rebound id (0x69386-0x69390) — a single
             argument, no default — the call 0x693b0
             binding the entry slot [rsp+0x70] (0x693c1).
        [E:] `if entry is None: return False` — the a9d30
             selector-8 None test over the entry (edx=8,
             call 0x69408, the CONST[30] operand staged
             0x693ef), the IsTrue chain and the False arm
             loading the explicit False (CONST[32], 0x6950d
             through the shared return guard 0x6972b);
             corpus events 105-126.
        [E:] the chain — entry.setdefault('logs',
             []).append(str(log)) — the setdefault GetAttr
             over the entry (GOT_914, 0x69483) with the
             'logs' (GOT_910, 0x69546) and the empty list
             built kind-2 with edx=0 (0x69560) as the
             kind-1 count-2 args (0x69579), the setdefault
             call 0x69598 whose result is NOT released —
             the .append GetAttr resolves over it (GOT_250,
             0x695b7) — then str staged a second time
             (GOT_150, 0x695e4) over the log parameter
             [rsp+0x68] (args 0x69616-0x69634, call
             0x69654) and the kind-1 count-1 append args
             over that (0x69657-0x69664), the append call
             0x69683 with its None result released; corpus
             events 129-184.
        [E:] self._save() — the GetAttr (GOT_915,
             0x696ab/0x696bf) and the zero-argument call
             0x69705, the result released; then the
             explicit return True (CONST[31], staged
             0x69724); corpus events 196-226.
        """
        id = str(id)
        entry = self._data.get(id)
        if entry is None:
            return False
        entry.setdefault('logs', []).append(str(log))
        self._save()
        return True

    def get_logs(self, id):
        """Registry L7058. Content: chunk labeled L7073 —
        recovered from the island bytes of chunk 7073 (dump
        file chunk7073_get_logs_L7058.txt, alignment +0, 87
        events, 492 insns @0x697a0 +1424) plus the entry
        prologue at 0x69740 inside chunk 7058's tail,
        cross-checked against the stream section
        (function@L7058, corpus lines 18324-18403, read
        complete). Signature ('self', 'id') [E:] — const-pool
        tuple slot 906 (0x697a4, LIVE; the two-argument
        frame enter).

        The reader: newest-first walk over the entry's lazy
        logs list, each log prepended above the accumulated
        text separated by a newline, the walk cut at the
        3500-character wall.

        [E:] id = str(id) — str staged (GOT_150, 0x697e5)
             over the id slot [rsp+0x60], the call 0x69855
             and the rebind (0x69863).
        [E:] entry = self._data.get(id) — the _data GetAttr
             (GOT_905, 0x6989f), the .get (GOT_47,
             0x698e9), the kind-1 count-1 args over the
             rebound id (0x69908-0x69926) and the call
             0x69946 binding [rsp+0x68] (0x69957) — a
             single argument, no default.
        [E:] `if not entry: return ''` — the IsTrue over
             the entry (0x6997d) with the swapped-const not
             emission (the truthy arm stages CONST[32]
             False at 0x69998, the falsy arm stages
             CONST[31] True at 0x699a9), the gate branch
             0x699da sending the not-entry arm to 0x69a0e
             where the explicit '' return is staged
             (CONST[241], 0x69a18); corpus events 102-119.
        [E:] logs = entry.get('logs', []) — the .get
             GetAttr over the entry (GOT_47, 0x69a03) with
             'logs' (GOT_910, 0x69a62) and the empty list
             built kind-2 with edx=0 (0x69a7c) as the
             kind-1 count-2 args (0x69a85-0x69a95), the
             call 0x69ab4 binding [rsp+0x70]; corpus
             events 116-155.
        [E:] result = '' — the accumulator slot [rsp+0x78]
             seeded with the CONST[241] '' (0x69ae5-0x69af1).
        [E:] the iterable — reversed(logs) — reversed
             staged (GOT_911, 0x69b03) over [rsp+0x70],
             converted through the GetIter family (the
             const-pool 27 slot, 0x69b84) and driven by the
             a9d60 iternext (0x69ba2) with each item in
             [rsp+0x80] (0x69bbe); corpus events 166-194.
        [E:] the prepend — `result = log if not result
             else f'{log}\\n{result}'` — the not-result
             computed through the swapped-const emission
             over the accumulator (IsTrue pair 0x69be4 /
             0x69c1d, the CONST[32] / CONST[31] arms at
             0x69bff / 0x69c08); the empty arm takes the raw
             item (0x69c3b-0x69cc0), the built arm runs
             the item through the -1 a9d48 FORMAT_VALUE
             (0x69c50-0x69c74), the '\\n' literal (GOT_239,
             staged 0x69c77), the accumulator through a
             second -1 FORMAT_VALUE (0x69c86-0x69ca4) and
             the three-piece BUILD_STRING (ecx=3 at
             0x69ca6, the piece order [log, \\n, result]);
             both arms converge the new value into
             [rsp+0x88] (0x69cc0-0x69cc8); corpus events
             205-230.
        [E:] the wall — `if len(result) > 3500: break` —
             len staged (GOT_267, 0x69ce9) over the new
             [rsp+0x88] value (args 0x69d1a-0x69d3b, call
             0x69d59), the a9d30 selector-4 comparison
             (edx=4 at 0x69d6e, r8 = the length, r9 =
             CONST[912] 3500 staged 0x69d5c) with the
             standard False-const arm (0x69d98); past the
             gate the accumulator rebinds from the new
             value ([rsp+0x78] = [rsp+0x88], 0x69dcd-
             0x69dd2) and the back-edge iternext continues
             (0x69de5, jne 0x69bb6), the over-wall arm
             releasing the iterator out through 0x69ebd —
             the compiled break; corpus events 237-292.
        [E:] return result — the post-loop loads the
             accumulator [rsp+0x78] (0x69ed0) through the
             shared return guard 0x69a28; the no-entry arm
             returns the '' from its own guard; corpus
             events 295-328.
        """
        id = str(id)
        entry = self._data.get(id)
        if not entry:
            return ''
        logs = entry.get('logs', [])
        result = ''
        for log in reversed(logs):
            result = (log if not result
                      else f'{log}\n{result}')
            if len(result) > 3500:
                break
        return result

    def get_protected_vanity(self, id):
        """Registry L7073. Content: chunk labeled L7080 —
        recovered from the island bytes of chunk 7080 (dump
        file chunk7080_get_protected_vanity_L7073.txt,
        alignment +0, 55 events, 312 insns @0x69f40 +1968)
        plus the entry prologue at 0x69ef0 inside chunk
        7073's tail, cross-checked against the stream
        section (function@L7073, corpus lines 18404-18465,
        read complete). Signature ('self', 'id') [E:] —
        const-pool tuple slot 906 (0x69f44, LIVE; the
        two-argument frame enter).

        The reader: a missing entry is a hard None; a hit
        returns the facade dict where the stored
        protected_vanity surfaces under the short vanity
        key alongside the action.

        [E:] id = str(id) — str staged (GOT_150, 0x69f85)
             with the kind-1 count-1 args over the id slot
             [rsp+0x60] (built 0x69fb7-0x69fd5), the call
             0x69ff5 and the rebind of [rsp+0x60] at
             0x6a003-0x6a008.
        [E:] entry = self._data.get(id) — the _data GetAttr
             (GOT_905, staged 0x6a02b, resolved 0x6a03f)
             with the .get GetAttr (GOT_47, resolved
             0x6a089), the kind-1 count-1 args over the
             rebound id (0x6a0af-0x6a0c6), the call 0x6a0e6
             binding the entry slot [rsp+0x68] (0x6a0f7);
             corpus events 58-102.
        [E:] `if not entry: return None` — the direct IsTrue
             over the entry (0x6a11d) with the swapped-const
             not emission (CONST[32] at 0x6a138, CONST[31]
             at 0x6a149), the gate 0x6a170 sending the
             empty arm to 0x6a239 where the explicit None
             return is staged (CONST[30], 0x6a243); corpus
             events 102-119.
        [E:] the two reads — entry.get('protected_vanity')
             and entry.get('action') — the first .get
             GetAttr over the entry (GOT_47, 0x6a1ac) with
             the kind-1 count-1 args ('protected_vanity',
             GOT_909, built 0x6a283-0x6a2a3) and the call
             0x6a2c1; the second .get (GOT_47, resolved
             0x6a2ff over the reloaded entry 0x6a2de) with
             the ('action', GOT_908, built 0x6a333-0x6a353)
             args and the call 0x6a371; corpus events
             127-187.
        [E:] the return dict — {'vanity': entry.get(
             'protected_vanity'), 'action': entry.get(
             'action')} — the a9d18 kind-3 count-2 build
             (ecx=3, edx=2 at 0x6a37d) with the external
             'vanity' key (GOT_907, staged 0x6a187 in rsi)
             over the protected_vanity value in r8/r9 and
             the stack pair carrying ('action' GOT_908 in
             r13, its get result, 0x6a373-0x6a378); corpus
             events 185-211.
        """
        id = str(id)
        entry = self._data.get(id)
        if not entry:
            return None
        return {'vanity': entry.get('protected_vanity'),
                'action': entry.get('action')}

    def get_all(self):
        """Registry L7080. Content: chunk labeled L7172 —
        recovered from the island bytes of chunk 7172 (dump
        file chunk7172_get_all_L7080.txt, alignment +0, 15
        events, 101 insns @0x6a3e0 +384) cross-checked
        against the stream section (function@L7080, corpus
        lines 18466-18482, read complete). Signature
        ('self',) [E:] — const-pool tuple slot 278
        (0x6a3e9, LIVE; the one-argument frame enter).

        The snapshot: a shallow copy of the whole store.

        [E:] return dict(self._data) — dict staged (GOT_
             904, 0x6a434) with the self._data GetAttr
             (GOT_905, resolved 0x6a489 over [rsp+0x58]),

             the kind-1 count-1 args over the _data object
             (0x6a4bb-0x6a4c8), the dict call 0x6a4e7 and
             the result returned through the tail (0x6a4ea-
             0x6a50a); corpus events 22-62.
        [E:] the merged set_guild_vanity (original line
             7086, 550 bytes, a session-1 no-body casualty)
             is absent from BOTH chunk 7172 and chunk 7183
             — the 7183 island spans 0x6a520-0x6ad00 and
             contains only startRPCTimer with the next entry
             prologue at 0x6ad00; its body lives in neither
             streamed nor span territory and joins the
             armed-assault watch list.
        """
        return dict(self._data)


def startRPCTimer(start, end):
    """Registry L7172. Content: chunk labeled L7183 —
    recovered from the island bytes of chunk 7183 (dump
    file chunk7183_startRPCTimer_L7172.txt, alignment +0,
    95 events, 491 insns) plus the entry prologue at
    0x6a520 inside chunk 7172's tail, cross-checked against
    the stream section (function@L7172, corpus lines
    18483-18602, read complete). Signature ('start', 'end')
    [E:] — const-pool tuple slot 899 (0x6a57b, LIVE; the
    two-argument frame enter).

    The RPC timers: the marker global is set to now, an
    elapsed (hours, minutes, seconds) tuple shifts it back,
    a duration tuple sets the end marker from it, and no
    duration clears the end marker. Timer semantics live
    alongside processDRPCData's timestamps family.

    [E:] start_rpc_time = datetime.now() — datetime staged
         (GOT_151 / GOT_152 with the .now GetAttr, the
         zero-arg call 0x6a648) stored through the
         global-name stage (the 'start_rpc_time' const
         GOT_900 in rsi over the now result, 0x6a660-
         0x6a680 — the a9d50 (name, value) STORE form of
         the global-name law); corpus events 38-61.
    [E:] `if start:` — the [rsp+0x68] parameter IsTrue
         (0x6a69f, branch jne 0x6a71e); `if end:` — the
         [rsp+0x70] parameter IsTrue (0x6a6d3, branch jne
         0x6a796) with the both-falsy fallthrough to the
         None arm; corpus events 71-108.
    [E:] the start arm — start_rpc_time = start_rpc_time -
         timedelta(hours=start[0], minutes=start[1],
         seconds=start[2]) — the start_rpc_time reload
         (stage r8d=1, 0x6a72c-0x6a740), the timedelta
         staged (GOT_896, r8d=1 at 0x6a763) with the three
         GetItems over the start tuple (hours CONST[277] 0
         at 0x6a820/0x6a836, minutes CONST[233] 1 at
         0x6a897/0x6a8ad, seconds CONST[478] 2 at
         0x6a8ff/0x6a915) feeding the kind-3 count-3
         kwargs build (0x6a95d-0x6a96f) and the timedelta
         call (0x6a997), then the a9d10 binop over (the
         reloaded start_rpc_time, the timedelta) with
         SELECTOR 0xE (0x6a9a4) and the store back into
         the start_rpc_time global (0x6a9bd-0x6a9d6,
         jne back into the end gate 0x6a9f4); corpus events
         110-200.
    [E:] THE 0xE FLAG: the a9d10 selector 0xE is not in
         the established op map (0x24 minus, 0x22 modulo,
         0xc floor-div, 0x1d multiply, 7 plus). The minus
         reading rests on the timer semantics (an elapsed
         tuple shifts the marker BACK while the duration
         tuple uses the established plus selector 7) and
         on the complementary pair both arms form; the
         selector number itself remains to be verified
         against the undumped sub-GOT op table
         (elf+0xA9000..0xA9D68) — flagged, not guessed
         away.
    [E:] the end arm — end_rpc_time = start_rpc_time +
         timedelta(hours=end[0], minutes=end[1],
         seconds=end[2]) — the start_rpc_time reload again
         (the GOT_900 const at 0x6a7ab, stage r8d=1 with
         the result held r15/[rsp+0x90]), the second
         timedelta staged (0x6aa33) with the three
         GetItems over the end tuple (hours 0 at
         0x6aaaa/0x6aac0, minutes 1 at 0x6ab21/0x6ab36,
         seconds 2 at 0x6ab86/0x6ab9b) feeding the kind-3
         count-3 kwargs (0x6abe1-0x6abf3) and the call
         0x6ac18, then the a9d10 binop over (the reloaded
         start_rpc_time, the timedelta) with the
         ESTABLISHED selector 7 (0x6ac2a) and the store
         into the end_rpc_time global (the GOT_903 const,
         store 0x6ac44-0x6ac4f); corpus events 229-329.
    [E:] the both-falsy arm — end_rpc_time = None — the
         GOT_903 const with the CONST[30] value staged
         straight to the same store at 0x6a6f5-0x6ac44
         (jmp 0x6ac44); corpus events 88-108.
    [E:] the implicit None return (CONST[30] staged
         0x6ac96 after the param releases and the
         PyErr residue clear); corpus events 210-228, 342.
    """
    start_rpc_time = datetime.now()
    if start:
        start_rpc_time = start_rpc_time - timedelta(
            hours=start[0], minutes=start[1],
            seconds=start[2])
    if end:
        end_rpc_time = start_rpc_time + timedelta(
            hours=end[0], minutes=end[1],
            seconds=end[2])
    else:
        end_rpc_time = None


def get_elapsed_time_unix():
    """Registry L7183. Content: chunk labeled L7219 —
    recovered from the island bytes of chunk 7219 (dump
    file chunk7219_get_elapsed_time_unix_L7183.txt,
    alignment +0, 55 events, 295 insns @0x6ad40 +1136)
    plus the entry prologue at 0x6ad00 inside chunk 7183's
    tail, cross-checked against the stream section
    (function@L7183, corpus lines 18603-18663, read
    complete). Signature () [E:] — a zero-argument module
    function; the corpus shows only the GOT_000 frame and
    no argument tuple is staged.

    The elapsed reader: recomposes the current moment as
    the start_time global shifted forward by the elapsed
    seconds, then returns its unix timestamp as an int.

    [E:] the elapsed — time.time() - start_time — the
         time module staged (GOT_427, 0x6ad54) with the
         .time GetAttr resolved over it (0x6ad9f — the
         second GOT_427 staging names the method builtin)
         and the zero-arg call 0x6add3; the start_time
         global loaded through the name stage (GOT_894,
         stage r8d=1, 0x6ade7-0x6adfb); the a9d10 binop
         with the ESTABLISHED selector 0x24 minus
         (r8d=0x24, 0x6ae0d - the counterpart of the 0xE
         flag in startRPCTimer's family) over (the now,
         the global) binding [rsp+0x48].
    [E:] the recomposition — datetime.fromtimestamp(
         start_time) + timedelta(seconds=elapsed) — the
         datetime module staged (GOT_151, 0x6ae3a) with
         the .fromtimestamp GetAttr (GOT_895, 0x6ae8c),
         the start_time global re-loaded (0x6aeb2-0x6aed4)
         as the kind-1 count-1 args (0x6aee4-0x6aef1) with
         the call 0x6af12 binding [rsp+0x50]; then timedelta
         staged (GOT_896, 0x6af70) with the kind-3 count-1
         kwargs seconds=elapsed (GOT_897 with r9 =
         [rsp+0x48], built 0x6afa5-0x6afcb, the call
         0x6afeb) and the a9d10 binop with the ESTABLISHED
         selector 7 (r8d=7, 0x6aff4) over (the
         fromtimestamp result, the timedelta) binding
         [rsp+0x58]; corpus events 64-123.
    [E:] the return — int(<that>.timestamp()) — int
         staged (GOT_372, 0x6b02c), the .timestamp
         GetAttr over the binop result (GOT_898,
         0x6b074/0x6b088) with the zero-arg call
         (0x6b0cd), then the kind-1 count-1 args (the
         timestamp result, 0x6b0d0-0x6b0dd) and the int
         call 0x6b0fc whose value is the return (the rdi
         release-check path 0x6b143 warns only on a NULL
         expression); corpus events 140-187.
    [E:] the start_time global (GOT_894) is distinct from
         start_rpc_time (GOT_900) — it is set outside this
         streamed family and read here; no store to it
         exists in this function.
    """
    return int(
        (datetime.fromtimestamp(start_time)
         + timedelta(
             seconds=time.time() - start_time)
         ).timestamp())


def getAppAssets():
    """Registry L7219. Content: chunk labeled L7237 —
    recovered from the island bytes of chunk 7237 (dump
    file chunk7237_getAppAssets_L7219.txt, alignment +0,
    17 events, 122 insns @0x6b1b0 +448 per the span line
    with the function entry embedded at the chunk head)
    cross-checked against the stream section
    (function@L7219, corpus lines 18664-18680, read
    complete). Signature () [E:] — a zero-argument module
    function; no argument tuple is staged.

    The assets reader: a fresh manager from the app_
    manager callable, its get_assets method over the
    current app id, the result returned directly.

    [E:] the manager — the app_manager name staged
         (GOT_558, stage r8d=1, 0x6b1d1) and CALLED with
         neither args nor kwargs (rdx = the loaded name,
         r8d=0 / r9d=0, the call 0x6b1fc — the callable is
         an object or class, its instance result in rbx)
         with the .get_assets GetAttr over it (GOT_892,
         resolved 0x6b21b); corpus events 17-35.
    [E:] the id — the getCurrentAppId name staged (GOT_
         559, 0x6b264) and called argumentless the same
         way (0x6b28d), the result as the kind-1 count-1
         args (0x6b290-0x6b29d); corpus events 40-48.
    [E:] the call — the get_assets invocation 0x6b2bc
         binding [rsp+0x48] and returned through the
         shared NULL-guard release (0x6b2e6-0x6b303);
         corpus events 71.
    [E:] the entry artifact: the chunk opens at 0x6b1b0
         with a stray `xor eax, 0x3eb6b` before the first
         staging — the emitter's padding, not source.
    """
    return app_manager().get_assets(getCurrentAppId())
