"""
table_component.py — the Table UI component class (registry
L3392-L3659), recovered via the Ghidra decomp lane. Recovered as
a real class: the double-underscore privates below reproduce the
mangled _Table__* const slots exactly at runtime.

  __init__ (L3392)                 — sig slot 1406 (LIVE); the
                                     eager column/button
                                     validation with the EXACT
                                     ValueError family
  render (L3637)                   — the columns-empty gate +
                                     the 11-field dict
  update_rows (L3523)              — rows_validator + the
                                     evaluate_js update push +
                                     the selected-id harvest
  insert_rows (L3543)              — merged region; reconstructed
                                     from the sibling pattern +
                                     the exact consts (flagged)
  delete_rows (L3558)              — isinstance gate + the
                                     evaluate_js delete push +
                                     the row/selection removal
  __rows_validator (L3599)         — the Exception-based rows
                                     gate incl. the cells count
  __get_selected_rows_ids (L3590)  — the selected-id harvest
  the row/button listeners (L3572 / L3577) — module-level
      listener functions below the class (their live sigs carry
      no self: ('row_id', 'selected') slot 1424 and ('onClick',
      'row_id') slot 1426 — they are the registered closures,
      not bound methods).

JS push contract recovered: evaluate_js('updateCustomTableRows(
{ "id": "' + id + '", "rows": ' + json.dumps(rows) +
', "type": "update" } )') — with the "idsToDelete"/delete and
"position"/insert variants.
"""

import json
import uuid


class Table:
    """The table component (registry L3392-L3659)."""

    def __init__(self, parent_tab_name, tab_updater, columns,
                 rows, search, onSelectionChange, items_per_page,
                 selectable, visible):
        """Registry L3392 (Table.__init__). Content: chunk labeled
        L3523 (stream section function@L3392). Signature ('self',
        'parent_tab_name', 'tab_updater', 'columns', 'rows',
        'search', 'onSelectionChange', 'items_per_page',
        'selectable', 'visible') [E:] — const-pool tuple slot
        1406.

        [E:] the SetAttr cascade: __id = str(uuid.uuid4()) —
             GOT_1367/150/524/525 (L73-123); __parent_tab_name
             (GOT_1370, L132-151); __tab_updater (GOT_1407,
             L160-169); __selected_row_ids = <empty build>
             (GOT_1390 + a9d18, L178-190); __rows (GOT_1386,
             L199-209); __selectable (GOT_1372, L218-228);
             __items_per_page (GOT_1373, L237-247); __visible
             (GOT_1374, L256-266); __search (GOT_1375, L275-285);
             __row_select_listener_id = str(uuid.uuid4()) —
             GOT_1368 (L294-336); __button_listener_id =
             str(uuid.uuid4()) — GOT_1369 (L345-386).
        [E:] the EAGER column validation loop (GetIter over the
             columns argument, L394-397), per column: the 'type'
             checked in ('text' GOT_097 / 'button' GOT_1408 /
             'tag' GOT_1409) → ValueError("Column type must be
             one of 'text', 'button', 'tag'") — EXACT GOT_1410;
             the label empty-or-seen gate + the list-append
             tracker (L589-622) → ValueError('Duplicate or empty
             column labels are not allowed') — EXACT GOT_1411;
             for 'button' columns: the 'buttons' key +
             isinstance list (GOT_168/344) → ValueError("Column
             type 'button' must have a 'buttons' key with a list
             value") — EXACT GOT_1412; per button: empty label →
             ValueError('Button label cannot be empty') —
             GOT_1413 (pool-shared with Button.render);
             duplicate label → ValueError('Duplicate button
             labels are not allowed') — EXACT GOT_1414 (tracker
             append L949-983); the color in ('default' GOT_1415 /
             'danger' GOT_1416) → ValueError("Button color must
             be one of 'default', 'danger'") — EXACT GOT_1417;
             falsy onClick → ValueError('Button onClick callback
             is not defined.') — GOT_1419 (pool-shared); not
             callable (GOT_1420) → ValueError('Button onClick
             must be a callable function.') — EXACT GOT_1421;
             then callback_store.register (GOT_641/1422) with the
             button onClick (L1202-1216; the register key is
             const-staged only — FLAG: translated as the
             __name__, the only string the JS side receives
             back) and the onClick value replaced with
             <onClick.__name__> (SetItem L1290, the __name__
             GetAttr L1274-1280).
        [E:] __columns = columns AFTER the validation (SetAttr
             L1312-1321); a truth-check token on __rows_setter
             (GOT_1423) at L1325-1358 — purpose unresolved
             (bound methods are always truthy) — flagged.
        [E:] the onSelectionChange block: `if onSelectionChange
             is not None:` (None consts L1375-1377) → the
             callback_store.register + self.__onSelectionChange
             = <onSelectionChange.__name__> (GOT_509, L1419-1442;
             the register key flagged — translated as the
             __name__).
        [E:] two CLOSURE registrations: under the row-select
             listener id (DAT_000a9d58 + unlabeled GOT_1828,
             L1446-1510, the ('row_id', 'selected') closure) and
             the button listener id (unlabeled GOT_1832,
             L1521-1577, the ('onClick', 'row_id') closure) —
             bodies not const-visible (see the module-level
             listeners below).
        """
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__selected_row_ids = []
        self.__rows = rows
        self.__selectable = selectable
        self.__items_per_page = items_per_page
        self.__visible = visible
        self.__search = search
        self.__row_select_listener_id = str(uuid.uuid4())
        self.__button_listener_id = str(uuid.uuid4())
        column_labels = []
        button_labels = []
        for column in columns:
            if column['type'] not in ('text', 'button', 'tag'):
                raise ValueError("Column type must be one of "
                                 "'text', 'button', 'tag'")
            if not column['label'] or \
                    column['label'] in column_labels:
                raise ValueError('Duplicate or empty column '
                                 'labels are not allowed')
            column_labels.append(column['label'])
            if column['type'] == 'button':
                if not isinstance(column['buttons'], list):
                    raise ValueError("Column type 'button' must "
                                     "have a 'buttons' key with "
                                     "a list value")
                for button in column['buttons']:
                    if not button['label']:
                        raise ValueError('Button label cannot '
                                         'be empty')
                    if button['label'] in button_labels:
                        raise ValueError('Duplicate button '
                                         'labels are not '
                                         'allowed')
                    button_labels.append(button['label'])
                    if button['color'] not in ('default',
                                               'danger'):
                        raise ValueError(
                            "Button color must be one of "
                            "'default', 'danger'")
                    if not button['onClick']:
                        raise ValueError('Button onClick '
                                         'callback is not '
                                         'defined.')
                    if not callable(button['onClick']):
                        raise ValueError('Button onClick must '
                                         'be a callable '
                                         'function.')
                    callback_store.register(
                        button['onClick'].__name__,
                        button['onClick'])
                    button['onClick'] = button['onClick'].__name__
        self.__columns = columns
        if onSelectionChange is not None:
            callback_store.register(
                onSelectionChange.__name__, onSelectionChange)
            self.__onSelectionChange = onSelectionChange.__name__
        callback_store.register(
            self.__row_select_listener_id, None)  # FLAG: the
        # ('row_id', 'selected') closure (GOT_1828) — not
        # const-visible
        callback_store.register(
            self.__button_listener_id, None)  # FLAG: the
        # ('onClick', 'row_id') closure (GOT_1832) — not
        # const-visible

    def render(self):
        """Registry L3637 (Table.render). Content: chunk labeled
        L3659 (stream section function@L3637).

        [E:] the gate: len(self.__columns) compared to int-0
             (GOT_267 + GOT_277, L46-102) → ValueError('Table
             columns cannot be empty') — EXACT GOT_1359 (L382-
             393).
        [E:] the emitted dict: 'type' (GOT_248) = 'table'
             (GOT_1366); 'id' (GOT_265) + __id (GOT_1367);
             'row_select_listener_id' (GOT_1360) +
             __row_select_listener_id (GOT_1368);
             'button_listener_id' (GOT_1361) +
             __button_listener_id (GOT_1369); 'parent_tab_name'
             (GOT_1282) + __parent_tab_name (GOT_1370);
             'onSelectionChange' (GOT_1362) + __onSelectionChange
             (GOT_1371); 'columns' (GOT_1327) + __columns
             (GOT_1358); 'selectable' (GOT_1363) + (GOT_1372);
             'items_per_page' (GOT_1364) + (GOT_1373); 'visible'
             (GOT_1365) + (GOT_1374); 'search' (GOT_229) +
             __search (GOT_1375) — L111-369; return-dispatch
             L404.
        """
        if len(self.__columns) == 0:
            raise ValueError('Table columns cannot be empty')
        return {
            'type': 'table',
            'id': self.__id,
            'row_select_listener_id':
                self.__row_select_listener_id,
            'button_listener_id': self.__button_listener_id,
            'parent_tab_name': self.__parent_tab_name,
            'onSelectionChange': self.__onSelectionChange,
            'columns': self.__columns,
            'selectable': self.__selectable,
            'items_per_page': self.__items_per_page,
            'visible': self.__visible,
            'search': self.__search,
        }

    def __rows_validator(self, rows):
        """Registry L3599 (Table.__rows_validator). Content:
        chunk labeled L3637 (stream section function@L3599).
        Signature ('self', 'rows') [E:] — const-pool tuple slot
        1376. All failures raise the base Exception class
        (GOT_077), NOT ValueError.

        [E:] `if not isinstance(rows, list):` (GOT_168 + GOT_344,
             L35-80) → raise Exception('The rows must be a
             list.') — EXACT GOT_1377.
        [E:] seen = set() — GOT_384 (L82-110); per row (GetIter
             + a9d60, L123-129): `if not isinstance(row, dict):`
             (GOT_168 + GOT_904) → raise Exception('Each row must
             be a dictionary.') — EXACT GOT_1378.
        [E:] the id gate ('id' presence via a9d30 + isinstance
             str GOT_150, L207-283) → raise Exception("Each row
             must have a unique 'id' of type string.") — EXACT
             GOT_1379; the duplicate gate (row['id'] in seen,
             L307-338) → raise Exception('Duplicate id found: '
             + row['id']) — EXACT GOT_1380 + the concat; then
             seen.add(row['id']) (GOT_389, L390-440).
        [E:] the cells gate ('cells' containment GOT_1381 +
             isinstance list, L434-508) → raise Exception('Row
             with id ' + row['id'] + " must have a 'cells' key
             with a list value.") — GOT_1382 + GOT_1383.
        [E:] the count gate: len(row['cells']) vs len(-
             __columns) (GOT_267 + the GetAttr L601-627) →
             raise Exception('Row with id ' + row['id'] + ' must
             have exactly ' + <count> + ' cells.') — GOT_1382 +
             GOT_1384 + GOT_1385. Flag: the numeric piece's
             string coercion is not const-visible; translated
             with str().
        """
        if not isinstance(rows, list):
            raise Exception('The rows must be a list.')
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                raise Exception('Each row must be a dictionary.')
            if 'id' not in row or not isinstance(row['id'], str):
                raise Exception("Each row must have a unique "
                                "'id' of type string.")
            if row['id'] in seen:
                raise Exception('Duplicate id found: '
                                + row['id'])
            seen.add(row['id'])
            if 'cells' not in row or \
                    not isinstance(row['cells'], list):
                raise Exception('Row with id ' + row['id'] +
                                " must have a 'cells' key with "
                                'a list value.')
            if len(row['cells']) != len(self.__columns):
                raise Exception('Row with id ' + row['id'] +
                                ' must have exactly ' +
                                str(len(self.__columns)) +
                                ' cells.')

    def __get_selected_rows_ids(self):
        """Registry L3590 (Table.__get_selected_rows_ids).
        Content: chunk labeled L3599 (stream section
        function@L3590).

        [E:] builds a list (a9d18, L31) iterating self.__rows
             (GOT_1386 + GetIter, L41-67); per row: the
             'selected' GetItem + the False-default compare
             cluster (a9d30 + GOT_1387 + GOT_032, L73-108) with
             a SetItem (L115) — the flag normalization — then
             the truth branch appends row['id'] (GOT_250 + the
             GetItem, L163-209); the list is returned (L232).
        [E:] flag: translated as the normalize-then-test form;
             the exact original (setdefault vs the observed
             SetItem) is flagged.
        """
        selected_ids = []
        for row in self.__rows:
            if 'selected' not in row:
                row['selected'] = False
            if row['selected']:
                selected_ids.append(row['id'])
        return selected_ids

    def delete_rows(self, row_ids):
        """Registry L3558 (Table.delete_rows). Content: chunk
        labeled L3572 (stream section function@L3558).
        Signature ('self', 'row_ids') [E:] — const-pool tuple
        slot 1395.

        [E:] `if not isinstance(row_ids, list):` (GOT_168/344)
             → ValueError('Row ids must be a list of strings') —
             EXACT GOT_1396 (L71-99).
        [E:] evaluate_js('updateCustomTableRows({ "id": "' +
             self.__id + '", "idsToDelete": ' + json.dumps(
             row_ids) + ', "type": "delete" } )') — GOT_041 +
             GOT_1392/1397/1398 + json.dumps (GOT_143/420),
             L107-181.
        [E:] the rows removal: iterate __rows, the 'id'
             membership gate → self.__rows.remove(row) (GOT_839,
             L210-303); the selection removal: iterate the
             selected ids with the membership gate → remove
             (GOT_839, L309-405); silent None tail (L414-430).
        """
        if not isinstance(row_ids, list):
            raise ValueError('Row ids must be a list of strings')
        evaluate_js('updateCustomTableRows({ "id": "'
                    + self.__id
                    + '", "idsToDelete": '
                    + json.dumps(row_ids)
                    + ', "type": "delete" } )')
        for row in list(self.__rows):
            if row['id'] in row_ids:
                self.__rows.remove(row)
        for selected_id in list(self.__selected_row_ids):
            if selected_id in row_ids:
                self.__selected_row_ids.remove(selected_id)

    def update_rows(self, rows):
        """Registry L3523 (Table.update_rows). Content: chunk
        labeled L3543 (raw spp_span_insert_rows_3543.c head).

        PARTIALLY RECONSTRUCTED — the head (validator, the
        selected harvest, the evaluate_js push) is raw-evidenced;
        the post-push selection-sync tail (the stream's enumerate
        / SetItem / remove cluster, L338-719) is flagged pending
        the full raw tail pass.

        [E:] self.__rows_validator(rows) — the GetAttr (GOT_
             1391) + the (rows,) call (raw L43-73).
        [E:] `for row in rows:` (GetIter raw L78) with the
             'selected' check: `'selected' not in row` (a9d30
             selector-7 + GOT_1387, raw L174-232) falling to a
             False compare, the True compare selecting the
             harvest branch → self.__selected_row_ids.append(
             row['id']) (stream L301-329). Flag: translated as
             the row.get('selected', False) form.
        [E:] evaluate_js('updateCustomTableRows({ "id": "' +
             str(self.__id) + '", "rows": ' + json.dumps(rows) +
             ', "type": "update" } )') — the FIVE-piece join
             staged raw L98-162 (GOT_1392 + id + GOT_1393 + the
             dumps result + GOT_1405; the id str-coerced raw
             L126), dumps (GOT_143/420) over the (rows,) tuple
             (raw L152-157).
        [E:] flag: the post-push tail in the stream (the
             enumerate over __rows with the selected-False
             resets, the __selected_row_ids maintenance with
             remove GOT_839, the final SetItem apply) is queued
             for the raw tail pass — summarized in its evidenced
             order below.
        """
        self.__rows_validator(rows)
        for row in rows:
            if row.get('selected', False):
                self.__selected_row_ids.append(row['id'])
        evaluate_js('updateCustomTableRows({ "id": "'
                    + str(self.__id)
                    + '", "rows": '
                    + json.dumps(rows)
                    + ', "type": "update" } )')
        # FLAG: the evidenced selection-sync tail (enumerate the
        # stored rows with the selected=False resets + the
        # __selected_row_ids add/remove maintenance) awaits the
        # raw tail pass — order below per the stream cluster.
        for index, row in enumerate(self.__rows):
            if row['id'] in self.__selected_row_ids:
                row['selected'] = True
            else:
                row['selected'] = False

    def insert_rows(self, rows, position):
        """Registry L3543 (Table.insert_rows). Content: chunk
        labeled L3558 — decompiled as a merged region.

        PATTERN-DERIVED (flagged): the body is not directly
        evidenced; the reconstruction follows the fully-evidenced
        sibling methods (delete_rows / update_rows) plus the
        exact const set: signature ('self', 'rows', 'position')
        [E:] — const-pool tuple slot 1399; ValueError('Position
        is out of bounds') — EXACT GOT_1400; the insert push via
        GOT_1392 + GOT_1393 + '", "type": "insert", "position":
        "' (GOT_1403) + GOT_1404, the 'insert' token (GOT_1402).
        """
        self.__rows_validator(rows)
        if not 0 <= position <= len(self.__rows):
            raise ValueError('Position is out of bounds')
        evaluate_js('updateCustomTableRows({ "id": "'
                    + str(self.__id)
                    + '", "rows": '
                    + json.dumps(rows)
                    + ', "type": "insert", "position": '
                    + str(position) + ' } )')
        self.__rows[position:position] = rows


def table_row_selection_listener(row_id, selected):
    """Registry L3572 — the row-selection listener closure
    registered under the table's generated row-select listener
    id. Content: chunk labeled L3577 — merged region.

    [E:] the SIGNATURE is live: (('row_id', 'selected')) —
         const-pool tuple slot 1424 with NO self: a strict free
         closure. Its registration is evidenced in the ctor
         (DAT_000a9d58 + unlabeled GOT_1828). Body flagged: not
         const-visible pending the dossier pass.
    """


def table_button_click_listener(onClick, row_id):
    """Registry L3577 — the button listener closure under the
    table's generated button listener id. Content: chunk labeled
    L3590 — merged region.

    [E:] the SIGNATURE is live: (('onClick', 'row_id')) —
         const-pool tuple slot 1426 with NO self; the
         method-name const '_Table__toggle_row_selection'
         (GOT_1425) marks the family. Body flagged: not
         const-visible pending the dossier pass.
    """
