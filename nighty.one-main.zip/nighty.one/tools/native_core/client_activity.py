"""
client_activity.py — Nighty's client-analytics persistence pair from
the SPP native core (/misc/client_analytics.json), with evidence
chains.
"""

import json


def getClientActivity():
    """Registry L534. Content: chunk labeled L538.

    [E:] no signature tuple (0 args).
    [E:] open(getDataPath() + '/misc/client_analytics.json', 'r') —
         the concat and the exact filename const are both visible in
         the dossier disasm (0x2e27-0x2e5d: the string-add op then the
         (1, 2, path, '/') open call) — + json.load inside a real try
         (Fetch at event 31). No encoding kwargs on this reader.
    [E:] the except return value is dispatcher-built (no const in the
         stream); {} by the analytics-dict usage — inferred, flagged.
    """
    try:
        with open(getDataPath() + '/misc/client_analytics.json',
                  'r') as f:
            return json.load(f)
    except Exception:
        return {}


def saveClientActivity(data):
    """Registry L538. Content: chunk labeled L545.

    [E:] signature tuple ('data',).
    [E:] open(getDataPath() + '/misc/client_analytics.json', 'w') +
         json.dump(data, f, indent=2) (events 7-30); the filename const
         and getDataPath staged like the reader; PyErr_Fetch after the
         dump = a real try around the write; handler silent (no
         logging consts). No encoding kwargs (plain 'w').
    """
    try:
        with open(getDataPath() + '/misc/client_analytics.json',
                  'w') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass
