"""
token_wrappers.py — the account-token sync wrappers from the
SPP native core (registry L7992-L8005), recovered from the
corpus event streams plus island dumps. Both are thin
synchronous bridges over module-level AsyncIO helpers:

  getAppID(token)        — asyncio.run(get_app_id(token))
  isAccountValid(token)  — asyncio.run(is_account_valid(token))

The wrapped async helpers (get_app_id / is_account_valid
globals, CONST[731]/CONST[730]) live elsewhere in the module
(the async family); their spans are tracked separately in the
registry.
"""

import asyncio  # noqa: F401  (the module global family import parity)


def getAppID(token):
    """Registry L7992. Content: chunk L8005 — recovered from the
    island bytes of chunk 8005 (dump file
    chunk8005_getAppID_L7992.txt, per the dumper +0 align, 20
    events, 124 insns, read complete through the
    isAccountValid@L8005 prologue at 0x77db0), cross-checked
    against the complete stream section (function@L7992,
    corpus lines 21211-21227, read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[129]
        ('token',) staged 0x77c19 with the GOT_000 binder
        (r8d=1) at 0x77c45.
    [E:] THE RUNNER — the 'asyncio' CONST[393] loaded as a
        name through the a9d50 stage (0x77c72-0x77c80,
        r8d=1), the GetAttr over it with the 'run' CONST[69]
        (staged 0x77c92, resolved 0x77cab) binding rsi —
        asyncio.run; corpus events 30-43.
    [E:] THE HELPER — the 'get_app_id' CONST[731] loaded as
        a module global through the a9d50 stage
        0x77ce6-0x77cfa binding rdi. CORPUS GAP: the
        section's event list (21211-21227) was generated
        before slot 731 had a corpus-side label, so the
        helper name is island-only in the citations — the
        live const pool carries it (slot 731, repr
        'get_app_id') and the corpus's a9d50 event at 55
        is its unlabeled counterpart; corpus events 48-58.
    [E:] THE CALL — the kind-1 [token] wrap at 0x77d28
        (r8 = the [rsp+0x58] parameter), the a9d20 call at
        0x77d46 (r8d=1) producing the coroutine, the kind-1
        re-wrap at 0x77d53, and the outer call through the
        a9d20 with rdx = the asyncio.run bound method
        (0x77d75, r8d=1) — asyncio.run(get_app_id(token))
        — returned through the ret-disp (a9d28) at
        0x77d90; corpus events 55-72.
    """
    return asyncio.run(get_app_id(token))


def isAccountValid(token):
    """Registry L8005. Content: chunk L8008 — recovered from the
    island bytes of chunk 8008 (dump file
    chunk8008_isAccountValid_L8005.txt, per the dumper +0
    align, 20 events, 124 insns, read complete through the
    get_theme_path@L8008 prologue at 0x77f90), cross-checked
    against the complete stream section (function@L8005,
    corpus lines 21228-21247, read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[129]
        ('token',) staged 0x77df9 with the GOT_000 binder
        (r8d=1) at 0x77e25.
    [E:] THE RUNNER — the 'asyncio' CONST[393] a9d50 name
        load (0x77e52-0x77e60) with the 'run' CONST[69]
        GetAttr (staged 0x77e72, resolved 0x77e8b) —
        asyncio.run; corpus events 28-41.
    [E:] THE HELPER — the 'is_account_valid' CONST[730]
        loaded as a module global at 0x77ec6-0x77eda —
        corpus events 45-53 (the corpus labels this slot
        live: GOT_730_str__is_account_valid_).
    [E:] THE CALL — the kind-1 [token] wrap 0x77f0a, the
        helper call at 0x77f26 (r8d=1), the kind-1 re-wrap
        0x77f36, the asyncio.run call at 0x77f55 —
        asyncio.run(is_account_valid(token)) — returned
        via the ret-disp (a9d28) at 0x77f70; corpus events
        56-70.
    """
    return asyncio.run(is_account_valid(token))


def getCreatedApp(url):
    """Registry L8352. Content: chunk L8360 — recovered from the
    island bytes of chunk 8360 (dump file
    chunk8360_getCreatedApp_L8352.txt, per the dumper +0 align,
    32 events, 200 insns, read complete through the check_app_id
    prologue), cross-checked against the complete stream section
    (function@L8352, corpus lines 22160-22195, read complete).
    The developer-portal app-ID extractor for the URL the
    watcher reports.

    [E:] THE SIGNATURE — the names-tuple CONST[679] ('url',)
        staged 0x7f43e with the GOT_000 binder (r8d=1) at
        0x7f46a.
    [E:] THE PATTERN — the live CONST[680]
        '^https:\\/\\/discord\\.com\\/developers\\/'
        'applications\\/(\\d+)\\/information\\/?$' (the JS-style
        escaped slashes array-quoted in the pool) staged
        0x7f478 binding [rsp+0x60].
    [E:] THE MATCH — the re global (CONST[228]) name-loaded
        0x7f4b7-0x7f4c5 with GetAttr 'match' (CONST[681])
        resolved 0x7f4f4; the kind-1 two-item build over the
        [rsp+0x60] pattern and the [rsp+0x58] url (0x7f534-
        0x7f53e) and the call 0x7f55e binding [rsp+0x68] —
        re.match(pattern, url); corpus events 28-60.
    [E:] THE GATE — the IsTrue over the match at 0x7f58d: the
        FALSY side releases and materializes the CONST[30] None
        staged 0x7f5b1 with the carry flag clear (the explicit
        `return None` through the 0x7f5ec exit); the TRUTHY side
        runs GetAttr 'group' (CONST[232], resolved 0x7f655) with
        the CONST[233] int-1 kind-1 wrap and the call —
        `return match.group(1)`; corpus events 77-140.
    """
    match = re.match(
        '^https:\\/\\/discord\\.com\\/developers\\/'
        'applications\\/(\\d+)\\/information\\/?$', url)
    if match:
        return match.group(1)
    return None


def check_app_id(app_id):
    """Registry L8360. Content: chunk L8374 — recovered from the
    island bytes of chunk 8374 (dump file
    chunk8374_check_app_id_L8360.txt, per the dumper +1 align,
    83 events, 431 insns, read complete through the __init__
    prologue), cross-checked against the complete stream section
    (function@L8360, corpus lines 22196-22285, read complete).
    The app-ID liveness probe the watcher tier uses before
    trusting a created app.

    [E:] THE SIGNATURE — the names-tuple CONST[675]
        ('app_id',) staged 0x7f737 with the GOT_000 binder
        (r8d=1) at 0x7f763.
    [E:] THE LOG — logging.info('Making app id check...') (the
        logging CONST[44] name load and 'info' CONST[51]
        GetAttr 0x7f7aa-0x7f7d6, the live CONST[676] message
        staged 0x7f7e9); corpus events 38-62.
    [E:] THE PROBE — requests (CONST[130]) .get (CONST[47]
        GetAttr 0x7f872), the two-piece f-string through the
        a9d48 builder over the live CONST[572]
        'https://discord.com/api/v9/applications/' (staged
        0x7f8b8) and the [rsp+0x60] app_id format piece —
        f'https://discord.com/api/v9/applications/{app_id}' —
        with the kwargs-kind-3 {'headers': getBasicHeaders()
        (CONST[677] global 0x7f925), 'timeout': CONST[199] 15}
        (0x7f96e-0x7f97c); corpus events 72-129.
    [E:] THE GUARD — the try body wraps the whole probe: the
        DAT_a9d40 fetch with the CONST[77] 'Exception' match
        staged 0x7fa21 (the sel-0xa law).
    [E:] THE GATE — GetAttr 'status_code' (CONST[141] staged
        0x7fa5a) with the a9d30 sel-2 equality over CONST[142]
        200 (staged 0x7fa97) — `if r.status_code == 200:` — the
        truthy arm returning the CONST[31] True staged 0x7fbc2,
        the falsy side releasing through the False
        materializations 0x7fad2/0x7fb0f —
        `return True` / `return False`; corpus events 216-264.
    [E:] THE EXCEPT — logging.error (the 'error' CONST[45]
        GetAttr 0x7fbe9) over the f-string pairing the live
        CONST[678] 'check_app_id: ' staged 0x7fc2f with the
        caught exception (the as-binding name is slot-inferred
        and flagged per the rename-loop convention) —
        `logging.error(f'check_app_id: {e}')` — then the
        CONST[32] False return staged 0x7fcb2; corpus events
        160-210.
    """
    try:
        logging.info('Making app id check...')
        r = requests.get(
            f'https://discord.com/api/v9/applications/{app_id}',
            headers=getBasicHeaders(),
            timeout=15)
        if r.status_code == 200:
            return True
        return False
    except Exception as e:
        logging.error(f'check_app_id: {e}')
        return False


def getAppToken(self, input_value):
    """Registry L8508. Content: chunk L8518 — recovered from the
    island bytes of chunk 8518 (dump file
    chunk8518_getAppToken_L8508.txt, per the dumper +1 align,
    82 events, 414 insns, read complete), cross-checked against
    the complete stream section (function@L8508, corpus lines
    22611-22694, read complete). The pywebview paste-token
    bridge: the PASTE TOKEN HERE watchdog hands the pasted
    value here, it lands in the login's app table, and the
    process relaunches.

    [E:] THE SIGNATURE — the names-tuple CONST[613]
        ('self', 'input_value') staged 0x81c97 with the
        GOT_000 binder (r8d=2) at 0x81cc3.
    [E:] THE SPLASH — main_ui.load_url('https://nighty.one/'
        'download/files/ui/loading.html'): the 'main_ui'
        CONST[40] global name load 0x81cd8-0x81cf7 with
        GetAttr 'load_url' (CONST[500], 0x81d0a) and the live
        CONST[655] one-positional call staged 0x81d49;
        corpus events 39-65.
    [E:] THE STORE — the walk: getConfigData() (CONST[145]
        name load 0x81d9f-0x81dd1, zero-arg) with
        ['logins'] (CONST[146], GetItems 0x81e10-0x81e39),
        [getActiveProfileName()] (CONST[425] global, zero-arg)
        and ['app'] (CONST[574] staged 0x81ee0, GetItem
        0x81ef9) binding the app dict; the SetItem at 0x81f4b
        with rdx = 'token' CONST[147] staged 0x81f18 and
        r8 = the [rsp+0x70] binder slot — the input_value —
        config['logins'][getActiveProfileName()]['app']
        ['token'] = input_value; corpus events 73-153.
    [E:] THE SAVE — saveConfigData (CONST[155] stage 0x81f79,
        the kind-1 [config] wrap and call) persisting the
        walk's container; corpus events 157-168.
    [E:] THE RELAUNCH — os (CONST[34] name load 0x820a4)
        .execv (CONST[123] GetAttr 0x820d6) over
        sys.executable (the sys CONST[79] load 0x8211e,
        GetAttr 'executable' CONST[124] 0x82150) and the
        kind-1 list ['python' (CONST[125] staged 0x82197)] +
        (the DAT_a9d10 concat selector 0x82180+)
        sys.argv (CONST[80] GetAttr 0x821e9) —
        os.execv(sys.executable, ['python'] + sys.argv);
        corpus events 177-255.
    """
    main_ui.load_url('https://nighty.one/download/files/ui/'
                     'loading.html')
    config = getConfigData()
    config['logins'][getActiveProfileName()]['app'][
        'token'] = input_value
    saveConfigData(config)
    os.execv(sys.executable, ['python'] + sys.argv)


def is_discord_bot_token_valid(token):
    """Registry L8518. Content: chunk L8531 — recovered from the
    island bytes of chunk 8531 (dump file
    chunk8531_is_discord_bot_token_valid_L8518.txt, per the
    dumper +0 align, 81 events, 418 insns, read complete),
    cross-checked against the complete stream section
    (function@L8518, corpus lines 22695-22783, read complete).
    The bot-token validator with the Bot-prefixed
    Authorization header.

    [E:] THE SIGNATURE — the names-tuple CONST[129] ('token',)
        with the GOT_000 binder (r8d=1).
    [E:] THE PROBE — requests.get (CONST[130]/CONST[47]) over
        the live CONST[131]
        'https://discord.com/api/v10/users/@me', the
        kwargs-kind-3 {'headers': {'Authorization': the
        two-piece f-string (a9d48 pair over the live
        CONST[654] 'Bot ' and the token format piece)}},
        verify=False (CONST[138]/False), timeout=15
        (CONST[139]/CONST[199]);
        corpus events 37-124.
    [E:] THE GATE — GetAttr 'status_code' (CONST[141]) with
        the a9d30 sel-2 equality against CONST[142] 200 —
        `if r.status_code == 200: return True` (the
        CONST[31] True) `return False` (the CONST[32]
        Falses 176/262); corpus events 132-180.
    [E:] THE EXCEPT — the DAT_a9d40 fetch with the specific
        match: requests.RequestException (the requests name
        and CONST[653] GetAttr, corpus events 189-210) —
        logging.error (CONST[45]) over the two-piece
        f-string (CONST[652] 'Error checking token: ' with
        the caught exception, the as-binding name
        slot-inferred and flagged) — `return False`;
        corpus events 216-264.
    """
    try:
        r = requests.get(
            'https://discord.com/api/v10/users/@me',
            headers={'Authorization': f'Bot {token}'},
            verify=False,
            timeout=15)
        if r.status_code == 200:
            return True
        return False
    except requests.RequestException as e:
        logging.error(f'Error checking token: {e}')
        return False


def is_discord_token_valid(token):
    """Registry L8531. Content: chunk L8545 — recovered from the
    corpus event stream section (function@L8531, corpus lines
    22784-22878, read complete; the chunk 8545 island dump
    queues with this registry wave). The user-token validator
    sibling: the bare Authorization with the full client
    header set, the same v10 probe and gates.

    [E:] THE SIGNATURE — the names-tuple CONST[129] ('token',)
        with the GOT_000 binder at the corpus event 31.
    [E:] THE PROBE — requests.get (CONST[130]/CONST[47]) over
        the same live CONST[131] endpoint, the
        kwargs-kind-3 {'headers': {'Authorization': the
        token DIRECT (no Bot prefix — no a9d48 build and no
        CONST[654] in this section, the defining difference
        against is_discord_bot_token_valid@L8518),
        'Content-Type': CONST[136] 'application/json',
        'User-Agent': the live client UA CONST[137] (the
        kind-3 three-pair frame, corpus events 44-64)},
        verify=False, timeout=15; corpus events 33-117.
    [E:] THE GATE — the sel-2 equality over the status_code
        against 200 — return True / return False (the True
        at corpus event 173); corpus events 125-173.
    [E:] THE EXCEPT — requests.RequestException (consts
        130/653) with logging.error over the CONST[652]
        f-string — return False (the triple at 255-257),
        GOT_002 tail at 266; corpus events 182-266.
    """
    try:
        r = requests.get(
            'https://discord.com/api/v10/users/@me',
            headers={
                'Authorization': token,
                'Content-Type': 'application/json',
                'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; '
                               'WOW64) AppleWebKit/537.36 '
                               '(KHTML, like Gecko) '
                               'discord/1.0.9001 '
                               'Chrome/83.0.4103.122 '
                               'Electron/9.3.5 Safari/537.36')},
            verify=False,
            timeout=15)
        if r.status_code == 200:
            return True
        return False
    except requests.RequestException as e:
        logging.error(f'Error checking token: {e}')
        return False
