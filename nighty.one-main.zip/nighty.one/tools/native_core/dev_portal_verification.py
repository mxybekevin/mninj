"""
dev_portal_verification.py — SUPERSEDED (a pointer module).

The dev-portal MFA completion pair recovered here in the corpus
era (verifyDevPortalPass@L8723 and verifyDevPortalMfa@L8776)
first shipped as drafts carrying five unverified guesses. Both
bodies are WebVersionApi members and now ship complete in
native_core/web_settings_window.py with the island-locked
corrections:

  — the app_manager() factory call: self is never read; every
    .session read walks the instance product
  — the f'\\n{data}\\n' sys.stdout writes carry the WHOLE
    payload, before the data['token'] extraction
  — the cookie value = the mfa-finish token over the
    '__Secure-recent_mfa=' const, not a register-held variant
  — the reset route is the three-piece f-string head + app_id
    + '/bot/reset', not str(...) joins
  — NO webview.start() in either span; the matched except arm
    swallows via logging.error(e) and only the unmatched arm
    escapes through GOT_002

The draft bodies that lived here encoded the opposites of all
five (mfa_cookie = None, events.loaded = None, the re-raise,
webview.start(), str(app_id), self.session) — this module now
contributes no function bodies to the merged assembly and is
kept only to record the supersession.

The MFA twin's full island record: chunk 8829 (dump file
chunk8829_verifyDevPortalMfa_8776.txt — read complete) with its
totp deltas: the names-tuple CONST[557] ('self', 'mfa_code')
staged 0x8abc8; the 'app_manager' CONST[558] name-load with the
zero-arg call; 'totp' CONST[569] staged 0x8b0d0; the cookie
const staged 0x8b4c0; the reset-url pieces staged 0x8b5f7 /
0x8b62b; the 484-byte watcher snippet CONST[576] staged
0x8bd10 (byte-identical to the pass variant's CONST[580]
copy); 'Authorize Nighty' CONST[577] staged 0x8bdef; the login
url CONST[115] staged 0x8be3f; the relaunch sizes 1075
CONST[117] staged 0x8be7b / 670 CONST[119] staged 0x8be99; the
events/loaded INPLACE adds staged 0x8c151-0x8c276; the
exception match CONST[77] staged 0x8c310 with the GOT_002
escape at 0x8c4b3.
"""
