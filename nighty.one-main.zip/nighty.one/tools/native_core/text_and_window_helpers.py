"""
text_and_window_helpers.py — the Qt text pipeline + window /
license-page helpers (registry L3985-L4580), recovered via the
Ghidra decomp lane.

  truncate_string          — sig ('text', 'max_length') + '...'
  update_text              — store + re-emit the wrapped text
  break_text_into_lines    — the QFontMetrics pixel-width wrapper
  requestAppToken          — load the app-authorize UI page
  close_application        — main_api.close()
  toggleNightyDiscoverable — config flip + the /v2/discoverable
                              POST with the 50-retry session
"""

import platform

import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry


def truncate_string(text, max_length):
    """Registry L3985 (module-level). Content: chunk labeled 3990
    (stream section function@L3985). Signature ('text',
    'max_length') [E:] — const-pool tuple slot 1247 (LIVE).

    [E:] the bounds branch: len-cluster + IsTrue gates
         (L36-40, L111-119) — `if len(text) <= max_length:
         return text`.
    [E:] the truncate branch: the slice over text with the
         DAT_000a9d10 arithmetic and PySlice_New + int 3
         (GOT_1033, L55-66) + the '...' suffix (GOT_270,
         L76-78) — `return text[:max_length - 3] + '...'`.
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + '...'


def update_text(self, text):
    """Registry L4029 (module-level helper — the Qt widget text
    refresher). Content: chunk labeled L4034 (stream section
    function@L4029).

    [E:] self.original_text = text — 'original_text' (GOT_1230)
         staged for the SetAttr at L35-64; the break_text_into_
         lines global (GOT_1238) staged L69-87; setText
         (GOT_1239) GetAttr L100-117 with the build at L121 and
         the dispatched return at L136.
    [E:] flag (partial): the attribute targets (the original_text
         and setText receivers — same-object assumption) are
         flagged pending the raw pass (the chunk's decomp file
         carries the body).
    """
    self.original_text = text
    self.setText(break_text_into_lines(self))


def break_text_into_lines(self):
    """Registry L4034 (module-level — the QFontMetrics wrapper).
    Content: chunk labeled L4513 (raw spp_span_requestAppToken_
    4513.c — the whole body is raw-decoded).

    [E:] font_metrics = QtGui.QFontMetrics(self.font()) —
         QtGui (GOT_1227) + QFontMetrics (GOT_1228) + the self
         (in_stack 0x58) font GetAttr (GOT_1229) + the 0-arg
         call raw L80-82, L34-82.
    [E:] lines = [] (the a9d18 (2,0) empty-list build, raw
         L91-93); current_line = '' (GOT_241, raw L99-106).
    [E:] the loop: iterate over self.original_text (the
         original_text GetAttr raw L107-127 + GetIter raw L128 +
         a9d60 next raw L130-131): per item the compare
         font_metrics.horizontalAdvance(current_line + item)
         vs self.max_width — horizontalAdvance (GOT_1231) + the
         DAT_000a9d10 add op (selector 7, raw L169-170) + the
         (1,1) build + max_width GetAttr (GOT_1232, raw
         L173-189) + the a9d30 compare (selector 1, raw L192);
         TRUE branch (IsTrue raw L198-220): current_line =
         current_line + item (the DAT_000a9d10 op 0xe — the
         BINARY-ADD, raw L212-218); FALSE branch (raw L221-254):
         lines.append(current_line) (GOT_250, raw L222-246) and
         current_line = <the item> (raw L250-251).
    [E:] the tail: after the iterator empties, if current_line:
         lines.append(current_line) (IsTrue raw L259-265 +
         append raw L266-298); then '<br>' (GOT_1233) joined via
         str.join (GOT_166) and wrapped: '<div style="line-
         height:' (GOT_1234) + self.line_height (GOT_1235) +
         the closing (GOT_1236) + '</div>' (GOT_1237) — a9d48
         joins L336-373.
    [E:] flag: the iterand element type (chars vs pre-split
         words) is not const-visible — the accumulation idiom
         reads item-wise.
    """
    font_metrics = QtGui.QFontMetrics(self.font())
    lines = []
    current_line = ''
    for item in self.original_text:
        if (font_metrics.horizontalAdvance
                (current_line + item) < self.max_width):
            current_line = current_line + item
        else:
            lines.append(current_line)
            current_line = item
    if current_line:
        lines.append(current_line)
    return ('<div style="line-height:' + self.line_height
            + ';">' + '<br>'.join(lines) + '</div>')


def requestAppToken():
    """Registry L4513 (module-level). Content: chunk labeled
    L4548 (stream section function@L4513). Zero-argument (the
    section opens directly on the main_ui loads).

    [E:] main_ui.load_url(url=<GOT_1226>) — main_ui (GOT_040) +
         load_url (GOT_500) + the 'url' kwarg key (GOT_114) with
         the EXACT page const GOT_1226 =
         'https://nighty.one/download/files/ui/app_token.html'
         (L12-42); silent None tail.
    """
    main_ui.load_url(
        url='https://nighty.one/download/files/ui/app_token.html')


def close_application():
    """Registry L4570 (module-level). Content: chunk labeled
    L4580 (stream section function@L4570). Zero-argument.

    [E:] main_api.close() — main_api (GOT_038) + 'close'
         (GOT_603, L30-36); silent None tail.
    """
    main_api.close()


def toggleNightyDiscoverable():
    """Registry L4580 (module-level). Content: chunk labeled
    L4599 (stream section function@L4580). Zero-argument.

    PARTIALLY RECONSTRUCTED — the session build, endpoint and
    payload are fully evidenced; the exact response analysis and
    failure-surface verbs are flagged pending the raw pass
    (spp_span_getScriptCodeData_4599.c).

    [E:] config = getConfigData() (GOT_145, L51-62);
         config['nighty_discoverable'] toggled — the key const
         GOT_1220 with PyObject_SetItem (L73-96) — translated as
         the not-inversion (the flag-carrying cluster);
         saveConfigData(config) (GOT_155, L100-111).
    [E:] session = requests.Session() — requests (GOT_130) +
         Session (GOT_585); session.mount('https://',
         HTTPAdapter(max_retries=Retry(total=50,
         status_forcelist=[429, 500, 503, 504],
         backoff_factor=5))) — mount (GOT_586) + 'https://'
         (GOT_587) + HTTPAdapter (GOT_588) + max_retries
         (GOT_589) + Retry (GOT_590) + total (GOT_591) + int 50
         (GOT_592!) + status_forcelist (GOT_593) + ints 429
         (GOT_594) / 500 (GOT_522) / 503 (GOT_595) / 504
         (GOT_596) + backoff_factor (GOT_597) + int 5
         (GOT_598), L120-239.
    [E:] the POST: session.post(SERVER_TO_USE + '/v2/discoverable',
         json={'state': <?flagged>, 'user_id': str(bot.user.id),
         'key': str(encryptRSA(getLicense()))}, verify=False) —
         SERVER_TO_USE (GOT_501) + '/v2/discoverable' (GOT_1221)
         + 'state' (GOT_983) + 'user_id' (GOT_1166) + bot.user.id
         (GOT_244/388/265) + 'key' (GOT_299) + encryptRSA
         (GOT_503) + getLicense (GOT_504) + verify (GOT_138) +
         False (GOT_032), L251-395 (the branch-repeated staging
         L415-561 = the retry/exception path per the DAT_000a9d40
         pair + the re-raise GOT_002 at L579).
    [E:] session.close() — 'close' (GOT_603), L590-607; then
         response.status_code compared to 200 (GOT_141/142,
         L616-650); response.json() (GOT_143) + .get chains
         (GOT_047) over 'status' (GOT_159) with the failure
         message 'Failed to change nighty discoverable...'
         (GOT_1222) + the 'success' (GOT_520) / 'message'
         (GOT_048) keys, L653-821 — flag: the exact success/
         failure reads (showToast vs logging.error) pending raw.
    """
    config = getConfigData()
    config['nighty_discoverable'] = \
        not config['nighty_discoverable']
    saveConfigData(config)
    session = requests.Session()
    session.mount('https://',
                  HTTPAdapter(max_retries=Retry(
                      total=50,
                      status_forcelist=[429, 500, 503, 504],
                      backoff_factor=5)))
    response = session.post(
        SERVER_TO_USE + '/v2/discoverable',
        json={'state': config['nighty_discoverable'],
              'user_id': str(bot.user.id),
              'key': str(encryptRSA(getLicense()))},
        verify=False)
    session.close()
    data = response.json()
    if response.status_code != 200 or not data.get('success',
                                                  False):
        showToast('Failed to change nighty discoverable.'
                  + ' ' + str(data.get('message')))


def getOS():
    """Registry L4000. Content: chunk labeled L4029 — recovered
    from the interior bytes of chunk 4029 (dump file
    chunk4029_getOS_L4000.txt; the earlier 'dead stub span'
    verdict was a boundary artifact — the chunk decodes at
    alignment +0, 62 events).

    [E:] platform module staged (GOT_1240 'platform') ->
         GetAttr 'system' (GOT_694) called zero-arg (0x41f7d)
         -> platform.system(); staged again -> GetAttr
         'version' (GOT_1024) called zero-arg (0x4202a) ->
         platform.version().
    [E:] compare SUBGOT_a9d30 selector 2 (the established ==
         selector) of the system value against 'Windows'
         (GOT_458) at 0x42078, IsTrue-normalized.
    [E:] not-Windows path: str-convert stages (SUBGOT_a9d48
         (0, X, 0xffffffff, 0)) on both values then the
         3-piece join with ' ' (GOT_243): returns
         f'{platform.system()} {platform.version()}'
         (0x420d4-0x4213f).
    [E:] Windows path: int staged (GOT_372); the version.Slice:
         GetAttr 'split' (GOT_364) on platform.version() called
         with '.' (GOT_808) -> .split('.'); PyObject_GetItem
         index 2 (GOT_478) -> the build number component; int()
         of it (0x42295); compare SUBGOT_a9d30 selector-5
         against int 22000 (GOT_1241) at 0x422ac — translated
         as >= (selector 2 is ==, 4 is the > family; flagged);
         True -> 'Windows 11' (GOT_1242, 0x4237x), False ->
         'Windows 10' (GOT_1243, 0x42309) — both returned via
         the SUBGOT_a9d48 1-piece stage.
    """
    if platform.system() == 'Windows':
        if int(platform.version().split('.')[2]) >= 22000:
            return 'Windows 11'
        return 'Windows 10'
    return f'{platform.system()} {platform.version()}'
