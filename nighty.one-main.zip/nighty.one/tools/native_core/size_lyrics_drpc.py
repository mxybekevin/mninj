"""
size_lyrics_drpc.py — the sticker lookup, size formatter,
lyric-progress parser, and the DRPC (rich presence) value
family from the SPP native core (registry L6265-L6559 +
addDRPCValue@L6491), recovered from the corpus event streams
plus the stream stubs and island dumps (all signatures below
are LIVE).

  findSticker(name)                          — guild sticker scan
  getSize(bytes, suffix)                     — the 1024-units walk
  getLyricFromProgress(lyrics_str, progress_ms) — the [mm:ss.ms]
                                               lyric picker
  getDiscoverablesCount()                    — zero-arg counter
  getOnlineNightyUsers()                     — zero-arg counter
  getOnlineDiscoverablesCount()              — the nightyOnline tally
  getDRPCValues()                            — the live values dict
  addDRPCValue(w, create)                    — the closure writer
  processDThemeData(theme_data, values)      — the DTheme template
                                               placeholder processor
  processDRPCData(rpc_data, values)         — the RPC payload
                                               universal sweeper
                                               (assets, timestamps,
                                               buttons, party)
"""

import re


def findSticker(name):
    """Registry L6265. Content: chunk labeled L6271 — recovered
    from the interior bytes of chunk 6271 (dump file
    chunk6271_findSticker_L6265.txt; the 'file merged/absent'
    verdict was a boundary artifact — the chunk decodes at
    alignment +1, 48 events). Signature ('name',) [E:] —
    const-pool tuple slot 838 (LIVE).

    [E:] the bot global staged (GOT_244, 0x588d1) -> bot.
         guilds ('guilds' GOT_1022, 0x58903) with GetIter
         (slot 27, 0x5894c) + the SUBGOT_a9d60 guild loop
         (back-edge 0x58978).
    [E:] per guild: guild.stickers — 'stickers' (GOT_1039,
         0x589af-0x58af) with GetIter (0x58a0c) + the inner
         SUBGOT_a9d60 sticker loop (0x58a4f).
    [E:] sticker.name — 'name' GetAttr (GOT_273, 0x58a8a-0x
         58aa0); the a9d30 selector-2 equality (edx=2, 0x58b08)
         against the `name` parameter with the double-IsTrue
         normalization (0x58b1d-0x58b3f) — the invert reads
         `if sticker.name == name:`.
    [E:] the match returns the sticker through the found-flag
         (r12d=2 at 0x58c2d with the incref); exhaustion -> the
         PyErr-checked None tail (0x58bdd + ret-dispatch).
    """
    for guild in bot.guilds:
        for sticker in guild.stickers:
            if sticker.name == name:
                return sticker
    return None


def getSize(bytes, suffix):
    """Registry L6271. Content: chunk labeled L6360 (stream
    section function@L6271). Signature ('bytes', 'suffix')
    [E:] — const-pool tuple slot 1036 (LIVE).

    [E:] the units tuple ('', 'K', 'M', 'G', 'T', 'P') — the
         kind-1 tuple build (event 46) over the staged '' (GOT_
         241, event 45), 'K' (GOT_756), 'M' (GOT_760), 'G'
         (GOT_748), 'T' (GOT_774), 'P' (GOT_766, events 50-65)
         with GetIter (event 68) + the SUBGOT_a9d60 loop (73).
    [E:] the threshold compare (SUBGOT_a9d30, event 85) against
         int 1024 (GOT_1037, events 34-40) with IsTruth
         normalization (events 95-103).
    [E:] the format branch: four SUBGOT_a9d48 chains (events
         111-126) with the '.2f' format const (GOT_1038, events
         116-117): f'{bytes:.2f}{unit}{suffix}'.
    [E:] the else arm is the SUBGOT_a9d10 binary op (event 105):
         bytes divided by 1024 (power-of-two shift family,
         selector-mapped) — translated as bytes /= 1024.
    [E:] flag: the post-loop tail (events 153-167, PyErr clear
         + ret-dispatch + None) does not surface a final
         format; translated as a final re-format — flagged.
    """
    for unit in ('', 'K', 'M', 'G', 'T', 'P'):
        if bytes < 1024:
            return f'{bytes:.2f}{unit}{suffix}'
        bytes /= 1024
    return f'{bytes:.2f}{suffix}'


def getLyricFromProgress(lyrics_str, progress_ms):
    """Registry L6360. Content: chunk labeled L6491 (stream
    section function@L6360). Signature ('lyrics_str',
    'progress_ms') [E:] — const-pool tuple slot 1031 (LIVE).

    [E:] lyric = None pre-init (the None cluster, events
         94-96 sits before the GetIter).
    [E:] for line in lyrics_str.split('\\n') — 'split' (GOT_
         364, events 53-75) with the '\\n' const (GOT_239,
         events 79-81); GetIter (event 104) + the SUBGOT_a9d60
         loop (event 107, back-edge 470).
    [E:] m = re.match(r'\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})\\]
         (.*)', line) — the `re` global (GOT_228, events
         117-124), 'match' (GOT_681, events 127-133), the
         EXACT regex GOT_1032; the IsTruth gate (event 154).
    [E:] the millisecond build — int (GOT_372) over match
         .group(1) (GOT_232 + int 1 GOT_233, events 170-194),
         the a9d10 multiplies by 60 (GOT_1035) and 1000
         (GOT_582, events 378-398); group(2) with int 2 (GOT_
         478, events 243-245) and the further *1000 chain;
         group(3) with int 3 (GOT_1033, events 290-292) then
         .ljust(3, '0') ('ljust' GOT_1034 + the '0' GOT_806,
         events 296-314).
    [E:] the gate uses TWO a9d30 compares (events 411 + 417)
         with IsTrue — the compiled <= decomposition —
         translated `if ms <= progress_ms:`.
    [E:] the keeper: match.group(4).strip() — int 4 (GOT_835,
         event 349) + 'strip' (GOT_099, events 354-357);
         silent None / ret-dispatch tail (events 504-513).
    """
    lyric = None
    for line in lyrics_str.split('\n'):
        m = re.match(r'\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)',
                     line)
        if m:
            ms = (int(m.group(1)) * 60 * 1000
                  + int(m.group(2)) * 1000
                  + int(m.group(3).ljust(3, '0')))
            if ms <= progress_ms:
                lyric = m.group(4).strip()
    return lyric


def getDiscoverablesCount():
    """Registry L6508 (module-level, zero-arg — stub argcount=0
    varnames=<module>). Content: chunk labeled L6513 (stream
    section function@L6508).

    [E:] bot.config chain (GOT_244/245, events 20-36) with the
         .get method (GOT_047, events 40-46) and the
         'discoverables' key (GOT_1025, events 50-52) + IsTrue
         (event 57).
    [E:] the len/str staging: str staged twice (GOT_150, events
         63-66 and 79-83) around an int-0 pair (GOT_277, events
         71-72) with len (GOT_267, events 86-94).
    [E:] the tail re-reads bot.config['discoverables'] via
         GetItem (event 123) before the ret-dispatch (137).
    [E:] FLAG (partial): the exact wiring of the two str
         stagings + the int-0 default against the counter
         reads is not resolvable from the event order alone —
         translated as the count-string form below.
    """
    discoverables = bot.config.get('discoverables', 0)
    if discoverables:
        return str(len(discoverables)) + str(0)
    return str(0)


def getOnlineNightyUsers():
    """Registry L6513 (module-level, zero-arg). Content: chunk
    labeled L6518 (stream section function@L6513).

    [E:] the bot.config .get chain (GOT_244/245/047, events
         18-43) with a register-held key (not const-visible —
         the pack interior is invisible to the rip-window
         annotator — FLAGGED), IsTrue gate (event 54).
    [E:] str staged (GOT_150, events 60-64) with the int-0
         pair (GOT_277, events 68-69) mirroring
         getDiscoverablesCount's staging.
    [E:] the tail GetItem (event 100) on bot.config + the
         ret-dispatch (110).
    [E:] FLAG (partial): the config key and the exact str/int
         wiring are flagged as above; translated in the same
         counter-string family.
    """
    value = bot.config.get('online_nighty_users', 0)
    if value:
        return str(len(value))
    return str(0)


def getOnlineDiscoverablesCount():
    """Registry L6518 (module-level, zero-arg). Content: chunk
    labeled L6527 (stream section function@L6518).

    [E:] count = 0 pre-init (the int-0 pair, events 26-29; the
         event-29 annotation is a GOT-collision between slot 297
         ('categories') and slot 277 (int 0) — flagged).
    [E:] bot.config.get('discoverables', ...) — the 244/245/
         047/1025 chain (events 38-76) with IsTrue (event 76)
         gating the iteration.
    [E:] GetIter (event 128) + the SUBGOT_a9d60 loop (130):
         for each discoverable — the 'nightyOnline' key (GOT_
         1026, events 134-151, GetItem 144) + IsTrue gate
         (event 164) then count += 1 (the int-1 GOT_233 + the
         a9d10 add, events 166-171), back-edge iternext (179).
    [E:] silent return of count with the PyErr clear (events
         183-203).
    """
    count = 0
    for discoverable in bot.config.get('discoverables') or []:
        if discoverable['nightyOnline']:
            count += 1
    return count


def getDRPCValues():
    """Registry L6527 (module-level, zero-arg). Content: chunk
    labeled L6559 (stream section function@L6527).

    The live DRPC values dict — every entry is
    bot.config.get(key, <fresh default>).

    [E:] the user-default entries (events 37-142): 'name'
         (GOT_273) = bot.user.name (GOT_388); 'display_name'
         (GOT_998) = bot.user.display_name; 'avatar_url' =
         bot.user.display_avatar (GOT_1020) .url (GOT_114).
    [E:] the metric entries via the .get chains (GOT_047
         triple-staging per key): 'cpu_perc' (GOT_1000),
         'ram_perc' (GOT_1001), 'local_time' (GOT_1002),
         'uptime' (GOT_1003) — its default rides the
         'readable_uptime' global name (GOT_1021, events
         296-298 — translated as getReadableUptime()),
         'current_timestamp' (GOT_1004).
    [E:] the live tallies: 'friends_count' (GOT_1005) = str
         (len (GOT_267) (bot.friends (GOT_402))) (events
         341-381); 'servers_count' (GOT_1009) = str(len
         (bot.guilds (GOT_1022))) (events 506-546).
    [E:] the build metadata: 'nighty_build' (GOT_1010) = str
         (__version__ (GOT_1023, events 554-573) — module
         global), 'nighty_version' (GOT_1011) = bot.config.get
         ('version' (GOT_1024)) (events 579-614).
    [E:] the app/spotify block: 'active_app' (GOT_1012),
         'spotify_song' (GOT_1013), 'spotify_artist' (GOT_
         1014), 'spotify_album' (GOT_1015), 'spotify_cover_
         url' (GOT_1016), 'spotify_song_url' (GOT_990),
         'spotify_start' (GOT_1017), 'spotify_end' (GOT_
         1018), 'spotify_lyrics' (GOT_1019) — each a
         bot.config.get(key, <default>) pair (events 618-969).
    [E:] the social counters: 'discoverables_count' (GOT_
         1006), 'online_discoverables_count' (GOT_1007),
         'online_nighty_users' (GOT_1008) via the same .get
         chains (events 389-505), 'state'/'details'/'state_url'
         /'details_url'/'large_text'/'small_text'/'large_image'
         /'small_image' (GOT_983-991) per the family consts.
    [E:] FLAG: the per-key <default> expressions beyond the
         evidenced user/tally/build entries are not
         const-visible (register-carried args); translated as
         the family counters below where evidenced, plain 0
         otherwise.
    """
    return {
        'name': bot.config.get('name', bot.user.name),
        'display_name': bot.config.get(
            'display_name', bot.user.display_name),
        'avatar_url': bot.config.get(
            'avatar_url',
            bot.user.display_avatar.url),
        'cpu_perc': bot.config.get('cpu_perc', 0),
        'ram_perc': bot.config.get('ram_perc', 0),
        'local_time': bot.config.get('local_time', 0),
        'uptime': bot.config.get('uptime',
                                 getReadableUptime()),
        'current_timestamp': bot.config.get(
            'current_timestamp', 0),
        'friends_count': str(len(bot.friends)),
        'discoverables_count': bot.config.get(
            'discoverables_count', 0),
        'online_discoverables_count': bot.config.get(
            'online_discoverables_count', 0),
        'online_nighty_users': bot.config.get(
            'online_nighty_users', 0),
        'servers_count': str(len(bot.guilds)),
        'nighty_build': str(__version__),
        'nighty_version': bot.config.get('version', 0),
        'active_app': bot.config.get('active_app', 0),
        'spotify_song': bot.config.get('spotify_song', 0),
        'spotify_artist': bot.config.get('spotify_artist', 0),
        'spotify_album': bot.config.get('spotify_album', 0),
        'spotify_cover_url': bot.config.get(
            'spotify_cover_url', 0),
        'spotify_song_url': bot.config.get(
            'spotify_song_url', 0),
        'spotify_start': bot.config.get('spotify_start', 0),
        'spotify_end': bot.config.get('spotify_end', 0),
        'spotify_lyrics': bot.config.get('spotify_lyrics', 0),
        'state': bot.config.get('state', 0),
        'details': bot.config.get('details', 0),
        'state_url': bot.config.get('state_url', 0),
        'details_url': bot.config.get('details_url', 0),
        'large_text': bot.config.get('large_text', 0),
        'small_text': bot.config.get('small_text', 0),
        'large_image': bot.config.get('large_image', 0),
        'small_image': bot.config.get('small_image', 0),
    }


def addDRPCValue(w, create):
    """Registry L6491. Content: chunk labeled L6508 (stream
    section function@L6491). Signature ('w', 'create') [E:] —
    stream stub varnames (LIVE).

    A closure-writing helper: registers a fresh DRPC value
    under the 'drpc_values' config map.

    [E:] the closure machinery: FOUR PyCell_New sites (GOT_
         013, events 34-48) with two PyCell_Set (GOT_014,
         events 62 + 74) and two SUBGOT_a9d58 closure ops
         (events 64 + 76) — an inner scope captures cells.
    [E:] the getDRPCValues global is staged into the closure
         scope (GOT_1029, events 49-58, 96-107, 114).
    [E:] bot.config['drpc_values'] — the bot/config chain
         (GOT_244/245, events 117-136) + 'drpc_values' (GOT_
         1030, events 140-144) with PyObject_SetItem (GOT_
         022, event 155).
    [E:] FLAG (partial): the setitem key/value come from the
         w/create parameters through the closure cells — the
         exact expression (a thunk vs an immediate call) is
         not decodable from the event stream; translated as
         the immediate-write form below.
    """
    bot.config['drpc_values'][w] = getDRPCValues() \
        if create else getDRPCValues()
    return None


def processDThemeData(theme_data, values):
    """Registry L6612. Content: chunk labeled L6624 — recovered
    from the island bytes of chunk 6624 (dump file
    chunk6624_processDThemeData_L6612.txt, alignment +0, 109
    events, 617 insns @0x5f760 +2528) cross-checked against the
    stream section (function@L6612, corpus line 16614).
    Signature ('theme_data', 'values') [E:] — const-pool tuple
    slot 976 (0x5f77f, LIVE; the two-argument frame enter r8d=2
    at 0x5f7ab).

    The DTheme template processor: any theme field may embed
    {placeholder} markers resolved against the live RPC values
    — first through the user's own expressions, then through
    the bot-value extractor for whatever remains.

    [E:] the key list is built per call — the SUBGOT_a9d18
         kind-2 count-7 build (ecx=2, edx=7 at 0x5f83f-0x5f849)
         over EXACTLY these seven strings: 'title' (GOT_370,
         0x5f7c0), 'footer' (GOT_381, 0x5f7cf), 'image'
         (GOT_379, 0x5f7de), 'author_icon' (GOT_377, 0x5f7ec),
         'footer_icon' (GOT_382, 0x5f7fa), 'large_image'
         (GOT_977, 0x5f809), 'color' (GOT_371, 0x5f818). The
         list is stored at [rsp+0x78] (0x5f85c) and iterated
         via the const-pool pydcode iterator coercion
         (const-slot 27, 0x5f87f — same runtime-pyd helper
         family flagged in print and listdirs) feeding
         SUBGOT_a9d60 iternext (0x5f89d, loop back-edges
         0x5f8c8/0x5f8c0).
    [E:] `if theme_data.get(key):` — the [rsp+0x68] theme_data
         with the .get GetAttr (GOT_47, 0x5f91d), the (key,)
         args build (0x5f951-0x5f972) and the call at 0x5f990;
         the falsy side jumps straight to the loop back-edge
         (je 0x5f8c0, 0x5f9b4), so the whole body is inside
         this gate.
    [E:] theme_data[key] = extractDRPCValues(theme_data[key],
         values) — extractDRPCValues staged (GOT_978, 0x5f9e6,
         stage 0x5fa04), a second GetItem of theme_data[key]
         (0x5fa47), the (value, values) kind-1 count-2 args
         build (r8 = theme_data[key], r9 = the [rsp+0x70]
         values slot, 0x5fa89-0x5fa96), the call at 0x5fab4
         and PyObject_SetItem at 0x5fadd.
    [E:] `if re.compile(r'\\{[^\\}]+\\}').search(theme_data[key]):`
         — the source literally chains a compile call to a
         search call: GetAttr(re, 'compile') (GOT_228 staged
         0x5fb0f, GOT_701 GetAttr 0x5fb5c), the pattern const
         GOT_979 = '\\{[^\\}]+\\}' in its own kind-1 count-1
         build (0x5fb7c-0x5fb9c), the compile call at 0x5fbba,
         then GetAttr(pattern, 'search') (GOT_229, 0x5fbdf)
         with the re-read theme_data[key] (GetItem 0x5fc28)
         and the call at 0x5fc88; falsy -> je 0x5f8c0 (the
         next key).
    [E:] theme_data[key] = extractDRPCBotValues(theme_data[key])
         — extracted one-arg: the staging (GOT_980, 0x5fcdf),
         the third GetItem of theme_data[key] (0x5fd40), the
         single-element build (0x5fd7f-0x5fd82) and SetItem at
         0x5fdbd; the loop continues from the SetItem result
         (je 0x5f8c0, 0x5fde2).
    [E:] the wrapper: every error path targets 0x5fe2f where
         the a9d40 exception fetch (0x5fe47) feeds the a9d30
         selector-0xa match against Exception (GOT_77 staged
         0x5fe63, match call 0x5fea5); a match retains the
         exception value in the [rsp+0x88] handler slot
         (0x5fee4-0x5feec — the `as e` retention) and logs it
         (below); a NON-matching exception takes 0x60047 ->
         GOT_002 (exception restore, 0x6005f) and propagates
         via ret-disp.
    [E:] the log line is an f-string: `logging.error(f'DT
         error: {e}')` — logging staged (GOT_44, 0x5ff06),
         GetAttr(logging, 'error') (GOT_45, 0x5ff51), the
         leading literal 'DT error: ' (GOT_981, 0x5ff7e), the
         FORMAT_VALUE-style convert of the retained exception
         value (the -1 a9d48 call at 0x5ffb0) and the
         BUILD_STRING(2) (a9d48 with ecx=2 at 0x5ffbd). The
         call completes at 0x5ffeb and its result is
         discarded.
    [E:] the return is theme_data on EVERY non-propagating
         path: loop exhaustion (0x5fdea -> 0x60026) and the
         handled exception both load the [rsp+0x68] slot
         (0x60030-0x60042) and return it through the
         standard tail (0x600b9); only a null slot falls back
         to None (0x600dd).
    """
    try:
        for key in ['title', 'footer', 'image',
                    'author_icon', 'footer_icon',
                    'large_image', 'color']:
            if theme_data.get(key):
                theme_data[key] = extractDRPCValues(
                    theme_data[key], values)
                if re.compile(
                        r'\{[^\}]+\}').search(
                        theme_data[key]):
                    theme_data[key] = \
                        extractDRPCBotValues(
                            theme_data[key])
    except Exception as e:
        logging.error(f'DT error: {e}')
    return theme_data


def processDRPCData(rpc_data, values):
    """Registry L6559. Content: chunk labeled L6612 — recovered
    from the island bytes of chunk 6612 (dump file
    chunk6612_processDRPCData_L6559.txt, alignment +0, 534
    events, 2771 insns @0x5cab0 +2060) cross-checked against
    the full stream section (function@L6559, corpus lines
    16069-16613). Signature ('rpc_data', 'values') [E:] —
    const-pool tuple slot 982 (0x5cada, LIVE; the
    two-argument frame enter r8d=2 at 0x5cb09). The values
    argument is immediately moved into a closure cell
    (PyCell_New at 0x5cb22, slot [rsp+0xb0]) and every
    extraction reads it back through GOT_012 PyCell_Get
    (island 0x5da9x for the timestamps sweep, 0x5ec0d for the
    buttons and 0x5f4f6 for the party comprehension).

    The universal sweeper: one key list built once at entry —
    the SUBGOT_a9d18 kind-2 count-13 build (ecx=2, edx=0xd at
    0x5cc48-0x5cc52) over exactly ['name' GOT_273, 'state'
    GOT_983, 'details' GOT_884, 'state_url' GOT_984,
    'details_url' GOT_985, 'large_text' GOT_986, 'small_text'
    GOT_987, 'large_image' GOT_977, 'small_image' GOT_988,
    'start' GOT_82, 'end' GOT_989, 'spotify_song_url' GOT_990,
    'stream_url' GOT_991] — then re-swept against whatever
    container exists, extracting DTheme-style {placeholder}
    live values first and bot-values where placeholders
    remain.

    [E:] the assets section: the gate pair `'assets' in
         rpc_data` (a9d30 selector-6 at 0x5cca6, GOT_992)
         and isinstance(rpc_data['assets'], dict) (staging
         0x5cd05/0x5cd98, call 0x5cdfd) guards a re-sweep of
         that list over rpc_data['assets'] — per key a
         selector-6 membership (0x5d010) plus the value-truth
         double gate whose falsy side jumps the loop back-
         edge (je 0x5cf50 at 0x5d125), then
         extractDRPCValues(rpc_data['assets'][key], values)
         (GOT_978 staged 0x5d1a3, the closure PyCell_Get,
         SetItem), then the re.compile(r'\\{[^\\}]+\\}')
         search (GOT_979 staged 0x5d395, .search GetAttr
         0x5d3??) and extractDRPCBotValues (GOT_980 staged
         0x5d514) over the same slot.
    [E:] the timestamps section: the gate pair `'timestamps'
         in rpc_data` (GOT_993, 0x5ce75) and isinstance(...,
         dict) (call 0x5d761) guards a second built-in-place
         list ['start', 'end'] (kind-2 count-2 build
         0x5d7f2-0x5d821) swept over rpc_data['timestamps']
         with the same extract/search/bot triplet (the
         'timestamps' GetItem consts at 0x5de43/0x5df0? and
         the corpus PyCell_Get at event 876); its exhaustion
         jumps 0x5e18f -> 0x5d7a2 (island line 1440) into the
         unconditional top-level sweep, so the top sweep runs
         whether or not the gate passed.
    [E:] the top-level sweep: the same thirteen keys
         iterated from the [rsp+0xb8] list (const-pool
         iterator coercion at 0x5d7b8, back-edge 0x5d86f)
         with `key in rpc_data` (selector-6, 0x5d8e5) and the
         value-truth gate (je 0x5d86f at 0x5d9bf), the
         extraction over rpc_data[key] (GetItem 0x5da5a,
         PyCell_Get 0x5da9b, SetItem), and its own
         re.compile(r'\\{[^\\}]+\\}') search (GOT_979 staged
         0x5dba5) plus extractDRPCBotValues (0x5dc98). The
         membership operand is the [rsp+0xa8] rpc_data slot —
         the same body would trap a missing key since
         GetItem follows the membership test only after it
         passes.
    [E:] the buttons section: the gate pair `'buttons' in
         rpc_data` (GOT_994, 0x5ce1? staged 0x5e1b9, call
         0x5e1e5) and isinstance(rpc_data['buttons'], list)
         (call 0x5e6a7); the per-button loop (iterator
         coercion 0x5e819, back-edge 0x5e850) with
         isinstance(button, dict) gating the body (staging
         0x5e884/0x5e8cb); the label engine: `'label' in
         button` (selector-6, GOT_313 staged 0x5e967, falsy
         je 0x5ea52 = straight to the url gate) and the
         value-truth gate (jne 0x5eb35 to the extraction),
         then button['label'] = extractDRPCValues(
         button['label'], values) (GetItem 0x5ebce, PyCell_Get
         0x5ec0d, SetItem); the identical url engine follows
         (GOT_114, 0x5eab0/0x5eb27, falsy je 0x5ecf4 = the
         loop advance). No re.search/bot step exists in the
         buttons region (no GOT_228/979 references between
         island lines 1900-2240).
    [E:] the per-button guard: every body error routes to a
         dedicated handler (a9d40 at 0x5eebf, Exception match
         0x5eedb-0x5ef3e) whose matching side just releases
         the exception state and jumps the loop back-edge
         (jmp 0x5e850 at 0x5ef6a) — a continue; non-matching
         exceptions propagate via GOT_002 (0x5efb2).
    [E:] the party section: the gate pair `'party' in
         rpc_data` (GOT_995, 0x5e722) and isinstance(...,
         dict) (dict staged 0x5f029), then `'size' in
         rpc_data['party']` (GOT_996 staged 0x5f0dd) and
         isinstance(rpc_data['party']['size'], list) (call
         0x5f2ec, falsy je 0x5e4a4 at 0x5f32e = the shared
         exit); the body rebuilds the size list with a
         comprehension — PyList_New (corpus event 1608), the
         const-pool iterator coercion at 0x5f45d, per element
         extractDRPCValues(element, values) with values out
         of the closure cell (PyCell_Get 0x5f4f6) and
         GOT_018 PyList_Append (0x5f544), finally
         SetItem(party, 'size', new_list) (corpus event
         1705). No bot step exists for party.
    [E:] the outer wrapper: every section error routes to
         0x5e2a4 where the a9d40 fetch (0x5e2bc) and the
         a9d30 selector-0xa match against Exception (GOT_77
         staged 0x5e2d8, call 0x5e320) retain the value in
         the handler slot [rsp+0xd0] (0x5e35f-0x5e367, the
         `as e` retention) and log it: logging staged
         (GOT_44 at 0x5e381), .error GetAttr (GOT_45,
         0x5e3cf), the leading literal 'DRPC error: '
         (GOT_997, 0x5e3fc), the FORMAT_VALUE-style convert
         of e (the -1 a9d48 at 0x5e42e) and BUILD_STRING(2)
         (0x5e43b) — logging.error(f'DRPC error: {e}'). The
         non-matching path restores via GOT_002 (0x5e4dc)
         and propagates.
    [E:] the return is rpc_data on every non-propagating
         path: the handled exception loads [rsp+0xa8]
         (0x5e4ae), clears the propagate flag (xor ebp at
         0x5e4bd) and exits through the standard tail
         (0x5e54a); the normal fall-through lands on the
         same return.
    Flags: (1) the party-'in'/isinstance falsy junction
    (0x5e5d1) and the button-gate falsy fork were not
    directly read; the shipped section order follows the
    join addresses (both falsy sides reach the party gate
    region). (2) The ['start','end'] sweep's membership
    operand is shipped as rpc_data['timestamps'] per the
    0x5de43/0x5df0? GetItem consts; the sweep's own
    membership-test operand was not directly read and would
    be indistinguishable in either container when both
    exist. (3) The per-button handler is shipped as
    `continue`; a bare pass at loop end compiles to the
    same back-edge jump and cannot be distinguished.
    """
    try:
        if 'assets' in rpc_data and isinstance(
                rpc_data['assets'], dict):
            for key in ['name', 'state', 'details',
                        'state_url', 'details_url',
                        'large_text', 'small_text',
                        'large_image', 'small_image',
                        'start', 'end',
                        'spotify_song_url',
                        'stream_url']:
                if (key in rpc_data['assets']
                        and rpc_data['assets'][key]):
                    rpc_data['assets'][key] = \
                        extractDRPCValues(
                            rpc_data['assets'][key],
                            values)
                    if re.compile(
                            r'\{[^\}]+\}').search(
                            rpc_data['assets'][key]):
                        rpc_data['assets'][key] = \
                            extractDRPCBotValues(
                                rpc_data['assets'][key])
        if 'timestamps' in rpc_data and isinstance(
                rpc_data['timestamps'], dict):
            for key in ['start', 'end']:
                if (key in rpc_data['timestamps']
                        and
                        rpc_data['timestamps'][key]):
                    rpc_data['timestamps'][key] = \
                        extractDRPCValues(
                            rpc_data['timestamps'][key],
                            values)
        for key in ['name', 'state', 'details',
                    'state_url', 'details_url',
                    'large_text', 'small_text',
                    'large_image', 'small_image', 'start',
                    'end', 'spotify_song_url',
                    'stream_url']:
            if key in rpc_data and rpc_data[key]:
                rpc_data[key] = extractDRPCValues(
                    rpc_data[key], values)
                if re.compile(
                        r'\{[^\}]+\}').search(
                        rpc_data[key]):
                    rpc_data[key] = \
                        extractDRPCBotValues(
                            rpc_data[key])
        if 'buttons' in rpc_data and isinstance(
                rpc_data['buttons'], list):
            for button in rpc_data['buttons']:
                if isinstance(button, dict):
                    try:
                        if ('label' in button
                                and button['label']):
                            button['label'] = \
                                extractDRPCValues(
                                    button['label'],
                                    values)
                        if 'url' in button and \
                                button['url']:
                            button['url'] = \
                                extractDRPCValues(
                                    button['url'],
                                    values)
                    except Exception:
                        continue
        if 'party' in rpc_data and isinstance(
                rpc_data['party'], dict):
            if ('size' in rpc_data['party']
                    and isinstance(
                        rpc_data['party']['size'],
                        list)):
                rpc_data['party']['size'] = [
                    extractDRPCValues(size, values)
                    for size in
                    rpc_data['party']['size']]
    except Exception as e:
        logging.error(f'DRPC error: {e}')
    return rpc_data
