"""
func_store.py — the FuncStore registry bridge (registry
L4707-L4718), recovered via the Ghidra decomp lane.

  __init__()                        — self.functions = {}
  register(self, func, name)        — self.functions[name] = func
  get(self, name)                   — self.functions.get(name)
  call(self, name, ...)            — the ValueError guard +
                                      the async bridge

The raised message is the EXACT recovered const: 'No function
registered with name '' + name + '''.
"""

import asyncio

from inspect import iscoroutinefunction


class FuncStore:
    """The named-callback store backing the js_api bridge."""

    def __init__(self):
        """Registry L4707 (FuncStore.__init__). Content: chunk
        labeled L4710 (stream section function@L4707).

        [E:] self.functions = <dispatcher-built dict> —
             'functions' (GOT_1193) staged for SetAttr (GOT_020,
             L25-37); the dispatcher-built {} (invisible build
             per the family invariant); silent None return
             (L43-51).
        """
        self.functions = {}

    def register(self, func, name):
        """Registry L4710 (FuncStore.register). Content: chunk
        labeled L4715 (stream section function@L4710).
        Signature ('self', 'func', 'name') [E:] — const-pool
        tuple slot 1194.

        [E:] self.functions[name] = func — 'functions' GetAttr
             (GOT_1193, L71-87) + PyObject_SetItem (GOT_022,
             L100); an early cluster touches func.__name__
             (GOT_509, L29-59) with a truth-select — flag: its
             role in the original (name-default vs validation) is
             not fully resolved; silent None return (L110-118).
        """
        self.functions[name] = func

    def get(self, name):
        """Registry L4715 (FuncStore.get). Content: chunk labeled
        L4718 (stream section function@L4715).

        [E:] return self.functions.get(name) — 'functions'
             GetAttr (GOT_1193, L33-44) + 'get' GetAttr (GOT_047,
             L54-60) + the (1,1) args build + the None default
             staged (GOT_030, L68-69) feeding the return-op
             (L77).
        """
        return self.functions.get(name)

    def call(self, name, *args, **kwargs):
        """Registry L4718 (FuncStore.call). Content: chunk labeled
        L4927 (stream section function@L4718).

        PARTIALLY RECONSTRUCTED — the guard and message are fully
        evidenced; the async-bridge tail is cluster-evidenced
        with the family consts (iscoroutinefunction GOT_1190 /
        run_coroutine_threadsafe GOT_1191 / loop GOT_1192 /
        result GOT_521) and flagged.

        [E:] func = self.functions.get(name) — the .get chain
             (GOT_047, L43-67); the truth gate (L93-101) raises
             ValueError (GOT_1187) with the a9d48-concat message
             'No function registered with name '' (GOT_1188) +
             name + ''' (GOT_1189), L104-124.
        [E:] the dispatch tail: asyncio load (L182-186) + the
             dispatch branch (L157, L196-211), the bot global
             (GOT_244, L218-221) and a 'result' GetAttr (GOT_521,
             L238-245); silent None otherwise (L267-276).
        """
        func = self.functions.get(name)
        if not func:
            raise ValueError("No function registered with name '"
                             + name + "'")
        if iscoroutinefunction(func):
            return asyncio.run_coroutine_threadsafe(
                func(*args, **kwargs), bot.loop).result()
        return func(*args, **kwargs)
