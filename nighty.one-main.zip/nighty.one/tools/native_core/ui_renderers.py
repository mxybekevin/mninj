"""
ui_renderers.py — the UI component renderer family (registry
L2235-L3523), recovered via the Ghidra decomp lane.

Recovered as real classes: the original attribute names are the
double-underscore privates (self.__content etc. — the evidence is
the _Text__*-style mangled const slots), and writing them inside
their classes reproduces the exact mangled names at runtime.

Registry invariants recovered from this family: ids generated via
str(uuid.uuid4()); callbacks registered through the global
callback_store with the bound function stored as its __name__;
Input/Select add a second closure listener registered under a
generated listener_id (cell machinery). Gate messages carry NO
trailing period except 'Button onClick callback is not defined.'
(GOT_1419 — the only one with a period).

  Text      ctor L2235 (sig slot 1572)   render L2337
  Button    ctor L2358 (sig slot 1556)   render L2500
  Input     ctor L2524 (sig slot 1540)   render L2715
  Image     ctor L2742 (sig slot 1515)   render L2876
  Toggle    ctor L2915 (sig slot 1487)   render L3003
  Select    ctor L3022 (sig slot 1474)   render L3246
  Checkbox  ctor L3278 (sig slot 1440)   render L3375
"""

import re
import uuid

_IMAGE_URL_PATTERN = (
    r'^(https?://)([a-zA-Z0-9.-]+)(\.[a-zA-Z]{2,})'
    r'(:\d+)?(/[\w./?%&=-]*)?$')


class Text:
    """The text component. Registry L2235 (ctor) / L2337 (render)."""

    def __init__(self, content, tab_updater, parent_tab_name,
                 size, weight, color, align, margin, visible):
        """Registry L2235 (Text.__init__). Content: chunk labeled
        L2337 — decompiled as a merged region (dossier pass
        queued); the SIGNATURE is live const-pool evidence [E:]:
        slot 1572 = ('self', 'content', 'tab_updater',
        'parent_tab_name', 'size', 'weight', 'color', 'align',
        'margin', 'visible').

        [E:] the Text-const neighborhood carries '_Text__tab_
             updater' (GOT_1573) plus the two module constants
             ALLOWED_WEIGHTS (GOT_1574) and ALLOWED_ALIGN
             (GOT_1575) — variant gates sit in this constructor
             (they ship in tailwind_validators.py).
        [E:] flag (partial): the merged-region decomp prevents
             citing the exact cascade — the validator placement,
             the __id assignment source (no id parameter exists
             in the sig) and any tab_updater registration are
             flagged pending the dossier pass; the cascade below
             is the sig-faithful skeleton.
        """
        self.__id = None
        self.__content = content
        self.__tab_updater = tab_updater
        self.__parent_tab_name = parent_tab_name
        self.__size = size
        self.__weight = weight
        self.__color = color
        self.__align = align
        self.__margin = margin
        self.__visible = visible

    def render(self):
        """Registry L2337 (Text.render). Content: chunk labeled
        L2358 (stream section function@L2337).

        [E:] gate: falsy content raises ValueError('Text
             content cannot be empty') — the EXACT const GOT_1562
             with NO trailing period ('Text content cannot be
             empty', L342-353) — the content GetAttr (GOT_1561,
             L44-63) + the truth select (L68-116).
        [E:] the emitted dict — every pair staged as <public key
             slot> + <mangled attr slot> + GetAttr: 'type'
             (GOT_248) = 'text' (GOT_097, L132-139); 'id'
             (GOT_265) + __id (GOT_1565, L141-161); 'content'
             (GOT_964) + __content (GOT_1561, L166-186); 'size'
             (GOT_996) + __size (GOT_1566, L191-211); 'weight'
             (GOT_1563) + __weight (GOT_1567, L216-236); 'color'
             (GOT_371) + __color (GOT_1568, L241-260); 'align'
             (GOT_1564) + __align (GOT_1569, L265-284); 'margin'
             (GOT_1461) + __margin (GOT_1570, L289-306);
             'visible' (GOT_1365) + __visible (GOT_1571,
             L312-329); return-dispatch L367.
        """
        if not self.__content:
            raise ValueError('Text content cannot be empty')
        return {
            'type': 'text',
            'id': self.__id,
            'content': self.__content,
            'size': self.__size,
            'weight': self.__weight,
            'color': self.__color,
            'align': self.__align,
            'margin': self.__margin,
            'visible': self.__visible,
        }


class Button:
    """The button component. Registry L2358 (ctor) / L2500
    (render)."""

    def __init__(self, parent_tab_name, tab_updater, label,
                 variant, color, size, full_width, disabled,
                 loading, onClick, margin, visible):
        """Registry L2358 (Button.__init__). Content: chunk
        labeled L2500 (stream section function@L2358).
        Signature ('self', 'parent_tab_name', 'tab_updater',
        'label', 'variant', 'color', 'size', 'full_width',
        'disabled', 'loading', 'onClick', 'margin', 'visible')
        [E:] — const-pool tuple slot 1556. The tuple encodes no
        defaults — translated without any (the plain truth gate
        below reads on an explicit value).

        [E:] self.__id = str(uuid.uuid4()) — str (GOT_150) +
             uuid (GOT_524) + uuid4 (GOT_525) + SetAttr (GOT_020,
             L68-114).
        [E:] setattr cascade in order: __parent_tab_name
             (GOT_1547, L124-131), __tab_updater (GOT_1557,
             L140-147), __label (GOT_1544, L156-163), __color
             (GOT_1549, L173-180), __size (GOT_1550, L190-197),
             __variant (GOT_1548, L207-214), __full_width
             (GOT_1551, L224-231), __disabled (GOT_1552,
             L241-248), __loading (GOT_1553, L258-265), __margin
             (GOT_1554, L275-282), __visible (GOT_1555,
             L292-299).
        [E:] the onClick registration: plain truth gate (IsTrue,
             L306 — no None consts, unlike Input) then the
             callback_store global (GOT_641) + register (GOT_1422)
             with a 2-slot args build (L308-330) and
             self.__onClick = onClick.__name__ (the __name__
             const GOT_509, GetAttr L363 + SetAttr L369). Flag:
             the register key is const-staged only, translated as
             the id per family symmetry.
        [E:] the validation line-up as BARE calls (no SetAttr
             follows them in the stream): margin_padding_
             validator(VALID_MARGINS, self.__margin) (GOT_1453/
             1454, L375-412); variant_validator(ALLOWED_VARIANTS,
             self.__variant) (GOT_1310/1558, L420-469);
             variant_validator(ALLOWED_COLORS, self.__color)
             (GOT_1559, L477-526); variant_validator(
             ALLOWED_SIZES, self.__size) (GOT_1560, L534-583).
        """
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__label = label
        self.__color = color
        self.__size = size
        self.__variant = variant
        self.__full_width = full_width
        self.__disabled = disabled
        self.__loading = loading
        self.__margin = margin
        self.__visible = visible
        if onClick:
            callback_store.register(self.__id, onClick)
            self.__onClick = onClick.__name__
        margin_padding_validator(VALID_MARGINS, self.__margin)
        variant_validator(ALLOWED_VARIANTS, self.__variant)
        variant_validator(ALLOWED_COLORS, self.__color)
        variant_validator(ALLOWED_SIZES, self.__size)

    def render(self):
        """Registry L2500 (Button.render). Content: chunk labeled
        L2524 (stream section function@L2500).

        [E:] the onClick gate comes FIRST (head truth select on
             __onClick, GOT_1543, L49-88): falsy raises
             ValueError('Button onClick callback is not defined.')
             — the EXACT message GOT_1419 (L529-555), the only
             gate message in the family WITH a trailing period.
        [E:] the label gates: __label (GOT_1544) + the truth
             select + the compare cluster against '' (GOT_241,
             L131-165) → ValueError('Button label cannot be
             empty') — EXACT GOT_1413, NO trailing period
             (L91-188).
        [E:] the emitted dict, staged <public key> + <mangled
             attr> pairs: 'type' (GOT_248) = 'button' (GOT_1408);
             'id' (GOT_265) + __id (GOT_1546); 'parent_tab_name'
             (GOT_1282) + __parent_tab_name (GOT_1547); 'label'
             (GOT_313) + __label (GOT_1544); 'variant' (GOT_1545)
             + __variant (GOT_1548); 'color' (GOT_371) + __color
             (GOT_1549); 'size' (GOT_996) + __size (GOT_1550);
             'full_width' (GOT_1335) + __full_width (GOT_1551);
             'disabled' (GOT_358) + __disabled (GOT_1552);
             'loading' (GOT_1458) + __loading (GOT_1553);
             'onClick' (GOT_1418) + __onClick (GOT_1543,
             L443-463); 'margin' (GOT_1461) + __margin (GOT_1554,
             L469-486); 'visible' (GOT_1365) + __visible
             (GOT_1555, L492-509).
        """
        if not self.__onClick:
            raise ValueError('Button onClick callback is not '
                             'defined.')
        if not self.__label or self.__label == '':
            raise ValueError('Button label cannot be empty')
        return {
            'type': 'button',
            'id': self.__id,
            'parent_tab_name': self.__parent_tab_name,
            'label': self.__label,
            'variant': self.__variant,
            'color': self.__color,
            'size': self.__size,
            'full_width': self.__full_width,
            'disabled': self.__disabled,
            'loading': self.__loading,
            'onClick': self.__onClick,
            'margin': self.__margin,
            'visible': self.__visible,
        }


class Input:
    """The input component. Registry L2524 (ctor) / L2715
    (render)."""

    def __init__(self, parent_tab_name, tab_updater, label,
                 placeholder, value, description, margin, onInput,
                 show_clear_button, invalid, disabled, readonly,
                 required, full_width, error_message, visible):
        """Registry L2524 (Input.__init__). Content: chunk labeled
        L2715 (stream section function@L2524). Signature ('self',
        'parent_tab_name', 'tab_updater', 'label', 'placeholder',
        'value', 'description', 'margin', 'onInput',
        'show_clear_button', 'invalid', 'disabled', 'readonly',
        'required', 'full_width', 'error_message', 'visible')
        [E:] — const-pool tuple slot 1540. No defaults encoded —
        translated without; the is-not-None gate reads on an
        explicit value. All parameters are cell-captured (the
        onInput listener closure references them).

        [E:] self.__id = str(uuid.uuid4()) — GOT_1525/150/524/
             525 + SetAttr (L88-143); self.__listener_id =
             str(uuid.uuid4()) — GOT_1524 + the same uuid chain
             (L188-229); plain cascade: __parent_tab_name
             (GOT_1526, L152-161), __tab_updater (GOT_1541,
             L170-179), __label (GOT_1523, L238-247),
             __placeholder (GOT_1527, L256-265), __value
             (GOT_1528, L274-283), __margin (GOT_1530, L292-301),
             __description (GOT_1532, L310-319), __show_clear_
             button (GOT_1533, L328-338), __invalid (GOT_1534,
             L347-357), __full_width (GOT_1529, L366-376),
             __disabled (GOT_1535, L385-395), __readonly (GOT_
             1536, L404-414), __required (GOT_1537, L423-433),
             __error_message (GOT_1538, L442-452), __visible
             (GOT_1539, L461-471).
        [E:] the onInput block: IsTrue gate WITH explicit None
             consts (L479, 495-497) — `if onInput is not None:` →
             callback_store.register (GOT_641/1422, L501-519; the
             first register key is const-staged only — flagged,
             translated as the id) + self.__onInput =
             onInput.__name__ (GOT_509, L555 + SetAttr L562);
             THEN a SECOND callback_store.register under the
             listener_id (L581-624) whose object is a CLOSURE
             built by the cell machinery (DAT_000a9d58 +
             unlabeled GOT_1848, L566-574) — flagged: the closure
             body is not const-visible.
        """
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__listener_id = str(uuid.uuid4())
        self.__label = label
        self.__placeholder = placeholder
        self.__value = value
        self.__margin = margin
        self.__description = description
        self.__show_clear_button = show_clear_button
        self.__invalid = invalid
        self.__full_width = full_width
        self.__disabled = disabled
        self.__readonly = readonly
        self.__required = required
        self.__error_message = error_message
        self.__visible = visible
        if onInput is not None:
            callback_store.register(self.__id, onInput)
            self.__onInput = onInput.__name__
            callback_store.register(
                self.__listener_id,
                None)  # FLAG: closure built via the cell
            # machinery (DAT_000a9d58) — the registered object is
            # not const-visible (GOT_1848 unlabeled)

    def render(self):
        """Registry L2715 (Input.render). Content: chunk labeled
        L2742 (stream section function@L2715). NO gates — the
        dict is emitted directly.

        [E:] the pairs, in emission order: 'type' (GOT_248) =
             'input' (GOT_1522); 'label' (GOT_313) + __label
             (GOT_1523); 'listener_id' (GOT_1429) +
             __listener_id (GOT_1524); 'id' (GOT_265) + __id
             (GOT_1525); 'parent_tab_name' (GOT_1282) +
             __parent_tab_name (GOT_1526); 'placeholder'
             (GOT_1517) + __placeholder (GOT_1527); 'value'
             (GOT_274) + __value (GOT_1528); 'full_width'
             (GOT_1335) + __full_width (GOT_1529); 'margin'
             (GOT_1461) + __margin (GOT_1530); 'onInput'
             (GOT_1518) + __onInput (GOT_1531); 'description'
             (GOT_249) + __description (GOT_1532);
             'show_clear_button' (GOT_1519) + __show_clear_button
             (GOT_1533); 'invalid' (GOT_1431) + __invalid
             (GOT_1534); 'disabled' (GOT_358) + __disabled
             (GOT_1535); 'readonly' (GOT_1520) + __readonly
             (GOT_1536); 'required' (GOT_1521) + __required
             (GOT_1537); 'error_message' (GOT_1459) +
             __error_message (GOT_1538); 'visible' (GOT_1365) +
             __visible (GOT_1539); return-dispatch L419.
        """
        return {
            'type': 'input',
            'label': self.__label,
            'listener_id': self.__listener_id,
            'id': self.__id,
            'parent_tab_name': self.__parent_tab_name,
            'placeholder': self.__placeholder,
            'value': self.__value,
            'full_width': self.__full_width,
            'margin': self.__margin,
            'onInput': self.__onInput,
            'description': self.__description,
            'show_clear_button': self.__show_clear_button,
            'invalid': self.__invalid,
            'disabled': self.__disabled,
            'readonly': self.__readonly,
            'required': self.__required,
            'error_message': self.__error_message,
            'visible': self.__visible,
        }


class Image:
    """The image component. Registry L2742 (ctor) / L2876
    (render)."""

    def __init__(self, parent_tab_name, tab_updater, url, alt,
                 circle, shadow, width, height, rounded, fill_type,
                 margin, border_color, border_width, visible):
        """Registry L2742 (Image.__init__). Content: chunk labeled
        L2876 (stream section function@L2742). Signature ('self',
        'parent_tab_name', 'tab_updater', 'url', 'alt', 'circle',
        'shadow', 'width', 'height', 'rounded', 'fill_type',
        'margin', 'border_color', 'border_width', 'visible')
        [E:] — const-pool tuple slot 1515. NO validators in this
        ctor (they live in render).

        [E:] self.__id = str(uuid.uuid4()) — GOT_1506/150/524/
             525 + SetAttr (L73-114); the cascade in order:
             __parent_tab_name (GOT_1507), __tab_updater (GOT_
             1516), __url (GOT_1497), __alt (GOT_1508), __circle
             (GOT_1509), __shadow (GOT_1510), __width (GOT_1511),
             __height (GOT_1512), __rounded (GOT_1493),
             __fill_type (GOT_1491), __margin (GOT_1489), __border_
             color (GOT_1513), __border_width (GOT_1494),
             __visible (GOT_1514) — SetAttrs L132-371.
        """
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__url = url
        self.__alt = alt
        self.__circle = circle
        self.__shadow = shadow
        self.__width = width
        self.__height = height
        self.__rounded = rounded
        self.__fill_type = fill_type
        self.__margin = margin
        self.__border_color = border_color
        self.__border_width = border_width
        self.__visible = visible

    def render(self):
        """Registry L2876 (Image.render). Content: chunk labeled
        L2915 (stream section function@L2876). The validators run
        in render (bare calls) before emission.

        [E:] margin_padding_validator(VALID_MARGINS, self.__margin)
             — GOT_1453/1454 (L52-92); variant_validator(
             ALLOWED_FILL_TYPES, self.__fill_type) — GOT_1310 +
             GOT_1490 (L102-151); variant_validator(
             ALLOWED_ROUNDED, self.__rounded) — GOT_1492 (L160-
             209).
        [E:] the border gate: `0 <= self.__border_width <= 10` —
             the compare with int-0 (GOT_277) and int-10
             (GOT_1162), L219-293 → ValueError('Border width must
             be between 0 and 10') — EXACT GOT_1495, NO trailing
             period (L300-319).
        [E:] the url gate: re.compile (GOT_228/701, L329-343)
             over the EXACT regex GOT_1496 = r'^(https?://)([a-
             zA-Z0-9.-]+)(\.[a-zA-Z]{2,})(:\d+)?(/[\w./?%&=-]*)?$'
             (verbatim live const), then bool() (GOT_408) +
             .match (GOT_681, L361-414) → ValueError('Invalid URL
             provided') — EXACT GOT_1498 (L422-451).
        [E:] the emitted dict: 'type' (GOT_248) = 'image'
             (GOT_379); 'id' (GOT_265) + __id (GOT_1506);
             'parent_tab_name' (GOT_1282) + __parent_tab_name
             (GOT_1507); 'url' (GOT_114) + __url (GOT_1497);
             'alt' (GOT_1499) + __alt (GOT_1508); 'circle'
             (GOT_1500) + __circle (GOT_1509); 'shadow' (GOT_1501)
             + __shadow (GOT_1510); 'width' (GOT_116) + __width
             (GOT_1511); 'height' (GOT_118) + __height (GOT_
             1512); 'rounded' (GOT_1502) + __rounded (GOT_1493);
             'fill_type' (GOT_1503) + __fill_type (GOT_1491);
             'margin' (GOT_1461) + __margin (GOT_1489); 'border_
             color' (GOT_1504) + __border_color (GOT_1513);
             'border_width' (GOT_1505) + __border_width (GOT_
             1494); 'visible' (GOT_1365) + __visible (GOT_1514)
             — L456-805.
        """
        margin_padding_validator(VALID_MARGINS, self.__margin)
        variant_validator(ALLOWED_FILL_TYPES, self.__fill_type)
        variant_validator(ALLOWED_ROUNDED, self.__rounded)
        if not 0 <= self.__border_width <= 10:
            raise ValueError('Border width must be between 0 '
                             'and 10')
        url_pattern = re.compile(_IMAGE_URL_PATTERN)
        if not bool(url_pattern.match(self.__url)):
            raise ValueError('Invalid URL provided')
        return {
            'type': 'image',
            'id': self.__id,
            'parent_tab_name': self.__parent_tab_name,
            'url': self.__url,
            'alt': self.__alt,
            'circle': self.__circle,
            'shadow': self.__shadow,
            'width': self.__width,
            'height': self.__height,
            'rounded': self.__rounded,
            'fill_type': self.__fill_type,
            'margin': self.__margin,
            'border_color': self.__border_color,
            'border_width': self.__border_width,
            'visible': self.__visible,
        }


class Toggle:
    """The toggle component. Registry L2915 (ctor) / L3003
    (render)."""

    def __init__(self, parent_tab_name, tab_updater, label,
                 checked, disabled, onChange, visible):
        """Registry L2915 (Toggle.__init__). Content: chunk
        labeled L3003 — decompiled as a merged region (dossier
        pass queued); the SIGNATURE is live const-pool evidence
        [E:]: slot 1487 = ('self', 'parent_tab_name',
        'tab_updater', 'label', 'checked', 'disabled', 'onChange',
        'visible').

        [E:] consts: _Toggle__tab_updater (GOT_1488); the render
             consumes id, listener_id, parent_tab_name, label,
             checked, disabled, onChange, visible — the ctor
             generates the ids per the family idiom. Flag
             (partial): the ctor BODY is dossier-queued; the
             cascade below is sig-faithful only (the onChange
             registration shape — raw value vs __name__ — is
             unverified for this class).
        """
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__label = label
        self.__checked = checked
        self.__disabled = disabled
        self.__visible = visible
        self.__onChange = onChange

    def render(self):
        """Registry L3003 (Toggle.render). Content: chunk labeled
        L3022 (stream section function@L3003).

        [E:] the label gate first: __label (GOT_1477) + truth
             select + the compare against '' (GOT_241, L82-116) →
             ValueError('Toggle label cannot be empty') — EXACT
             GOT_1478, NO trailing period (L344-355).
        [E:] the emitted dict: 'type' (GOT_248) = 'toggle'
             (GOT_1479); 'id' (GOT_265) + __id (GOT_1480);
             'listener_id' (GOT_1429) + __listener_id (GOT_1481);
             'parent_tab_name' (GOT_1282) + __parent_tab_name
             (GOT_1482); 'label' (GOT_313) + __label (GOT_1477);
             'checked' (GOT_1430) + __checked (GOT_1483);
             'disabled' (GOT_358) + __disabled (GOT_1484);
             'onChange' (GOT_1460) + __onChange (GOT_1485);
             'visible' (GOT_1365) + __visible (GOT_1486).
        """
        if not self.__label or self.__label == '':
            raise ValueError('Toggle label cannot be empty')
        return {
            'type': 'toggle',
            'id': self.__id,
            'listener_id': self.__listener_id,
            'parent_tab_name': self.__parent_tab_name,
            'label': self.__label,
            'checked': self.__checked,
            'disabled': self.__disabled,
            'onChange': self.__onChange,
            'visible': self.__visible,
        }


class Select:
    """The select component. Registry L3022 (ctor) / L3246
    (render)."""

    def __init__(self, parent_tab_name, tab_updater, label, items,
                 selected_items, disabled_items, mode, description,
                 loading, disabled, invalid, error_message,
                 onChange, margin, full_width, visible):
        """Registry L3022 (Select.__init__). Content: chunk
        labeled L3246 (stream section function@L3022).
        Signature ('self', 'parent_tab_name', 'tab_updater',
        'label', 'items', 'selected_items', 'disabled_items',
        'mode', 'description', 'loading', 'disabled', 'invalid',
        'error_message', 'onChange', 'margin', 'full_width',
        'visible') [E:] — const-pool tuple slot 1474. No defaults
        encoded; the normalization below handles an explicit
        None.

        [E:] self.__id = str(uuid.uuid4()) (GOT_1463/150/524/525
             + SetAttr, L82-140); __parent_tab_name (GOT_1465),
             __tab_updater (GOT_1475), __label (GOT_1444) —
             L149-194.
        [E:] items / selected_items / disabled_items pass through
             None-compare ternaries — a9d30 + None (GOT_030) +
             dual IsTrue + the a9d18 empty build + SetAttr
             (L203-243 items / L252-288 selected_items / L297-333
             disabled_items) — translated `x if x is not None
             else []`; the default build kind is flagged (the
             empty build reads as the list idiom).
        [E:] the plain cascade: __mode (GOT_1452), __description
             (GOT_1466), __loading (GOT_1467), __disabled (GOT_
             1468), __invalid (GOT_1469), __error_message (GOT_
             1470), __margin (GOT_1455), __full_width (GOT_1472),
             __visible (GOT_1473) — SetAttrs L342-502.
        [E:] the onChange block mirrors Input: IsTrue gate WITH
             None consts (L514, 530-532) — `if onChange is not
             None:` → callback_store.register (GOT_641/1422,
             L536-554; the first key is const-staged only —
             flagged, translated as the id) + self.__onChange =
             onChange.__name__ (GOT_509, L573-595); THEN
             self.__listener_id = str(uuid.uuid4()) (GOT_1464,
             L604-645) and a second callback_store.register under
             it with a CLOSURE built by the cell machinery
             (DAT_000a9d58 + unlabeled GOT_1840, L649-711) —
             flagged: the closure body is not const-visible.
        """
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__label = label
        self.__items = items if items is not None else []
        self.__selected_items = (selected_items
                                 if selected_items is not None
                                 else [])
        self.__disabled_items = (disabled_items
                                  if disabled_items is not None
                                  else [])
        self.__mode = mode
        self.__description = description
        self.__loading = loading
        self.__disabled = disabled
        self.__invalid = invalid
        self.__error_message = error_message
        self.__margin = margin
        self.__full_width = full_width
        self.__visible = visible
        if onChange is not None:
            callback_store.register(self.__id, onChange)
            self.__onChange = onChange.__name__
            self.__listener_id = str(uuid.uuid4())
            callback_store.register(
                self.__listener_id,
                None)  # FLAG: closure built via the cell
            # machinery (DAT_000a9d58) — the registered object is
            # not const-visible (GOT_1840 unlabeled)

    def render(self):
        """Registry L3246 (Select.render). Content: chunk labeled
        L3278 (stream section function@L3246).

        [E:] the label gate: __label (GOT_1444) + the truth
             select + the compare against '' (GOT_241, L97-131) →
             ValueError('Select label cannot be empty') — EXACT
             GOT_1445, NO trailing period (L880-891).
        [E:] the private-method validator line-up (bare calls):
             self.__items_validator(self.__items) — GOT_1446/1447
             (L141-186); self.__keys_validator(
             self.__selected_items) — GOT_1448/1449 (L195-238);
             self.__keys_validator(self.__disabled_items) —
             GOT_1448/1450 (L247-290);
             variant_validator(ALLOWED_MODES, self.__mode) —
             GOT_1310/1451/1452 (L298-347);
             margin_padding_validator(VALID_MARGINS, self.__margin)
             — GOT_1453/1454/1455 (L355-393). Flag: the __items_
             validator / __keys_validator METHOD bodies live
             elsewhere in the registry (decoded queued).
        [E:] the emitted dict: 'type' (GOT_248) = 'select'
             (GOT_1462); 'id' (GOT_265) + __id (GOT_1463);
             'listener_id' (GOT_1429) + __listener_id (GOT_1464);
             'parent_tab_name' (GOT_1282) + __parent_tab_name
             (GOT_1465); 'label' (GOT_313) + __label (GOT_1444);
             'items' (GOT_247) + __items (GOT_1447);
             'selected_items' (GOT_1456) + __selected_items (GOT_
             1449); 'disabled_items' (GOT_1457) + __disabled_items
             (GOT_1450); 'mode' (GOT_352) + __mode (GOT_1452);
             'description' (GOT_249) + __description (GOT_1466);
             'loading' (GOT_1458) + __loading (GOT_1467);
             'disabled' (GOT_358) + __disabled (GOT_1468);
             'invalid' (GOT_1431) + __invalid (GOT_1469);
             'error_message' (GOT_1459) + __error_message (GOT_
             1470); 'onChange' (GOT_1460) + __onChange (GOT_1471);
             'margin' (GOT_1461) + __margin (GOT_1455);
             'full_width' (GOT_1335) + __full_width (GOT_1472);
             'visible' (GOT_1365) + __visible (GOT_1473) —
             L403-862.
        """
        if not self.__label or self.__label == '':
            raise ValueError('Select label cannot be empty')
        self.__items_validator(self.__items)
        self.__keys_validator(self.__selected_items)
        self.__keys_validator(self.__disabled_items)
        variant_validator(ALLOWED_MODES, self.__mode)
        margin_padding_validator(VALID_MARGINS, self.__margin)
        return {
            'type': 'select',
            'id': self.__id,
            'listener_id': self.__listener_id,
            'parent_tab_name': self.__parent_tab_name,
            'label': self.__label,
            'items': self.__items,
            'selected_items': self.__selected_items,
            'disabled_items': self.__disabled_items,
            'mode': self.__mode,
            'description': self.__description,
            'loading': self.__loading,
            'disabled': self.__disabled,
            'invalid': self.__invalid,
            'error_message': self.__error_message,
            'onChange': self.__onChange,
            'margin': self.__margin,
            'full_width': self.__full_width,
            'visible': self.__visible,
        }


class Checkbox:
    """The checkbox component. Registry L3278 (ctor) / L3375
    (render)."""

    def __init__(self, parent_tab_name, tab_updater, label,
                 checked, disabled, invalid, onChange, visible):
        """Registry L3278 (Checkbox.__init__). Content: chunk
        labeled L3375 — decompiled as a merged region (dossier
        pass queued); the SIGNATURE is live const-pool evidence
        [E:]: slot 1440 = ('self', 'parent_tab_name',
        'tab_updater', 'label', 'checked', 'disabled', 'invalid',
        'onChange', 'visible').

        [E:] consts: _Checkbox__tab_updater (GOT_1441) +
             _Checkbox__onChange (GOT_1442); the render consumes
             id, listener_id, parent_tab_name, checked, label,
             disabled, invalid, visible. The ('new_checked',)
             tuple (slot 1443) marks a checked-setter listener
             nearby in the registry. Flag (partial): the ctor body
             is dossier-queued; the cascade below is
             sig-faithful only.
        """
        self.__id = str(uuid.uuid4())
        self.__parent_tab_name = parent_tab_name
        self.__tab_updater = tab_updater
        self.__label = label
        self.__checked = checked
        self.__disabled = disabled
        self.__invalid = invalid
        self.__visible = visible
        self.__onChange = onChange

    def render(self):
        """Registry L3375 (Checkbox.render). Content: chunk
        labeled L3392 (stream section function@L3375).

        [E:] the label gate: __label (GOT_1427) + the truth
             select + the compare against '' (GOT_241, L82-123) →
             ValueError('Checkbox label cannot be empty') — EXACT
             GOT_1428, NO trailing period (L346-357).
        [E:] the emitted dict: 'type' (GOT_248) = 'checkbox'
             (GOT_1432); 'id' (GOT_265) + __id (GOT_1433);
             'listener_id' (GOT_1429) + __listener_id (GOT_1434);
             'parent_tab_name' (GOT_1282) + __parent_tab_name
             (GOT_1435); 'checked' (GOT_1430) + __checked (GOT_
             1436); 'label' (GOT_313) + __label (GOT_1427);
             'disabled' (GOT_358) + __disabled (GOT_1437);
             'invalid' (GOT_1431) + __invalid (GOT_1438);
             'visible' (GOT_1365) + __visible (GOT_1439).
        """
        if not self.__label or self.__label == '':
            raise ValueError('Checkbox label cannot be empty')
        return {
            'type': 'checkbox',
            'id': self.__id,
            'listener_id': self.__listener_id,
            'parent_tab_name': self.__parent_tab_name,
            'checked': self.__checked,
            'label': self.__label,
            'disabled': self.__disabled,
            'invalid': self.__invalid,
            'visible': self.__visible,
        }


def ui_element_instance_checker(element):
    """Registry L3659. Content: chunk labeled L3667 — recovered
    from the interior bytes of chunk 3667 (dump file
    chunk3667_ui_element_instance_checker_L3659.txt; the
    'file merged/absent' verdict was a boundary artifact — the
    chunk decodes at alignment +1).

    A pure validator: raises ValueError when element is not one
    of the eight UI element classes; returns None when it is.

    [E:] signature ('element',) — const-pool tuple slot 1348
         with the GOT_000 frame-enter op.
    [E:] the isinstance builtin staged (slot 168), then the
         class roster gathered attr-by-attr from the UI module
         global (staged name 'UI', GOT_1349): Button (GOT_312),
         Text (GOT_1350), Input (GOT_1351), Image (GOT_1352),
         Toggle (GOT_1353), Select (GOT_1354), Checkbox (GOT_
         1355), Table (GOT_1356) — eight GetAttr chains.
    [E:] the 8-tuple build: SUBGOT_a9d18 kind-1 count-8 at
         0x39786-0x397a0 (pieces in r8/r9 + six stack slots).
    [E:] the isinstance call: the 2-piece args pack (element,
         the tuple) built kind-1 count-2, called via SUBGOT_
         a9d20 with the staged isinstance (0x397df).
    [E:] the invert-idiom: IsTrue of the result chooses
         CONST[31] True on false / CONST[32] False on true
         (0x397f5-0x3982e), re-IsTrue'd — so the raise fires
         when element is NOT a UI element.
    [E:] the raise path: ValueError staged (GOT_1187) built
         with the message tuple (GOT_1357, 0x398e7), the
         exception raised through GOT_001 with the frame at
         0x39913. The message text is EXACT: 'Invalid element
         type provided. Cards can only hold Groups or
         UIElements. Groups can only hold UIElements or nested
         groups'.
    """
    if not isinstance(
            element,
            (UI.Button, UI.Text, UI.Input, UI.Image, UI.Toggle,
             UI.Select, UI.Checkbox, UI.Table)):
        raise ValueError(
            'Invalid element type provided. Cards can only hold '
            'Groups or UIElements. Groups can only hold '
            'UIElements or nested groups')
