"""
voice_mute_view.py — the voice-mute View pair from the SPP
native core (registry L10039-L10111), recovered from the island
bytes of chunks 10101/10111/10452, cross-checked against the
complete stream sections. The registry interleaves TWO discord
View classes: the list-management view (one method) and the
behavior-settings view (embed before render), pinned by the
callback families and the embed title:
'discord_bot.ui.Button' families, clear_items/add_item, the
instance-SetAttr callbacks (ui.Button takes NO callback kwarg).

  VoicemuteListView       render() (L10039) — the five list
                          buttons: Status/Mode/Add/Remove/Clear
  VoicemuteSettingsView   embed()  (L10101) — the 'Voicemute »
                          Settings' description panel
                          render() (L10111) — the four toggle
                          buttons: Non-friends/Mute on join/
                          Apply to new users/Unmute on leave

CLASS NAME FLAG: no live const names either class — the views
mount under descriptive names; rename when a booter island
stages the class-name consts.
"""

import logging  # noqa: F401


class VoicemuteListView:
    """The list-management panel: Status/Mode/Add/Remove/Clear."""

    def render(self):
        """Registry L10039. Content: chunk L10101 — recovered from
        the island bytes of chunk 10101 (@0x98e70, 321 events);
        the stream section (function@L10039, corpus lines
        26620-26621) is a merged region (decomp file absent), so
        the island carries the whole decode.

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x98e9a with the GOT_000 binder
            (r8d=1) at 0x98ec6; self at [rsp+0x78] for the
            whole body.
        [E:] THE RESET — GetAttr 'clear_items' (CONST[307]),
            zero-arg call 0x98f3f, result DecRef'd (a statement
            call).
        [E:] THE CONFIG — the 'getVoiceMuteConfig' CONST[308]
            name-load, zero-arg call; GetItem 'list'
            (CONST[344]) -> [rsp+0x80] — the config local.
        [E:] BUTTON LAW — every button walks 'discord_bot'
            (CONST[310]) -> 'ui' (CONST[311]) -> 'Button'
            (CONST[312]) and builds a kind-3 kwargs dict
            (buttons 1-3 edx=2; buttons 4-5 edx=3); the class
            call stages r8d=0/r9d=1 (kwargs, no positional);
            SET-ATTR on the INSTANCE stores the callback
            ('callback' CONST[323] + '_toggle_enabled'
            CONST[350] etc.) — ui.Button takes NO callback
            kwarg (the pair count proves it); finally GetAttr
            self.add_item (CONST[324]) with the 1-arg button
            tuple.
        [E:] BUTTON 1 — label = the a9d48 join of 'Status: '
            (CONST[345]) + the config['enabled'] ternary
            ('ON' CONST[347] / 'OFF' CONST[348]); style =
            discord_bot.ButtonStyle.green if config['enabled']
            else .red (CONST[320]/'green' CONST[329] vs 'red'
            CONST[349]; ButtonStyle hangs OFF discord_bot, NOT
            discord_bot.ui); the second config['enabled']
            GetItem re-evaluated (no CSE); instance
            [rsp+0x88], callback SetAttr 0x99470, add_item
            0x99549.
        [E:] BUTTON 2 — label = the 2-piece join 'Mode: '
            (CONST[351]) + config['mode'].capitalize()
            (GetItem 'mode' CONST[352], GetAttr 'capitalize'
            CONST[353], zero-arg call); style =
            ButtonStyle.primary (CONST[321]); instance
            [rsp+0x90], callback SetAttr '_toggle_mode'
            (CONST[354] 0x998db), add_item 0x9999d.
        [E:] BUTTON 3 — label 'Add ID(s)' (CONST[355]); style
            ButtonStyle.secondary (CONST[330]); dict edx=2;
            instance [rsp+0x98], callback SetAttr '_add_id'
            (CONST[356] 0x99c39), add_item 0x99cff.
        [E:] BUTTON 4 — label 'Remove ID(s)' (CONST[357]);
            style secondary; disabled = not config['ids']:
            GetItem 'ids' (CONST[359]), IsTrue, the falsy-list
            -> materialized True (law 8); dict edx=3; instance
            [rsp+0xa0], callback SetAttr '_remove_id'
            (CONST[360] 0xa06b), add_item 0x9a12d.
        [E:] BUTTON 5 — label 'Clear list' (CONST[361]);
            style secondary; disabled = the duplicate
            not-config['ids'] text with the SAME consts; dict
            edx=3; instance [rsp+0xa8], callback SetAttr
            '_clear' (CONST[362] 0xa48d), add_item 0x9a62b.
        [E:] THE TAIL — the five [rsp+0x88]/[0x90]/[0x98]/
            [0xa0]/[0xa8] locals stay live to the epilogue
            (DecRefs 0x9a513-0x9a56c — five DISTINCT fastlocal
            slots = five distinct source names); success path:
            PyErr_Occurred / PyErr_Clear / CONST[30] None =
            IMPLICIT return (no explicit return statement).

        FLAG: the five button locals' names are not carried —
            button1..button5 are stand-ins for five distinct
            fastlocals; the `config` local is name-inferred
            (the [rsp+0x80] slot).
        """
        self.clear_items()
        config = getVoiceMuteConfig()['list']
        button1 = discord_bot.ui.Button(
            label=f'Status: {"ON" if config["enabled"] else "OFF"}',
            style=discord_bot.ButtonStyle.green
            if config['enabled'] else discord_bot.ButtonStyle.red)
        button1.callback = self._toggle_enabled
        self.add_item(button1)
        button2 = discord_bot.ui.Button(
            label=f'Mode: {config["mode"].capitalize()}',
            style=discord_bot.ButtonStyle.primary)
        button2.callback = self._toggle_mode
        self.add_item(button2)
        button3 = discord_bot.ui.Button(
            label='Add ID(s)',
            style=discord_bot.ButtonStyle.secondary)
        button3.callback = self._add_id
        self.add_item(button3)
        button4 = discord_bot.ui.Button(
            label='Remove ID(s)',
            style=discord_bot.ButtonStyle.secondary,
            disabled=not config['ids'])
        button4.callback = self._remove_id
        self.add_item(button4)
        button5 = discord_bot.ui.Button(
            label='Clear list',
            style=discord_bot.ButtonStyle.secondary,
            disabled=not config['ids'])
        button5.callback = self._clear
        self.add_item(button5)


class VoicemuteSettingsView:
    """The behavior-settings panel: the embed + four toggles."""

    def embed(self):
        """Registry L10101. Content: chunk L10111 — recovered from
        the island bytes of chunk 10111 (@0x9a690 +1536),
        cross-checked against the complete stream section
        (function@L10101, corpus lines 26623-26714). MEMBER OF
        THE SETTINGS VIEW: the title CONST[343] 'Voicemute »
        Settings' pins the class identity; its render twin sits
        at L10111.

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x9a6a7 with the GOT_000 binder
            (r8d=1).
        [E:] THE SETTINGS — the 'getVoiceMuteConfig' CONST[308]
            name-load, zero-arg call, then GetItem 'settings'
            (CONST[309]) — getVoiceMuteConfig()['settings'].
        [E:] THE DESCRIPTION — the a9d48 build over 8
            source-order pieces (4 literals + 4 pre-built
            dynamic ternaries): '**Users other than friends**: '
            (CONST[338]) + the settings['non_friends_action']
            (CONST[315]) sel-2 vs 'automute' (CONST[316])
            ternary ('Auto mute' CONST[317] / 'Do nothing'
            CONST[318]); CONST[339] '\\n**Auto mute when you
            join a voice channel**: ' + the settings[
            'automute_on_join'] (CONST[326]) ternary ('On'
            CONST[327] / 'Off' CONST[328]); CONST[340] '\\n**
            Auto apply to new users joining your channel**: '
            + settings['auto_apply_new_users'] (CONST[333]);
            CONST[341] '\\n**Auto unmute when a user or you
            leaves**: ' + settings['auto_unmute_on_leave']
            (CONST[336]).
        [E:] THE RETURN — the 'voiceMuteEmbed' CONST[342]
            MODULE name-load (0x9ab59) called with the 2-tuple
            r8='Voicemute » Settings' CONST[343] (0x9ab8e) +
            the description — return voiceMuteEmbed('Voicemute
            » Settings', description); the CONST[30] None is
            the epilogue fallback.

        FLAG: the settings/description local names are
            inferred.
        """
        settings = getVoiceMuteConfig()['settings']
        description = (
            f"**Users other than friends**: "
            f"{'Auto mute' if settings['non_friends_action'] == 'automute' else 'Do nothing'}"
            f"\n**Auto mute when you join a voice channel**: "
            f"{'On' if settings['automute_on_join'] else 'Off'}"
            f"\n**Auto apply to new users joining your channel**: "
            f"{'On' if settings['auto_apply_new_users'] else 'Off'}"
            f"\n**Auto unmute when a user or you leaves**: "
            f"{'On' if settings['auto_unmute_on_leave'] else 'Off'}")
        return voiceMuteEmbed('Voicemute » Settings', description)

    def render(self):
        """Registry L10111. Content: chunk L10452 — recovered from
        the island bytes of chunk 10452 (dump file
        chunk10452_render_10111.txt, @0x9ac90 +5904, +0 align,
        309 events, 1547 insns, read complete), cross-checked
        against the stream section (function@L10111; the
        decomp-file mapping spp_span__backupsPath_10452.c is a
        merged-region marker, so the island carries the decode).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x9acbe with the GOT_000 binder
            (r8d=1) at 0x9acea.
        [E:] THE RESET — GetAttr 'clear_items' (CONST[307]
            staged 0x9ad0b), zero-arg call 0x9ad63, result
            DecRef'd.
        [E:] THE CONFIG — the 'getVoiceMuteConfig' CONST[308]
            name-load + zero-arg call, then the GetItem
            'settings' (CONST[309] staged 0x9adce) —
            getVoiceMuteConfig()['settings'] stored [rsp+0x80]
            (THE SETTINGS TWIN of the L10039 render's ['list']).
        [E:] BUTTON 1 — the discord_bot.ui.Button walk
            (CONST[310]/[311]/[312] staged 0x9ae36-0x9aebf);
            label = the a9d48 join of 'Non-friends: '
            (CONST[314]) + the settings['non_friends_action']
            (GetItem CONST[315] 0x9af46) sel-2 vs 'automute'
            (CONST[316]) ternary ('Auto mute' CONST[317] /
            'Do nothing' CONST[318]); style =
            discord_bot.ButtonStyle.primary (CONST[320] +
            'primary' CONST[321]); the callback SetAttr
            '_toggle_non_friends' (CONST[322] staged
            0x9b163) over the instance [rsp+0x88]; self
            .add_item (CONST[324]) with the 1-arg tuple.
        [E:] BUTTON 2 — label = 'Mute on join: ' (CONST[325])
            + the settings['automute_on_join'] (CONST[326])
            ternary ('On' CONST[327] / 'Off' CONST[328],
            address-locked 0x9b41a-0x9b44a); style = the
            TERNARY green (CONST[329]) if settings[
            'automute_on_join'] (the GetItem re-evaluated
            0x9b48f — no CSE) else secondary (CONST[330]);
            callback SetAttr '_toggle_join' (CONST[331] staged
            0x9b6cf); the [rsp+0x90] instance; add_item.
        [E:] BUTTON 3 — label = 'Apply to new users: '
            (CONST[332]) + the settings['auto_apply_new_users']
            (CONST[333]) ternary; style = the same green/
            secondary ternary over [333] re-evaluated; callback
            SetAttr '_toggle_new_users' (CONST[334] staged
            0x9bc12); the [rsp+0x98] instance; add_item.
        [E:] BUTTON 4 — label = 'Unmute on leave: '
            (CONST[335]) + the settings['auto_unmute_on_leave']
            (CONST[336]) ternary; style = the same green/
            secondary ternary over [336]; callback SetAttr
            '_toggle_unmute_leave' (CONST[337] staged
            0x9c152); the [rsp+0xa0] instance; add_item; then
            the epilogue — FOUR button fastlocals DecRef
            ([0x88]/[0x90]/[0x98]/[0xa0], 0x9c238-0x9c283), the
            r14b error flag, PyErr_Occurred/Clear + CONST[30]
            None = the IMPLICIT return.

        FLAG: the four button locals' names are not carried —
            button1..button4 are stand-ins; the `settings` local
            is name-inferred ([rsp+0x80]).
        """
        self.clear_items()
        settings = getVoiceMuteConfig()['settings']
        button1 = discord_bot.ui.Button(
            label=f"Non-friends: "
                  f"{'Auto mute' if settings['non_friends_action'] == 'automute' else 'Do nothing'}",
            style=discord_bot.ButtonStyle.primary)
        button1.callback = self._toggle_non_friends
        self.add_item(button1)
        button2 = discord_bot.ui.Button(
            label=f"Mute on join: "
                  f"{'On' if settings['automute_on_join'] else 'Off'}",
            style=discord_bot.ButtonStyle.green
            if settings['automute_on_join']
            else discord_bot.ButtonStyle.secondary)
        button2.callback = self._toggle_join
        self.add_item(button2)
        button3 = discord_bot.ui.Button(
            label=f"Apply to new users: "
                  f"{'On' if settings['auto_apply_new_users'] else 'Off'}",
            style=discord_bot.ButtonStyle.green
            if settings['auto_apply_new_users']
            else discord_bot.ButtonStyle.secondary)
        button3.callback = self._toggle_new_users
        self.add_item(button3)
        button4 = discord_bot.ui.Button(
            label=f"Unmute on leave: "
                  f"{'On' if settings['auto_unmute_on_leave'] else 'Off'}",
            style=discord_bot.ButtonStyle.green
            if settings['auto_unmute_on_leave']
            else discord_bot.ButtonStyle.secondary)
        button4.callback = self._toggle_unmute_leave
        self.add_item(button4)
