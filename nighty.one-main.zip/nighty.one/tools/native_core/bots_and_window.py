"""
bots_and_window.py — the bots manager + main-window helpers
(registry L4548-L4933), recovered via the Ghidra decomp lane.

  class BotsManager                — the action/bots manager
                                      (NAME FLAG: descriptive —
                                      the class name is not
                                      recovered; the evidenced
                                      attrs define the role:
                                      tokens/bots/connected_
                                      bots/servers/action_queue)
  show_main_window()               — main_api.show()
  hide_main_window()               — main_api.hide()
"""

import asyncio

import discord


class BotsManager:
    """The action-queue + bots manager."""

    def __init__(self, tokens):
        """Registry L4927 (bots manager constructor). Content:
        chunk labeled L4933 (resynced lane-2 decomp
        sppL2_run_bots_4933.c). Signature ('self', 'tokens')
        [E:] — const-pool tuple slot 1185, adjacent to the bots
        cluster ('tokens' 1176, 'bots' 1183, 'connected_bots'
        1186).

        [E:] four attribute assignments via PyObject_SetAttr on
             the self slot, in order (raw L37-101): self.tokens =
             tokens (the parameter); self.bots = [] (the
             dispatcher-built empty list, (2,0) build at L63);
             self.connected_bots = 0 (int-0 const GOT_277);
             self.servers = 0.
        [E:] any SetAttr failure exits through a shared
             silent-error path: PyErr_Occurred/PyErr_Clear +
             None (L110-121); the function returns None.
        """
        self.tokens = tokens
        self.bots = []
        self.connected_bots = 0
        self.servers = 0

    def enqueue_action(self, action):
        """Registry L4548. Content: chunk labeled L4552 (the
        resynced lane-2 decomp sppL2_process_actions_4552.c —
        the span label names the NEXT registry entry; the body
        belongs to THIS one). Signature ('self', 'action')
        [E:] — const-pool tuple slot 1224, directly adjacent to
        this body's const cluster ('action_queue' 1223, 'put'
        1225).

        [E:] self.action_queue — GetAttr(self, 'action_queue')
             (raw L34-48, GOT_1223); .put — GetAttr (L53-60,
             GOT_1225); the (1,1) args build over the `action`
             parameter slot + the 1-positional-arg call (L63-69).
        [E:] the put result is consumed bare (DecRef without
             store, raw L76) — a pure side-effect call; the tail
             clears any pending error and returns None (L79-88).
        """
        self.action_queue.put(action)

    def process_actions(self):
        """Registry L4552. Content: chunk labeled L4558 (stream
        section function@L4552).

        [E:] self.action_queue GetAttr (GOT_1223, L22-27);
             .empty() GetAttr (GOT_1132 'empty', L31-37) + call;
             the negated-truth select (IsTrue + True/False
             consts, L43-52) — `if not self.action_queue.
             empty():`; self.action_queue.get() (second attr
             load L54-86 + 'get' GOT_047, L90-96) fed directly to
             the return-op (L105) — the dequeued action is
             returned.
        [E:] flag: the tail (L109-130) holds further
             action_queue references and call ops after the
             primary return — read as the empty-case/alternate
             exits; the empty-case return default reads None
             (silent-None cluster at the family-standard
             position); flagged.
        """
        if not self.action_queue.empty():
            return self.action_queue.get()
        return None

    def run_bots(self):
        """Registry L4933. Content: chunk labeled L5007 (stream
        section function@L4933).

        [E:] loop = asyncio.get_event_loop() (GOT_393 'asyncio',
             GOT_1175 get_event_loop, L36-55); iterate self.tokens
             (GOT_1176 + GetIter/a9d60, L67-91);
             client = discord.Client(chunk_guilds_at_startup=
             False, afk=True) (GOT_1177/1178 + the two kwarg keys
             GOT_1179/1180 with False/True consts, L98-132);
             client.event(create_on_connect_handler()) ('event'
             GOT_489 + GOT_1181, L140-189); client.event(
             create_on_message_handler()) (GOT_1182, L200-244);
             self.bots.append(client) (GOT_1183 + GOT_250,
             L255-286); loop.create_task(client.start(<token>))
             (GOT_394 create_task + 'start' GOT_082 with the
             1-arg build, L295-339 — the arg is the loop token);
             all inside try-machinery (DAT_000a9d40 pairs,
             L348-394).
        [E:] loop.run_forever() (GOT_1184, L420-438); silent
             None.
        [E:] flag: the two DAT_000a9d40 clusters (L348-394) +
             the re-raise dispatch and a None-returning handler
             at L402-413 sit between the loop machinery and
             run_forever in the decompiler layout; the try-block
             bounds (around the per-token create_task, per the
             exception-fetch positions) are flagged —
             translated flat.
        """
        loop = asyncio.get_event_loop()
        for token in self.tokens:
            client = discord.Client(
                chunk_guilds_at_startup=False, afk=True)
            client.event(create_on_connect_handler())
            client.event(create_on_message_handler())
            self.bots.append(client)
            loop.create_task(client.start(token))
        loop.run_forever()


def show_main_window():
    """Registry L4558. Content: chunk labeled L4566 (stream
    section function@L4558).

    [E:] main_api.show() — the main_api global (GOT_038) +
         'show' (GOT_650) GetAttr + the 0-arg call +
         return-dispatch (L18-44); silent None with PyErr clear
         (L49-55).
    """
    main_api.show()


def hide_main_window():
    """Registry L4566. Content: chunk labeled L4570 (stream
    section function@L4566).

    [E:] identical shape with 'hide' (GOT_648) — main_api.hide(),
         L18-44; silent None.
    """
    main_api.hide()
