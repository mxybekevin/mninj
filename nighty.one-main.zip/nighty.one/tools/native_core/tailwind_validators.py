"""
tailwind_validators.py — the UI tailwind class generator and the
value validators (registry L2199-L2223), recovered from the
island byte dumps of chunks 2209/2215/2223 (the raised-cap
re-snatch session backing the consts), cross-checked against the
complete stream sections. SUPERSEDE NOTE: the earlier corpus-only
draft carried three misreadings that the island bytes now
contradict — the seven-side list is ONE a9d18 edx=7 build with
'' first (not a split seed-plus-sides pair) and the join is a
single a9d48 f-string (zero a9d10 add sites, not '+'
concatenation); the gap bounds are the opcode pair edx=0 ('<') /
edx=4 ('>') with the success arm staging None (not a chained
comparison returning gap_value); variant_validator opens with
the falsy gate staging None and its message is one five-piece
a9d48 f-string. All three corrected drafts carry the island
address chains.

  generate_tailwind_classes(prefix) — the '',t,r,b,l,x,y × 0..10
      class family builder (a single f-string join)
  _gap_validator(gap_value) — 0..10 bounds or ValueError
  variant_validator(valid_variants, value) — falsy gate +
      space-strip + membership
  margin_padding_validator(valid_classes, value) — per-token
      membership over value.split(' ') — the corpus-only draft
      body below is PENDING its island pass (chunk 2235): the
      sibling trio's corrections (the f-string joins, the
      falsy-gate idiom) may apply to it too; verify before
      trusting its exact emission details.
"""


def generate_tailwind_classes(prefix):
    """Registry L2199 (and its first-registration mirror Registry L2168 - identical const-dedup event stream, corpus lines 5958-6013 vs 6113-6168, the same const slots at the same event ordinals; this island-verified body resolves both). Content: chunk L2209 — recovered from the
    island bytes of chunk 2209 (chunk2209_generate_tailwind_classes_
    L2199.txt, @0x23e80, alignment +0, 55 events, 314 insns, read
    complete through the _gap_validator entry at 0x24340),
    cross-checked against the complete stream section
    (function@L2199, corpus lines 6113-6168, events 29-208).

    [E:] THE SIGNATURE — the names-tuple CONST[1581] ('prefix',)
        staged 0x23e9f with the GOT_000 binder (r8d=1) at 0x23ecb.
    [E:] classes = [] — a9d18 kind-2 (ecx=2) with edx=0 items at
        0x23ee2, parked in frame slot [rsp+0x70]; it is the
        '.append' receiver (0x2410f) and the returned object
        (0x24320). Corpus event 37.
    [E:] THE SIDES LIST — ONE a9d18 kind-2 build, edx=7 items,
        called 0x23f98: r8=CONST[241] '' (0x23f0f), r9=CONST[1582]
        't' (0x23f1e), frame slots [rsp+0x20..0x40] staged in order
        with CONST[283] 'r' (0x23f2d), CONST[1583] 'b' (0x23f3b),
        CONST[1584] 'l' (0x23f49), CONST[1585] 'x' (0x23f58),
        CONST[1586] 'y' (0x23f67) — insertion order = frame order
        (law 3) -> ['', 't', 'r', 'b', 'l', 'x', 'y'], the ''
        FIRST. Corpus events 46-69.
    [E:] OUTER LOOP — GetIter (GOT_027) 0x23fce over that
        7-list, a9d60 iternext 0x23ff0, loop var [rsp+0x80],
        re-entry 0x23feb; loop exit checks PyErr_Occurred
        0x24273. Corpus events 77-83.
    [E:] range(11) — 'range' CONST[1587] loaded 0x24021 through
        the a9d50 name-stage 0x2403e (LOAD_GLOBAL); args tuple
        a9d18 kind-1 edx=1 staging r8=CONST[1588] 11 (0x2405b);
        a9d20 call 0x24094; GetIter 0x240a3; iternext 0x240c1
        slot [rsp+0x88]. Corpus events 101-119.
    [E:] classes.append — GetAttr(classes, CONST[250] 'append')
        0x24115; args tuple a9d18 kind-1 edx=1 at 0x241fa over
        the f-string; call 0x2421b. Corpus events 126-143.
    [E:] THE F-STRING — a9d48 (BUILD_STRING, law 4): dynamic
        pre-builds with r8d=-1 over prefix [rsp+0x68] (0x2417d),
        side [rsp+0x80] (0x241a3), size [rsp+0x88] (0x241d9);
        finalize 0x241ee ecx=4: rdx=prefix, r8=side, r9=CONST
        [1589] '-' (0x241a8), frame piece=size ->
        f'{prefix}{side}-{size}'. Corpus events 147-162. NO
        DAT_a9d10 (BINARY_ADD) event anywhere in the section —
        the join is a single f-string, not '+' concat.
    [E:] THE RETURN — clean loop-exit arm 0x24316 increfs and
        steals [rsp+0x70] (bl=0, rsi=classes, 0x2432e-0x24332)
        -> epilogue rax=rsi: explicit return of the built list.
        Error arms keep bl=1 -> a9d28 ret-disp(ecx=1) 0x242da.
        Corpus events 199-208.

    FLAG: the names classes / side / size are slot-inferred (the
        frame slots carry no name consts); the 7-item list is
        drafted inline (the edx=7 build is immediately GetIter'd
        at 0x23f98 -> 0x23fce; a named local before the loop is
        not distinguishable from an inline literal).
    """
    classes = []
    for side in ['', 't', 'r', 'b', 'l', 'x', 'y']:
        for size in range(11):
            classes.append(f'{prefix}{side}-{size}')
    return classes


def _gap_validator(gap_value):
    """Registry L2209 (and its first-registration mirror Registry L2178 - identical const-dedup event stream, corpus lines 6015-6051 vs 6170-6207; this body resolves both). Content: chunk L2215 — recovered from the
    island bytes of chunk 2215 (chunk2215__gap_validator_L2209.txt,
    @0x24380, alignment +0, 29 events, 160 insns, read complete
    through the variant_validator entry at 0x245c0), cross-checked
    against the complete stream section (function@L2209, corpus
    lines 6170-6207, events 19-109).

    [E:] THE SIGNATURE — the names-tuple CONST[1579] ('gap_value',)
        staged 0x24386 with the GOT_000 binder (r8d=1) at 0x243b1.
    [E:] BOUND COMPARE 1 — a9d30 0x243e9: r8=[rsp+0x58] gap_value
        (0x243c6), r9=CONST[277] 0 (0x243d3), edx=0 -> CPython
        richcompare Py_LT (law-5's enum: 2 '==' 3 '!=' 4 '>' 5
        '>=' map Py_EQ/Py_NE/Py_GT/Py_GE, so 0 = Py_LT '<'):
        gap_value < 0. Corpus events 22-31.
    [E:] THE 'or' — py38 or-chain rendered as falsy-materialize
        phis: IsTrue 0x243fa, keep-if-truthy else load CONST[32]
        False 0x2440a; second IsTrue 0x2441f, FALSE -> second
        compare arm 0x24487. Corpus events 35-43.
    [E:] BOUND COMPARE 2 — a9d30 0x244bd: r8=gap_value
        (0x24497), r9=CONST[1162] 10 (0x244a4), edx=4 = Py_GT
        '>' (law 5): gap_value > 10; IsTrue 0x244ce + CONST[32]
        False phi 0x244de; both truth arms converge at the
        final decision (jns 0x2442f). Corpus events 47-64.
    [E:] THE DECISION — final IsTrue 0x2442f over the chain
        value: TRUE (gap_value < 0 or gap_value > 10) -> raise
        arm 0x24506; FALSE -> success arm 0x24454. NOT a chained
        `not 0 <= gap_value <= 10`: that compiles two Py_LE
        (edx=1) compares; observed opcodes are 0 and 4.
    [E:] THE RAISE — 'ValueError' CONST[1187] staged 0x24514,
        name-loaded via a9d50 0x24530; message tuple a9d18
        kind-1 edx=1 over CONST[1580] 'Gap value must be between
        0 and 10' (0x2454d); call 0x24584 -> ValueError(msg);
        GOT_001 raise helper called 0x24592 (r8d=0); error arms
        tail to a9d28(ecx=1) 0x245a4. Corpus events 69-97, 109.
    [E:] THE RETURN — success arm 0x24454 DecRefs the parameter
        (no value steal), PyErr_Occurred 0x2445f / PyErr_Clear
        0x2446a, then stages CONST[30] None in-body 0x24470 ->
        return None. Corpus events 75-83.

    FLAG: the trailing `return None` — the in-body CONST[30]
        staging maps to an explicit return (byte-identical to a
        bare `return`); edx=0 '<' extends law 5 by the CPython
        richcompare enum (Py_LT).
    """
    if gap_value < 0 or gap_value > 10:
        raise ValueError('Gap value must be between 0 and 10')
    return None


def variant_validator(valid_variants, value):
    """Registry L2215 (and its first-registration mirror Registry L2184 - identical const-dedup event stream, corpus lines 6053-6108 vs 6208-6264; this body resolves both). Content: chunk L2223 — recovered from the
    island bytes of chunk 2223 (chunk2223_variant_validator_
    L2215.txt, @0x24600, alignment +0, 45 events, 280 insns, read
    complete through the margin_padding_validator entry at
    0x249e0), cross-checked against the complete stream section
    (function@L2215, corpus lines 6208-6264, events 30-202).

    [E:] THE SIGNATURE — the names-tuple CONST[1576]
        ('valid_variants', 'value') staged 0x24618 with the
        GOT_000 binder (r8d=2) at 0x24644; frame [rsp+0x58]
        valid_variants, [rsp+0x60] value.
    [E:] THE FALSY GATE — IsTrue(value) 0x24668 -> phi
        materialized per the not-swap (law 8): truthy arm loads
        CONST[32] False 0x24683, falsy arm loads CONST[31] True
        0x24694 (the value IS consumed at 0x24673) -> `not
        value`; IsTrue 0x246a9: TRUE arm 0x246f9 stages CONST[30]
        None 0x24703, ebp=0, RETURNS None past the fallback ->
        `if not value: return None`. Corpus events 46-58,
        176-179.
    [E:] THE STRIP — GetAttr(value, CONST[237] 'replace')
        0x246ee; args a9d18 kind-1 edx=2 staging r8=CONST[243]
        ' ' (0x2474c) and r9=CONST[241] '' (0x2475b); call
        0x24794; result stored back into [rsp+0x60]
        0x247a0-0x247a5 -> value = value.replace(' ', ''). Two-arg
        call calibrated against the KNOWN two-arg
        text.replace('_', '\\_') of escape_markdown@L7854
        (island 0x76235-0x7623e shows the same a9d18 edx=2 +
        a9d20 r8d=1 plumbing). Corpus events 61-89.
    [E:] THE MEMBERSHIP GATE — a9d30 call 0x247ed: r8=[rsp+0x60]
        the stripped value, r9=[rsp+0x58] valid_variants, edx=7
        (law-5 in-family). Truth flow: IsTrue 0x247fb + False phi
        0x24807; final IsTrue 0x24818: TRUE -> raise arm 0x248ae,
        FALSE -> success arm 0x24832. Reversed operand order is
        excluded (an `in` reading would raise on VALID values,
        contradicting the raised message); truthy->raise forces
        `not in`: `if value not in valid_variants:`. Corpus
        events 98-119.
    [E:] THE RAISE MESSAGE — ONE a9d48 BUILD_STRING finalize
        0x2498a, ecx=5 pieces in source order: piece1 = the
        CONST[1577] text (0x24901, 15 chars: "Invalid value: "),
        piece2 dynamic value pre-build r8d=-1 over [rsp+0x60]
        (0x24930), piece3 the CONST[1578] text (0x24935 — 21
        chars, NO quote marks: the repr delimiters are NOT
        content; the first draft mis-read them as apostrophes and
        the byte-audit hex-probe corrected it; the live body
        carries the corrected text), piece4 dynamic
        valid_variants pre-build over [rsp+0x58] (0x24962),
        piece5 CONST[808] '.' (0x24964, frame [rsp+0x28]) ->
        an f-string, NOT '+' concat (again zero a9d10 sites).
        'ValueError' CONST[1187] name-staged via a9d50 0x248dd;
        tuple wrap a9d18 kind-1 0x2499a; call 0x249bb; GOT_001
        raise 0x249c9 (r8d=0) -> error tail bpl=1 -> a9d28(ecx=1)
        0x2485f. Corpus events 121-160, 191.
    [E:] THE TAIL — success arm 0x24832 leaves esi=0 and ebp=0;
        cleanup DecRefs [rsp+0x58]/[rsp+0x60] with NO
        incref-steal of value; pending-err check
        (PyErr_Occurred 0x24888 / PyErr_Clear 0x24893) then the
        GENERIC epilogue None fallback stages CONST[30] 0x2489e.
        No in-body return staging exists on this arm (contrast
        arms 2 and the _gap_validator tail) -> no explicit tail
        return: the function falls off the end (implicit None).
        Corpus events 176-202.

    FLAG: parameter names valid_variants / value are LIVE from
        CONST[1576]; the message's quote style is not
        const-visible (a single-quoted source with \' escapes is
        byte-identical to the drafted double-quoted literal);
        the tail is drafted with NO return statement (a bare
        return / return None compiles identically, flagged);
        valid_variants enters the message via the a9d48 dynamic
        pre-build (auto-str), not an explicit str() call.
    """
    if not value:
        return None
    value = value.replace(' ', '')
    if value not in valid_variants:
        raise ValueError(f"Invalid value: {value}. Valid values "
                         f"are: {valid_variants}.")


def margin_padding_validator(valid_variants, value):
    """Registry L2223 (and Registry L2192, the first registration
    whose chunk-L2199 span decompiled as a merged region — the
    registry names both registrations identically and the const
    pool dedupes their strings; this island-verified body
    resolves both). Content: chunk L2235 — recovered from the
    island bytes of chunk 2235 (dump file
    chunk2235_margin_padding_validator_L2223.txt, +0 align, 44
    events, 260 insns, read complete), cross-checked against the
    complete stream section (function@L2223, corpus lines
    6265-6311, read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[1576]
        ('valid_variants', 'value') staged 0x24a40 with the
        GOT_000 binder (r8d=2) at 0x24a6c — the LIVE tuple, the
        same one variant_validator@L2215 binds; the earlier
        corpus draft's ('valid_classes', 'value') was a
        mis-translation.
    [E:] THE SPLIT — GetAttr over the value param
        ('split' CONST[364] staged 0x24a8d) with the kind-1
        (' ',) args build over CONST[243] 0x24ad2-0x24af4 and
        the one-positional call 0x24b10, the list parked
        [rsp+0x68] (0x24b22-0x24b27); GetIter 0x24b45-0x24b5f,
        the a9d60 iternext loop with the STORE_FAST pattern into
        [rsp+0x70] (0x24b8d-0x24bab).
    [E:] THE MEMBERSHIP — per piece the a9d30 contains with
        edx=7: r8 = the [rsp+0x60] value, r9 = the [rsp+0x58]
        valid_variants (0x24bb1-0x24bda); the truthy arm jumps
        the raise at 0x24c14, the falsy arm materializes
        CONST[32] False (0x24bff) and returns to the iternext —
        `if value not in valid_variants:`.
    [E:] THE RAISE — 'ValueError' CONST[1187] staged 0x24c3b,
        name-loaded via a9d50; the five-piece a9d48 finalize
        (ecx=5, 0x24d19-0x24d27): rdx = CONST[1577], r8 = the
        r8d=-1 pre-built [rsp+0x60] value piece
        (0x24cb6-0x24ccf), r9 = CONST[1578], frame = the
        r8d=-1 pre-built [rsp+0x58] valid_variants piece
        (0x24ce1-0x24cff) and CONST[808] '.' — the piece order
        [1577][value][1578][valid_variants][808], the same
        corrected message shape as variant_validator; the kind-1
        wrap 0x24d29-0x24d36 and the exception call 0x24d55 with
        the GOT_001 raise dispatch 0x24d67 (r8d=0); corpus
        events 106-140.
    [E:] THE TAIL — the loop-exhaust at 0x24c62: the
        PyErr_Occurred check, the clean path clearing r12d and
        jumping the epilogue (0x24c7d) whose r12b test skips the
        ret-disp, the PyErr_Occurred/Clear pair 0x24db5-0x24dc0
        and the CONST[30] None staged 0x24dc6 — the implicit
        None fall-off, NO return statement (the earlier draft's
        `return value` was wrong); the epilogue DecRefs the
        four frame slots [rsp+0x58]/[rsp+0x60]/[rsp+0x68]/
        [rsp+0x70] (0x24d77-0x24d9d).

    FLAG: the loop variable ([rsp+0x70]) is loaded and released
        but NEVER consumed — the compare and both message
        interpolations read the raw value param [rsp+0x60]
        every iteration (an original-source idiosyncrasy,
        emitted as-is; the intended per-piece check would read
        [rsp+0x70]).
    """
    for cls in value.split(' '):
        if value not in valid_variants:
            raise ValueError(f'Invalid value: {value}. Valid '
                             f'values are: {valid_variants}.')
