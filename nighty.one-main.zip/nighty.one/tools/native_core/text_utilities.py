"""
text_utilities.py — the text helper family from the SPP
native core (registry L7657-L7992), recovered from the corpus
event streams plus island dumps. Shipped here complete:

  splitEmbedText(text, limit, max_parts) — the embed splitter
  escape_markdown(text) — the Discord markdown escape pair
  maskString(s)         — the token mask (first 5 chars +
                          escaped-asterisk fill)
  morseTranslate / before / after — the rest of the block
  removeSpoilers(content)      — the spoiler-tag stripper
  getActiveCtxMenus()          — the active context-menu lister
  extract_chat_response(text)  — the AI thinking-tag stripper
"""

import logging  # noqa: F401
import re  # noqa: F401


def escape_markdown(text):
    """Registry L7854 (and Registry L9517, its streaming-tier twin
    — a distinct second function whose island body decodes
    byte-identical: chunk 9645 @0x92fb0, the CONST[227]
    ('text',) names-tuple staged 0x92fb6 with the GOT_000
    binder r8d=1 at 0x92fe1, the two replace walks over
    CONST[237] staged 0x9300a/0x93029/0x930a4: '_' CONST[304]
    onto '\_' CONST[429] then '*' CONST[430] onto '\*'
    CONST[431] — one recovered body resolves both
    registrations). Content: chunk L7857 — recovered from the
    island bytes of chunk 7857 (dump file
    chunk7857_escape_markdown_L7854.txt, @0x76150, alignment
    +0, 22 events, 133 insns, read complete through the
    maskString entry at 0x76330), cross-checked against the
    complete stream section (function@L7854, corpus lines
    20878-20902, read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[227] ('text',)
        staged 0x76156 with the GOT_000 binder (r8d=1) at
        0x76181 — def escape_markdown(text):.
    [E:] THE FIRST ESCAPE — GetAttr over the bound parameter
        [rsp+0x58] with the 'replace' CONST[237] (staged
        0x761aa, resolved through PyObject_GetAttr at
        0x761be; the companion stage at 0x761c9 is the SPP
        null-fold arm, not a third call — corpus events
        25-36), then the kind-1 two-arg build (a9d18,
        ecx=1/edx=2 at 0x76214) staging '_' CONST[304] as r8
        (0x761f6) and '\\_' CONST[429] as r9 (0x76205),
        called through the a9d20 call helper (r14) at
        0x7623e — text.replace('_', '\\_').
    [E:] THE SECOND ESCAPE — GetAttr over the first result
        with 'replace' staged 0x76244 (resolved 0x7625d),
        then the kind-1 two-arg build at 0x7627c staging '*'
        CONST[430] (0x76283) and '\\*' CONST[431] (0x76292),
        called at 0x762c5 — .replace('*', '\\*').
    [E:] THE RETURN — ret-disp (a9d28) at 0x762e4 carrying
        the chained result; corpus events 19-81.
    """
    return text.replace('_', '\\_').replace('*', '\\*')


def maskString(s):
    """Registry L7857. Content: chunk L7887 — recovered from the
    island bytes of chunk 7887 (dump file
    chunk7887_maskString_L7857.txt, @0x76340, alignment +0,
    20 events, 135 insns, read complete through the
    morseTranslate entry at 0x76500), cross-checked against
    the complete stream section (function@L7857, corpus lines
    20904-20926, read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[815] ('s',)
        staged 0x7634c with the GOT_000 binder (r8d=1) at
        0x76378 — def maskString(s):.
    [E:] THE HEAD SLICE — the PySlice-family slot CONST[26]
        called 0x763a1-0x763bd with rcx=NULL (start, None),
        rdx=CONST[598] int-5 (stop), r8d=NULL (step) — the
        slice(None, 5, None) literal — then PyObject_GetItem
        over the bound parameter [rsp+0x58] at 0x763d8 —
        s[:5] (the direction is operand-locked: the start
        slot is the NULL one, the 5 sits in the stop
        position).
    [E:] THE MASK FACTOR — the '\\*' CONST[431] staged
        0x763fa (the SAME escaped-asterisk literal as
        escape_markdown's replacement — the mask renders as
        literal asterisks inside Discord markdown), the
        'len' CONST[267] loaded as a global through the
        a9d50 name stage (r8d=1) at 0x76436-0x76443 with the
        kind-1 [s] wrap built 0x7644c, the len(s) call via
        the a9d20 helper (rbp, staged 0x76412), the
        subtraction of CONST[598] int-5 (staged 0x7648a as
        the second a9d10 operand) — len(s) - 5 — then the
        a9d10 string-repeat of the mask literal over that
        count.
    [E:] THE JOIN — the first a9d10 pointer (r15, staged at
        0x7638e before the slice zone) is the plain plus
        combining s[:5] with the repeated mask —
        s[:5] + '\\*' * (len(s) - 5) — returned through the
        ret-disp (a9d28) at 0x764da; corpus events 24-80.
    """
    return s[:5] + '\\*' * (len(s) - 5)


def morseTranslate(sentence):
    """Registry L7887. Content: chunk L7949 — recovered from the
    island bytes of chunk 7949 (dump file
    chunk7949_morseTranslate_L7887.txt, per the dumper +0
    align, 117 events, 774 insns, read complete through the
    before@L7949 prologue at 0x77430), cross-checked against
    the complete stream section (function@L7887, corpus lines
    20928-21122, read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[735]
        ('sentence',) staged 0x76566 with the GOT_000 binder
        (r8d=1) at 0x76595.
    [E:] THE ACCUMULATOR — the CONST[241] '' staged 0x765a3
        and stored to the [rsp+0x2e0] accumulator slot —
        result = '' (the receiver name is slot-inferred and
        flagged, per the renameRPCPreset convention).
    [E:] THE ITERABLE — sentence.upper(): the 'upper'
        CONST[416] GetAttr over the [rsp+0x2d8] parameter
        resolved 0x765f9, the zero-argument call at 0x76646,
        then the GetIter through the CONST[27] family call
        at 0x76658 binding the [rsp+0x2b8] iterator.
    [E:] THE LOOP — the a9d60 iternext at 0x766b5 (loop head
        0x766ad) binding each char to [rsp+0x2d8]; the loop
        body builds the 36-pair dict LITERAL INLINE (a
        per-iteration construction — the kind-3 a9d18 build
        with ecx=3 at 0x772a9, edx raw-recorded 0x2a, the
        first pair 'A'/'•- ' in the r8/r9 registers and the
        remaining 35 pairs marshalled through the
        [rsp+0x510]-descending frame fill 0x766ee-0x772a4),
        then PyObject_GetItem over the dict and the char at
        0x772e7, then the AUGMENTED concat — SUBGOT_a9d10
        with rcx = the result slot, rdx = the mapped piece,
        r8d = 0xe (the in-place selector) at 0x7768f/0x77348
        — result += piece; the back-edge returns to the
        0x766ad head; corpus events 24-380.
    [E:] THE EXIT — the exhausted iterator falls to
        0x7736f: the PyErr_Occurred check (a clean exit
        loads the [rsp+0x2e0] accumulator 0x7740a-0x77425
        with the success flag clear), the error paths set
        the propagate flag and tail through the ret-disp
        (a9d28) at 0x773c4 — `except`-free: a char missing
        from the table raises KeyError straight out; corpus
        events 371-380.
    [E:] THE TABLE — every value is LIVE from the const
        pool (island annotations + the snatched reprs): the
        dot glyph is U+2022 '•' (const_reprs.json carries
        the escaped \\u2022 repr; the codepoint array
        0x27/0x2022/0x2d/0x20/0x27 for slot 737 settles the
        glyph — earlier console captures showing an
        o-grave were transport artifacts of this pipeline,
        not the source's byte). 'T' reuses the pooled 251
        '- ' and the space key reuses the pooled 243 ' ';
        the '.'-key maps to the pooled 56 ':' — the author's
        own scheme, staged island-side at 0x76d5a and
        0x77671 (both null-fold companioned) and
        repr-verified — NOT the ITU
        '.-.-.-' (flagged: the table's punctuation set is
        the author's choice, quoted verbatim). Each value
        carries its trailing space so the accumulate
        self-separates and words break on ' | '.
    """
    result = ''
    for char in sentence.upper():
        result += {'A': '•- ', 'B': '-••• ', 'C': '-•-• ',
                   'D': '-•• ', 'E': '• ', 'F': '••-• ',
                   'G': '--• ', 'H': '•••• ', 'I': '•• ',
                   'J': '•--- ', 'K': '-•- ', 'L': '•-•• ',
                   'M': '-- ', 'N': '-• ', 'O': '--- ',
                   'P': '•--• ', 'Q': '--•- ', 'R': '•-• ',
                   'S': '••• ', 'T': '- ', 'U': '••- ',
                   'V': '•••- ', 'W': '•-- ', 'X': '-••- ',
                   'Y': '-•-- ', 'Z': '--•• ', ' ': ' | ',
                   '1': '•---- ', '2': '••--- ', '3': '•••-- ',
                   '4': '••••- ', '5': '••••• ', '6': '-•••• ',
                   '7': '--••• ', '8': '---•• ', '9': '----• ',
                   '0': '----- ', '.': ':', '+': '•-•-• ',
                   '=': '-•••- ', '/': '-••-• '}[char]
    return result


def before(value, a):
    """Registry L7949. Content: chunk L7955 — recovered from the
    island bytes of chunk 7955 (dump file
    chunk7955_before_L7949.txt, per the dumper +0 align, 31
    events, 197 insns, read complete through the after@L7955
    prologue at 0x77710), cross-checked against the complete
    stream section (function@L7949, corpus lines 21123-21157,
    read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[732]
        ('value', 'a') staged 0x7747d with the GOT_000
        binder (r8d=2) at 0x774a9.
    [E:] THE FIND — GetAttr over [rsp+0x58] with the 'find'
        CONST[734] (staged 0x774ca, resolved 0x774de; the
        0x774e9 stage is the null-fold companion), the
        kind-1 single-arg build at 0x7750f wrapping
        [rsp+0x60] (a), the call through a9d20 at 0x7754d —
        value.find(a), stored [rsp+0x68] and REUSED for the
        slice (one call in the whole frame — the shipped
        `idx =` local reflects the single computation; a
        source-level double call is excluded by the corpus
        cluster count, SPP CSE flagged as the alternative);
        corpus events 31-55.
    [E:] THE GATE — the -1 operand via the GOT_003
        negative-materializer dispatch over the int-1
        CONST[233] (0x77591-0x775ab, selector 0x1e; the
        unary-negative reading this chain establishes is
        shared with removeRandomChars@L6832 and after@L7955)
        compared through the a9d30 with edx=2 (the Py_EQ
        richcompare opcode — the selector table law: 2 = ==,
        3 = !=, 5 = >=) binding r8 = the find result, r9 =
        -1 — `value.find(a) == -1`; the double IsTrue gates
        0x775ce-0x775fe route the TRUE arm through the
        shared 0x776eb block: the CONST[241] '' staged
        0x776f5 and returned — corpus events 68-92.
    [E:] THE SLICE — the FOUND arm: the PySlice-family slot
        CONST[26] at 0x77629 with the CONST[277] int-0
        staged as the rcx START operand and the [rsp+0x68]
        find result as the rdx STOP (the call 0x7764f), then
        PyObject_GetItem over the [rsp+0x58] value at
        0x7766a — `value[0:idx]` (the explicit [0:idx] form
        matches the staged start; `[:idx]` would leave the
        start slot NULL as in maskString) — returned via the
        ret-disp a9d28 at 0x776b9; corpus events 101-138.
    """
    idx = value.find(a)
    if idx == -1:
        return ''
    return value[0:idx]


def after(value, a):
    """Registry L7955. Content: chunk L7992 — recovered from the
    island bytes of chunk 7992 (dump file
    chunk7992_after_L7955.txt, per the dumper +0 align, 51
    events, 314 insns, read complete through the getAppID
    prologue at 0x77db0), cross-checked against the complete
    stream section (function@L7955, corpus lines 21158-21210,
    read complete).

    [E:] THE SIGNATURE — the names-tuple CONST[732]
        ('value', 'a') staged 0x7776c with the GOT_000
        binder (r8d=2) at 0x77798.
    [E:] THE RFIND — GetAttr 'rfind' CONST[733] over the
        [rsp+0x58] value (staged 0x777b9, resolved 0x777cd),
        the kind-1 [a] build 0x77805-0x7781c (r8=[rsp+0x60]),
        the call at 0x7783c — value.rfind(a), stored
        [rsp+0x68]; corpus events 31-55.
    [E:] THE NOT-FOUND GATE — the GOT_003 negative of the
        1-const (0x77881-0x7789b) against the rfind result
        through the a9d30 edx=2 (Py_EQ; r8 = the rfind
        result, r9 = -1) at 0x778ad, the gates
        0x778be-0x778ff sending the TRUE arm to the SHARED
        empty-string return at 0x77b9c; corpus events
        67-91.
    [E:] THE OFFSET — pos = idx + len(a): the r14 a9d10
        staged 0x77905 with rdi = [rsp+0x68] (idx), the
        'len' CONST[267] loaded as a name through the a9d50
        stage 0x7793b-0x77941, the kind-1 [a] wrap at
        0x77965 and the len(a) call at 0x7798f, then the
        a9d10 with rcx = idx, rdx = len(a), r8d = 7 (the
        plain-plus selector) at 0x7799e — the sum stored
        [rsp+0x70] as one computation (the shipped `pos`
        local; the SPP CSE alternative flagged); corpus
        events 94-121.
    [E:] THE LENGTH GATE — the a9d30 cmp with edx=5 (the
        Py_GE richcompare opcode, extending the established
        ==/!= selector family) at 0x77a5f-0x77a6a: r8 =
        the pos, r9 = the len(value) (the second 'len'
        global stage 0x779e7-0x77a03, the [value] wrap
        0x77a2d, the call 0x77a57) — `idx + len(a) >=
        len(value)` keeps the author's redundant guard (the
        slice would yield '' anyway at equality); the TRUE
        arm joins the not-found arm at the shared 0x77b9c
        block returning the CONST[241] '' staged 0x77ba6;
        corpus events 133-168.
    [E:] THE TAIL SLICE — the PySlice-family CONST[26] at
        0x77ad3 with rcx = the [rsp+0x70] pos as the START,
        the rdx/r8 slots NULL (the call 0x77aed mirrors
        maskString's operand order), PyObject_GetItem over
        the value at 0x77b08 — `value[pos:]` — carried to
        the ret-disp (a9d28) at 0x77b64 through the bpl
        gate; corpus events 177-206.
    """
    idx = value.rfind(a)
    if idx == -1:
        return ''
    pos = idx + len(a)
    if pos >= len(value):
        return ''
    return value[pos:]


def splitEmbedText(text, limit, max_parts):
    """Registry L7657. Content: chunk L7854 — recovered from the
    island bytes of chunk 7854 (dump file
    chunk7854_splitEmbedText_L7657.txt, @0x75100, +4176, 184
    events, 1047 insns, read complete through the
    escape_markdown prologue at 0x76110), cross-checked against
    the complete stream section (function@L7657, corpus lines
    20698-20876, read complete; events 36-706). The island
    header names the NEXT registry entry (escape_markdown) —
    the established header-mislabel law; the body is this
    function's.

    [E:] THE SIGNATURE — the names-tuple CONST[816] ('text',
        'limit', 'max_parts') staged 0x75130 with the GOT_000
        binder (r8d=3) at 0x7515c; corpus events 36/40. Bound
        locals: [rsp+0x58] text, [rsp+0x60] limit,
        [rsp+0x68] max_parts (operand-locked: [rsp+0x68] is
        the r9 comparand of the 0x75319 cmp, [rsp+0x60] of the
        0x75418/0x75ca6 cmps — limit — and the rcx of every
        threshold binop).
    [E:] THE ENTRY GUARD — an or-chain: UNARY_NOT over text
        (IsTrue 0x75180; the True/False select 0x7519b/0x751ac
        — text-falsy lands on True, corpus True@51 before
        False@53, the not-swap law; IsTrue 0x751c1); the
        not-text-FALSE arm runs the second operand from
        0x75bcd: 'len' via a9d50 staged 0x75c00, kind-1
        (text,) wrap 0x75c54-0x75c6b, len call 0x75c89,
        a9d30 edx=1 (Py_LE; r8 = len(text), r9 = [rsp+0x60])
        at 0x75ca6. Both TRUE arms converge (0x751d5/0x75ccd
        -> 0x75c0b) into the kind-2 one-item list build
        (ecx=2, edx=1, item [rsp+0x58]) 0x75c13-0x75c31: `if
        not text or len(text) <= limit: return [text]`. The
        FALSE arm falls into the working body at 0x751fa.
        Corpus 48-57 (the not-consts) and 157-180 (the entry
        len/denorm cluster).
    [E:] THE STATE — kind-2 empty list a9d18 (ecx=2, edx=0)
        0x751fc-0x75209 -> [rsp+0x70]: parts = [];
        [rsp+0x78] <= [rsp+0x58] at 0x75227-0x75244:
        remaining = text. (FLAG: names-inferred.)
    [E:] THE LOOP HEAD — the and-chain: IsTrue over remaining
        0x75264/0x75269; falsy routes [rsp+0x78] itself to
        the 0x7535d merge (je 0x7535d @0x75277); truthy stages
        'len' 0x752af, kind-1 ([rsp+0x70]) wrap
        0x752cc-0x752e3, call 0x75301 (r8d=1), a9d30 edx=0
        (Py_LT; r8 = len(parts), r9 = [rsp+0x68]) at 0x75319
        — `while remaining and len(parts) < max_parts:`; the
        merge IsTrue 0x75360 exits via je 0x75e62 @0x7537c;
        the ONLY re-entry edge is jne 0x75264 @0x75bc2. Corpus
        denorm cluster 83-98.
    [E:] THE FITS ARM — 'len' staged 0x753ab, kind-1
        ([rsp+0x78]) wrap 0x753c8-0x753df, call 0x753fd,
        a9d30 edx=1 (Py_LE) 0x75418 — `if len(remaining) <=
        limit:`; TRUE jumps 0x75d87: 'append' CONST[250]
        GetAttr over [rsp+0x70] 0x75da3-0x75db7, kind-1
        (remaining,) wrap 0x75def-0x75e06, a9d20 (r8d=1) call
        0x75e26 — parts.append(remaining); then CONST[241] ''
        staged 0x75e3b stored [rsp+0x78] — remaining = '' —
        and the tail falls straight into the 0x75e62 post-loop
        gate with NO re-entry edge: the py38 break. Corpus
        310-345 (append + '' clusters). (FLAG: break
        structurally forced by the missing back-edge; an
        if/else spelling compiles stream-identically.)
    [E:] THE SPLIT ARM — the FALSE fall-through 0x75467:
        PySlice-family CONST[26] 0x75474-0x7548c (rcx NULL,
        rdx [rsp+0x60], r8 NULL) then GetItem 0x754ac over
        [rsp+0x78], stored [rsp+0x80] — chunk =
        remaining[:limit] (corpus Slice_New 223 / GetItem
        247). (FLAG: name-inferred.)
    [E:] THE RFIND CASCADE — 'rfind' CONST[733] over
        [rsp+0x80] (GetAttr 0x7552e), kind-1 ('\\n\\n',)
        build 0x7555f-0x75578 (CONST[817]), call 0x75596 ->
        [rsp+0x88]: cut = chunk.rfind('\\n\\n'); threshold
        a9d10 rcx=[rsp+0x60], rdx=CONST[478] int-2, r8d=0xc
        0x755e0-0x75607 — limit // 2 (selector 0xc =
        floor-div, LIVE table from getReadableUptime@L5800:
        0x1d *, 0xc //, 0x22 %, 0x24 -, 7 +, 0xe +=) — a9d30
        edx=0 cmp 0x75614: `if cut < limit // 2:`; the TRUE
        arm re-derives the same slot with '\\n' (CONST[239]
        build 0x756d2-0x756eb, call 0x75709, stored 0x7571f),
        the 0x75732 merge re-tests, the second TRUE arm
        re-derives with ' ' (CONST[243] 0x75845, call
        0x7587c, stored 0x75892), the THIRD cmp 0x758fa
        (threshold 0x758c6-0x758ed, sel 0xc) with its TRUE arm
        storing [rsp+0x60] -> [rsp+0x88] 0x7594e-0x75966: cut
        = limit. FALSE arms skip each re-derive (je 0x75732
        @0x7565d / je 0x758a5 @0x757d0 / je 0x75979 @0x75943).
        Corpus rfinds 376-542; seps '\\n\\n' 403-404, '\\n'
        472-473, ' ' 541-542; int-2 424-426 / 493-495 /
        562-564. (FLAG: name-inferred.)
    [E:] THE EMIT — 'append' GetAttr 0x75995-0x759aa over
        [rsp+0x70]; PySlice 0x759f8 (rcx NULL, rdx
        [rsp+0x88]) + GetItem 0x75a34 — remaining[:cut];
        'rstrip' CONST[818] GetAttr 0x75a69, zero-arg call
        0x75a99 (r8d=0); kind-1 wrap 0x75a9b-0x75aa5, append
        call 0x75ac6 (r8d=1) —
        parts.append(remaining[:cut].rstrip()). Then PySlice
        0x75af7 (rcx [rsp+0x88], rdx NULL) + GetItem 0x75b33
        — remaining[cut:]; 'lstrip' CONST[819] GetAttr
        0x75b67, zero-arg call 0x75b97, stored [rsp+0x78] —
        remaining = remaining[cut:].lstrip(); then the
        0x75bbf test + jne 0x75264 re-entry. Corpus rstrip
        627-629, lstrip 658-660; corpus SetItem 264 is the
        only SetItem.
    [E:] THE OVERFLOW ELLIPSIS — the 0x75e62 gate re-loads
        [rsp+0x78] and IsTrue-tests 0x75e75 — `if remaining:`
        (truthy only when max_parts stopped the loop with
        text left); FALSY returns parts at 0x75e93-0x75eb3
        (r13d cleared, rsi = [rsp+0x70], jmp 0x75ce0). TRUE
        arm: ' ...' CONST[820] staged 0x75eb8 into [rsp+0x90]
        — suffix = ' ...' — ONE materialization, double-read
        (0x75fe3 len-wrap / 0x7607a concat) vs the DOUBLED -1
        handoffs below, which settles local-vs-literal (FLAG:
        name-inferred; two-inline-literal CSE alternative
        flagged); two GOT_003 unary-minus dispatches over
        CONST[233] int-1 with edx=0x1e (0x75ef1->0x75f0b and
        0x75f31->0x75f4b; corpus int-1/-1 clusters 196-210):
        GetItem(parts, -1) 0x75f66 and the SetItem key
        0x760b4-0x760ba; 'len' staged 0x75fcc, kind-1 suffix
        wrap 0x75fe3-0x76004, call 0x76025 = len(suffix);
        a9d10 rcx=[rsp+0x60] (limit), rdx=len(suffix),
        r8d=0x24 0x76027-0x76033 — limit - len(suffix)
        (selector 0x24 = subtraction, LIVE-verified);
        PySlice 0x76035 (rcx NULL, rdx threshold) + GetItem
        0x76057 — parts[-1][:limit - len(suffix)]; concat
        a9d10 rcx=slice result 0x76081, rdx=[rsp+0x90],
        r8d=7 (plain-plus) 0x76084-0x7608a; SetItem parts[-1]
        = ... 0x760ba; jmp 0x75e93 (return parts). Corpus
        ' ...' 183-187; len/stage/build clusters 227-237 and
        279-287.
    [E:] THE TAIL — the 0x75ce0 epilogue decrefs the eight
        frame slots 0x75ce0-0x75d41 ([0x58] text, [0x60]
        limit, [0x68] max_parts, [0x70] parts, [0x78]
        remaining, [0x80] chunk, [0x88] cut, [0x90] suffix —
        the complete local census); the r13b flag (sete
        0x75c36 on the guard-list build) routes failures
        through the a9d28 ret-dispatch 0x75d4b with the None
        slots (corpus 697-706); live returns leave via
        0x75d72/0x75d53 with rsi = the parts list.
    """
    if not text or len(text) <= limit:
        return [text]
    parts = []
    remaining = text
    while remaining and len(parts) < max_parts:
        if len(remaining) <= limit:
            parts.append(remaining)
            remaining = ''
            break
        chunk = remaining[:limit]
        cut = chunk.rfind('\n\n')
        if cut < limit // 2:
            cut = chunk.rfind('\n')
        if cut < limit // 2:
            cut = chunk.rfind(' ')
        if cut < limit // 2:
            cut = limit
        parts.append(remaining[:cut].rstrip())
        remaining = remaining[cut:].lstrip()
    if remaining:
        suffix = ' ...'
        parts[-1] = parts[-1][:limit - len(suffix)] + suffix
    return parts


def removeSpoilers(content):
    """Registry L11446. Content: chunk L11951 — recovered from the
    island bytes of chunk 11951 (dump file
    chunk11951_removeSpoilers_11446.txt, span +3248, alignment
    +0), cross-checked against the complete stream section
    (function@L11446, corpus lines 27352-27371).

    [E:] THE SIGNATURE — the names-tuple CONST[256] ('content',)
        staged 0xa03a5 with the GOT_000 binder r8d=1 at 0xa03d9
        (corpus 22).
    [E:] THE CHAIN — re staged (CONST[228] via the a9d50 name
        load 0xa03f0), GetAttr 'sub' (CONST[257] staged
        0xa041e); the 3-tuple args: r8 = CONST[258]
        r'\|\|(.*?)\|\|' (staged 0xa045d), r9 = CONST[259]
        r'\1' (staged 0xa046c), frame = the content param
        (corpus 26-50) — re.sub(r'\|\|(.*?)\|\|', r'\1',
        content).
    [E:] THE RETURN — the sub result rides rsi to the a9d28
        ret-dispatch (corpus 60; LAW 14). No try/with/IsTrue
        branches in this function (no DAT_a9d40, no const-bool
        materialization).
    """
    return re.sub(r'\|\|(.*?)\|\|', r'\1', content)


def getActiveCtxMenus():
    """Registry L11951. Content: chunk L11966 — recovered from the
    island bytes of chunk 11966 (dump file
    chunk11966_getActiveCtxMenus_11951.txt, @0xa0530 +2560,
    alignment +0, 116 events, 650 insns, read complete),
    cross-checked against the complete stream section
    (function@L11951).

    MODULE-LEVEL ZERO-ARG: no names-tuple is staged — the span
    opens with the kind-2 (2,0) empty-list build 0xa0547 (the
    context_menus accumulator, [rsp+0x58]).

    [E:] THE BOT WALK — the 'bot' CONST[244] name-load staged
        0xa0575, the 'config' CONST[245] GetAttr 0xa05c0, the
        'context_menus' CONST[246] + 'items' CONST[247]
        GetAttr walk + call; the GetIter + the a9d60 iternext;
        the (name, data) 2-unpack per turn.
    [E:] THE ACTIVE GATE — data.get('active', False): the
        .get GetAttr with the ('active', False) 2-tuple;
        the IsTrue gate skips the body on falsy; menu_type =
        data['type'] (the CONST[248] GetItem).
    [E:] THE DESCRIPTION GATE — data.get('description') (the
        1-tuple .get over CONST[249], the product
        [rsp+0x78]) — the IsTrue splits the two append arms.
    [E:] THE APPENDS — the a9d48 four-piece: CONST[251] '- '
        + the -1 format of the name + CONST[252] (the type
        label with its newline head) + the -1 format of the
        menu_type — the (2,0) 1-arg tuple + the append call
        over [rsp+0x58]; the six-piece arm adds CONST[253]
        (the description label with its newline head) + the
        -1 format of the pre-built [rsp+0x78] get-product.
    [E:] THE TAIL — the loop-exhaust: the IsTrue over
        [rsp+0x58] at 0xa0d49; the FALSY arm stages
        CONST[255] 'No active context menus.' and returns it;
        the TRUTHY arm walks the '\n'.join GetAttr over the
        (context_menus,) 1-tuple call — then the a9d10 sel-7
        ADD over the one-piece-formatted CONST[254]
        '**Active context menus**:' (its newline tail) + the
        join product — the string-concatenation return.

    FLAG: the context_menus/menu_type locals are
        name-inferred (the frame slots).
    """
    context_menus = []
    for name, data in bot.config['context_menus'].items():
        if data.get('active', False):
            menu_type = data['type']
            if data.get('description'):
                context_menus.append(
                    f'- {name}\n-# Type: {menu_type}\n'
                    f'-# Description: {data.get("description")}')
            else:
                context_menus.append(
                    f'- {name}\n-# Type: {menu_type}')
    if not context_menus:
        return 'No active context menus.'
    return '**Active context menus**:\n' + '\n'.join(context_menus)


def extract_chat_response(text):
    """Registry L11966. Content: chunk L12020 — recovered from the
    island bytes of chunk 12020 (dump file
    chunk12020_extract_chat_response_11966.txt, @0xa0f30
    +2128, alignment +0, 102 events, 565 insns, read
    complete), cross-checked against the complete stream
    section (function@L11966). The AI-response post-processor:
    strips a closing think-tag block, unwraps a quoted
    payload, and normalizes hand-escaped control sequences.

    [E:] THE SIGNATURE — the names-tuple CONST[227] ('text',)
        staged 0xa0f48 with the GOT_000 binder (r8d=1) at
        0xa0f74.
    [E:] THE SEARCH — the 're' CONST[228] name-load (staged
        0xa0f89) + the 'search' CONST[229] GetAttr (staged
        0xa0fbb); the 3-tuple args over the pattern pool
        slot 230 (hex-locked: the closing-tag head then one
        literal backslash-s, the star-paren-dot-star-paren
        tail — the raw source form r'</think\s*(.*)'), the
        text param, and the re.DOTALL flag ('DOTALL'
        CONST[231] over the re module product) —
        match = re.search(r'</think\s*(.*)', text,
        re.DOTALL).
    [E:] THE MATCH ARMS — the IsTrue gate over the search
        product: the truthy arm walks 'group' (CONST[232])
        with the (1,) tuple + the .strip() chain —
        response = match.group(1).strip(); the falsy arm
        walks the text's own .strip() —
        response = text.strip(); both arms land [rsp+0x58].
    [E:] THE QUOTE UNWRAP — the 'startswith' CONST[234] call
        with the '"' CONST[235] tuple AND the 'endswith'
        CONST[236] call; the pair gates the slice: the
        CONST[26] slice-maker with start = CONST[233] 1 and
        the -1 stop —
        if response.startswith('"') and response.endswith(
        '"'): response = response[1:-1].
    [E:] THE NORMALIZATION — three chained 'replace'
        (CONST[237]) calls: the two-char backslash-n literal
        (pool 238) onto the one-char newline (pool 239); the
        backslash-r literal (pool 240) onto the empty string
        (pool 241); the backslash-t literal (pool 242) onto a
        single space (pool 243) — the hand-unescaping of
        JSON-style control text.
    [E:] THE RETURN — the [rsp+0x58] product rides rsi
        (LAW 14) — return response; the CONST[30] None at the
        tail is the NULL-fallback.

    FLAG: the match/response locals are name-inferred (the
        frame slots).
    """
    match = re.search(r'</think\s*(.*)', text, re.DOTALL)
    if match:
        response = match.group(1).strip()
    else:
        response = text.strip()
    if response.startswith('"') and response.endswith('"'):
        response = response[1:-1]
    response = response.replace('\\n', '\n').replace('\\r', '').replace('\\t', ' ')
    return response
