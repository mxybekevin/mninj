"""
scripts_discoverables_store.py — the enabled-scripts and blocked-
discoverables list CRUD from the SPP native core, recovered via the
Ghidra batch-decompilation lane (oracle/out/ghidra_decomp).

Family shape — all four functions identical modulo four const
deltas (reader, section key, mutator, file path):

    data = getScriptsConfig() / getDiscoverablesConfig()
    if <arg> [not] in data['enabled' / 'blocked']:
        data['enabled' / 'blocked'].append / remove(<arg>)
        with open(getDataPath() + '/misc/scripts.json' or
                 '/misc/discoverables.json', 'w',
                 encoding='utf-8', errors='ignore') as f:
            json.dump(data, f, indent=2)

The save executes INSIDE the mutation branch (evidenced: the open
prologue is guarded by the append/remove call result) and the
compiled tail stages None — no explicit return value.

New SPP-op fact established by this family: the member check runs
through SUBGOT_a9d30 with a numeric selector — 6 = `in` (mutate when
present), 7 = `not in` (mutate when absent) — applied needle-first
(the function argument tested against the list).
"""

import json


def addEnabledScript(script_name):
    """Registry L1533. Content: chunk labeled L1540 (decomp
    spp_span_removeEnabledScript_1540.c). Signature ('script_name',)
    [E:] — dossier stub + the const-pool sig tuple (slot 1635).

    [E:] scripts = getScriptsConfig() (L28-64, GOT_870); the guard
         `<script_name> not in scripts['enabled']` — SUBGOT_a9d30
         selector 7 at raw L79 ('enabled' GOT_346 GetItem L75);
         scripts['enabled'].append(script_name) — 'append' GOT_250
         GetAttr L121 + 1-arg call L129-130 (the arg = the function
         parameter slot).
    [E:] the save runs inside the mutation branch (raw L131:
         `if (lVar9 != 0) { open... }`): open(getDataPath() +
         '/misc/scripts.json', 'w', encoding='utf-8',
         errors='ignore') (L133-189: 'open' GOT_201, 'getDataPath'
         GOT_194, the a9d48 path-join op, GOT_1636, 'w' GOT_833,
         GOT_284/285 encoding, GOT_685/686 errors/ignore) +
         json.dump(scripts, f, indent=2) (L206-244: 'json' GOT_143,
         'dump' GOT_689, 'indent' GOT_690, int 2 GOT_478).
    [E:] the tail stages None (L249-307) — no explicit return.
    """
    scripts = getScriptsConfig()
    if script_name not in scripts['enabled']:
        scripts['enabled'].append(script_name)
        with open(getDataPath() + '/misc/scripts.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(scripts, f, indent=2)


def removeEnabledScript(script_name):
    """Registry L1540. Content: chunk labeled L1547 (decomp
    spp_span_addBlockedDiscoverable_1547.c). Signature
    ('script_name',) [E:] — marshal unit varnames.

    [E:] identical family shape with SUBGOT_a9d30 selector 6
         (raw L79: `script_name in scripts['enabled']`) and the
         'remove' mutator (GOT_839 GetAttr L121, 1-arg call
         L129-130); same conditional save via getDataPath() +
         '/misc/scripts.json' with indent=2; None return.
    """
    scripts = getScriptsConfig()
    if script_name in scripts['enabled']:
        scripts['enabled'].remove(script_name)
        with open(getDataPath() + '/misc/scripts.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(scripts, f, indent=2)


def addBlockedDiscoverable(user_id):
    """Registry L1547. Content: chunk labeled L1554 (decomp
    spp_span_removeBlockedDiscoverable_1554.c). Signature
    ('user_id',) [E:] — marshal unit varnames + the const-pool sig
    tuple (slot 1631, placed directly before this family's const
    cluster).

    [E:] data = getDiscoverablesConfig() (GOT_1632); section key
         'blocked' (GOT_1633, GetItems at stream L75/L111); the
         mutator 'append' (GOT_250, stream L115-121); the save via
         getDataPath() + '/misc/discoverables.json' (GOT_1634) with
         'w'/encoding='utf-8'/errors='ignore' + json.dump(...,
         indent=2) (stream L133-244); None return.
    [E:] flag: the guard's a9d30 selector is cited as 7 (`not in`)
         by family invariant — the ADD sibling's selector is
         raw-evidenced (op 7 in addEnabledScript) and this
         function's stream shows the identical guard cluster incl.
         the bool_False fallback; selector 6/7 pairs with the
         REMOVE sibling mirror the scripts pair exactly.
    """
    discoverables = getDiscoverablesConfig()
    if user_id not in discoverables['blocked']:
        discoverables['blocked'].append(user_id)
        with open(getDataPath() + '/misc/discoverables.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(discoverables, f, indent=2)


def removeBlockedDiscoverable(user_id):
    """Registry L1554. Content: chunk labeled L1562 (decomp
    spp_span_encryptCurrentToken_1562.c — this span's head carries
    this body before the encryptCurrentToken tail). Signature
    ('user_id',) [E:] — marshal unit varnames.

    [E:] identical family shape with the mutator 'remove' (GOT_839,
         stream L115-121), reader getDiscoverablesConfig (GOT_1632),
         section key 'blocked' (GOT_1633), the save via getDataPath()
         + '/misc/discoverables.json' (GOT_1634) with indent=2
         inside the mutation branch; None return.
    [E:] flag: the guard's a9d30 selector cited as 6 (`in`) by
         family invariant (raw-evidenced in the removeEnabledScript
         twin; identical guard cluster in this function's stream).
    """
    discoverables = getDiscoverablesConfig()
    if user_id in discoverables['blocked']:
        discoverables['blocked'].remove(user_id)
        with open(getDataPath() + '/misc/discoverables.json', 'w',
                  encoding='utf-8', errors='ignore') as f:
            json.dump(discoverables, f, indent=2)
