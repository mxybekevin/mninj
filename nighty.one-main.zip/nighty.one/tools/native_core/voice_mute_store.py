"""
voice_mute_store.py — Nighty's voice-mute settings family from the SPP
native core, translated with per-statement evidence.

Config shape (reconstructed from the function streams):
    voicemute.json = {
        'settings': { <key>: <value>, ... },
        'list': { 'enabled': bool, 'mode': 'whitelist'|'blacklist',
                  'ids': [str, ...] }
    }
History: voicemute_history.json = [str(user_id), ...]

Every function cites the chunk its stream was found in (registry
labels are off by one relative to true contents - verified repeatedly).

Recovery-method note: chunk starts that cut mid-instruction make naive
linear capstone scans stall or self-sync on garbage bytes — that is
what the earlier "zero events" readings on chunks L816/L886/L1787 were
(NOT armed placeholders). Aligned/resync reads resolve them; see
clearVoiceMuteHistory below for the worked example.
"""

import copy
import json
import re  # noqa: F401


def _merge_defaults(config, defaults):
    """[E:] items/isinstance/get/deepcopy cascade seen in getVoiceMuteConfig
    and getVoiceMuteHistory streams; exact nesting reconstructed from the
    items-get-items-deepcopy sequence in the const flow."""
    for key, value in defaults.items():
        if isinstance(value, dict):
            cur = config.get(key)
            if not isinstance(cur, dict):
                cur = config[key] = copy.deepcopy(value)
            else:
                _merge_defaults(cur, value)
        elif key not in config:
            config[key] = copy.deepcopy(value)
    return config


def getVoiceMuteConfig():
    """Registry L669. Content: chunk labeled L699.

    [E:] open(voicemute_path, 'r', encoding='utf-8', errors='ignore')
    [E:] json.load; isinstance-dict check;
    [E:] raise ValueError('voicemute.json is not an object')
    [E:] on Exception: copy.deepcopy(VOICEMUTE_DEFAULTS) +
         saveVoiceMuteConfig(...); then recursive defaults fill
         (items/isinstance/get/get/deepcopy cascade).
    [E:] saveVoiceMuteConfig appears TWICE in the stream (events 19 and
         30): in the restore branch AND after the merge - the reader
         persists the merged config before returning it.
    """
    try:
        with open(voicemute_path, 'r', encoding='utf-8',
                  errors='ignore') as f:
            config = json.load(f)
        if not isinstance(config, dict):
            raise ValueError('voicemute.json is not an object')
    except Exception:
        config = copy.deepcopy(VOICEMUTE_DEFAULTS)
        saveVoiceMuteConfig(config)
    _merge_defaults(config, VOICEMUTE_DEFAULTS)
    saveVoiceMuteConfig(config)
    return config


def getVoiceMuteSetting(key):
    """Registry L699. Content: chunk labeled L703.
    [E:] sig ('key',); getVoiceMuteConfig()['settings'].get(key)
    """
    return getVoiceMuteConfig()['settings'].get(key)


def setVoiceMuteSetting(key, value):
    """Registry L703. Content: chunk labeled L711.
    [E:] sig ('key', 'value'); config['settings'][key] = value;
         saveVoiceMuteConfig(config); return None
    """
    config = getVoiceMuteConfig()
    config['settings'][key] = value
    saveVoiceMuteConfig(config)


def getVoiceMuteList():
    """Registry L711. Content: chunk labeled L715.
    [E:] return getVoiceMuteConfig()['list']
    """
    return getVoiceMuteConfig()['list']


def isVoiceMuteListEnabled():
    """Registry L715. Content: chunk labeled L718.
    [E:] return getVoiceMuteConfig()['list']['enabled']
    """
    return getVoiceMuteConfig()['list']['enabled']


def setVoiceMuteListEnabled(state):
    """Registry L718. Content: chunk labeled L724.
    [E:] sig ('state',); config['list']['enabled'] = bool(state);
         saveVoiceMuteConfig(config).
    [E:] trailing events re-read config['list']['enabled'] through the
         cached config (events 27-35) - the setter returns the freshly
         written value, not None.
    """
    config = getVoiceMuteConfig()
    config['list']['enabled'] = bool(state)
    saveVoiceMuteConfig(config)
    return config['list']['enabled']


def getVoiceMuteListMode():
    """Registry L724. Content: chunk labeled L727.
    [E:] return getVoiceMuteConfig()['list']['mode']
    """
    return getVoiceMuteConfig()['list']['mode']


def setVoiceMuteListMode(mode):
    """Registry L727. Content: chunk labeled L733.
    [E:] sig ('mode',); sets config['list']['mode'] to 'whitelist' or
         'blacklist' via a truthiness branch (IsTrue + the two string
         consts are both in the stream); saves config.
    [E:] note: whether the original compared `mode` as a string equality
         or as a boolean selector is not fully disambiguated in the
         disassembly - noted honestly.
    [E:] trailing events re-read config['list']['mode'] (events 32-40):
         returns the written value.
    """
    config = getVoiceMuteConfig()
    config['list']['mode'] = 'whitelist' if mode else 'blacklist'
    saveVoiceMuteConfig(config)
    return config['list']['mode']


def addVoiceMuteListId(user_id):
    """Registry L733. Content: chunk labeled L743.
    [E:] sig ('user_id',); ids = config['list']['ids'];
         membership check on str(user_id); ids.append(str(user_id));
         saveVoiceMuteConfig(config); returns True
    """
    config = getVoiceMuteConfig()
    uid = str(user_id)
    ids = config['list']['ids']
    if uid not in ids:
        ids.append(uid)
        saveVoiceMuteConfig(config)
    return True


def removeVoiceMuteListId(user_id):
    """Registry L743. Content: chunk labeled L753.
    [E:] same shape as the add with 'remove' (stream shows
         GetAttr('remove')) + save + True.
    """
    config = getVoiceMuteConfig()
    uid = str(user_id)
    ids = config['list']['ids']
    if uid in ids:
        ids.remove(uid)
        saveVoiceMuteConfig(config)
    return True


def isInVoiceMuteList(user_id):
    """Registry L753. Content: chunk labeled L757.
    [E:] sig ('user_id',); return str(user_id) in
         getVoiceMuteConfig()['list']['ids'] (IsTrue/bool flow).
    """
    return str(user_id) in getVoiceMuteConfig()['list']['ids']


def getVoiceMuteHistory():
    """Registry L761. Content: chunk labeled L773.
    [E:] json.load(voicemute_history_path); isinstance-LIST check;
    [E:] raise ValueError('voicemute_history.json is not an array');
    [E:] on Exception: saveVoiceMuteHistory(...) restore (the restored
         value's exact constant is not visible in the stream - noted).
    """
    try:
        with open(voicemute_history_path, 'r', encoding='utf-8',
                  errors='ignore') as f:
            hist = json.load(f)
        if not isinstance(hist, list):
            raise ValueError('voicemute_history.json is not an array')
        return hist
    except Exception:
        hist = []
        saveVoiceMuteHistory(hist)
        return hist


def addVoiceMuteHistory(user_id):
    """Registry L773. Content: chunk labeled L789.
    [E:] sig ('user_id',); isinstance((list, set, tuple)) check on the
         history; iteration (GetIter) with a counter; str(user_id)
         membership test; append; saveVoiceMuteHistory.
    [E:] note: whether it also caps/purges old entries in the loop is
         not fully resolved from the counter pattern - noted.
    """
    history = getVoiceMuteHistory()
    if isinstance(history, (list, set, tuple)):
        uid = str(user_id)
        if uid not in history:
            history.append(uid)
            saveVoiceMuteHistory(list(history))


def removeVoiceMuteHistory(user_id):
    """Registry L789. Content: chunk labeled L799.
    [E:] sig ('user_id',); if str(user_id) in history: remove +
         saveVoiceMuteHistory; the branch returns True (event 27), the
         early-exit path returns None (event 16).
    """
    history = getVoiceMuteHistory()
    uid = str(user_id)
    if uid in history:
        history.remove(uid)
        saveVoiceMuteHistory(history)
        return True


def isInVoiceMuteHistory(user_id):
    """Registry L799. Content: chunk labeled L802.
    [E:] return str(user_id) in getVoiceMuteHistory()
    """
    return str(user_id) in getVoiceMuteHistory()


def clearVoiceMuteHistory():
    """Registry L802. Content: chunk labeled L816.

    [E:] RECOVERED via aligned re-reading — the naive scan stalled on
         the mid-instruction chunk start and hid the operative events.
         Dossier 0xbc83 loads rdi from const slot 1702; the live const
         dump resolves slot 1702 = 'saveVoiceMuteHistory' (and the
         surrounding slots are exactly this function's neighborhood:
         1701 ('data',) / 1703 'getVoiceMuteHistory' / 1704 'tuple').
         The name is staged via the 0xa9d50 op (0xbc9f), Py_DecRef'd,
         then the dispatcher build pair ([0xa9d18] twice: ecx=2/edx=0
         then ecx=1/edx=1 with the prior result), the standard
         guard-epilogue (PyErr_Occurred/PyErr_Clear, const None) and
         the return op ([0xa9d28]).
    [E:] the payload is dispatcher-built (no const, no PyList_New
         visible); [] by the voicemute_history isinstance-list
         invariant — inferred, flagged.
    [E:] identical shape to clearNoLeaveData (chunk L886), whose
         alignable stream shows the same name-stage -> call -> build
         -> exit sequence.
    """
    saveVoiceMuteHistory([])


def voiceMuteEmbed(title, description):
    """Registry L9942. Content: chunk L9951 — recovered from the
    island bytes of chunk 9951 (@0x98070 +2080), cross-checked
    against the complete stream section (function@L9942,
    corpus lines 26428-26555).

    [E:] THE SIGNATURE — the names-tuple CONST[367] ('title',
        'description') staged 0x9808a with the GOT_000 binder
        (r8d=2) — a MODULE-LEVEL function (no self).
    [E:] THE THEME — bot (CONST[244] staged 0x980c4) ->
        config (CONST[245]) -> GetItem 'theme' (CONST[368]).
    [E:] THE EMBED — discord_bot (CONST[310]) -> 'Embed'
        (CONST[369]; NOT ui.Embed) with the a9d18 ecx=3 kwargs
        dict in frame order: title (CONST[370]) =
        theme['title'], description (CONST[249]) = the param,
        color (CONST[371]) = int(theme['color'].replace('#',
        ''), 16): 'replace' CONST[237], '#' CONST[373], ''
        CONST[241], the int arg 16 (CONST[374] staged 0x98410).
    [E:] THE CHAIN — .set_author (CONST[375]) kwargs name
        (CONST[273]) = title, icon_url (CONST[376]) =
        theme['author_icon'] (CONST[377]); .set_thumbnail
        (CONST[378]) kwargs url (CONST[114]) = theme['image']
        (CONST[379]); .set_footer (CONST[380]) kwargs text
        (CONST[97]) = theme['footer'] (CONST[381]), icon_url =
        theme['footer_icon'] (CONST[382]) — each call's result
        feeds the next GetAttr; the final result rides the
        ret-dispatch.

    FLAG: the `theme` local is name-inferred.
    """
    theme = bot.config['theme']
    return (discord_bot.Embed(
                title=theme['title'],
                description=description,
                color=int(theme['color'].replace('#', ''), 16))
            .set_author(name=title,
                        icon_url=theme['author_icon'])
            .set_thumbnail(url=theme['image'])
            .set_footer(text=theme['footer'],
                        icon_url=theme['footer_icon']))


def parseVoiceMuteIds(raw):
    """Registry L9951. Content: chunk L10039 — recovered from the
    island bytes of chunk 10039 (@0x98890 +1504), cross-checked
    against the complete stream section (function@L9951, corpus
    lines 26556-26619).

    [E:] THE SIGNATURE — the names-tuple ('raw',) with the
        GOT_000 binder (r8d=1).
    [E:] THE INIT — the GOT_004 unpack of the paired list init
        `ids, removed = [], []` (the a9d18 ecx=2 pair + the
        tuple-unpack dispatch).
    [E:] THE LOOP — re.split on the raw-string pattern
        r'[,\n]+' over `raw or ''` (the or stages the '' as the
        falsy side); the a9d60 iternext; per-iteration
        re-store of piece.strip() (GetAttr 'strip'); the
        `if not piece:` continue uses the falsy-on-True swap.
    [E:] THE SORT — the piece.isdigit() probe; the truthy arm
        appends to ids via .append, the falsy arm to removed.
    [E:] THE RETURN — the a9d18 ecx=1 tuple of (ids,
        removed) rides the ret-dispatch.

    FLAG: the ids/removed/piece local names are inferred (raw
        is live from the names-tuple).
    """
    ids, removed = [], []
    for piece in re.split(r'[,\n]+', raw or ''):
        piece = piece.strip()
        if not piece:
            continue
        if piece.isdigit():
            ids.append(piece)
        else:
            removed.append(piece)
    return ids, removed


