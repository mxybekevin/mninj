"""
turbo_sniper_manager.py — the TurboSniper.exe process manager
class from the SPP native core (registry L9424-L9506),
recovered from the island bytes of chunks 9430/9451/9499/9506/9517,
cross-checked against the complete stream sections.

  __init__(self, exe_path) — four attribute seeds
  _reader(self)             — the stdout JSON pump loop
  start(self, token, session_mode, dpb) — spawn + configure
  send(self, message)       — the stdin JSON write
  stop(self)                — terminate + wait

CLASS NAME FLAG: nothing mangles and no live const names this
class — 'TurboSniper manager' is positional; the close@L8560
marquee uses the turbo_sniper MODULE GLOBAL for the running
instance (its construction call site is not in this block).
"""

import asyncio  # noqa: F401
import json  # noqa: F401
import logging  # noqa: F401
import os  # noqa: F401
import subprocess  # noqa: F401

from threading import Thread  # noqa: F401  # the bare-name Thread load


class TurboSniperManager:

    def __init__(self, exe_path):
        """Registry L9424. Content: chunk L9430 — recovered from the
        island bytes of chunk 9430 (@0x8fe30 +720), cross-checked
        against the complete stream section (function@L9424,
        corpus lines 25335-25368).

        [E:] THE SIGNATURE — the names-tuple CONST[496] ('self',
            'exe_path') staged 0x8fe42 with the GOT_000 binder at
            0x8fe6e (r8d=2) — exe_path is a PARAMETER, not a
            literal (no value const between the CONST[442]
            stages and the SetAttr).
        [E:] THE SETATTRS — in order: 'exe_path' (CONST[442]
            0x8fe88 = the bound parameter), 'proc' (CONST[433]
            0x8ff14) = None (CONST[30]), 'thread' (CONST[485]
            0x8ff88) = None, 'running' (CONST[432] 0x8fffc) =
            False (CONST[32]); the implicit None return.
        """
        self.exe_path = exe_path
        self.proc = None
        self.thread = None
        self.running = False

    def _reader(self):
        """Registry L9430. Content: chunk L9451 — recovered from the
        island bytes of chunk 9451 (@0x90100 +3216),
        cross-checked against the complete stream section
        (function@L9430, corpus lines 25369-25546 / 154 events).

        [E:] THE LOOP — sig ('self',) (CONST[278] 0x90117;
            GOT_000 binder 0x90143); self.proc.stdout (CONST[433]/
            [98]) -> GetIter -> the a9d60 iternext loop
            (0x90204/0x90231); the strip gate stages 'strip'
            CONST[99] with the falsy side landing on the
            materialized CONST[31] True (0x90338) = `if not
            line.strip(): continue` (law 8).
        [E:] THE TRY — the json name-load + 'loads' CONST[424]
            GetAttr, json.loads(line); the DAT_a9d40 exc fetch
            at 0x90ad4 + the a9d30 with edx=0xa (0x90b6e)
            matching json.JSONDecodeError (CONST[495]) —
            no-match -> GOT_002 re-raise at 0x90cc2; the matched
            arm prints the f-string over CONST[494] 'Nitro
            Sniper (Turbo) | Invalid message from Go: ' (0x90beb)
            + {line} ([rsp+0x70]) and jumps 0x90c8d -> 0x9022e =
            the loop head (continue).
        [E:] THE ARMS — the a9d30 sel-6 'notification' in
            [rsp+0x78] message (0x90433-0x9045e, edx=6); truthy ->
            print over CONST[488] 'Nitro Sniper (Turbo) | ' +
            the GetItem message['notification'] (CONST[487],
            0x906b1); falsy -> elif message.get('event') ==
            'connected' (a9d30 sel-2 0x905ac, 'event' CONST[489],
            'connected' CONST[490]; the .get is a GetAttr over
            CONST[47] + the 1-arg call); truthy -> print over
            CONST[491] 'Nitro Sniper (Turbo) | Logged in as ' +
            the GetItem message['user'] (CONST[388]); elif ==
            'nitro' (CONST[492] 0x90795; truthy -> the asyncio
            (CONST[393]) .run (CONST[69]) applied to the
            notifyNitroSnipe (CONST[493]) name-load with the
            1-arg (message,) tuple); else -> print over
            CONST[488] + {message} raw.
        [E:] THE RETURN — PyErr_Occurred/Clear then CONST[30]
            None (0x90d18): the implicit None after the loop.

        FLAG: the line/message local names are inferred (the
            [rsp+0x70]/[rsp+0x78] slots).
        """
        for line in self.proc.stdout:
            if not line.strip():
                continue
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                print(f'Nitro Sniper (Turbo) | Invalid message '
                      f'from Go: {line}')
                continue
            if 'notification' in message:
                print(f'Nitro Sniper (Turbo) | '
                      f'{message["notification"]}')
            elif message.get('event') == 'connected':
                print(f'Nitro Sniper (Turbo) | Logged in as '
                      f'{message["user"]}')
            elif message.get('event') == 'nitro':
                asyncio.run(notifyNitroSnipe(message))
            else:
                print(f'Nitro Sniper (Turbo) | {message}')

    def start(self, token, session_mode, dpb):
        """Registry L9451. Content: chunk L9499 — recovered from the
        island bytes of chunk 9499 (@0x90d90 +6400, 311 events);
        the stream section (function@L9451, corpus lines
        25547-25548) is a merged region (decomp file absent), so
        the island carries the whole decode.

        [E:] THE SIGNATURE — the names-tuple CONST[440] ('self',
            'token', 'session_mode', 'dpb') with the GOT_000
            binder (r8d=4); params [rsp+0xc8]/[rsp+0xd0]/
            [rsp+0xd8]/[rsp+0xe0].
        [E:] THE GATES — self.running (CONST[432]) truthy prints
            CONST[441] 'Process already running'; os (CONST[34])
            -> exists (CONST[193]) over self.exe_path; the falsy
            arm runs logging.error over the 3-piece a9d48
            f-string CONST[443] 'TurboSniper: ' + self.exe_path
            + CONST[444] ' not found, turbo mode unavailable',
            then print with the args+kwargs pair: message
            CONST[445] 'Nitro Sniper (Turbo) | TurboSniper.exe
            is missing (check your antivirus), turbo mode
            unavailable. Switch the nitro sniper back to On.'
            and the kwargs {'type_' (CONST[208]): ERROR
            (CONST[67])}, then return.
        [E:] THE SPAWN — subprocess (CONST[93]) .Popen
            (CONST[446]) with the 1-item list [self.exe_path]
            and kwargs stdin=/stdout=subprocess.PIPE CONST[447]
            x2, text=True, bufsize=1; result SetAttr'd to
            self.proc ('proc' CONST[433]).
        [E:] THE SESSION CONFIG — the a9d18 ecx=3 edx=7 dict in
            frame order ios/android/windows/linux/web/xbox/ps5;
            each value a 4-item list (ecx=2, edx=4): [os,
            browser, os, user-agent] with the os const reused
            as the device item (the LIVE UA consts).
        [E:] THE PAYLOAD — the GetItems session_configs[
            session_mode] per key ([0] 0, [1] 1, [2] 2) -> the
            a9d18 ecx=3 edx=7 dict: token (CONST[147]) = the
            param, os (CONST[34]), browser (CONST[474]), device
            (CONST[475]), status (CONST[159]) = GetItem
            'status' over GetAttr(dpb, 'config' CONST[245]),
            user-agent (CONST[476]) = GetAttr(dpb.http
            CONST[479], 'user_agent'), x-super-properties
            (CONST[477]) = GetAttr(dpb.http,
            'encoded_super_properties').
        [E:] THE WIRING — self.proc.stdin (CONST[438]).write(
            json.dumps(payload) + '\n' (CONST[239])) then
            .flush (CONST[439]); the self.running SetAttr;
            Thread (CONST[481]) with kwargs target (CONST[482])
            = the _reader GetAttr + daemon (CONST[484]) = True,
            SetAttr'd to self.thread (CONST[485]) and started;
            print over CONST[486] 'Nitro Sniper (Turbo)
            starting..'.

        FLAG: the session_configs/payload locals are
            name-inferred.
        """
        if self.running:
            print('Process already running')
            return
        if not os.path.exists(self.exe_path):
            logging.error(
                f'TurboSniper: {self.exe_path} not found, '
                f'turbo mode unavailable')
            print('Nitro Sniper (Turbo) | TurboSniper.exe is '
                  'missing (check your antivirus), turbo mode '
                  'unavailable. Switch the nitro sniper back to '
                  'On.', type_='ERROR')
            return
        self.proc = subprocess.Popen(
            [self.exe_path], stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, text=True, bufsize=1)
        session_configs = {
            'ios': ['iOS', 'Discord iOS', 'iOS',
                    'Discord-iOS/231028; CFNetwork/1490.0.7; '
                    'Darwin/23.2.0'],
            'android': ['Android', 'Discord Android', 'Android',
                        'Discord-Android/267200;RNA'],
            'windows': ['Windows', 'Discord Client', 'Windows',
                        'Mozilla/5.0 (Windows NT 10.0; Win64; '
                        'x64) AppleWebKit/537.36 (KHTML, like '
                        'Gecko) Discord/1.0.9001 '
                        'Chrome/108.0.5359.215 '
                        'Electron/22.3.24 Safari/537.36'],
            'linux': ['Linux', 'Discord Client', 'Linux',
                      'Mozilla/5.0 (X11; Linux x86_64) '
                      'AppleWebKit/537.36 (KHTML, like Gecko) '
                      'Discord/1.0.9002 Chrome/108.0.5359.215 '
                      'Electron/22.3.24 Safari/537.36'],
            'web': ['Windows', 'Chrome', 'Windows',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                    'AppleWebKit/537.36 (KHTML, like Gecko) '
                    'Chrome/125.0.0.0 Safari/537.36'],
            'xbox': ['Xbox', 'Discord Embedded', 'Xbox',
                     'Mozilla/5.0 (Windows NT 10.0; Win64; x64; '
                     'Xbox; Xbox Series X) AppleWebKit/537.36 '
                     '(KHTML, like Gecko) Chrome/120.0.0.0 '
                     'Safari/537.36 Edge/44.19041'],
            'ps5': ['PS5', 'Discord Embedded', 'PS5',
                    'Mozilla/5.0 (PlayStation; PlayStation 5) '
                    'AppleWebKit/605.1.15 (KHTML, like Gecko) '
                    'Version/15.0 Safari/605.1.15']}
        payload = {
            'token': token,
            'os': session_configs[session_mode][0],
            'browser': session_configs[session_mode][1],
            'device': session_configs[session_mode][2],
            'status': dpb.config['status'],
            'user-agent': dpb.http.user_agent,
            'x-super-properties': dpb.http.encoded_super_properties}
        self.proc.stdin.write(json.dumps(payload) + '\n')
        self.proc.stdin.flush()
        self.running = True
        self.thread = Thread(target=self._reader, daemon=True)
        self.thread.start()
        print('Nitro Sniper (Turbo) starting..')

    def send(self, message):
        """Registry L9499. Content: chunk L9506 — recovered from the
        island bytes of chunk 9506 (@0x92690 +1344),
        cross-checked against the complete stream section
        (function@L9499, corpus lines 25550-25625).

        [E:] THE SIGNATURE — the names-tuple CONST[436] ('self',
            'message') staged 0x926a8 with the GOT_000 binder
            (r8d=2).
        [E:] THE GATE — the 'running' CONST[432] GetAttr with
            the falsy side on CONST[31] True = `if not
            self.running`; the GOT_001 raise dispatch with
            'RuntimeError' CONST[414] and 'Process is not
            running' CONST[437].
        [E:] THE WRITE — self.proc.stdin .write of json.dumps +
            the '\n' const (the DAT_a9d10 plain +); then .flush
            on the same self.proc.stdin walk; the implicit None
            return.
        """
        if not self.running:
            raise RuntimeError('Process is not running')
        self.proc.stdin.write(json.dumps(message) + '\n')
        self.proc.stdin.flush()

    def stop(self):
        """Registry L9506. Content: chunk L9517 — recovered from the
        island bytes of chunk 9517 (@0x92bd0 +992),
        cross-checked against the complete stream section
        (function@L9506, corpus lines 25626-25682).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x92bd6, the GOT_000 binder at
            0x92c02.
        [E:] THE GATE — the 'running' CONST[432] GetAttr
            (0x92c1c) with NO bool materialization = a plain
            truthy if (the contrast with send@L9499's
            not-swap).
        [E:] THE TEARDOWN — self.proc .terminate (CONST[434]);
            self.proc .wait (CONST[107]) — both zero-arg calls;
            the SetAttr self.running = False (CONST[32]); print
            over CONST[435] 'Nitro Sniper (Turbo) stopped.'.
        """
        if self.running:
            self.proc.terminate()
            self.proc.wait()
            self.running = False
            print('Nitro Sniper (Turbo) stopped.')
