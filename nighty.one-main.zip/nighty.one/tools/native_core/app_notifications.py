"""
app_notifications.py — the console/notification publisher family
from the SPP native core (registry L6640 onward), recovered from
the corpus event streams plus island dumps. The module-level
print() below is the app-wide print override: every recovered
caller in the shell invokes it to publish a notification record.

  print(text, discordChannel, url, type_, message)
                                    — the notification publisher
                                      console console-record
                                      pusher (addConsoleRecord)
  isNotActiveDiscord(message, user) — the active-window analyzer
                                      (away = the focused Discord
                                      window is a different chat)
  showToast(text, title, url, type_, details,
            timeout, message, user)
                                    — the OS toast dispatcher
                                      gated on the away-window
  sendAppNotification(content, discord_url, channel,
                      type_, message)
                                    — the shell-app payload builder
                                      over print()
  listdirs(path)                     — the directories-only
                                      os.listdir comprehension
  removeRandomChars(html_string)     — the HTML response trimmer
                                      (everything after the
                                      closing tag is dropped)
"""

import json
import re
import time
import uuid


def print(text, discordChannel=None, url=None, type_=None,
          message=None):
    """Registry L6640. Content: chunk labeled L6696 —

    recovered from the interior bytes of chunk 6696 (dump file
    chunk6696_print_L6640.txt; the span file's 'file
    merged/absent' verdict was a boundary artifact — the chunk
    island-dumps cleanly at alignment +0, 324 events, 1676
    insns @0x60920 +6896). Signature ('text', 'discordChannel',
    'url', 'type_', 'message') [E:] — const-pool tuple slot 956
    (0x60952, LIVE). The name print is exact: the original
    module shadows the builtin with this function.

    The ERROR suppression gate. [E:] the a9d30 selector-2
         equality (edx=2 at 0x609bd) of type_ against 'ERROR'
         (GOT_67, 0x609a4); the TRUE branch stages
         getNotifications (GOT_936, 0x60abc), calls it at
         0x60df8, GetItems 'app' (GOT_574, 0x60e2d ->
         PyObject_GetItem 0x60e44) then 'errors' (GOT_685,
         0x60edd -> GetItem 0x60ef6). [E:] the truth chain at
         0x60f3a-0x60f76 maps errors-FALSY to the True const
         and errors-TRUTHY to the False const — the gate is an
         evidence-locked NOT: a falsy ['app']['errors'] returns
         None, a truthy one proceeds to the record build.
         (Reading: ['app']['errors'] acts as the error-logging
         enabled flag; when it is falsy ERROR records are
         dropped.)
    [E:] the frames else: notification = {'type': type_,
         'text': text, 'id': str(uuid.uuid4()), 'created_at':
         int(time.time())} — the a9d18 kind-3 count-4 build at
         0x60d0e with the keys in this exact order ('type'
         GOT_248 0x60a1f, 'text' GOT_97 0x60a3d, 'id' GOT_265
         0x60a57, 'created_at' GOT_957 0x60bc6), the str()
         (GOT_150 0x60a8d) around uuid.uuid4() (GOT_524/GOT_525,
         0x60b03/0x60b37) and the int() (GOT_372 0x60bdc)
         around time.time() (GOT_427, 0x60c1e/0x60c53).
    [E:] the message branch: notification['url'] =
         message.jump_url.replace('https://', 'discord://') —
         'jump_url' GetAttr (GOT_958, 0x60e9e/0x60eb7), the
         .replace (GOT_237, 0x6110c/0x61126), the a9d18 kind-1
         count-2 args build ('https://' GOT_587 0x6114d,
         'discord://' GOT_932 0x6115c), the call at 0x61193,
         SetItem 'url' at 0x611bd.
    [E:] server_icon = None then `if message.guild and
         message.guild.icon:` — the None store at 0x611e8-
         0x61202, 'guild' GetAttr (GOT_289, 0x61238), IsTrue at
         0x6127f (TRUE -> 0x613c2), the guild.icon GetAttr
         (GOT_959, 0x613ed/0x6153a) with IsTrue at 0x61565; the
         truthy side re-fetches message.guild (0x615b2 ->
         0x61abb), guild.icon (0x61ae6) and guild.icon.url
         ('url' GOT_114, 0x61b05/0x61b1e) into the slot
         (0x61b46-0x61b4e), both falsy sides fall/join at
         0x61297 keeping None.
    [E:] notification['channel'] = {'name':
         getChannelInfo(message.channel), 'server_icon':
         server_icon} — 'channel' (GOT_405, 0x612a6), 'name'
         (GOT_273, 0x612c0) as a KEY, getChannelInfo staged
         (GOT_933, 0x612da), message.channel GetAttr
         (0x6141e/0x61434), the call at 0x61494, the a9d18
         kind-3 count-2 dict build (0x6165a-0x6166a), SetItem
         'channel' at 0x61695.
    [E:] notification['author'] = {'name':
         message.author.name, 'avatar': (message.author.avatar
         or message.author.default_avatar).url} — 'author'
         (GOT_954, first staged 0x616cf), the .name GetAttr at
         0x6184b, 'avatar' (GOT_961, 0x61873) with IsTrue at
         0x61921; the truthy side re-fetches message.author
         (0x61b98) then .avatar (0x61d7a); the falsy side
         fetches message.author.default_avatar ('default_avatar'
         GOT_962, 0x61cdc/0x61cf7); both sides share the single
         .url GetAttr (GOT_114, 0x61b3a/0x61db5) — the or-idiom
         is locked by the shared terminal GetAttr. The a9d18
         kind-3 count-2 dict (0x61ddf) sets it under 'author' at
         0x61e1c.
    [E:] the emoji attach splits by branch and shares ONE
         SetItem site (0x61014 'emojis' GOT_965 with the
         notification dict at rdi): the no-message side calls
         get_custom_emojis(text) (GOT_963 staged 0x60da9, frame
         text slot [rsp+0x78], call 0x60fea); the message side
         stages message.content (GOT_964, 0x61e56/0x61eca) and
         jumps back to the shared guards (0x61f32 jne ->
         0x60ff9) — get_custom_emojis(message.content).
    [E:] the dispatch after the attach — separate ifs, NOT an
         elif chain: `if discordChannel:` sets 'discordChannel'
         (GOT_934, staged 0x61318, SetItem 0x61356) and then,
         only when message is falsy, overwrites the channel with
         {'name': discordChannel} — the message re-check at
         0x61394 with the True/False const inversion at
         0x613b6/0x61ba6 (je 0x61077 on the False side), the
         a9d18 kind-3 count-1 build ('name' GOT_273 r8 +
         the discordChannel frame slot [rsp+0x80] r9, 0x61c2a)
         and SetItem 'channel' at 0x61c54, jmp 0x61077 (0x61c7f).
    [E:] `if url:` — the IsTrue at 0x61077 over the [rsp+0x88]
         slot, 'url' (GOT_114, 0x615cf), SetItem at 0x6160d
         (0x61638 jmp 0x610af after) — the url parameter
         overrides anything the message branch stored under
         'url'.
    [E:] __all_notifications__.append(notification) — the
         global (GOT_631, staged 0x610b6/0x61995) with the
         .append GetAttr (GOT_250, 0x6173e/0x61757), the a9d18
         kind-1 count-1 args build over the notification slot
         (0x61776-0x61797), the call at 0x617b5, the result
         DecRef'd at 0x617c4. Every successful call appends.
    [E:] the 500 cap: len staged (GOT_267, 0x617d8), the
         a9d20 call at 0x619f3 over (__all_notifications__,)
         (build 0x619d4), the 500 (GOT_522, 0x619f6) with the
         a9d30 selector-4 compare (edx=4 at 0x61a0a) — `if
         len(__all_notifications__) > 500:`; the TRUE side
         (0x61c84 -> 0x622ac) re-stages len + the global, calls
         len again (0x62361), then the a9d10 binop with
         selector 0x24 (the SUBTRACT, 0x62375) against 500
         (0x62364) and Py_DelItem at 0x623a4 — `del
         __all_notifications__[len(__all_notifications__) -
         500]`.
    [E:] the console push: evaluate_js(f'addConsoleRecord(
         {json.dumps(notification)});') — evaluate_js staged
         (GOT_41, 0x61a77), json staged (GOT_143, 0x6218d)
         with .dumps GetAttr (GOT_420, 0x621da), dumps
         called over the notification dict (build
         0x621f9-0x6221a, call 0x62238). The argument is an
         f-string: the dumps result passes the FORMAT_VALUE-
         style convert (the -1 a9d48 call at 0x62248) and
         the a9d48 BUILD_STRING(3) joins the literal chunks
         'addConsoleRecord(' (GOT_966 0x6216e), the
         formatted value and ');' (GOT_967 0x6224a, ecx=3 at
         0x62259) — no a9d10 concatenation exists at this
         site (see the flags below). The a9d18 kind-1
         count-1 args build (0x62267-0x62274) and the a9d20
         call at 0x62295 execute the push; the result is
         DecRef'd (0x622a2 -> 0x6203e) and discarded.
    [E:] the wrapper: the whole body runs inside `try:` —
         every error path targets 0x61f53, where the a9d40
         exception state fetch (0x61f6b) feeds an a9d30
         selector-0xa match against Exception (GOT_77, staged
         0x61f87, match call 0x61fc9); a matching exception is
         retained in the [rsp+0xb8] handler slot (0x62007) and
         the error state cleared — the handler body is empty
         (pass) and the function returns None. Non-matching
         exceptions propagate (r14b=1 at 0x62056/0x620fc).
    [E:] the return is None on every path — the success tail
         zeroes esi and the None const is staged for the
         return (0x6213e); the early ERROR-gate return carries
         the same None (0x60f86).

    Flags: (1) between the -500 binop and Py_DelItem the
    emitter places one call through const-slot 26, which is a
    pydcode runtime slot (value 0x6d654180, invisible to the
    static dump) — it behaves like the index coercion ahead of
    the del and does not change the semantics, but it is
    annotator-unresolvable and noted here rather than guessed.
    (2) The [rsp+0xb8] exception-value retention is the
    Python 3.8 handler-slot pattern; `except Exception:` and
    `except Exception as e:` compile indistinguishably here
    (the slot is never read), so the bare form is shipped.
    (3) The trim index (len - 500) deletes from the live end,
    not the oldest element at index 0 — the exact observed
    arithmetic is shipped even though a 0-based trim might
    have been the author's intent.
    """
    try:
        if type_ == 'ERROR' and not getNotifications(
                )['app']['errors']:
            return None
        notification = {
            'type': type_,
            'text': text,
            'id': str(uuid.uuid4()),
            'created_at': int(time.time()),
        }
        if message:
            notification['url'] = message.jump_url.replace(
                'https://', 'discord://')
            server_icon = None
            if message.guild and message.guild.icon:
                server_icon = message.guild.icon.url
            notification['channel'] = {
                'name': getChannelInfo(message.channel),
                'server_icon': server_icon,
            }
            notification['author'] = {
                'name': message.author.name,
                'avatar': (message.author.avatar
                           or message.author.default_avatar
                           ).url,
            }
            notification['emojis'] = get_custom_emojis(
                message.content)
        else:
            notification['emojis'] = get_custom_emojis(text)
        if discordChannel:
            notification['discordChannel'] = discordChannel
            if not message:
                notification['channel'] = {
                    'name': discordChannel}
        if url:
            notification['url'] = url
        __all_notifications__.append(notification)
        if len(__all_notifications__) > 500:
            del __all_notifications__[
                len(__all_notifications__) - 500]
        evaluate_js(
            f'addConsoleRecord('
            f'{json.dumps(notification)});')
    except Exception:
        pass
    return None


def isNotActiveDiscord(message, user):
    """Registry L6696. Content: chunk labeled L6741 — recovered
    from the island bytes of chunk 6741 (dump file
    chunk6741_isNotActiveDiscord_L6696.txt, alignment +0, 188
    events, 1019 insns @0x62420 +6896) cross-checked against
    the stream section (function@L6696, corpus line 17074).
    Signature ('message', 'user') [E:] — const-pool tuple slot
    947 (0x62438, LIVE; the two-argument frame enter r8d=2 at
    0x62464).

    The away-detector: reads the focused window title and
    decides whether the user is looking at the conversation the
    notification belongs to. True means away — showToast only
    fires when this returns True.

    [E:] the context gate: two a9d30 selector-8 None compares
         (edx=8 at 0x6249a and 0x6251e) over the message and
         user frame slots against the None const, joined by
         the True/False const chains (0x624c3/0x6253f) into one
         shared normalize (0x62562) — BOTH falsy takes jne
         0x62629 (0x62581) into the True-return block; a
         truthy slot drops to getActiveWindow. Reads `if
         message is None and user is None: return True`.
         (Selector-8 None compares are flagged per the
         None-compare law.)
    [E:] the window gate: getActiveWindow staged (GOT_948,
         0x6258e) and called; the falsy result takes jne
         0x6264f's inverse (0x62625 test / 0x62627) into
         0x62629 — `if not getActiveWindow(): return True`.
    [E:] window.title via GetAttr (GOT_370, staged
         0x6265b/0x6267a, call 0x6266f) stored to the
         [rsp+0x70] title slot (0x626a9-0x626ae).
    [E:] `'Discord' not in title` — the a9d30 selector-6
         membership compare (edx=6 at 0x626e6, GOT_949 staged
         0x626c5) with the False const inversion at 0x6270c;
         je 0x62629 at 0x6273d fires the True-return when
         Discord is absent.
    [E:] the three-way: `'|' in title` (GOT_950, selector-6
         0x627b, jne 0x62882 at 0x627c2 -> the channel
         window branch); `elif '@' in title` (GOT_952,
         selector-6 0x627f0, je 0x62629 at 0x62845 -> the DM
         window branch); anything else returns True.
    [E:] the channel branch: the exact pattern '#([^|]+) \\| '
         '([^-]+) - Discord' (GOT_951, build 0x628f3-0x62920,
         call 0x62940) — no match returns True (je 0x62629 at
         0x62993); group(1).strip() and group(2).strip()
         (CONST 1 at 0x629f8, CONST 2 at 0x62c3b, strip
         GetAttrs 0x62a58/0x62c7a) feed the channel and guild
         slot values wired into compares one and three.
    [E:] `if not message.guild: return True` — the guild
         GetAttr (GOT_289, 0x62d4b) with the IsTrue at
         0x62e1f and the True const inversion 0x62e38 ->
         jne 0x62629 at 0x62f97.
    [E:] the DM branch: the exact pattern '@([^ ]+) - Discord'
         (GOT_953, build 0x62aa9-0x62ab0) — group(1).strip()
         (CONST 1 at 0x62d86, strip at 0x62dc5, result stored
         0x63175-region); the target selection gates: message
         truthy -> message.author.global_name (GetAttr
         0x62f58, 'global_name' GOT_955 with the shared
         GetAttr 0x63026), elif user -> user.global_name
         (0x62f19-staged, same shared GetAttr), both falsy ->
         return True (je 0x62629 at 0x62f03).
    [E:] the three selector-2 equality compares and the shared
         tail: compare one (0x63095, [rsp+0x80] vs
         message.channel.name — channel GetAttr 0x62fd4, name
         GetAttr 0x63075), compare two (0x63190, the DM
         handle vs the global_name slot), compare three
         (0x63299, [rsp+0x88] vs message.guild.name — guild
         GetAttr 0x6311f, name GetAttr 0x63279). All funnel
         into the 0x631f4 normalize: unequal (je 0x62629 at
         0x63211) returns True; the all-equal fallthrough
         stages the False const (0x63223) and returns False.
    Flags: (1) the [rsp+0x80]/[rsp+0x88]/[rsp+0x90] slot
    wiring for the three extracted names is inferred from the
    compare operands (the strip results ride interleaved call
    sites inside the 0x62a-0x62e gap); the group numbers
    themselves are pattern-locked. (2) The channel branch is
    shipped as a sequential guard `not message.guild or
    channel mismatch or guild mismatch -> True` — the
    evidence (one early True-return address shared by the
    guild gate and the compare tails) cannot distinguish it
    from nested ifs. (3) The DM-branch no-match gate sits in
    the 0x62b2d IsTrue region whose branch instructions were
    not directly read; its False path is assumed to join the
    same True-return used by every other failed gate.
    """
    if message is None and user is None:
        return True
    window = getActiveWindow()
    if not window:
        return True
    title = window.title
    if 'Discord' not in title:
        return True
    if '|' in title:
        m = re.match(r'#([^|]+) \| ([^-]+) - Discord',
                     title)
        if not m:
            return True
        channel_name = m.group(1).strip()
        guild_name = m.group(2).strip()
        if (not message.guild
                or channel_name != message.channel.name
                or guild_name != message.guild.name):
            return True
        return False
    if '@' in title:
        m = re.match(r'@([^ ]+) - Discord', title)
        if not m:
            return True
        handle = m.group(1).strip()
        if message:
            name = message.author.global_name
        elif user:
            name = user.global_name
        else:
            return True
        return handle != name
    return True


def showToast(text, title, url, type_, details, timeout,
              message, user):
    """Registry L6741. Content: chunk labeled L6763 — recovered
    from the island bytes of chunk 6763 (dump file
    chunk6763_showToast_L6741.txt, alignment +0, 152 events,
    797 insns @0x633e0 +3232) cross-checked against the stream
    section (function@L6741, corpus line 17265). Signature
    ('text', 'title', 'url', 'type_', 'details', 'timeout',
    'message', 'user') [E:] — const-pool tuple slot 935
    (0x6341e, LIVE; the eight-argument frame enter r8d=8 at
    0x63444).

    The OS-toast dispatcher: gated on the toast toggle, the
    away-detector and the toast settings, then forwarded to
    the notification_sender backend.

    [E:] the toggle gate: getNotifications() (GOT_936 staged
         0x63462, call 0x634ac) subscripted ['toast'] (GOT_937,
         GetItem 0x634ca) and ['toast'] again (GetItem
         0x63502); the IsTrue at 0x63530 with the falsy path
         (xor ebp, 0x6354e) joining the shared exit -> return
         None. Reads `if not getNotifications()['toast']'
         ']: <['toast']>: return None`.
    [E:] the url fixup: the [rsp+0xa8] url slot gated at
         0x63555 (jne 0x635c1); 'discord.com' (GOT_938) via
         the a9d30 selector-6 membership compare (0x635c8-0x635f4)
         with the False const inversion 0x63615 and je
         0x63589 at 0x63646; the replace arm: .replace GetAttr
         (GOT_237, 0x6367e), the build ('https://' GOT_587
         0x638ef, 'discord://' GOT_932 0x638fe), the call
         0x63935, the slot overwrite 0x63949 and jmp 0x63589
         (0x63960) — the replace result rejoins the same
         activity gate, so the fixup is a conditional rebind
         inside the function.
    [E:] the away gate: isNotActiveDiscord staged (GOT_939,
         0x63590) with the (message, user) kind-1 build (r8 =
         the [rsp+0xc8] message slot, r9 = the [rsp+0xd0] user
         slot, 0x63697-0x636c8), the call at 0x636e6, IsTrue
         at 0x636f7; the falsy side (user IS looking at
         discord) takes je 0x6354e (0x63713) -> return None.
    [E:] the timeout: getNotifications()['toast']['settings']
         (the 0x63720-0x637c1 chain) .get('duration') —
         'get' GetAttr (GOT_47, 0x637f9), the ('duration',)
         build (GOT_940, 0x6381f), call 0x63856, IsTrue
         0x63868; truthy re-reads the bracket form
         ['toast']['settings']['duration'] (GetItem 0x63a58)
         inside int() ('int' GOT_372 staged 0x63891, call
         0x63aa4) and overwrites the [rsp+0xc0] timeout slot
         (0x63ab8).
    [E:] the logo: ['toast']['settings'].get('image_url')
         (GOT_941, build 0x63bca, call 0x63c08, IsTrue
         0x63c1a); falsy binds the literal 'https://nighty.one'
         '/img/nighty.png' (GOT_942, 0x63c38) to the [rsp+0xd8]
         logo slot (0x63c4a); truthy re-reads
         ['toast']['settings']['image_url'] (GetItem 0x63d3e)
         into the same slot (0x63d6e).
    [E:] the send: notification_sender staged (GOT_943,
         0x63d90), the .sendToast GetAttr (GOT_944, 0x63dde)
         to [rsp+0x78]; the (text,) positional build (r8 =
         the [rsp+0x98] text slot, 0x63e0d) and the a9d18
         kind-3 count-6 kwargs dict (0x63f1d-0x63f27) in this
         pair order: 'logo_url' (GOT_945) -> logo slot,
         'on_click' (GOT_946) -> the url slot, 'type_'
         (GOT_208) -> [rsp+0xb0], 'title' (GOT_370) ->
         [rsp+0xa0], 'details' (GOT_884) -> [rsp+0xb8],
         'timeout' (GOT_139) -> [rsp+0xc0]; the call at
         0x63f46, its result DecRef'd 0x63f55, jmp 0x6354e ->
         the exit.
    [E:] the return is None on every path (the None const at
         0x64001 for the shared exit; every early gate clears
         ebp and routes through 0x63f60).
    """
    if not getNotifications()['toast']['toast']:
        return None
    if url:
        if 'discord.com' in url:
            url = url.replace('https://', 'discord://')
    if not isNotActiveDiscord(message, user):
        return None
    if getNotifications()['toast']['settings'].get('duration'):
        timeout = int(
            getNotifications()['toast']['settings']['duration'])
    if getNotifications()['toast']['settings'].get('image_url'):
        logo_url = getNotifications()['toast']['settings'][
            'image_url']
    else:
        logo_url = ('https://nighty.one/img/nighty.png')
    notification_sender.sendToast(
        text,
        logo_url=logo_url,
        on_click=url,
        type_=type_,
        title=title,
        details=details,
        timeout=timeout)
    return None


def sendAppNotification(content, discord_url, channel, type_,
                       message):
    """Registry L6763. Content: chunk labeled L6829 — recovered
    from the island bytes of chunk 6829 (dump file
    chunk6829_sendAppNotification_L6763.txt, alignment +0, 43
    events, 265 insns @0x64080 +1056) cross-checked against the
    stream section (function@L6763, corpus line 17431).
    Signature ('content', 'discord_url', 'channel', 'type_',
    'message') [E:] — const-pool tuple slot 931 (0x6409b, LIVE;
    the five-argument frame enter r8d=5 at 0x640be).

    sendAppNotification is print()'s payload builder: it
    normalizes its url and channel arguments and forwards
    everything into the app-wide notification publisher.

    [E:] the first gate (IsTrue at 0x640eb on the [rsp+0x70]
         discord_url slot; je 0x641d3 at 0x64107 skips the
         whole block on falsy) reassigns in place: discord_url
         = discord_url.replace('https://', 'discord://') — the
         .replace GetAttr (GOT_237, 0x64120/0x64134), the a9d18
         kind-1 count-2 args build ('https://' GOT_587 0x6416c,
         'discord://' GOT_932 0x6417b), the call at 0x641b2 and
         the slot overwrite at 0x641c3.
    [E:] the second gate (IsTrue at 0x641e6 on the [rsp+0x78]
         channel slot; je 0x6429d at 0x64202) reassigns:
         channel = getChannelInfo(channel) — staged GOT_933
         (0x6420f), the (channel,) kind-1 build (0x64241-0x6425f
         with r8 = [rsp+0x78]), the call at 0x6427d and the
         slot overwrite at 0x6428d.
    [E:] the forward into print: the global staged as GOT_204
         'print' (0x642a4) — the module's own override — the
         (content,) positional build (0x642d6, r8 = [rsp+0x68])
         and the a9d18 kind-3 count-4 kwargs dict (0x64392,
         pairs in this order): 'url' -> the transformed
         discord_url slot, 'discordChannel' -> the transformed
         channel slot (GOT_934 key at 0x6431c), 'type_'
         (GOT_208 key at 0x64336) and 'message' (GOT_48 key at
         0x64355). The result is DecRef'd (0x643c0-0x643c3) and
         discarded.
    [E:] the return is None (the ebp-flag cleared at 0x643c9,
         the None const staged for the return at 0x6442b).
    """
    if discord_url:
        discord_url = discord_url.replace(
            'https://', 'discord://')
    if channel:
        channel = getChannelInfo(channel)
    print(content, url=discord_url, discordChannel=channel,
          type_=type_, message=message)
    return None


def listdirs(path):
    """Registry L6829. Content: chunk labeled L6832 — recovered
    from the island bytes of chunk 6832 (dump file
    chunk6832_listdirs_L6829.txt, alignment +0, 59 events, 328
    insns @0x644b0 +1056) cross-checked against the stream
    section (function@L6829, corpus line 17479). Signature
    ('path',) [E:] — const-pool tuple slot 930 (0x644b2, LIVE).

    A single comprehension: every directory of path.

    [E:] the list machinery is explicit — GOT_013 PyCell_New
         and GOT_024 PyList_New in the event stream (frames 37
         and 47-48 of the corpus section) plus GOT_012
         PyCell_Get for the path closure (frame 74/173) and
         GOT_018 PyList_Append for the append (frame 191): a
         CPython 3.8 comprehension frame with path closed over.
    [E:] os.listdir staged via 'os' (GOT_34) with the .listdir
         GetAttr (GOT_280, 0x64576-0x64590) over (path,); the
         iteration runs on SUBGOT_a9d60 (iternext 0x6462c,
         back-edge 0x64658).
    [E:] the filter calls os.path.isdir(os.path.join(path,
         entry)) — os.path via 'os' then 'path' (GOT_165,
         0x646b7/0x646d2), .isdir (GOT_872, 0x646f2-0x6470d),
         os.path.join (GOT_166, 0x647aa-0x647c4) with the
         two-element args build (0x647e4) reading path out of
         the cell (PyCell_Get, corpus frame 173) and the entry
         from the loop register; the IsTrue filter at 0x64870
         gates the PyList_Append.
    [E:] one annotator-unresolvable call site (const-slot 27,
         0x6460e) sits between the list build and the first
         iternext — same runtime-pyd slot family as the
         coercion calls flagged in print(); the comprehension
         semantics are unaffected and the flag is recorded
         rather than guessed.
    """
    return [entry for entry in os.listdir(path)
            if os.path.isdir(os.path.join(path, entry))]


def removeRandomChars(html_string):
    """Registry L6832. Content: chunk labeled L6846 — recovered
    from the island bytes of chunk 6846 (dump file
    chunk6846_removeRandomChars_L6832.txt, alignment +0, 38
    events, 240 insns @0x64990 +928) cross-checked against
    the stream section (function@L6832, corpus line 17532).
    Signature ('html_string',) [E:] — const-pool tuple slot
    928 (0x649a4, LIVE; the one-argument frame enter r8d=1 at
    0x649d0).

    Despite the registry name this is an HTML response trimmer:
    it keeps everything up to and including the closing
    </html> tag and drops whatever the server appended after
    it (the "random chars" of the name).

    [E:] the marker search: html_string.rfind('</html>') —
         the .rfind GetAttr (GOT_733, 0x64a05) over the
         ('</html>',) kind-1 build (GOT_929, 0x64a3d-0x64a56),
         the call at 0x64a76 with the result stored to the
         [rsp+0x60] slot (0x64a8d).
    [E:] the found test: `if idx != -1:` — the -1 operand is
         produced by a GOT_003 dispatch over the int 1 const
         (CONST[233] staged 0x64ac2, selector 0x1e at
         0x64ad0, call 0x64ad5) and compared through the
         a9d30 selector-3 non-equality (edx=3 at 0x64adc, r8 =
         the rfind result, r9 = the -1 operand) with the
         standard False-const inversion (0x64b08). Flag: the
         GOT_003/0x1e dispatch is the only semantics that
         fits (a unary negative of the 1 const); the slot
         mapping itself is annotator-invisible and recorded
         rather than guessed.
    [E:] the falsy side returns the argument unchanged (the
         [rsp+0x58] html_string slot copied to the return slot
         [rsp+0x68] at 0x64b3b-0x64b50 and jmp 0x64c54).
    [E:] the slice: html_string[:idx + len('</html>')] — 'len'
         staged (GOT_267, stage 0x64ba3) over the
         ('</html>',) build (0x64bc1) with the call at
         0x64bfa, then the a9d10 selector-7 addition
         (r8d=7 at 0x64c03: the rfind result + the length),
         the slice object through the const-pool pydcode
         slot 26 (0x64c09 — the PySlice_New family, GOT_026
         at corpus event 121) and PyObject_GetItem at
         0x64c2a; the slice result is stored to [rsp+0x68].
    [E:] the return loads [rsp+0x68] (0x64c69-0x64c73) on both
         paths with the propagate flag cleared (xor ebp at
         0x64c73); only the error entries fall back to None
         (0x64cd2).
    """
    index = html_string.rfind('</html>')
    if index != -1:
        return html_string[:index + len('</html>')]
    return html_string
