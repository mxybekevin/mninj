"""
discord_state_helpers.py — the ChannelManager voice-state family
from the SPP native core (registry L9788-L9902), recovered via the
decomp lane and upgraded with island passes. The class runs
further than the first draft believed: past getActiveChannelId it
continues with getFriendsSet (a METHOD — the fresh chunk-9805
island binds the ('self',) names-tuple; the corpus draft's
module-level mounting was the mis-read, forced out by the
getIdsToMute self.getFriendsSet() call sites), the channel-
members probe and the voice-mute _enqueue / _schedule_flush /
getIdsToMute engine — one class object through L9902.

  __init__()                        — the empty ctor (L9788)
  setActiveChannelId(active_channel_id) — the setter (L9791)
  getActiveChannelId()              — stored attr, else the live
                                      voice channel id (L9794)
  getFriendsSet()                   — the bot.friends id set
                                      (L9801)
  getChannelMembers()               — the channel probe (L9805)
  _enqueue(ids, muted)              — the pending map + flush
                                      scheduling (L9829)
  _schedule_flush()                 — the asyncio flush gate
                                      (L9836)
  getIdsToMute()                    — the routing engine
                                      (L9902)

CLASS NAME FLAG: descriptive (nothing in the binary evidence
names the class — the evidenced attr active_channel_id defines
the role).
"""

import asyncio  # noqa: F401
import json  # noqa: F401
import logging  # noqa: F401


class ChannelManager:
    """The active-channel state + the voice-mute engine."""

    def __init__(self):
        """Registry L9788. Content: chunk labeled L9791 (stream
        section function@L9788).

        [E:] the body is the empty-constructor emission: entry
             op + error-clear + None return only (stream L14-26);
             no attribute assignments, no argument use.
        """
        pass

    def setActiveChannelId(self, active_channel_id):
        """Registry L9791. Content: chunk labeled L9794 (stream
        section function@L9791). Signature [E:]-flagged: a
        single parameter feeds the SetAttr (the const-pool name
        'active_channel_id' GOT_403 is the stored attribute; the
        parameter shares it by the family setter convention).

        [E:] self.active_channel_id = active_channel_id —
             SetAttr (GOT_020, L39); silent None return (L48-54).
        """
        self.active_channel_id = active_channel_id

    def getActiveChannelId(self):
        """Registry L9794. Content: chunk labeled L9801 (stream
        section function@L9794).

        [E:] self.active_channel_id GetAttr (GOT_403, L27-46) +
             IsTrue (L56) — the stored value returns when truthy;
             the fallback chain reads bot.user.voice.channel (GOT_
             244/388/404/405, L58-146) with a truth gate, then
             bot.user.voice.channel.id (the second chain L164-208
             with the 'id' GetAttr GOT_265) returned; the falsy
             tail returns None (L149-153, L224-233).
        [E:] flag: the two live-chain passes are the compiled
             double-evaluation of the same bot.user.voice.channel
             expression (read + read.id); translated as the
             natural single-expression form.
        """
        if self.active_channel_id:
            return self.active_channel_id
        if bot.user.voice.channel:
            return bot.user.voice.channel.id
        return None

    def getFriendsSet(self):
        """Registry L9801. Content: chunk L9805 — recovered from the
        island bytes of chunk 9805 (dump file
        chunk9805_getFriendsSet_L9801.txt, +0 align, 37 events,
        206 insns, @0x95df0) — the ISLAND-METHOD UPGRADE: the
        ('self',) names-tuple CONST[278] staged 0x95e08 with the
        GOT_000 binder (r8d=1) at 0x95e34 pins the method form;
        cross-checked against the stream section
        (function@L9801).

        [E:] THE SIGNATURE — CONST[278] ('self',) staged 0x95e08
             with the GOT_000 binder (r8d=1) at 0x95e34.
        [E:] THE LIST — the raw PyList_New 0x95e46 (r13b=1 = the
             build flag); the friends walk: bot (CONST[244]
             staged 0x95e5b) -> friends (CONST[402] staged
             0x95e8d) GetAttr 0x95ea6 -> the iterator (the
             CONST[27] call at 0x95ed2); the a9d60 iternext loop
             0x95f03 with per-friend .id staging (CONST[265]
             0x95f26) and PyList_Append.
        [E:] THE SET — the set() global over the (1,1) build —
             return set(friend.id for friend in bot.friends)
             (the prior draft's const reads stand; the
             return-op rides the a9d28 dispatch).
        """
        return set(friend.id for friend in bot.friends)

    def getChannelMembers(self):
        """Registry L9805. Content: chunk L9829 — recovered from the
        island bytes of chunk 9829 (dump file
        chunk9829_getChannelMembers_9805.txt, @0x96110 +1008),
        cross-checked against the complete stream section
        (function@L9805, corpus lines 26266-26316).

        [E:] THE SIGNATURE — the names-tuple CONST[278] ('self',)
            staged 0x9611e with the GOT_000 binder at 0x9614a.
        [E:] THE CHANNEL — the 'getActiveChannelId' CONST[399]
            GetAttr walk, zero-arg call; the a9d30 pair with
            the None const and CONST[32] False — the `is None`
            half of the or-test.
        [E:] THE PROBE — 'bot' CONST[244] -> 'get_channel'
            CONST[400] GetAttr with the channel_id arg — and
            the result is evaluated ONCE into a temp reused by
            the second half of the or-test (single
            bot.get_channel(...) evaluation, no re-call); the
            second a9d30 with None + False = `is None` on the
            temp.
        [E:] THE RETURN — the 'members' CONST[401] GetAttr
            (0x963e7, repeated 0x9648e) on the resolved channel
            — return channel.members; the empty-arm returns the
            [] materialization; the epilogue None CONST[30]
            0x9645d.

        FLAG: the channel/channel_id local names are inferred —
            the island shows one get_channel eval stored to a
            temp; the or-chain and the return share it.
        """
        channel_id = self.getActiveChannelId()
        channel = bot.get_channel(channel_id)
        if channel_id is None or channel is None:
            return []
        return channel.members

    def _enqueue(self, ids, muted):
        """Registry L9829. Content: chunk L9836 — recovered from the
        island bytes of chunk 9836 (dump file
        chunk9836__enqueue_9829.txt, @0x96500 +1040),
        cross-checked against the complete stream section
        (function@L9829, corpus lines 26317-26358).

        [E:] THE SIGNATURE — the names-tuple CONST[396] ('self',
            'ids', 'muted') staged 0x96520 with the GOT_000
            binder at 0x9654c (r8d=3).
        [E:] THE GATE — the not-swap on the ids parameter:
            CONST[32] False at 0x9658b then CONST[31] True at
            0x9659c = `if not ids: return` (the implicit None
            via CONST[30] 0x96754 / the ret-dispatch 0x967c8).
        [E:] THE LOOP — the a9d60 iternext at 0x96609 over
            GetIter(ids); body: SetItem on GetAttr '_pending'
            (CONST[397]) keyed by the int() call over the loop
            var with the value `muted` — self._pending[int(x)]
            = muted.
        [E:] THE TAIL — GetAttr '_schedule_flush' (CONST[398]
            0x96848/0x96867), zero-arg call —
            self._schedule_flush().

        FLAG: the loop-variable name is not carried — drafted
            as userid (name-inferred); ids/muted are live from
            the names-tuple.
        """
        if not ids:
            return
        for userid in ids:
            self._pending[int(userid)] = muted
        self._schedule_flush()

    def _schedule_flush(self):
        """Registry L9836. Content: chunk L9902 — recovered from the
        island bytes of chunk 9902 (dump file
        chunk9902__schedule_flush_9836.txt, @0x96910 +1168),
        cross-checked against the complete stream section
        (function@L9836, corpus lines 26359-26424).

        [E:] THE SIGNATURE — the names-tuple CONST[278]
            ('self',) staged 0x9691f with the GOT_000 binder at
            0x9694b.
        [E:] GATE 1 — the a9d30 over GetAttr '_flush_task'
            (CONST[391]) vs None — the selector byte at
            0x969c5 is edx=9 = `is not` (law 5); CONST[32]
            False at 0x969ef materializes the and-chain.
        [E:] GATE 2 — GetAttr '_flush_task' -> GetAttr 'done'
            (CONST[392]), zero-arg call, then the not-swap:
            CONST[32] False onto CONST[31] True = `not
            self._flush_task.done()`.
        [E:] THE CANCEL-SKIP BODY — the early arm returns the
            implicit None (CONST[30] at 0x96d01); the
            fallthrough SetAttr '_flush_task' = the asyncio
            (CONST[393]) 'create_task' (CONST[394]) applied to
            GetAttr '_flush_after_delay' (CONST[395]),
            zero-arg — self._flush_task =
            asyncio.create_task(self._flush_after_delay()).
        """
        if self._flush_task is not None and \
                not self._flush_task.done():
            return
        self._flush_task = \
            asyncio.create_task(self._flush_after_delay())

    def getIdsToMute(self):
        """Registry L9902. Content: chunk L9942 — recovered from the
        island bytes of chunk 9942 (dump file
        chunk9942_getIdsToMute_9902.txt, @0x96da0 +4816, 62
        events); the stream section (function@L9902, corpus
        lines 26425-26426) is a merged region (decomp file
        absent), so the island carries the whole decode.

        [E:] THE SETUP — the getVoiceMuteConfig() module
            name-load, zero-arg call; the SEPARATE one-shot
            GetItems stage the enabled/mode locals (one GetItem
            per key, each result stored and reused by both
            arms); all_ids is a SET COMPREHENSION — PySet_New +
            PySet_Add with NO 'add' GetAttr — {int(uid) for uid
            in config['list']['ids']}; automute =
            getVoiceMuteSetting('non_friends_action') ==
            'automute' (a9d30 sel-2); to_mute = set() via the
            'set' name-load + zero-arg call; members =
            self.getChannelMembers(); friends =
            self.getFriendsSet() — both receiver-locked
            GetAttrs off self.
        [E:] THE ROUTING — the compound test (enabled and mode
            == 'whitelist') resolves truthy into the loop
            reading all_ids; the falsy path enters the friends
            + automute loop body; the a9d30 with edx=7 (the
            negated CONTAINS_OP) implements `member.id not in
            ...`.
        [E:] THE WHITELIST ARM — the member loop skipping
            bot.user.id, then `if member.id not in all_ids:
            to_mute.add(member.id)` (the explicit .add via
            GetAttr); the arm returns to_mute right after its
            loop head-exhaustion.
        [E:] THE ELSE ARM — `if automute and member.id not in
            friends: to_mute.add(member.id)`; then `if enabled
            and mode == 'blacklist': for uid in all_ids:
            to_mute.add(uid)`; the final return to_mute.

        FLAG: the config/enabled/mode/all_ids/automute/to_mute/
            members/friends locals are name-inferred (the slot
            wiring is live, the spellings are not).
        FLAG: the bot.user.id skip is recorded as a dedicated
            skip-step in the whitelist loop; the predicate
            spelling follows the skip-step read.
        """
        config = getVoiceMuteConfig()
        enabled = config['enabled']
        mode = config['mode']
        all_ids = {int(uid) for uid in config['list']['ids']}
        automute = getVoiceMuteSetting('non_friends_action') == \
            'automute'
        to_mute = set()
        members = self.getChannelMembers()
        friends = self.getFriendsSet()
        if enabled and mode == 'whitelist':
            for member in members:
                if member.id == bot.user.id:
                    continue
                if member.id not in all_ids:
                    to_mute.add(member.id)
            return to_mute
        for member in members:
            if automute and member.id not in friends:
                to_mute.add(member.id)
        if enabled and mode == 'blacklist':
            for uid in all_ids:
                to_mute.add(uid)
        return to_mute
