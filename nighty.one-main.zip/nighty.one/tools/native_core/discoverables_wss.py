"""
discoverables_wss.py — the Nighty discoverables websocket client
(registry L5040-L5524), recovered via the Ghidra decomp lane.

  class DiscoverablesClient  (NAME FLAG: descriptive — the
      class name is not recovered; the evidenced attrs define
      the role: the uri/websocket/reconnect/heartbeat/
      last_status/uuid/user_id cluster)
    __init__()               — endpoint + state fields
                               (registry L5040)
    process_discoverables(..) — diff nightyOnline vs last_status,
                               notify + update (registry L5511)
    notify_status_change(..) — the Discoverables toasts
                               (registry L5524)

Endpoint recovered: wss://eu.nighty.one/v2 (const slot 1155).
"""


class DiscoverablesClient:
    """The discoverables websocket client."""

    def __init__(self):
        """Registry L5040 (discoverables client constructor).
        Content: chunk labeled L5511 (the lane-2 resync
        sppL2_process_discoverables_5511.c), per the off-by-one
        law.

        [E:] the full SetAttr cascade on the self slot, in order
             (raw L28-252): self.uri = 'wss://eu.nighty.one/v2'
             (GOT_1156/1155); self.websocket = None;
             self.is_connected = False; self.reconnect_delay =
             60 (int 60 GOT_1035); self.max_reconnect_delay = 90
             (int 90 GOT_1160); self.heartbeat_interval = 10
             (int GOT_1162); self.heartbeat_task = None;
             self.listen_task = None; self.last_status = {} (the
             (3,0) dict build, L168-174); self.key = None;
             self.uuid = None; self.user_id = None;
             self.info_data = {} (the (3,0) build, L234-237).
        [E:] any SetAttr failure exits to the shared silent path
             (PyErr clear + None, L241-253); success returns None
             after the final SetAttr.
        """
        self.uri = 'wss://eu.nighty.one/v2'
        self.websocket = None
        self.is_connected = False
        self.reconnect_delay = 60
        self.max_reconnect_delay = 90
        self.heartbeat_interval = 10
        self.heartbeat_task = None
        self.listen_task = None
        self.last_status = {}
        self.key = None
        self.uuid = None
        self.user_id = None
        self.info_data = {}

    def process_discoverables(self, discoverables):
        """Registry L5511. Content: chunk labeled L5524 (stream
        section function@L5511). Signature ('self',
        'discoverables') [E:] — const-pool tuple slot 1152.

        [E:] try-machinery opening (DAT_000a9d40, L39-60);
             iterate the `discoverables` parameter (GetIter +
             a9d60 loop, L72-78).
        [E:] per entry: d['id'] GetItem (GOT_265, L86-103) and
             d['nightyOnline'] GetItem (GOT_1026, L118-134).
        [E:] the compare cluster (a9d30, L146-180) against
             self.last_status (GOT_1153 GetAttr, L150-166 + a
             second GetAttr + GetItem at L183-212) — previous
             state fetch; the truth-selected branch calls
             self.notify_status_change (GOT_1154 GetAttr +
             build, L232-255) and then PyObject_SetItem (GOT_022,
             L302) writes the new state back into self.last_
             status.
        [E:] flag: the last_status read is GetItem-shaped in the
             stream (self.last_status[d['id']]) with the compare
             via the a9d30 cluster; the .get-vs-index read and
             the notify_status_change argument list are
             const-staged — translated with the defensive .get +
             (id, state) args, flagged.
        [E:] silent None with PyErr clear (L321-327) — the
             compiled try wraps the whole loop (exception-fetch
             at entry).
        """
        try:
            for entry in discoverables:
                entry_id = entry['id']
                online = entry['nightyOnline']
                previous = self.last_status.get(entry_id)
                if previous != online:
                    self.notify_status_change(entry_id, online)
                    self.last_status[entry_id] = online
        except Exception:
            pass
        return None

    def notify_status_change(self, user_id, online):
        """Registry L5524. Content: chunk labeled L5568 (stream
        section function@L5524).

        [E:] getNotifications()['toast'] (GOT_936 + GetItem
             GOT_937, L33-71), then .get('discoverables', False)
             (GOT_047 + GOT_1025 + False, L79-100) with the
             truth-select (L103-109) — the settings gate.
        [E:] bot.get_relationship(int(<arg>)) (GOT_244 'bot',
             GOT_1148 get_relationship, int GOT_372, L111-145)
             then .user (GOT_388, L163-187) with IsTrue gates
             (L160, L200).
        [E:] the paired branches build showToast kwargs via the
             a9d48 concat op: text = <user.name> + ' has
             disconnected from Nighty' (GOT_1151) / ' is now
             connected to Nighty' (GOT_1149), title =
             'Discoverables' (GOT_1150) — 'text' GOT_097, 'name'
             GOT_273, showToast GOT_881, L202-304.
        [E:] silent None tails (L323-359). Flag: the branch
             polarity (online -> connected toast) follows the
             stream's second branch; const-staging order !=
             execution order.
        """
        if not getNotifications()['toast'].get('discoverables',
                                               False):
            return None
        user = bot.get_relationship(int(user_id)).user
        if user:
            if online:
                showToast(text=user.name +
                          ' is now connected to Nighty',
                          title='Discoverables')
            else:
                showToast(text=user.name +
                          ' has disconnected from Nighty',
                          title='Discoverables')
        return None
