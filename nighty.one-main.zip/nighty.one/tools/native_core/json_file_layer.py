"""
json_file_layer.py — translated units of Nighty's SPP native layer.

Evidence chain per function:
  - SPP chunk (annotated capstone listing, out/spans_asm/ALL_SPANS.txt)
  - live constant streams (out/got_snatch/const_reprs.json)
  - live GOT semantics (out/got_snatch/got_map.json)
  - signature tuples from the resegmentation pass (out/resegment_attrib.json)

[E:] lines are statement-backed by named consts/API calls. Uncertainties
are stated, never guessed away.
"""

import json
import os
import shutil


def atomicJsonDump(data, path):
    """Registry line ~1244. Content: chunk labeled L1254 (off-by-one
    correction), VA 0xF020. Signature tuple [E:] ('data', 'path').

    [E:] writes ``path + '.tmp'`` then renames (atomic save)
    [E:] open(tmp, 'w', encoding='utf-8', errors='ignore')
    [E:] json.dump(data, f, indent=2)
    [E:] f.flush(); os.fsync(f.fileno()); then rename to path
    [E:] returns None
    """
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8', errors='ignore') as f:
        json.dump(data, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _loadJsonOrRestore(path, defaults, lock):
    """Registry line ~1254. Content: chunk labeled L1277. Signature
    tuple [E:] ('path', 'defaults', 'lock').

    [E:] open(path, encoding='utf-8', errors='ignore') -> json.load
    [E:] if not isinstance(data, dict): raise ValueError(
             'config root is not an object')
    [E:] on Exception (corrupt/unreadable): if os.path.exists(path):
             shutil.copyfile(path, path + '.corrupted')   # quarantine
    [E:] restores defaults via atomicJsonDump(defaults, path)
    [E:] returns a fresh dict copy of defaults in that case
    [E:] the caller's lock object is passed (serialized config IO)
    """
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError('config root is not an object')
        return data
    except Exception:
        try:
            if os.path.exists(path):
                shutil.copyfile(path, path + '.corrupted')
            atomicJsonDump(defaults, path)
            return dict(defaults)
        except Exception:
            return dict(defaults)
