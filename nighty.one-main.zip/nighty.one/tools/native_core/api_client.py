"""
api_client.py — the guild-creator API client class (registry
L5568-L5590), recovered via the Ghidra decomp lane.

The original source defines TWO twin session classes with an
identical boilerplate ctor (the const pool dedupes their
strings); THIS file carries the first one — the class whose
only other registry entry is the guild creator create@5590.
The twin — the applications-REST class (ctor L5597) — ships as
the ApplicationsApi class in app_authorize_api.py.

  class GuildsApi  (NAME FLAG: descriptive — the class name is
      not recovered from the const pool; the evidenced method
      set defines the role: the session ctor + the guild
      creator)
    __init__()        — the tls_client browser-impersonation
                        session ctor (registry L5568)
    create(name, icon) — POST /api/v9/guilds: the guild
                        creator (registry L5590)

The ctor builds a tus_client session impersonating the Discord
desktop client (client_identifier 'chrome<110-115>'), warms the
Cloudflare cookie jar via a GET to https://discord.com, and
installs the FULL hardcoded 16-key browser header set — every
value below is the exact live const.
"""

import random

from tls_client import TLSSession


class GuildsApi:
    """The guild-creator REST client."""

    def __init__(self):
        """Registry L5568 (the guild-creator class ctor — the
        TWIN). Content: chunk labeled L5590 (raw
        spp_span_create_5590.c, read end-to-end). Signature
        ('self',) [E:]-flagged (no further argument slots surface
        in the raw).

        The body is LINE-FOR-LINE the same flow as the L5597
        applications ctor (both files stage the identical const
        sequence — the pool dedupes): the TLSSession build (raw
        L60-126: the TLSSession global GOT_1106 + the kwargs
        (3,2) over 'client_identifier' GOT_1107 +
        'random_tls_extension_order' GOT_1113 + True — the value
        built by concats over 'chrome' GOT_1108 +
        random.randint (GOT_1109/1110) with the int consts 110
        (GOT_1111) and 115 (GOT_1112) + the str-convert chain
        raw L112-115; SetAttr L126), the Cloudflare cookie warm
        — self.session.cookies = self.session.get(
        'https://discord.com').cookies (raw L130-208: the session
        receiver re-GetAttr'd raw L140-148, 'get' + the url
        GOT_1114, the call raw L194, the 'cookies' GetAttr on the
        result GOT_1115 raw L195-203, SetAttr raw L208), and the
        16-key header dict — self.session.headers = { ... } (raw
        L221-357: the receiver re-GetAttr'd raw L221-231, the
        (3,0x10) build over GOT_1116-1142, SetAttr raw L357);
        silent None tail.

        [E:] the header set (every pair staged in order, raw
             L238-355): 'authority' GOT_1116 / 'discord.com'
             GOT_938; 'accept' GOT_1117 / '*/*' GOT_1118;
             'accept-language' GOT_1119 / 'en-GB,en;q=0.5'
             GOT_1120; 'content-type' GOT_1121 /
             'application/json' GOT_136; 'origin' GOT_1122 /
             'https://discord.com' GOT_1114; 'referer' GOT_1123 /
             'https://discord.com/' GOT_1124; 'sec-ch-ua'
             GOT_1125 / '"Not?A_Brand";v="8", "Chromium";v="108"'
             GOT_1126 (the live dump's literal);
             'sec-ch-ua-mobile' GOT_1127 / '?0' GOT_1128;
             'sec-ch-ua-platform' GOT_1129 / '"Windows"' GOT_1130;
             'sec-fetch-dest' GOT_1131 / 'empty' GOT_1132;
             'sec-fetch-mode' GOT_1133 / 'cors' GOT_1134;
             'sec-fetch-site' GOT_1135 / 'same-origin' GOT_1136;
             'user-agent' GOT_476 / the full Discord-desktop UA
             GOT_1137; 'x-debug-options' GOT_1138 /
             'bugReporterEnabled' GOT_1139; 'x-discord-timezone'
             GOT_1140 / 'Europe/Prague' GOT_1141;
             'x-super-properties' GOT_477 / GOT_1142 — the full
             592-char const, recovered complete from the marshal
             stream.
        """
        self.session = TLSSession(
            client_identifier='chrome' +
                              str(random.randint(110, 115)),
            random_tls_extension_order=True)
        self.session.cookies = \
            self.session.get('https://discord.com').cookies
        self.session.headers = {
            'authority': 'discord.com',
            'accept': '*/*',
            'accept-language': 'en-GB,en;q=0.5',
            'content-type': 'application/json',
            'origin': 'https://discord.com',
            'referer': 'https://discord.com/',
            'sec-ch-ua':
                '"Not?A_Brand";v="8", "Chromium";v="108"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': ('Mozilla/5.0 (Windows NT 10.0; WOW64) '
                           'AppleWebKit/537.36 (KHTML, like '
                           'Gecko) discord/1.0.9016 '
                           'Chrome/108.0.5359.215 '
                           'Electron/22.3.12 Safari/537.36'),
            'x-debug-options': 'bugReporterEnabled',
            'x-discord-timezone': 'Europe/Prague',
            'x-super-properties': (
                'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxl'
                'YXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDE2'
                'Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDUiLCJvc19hcmNoIjoieDY0Iiwic3lz'
                'dGVtX2xvY2FsZSI6InN2IiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81'
                'LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAo'
                'S0hUTUwsIGxpa2UgR2Vja28pIGRpc2NvcmQvMS4wLjkwMTYgQ2hyb21lLzEwOC4w'
                'LjUzNTkuMjE1IEVsZWN0cm9uLzIyLjMuMTIgU2FmYXJpLzUzNy4zNiIsImJyb3dz'
                'ZXJfdmVyc2lvbiI6IjIyLjMuMTIiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoyMTg2'
                'MDQsIm5hdGl2ZV9idWlsZF9udW1iZXIiOjM1MjM2LCJjbGllbnRfZXZlbnRfc291'
                'cmNlIjpudWxsfQ=='
            ),
        }

    def create(self, name, icon):
        """Registry L5590 (the guild creator). Content: chunk
        labeled L5597 (raw spp_span___init___5597.c).

        [E:] argument frame: a9d50(param_1, 1, 2) — the
             2-argument frame (raw L32); params: name (in_stack
             slot 0x90), icon (in_stack slot 0x98); raw L156-165
             pair them to the 'name' (GOT_273) and 'icon'
             (GOT_959) dict keys.
        [E:] self.session.headers.update({'Authorization':
             getCurrentToken()}) — raw L37-104 (session GOT_561,
             headers GOT_132, update GOT_562, Authorization
             GOT_133, getCurrentToken GOT_563, the (3,1) +
             (1,1) dict/tuple builds, the update call raw L101).
        [E:] return self.session.post('https://discord.com/api/
             v9/guilds', json={'name': name, 'icon': icon,
             'channels': [], 'system_channel_id': None,
             'guild_template_code': None}).json() — the post
             GetAttr (GOT_564, raw L127-136); the URL GOT_1144
             via the a9d48 1-piece format (raw L137-144); the
             json kwarg: the (3,1) wrap over the (3,5) 5-key dict
             (raw L146-183) — the 'channels' value is the
             HARDCODED empty list (the a9d18 (2,0) empty-list
             build sits inline between the 'channels' (GOT_294)
             and 'system_channel_id' (GOT_1145) key stagings, raw
             L166-169); system_channel_id and guild_template_code
             (GOT_1145/1146) both take None (GOT_030, raw
             L173-181); the response handled raw L185-216 ('json'
             GetAttr GOT_143 + the 0-arg call + the direct
             return of the parsed payload; the silent-None/
             exception tail raw L218-236).
        """
        self.session.headers.update(
            {'Authorization': getCurrentToken()})
        return self.session.post(
            'https://discord.com/api/v9/guilds',
            json={'name': name,
                  'icon': icon,
                  'channels': [],
                  'system_channel_id': None,
                  'guild_template_code': None}).json()
