# bootfix46.py - run the rebuild briefly, capture the first
# crash, report missing globals.
import os
import subprocess
import sys
import threading
import time

PY38 = r'C:\Users\brian\Downloads\Nighty\py38\python.exe'
APP = (r'D:\SSD-Offload\brian\Downloads\Nighty'
       r'\NightyRecovered\rebuild\app\run_nighty.py')
LOG = (r'C:\Users\brian\Downloads\Nighty\oracle\out'
       r'\rebuild46\boot.log')
os.makedirs(os.path.dirname(LOG), exist_ok=True)

env = dict(os.environ)
env['PYTHONIOENCODING'] = 'utf-8'
p = subprocess.Popen([PY38, APP], stdout=open(LOG, 'w'),
                     stderr=subprocess.STDOUT, env=env)
time.sleep(14)
p.kill()
out = open(LOG, encoding='utf-8', errors='replace').read()
# find NameError/AttributeError lines
import re
errs = []
for ln in out.split('\n'):
    if ('NameError' in ln or 'AttributeError' in ln or
            'ImportError' in ln or 'ModuleNotFoundError' in ln):
        errs.append(ln.strip())
seen = set()
uniq = []
for e in errs:
    m = re.search(r"name '(\S+)'", e)
    k = m.group(1) if m else e
    if k not in seen:
        seen.add(k)
        uniq.append(e[:110])
print('distinct errors:', len(uniq))
for e in uniq[:20]:
    print('  ', e)
