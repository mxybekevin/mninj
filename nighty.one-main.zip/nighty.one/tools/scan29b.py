# scan29b.py - the corrected whole-body matcher: candidates are keyed
# by EXACT BYTES (the corpus law: a real body recurs byte-identical
# across independent captures; junk windows scatter). Reruns over the
# same corpora as scan29 with sub-run scanning and reports, per armed
# target, every byte-identical candidate with its recurrence count.
import collections
import glob
import json
import marshal
import math
import opcode
import os
import struct
import types
import dis

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out')
V5D = os.path.join(OUT, 'v5')
SNAPS = os.path.join(OUT, 'fence_snaps')
FENCE27 = os.path.join(OUT, 'armed_snatch')
FRD = os.path.join(OUT, 'fragverify')

VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}
NAME_OPS = {'LOAD_GLOBAL', 'STORE_GLOBAL', 'LOAD_NAME', 'STORE_NAME',
            'DELETE_NAME', 'LOAD_ATTR', 'STORE_ATTR', 'IMPORT_NAME',
            'IMPORT_FROM', 'LOAD_METHOD'}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)


def is_armed(code):
    return (len(code) >= 6 and code[0] == 0x74 and
            code[2:4] == b'\x83\x00' and code[4:6] == b'\x09\x00')


def learn_profile():
    hist = collections.Counter()
    stack_ct = 0
    for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
        try:
            co = marshal.load(open(p, 'rb'))
        except Exception:
            continue
        if not isinstance(co, types.CodeType) or is_armed(co.co_code):
            continue
        stack = [(co, 0)]
        while stack:
            c, d = stack.pop()
            if d > 20:
                continue
            hist.update(c.co_code[i]
                        for i in range(0, len(c.co_code) - 1, 2))
            for k in c.co_consts:
                if isinstance(k, types.CodeType):
                    stack.append((k, d + 1))
    total = sum(hist.values())
    return {op: math.log((hist[op] + 0.5) / (total + 0.5 * len(VALID)))
            for op in VALID}


def lnotab_offsets(lnotab):
    offs = {0}
    start = 0
    for i in range(0, len(lnotab), 2):
        start += lnotab[i]
        offs.add(start)
    return offs


def hard_ok(win, co, L, offs):
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nderefc = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    for i in range(0, L, 2):
        op = win[i]
        if op not in VALID:
            return False
        arg = win[i + 1] if i + 1 < L else 0
        nm = opcode.opname[op]
        if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == 'LOAD_CONST' and arg >= nconst:
            return False
        if nm in ('LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                  'LOAD_CLOSURE') and arg >= nderefc:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


def stack_walk_depth(win, L):
    d = 0
    lo = 0
    for i in range(0, L, 2):
        op = win[i]
        arg = win[i + 1] if i + 1 < L else 0
        try:
            e = dis.stack_effect(op, arg) if op >= opcode.HAVE_ARGUMENT \
                else dis.stack_effect(op)
        except ValueError:
            return None
        d += e
        lo = min(lo, d)
    return lo


targets = []
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        co = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if isinstance(co, types.CodeType) and is_armed(co.co_code):
        targets.append((str(co.co_name), co.co_firstlineno, co))
print('armed targets: %d' % len(targets))
logp = learn_profile()
by_len = collections.defaultdict(list)
for nm, fl, co in targets:
    by_len[len(co.co_code)].append((nm, fl, co))
lens = sorted(by_len)
MINLEN = lens[0]

# THE LAW: candidates keyed by exact bytes; recurrence count = evidence
cands = collections.defaultdict(collections.Counter)   # key -> bytes->count
prov = {}


def try_hit(run, L, src, note):
    if len(run) != L:
        return
    for nm, fl, co in by_len.get(L, ()):
        if not hard_ok(run, co, L, lnotab_offsets(co.co_lnotab or b'')):
            continue
        ops = [run[i] for i in range(0, L, 2)]
        s = sum(logp.get(o, -9.0) for o in ops) / len(ops)
        dv = len(set(ops)) / len(ops)
        if s < -8.245 or dv < 0.06:
            continue
        dp = stack_walk_depth(run, L)
        if dp is not None and dp < -600:
            continue
        cands[(nm, fl)][run] += 1
        prov.setdefault((nm, fl, run), []).append(src)


def scan_buffer(payload, src, note):
    pl = len(payload) & ~1
    for parity in (0, 1):
        pos = parity
        while pos < pl - 4:
            if payload[pos] not in VALID:
                pos += 2
                continue
            q = pos
            while q < pl and payload[q] in VALID:
                q += 2
            run_len = q - pos
            if run_len >= MINLEN:
                want = [L for L in lens if L <= run_len]
                data = bytes(payload[pos:pos + run_len])
                for L in want:
                    for off in range(0, run_len - L + 1, 2):
                        try_hit(data[off:off + L], L, src, note)
            pos = q if q > pos else pos + 2


for name in ('grab_stream.bin', 'hammer_stream.bin'):
    p = os.path.join(SNAPS, name)
    if not os.path.exists(p):
        continue
    n = 0
    with open(p, 'rb') as f:
        while True:
            head = f.read(16)
            if len(head) < 16:
                break
            addr, ln_, t_ms = struct.unpack('<QII', head)
            if ln_ == 0 or ln_ > 2 * 1024 * 1024:
                break
            payload = f.read(ln_)
            if len(payload) < ln_:
                break
            n += 1
            scan_buffer(payload, '%s@%#x' % (name, addr),
                        '%s rec %d' % (name, n))
            if n % 20000 == 0:
                print('  %s: %d records...' % (name, n), flush=True)
    print('%s done: %d records' % (name, n), flush=True)

for p in sorted(glob.glob(os.path.join(SNAPS, 'target_stream_*.bin'))):
    n = 0
    with open(p, 'rb') as f:
        while True:
            head = f.read(16)
            if len(head) < 16:
                break
            addr, ln_, t_ms = struct.unpack('<QII', head)
            if ln_ == 0 or ln_ > 2 * 1024 * 1024:
                break
            payload = f.read(ln_)
            if len(payload) < ln_:
                break
            n += 1
            scan_buffer(payload, '%s@%#x' % (os.path.basename(p), addr),
                        '%s rec %d' % (os.path.basename(p), n))
    print('%s done: %d records' % (os.path.basename(p), n), flush=True)

files = sorted(glob.glob(os.path.join(FENCE27, 'cand_live_*.bin')))
print('fence27 windows: %d' % len(files), flush=True)
for k, p in enumerate(files):
    with open(p, 'rb') as f:
        payload = f.read()
    scan_buffer(payload, os.path.basename(p), 'fence27 %d' % (k + 1))
    if (k + 1) % 12000 == 0:
        print('  fence27: %d/%d...' % (k + 1, len(files)), flush=True)
print('fence27 done', flush=True)

# --------------------------------------------------- the honest verdicts
report = []
for (nm, fl), ctr in sorted(cands.items()):
    rows = ctr.most_common(8)
    print('%s L%d: %d distinct byte-candidates, top counts: %s'
          % (nm, fl, len(ctr), [c for _, c in rows[:6]]))
    for run, cnt in rows:
        ops = [run[i] for i in range(0, len(run), 2)]
        s = sum(logp.get(o, -9.0) for o in ops) / len(ops)
        dv = len(set(ops)) / len(ops)
        report.append({'name': nm, 'line': fl, 'len': len(run),
                       'count': cnt, 'score': round(s, 2),
                       'div': round(dv, 2),
                       'provenance': prov.get((nm, fl, run), [])[:3],
                       'head': run[:8].hex()})
        if cnt >= 2:
            fn = 'scan29b_%s_L%d_n%d.bin' % (
                nm.replace('.', '_'), fl, cnt)
            with open(os.path.join(FRD, fn), 'wb') as f:
                f.write(run)
            print('   RECURRING %d x len=%d head=%s -> %s'
                  % (cnt, len(run), run[:8].hex(), fn))
with open(os.path.join(FRD, 'scan29b_report.json'), 'w') as f:
    json.dump(report, f, indent=1)
print('SCAN29B DONE')
