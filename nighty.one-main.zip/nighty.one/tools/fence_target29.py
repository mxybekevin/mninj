"""fence_target29.py - the live capture session for the remaining frontier:
the 3 still-armed units + the 81 no-body units (junk/stamp co_code at
rest). In-process (fence26/27 harness class; ReadProcessMemory on SELF
only - no other process is ever touched; the license stays reseeded in
%APPDATA%\\Nighty Selfbot\\auth.json).

Three harvests in one run:
  A. post-call marshals: force-call every pending callable (garbage
     args; exceptions swallowed - the decrypt happens before arg
     validation), then immediately marshal-dump its code object. If
     pyarmor restores co_code in place at call time, these marshals
     hold REAL PLAIN WORDCODE for the whole 81-unit set.
  B. scratch stream: a thread continuously harvests maximal valid-
     opcode runs from the harness heap (EXCLUDING loaded images and
     the spp core copies) into a <QII>+payload record stream, for the
     byte-keyed whole-body matcher.
  C. inline trio matcher: the still-armed trio's exact expected sizes
     are validated live (whole exact-length runs, hard_ok operands)
     with byte-keyed recurrence counts.

Output: oracle/out/fence29/*.marshal + fence29_stream.bin + log.
"""
import ctypes
import glob
import json
import marshal
import os
import re
import struct
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
RTP = os.path.join(OUT, 'fence29')
STREAM = os.path.join(RTP, 'fence29_stream.bin')
os.makedirs(RTP, exist_ok=True)
EXTRACT = r'C:\Users\brian\Downloads\Nighty\Nighty.exe_extracted'
PYZ_EXT = os.path.join(EXTRACT, 'PYZ.pyz_extracted')

sys.path.insert(0, HERE)
from spp_fake import make_fake_module

import opcode
VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}
NAME_OPS = {'LOAD_GLOBAL', 'STORE_GLOBAL', 'LOAD_NAME', 'STORE_NAME',
            'DELETE_NAME', 'LOAD_ATTR', 'STORE_ATTR', 'IMPORT_NAME',
            'IMPORT_FROM', 'LOAD_METHOD'}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)

k32 = ctypes.WinDLL('kernel32')
T0 = time.time()
LOGH = open(os.path.join(RTP, 'fence29_session.log'), 'w', 1)


def log(m):
    LOGH.write('%s\n' % m)


# ------------------------------------------------------------ the worklist
census = json.load(open(os.path.join(OUT, 'pending_census.json')))
work = [(e['name'], e['line'], e['size'], k)
        for k in ('ARMED', 'OTHER')
        for e in census[k]]
if not work:
    # fall back to the whole pending tail
    work = [(e['name'], e['line'], e['size'], '?')
            for e in census['PLAIN'] +
            (census.get('UTF16') or [])]
print('[29] worklist: %d units' % len(work), flush=True)
log('worklist: %d' % len(work))

# the still-armed trio's code objects for the inline matcher + metadata
TARGET_CO = {}
for e in census['ARMED']:
    TARGET_CO.setdefault(e['line'], None)
for p in glob.glob(os.path.join(OUT, 'v5', 'v5_*.marshal')):
    try:
        co = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not hasattr(co, 'co_firstlineno'):
        continue
    stack = [(co, 0)]
    while stack:
        c, d = stack.pop()
        if d > 20:
            continue
        if c.co_firstlineno in TARGET_CO and \
                TARGET_CO[c.co_firstlineno] is None:
            TARGET_CO[c.co_firstlineno] = (str(c.co_name), c)
        for k in c.co_consts:
            if hasattr(k, 'co_firstlineno'):
                stack.append((k, d + 1))
ARMED_BY_LEN = {}
for line, pair in TARGET_CO.items():
    if pair:
        nm, co = pair
        ARMED_BY_LEN[len(co.co_code)] = co
        log('armed target: %s L%d +%d' % (nm, line, len(co.co_code)))
MIN_ARMED = min(ARMED_BY_LEN) if ARMED_BY_LEN else 0

LAB = {'ARMED': 'armed', 'OTHER': 'other', '?': 'unk'}


class MBI(ctypes.Structure):
    _fields_ = [('BaseAddress', ctypes.c_void_p),
                ('AllocationBase', ctypes.c_void_p),
                ('AllocationProtect', ctypes.c_uint32),
                ('RegionSize', ctypes.c_size_t),
                ('State', ctypes.c_uint32),
                ('Protect', ctypes.c_uint32),
                ('Type', ctypes.c_uint32)]


def walk_regions():
    mbi = MBI()
    addr = 0x10000
    hps = ctypes.c_void_p(k32.GetCurrentProcess())
    while addr < 0x7FFFFFFEFFFF:
        r = k32.VirtualQueryEx(hps, ctypes.c_void_p(addr),
                               ctypes.byref(mbi), ctypes.sizeof(mbi))
        if r == 0:
            break
        if mbi.RegionSize:
            yield (mbi.BaseAddress or addr, mbi.RegionSize,
                   mbi.Protect, mbi.State, mbi.Type)
            addr += mbi.RegionSize
        else:
            addr += 0x1000


def safe_read(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t(0)
    ok = k32.ReadProcessMemory(
        ctypes.c_void_p(k32.GetCurrentProcess()),
        ctypes.c_void_p(addr), buf, size, ctypes.byref(got))
    if not ok or got.value < size:
        return None
    return buf.raw[:size]


ELF_NEEDLE = bytes.fromhex('8b0572740100488d4c24580f11742430')
ANCHOR_VA = 0x931A0
IMG_LEN = 0xafac0


def find_elf_bases():
    bases = set()
    needle = ELF_NEEDLE
    for base, size, prot, state, mtype in walk_regions():
        if state != 0x1000 or mtype == 0x1000000:
            continue
        if not (prot & (0x02 | 0x04 | 0x20 | 0x40)) or (prot & 0x100):
            continue
        if size < 0x2000 or size > 0x1000000:
            continue
        pos = 0
        while pos + len(needle) <= size:
            chunk = safe_read(base + pos,
                              min(0x40000, size - pos))
            if not chunk:
                break
            i = chunk.find(needle)
            while i >= 0:
                bases.add(base + pos + i - ANCHOR_VA)
                i = chunk.find(needle, i + 1)
            pos += 0x40000 if len(chunk) == 0x40000 else len(chunk)
    return bases


DIE = [False]
EXEC_DONE = [False]
G = {}
GOT_HITS = {}
STREAMH = None
STREAM_BUDGET = [600 * 1024 * 1024]
STREAM_WROTE = [0]
ROUNDS = [0]


def lnotab_offsets(lnotab):
    offs = {0}
    start = 0
    for i in range(0, len(lnotab or b''), 2):
        start += lnotab[i]
        offs.add(start)
    return offs


def hard_ok(win, co, L, offs):
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nd = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    for i in range(0, L, 2):
        op = win[i]
        if op not in VALID:
            return False
        arg = win[i + 1] if i + 1 < L else 0
        nm = opcode.opname[op]
        if op < opcode.HAVE_ARGUMENT and arg != 0:
            return False
        if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == 'LOAD_CONST' and arg >= nconst:
            return False
        if nm in ('LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                  'LOAD_CLOSURE') and arg >= nd:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


def try_armed_hit(run):
    L = len(run)
    for co in [c for ln, c in ARMED_BY_LEN.items() if ln == L]:
        if hard_ok(run, co, L, lnotab_offsets(co.co_lnotab)):
            key = bytes(run)
            GOT_HITS.setdefault((str(co.co_name), co.co_firstlineno),
                                {}).setdefault(key, 0)
            GOT_HITS[(str(co.co_name), co.co_firstlineno)][key] += 1
            log('LIVE-ARMED-HIT %s L%d count=%d sha=%s'
                % (co.co_name, co.co_firstlineno,
                   GOT_HITS[(str(co.co_name),
                             co.co_firstlineno)][key],
                   key.hex()[:16]))


def sampler_thread():
    global STREAMH
    bases = find_elf_bases()
    log('spp copy bases: %s' % [hex(b) for b in bases])
    STREAMH = open(STREAM, 'wb')
    while not DIE[0] and time.time() - T0 < 150:
        try:
            sweep = 0
            for base, size, prot, state, mtype in walk_regions():
                if state != 0x1000:
                    continue
                if mtype == 0x1000000:
                    continue
                if not (prot & (0x02 | 0x04 | 0x20 | 0x40)) or \
                        (prot & 0x100):
                    continue
                if mtype == 0x40000 and size > 0x400000:
                    continue
                if size > 0x1000000:
                    continue
                if any(b - 0x2000 <= base <
                       b + IMG_LEN + 0x2000 for b in bases):
                    continue
                pos = 0
                while pos + 0x800 <= size and \
                        STREAM_WROTE[0] < STREAM_BUDGET[0]:
                    chunk = safe_read(base + pos,
                                      min(0x8000, size - pos))
                    if not chunk:
                        break
                    # maximal valid-opcode runs -> records
                    pl = len(chunk) & ~1
                    rpos = 0
                    while rpos < pl - 6:
                        if chunk[rpos] not in VALID:
                            rpos += 2
                            continue
                        q = rpos
                        while q < pl and chunk[q] in VALID:
                            q += 2
                        run_len = q - rpos
                        if run_len >= 16:
                            payload = bytes(chunk[rpos:q])
                            head = struct.pack(
                                '<QII', base + pos + rpos,
                                len(payload),
                                int(time.time() * 1000) & 0xFFFFFF)
                            STREAMH.write(head + payload)
                            STREAM_WROTE[0] += len(payload) + 16
                            if len(payload) in ARMED_BY_LEN:
                                try_armed_hit(chunk[rpos:q])
                        rpos = q if q > rpos else rpos + 2
                    pos += 0x8000
                    sweep += 1
            ROUNDS[0] += 1
        except BaseException as e:
            log('sampler err %r' % (e,))
        time.sleep(0.05)
    try:
        STREAMH.flush()
        STREAMH.close()
    except Exception:
        pass
    log('sampler done: rounds=%d stream=%d bytes' %
        (ROUNDS[0], STREAM_WROTE[0]))


def caller_thread():
    # wait for the module exec to finish so classes/functions exist
    while not EXEC_DONE[0] and time.time() - T0 < 90:
        time.sleep(0.2)
    if not EXEC_DONE[0]:
        return
    import types as _t
    calls_ok = {}
    errs = {}
    plan = []
    # module-level callables
    for name, line, size, cls in work:
        obj = G.get(name)
        if callable(obj) and hasattr(obj, '__code__'):
            plan.append((name, line, obj))
    log('call plan phase 1: %d module-level'
        % len(plan))
    have = {(p[0], p[1]) for p in plan}
    for name, line, size, cls in work:
        if (name, line) in have:
            continue
        for v in list(G.values()):
            if isinstance(v, type):
                try:
                    for an, attr in vars(v).items():
                        if callable(attr) and \
                                hasattr(attr, '__code__') and \
                                attr.__code__.co_firstlineno == line:
                            plan.append((name, line, attr))
                            raise _StopScan()
                except _StopScan:
                    break
                except Exception:
                    continue
    log('call plan: %d callables' % len(plan))
    for name, line, obj in plan:
        for args in ((), (None,), (None, None),
                     (None, None, None)):
            try:
                if args:
                    obj(*args)
                else:
                    obj()
                calls_ok[(name, line)] = \
                    calls_ok.get((name, line), 0) + 1
            except BaseException as e:
                k = '%s:%s' % (name, type(e).__name__)
                errs[k] = errs.get(k, 0) + 1
        # post-call marshal harvest
        try:
            code = obj.__code__
            fn = 'post_%s_L%d.marshal' % (
                name.replace('.', '_'), line)
            with open(os.path.join(RTP, fn), 'wb') as f:
                marshal.dump(code, f)
        except BaseException as e:
            log('marshal fail %s L%d %r' % (name, line, e))
    log('calls ok=%r errs=%r' % (
        {k: v for k, v in list(calls_ok.items())[:10]},
        {k: v for k, v in list(errs.items())[:16]}))


class _StopScan(Exception):
    pass


threading.Thread(target=sampler_thread, daemon=True).start()
threading.Thread(target=caller_thread, daemon=True).start()


def killer():
    time.sleep(200)
    log('killer exit')
    LOGH.flush()
    os._exit(0)


threading.Thread(target=killer, daemon=True).start()

os.environ['TCL_LIBRARY'] = os.path.join(PYZ_EXT, '_tcl_data')
os.environ['TK_LIBRARY'] = os.path.join(PYZ_EXT, '_tk_data')
sys.path.insert(1, EXTRACT)
sys.path.append(PYZ_EXT)
sys.path.append(os.path.join(EXTRACT, 'win32'))
sys.path.append(os.path.join(PYZ_EXT, 'win32'))
sys.path.append(os.path.join(HERE, 'py38_extra'))

make_fake_module('spp_export_api')

with open(os.path.join(HERE, 'Nighty.pyc'), 'rb') as f:
    raw = f.read()
bootstrap = marshal.loads(raw[16:])
g = {'__name__': '__main__',
     '__file__': os.path.join(EXTRACT, 'Nighty.pyc'),
     '__builtins__': __builtins__}
G.update(g)
print('[29] bootstrap exec', flush=True)
try:
    exec(bootstrap, g)
except BaseException as e:
    print('[29] exec ended: %r' % (e,), flush=True)
EXEC_DONE[0] = True
G.update(g)
print('[29] exec done t=%.1f; plan-ready' % (time.time() - T0),
      flush=True)
time.sleep(190)
