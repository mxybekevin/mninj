"""
build_coverage.py - the everything-register: per-registry-entry
recovery status for all 371 SPP functions.

Status per entry:
  SHIPPED  - translated + committed in native_core/<module>.py
             (detected via the docstring "Registry L<line>" citations)
  ARMED    - content chunk is a zero-event cipher blob (only the
             two census-confirmed spans; the function bodies live in
             pyarmor's armed store, not in SPP space)
  TODO     - decompiled + streamed, awaiting translation

Also emits the decomp-file mapping per function (the off-by-one
content-chunk file).
"""
import os
import re
import struct

ORACLE = r"C:\Users\brian\Downloads\Nighty\oracle"
CORE = r"C:\Users\brian\Downloads\Nighty\NightyRecovered\native_core"

elf = open(os.path.join(ORACLE, "out", "spp_core.elf"), "rb").read()
blob = elf[0x40:0x40 + 0xafac0]
trailer = elf[0x40 + 0xafac0:]
n = len(trailer) // 32
census_zero = set()
try:
    for line in open(os.path.join(ORACLE, "out", "zero_event_census.txt"),
                     encoding="utf-8"):
        if line.startswith("chunk L"):
            m = re.match(r"chunk L(\d+) ", line)
            if m:
                census_zero.add(int(m.group(1)))
except FileNotFoundError:
    pass
print("zero-event chunks from census:", sorted(census_zero))

spans = {}
prev = 0
order = []
for k in range(n):
    p, s, t, z = struct.unpack_from("<4Q", trailer, k * 32)
    if s == 0:
        break
    e = elf.index(b"\x00", p)
    m = re.match(r"^spp_(.*)_(\d+)$", elf[p:e].decode("latin1"))
    if m:
        spans[int(m.group(2))] = (m.group(1), prev, s - prev)
        order.append(int(m.group(2)))
    prev = s


def sanitize(s, maxlen=64):
    return re.sub(r"[^0-9A-Za-z_]", "_", str(s))[:maxlen]


DEC = os.path.join(ORACLE, "out", "ghidra_decomp")


def decomp_file(ln):
    nm = spans[ln][0]
    return "spp_span_%s_%d.c" % (sanitize(nm), ln)


# shipped detection from the committed docstrings
shipped = {}
for fn in sorted(os.listdir(CORE)):
    if not fn.endswith(".py"):
        continue
    txt = open(os.path.join(CORE, fn), encoding="utf-8").read()
    for m in re.finditer(r"Registry (?:line ~|L)(\d+)", txt):
        line = int(m.group(1))
        if line not in shipped:
            shipped[line] = fn

# armed detection: function whose content chunk is a zero-event span
armed = set()
for idx, ln in enumerate(order):
    if idx + 1 < len(order) and order[idx + 1] in census_zero:
        armed.add(ln)

rows = []
n_ship = n_arm = n_todo = 0
for idx, ln in enumerate(order):
    nm, a, sz = spans[ln]
    chunk = order[idx + 1] if idx + 1 < len(order) else -1
    f = decomp_file(chunk) if chunk > 0 else "<tail>"
    exists = chunk > 0 and os.path.exists(os.path.join(DEC, f))
    if ln in shipped:
        status = "SHIPPED"
        extra = "-> " + shipped[ln]
        n_ship += 1
    elif ln in armed:
        status = "ARMED"
        extra = "-> armed ledger (cipher blob chunk L%d)" % chunk
        n_arm += 1
    else:
        status = "TODO"
        extra = "-> %s%s" % (f, "" if exists else " (file merged/absent)")
        n_todo += 1
    rows.append("L%-6d %-44s %-7s %s" % (ln, nm, status, extra))

out = ["COVERAGE: %d SHIPPED / %d TODO / %d ARMED / %d total"
       % (n_ship, n_todo, n_arm, len(order)), ""]
out += rows
with open(os.path.join(ORACLE, "out", "coverage.txt"), "w",
          encoding="utf-8") as f:
    f.write("\n".join(out))
print(out[0])
todo_lines = [r for r in rows if " TODO " in r]
print("first TODOs:")
print("\n".join(todo_lines[:12]))
