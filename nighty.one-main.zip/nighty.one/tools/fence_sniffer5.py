"""
fence_sniffer5.py - DEDICATED max-cadence sniffer for specific target units.

sniffer3 divides attention across every tracked buffer (~300 windows x 64
pages round-robin) - for a unit whose decrypt window lives only
microseconds, the per-buffer cadence is far too slow. This variant:

  * reads fence_calls.log 'call' entries but keeps ONLY buffers whose
    ids match the pending TARGET set (supplied as a list of names);
  * sweeps just those buffers' +-16KB at maximum speed in a tight loop;
  * records any page change with timestamps to target_stream.bin.

usage: python fence_sniffer5.py <pid> <name-substring> [<name-substring>...]
"""
import ctypes
import marshal
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
os.makedirs(SNAPS, exist_ok=True)
CALLS_LOG = os.path.join(OUT, "fence_calls.log")

pid = int(sys.argv[1])
subs = [a.lower() for a in sys.argv[2:]]
if not subs:
    subs = ["nighty2", "toast", "getgooglelanguages"]

STORE_NAME = "target_stream_%d.bin" % pid
STREAM = os.path.join(SNAPS, STORE_NAME)

k32 = ctypes.WinDLL("kernel32", use_last_error=True)
h = k32.OpenProcess(0x0010 | 0x0400, False, pid)
if not h:
    print("[-] OpenProcess failed:", k32.GetLastError())
    sys.exit(1)
print("[+] dedicated sniffer pid %d targets=%s" % (pid, subs), flush=True)


def rpm(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t()
    ok = k32.ReadProcessMemory(h, ctypes.c_void_p(addr), buf, ctypes.c_size_t(size),
                               ctypes.byref(got))
    if not ok:
        return None
    return buf.raw[:got.value]


PAGE = 0x1000
BEFORE = 4        # pages before the buffer
AFTER = 4         # pages after

# collect target buffer addresses from the calls log (name-substring match)
target_keys = {}          # pagekey -> buf addr
file_pos = 0
t0 = time.time()
pages = {}                # page -> last content
n_records = 0
last_shown = 0.0

stream = open(STREAM, "ab", buffering=1024 * 512)

while time.time() - t0 < 6000:
    # refresh target list from the log
    if os.path.exists(CALLS_LOG):
        with open(CALLS_LOG, "r", encoding="utf-8", errors="replace") as f:
            f.seek(file_pos)
            data = f.read()
            file_pos = f.tell()
        for line in data.splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[1] in ("call", "fcall", "newcall", "refocus"):
                try:
                    cid = int(parts[2])
                    ptr = int(parts[3])
                except ValueError:
                    continue
                if not ptr:
                    continue
                nameline = line.lower()
                if any(s in nameline for s in subs):
                    key = (ptr >> 12) << 12
                    if key not in target_keys:
                        target_keys[key] = ptr
                        print("[+] target window @%#x (buf %#x) n=%d" % (
                            key, ptr, len(target_keys)), flush=True)

    changed = 0
    for key in list(target_keys.keys()):
        for pi in range(-BEFORE, 1 + AFTER):
            pa = key + pi * PAGE
            try:
                content = rpm(pa, PAGE)
            except Exception:
                content = None
            if content is None:
                continue
            ent = pages.get(pa)
            if ent is None:
                pages[pa] = content
                changed += 1
                ts = time.time() - t0
                stream.write(struct.pack("<QII", pa, PAGE, int(ts * 1000) & 0xFFFFFF))
                stream.write(content)
                n_records += 1
            elif content != ent:
                pages[pa] = content
                changed += 1
                ts = time.time() - t0
                stream.write(struct.pack("<QII", pa, PAGE, int(ts * 1000) & 0xFFFFFF))
                stream.write(content)
                n_records += 1
    if time.time() - last_shown > 10:
        last_shown = time.time()
        print("[%6.1f] windows=%d records=%d" % (
            time.time() - t0, len(target_keys), n_records), flush=True)

stream.close()
print("[+] done: %d records -> %s" % (n_records, STORE_NAME), flush=True)
