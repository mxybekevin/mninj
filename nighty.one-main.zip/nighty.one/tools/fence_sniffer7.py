"""
fence_sniffer7.py - VirtualProtectEx mid-flight fence grabber.

Discovery driving this: sniffer4/5/3 proved decrypted blocks are only
present while their pages sit in the NOACCESS fence (RPM fails = 41k
observed failures at exactly those moments; readable snapshots always
show armed bytes). External processes cannot read NOACCESS pages - but
we CAN (on a suspended process):
    VirtualProtectEx(h, addr, size, PAGE_READONLY, &old) -> RPM -> restore
So:
  * poll known armed buffer windows (from fence_calls.log)
  * the moment a probe FAILS (fence active): NtSuspendProcess
  * flip every NOACCESS page in the window to READONLY, read, restore
  * NtResumeProcess
  * store records (dedup: sha1 per addr) to grab7_stream.bin
Plaintext blocks end up in the stream; plainscan-style diffing offline.
"""
import ctypes
import hashlib
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
os.makedirs(SNAPS, exist_ok=True)
CALLS_LOG = os.path.join(OUT, "fence_calls.log")
STREAM = os.path.join(SNAPS, "grab7_stream.bin")

pid = int(sys.argv[1])
k32 = ctypes.WinDLL("kernel32", use_last_error=True)
ntdll = ctypes.WinDLL("ntdll", use_last_error=True)

PROCESS_VM_READ = 0x0010
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_SUSPEND_RESUME = 0x0800
PROCESS_VM_OPERATION = 0x0008

h = k32.OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION |
                    PROCESS_SUSPEND_RESUME | PROCESS_VM_OPERATION, False, pid)
if not h:
    print("[-] OpenProcess failed:", k32.GetLastError())
    sys.exit(1)
print("[+] target pid %d" % pid)


def suspend():
    ntdll.NtSuspendProcess(h)


def resume():
    ntdll.NtResumeProcess(h)


class MBI(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p), ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", ctypes.c_ulong), ("RegionSize", ctypes.c_size_t),
        ("State", ctypes.c_ulong), ("Protect", ctypes.c_ulong),
        ("Type", ctypes.c_ulong),
    ]


def rpm(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t()
    ok = k32.ReadProcessMemory(h, ctypes.c_void_p(addr), buf,
                               ctypes.c_size_t(size), ctypes.byref(got))
    if not ok:
        return None
    return buf.raw[:got.value]


def query(addr):
    mbi = MBI()
    r = k32.VirtualQueryEx(h, ctypes.c_void_p(addr), ctypes.byref(mbi),
                           ctypes.sizeof(mbi))
    if r == 0:
        return None
    return (mbi.BaseAddress or addr, mbi.RegionSize, mbi.State, mbi.Protect)


PAGE_NOACCESS = 0x01
PAGE_READONLY = 0x02
MEM_COMMIT = 0x1000
mbi = MBI()

t_start = time.time()
stream = open(STREAM, "ab", buffering=1024 * 1024)
stats = {"stored": 0, "bytes": 0, "catches": 0, "flips": 0, "probes": 0, "fails": 0}
seen = {}


def note(a, data):
    if not data:
        return
    dig = hashlib.sha1(data).digest()
    s = seen.get(a)
    if s is None:
        s = seen[a] = set()
    if dig in s or len(s) >= 200:
        return
    s.add(dig)
    stream.write(struct.pack("<QII", a, len(data),
                             int((time.time() - t_start) * 1000) & 0xFFFFFFFF))
    stream.write(data)
    stats["stored"] += 1
    stats["bytes"] += len(data)


# ------------------------------------------------ window tracking
file_pos = 0
windows = {}       # page_base -> True


def harvest_log():
    global file_pos
    if not os.path.exists(CALLS_LOG):
        return
    with open(CALLS_LOG, "r", encoding="utf-8", errors="replace") as f:
        f.seek(file_pos)
        data = f.read()
        file_pos = f.tell()
    n = 0
    for line in data.splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[1] in ("call", "seen"):
            try:
                cid = int(parts[2])
                ptr = int(parts[3])
            except ValueError:
                continue
            if not ptr:
                continue
            key = ptr & ~0xFFF
            if key not in windows:
                windows[key] = True
                n += 1
    if n:
        print("[%6.1fs] +%d windows (tot %d)" % (
            time.time() - t_start, n, len(windows)), flush=True)


PAGES_BACK = 2      # page sweep around a catch: center page +-2 pages
PAGES_FWD = 3

alive = ctypes.c_ulong()
last_report = time.time()
harvest_log()

while True:
    # exit when target gone
    k32.GetExitCodeProcess(h, ctypes.byref(alive))
    if alive.value != 259:
        break

    harvest_log()

    caught = []
    for base in list(windows.keys()):
        stats["probes"] += 1
        d = rpm(base, 16)
        if d is None:
            stats["fails"] += 1
            caught.append(base)

    if caught:
        stats["catches"] += 1
        suspend()
        time.sleep(0.002)
        for base in caught:
            lo = int(base) - PAGES_BACK * 0x1000
            hi = int(base) + PAGES_FWD * 0x1000
            pa = lo
            while pa < hi:
                r = query(pa)
                if r is None:
                    pa += 0x1000
                    continue
                qbase, qsize, qstate, qprot = r
                page = (pa & ~0xFFF)
                if qstate == MEM_COMMIT:
                    if qprot & PAGE_NOACCESS:
                        old = ctypes.c_ulong()
                        ok = k32.VirtualProtectEx(
                            h, ctypes.c_void_p(page), ctypes.c_size_t(0x1000),
                            PAGE_READONLY, ctypes.byref(old))
                        if ok:
                            stats["flips"] += 1
                            d = rpm(page, 0x1000)
                            if d is not None:
                                note(page, d)
                            # restore original protection
                            _old = ctypes.c_ulong()
                            k32.VirtualProtectEx(
                                h, ctypes.c_void_p(page), ctypes.c_size_t(0x1000),
                                old.value, ctypes.byref(_old))
                        else:
                            stats["flips"] -= 0
                    else:
                        d = rpm(page, 0x1000)
                        if d is not None:
                            note(page, d)
                pa = page + 0x1000
        resume()

    if time.time() - last_report >= 5.0:
        print("[%6.1fs] win=%d catches=%d flips=%d stored=%d (%.1f MB) probes=%d fails=%d" % (
            time.time() - t_start, len(windows), stats["catches"], stats["flips"],
            stats["stored"], stats["bytes"] / 1e6, stats["probes"], stats["fails"]), flush=True)
        stream.flush()
        last_report = time.time()

stream.flush()
print("[done] catches=%d flips=%d stored=%d (%.1f MB)" % (
    stats["catches"], stats["flips"], stats["stored"], stats["bytes"] / 1e6))
