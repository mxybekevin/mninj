# ship45.py - insert verified wave sources into Nighty.py and
# Nighty_base.py as proper sections; update the pending ledger.
import os
import py_compile
import re
import shutil

REPO = (r'D:\SSD-Offload\brian\Downloads\Nighty'
        r'\NightyRecovered')
WAVE = r'C:\Users\brian\Downloads\Nighty\oracle\out\wave45'
FILES = [os.path.join(REPO, 'Nighty.py'),
         os.path.join(REPO, 'Nighty_base.py')]

HDR = ('#' * 76 + '\n# %s   (original line %d)\n'
       + '#' * 76 + '\n')


def load_units():
    units = []
    for f in sorted(os.listdir(WAVE)):
        m = re.match(r'src_L(\d+)\.py$', f)
        if not m:
            continue
        ln = int(m.group(1))
        src = open(os.path.join(WAVE, f),
                   encoding='ascii',
                   errors='replace').read().strip()
        m2 = re.search(r'#\s*unit\s+L\d+\s+(\S+)', src)
        name = m2.group(1) if m2 else 'unknown'
        conf = 'high'
        for tag in ('byte-verified', 'confidence=high'):
            if tag in src:
                conf = 'high'
                break
        if 'confidence=medium' in src:
            conf = 'medium'
        if ('confidence=low' in src
                or 'semantic-family' in src):
            conf = 'low'
        units.append((ln, name, conf, src))
    units.sort()
    return units


def ship(path, units):
    txt = open(path, encoding='utf-8').read()
    lines = txt.split('\n')
    # existing section headers by line number (initial scan)
    hdr_re = re.compile(r'^# (\S.*\S)?\s+\(original line (\d+)\)$')
    shipped = 0
    skipped = []
    for ln, name, conf, src in units:
        # fresh scan each iteration (indexes shift on insert)
        hdr_at = {}
        for i, ln_ in enumerate(lines):
            m = hdr_re.match(ln_)
            if m:
                n = int(m.group(2))
                hdr_at.setdefault(n, i)
        src_lines = src.split('\n')
        body = [x for x in src_lines
                if not x.startswith('# unit ')]
        block = (HDR % (name, ln)).split('\n')
        if conf != 'high':
            block.append('# [confidence=%s - see wave45 '
                         'evidence]' % conf)
        block += body
        block.append('')
        if ln in hdr_at:
            # replace existing section body up to next header
            i0 = hdr_at[ln]
            j = i0 + 1
            while j < len(lines):
                if lines[j].startswith('#' * 60) or \
                        (hdr_re.match(lines[j])):
                    break
                j += 1
            lines[i0 + 1:j] = block
            shipped += 1
        else:
            # insert after nearest lower section end
            lower = [n for n in hdr_at if n < ln]
            if lower:
                i0 = hdr_at[max(lower)]
                j = i0 + 1
                while j < len(lines):
                    if lines[j].startswith('#' * 60):
                        j += 1
                        break
                    j += 1
                lines[j:j] = block
                shipped += 1
            else:
                skipped.append((ln, name))
    txt = '\n'.join(lines)
    # update ledger rows: remove shipped lines
    out = []
    removed = 0
    for ln_ in txt.split('\n'):
        m = re.match(
            r'^#   - (\S.*\S?) \(line (\d+), \d+ bytes\) '
            r'\[.*$', ln_)
        if m and int(m.group(2)) in [u[0] for u in units]:
            removed += 1
            continue
        out.append(ln_)
    txt = '\n'.join(out)
    txt = txt.replace(
        '# PENDING UNITS (11 still-armed, 71 no-body; 10 '
        'armed-scratch impostor ships retracted 2026-10-17):',
        '# PENDING UNITS (fence45 wave shipped %d units; '
        'remaining below):' % shipped)
    open(path, 'w', encoding='utf-8',
         newline='\n').write(txt)
    print('%s: shipped %d, skipped %s, ledger rows removed %d'
          % (os.path.basename(path), shipped,
             [s[1] for s in skipped], removed))
    return shipped, removed


units = load_units()
print('units to ship: %d' % len(units))
for p in FILES:
    ship(p, units)
for p in FILES:
    py_compile.compile(p, doraise=True)
    print('COMPILE OK:', p)
