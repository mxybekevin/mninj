# rebuild46d.py - anchor-range class assembly. A class anchor =
# a bank-mapped __init__/method line; the class owns all units
# until the next anchor. Empty classes get pass.
import glob
import marshal
import os
import re
import types as _t

REPO = (r'D:\SSD-Offload\brian\Downloads\Nighty'
        r'\NightyRecovered')
NY = os.path.join(REPO, 'Nighty.py')
ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out', 'rebuild46')

txt = open(NY, encoding='utf-8').read()
lines = txt.split('\n')
hdr_re = re.compile(
    r'^# (.+?)\s+\(original line (\d+)\)$')
hdr_idx = [i for i, l in enumerate(lines)
           if hdr_re.match(l)]
secs = []
for j, i in enumerate(hdr_idx):
    m = hdr_re.match(lines[i])
    b0 = i + 1
    if b0 < len(lines) and lines[b0].strip() and \
            set(lines[b0].strip()) <= {'#'}:
        b0 += 1
    if j + 1 < len(hdr_idx):
        b1 = hdr_idx[j + 1]
        while b1 > b0 and (lines[b1 - 1].strip() == '' or
                           (lines[b1 - 1].strip() and
                            set(lines[b1 - 1].strip()) <= {'#'})):
            b1 -= 1
    else:
        b1 = len(lines)
    secs.append({'name': m.group(1),
                 'line': int(m.group(2)),
                 'body': '\n'.join(lines[b0:b1]).strip('\n')})
keep = {}
for s in secs:
    keep[(s['line'], s['name'])] = s
uniq = sorted(keep.values(), key=lambda s: s['line'])

clsmap = {}
for p in glob.glob(os.path.join(ORACLE, 'out', 'decrypted',
                                'dec_*.marshal')):
    base = os.path.basename(p)[4:]
    m = re.match(r'(.+?)\.(\S+?)_\d+\.marshal$', base)
    if not m:
        continue
    cls, meth = m.group(1), m.group(2)
    try:
        tr = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    st = [tr] if isinstance(tr, _t.CodeType) else []
    while st:
        c = st.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                st.append(k)
        if c.co_name == meth:
            clsmap.setdefault(c.co_firstlineno, cls)

# class anchors = earliest mapped line per class
anchor = {}
for ln, cls in sorted(clsmap.items()):
    if cls not in anchor:
        anchor[cls] = ln
anchors = sorted(
    ((ln, cls) for cls, ln in anchor.items()))
print('class anchors: %d' % len(anchors))
for ln, cls in anchors[:20]:
    print('   %-30s %d' % (cls, ln))

# assign each unit to the last anchor at-or-before its line
ai = 0
for s in uniq:
    while ai + 1 < len(anchors) and \
            anchors[ai + 1][0] <= s['line']:
        ai += 1
    if anchors and anchors[ai][0] <= s['line']:
        s['cls'] = anchors[ai][1]
    else:
        s['cls'] = None

# drop covered lambdas (inside any host's line window)
byline = uniq
final = []
for s in byline:
    if '<' in s['name']:
        host = None
        for o in byline:
            if o is s or '<' in o['name']:
                continue
            if o['line'] <= s['line'] <= o['line'] + 120:
                host = o
                break
        if host is not None:
            continue
    final.append(s)
print('final units: %d (dropped %d nested)'
      % (len(final), len(uniq) - len(final)))

# emit: module header, then per-anchor class blocks
IMPORTS = '''import os
import sys
import json
import time
import queue
import logging
import threading
import subprocess
import webbrowser
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import asyncio
import discord_bot
import flask
from flask import Flask, request, jsonify
from flask_sock import Sock
import webview
from PyQt5 import QtCore, QtGui, QtWidgets
'''

out = ['"""Nighty - recovered application source.\n'
       'Rebuilt from the fence45-46 evidence campaign.\n"""\n',
       IMPORTS]
cur_cls = None
for s in final:
    if s['cls'] != cur_cls:
        if s['cls']:
            out.append('\n\nclass %s:  # line %d'
                       % (s['cls'], s['line']))
            cur_cls = s['cls']
            body_added = False
        else:
            cur_cls = None
    if cur_cls:
        for ln_ in s['body'].split('\n'):
            out.append('    ' + ln_ if ln_.strip() else '')
    else:
        out.append('\n\n' + s['body'])

# post-pass: empty class bodies -> add pass
src = '\n'.join(out) + '\n'
src_lines = src.split('\n')
fixed = []
for i, ln_ in enumerate(src_lines):
    fixed.append(ln_)
    if re.match(r'^class \w+', ln_):
        j = i + 1
        while j < len(src_lines) and \
                not src_lines[j].strip():
            j += 1
        if j >= len(src_lines) or \
                (not src_lines[j].startswith(' ')
                 and not src_lines[j].startswith('\t')):
            fixed.append('    pass')
src = '\n'.join(fixed)
open(os.path.join(OUT, 'Nighty_source.py'), 'w',
     encoding='ascii', errors='replace',
     newline='\n').write(src)
print('written', len(src))
import py_compile
try:
    py_compile.compile(os.path.join(OUT, 'Nighty_source.py'),
                       doraise=True)
    print('COMPILES')
except Exception as e:
    print('compile fail: %s' % str(e)[:140])
