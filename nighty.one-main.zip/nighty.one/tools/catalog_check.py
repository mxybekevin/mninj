# catalog_check.py - the honest disambiguation of the 20 candidates:
#   1. ALPHABET: homogeneous 2-byte repeats in the head = stamp junk;
#   2. CATALOG:  does the candidate byte string equal some OTHER
#               unit's known co_code (misattributed foreign body)?
#   3. UNIQUENESS: does it pass hard_ok for exactly ONE target at its
#               length (the by_len ambiguity test)?
import collections
import glob
import json
import marshal
import os
import re
import types

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out')
RTP = os.path.join(OUT, 'fence29')
DEC = os.path.join(RTP, 'dec')
V5D = os.path.join(OUT, 'v5')

import opcode
VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}
NAME_OPS = {'LOAD_GLOBAL', 'STORE_GLOBAL', 'LOAD_NAME', 'STORE_NAME',
            'DELETE_NAME', 'LOAD_ATTR', 'STORE_ATTR', 'IMPORT_NAME',
            'IMPORT_FROM', 'LOAD_METHOD'}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)

# 1. the catalog of ALL known code bytes (every co in every v5 marshal)
catalog = {}          # bytes -> [(name, line), ...]
targets = []          # (name, line, co)  [the 62-unit worklist]
census = json.load(open(os.path.join(OUT, 'pending_census.json')))
target_keys = {(e['name'], e['line']) for k in census
               for e in census[k]}
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        top = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(top, types.CodeType):
        continue
    stack = [(top, 0)]
    while stack:
        c, d = stack.pop()
        if d > 22:
            continue
        catalog.setdefault(bytes(c.co_code), []).append(
            (str(c.co_name), c.co_firstlineno))
        if (str(c.co_name), c.co_firstlineno) in target_keys:
            targets.append((str(c.co_name), c.co_firstlineno, c))
        for k in c.co_consts:
            if isinstance(k, types.CodeType):
                stack.append((k, d + 1))
print('catalog entries: %d distinct byte strings' % len(catalog))
by_len = collections.defaultdict(list)
for nm, fl, co in targets:
    by_len[len(co.co_code)].append((nm, fl, co))


def lnotab_offsets(lnotab):
    offs = {0}
    start = 0
    for i in range(0, len(lnotab or b''), 2):
        start += lnotab[i]
        offs.add(start)
    return offs


def hard_ok(win, co, L):
    offs = lnotab_offsets(co.co_lnotab)
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nd = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    for i in range(0, L, 2):
        op = win[i]
        if op not in VALID:
            return False
        arg = win[i + 1] if i + 1 < L else 0
        nm = opcode.opname[op]
        if op < opcode.HAVE_ARGUMENT and arg != 0:
            return False
        if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == 'LOAD_CONST' and arg >= nconst:
            return False
        if nm in ('LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                  'LOAD_CLOSURE') and arg >= nd:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


def alphabetish(run):
    # homogeneous 2-byte repeat alphabet in the first 32 bytes
    head = run[:32]
    pairs = [head[i:i + 2] for i in range(0, len(head) - 1, 2)]
    counts = collections.Counter(pairs)
    if not counts:
        return False
    top, n = counts.most_common(1)[0]
    return n >= 4


rows = []
for p in sorted(os.listdir(DEC)):
    if not p.endswith('.marshal'):
        continue
    m = re.match(r'dec_(.+)_L(\d+)\.marshal', p)
    nm, line = m.group(1), int(m.group(2))
    co = marshal.load(open(os.path.join(DEC, p), 'rb'))
    run = bytes(co.co_code)
    L = len(run)
    # alphabet check
    if alphabetish(run):
        verdict = 'STAMP-ALPHABET'
    else:
        # catalog: some other unit's real bytes?
        owners = catalog.get(run, [])
        foreign = [(n2, l2) for n2, l2 in owners
                   if not (n2.replace('.', '_') == nm
                           and l2 == line)]
        self_own = any(n2.replace('.', '_') == nm and l2 == line
                       for n2, l2 in owners)
        # uniqueness
        passing = [t for t in by_len.get(L, ())
                   if hard_ok(run, t[2], L)]
        uniq = len(passing) == 1 and \
            passing[0][0].replace('.', '_') == nm and \
            passing[0][1] == line
        if self_own:
            verdict = 'SELF-CONFIRMED'
        elif foreign:
            verdict = 'FOREIGN-BODY (%s L%d)' % (
                foreign[0][0], foreign[0][1])
        elif len(passing) == 1 and not uniq:
            verdict = 'UNIQUE-BUT-OTHER (L%d %s)' % (
                passing[0][1], passing[0][0])
        elif uniq:
            verdict = 'CANDIDATE-UNIQUE'
        else:
            verdict = 'AMBIGUOUS (%d targets pass)' % len(passing)
    rows.append({'name': nm, 'line': line, 'verdict': verdict,
                 'head': run[:8].hex()})
    print('%-14s %-30s L%-6d %s'
          % (verdict.split(' ')[0], nm[:30], line, verdict))

survivors = [r for r in rows
             if r['verdict'] == 'CANDIDATE-UNIQUE']
print()
print('TRUE candidates surviving all three filters: %d'
      % len(survivors))
for r in survivors:
    print('   L%-7d %-30s head=%s'
          % (r['line'], r['name'][:30], r['head']))
json.dump(rows,
          open(os.path.join(RTP, 'catalog_check.json'), 'w'),
          indent=1)
print('CATALOG CHECK DONE')
