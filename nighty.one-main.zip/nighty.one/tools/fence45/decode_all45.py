# decode_all45.py - THE OFFLINE FULL-ARMOR DECODER (validated).
# Wordloop6 model:
#   K6 = [t0^d2.0, (t1-0xb35)^d2.1, (t2+0xd6ae)^da.0,
#         (t3+0xe9c3)^da.1, e2.0, e2.1]
#   D(S)[i] = (S[i] ^ K6[i%6]) + 0xdd15
# CTR model (build-state stub envelopes):
#   key = [t0^q1ce.0, (t1-0xf275)^q1ce.1, (t2+0xb0b0)^q1d6.0,
#          (t3+0xcd59)^q1d6.1], IV = tail16, AES-128-CTR both-endian
# Applies to: all v5 at-rest armed stamps + fence44 runtime
# envelopes. Output: out\streams45\<unit>.stream
import glob
import json
import marshal
import os
import struct
import types as _t
import opcode as _op

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out', 'streams45')
os.makedirs(OUT, exist_ok=True)

kb = open(os.path.join(ORACLE, 'out', 'fence45',
                      'bss_dump.json'))
DUMP = json.load(open(os.path.join(ORACLE, 'out', 'fence45',
                                   'bss_dump.json')))
kbb = bytes.fromhex(DUMP['keys_block'])
BASE = 0x10a0c0
IB = 0x6d600000
M32 = 0xffffffff


def u32(x):
    return x & M32


def w(va, i):
    return struct.unpack_from('<I', kbb,
                              va - IB - BASE + 4 * i)[0]


D2 = [w(0x6d70a1d2, 0), w(0x6d70a1d2, 1)]
DA = [w(0x6d70a1da, 0), w(0x6d70a1da, 1)]
E2 = [w(0x6d70a1e2, 0), w(0x6d70a1e2, 1)]
Q1CE = [w(0x6d70a1ce, 0), w(0x6d70a1ce, 1)]
Q1D6 = [w(0x6d70a1d6, 0), w(0x6d70a1d6, 1)]
print('cluster d2/da/e2:', [hex(x) for x in D2 + DA + E2])

src = open(os.path.join(ORACLE, 'decryptor46.py')).read()
cut = src.index('# ---------- the cheap decoders ----------')
ns = {}
exec(src[:cut], ns)
aes128_ctr = ns['aes128_ctr']


def key6(t):
    return [u32(t[0] ^ D2[0]),
            u32(u32(t[1] - 0xb35) ^ D2[1]),
            u32(u32(t[2] + 0xd6ae) ^ DA[0]),
            u32(u32(t[3] + 0xe9c3) ^ DA[1]),
            E2[0], E2[1]]


def wl_dec6(S, tail16):
    t = struct.unpack('<4I', tail16)
    K = key6(t)
    out = bytearray(S)
    for i in range(len(out) // 4):
        v = struct.unpack_from('<I', out, i * 4)[0]
        v = u32((v ^ K[i % 6]) + 0xdd15)
        struct.pack_into('<I', out, i * 4, v)
    return bytes(out)


def ctr_key(t):
    return [u32(t[0] ^ Q1CE[0]),
            u32(u32(t[1] - 0xf275) ^ Q1CE[1]),
            u32(u32(t[2] + 0xb0b0) ^ Q1D6[0]),
            u32(u32(t[3] + 0xcd59) ^ Q1D6[1])]


VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}
VM_OK = VALID | {0x7a, 0x87, 0xbc, 0xc6, 0x14, 0x4c, 0x5d,
                 0xf1, 0xf8, 0x41, 0x45, 0x100}


def stream_score(dec):
    n = ok = 0
    for i in range(0, min(len(dec) - 1, 400), 2):
        n += 1
        if dec[i] in VM_OK:
            ok += 1
    if n == 0:
        return 0
    r = (ok * 100 // n)
    # format: real + vm mix, ends with return-ish
    return r


census = []
for p in glob.glob(os.path.join(ORACLE, 'out', 'v5',
                                'v5_*.marshal')):
    try:
        t = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(t, _t.CodeType):
        continue
    st = [t]
    while st:
        c = st.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                st.append(k)
        if c.co_name != '<module>':
            census.append(c)

armed = {}
for c in census:
    f = c.co_flags
    if (f & 0x20000000) and (f & 0x60000000):
        armed[(c.co_firstlineno, c.co_name)] = c

print('armed units:', len(armed))
solved = {}
for (ln, name), c in sorted(armed.items()):
    code = c.co_code
    f = c.co_flags
    tail = code[-16:]
    best = None
    n = len(code)
    if n >= 32:
        span = code[16:-16]
        d = wl_dec6(span, tail)
        s = stream_score(d)
        if best is None or s > best[1]:
            best = (d, s, 'wl6')
    stub = (len(code) >= 6 and code[0] == 0x74
            and code[2:4] == b'\x83\x00')
    if stub and n >= 32:
        t = struct.unpack('<4I', tail)
        kk = struct.pack('<4I', *ctr_key(t))
        for endn in ('le', 'be'):
            d = aes128_ctr(kk, tail, code[16:-16], endn)
            s = stream_score(d)
            if best is None or s > best[1]:
                best = (d, s, 'ctr-' + endn)
    if best:
        d, s, how = best
        solved[(ln, name)] = (d, s, how)
        fn = ('S_L%d_%s_len%d_%s_%d.stream'
              % (ln, name.strip('<>').replace(':', '_')[:16],
                 len(d), how, s))
        with open(os.path.join(OUT, fn), 'wb') as fh:
            fh.write(d)
        print('L%-6d %-26s %-7s score=%3d len=%-5d'
              % (ln, name[:26], how, s, len(d)))
    else:
        print('L%-6d %-26s (no span)' % (ln, name[:26]))

print()
print('streams emitted:', len(solved))
with open(os.path.join(OUT, 'index.json'), 'w') as fh:
    json.dump({'%d:%s' % k: {'score': v[1], 'mode': v[2],
                             'len': len(v[0])}
               for k, v in solved.items()}, fh, indent=1)
print('DONE ->', OUT)
