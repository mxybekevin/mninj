// hook45b.js - THE PLAINTEXT SCOOP. For every armed call:
//   engine onEnter: push (cipherPtr, len) on a context stack,
//                   record the envelope head+tail once per unit.
//   exec (0x7b650) onLeave: pop the context and DUMP the span -
//                   it is still PLAINTEXT here (the engine re-arms
//                   only after the body finishes).
// Keeps ctr_start (id/IV/KEY cross-check) and the ctr_decrypt
// scoop. Dedupes by pragma of envelope head+cipher-len.
var OUT = 'C:\\Users\\brian\\Downloads\\Nighty\\oracle\\out\\fence45\\trap\\';
var CTR = [];
var SEEN = {};
var NPT = 0, NUNIQ = 0;
var NKS = 0;

function hx(a, k) {
    try {
        var b = new Uint8Array(a.readByteArray(k));
        var s = '';
        for (var j = 0; j < b.length; j++) {
            var t = b[j].toString(16);
            if (t.length < 2) t = '0' + t;
            s += t;
        }
        return s;
    } catch (e) { return null; }
}
function sp(p) {
    try { return p.readPointer(); } catch (e) { return ptr(0); }
}
function wf(name, txt) {
    try { var f = new File(OUT + name, 'w'); f.write(txt); f.close(); }
    catch (e) { send({t: 'wferr', n: '' + name, e: '' + e}); }
}

var PTF = null;
var mods = Process.enumerateModules();
for (var i = 0; i < mods.length; i++) {
    if (mods[i].name.toLowerCase() === 'pytransform.pyd') {
        PTF = mods[i]; break;
    }
}
if (PTF === null) { send({t: 'nomod'}); }
else {
    var B = PTF.base;

    Interceptor.attach(B.add(0x4850), {
        onEnter: function (a) {
            var ctx = { pt: a[2], len: a[3].toInt32(),
                        frame: a[0], code: a[1] };
            CTR.push(ctx);
            if (NUNIQ < 800) {
                try {
                    var env = 0;
                    var co = a[1];
                    var bc = sp(co.add(0x30));
                    var n = Number(bc.add(16).readU64());
                    if (n > 0 && n < 65536) {
                        var key = n + '_' + hx(bc.add(32), 12);
                        if (!SEEN[key]) {
                            SEEN[key] = 1;
                            var fl = Number(co.add(0x24).readU32());
                            wf('env_' + NUNIQ + '_n' + n +
                               '_f' + fl + '.bin',
                               'LEN=' + n + ' FLAGS=' + fl + '\n' +
                               (hx(bc.add(32), n) || ''));
                            NUNIQ++;
                        }
                    }
                } catch (e) {}
            }
        }
    });

    Interceptor.attach(B.add(0x7b650), {
        onLeave: function (r) {
            var ctx = CTR.pop();
            if (!ctx) return;
            if (NPT >= 800) return;
            var L = ctx.len;
            if (L < 8 || L > 65536 || L % 2) return;
            var body = hx(ctx.pt, L);
            if (!body) return;
            wf('plain_' + NPT + '_len' + L + '.hex', body);
            NPT++;
        }
    });

    Interceptor.attach(B.add(0x168a0), {
        onEnter: function (a) {
            if (NKS >= 300) return;
            try {
                wf('ks_' + NKS + '.json', JSON.stringify({
                    t: 'ctr_start', n: NKS,
                    id: a[0].toInt32(),
                    iv: hx(a[1], 16),
                    key: hx(a[2], 16),
                    keylen: a[3].toInt32()}));
                NKS++;
            } catch (e) {}
        }
    });

    send({t: 'ready2', base: '' + B});
}
