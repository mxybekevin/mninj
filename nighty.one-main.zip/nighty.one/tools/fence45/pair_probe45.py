# pair_probe45.py - solve the cheap-cipher model from clean same-
# session (envelope, plain) pairs. Full K-sequence structure probes.
import glob
import json
import marshal
import os
import re
import struct
import types as _t

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
TRAP = os.path.join(ORACLE, 'out', 'fence45', 'trap')

envs = {}
for p in glob.glob(os.path.join(TRAP, 'env_*.bin')):
    txt = open(p).read()
    m = re.match(r'LEN=(\d+) FLAGS=(\d+)\n(.*)', txt, re.S)
    if not m:
        continue
    envs[(int(m.group(2)), int(m.group(1)))
         ] = bytes.fromhex(m.group(3).strip())

plains = {}
for p in glob.glob(os.path.join(TRAP, 'plain_*.hex')):
    b = bytes.fromhex(open(p).read().strip())
    plains.setdefault(len(b), set()).add(b)

M32 = 0xffffffff


def u32(x):
    return x & M32


def ks_seq(S, P, model, c=0xdd15):
    out = []
    for i in range(len(S) // 4):
        sw = struct.unpack_from('<I', S, i * 4)[0]
        pw = struct.unpack_from('<I', P, i * 4)[0]
        if model == 'sub_xor':      # S=(P-c)^K -> K=S^((P-c))
            k = sw ^ u32(pw - c)
        elif model == 'addc_xor':   # S=(P+c)^K
            k = sw ^ u32(pw + c)
        elif model == 'xor_addc':    # S=(P^K)+c
            k = None
        elif model == 'xor_only':
            k = sw ^ pw
        out.append(k if k is None else k)
    return out


def periodic(K, mod=4):
    if len(K) < 8:
        return None
    base = K[:mod]
    good = sum(1 for i in range(len(K)) if K[i] == base[i % mod])
    return (good * 100) // len(K)


for (fl, n), env in sorted(envs.items(), key=lambda kv: kv[0][1]):
    tail = env[-16:]
    for L in (n - 32, n - 16):
        if L in plains:
            for P in plains[L]:
                S = env[16:16 + L]
                if len(S) < L:
                    S = env[16:]
                best = None
                for model in ('sub_xor', 'addc_xor', 'xor_only'):
                    K = ks_seq(S, P, model)
                    if any(k is None for k in K):
                        continue
                    pct = periodic(K)
                    if pct is not None and (best is None
                                            or pct > best[0]):
                        best = (pct, model, K[:8],
                                '%.2f' % (sum(1 for k in K
                                              if k is not None)
                                          / len(K)))
                if best and best[0] >= 50:
                    print('n=%d f=%x L=%d  %-9s periodic4=%d%% '
                          'K8=%s' % (n, fl, L, best[1], best[0],
                                     [hex(x) for x in best[2]]))
                elif best:
                    print('n=%d f=%x L=%d  %-9s periodic4=%d%%'
                          % (n, fl, L, best[1], best[0]))

# dedicated deep-dive on the clean singleton: slide_up 166
env = None
for (fl, n), e in envs.items():
    if n == 166:
        env = e
        break
if env:
    P = None
    for cand in plains.get(134, ()) | plains.get(150, ()):
        P = cand
        break
    if P and len(P) == 134:
        S = env[16:150]
        print()
        print('=== slide_up deep dive (len 166 env, 134 span) ===')
        for model in ('sub_xor', 'addc_xor', 'xor_only'):
            K = ks_seq(S, P, model)
            p4 = periodic(K)
            print('%-9s periodic4=%s  Kfull=%s'
                  % (model, p4,
                     [hex(x) for x in K[:16]]))
        # raw first-16-bytes comparison
        print('S head:', S[:16].hex())
        print('P head:', P[:16].hex())
        print('X  head:', bytes(a ^ b for a, b in
                               zip(S[:16], P[:16])).hex())
        print('tail:', tail.hex())
