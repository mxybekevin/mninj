# decryptor46.py - THE OFFLINE ARMOR BREAKER.
# All secrets captured (fence45 bss dump): AES id confirmed, key
# globals in hand. Decodes every armed at-rest envelope in the v5
# stamps + fence44 captures using the engine's exact formulas:
#   CTR build state:   span=[16:-16), IV=tail16, key=4 words derived
#                     from tail16 * q@1ce/q@1d6, AES-128-CTR (both
#                     counter endians tested)
#   WORDLOOP steady:  span=[16:-16), w'=(w ^ K[i%4]) + 0xdd15
#                     K derived from tail16 * q@1d2/q@1da
#   XOR24 steady:     key = 24 B @q1d2 mangled by (0x17-i)^2+3
# Oracle: strict py38 opcode walk vs the unit's TRUE stamp tables.
import dis
import glob
import io
import json
import marshal
import os
import struct
import types as _t
from collections import defaultdict

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUTD = os.path.join(ORACLE, 'out', 'decrypt46')
os.makedirs(OUTD, exist_ok=True)

# ---------- captured constants (fence45 bss_dump) ----------
DUMP = json.load(open(os.path.join(ORACLE, 'out', 'fence45',
                                   'bss_dump.json')))
kb = bytes.fromhex(DUMP['keys_block'])
OFF = 0x10a0c0           # start of keys_block
IB = 0x6d600000


def qword(va):
    o = va - IB - OFF
    return struct.unpack_from('<Q', kb, o)[0]


def dwords(va, n):
    o = va - IB - OFF
    return struct.unpack_from('<%dI' % n, kb, o)


Q1CE = qword(0x6d70a1ce)
Q1D6 = qword(0x6d70a1d6)
Q1D2 = qword(0x6d70a1d2)
Q1DA = qword(0x6d70a1da)
assert Q1CE == 0xf40f5a3d2e6ac913, hex(Q1CE)
assert Q1D6 == 0x75054208bc248f81, hex(Q1D6)
XOR24_KEY = kb[0x6d70a1d2 - IB - OFF:0x6d70a1ea - IB - OFF]
assert len(XOR24_KEY) == 0x18

M32 = 0xffffffff


def u32(x):
    return x & M32


def ctr_key(tail16):
    w = struct.unpack('<4I', tail16)
    k0 = u32(w[0] ^ (Q1CE & M32))
    k1 = u32((u32(w[1] - 0xf275)) ^ (Q1CE >> 32))
    k2 = u32((u32(w[2] + 0xb0b0)) ^ (Q1D6 & M32))
    k3 = u32((u32(w[3] + 0xcd59)) ^ (Q1D6 >> 32))
    return struct.pack('<4I', k0, k1, k2, k3)


def wordloop_key(tail16):
    w = struct.unpack('<4I', tail16)
    k0 = u32(w[0] ^ (Q1D2 & M32))
    k1 = u32((u32(w[1] - 0xb35)) ^ (Q1D2 >> 32))
    k2 = u32((u32(w[2] + 0xd6ae)) ^ (Q1DA & M32))
    k3 = u32((u32(w[3] + 0xe9c3)) ^ (Q1DA >> 32))
    return struct.pack('<4I', k0, k1, k2, k3)


# ---------- pure-python AES-128 ----------
def _gmul(a, b):
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xff
        if hi:
            a ^= 0x1b
        b >>= 1
    return p


def _rotl8(x, s):
    return ((x << s) | (x >> (8 - s))) & 0xff


def _affine(x):
    r = x
    for s in (1, 2, 3, 4):
        r ^= _rotl8(x, s)
    return (r ^ 0x63) & 0xff


_SBOX = bytes(_affine(_inv) for _inv in
             [next((x for x in range(1, 256)
                    if _gmul(x, a) == 1), 0) for a in range(256)])


def _expand(key):
    w = [struct.unpack('>I', key[4 * i:4 * i + 4])[0]
         for i in range(4)]
    rcon = 1
    for i in range(4, 44):
        t = w[i - 1]
        if i % 4 == 0:
            bs = [(t >> 24) & 0xff, (t >> 16) & 0xff,
                  (t >> 8) & 0xff, t & 0xff]
            bs = [_SBOX[x] for x in (bs[1], bs[2], bs[3], bs[0])]
            t = (bs[0] << 24) | (bs[1] << 16) | (bs[2] << 8) | bs[3]
            t ^= rcon << 24
            rcon = _gmul(rcon, 2)
        w.append(w[i - 4] ^ t)
    return w


def _enc_block(rk, block):
    s = struct.unpack('<16B', block)
    s = [s[i] ^ ((rk[i // 4] >> (24 - 8 * (i % 4)))
                 & 0xff) for i in range(16)]

    def state_bytes(s):
        # s[r][c]
        return [[s[r + 4 * c] for c in range(4)] for r in range(4)]
    st = state_bytes(s)

    def flat(st):
        out = []
        for c in range(4):
            for r in range(4):
                out.append(st[r][c])
        return out

    def addrk(st, rnd):
        return [[st[r][c] ^ ((rk[rnd * 4 + c] >> (24 - 8 * r))
                             & 0xff) for c in range(4)]
                for r in range(4)]
    st = addrk(st, 0)
    for rnd in range(1, 10):
        st = [[_Sbox_apply(st[r][c]) for c in range(4)]
              for r in range(4)] if False else \
             [[_SBOX[st[r][c]] for c in range(4)] for r in range(4)]
        st = [[st[r][(c + r) % 4] for c in range(4)]
              for r in range(4)]  # shift rows
        col = [[st[r][c] for r in range(4)] for c in range(4)]
        new = []
        for c in range(4):

            def xt(a):
                a <<= 1
                return (a ^ 0x1b) & 0xff if a & 0x100 else a
            v = col[c]
            n0 = xt(v[0]) ^ (xt(v[1]) ^ v[1]) ^ v[2] ^ v[3]
            n1 = v[0] ^ xt(v[1]) ^ (xt(v[2]) ^ v[2]) ^ v[3]
            n2 = v[0] ^ v[1] ^ xt(v[2]) ^ (xt(v[3]) ^ v[3])
            n3 = (xt(v[0]) ^ v[0]) ^ v[1] ^ v[2] ^ xt(v[3])
            new.append([n0 & 0xff, n1 & 0xff, n2 & 0xff, n3 & 0xff])
        st = [[new[c][r] for c in range(4)] for r in range(4)]
        st = addrk(st, rnd)
    st = [[_SBOX[st[r][c]] for c in range(4)] for r in range(4)]
    st = [[st[r][(c + r) % 4] for c in range(4)] for r in range(4)]
    st = addrk(st, 10)
    return bytes(flat(st))


def _Sbox_apply(b):
    return _SBOX[b]


def aes128_ecb(key, block):
    rk = _expand(key)
    return _enc_block(rk, block)


def aes128_ctr(key, iv, data, endian='le'):
    ks = b''
    ctr = bytearray(iv)
    n = len(data)
    while len(ks) < n:
        ks += aes128_ecb(key, bytes(ctr))
        if endian == 'le':
            i = 0
            while True:
                if ctr[i] == 0xff:
                    ctr[i] = 0
                    i += 1
                else:
                    ctr[i] += 1
                    break
        else:
            i = 15
            while True:
                if ctr[i] == 0xff:
                    ctr[i] = 0
                    i -= 1
                else:
                    ctr[i] += 1
                    break
    return bytes(a ^ b for a, b in zip(data, ks))


# ---------- CNG native AES-128-ECB via bcrypt.dll (authoritative) ----------
import ctypes as _ct
from ctypes import c_void_p as _vp, c_ulong as _ul
_bc = _ct.win() if False else _ct.windll.bcrypt
_hAlg = _vp()
assert _bc.BCryptOpenAlgorithmProvider(_ct.byref(_hAlg), 'AES',
                                       None, 0) == 0
MODE_ECB_BYTES = _ct.create_unicode_buffer('ChainingModeECB')
assert _bc.BCryptSetProperty(
    _hAlg, 'ChainingMode', MODE_ECB_BYTES,
    _ct.sizeof(MODE_ECB_BYTES), 0) == 0
_olen = _ul(0)
_bc.BCryptGetProperty(_hAlg, 'ObjectLength', _ct.byref(_olen),
                      _ct.sizeof(_olen), _ct.byref(_ul(0)), 0)
_KOBJ = int(_olen.value)
_KEY_CACHE = {}


def _cng_key(key):
    kb = _KEY_CACHE.get(key)
    if kb is None:
        hKey = _vp()
        kobj = _ct.create_string_buffer(_KOBJ)
        st = _bc.BCryptGenerateSymmetricKey(
            _hAlg, _ct.byref(hKey), kobj, _KOBJ, key, len(key), 0)
        assert st == 0, st
        kb = (hKey, kobj)
        _KEY_CACHE[key] = kb
    return kb


def aes128_ecb(key, block):
    hKey, _ = _cng_key(key)
    out = _ct.create_string_buffer(16)
    done = _ul(0)
    st = _bc.BCryptEncrypt(hKey, block, len(block), None, None, 0,
                           out, 16, _ct.byref(done), 0)
    assert st == 0, st
    return out.raw[:16]


_cng_test = aes128_ecb(
    bytes.fromhex('2b7e151628aed2a6abf7158809cf4f3c'),
    bytes.fromhex('6bc1bee22e409f96e93d7e117393172a'))
assert _cng_test.hex() == '3ad77bb40d7a3660a89ecaf32466ef97', \
    _cng_test.hex()
print('CNG AES self-test OK')

# AES self-test (FIPS-197 C.1 + C.3 canonical vectors)
_vt = aes128_ecb(bytes.fromhex('2b7e151628aed2a6abf7158809cf4f3c'),
                 bytes.fromhex('3243f6a8885a308d313198a2e0370734'))
assert _vt.hex() == '3925841d02dc09fbdc118597196a0b32', _vt.hex()
_vt2 = aes128_ecb(bytes(range(16)),
                  bytes.fromhex('00112233445566778899aabbccddeeff'))
assert _vt2.hex() == '69c4e0d86a7b0430d8cdb78070b4c55a', _vt2.hex()
print('AES self-test OK')

# ---------- the cheap decoders ----------
def wordloop_dec(span, tail16):
    K = struct.unpack('<4I', wordloop_key(tail16))
    out = bytearray(span)
    nd = len(out) // 4           # engine: len >> 2 dwords, rest kept
    for i in range(nd):
        w = struct.unpack_from('<I', out, i * 4)[0]
        w = u32((w ^ K[i % 4]) + 0xdd15)
        struct.pack_into('<I', out, i * 4, w)
    return bytes(out)


def xor24_dec(buf):
    k = bytearray(XOR24_KEY)
    kb2 = bytearray(k)
    for i in range(0x18):
        c = (0x17 - i)
        kb2[i] ^= (u32(c * c + 3)) & 0xff
    out = bytearray(buf)
    for i in range(len(out)):
        out[i] ^= kb2[i % 0x18]
    return bytes(out)


def xor24_dec2(buf):
    # variant: transform applied per formula c=c-0x17 negative? Keep
    # the exact Ghidra reading: cVar2=(char)iVar5 with iVar5 from
    # 0x17 down; *pk ^= cVar2*cVar2+3 -- same as above.
    return xor24_dec(buf)


# ---------- oracle ----------
import opcode as _op
VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}
JREL = set(_op.hasjrel)
JABS = set(_op.hasjabs)
NAME_OPS = {'LOAD_GLOBAL', 'LOAD_ATTR', 'LOAD_METHOD', 'STORE_ATTR',
            'IMPORT_NAME', 'IMPORT_FROM', 'LOAD_NAME', 'STORE_NAME'}
FAST_OPS = {'LOAD_FAST', 'STORE_FAST', 'DELETE_FAST'}
CONST_OPS = {'LOAD_CONST'}


def oracle(code, meta):
    L = len(code)
    if L < 8 or L % 2:
        return None
    nloc = meta['nlocals']
    nnam = meta['nnames']
    maxfast = maxname = maxconst = -1
    i = 0
    ext = 0
    calls = rets = 0
    while i < L:
        op = code[i]
        if op not in VALID:
            return None
        arg = code[i + 1]
        nm = _op.opname[op]
        if nm == 'EXTENDED_ARG':
            ext = (ext << 8) | arg
            i += 2
            if i + 1 >= L:
                return None
            continue
        earg = (ext << 8) | arg
        ext = 0
        if nm in FAST_OPS:
            maxfast = max(maxfast, earg)
        elif nm in NAME_OPS:
            maxname = max(maxname, earg)
        elif nm in CONST_OPS:
            maxconst = max(maxconst, earg)
        elif nm == 'RETURN_VALUE':
            rets += 1
        elif 'CALL' in nm:
            calls += 1
        if op in JREL:
            t = i + 2 + earg
            if not (0 <= t < L) or t % 2:
                return None
        elif op in JABS:
            if not (0 <= earg < L) or earg % 2:
                return None
        i += 2
    if code[-2] != 0x53:
        return None
    if maxfast >= nloc or maxname >= nnam:
        return None
    nconst = meta.get('nconsts')
    if nconst and maxconst >= nconst:
        return None
    if rets < 1:
        return None
    return {'maxfast': maxfast, 'maxname': maxname,
            'maxconst': maxconst, 'calls': calls,
            'ops': L // 2}


# ---------- gather targets ----------
targets = {}
for p in glob.glob(os.path.join(ORACLE, 'out', 'v5', 'v5_*.marshal')):
    try:
        t = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(t, _t.CodeType):
        continue
    st = [t]
    while st:
        c = st.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                st.append(k)
        if c.co_name == '<module>':
            continue
        key = (c.co_name, c.co_firstlineno)
        cur = targets.get(key)
        if cur is None or len(c.co_code) > len(cur.co_code):
            targets[key] = c

armed = {}
for (nm, ln), c in targets.items():
    f = c.co_flags
    head = c.co_code[:4].hex()
    is_plain = (not (f & 0x20000000))
    if is_plain:
        continue
    # skip restored plaintext units (scar only), they are known
    if (f & 0x20000000) and not (f & 0x60000000):
        continue
    armed[(nm, ln)] = c

print('armed targets: %d' % len(armed))

results = {}
for (nm, ln), c in sorted(armed.items(),
                           key=lambda kv: kv[0][1]):
    code = c.co_code
    meta = {'nlocals': len(c.co_varnames), 'nnames':
            len(c.co_names), 'nconsts': len(c.co_consts)}
    f = c.co_flags
    cands = []
    stub = (len(code) >= 6 and code[0] == 0x74
            and code[2:4] == b'\x83\x00')
    # universalcandidate list
    spans = []
    if len(code) >= 48:
        tail = code[-16:]
        spans.append(('ctr|span16|le',
                      aes128_ctr(ctr_key(tail), tail,
                                 code[16:-16], 'le'), stub))
        spans.append(('ctr|span16|be',
                      aes128_ctr(ctr_key(tail), tail,
                                 code[16:-16], 'be'), stub))
        spans.append(('wl|span16',
                      wordloop_dec(code[16:-16], tail), stub))
        spans.append(('wl|full16',
                      wordloop_dec(code[16:], code[:16]), stub))
        spans.append(('wl|span8',
                      wordloop_dec(code[8:-16], tail), stub))
        spans.append(('wl|full',
                      wordloop_dec(code[:16], code[-16:]), stub))
    spans.append(('x24|full', xor24_dec(code), stub))
    spans.append(('x24|nos', xor24_dec(code[16:]), stub))
    if len(code) >= 48:
        spans.append(('x24|span16',
                      xor24_dec(code[16:-16]), stub))
    spans.append(('raw|full', code, stub))

    best = None
    for tag, dec, was_stub in spans:
        if len(dec) < 12:
            continue
        v = oracle(dec, meta)
        if v is None:
            continue
        if best is None or v['ops'] > best[2]['ops']:
            best = (tag, dec, v)
    if best:
        tag, dec, v = best
        fn = 'D_%d_%s_%d.bin' % (ln, nm.strip('<>').replace(
            ':', '_')[:20], len(dec))
        with open(os.path.join(OUTD, fn), 'wb') as fh:
            fh.write(dec)
        with open(os.path.join(OUTD, fn.replace(
                '.bin', '.meta.json')), 'w') as fh:
            json.dump({'name': nm, 'line': ln, 'mode': tag,
                       'valid': v, 'flags': hex(f),
                       'stub': was_stub}, fh, indent=1)
        results[(nm, ln)] = (tag, v)
        print('L%-6d %-22s %-14s ops=%-4d calls=%-3d '
              'maxfast=%d/%d maxname=%d/%d%s'
              % (ln, nm[:22], tag, v['ops'], v['calls'],
                 v['maxfast'], meta['nlocals'], v['maxname'],
                 meta['nnames'],
                 ' [was-stub}' if was_stub else ''))
    else:
        print('L%-6d %-22s NO-VALID decode' % (ln, nm[:22]))

print()
print('decoded: %d / %d armed' % (len(results), len(armed)))
with open(os.path.join(OUTD, 'summary.json'), 'w') as fh:
    json.dump({'%s@%d' % k: v[0] for k, v in results.items()},
              fh, indent=1)
print('DECRYPTOR46 DONE -> %s' % OUTD)
