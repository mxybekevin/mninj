# aes_debug.py - isolate the AES bug against FIPS-197 C.1 knowns.
import struct
src = open(r'C:\Users\brian\Downloads\Nighty\oracle\decryptor46.py').read()
cut = src.index('# AES self-test')
ns = {}
exec(src[:cut], ns)
_SBOX = ns['_SBOX']
_expand = ns['_expand']
aes128_ecb = ns['aes128_ecb']

KEY = bytes.fromhex('2b7e151628aed2a6abf7158809cf4f3c')
PT = bytes.fromhex('3243f6a8885a308d313198a2e0370734')

print('sbox(00)=%02x (want 63)' % _SBOX[0])
print('sbox(53)=%02x (want ed)' % _SBOX[0x53])
print('sbox(ff)=%02x (want 16)' % _SBOX[0xff])
w = _expand(KEY)
print('w4=%08x (want a0fafe17)' % w[4])
print('w5=%08x (want fefefefe?? actually 919195f7)' % w[5])
print('w43=%08x (want 3d471de5?? d41a??)' % w[43])

ct = aes128_ecb(KEY, PT)
print('ct=%s (want 3925841d02dc09fbdc118597196a0b32)' % ct.hex())

# SP800-38A vector
ct2 = aes128_ecb(KEY, bytes.fromhex(
    '6bc1bee22e409f96e93d7e117393172a'))
print('ct2=%s (want 3ad77bb40d7a3660a89ecaf32466ef97)' % ct2.hex())
