# stream_pkg45.py - THE STREAM HARVEST PROCESSOR.
# 1. deduple scooped plains + envelopes;
# 2. pair each plain (P) with its at-rest stamp cipher (S) via
#    geometry (flags, len): solving the cheap-cipher keystream
#    K = f(S, P) and validating the engine formulas;
# 3. with validated formulas, decode EVERY at-rest armed stamp
#    offline to its VM-stream;
# 4. emit per-unit stream packages (stream + census metadata)
#    ready for source reconstruction.
import glob
import json
import marshal
import os
import struct
import types as _t
from collections import defaultdict

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
TRAP = os.path.join(ORACLE, 'out', 'fence45', 'trap')
OUT = os.path.join(ORACLE, 'out', 'stream45')
os.makedirs(OUT, exist_ok=True)

# ---------- load census ----------
census = []
for p in glob.glob(os.path.join(ORACLE, 'out', 'v5',
                                'v5_*.marshal')):
    try:
        t = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(t, _t.CodeType):
        continue
    st = [t]
    while st:
        c = st.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                st.append(k)
        if c.co_name == '<module>':
            continue
        census.append(c)

armed = [c for c in census
         if (c.co_flags & 0x20000000)
         and (c.co_flags & 0x60000000)]
by_geom = defaultdict(list)
for c in armed:
    by_geom[(c.co_flags, len(c.co_code))].append(c)
print('armed census:', len(armed))

# ---------- envelopes ----------
envs = {}
pat_meta = re = None
for p in glob.glob(os.path.join(TRAP, 'env_*.bin')):
    txt = open(p).read()
    m = __import__('re').match(r'LEN=(\d+) FLAGS=(\d+)\n(.*)',
                               txt, __import__('re').S)
    if not m:
        continue
    n = int(m.group(1))
    fl = int(m.group(2))
    body = bytes.fromhex(m.group(3).strip())
    if len(body) != n:
        print('len mismatch', p, n, len(body))
        continue
    envs[(fl, n)] = body
print('unique envelopes:', len(envs))

# ---------- plains ----------
plains = {}
for p in glob.glob(os.path.join(TRAP, 'plain_*.hex')):
    b = bytes.fromhex(open(p).read().strip())
    plains.setdefault(len(b), {})[b] = plains.setdefault(
        len(b), {}).get(b, p)
print('unique plain streams:', sum(len(v) for v in plains.values()))

# ---------- pairing ----------
M32 = 0xffffffff


def u32(x):
    return x & M32


pairs = []
for (fl, n), env in envs.items():
    for L, d in plains.items():
        # geometry: span = n - 16 - 16 (wordloop class)
        if L == n - 32 or L == n - 16:
            cands = d.keys()
            st_units = by_geom.get((fl, n), [])
            for st in st_units:
                # S = the SAME-SESSION armed envelope bytes
                S = env[16:16 + L]
                for P in cands:
                    if len(S) == len(P):
                        pairs.append((st, env, P, S))
print('pairs (unit, env, plain, cipher):', len(pairs))

# ---------- keystream attack on wordloop ----------
# E: S = (P - 0xdd15) ^ K[i%4]  =>  K[i%4] = S ^ ((P - 0xdd15))
solved = {}
for st, env, P, S in pairs:
    if len(P) != len(S) or len(P) < 4:
        continue
    tP = env[-16:]
    ks = []
    for i in range(len(P) // 4):
        pw = struct.unpack_from('<I', P, i * 4)[0]
        sw = struct.unpack_from('<I', S, i * 4)[0]
        k = sw ^ u32(pw - 0xdd15)
        ks.append(k)
    k0 = ks[0] if ks else None
    cyc = ks[:4]
    # verify the cycle: K[i%4] constant?
    okcyc = all(cyc[i % 4] == ks[i]
                for i in range(min(len(ks), 40)))
    print('unit %-24s L%-5d tail=%s Kcycle-ok=%s K=%s'
          % (st.co_name[:24], st.co_firstlineno,
             tP.hex(), okcyc,
             [hex(x) for x in cyc] if ks else None))
    if okcyc and len(cyc) == 4:
        solved[(st.co_name, st.co_firstlineno)] = (
            cyc, tP, st, P)

if solved:
    # derive the K(tail) formula empirically from solved pairs
    print()
    print('=== KEY FORMULA RECOVERY ===')
    for ukey, (cyc, tP, st, P) in list(solved.items())[:6]:
        w = struct.unpack('<4I', tP)
        print('unit %-24s L%d' % ukey)
        print('  tail words : %s' % [hex(x) for x in w])
        print('  solved K   : %s' % [hex(x) for x in cyc])
        # test my formula against the bss cluster values in all
        # available sessions
        for label, kb in (
                ('sess2', os.path.join(TRAP, 'bss_keys.bin')),
                ('sess1', os.path.join(ORACLE, 'out', 'fence45',
                                       'trap_session1',
                                       'bss_keys.bin'))):
            if not os.path.exists(kb):
                continue
            kbb = open(kb, 'rb').read()
            BASE = 0x10a0c0

            def q(va):
                return struct.unpack_from('<Q', kbb,
                                          va - BASE)[0]

            Q1D2 = q(0x10a1d2)
            Q1DA = q(0x10a1da)
            k0 = u32(w[0] ^ (Q1D2 & M32))
            k1 = u32((u32(w[1] - 0xb35)) ^ (Q1D2 >> 32))
            k2 = u32((u32(w[2] + 0xd6ae)) ^ (Q1DA & M32))
            k3 = u32((u32(w[3] + 0xe9c3)) ^ (Q1DA >> 32))
            mine = [k0, k1, k2, k3]
            print('  formula(%s): %s   %s'
                  % (label, [hex(x) for x in mine],
                     'MATCH' if mine == cyc else 'differ'))
            d0 = cyc[0] ^ w[0]
            d1 = ((cyc[1] ^ u32(w[1] - 0xb35)))
            d2 = ((cyc[2] ^ u32(w[2] + 0xd6ae)))
            d3 = ((cyc[3] ^ u32(w[3] + 0xe9c3)))
            print('  implied cluster dwords: %s'
                  % [hex(x) for x in (d0, d1, d2, d3)])
            qq = struct.unpack('<Q', kbb[0x10a1d2 - BASE:
                                          0x10a1d2 - BASE + 8])
            qa = struct.unpack('<Q', kbb[0x10a1da - BASE:
                                          0x10a1da - BASE + 8])
            print('  cluster1d2 raw: %s  =? %s| %s'
                  % (hex(qq), hex(d0), hex(d1)))
            print('  cluster1da raw: %s  =? %s| %s'
                  % (hex(qa), hex(d2), hex(d3)))

# ---------- save stream packages ----------
pkg = 0
for st, env, P, S in pairs:
    fn = ('stream_L%d_%s_len%d.json'
          % (st.co_firstlineno, st.co_name.strip('<>')
             .replace(':', '_')[:20], len(P)))
    rec = {
        'unit': st.co_name,
        'firstlineno': st.co_firstlineno,
        'argcount': st.co_argcount,
        'flags': st.co_flags,
        'varnames': list(st.co_varnames),
        'names': list(st.co_names),
        'consts_shapes': [type(k).__name__
                          for k in st.co_consts][:40],
        'nconsts': len(st.co_consts),
        'stream_hex': P.hex(),
        'envelope_head32': env[:32].hex(),
        'envelope_len': len(env),
    }
    with open(os.path.join(OUT, fn), 'w') as f:
        json.dump(rec, f, indent=1)
    pkg += 1
print('stream packages written:', pkg)
print('DONE ->', OUT)
