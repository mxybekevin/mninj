// hook45.js - THE GROUND-TRUTH TRAP.
// Traps on pytransform.pyd (RVAs from the Ghidra map, base-relative):
//   +0x4850  engine entry: dump stack args (buf+12 / tail ptrs) and
//            the live frame's envelope head/tail. Capped.
//   +0x168a0 ctr_start: capture the REAL cipher id + IV + KEY the
//            armor derives. Capped at 40.
//   +0x16270 ctr_decrypt: onLeave, scoop the DECRYPTED PLAINTEXT
//            buffer (the true bodies!). Capped at 60, size-capped.
//   one-shot bss dump (keys_block) for bare-vs-app comparison.
var OUT = 'C:\\Users\\brian\\Downloads\\Nighty\\oracle\\out\\fence45\\trap\\';
var NENG = 0, NKS = 0, NPT = 0;

function hx(a, k) {
    try {
        var b = new Uint8Array(a.readByteArray(k));
        var s = '';
        for (var j = 0; j < b.length; j++) {
            var t = b[j].toString(16);
            if (t.length < 2) t = '0' + t;
            s += t;
        }
        return s;
    } catch (e) { return null; }
}
function wf(name, txt) {
    try { var f = new File(OUT + name, 'w'); f.write(txt); f.close(); }
    catch (e) { send({t: 'wferr', e: '' + e}); }
}

var PTF = null;
var mods = Process.enumerateModules();
for (var i = 0; i < mods.length; i++) {
    if (mods[i].name.toLowerCase() === 'pytransform.pyd') {
        PTF = mods[i]; break;
    }
}
if (PTF === null) { send({t: 'nomod'}); }
else {
    var B = PTF.base;
    wf('module.txt', 'base=' + B + ' size=' + PTF.size);

    // one-shot bss dump
    wf('bss_keys.bin', hx(B.add(0x10a0c0), 0x180) || 'FAIL');
    wf('descr.bin', hx(B.add(0x10d100), 0x300) || 'FAIL');

    // --- engine entry trap ---
    Interceptor.attach(B.add(0x4850), {
        onEnter: function (a) {
            if (NENG >= 15) return;
            try {
                var frame = a[0];
                var code = a[1];
                var cipherPtr = a[2];
                var clen = a[3].toInt32();
                var s5 = a[4];  // first stack arg
                var s6 = a[5];  // second stack arg
                var rec = {
                    t: 'eng', n: NENG,
                    clen: clen,
                    s5: '' + s5, s6: '' + s6,
                    s5hex: hx(s5, 16),
                    s6hex: s6.isNull() ? null : hx(s6, 16),
                    cipher_head: hx(cipherPtr, 32)
                };
                if (!code.isNull()) {
                    // co_code bytes object lives at code+0x30
                    try {
                        var bc = code.add(0x30).readPointer();
                        var bn = Number(bc.add(16).readU64());
                        rec.env_len = bn;
                        rec.env_head = hx(bc.add(32), 32);
                        rec.env_tail = hx(bc.add(32).add(bn - 16), 16);
                    } catch (e2) {}
                }
                wf('eng_' + NENG + '.json', JSON.stringify(rec));
                NENG++;
            } catch (e) { send({t: 'engerr', e: '' + e}); }
        }
    });

    // --- ctr_start trap: the REAL id/IV/key ---
    Interceptor.attach(B.add(0x168a0), {
        onEnter: function (a) {
            if (NKS >= 40) return;
            try {
                var rec = {
                    t: 'ctr_start', n: NKS,
                    id: a[0].toInt32(),
                    iv: hx(a[1], 16),
                    key: hx(a[2], 16),
                    keylen: a[3].toInt32()
                };
                wf('ks_' + NKS + '.json', JSON.stringify(rec));
                NKS++;
            } catch (e) { send({t: 'kserr', e: '' + e}); }
        }
    });

    // --- ctr_decrypt trap: scoop plaintext on leave ---
    Interceptor.attach(B.add(0x16270), {
        onEnter: function (a) {
            this.pt = a[0];
            this.len = a[2].toInt32();
        },
        onLeave: function (r) {
            if (NPT >= 60) return;
            if (this.len < 40 || this.len > 4096 || this.len % 2) return;
            var body = hx(this.pt, this.len);
            if (!body) return;
            wf('plain_' + NPT + '_len' + this.len + '.bin', body);
            NPT++;
        }
    });

    send({t: 'ready', base: '' + B});
}
