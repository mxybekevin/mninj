# eng_decode45.py - prove the cipher math against live engine
# envelopes using the SESSION constants (app process bss block).
import json
import os
import struct

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
TRAP = os.path.join(ORACLE, 'out', 'fence45', 'trap')

src = open(os.path.join(ORACLE, 'decryptor46.py')).read()
cut = src.index('# ---------- oracle ----------')
ns = {}
exec(src[:cut], ns)
wordloop_dec = ns['wordloop_dec']
xor24_dec = ns['xor24_dec']
aes128_ctr = ns['aes128_ctr']
ctr_key = ns['ctr_key']

# reload the key cluster from the APP-PROCESS block
kb = open(os.path.join(TRAP, 'bss_keys.bin'), 'rb').read()
BASE = 0x10a0c0


def q(va):
    return struct.unpack_from('<Q', kb, va - BASE)[0]


Q1CE = q(0x10a1ce)
Q1D6 = q(0x10a1d6)
Q1D2 = q(0x10a1d2)
Q1DA = q(0x10a1da)
XOR24_KEY = kb[0x10a1d2 - BASE:0x10a1ea - BASE]
print('APP q1ce=%016x q1d6=%016x' % (Q1CE, Q1D6))
print('APP xor24key=%s' % XOR24_KEY.hex())
ns2 = dict(ns)
ns2['Q1CE'] = Q1CE
ns2['Q1D6'] = Q1D6
ns2['Q1D2'] = Q1D2
ns2['Q1DA'] = Q1DA
ns2['XOR24_KEY'] = XOR24_KEY

# rebuild the key functions against the app constants
M32 = 0xffffffff


def u32(x):
    return x & M32


def ctr_key2(tail16):
    w = struct.unpack('<4I', tail16)
    k0 = u32(w[0] ^ (Q1CE & M32))
    k1 = u32((u32(w[1] - 0xf275)) ^ (Q1CE >> 32))
    k2 = u32((u32(w[2] + 0xb0b0)) ^ (Q1D6 & M32))
    k3 = u32((u32(w[3] + 0xcd59)) ^ (Q1D6 >> 32))
    return struct.pack('<4I', k0, k1, k2, k3)


def wordloop_key2(tail16):
    w = struct.unpack('<4I', tail16)
    k0 = u32(w[0] ^ (Q1D2 & M32))
    k1 = u32((u32(w[1] - 0xb35)) ^ (Q1D2 >> 32))
    k2 = u32((u32(w[2] + 0xd6ae)) ^ (Q1DA & M32))
    k3 = u32((u32(w[3] + 0xe9c3)) ^ (Q1DA >> 32))
    return struct.pack('<4I', k0, k1, k2, k3)


def wordloop_dec2(span, tail16):
    K = struct.unpack('<4I', wordloop_key2(tail16))
    out = bytearray(span)
    nd = len(out) // 4
    for i in range(nd):
        w = struct.unpack_from('<I', out, i * 4)[0]
        w = u32((w ^ K[i % 4]) + 0xdd15)
        struct.pack_into('<I', out, i * 4, w)
    return bytes(out)


def xor24_dec2(buf):
    kb2 = bytearray(XOR24_KEY)
    for i in range(0x18):
        c = (0x17 - i)
        kb2[i] ^= (u32(c * c + 3)) & 0xff
    out = bytearray(buf)
    for i in range(len(out)):
        out[i] ^= kb2[i % 0x18]
    return bytes(out)


import opcode as _op
VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}


def score(dec, lo=0, hi=None):
    hi = hi or min(len(dec), 400)
    n = ok = 0
    for i in range(lo, min(len(dec) - 1, hi), 2):
        n += 1
        if dec[i] in VALID:
            ok += 1
    return (ok * 100 // n) if n else 0


for fn in sorted(os.listdir(TRAP)):
    if not fn.startswith('eng_'):
        continue
    rec = json.load(open(os.path.join(TRAP, fn)))
    head = bytes.fromhex(rec['env_head'])
    n = rec['env_len']
    tail = bytes.fromhex(rec['env_tail'])
    # reconstruct the full cipher window from cipher_head (32B) is
    # partial; use span = cipher if env fully known else skip
    # We know: env[0:32]=head, tail = env[n-16:]
    full = None  # not captured in full; decode the first 32B window
    cipher16 = head[16:32]
    print('== %s len=%d tail=%s' % (fn, n, rec['env_tail']))
    # wordloop on the visible 16 cipher bytes
    wl = wordloop_dec2(cipher16, tail)
    print('   wlVisible   score=%3d %s' % (score(wl), wl.hex()))
    # xor24 on the visible window (key index alignment 16..31)
    xk = xor24_dec2(head[16:32])
    print('   x24Visible  score=%3d %s' % (score(xk), xk.hex()))
    # CTR keystream from tail as iv+key
    ks16 = aes128_ctr(ctr_key2(tail), tail, cipher16, 'le')
    print('   ctrVisible  score=%3d %s' % (score(ks16), ks16.hex()))
print('DONE')
