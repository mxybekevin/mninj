# fence45_bss.py - THE LIVE GRAB. Import pytransform bare in our own
# py38, locate its base in this process, and dump the runtime bss
# cipher block (key material + cipher id + libtom descriptor tables).
# Read-only self-process access; writes out\\fence45\\bss_dump.bin+json.
import ctypes
import json
import os
import struct
import sys

XDIR = r'C:\Users\brian\Downloads\Nighty\Nighty.exe_extracted'
OUTD = r'C:\Users\brian\Downloads\Nighty\oracle\out\fence45'
os.makedirs(OUTD, exist_ok=True)

report = {'notes': []}

sys.path.insert(0, XDIR)
os.chdir(XDIR)
try:
    import pytransform
    report['import'] = 'ok'
except BaseException as e:
    report['import'] = 'fail: %r' % (e,)
    print(json.dumps(report, indent=1))
    sys.exit(1)

k32 = ctypes.windll.kernel32
k32.CreateToolhelp32Snapshot.restype = ctypes.c_void_p


class MODULEENTRY32W(ctypes.Structure):
    _fields_ = [
        ('dwSize', ctypes.c_ulong),
        ('th32ModuleID', ctypes.c_ulong),
        ('th32ProcessID', ctypes.c_ulong),
        ('GlblcntUsage', ctypes.c_ulong),
        ('ProccntUsage', ctypes.c_ulong),
        ('modBaseAddr', ctypes.c_void_p),
        ('modBaseSize', ctypes.c_ulong),
        ('hModule', ctypes.c_void_p),
        ('szModule', ctypes.c_wchar * 256),
        ('szExePath', ctypes.c_wchar * 260),
    ]


TH32CS_SNAPMODULE = 0x8
snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, os.getpid())
me = MODULEENTRY32W()
me.dwSize = ctypes.sizeof(MODULEENTRY32W)
ok = k32.Module32FirstW(snap, ctypes.byref(me))
base = None
mods = []
while ok:
    mods.append((me.szModule, me.modBaseSize))
    if me.szModule.lower() == 'pytransform.pyd':
        base = me.modBaseAddr
        break
    ok = k32.Module32NextW(snap, ctypes.byref(me))
k32.CloseHandle(snap)
if base is None:
    report['base'] = 'not found; modules=%r' % [m for m in mods][:40]
    print(json.dumps(report, indent=1))
    sys.exit(2)
report['base'] = hex(base)


def rd(off, n):
    try:
        buf = ctypes.create_string_buffer(n)
        ctypes.memmove(buf, ctypes.c_void_p(base + off), n)
        return buf.raw
    except BaseException as e:
        return b''


REGIONS = [
    ('sanity_head', 0x0, 0x40),
    ('expiry_068', 0x10a068, 8),
    ('lica_170', 0x10a170, 0x1b),
    ('licb_1a0', 0x10a1a0, 0x4b),
    ('keys_block', 0x10a0c0, 0x180),    # covers a0c0..a240 incl 1ce/1d6/1d2/1da/1e2/204
    ('exec_arg_030', 0x10a030, 8),
    ('descr_d100', 0x10d100, 0x300),    # libtom descriptor block
]

blob_all = b''
for label, off, n in REGIONS:
    data = rd(off, n)
    report[label] = data.hex()
    blob_all += struct.pack('<QII', off, n, 0) + data

with open(os.path.join(OUTD, 'bss_dump.bin'), 'wb') as f:
    f.write(blob_all)

# sanity: module header
mz = rd(0, 2)
report['mz'] = mz.hex()

# chase descriptor name pointers if the block reads back sane
try:
    d = rd(0x10d1b0, 0xf0)
    names = []
    ptrs = struct.unpack_from('<30Q', d, 0)
    for p in ptrs:
        if 0x6d600000 <= p < 0x6d800000:
            rva = p - 0x6d600000
            try:
                s = ctypes.create_string_buffer(40)
                ctypes.memmove(s, ctypes.c_void_p(base + rva), 39)
                z = s.raw.split(b'\x00')[0]
                if z and all(32 <= b < 127 for b in z):
                    names.append((hex(p), z.decode()))
            except BaseException:
                pass
    report['descr_strings'] = names[:20]
except BaseException as e:
    report['descr_strings'] = 'err %r' % (e,)

# cipher id dword + key qwords
k = rd(0x10a1ce, 0x40)
if len(k) == 0x40:
    report['cipher_id_204'] = struct.unpack_from('<I', k, 0x204 - 0x1ce)[0]
    report['q_1ce'] = hex(struct.unpack_from('<Q', k, 0)[0])
    report['q_1d6'] = hex(struct.unpack_from('<Q', k, 8)[0])
    kk = k[0x1d2 - 0x1ce:0x1ec - 0x1ce]
    report['xor24_key_1d2'] = kk.hex()
    report['magic_1e2'] = k[0x1e2 - 0x1ce:0x1f0 - 0x1ce].hex()

with open(os.path.join(OUTD, 'bss_dump.json'), 'w') as f:
    json.dump(report, f, indent=1)
print('cipher_id =', report.get('cipher_id_204'))
print('q_1ce     =', report.get('q_1ce'))
print('q_1d6     =', report.get('q_1d6'))
print('xor24key  =', report.get('xor24_key_1d2'))
print('magic1e2  =', report.get('magic_1e2'))
print('descr     =', report.get('descr_strings'))
print('DUMP OK ->', OUTD)
