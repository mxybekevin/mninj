# wordloop6_val.py - validate the corrected 6-word wordloop model.
# K6 = [f(tail,d2), f(tail,d2), f(tail,da), f(tail,da), e2.w0, e2.w1]
# cycle period 6; D(S)[i] = (S[i] ^ K6[i%6]) + 0xdd15
# E(P)[i] = (P[i] - 0xdd15) ^ K6[i%6]
import glob
import os
import re
import struct

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
TRAP = os.path.join(ORACLE, 'out', 'fence45', 'trap')

kb = open(os.path.join(TRAP, 'bss_keys.bin'), 'rb').read()
BASE = 0x10a0c0
M32 = 0xffffffff


def u32(x):
    return x & M32


def w(va, i):
    return struct.unpack_from('<I', kb, va - BASE + 4 * i)[0]


Q1D2 = [w(0x10a1d2, 0), w(0x10a1d2, 1)]
Q1DA = [w(0x10a1da, 0), w(0x10a1da, 1)]
Q1E2 = [w(0x10a1e2, 0), w(0x10a1e2, 1)]
print('sess2 d2=%s da=%s e2=%s'
      % ([hex(x) for x in Q1D2], [hex(x) for x in Q1DA],
         [hex(x) for x in Q1E2]))


def key6(tail16):
    t = struct.unpack('<4I', tail16)
    return [
        u32(t[0] ^ Q1D2[0]),
        u32(u32(t[1] - 0xb35) ^ Q1D2[1]),
        u32(u32(t[2] + 0xd6ae) ^ Q1DA[0]),
        u32(u32(t[3] + 0xe9c3) ^ Q1DA[1]),
        Q1E2[0],
        Q1E2[1],
    ]


def dec(S, tail16):
    K = key6(tail16)
    out = bytearray(S)
    nd = len(out) // 4
    for i in range(nd):
        v = struct.unpack_from('<I', out, i * 4)[0]
        v = u32((v ^ K[i % 6]) + 0xdd15)
        struct.pack_into('<I', out, i * 4, v)
    return bytes(out)


def enc(P, tail16):
    K = key6(tail16)
    out = bytearray(P)
    nd = len(out) // 4
    for i in range(nd):
        v = struct.unpack_from('<I', out, i * 4)[0]
        v = u32(u32(v - 0xdd15) ^ K[i % 6])
        struct.pack_into('<I', out, i * 4, v)
    return bytes(out)


envs = {}
for p in glob.glob(os.path.join(TRAP, 'env_*.bin')):
    txt = open(p).read()
    m = re.match(r'LEN=(\d+) FLAGS=(\d+)\n(.*)', txt, re.S)
    if m:
        envs[(int(m.group(2)), int(m.group(1)))
             ] = bytes.fromhex(m.group(3).strip())

plains = {}
for p in glob.glob(os.path.join(TRAP, 'plain_*.hex')):
    b = bytes.fromhex(open(p).read().strip())
    plains.setdefault(len(b), set()).add(b)

n_ok = n_try = 0
for (fl, n), env in sorted(envs.items(),
                           key=lambda kv: kv[0][1]):
    tail = env[-16:]
    for L in (n - 32, n - 16):
        if L not in plains:
            continue
        S = env[16:16 + L] if L == n - 32 else env[16:]
        for P in plains[L]:
            D = dec(S, tail)
            match = (D[:len(P)] == P[:len(S)])
            n_try += 1
            if match:
                n_ok += 1
                print('n=%3d L=%3d  DECODE MATCH  '
                      'P-head=%s' % (n, L, P[:12].hex()))
            else:
                # how close?
                same = sum(1 for a, b in zip(D, P)
                           if a == b)
                print('n=%3d L=%3d  mismatch %d/%d bytes'
                      % (n, L, same, len(P)))
print()
print('validated %d/%d pairs' % (n_ok, n_try))
