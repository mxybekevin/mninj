# bank_intersect45.py - coverage of the missing set by the native
# decomp bank (unit-named pseudocode files).
import glob
import json
import os
import re
from collections import defaultdict

G = r'C:\Users\brian\Downloads\Nighty\oracle\out\ghidra_decomp'
NY = (r'D:\SSD-Offload\brian\Downloads\Nighty\NightyRecovered'
      r'\Nighty.py')
ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'

bank = {}
for f in glob.glob(os.path.join(G, '*.c')):
    m = re.match(r'^(spp.*?|FUN_.*)_(\d+)$',
                 os.path.splitext(os.path.basename(f))[0])
    if m and not m.group(1).startswith('FUN_'):
        bank.setdefault(int(m.group(2)), []).append(
            (m.group(1), f))

print('bank units with lines: %d distinct lines' % len(bank))

# missing set from the Nighty.py tail ledger
missing = []
pat = re.compile(r'^#\s+-\s+([\w.]+)\s+\(line (\d+)')
for line in open(NY, 'r', encoding='utf-8', errors='replace'):
    m = pat.match(line.strip())
    if m:
        missing.append((m.group(1), int(m.group(2))))
missing.append(('getSpotifyHeaders', 6330))
print('ledger missing entries: %d' % len(missing))

# pending census for the armed/other classes
pc = json.load(open(os.path.join(ORACLE, 'out',
                                 'pending_census.json')))
print('pending_census keys: %r' % (list(pc)[:6],))
armed = pc.get('armed') or pc.get('ARMED') or []
other = pc.get('other') or pc.get('OTHER') or []
print('armed: %r' % (armed[:3],))
print('other: %d' % len(other))

covered = []
uncovered = []
for name, line in missing:
    hits = bank.get(line, [])
    ok = any(re.sub(r'^(sppL2_|spp_span_|spp_)', '', h[0]).
             startswith(name[:8]) for h in hits)
    row = (name, line, [h[0] for h in hits])
    (covered if hits else uncovered).append(row)

print()
print('=== MISSING WITH BANK COVERAGE (%d) ===' % len(covered))
for name, line, hits in covered:
    print('L%-6d %-28s %s' % (line, name[:28], hits[:3]))
print()
print('=== MISSING NOT IN BANK (%d) ===' % len(uncovered))
for name, line, _ in uncovered:
    inbank = bank.get(line)
    print('L%-6d %s' % (line, name))

# distribution of bank lines for the 4100-4600 corridor
corr = [ln for ln in sorted(bank) if 3900 <= ln <= 4700]
print()
print('bank lines in 3900-4700 corridor:', corr)
# and 5600-7000
corr2 = [ln for ln in sorted(bank) if 5600 <= ln <= 7100]
print('bank lines in 5600-7100:', corr2)
