# scoop_check45.py - validate the scooped plaintext bodies, identify
# their units via the stamp census fingerprints.
import glob
import marshal
import os
import struct
import types as _t
import opcode as _op
from collections import defaultdict

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
TRAP = os.path.join(ORACLE, 'out', 'fence45', 'trap')

VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}
JREL = set(_op.hasjrel)
JABS = set(_op.hasjabs)
NAME_OPS = {'LOAD_GLOBAL', 'LOAD_ATTR', 'LOAD_METHOD',
            'STORE_ATTR', 'IMPORT_NAME', 'IMPORT_FROM',
            'LOAD_NAME', 'STORE_NAME'}
FAST_OPS = {'LOAD_FAST', 'STORE_FAST', 'DELETE_FAST'}


def oracle(code):
    L = len(code)
    if L < 8 or L % 2:
        return None
    mx_f = mx_n = mx_c = -1
    i = 0
    ext = 0
    rets = calls = 0
    while i < L:
        op = code[i]
        if op not in VALID:
            return None
        arg = code[i + 1]
        nm = _op.opname[op]
        if nm == 'EXTENDED_ARG':
            ext = (ext << 8) | arg
            i += 2
            continue
        ea = (ext << 8) | arg
        ext = 0
        if nm in FAST_OPS:
            mx_f = max(mx_f, ea)
        elif nm in NAME_OPS:
            mx_n = max(mx_n, ea)
        elif nm == 'LOAD_CONST':
            mx_c = max(mx_c, ea)
        elif nm == 'RETURN_VALUE':
            rets += 1
        elif 'CALL' in nm:
            calls += 1
        if op in JREL:
            t = i + 2 + ea
            if not (0 <= t < L) or t % 2:
                return None
        elif op in JABS:
            if not (0 <= ea < L) or ea % 2:
                return None
        i += 2
    if code[-2] != 0x53:
        return None
    return {'mx_f': mx_f, 'mx_n': mx_n, 'mx_c': mx_c,
            'rets': rets, 'calls': calls, 'ops': L // 2}


# stamp census
units = []
for p in glob.glob(os.path.join(ORACLE, 'out', 'v5', 'v5_*.marshal')):
    try:
        t = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(t, _t.CodeType):
        continue
    st = [t]
    while st:
        c = st.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                st.append(k)
        if c.co_name == '<module>':
            continue
        if c.co_flags & 0x20000000 and c.co_flags & 0x60000000:
            units.append(c)

byc = defaultdict(list)
for c in units:
    byc[(c.co_flags, len(c.co_code))].append(c)

plains = {}
for p in glob.glob(os.path.join(TRAP, 'plain_*.hex')):
    body = bytes.fromhex(open(p).read().strip())
    key = body
    if plains.setdefault(body, p) == p:
        v = oracle(body)
        print('%s len=%d valid=%s' % (os.path.basename(p),
                                      len(body), v))
        if v:
            # find which stamp unit it could be
            for c in units:
                f = c.co_flags
                is_stub = (len(c.co_code) >= 6
                           and c.co_code[0] == 0x74
                           and c.co_code[2:4] == b'\x83\x00')
                if is_stub:
                    span_cand = len(c.co_code) - 32
                else:
                    span_cand = len(c.co_code) - 16
                if abs(span_cand - len(body)) > 16:
                    continue
                if v['mx_f'] >= len(c.co_varnames):
                    continue
                if v['mx_n'] >= len(c.co_names):
                    continue
                print('   candidate: %-25s L%-5d flags=%x '
                      'nloc=%d nnames=%d nconst=%d code_len=%d'
                      % (c.co_name, c.co_firstlineno, f,
                         len(c.co_varnames), len(c.co_names),
                         len(c.co_consts), len(c.co_code)))

print('unique bodies: %d' % len(plains))
