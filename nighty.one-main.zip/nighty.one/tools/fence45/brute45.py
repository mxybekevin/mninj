# brute45.py - find the cheap-cipher formula on the live engine
# envelope eng_0 (64B unit, cipher window visible 16B, tail known).
import json
import os
import struct
import opcode as _op

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
TRAP = os.path.join(ORACLE, 'out', 'fence45', 'trap')

kb = open(os.path.join(TRAP, 'bss_keys.bin'), 'rb').read()
BASE = 0x10a0c0
rec = json.load(open(os.path.join(TRAP, 'eng_0.json')))
env_head = bytes.fromhex(rec['env_head'])
tail = bytes.fromhex(rec['env_tail'])
C16 = env_head[16:32]        # first 16 cipher bytes (span-aligned)
print('cipher16:', C16.hex())
print('tail    :', tail.hex())

STRING = kb[0x10a1ce - BASE:0x10a1ea - BASE]   # 28 ASCII bytes
print('cluster :', STRING.decode('ascii', 'replace'))

M32 = 0xffffffff


def u32(x):
    return x & M32


q1d2 = struct.unpack('<Q', STRING[4:12])[0]
q1da_lo = struct.unpack('<I', STRING[12:16])[0]
q1da_hi = struct.unpack('<I', STRING[16:20])[0]
XOR24 = STRING[4:28]        # 24 ascii bytes per 0x1d2..0x1ea

# key sources
tails = {
    'tail': struct.unpack('<4I', tail),
    'str4': struct.unpack('<4I', STRING[:16]),
    'stra': struct.unpack('<4I', STRING[4:20]),
    'str0': struct.unpack('<4I', STRING[0:16]),
    'cluster_lo': struct.unpack('<4I', kb[0x10a1c8 - BASE:0x10a1d8 - BASE]),
    'ctx0': struct.unpack('<4I', kb[0x10a1e2 - BASE:0x10a1f2 - BASE]),
}
# after-tail binary run: bytes 0x1ea.. = ce88...
postbin = kb[0x10a1ea - BASE:0x10a1fa - BASE]
tails['postbin'] = struct.unpack('<4I', postbin)

CONST = [0x0, 0xdd15, 0xf275, 0xb0b0, 0xcd59, 0xb35, 0xd6ae, 0xe9c3]
OPS = ['xor_add', 'sub_xor', 'add_xor', 'xor', 'xor_sub', 'rev_pairs']

VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}
JREL = set(_op.hasjrel)
JABS = set(_op.hasjabs)


def window_score(dec16):
    # dis validity over the 16B window (8 ops)
    if len(dec16) < 16:
        return 0
    ok = 0
    i = 0
    while i < 16:
        if dec16[i] not in VALID:
            return 0
        op = dec16[i]
        arg = dec16[i + 1]
        nm = _op.opname[op]
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t <= 64):
                ok -= 2
        i += 2
        ok += 1
    return ok * 12  # 96 = perfect


results = []
for ks_name, KS in tails.items():
    # K derivation: apply the engine assembly exact operations
    w0, w1, w2, w3 = struct.unpack('<4I', tail)
    derived = {
        'derA': (u32(w0 ^ (q1d2 & M32)),
                 u32((u32(w1 - 0xb35)) ^ (q1d2 >> 32)),
                 u32((u32(w2 + 0xd6ae)) ^ q1da_lo),
                 u32((u32(w3 + 0xe9c3)) ^ q1da_hi)),
        'derB': (u32(w0 ^ q1da_lo),
                 u32((u32(w1 - 0xb35)) ^ q1da_hi),
                 u32((u32(w2 + 0xd6ae)) ^ (q1d2 & M32)),
                 u32((u32(w3 + 0xe9c3)) ^ (q1d2 >> 32))),
        'raw': KS,
    }
    for dname, K in derived.items():
        for cnst in CONST:
            for opn in OPS:
                out = bytearray(C16)
                for i in range(4):
                    w = struct.unpack_from('<I', out, i * 4)[0]
                    k = K[i % 4]
                    if opn == 'xor_add':
                        w = u32((w ^ k) + cnst)
                    elif opn == 'sub_xor':
                        w = u32((u32(w - cnst)) ^ k)
                    elif opn == 'add_xor':
                        w = u32((u32(w + cnst)) ^ k)
                    elif opn == 'xor':
                        w = u32(w ^ k) if cnst == 0 else None
                    elif opn == 'xor_sub':
                        w = u32((w ^ k) - cnst)
                    elif opn == 'rev_pairs':
                        w = u32(u32(w ^ k) + cnst)
                    if w is None:
                        break
                    struct.pack_into('<I', out, i * 4, w)
                else:
                    s = window_score(bytes(out))
                    if s >= 96:
                        results.append((s, ks_name, dname, cnst,
                                        opn, bytes(out).hex()))
                        print('HIT %-10s %-4s c=%05x %-8s -> %s'
                              % (ks_name, dname, cnst, opn,
                                 bytes(out).hex()))

# xor24 family: key variants, mangle variants, anchors
xkeys = {'ascii24': XOR24, 'str0_24': STRING[:24]}
for kn, kv in xkeys.items():
    for mangle in (True, False):
        k = bytearray(kv)
        if mangle:
            for i in range(0x18):
                c = 0x17 - i
                k[i] ^= (u32(c * c + 3)) & 0xff
        out = bytearray(C16)
        for i in range(16):
            out[i] ^= k[i % 0x18]
        s = window_score(bytes(out))
        if s >= 96:
            print('HIT x24 %s mangle=%s -> %s'
                  % (kn, mangle, bytes(out).hex()))

# xor with tail directly (both ends)
for tn, tv in (('tail', tail), ('str', STRING[:16])):
    out = bytes(a ^ b for a, b in zip(C16, tv))
    s = window_score(out)
    if s >= 96:
        print('HIT plain xor %s -> %s' % (tn, out.hex()))

print('brute done; hits = %d' % len(results))
