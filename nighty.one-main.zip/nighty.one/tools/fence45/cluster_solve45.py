# cluster_solve45.py - derive the sess2 cluster d2/da from a clean
# (envelope, plain) pair, then validate the 6-word model on every
# other pair. e2 words stay raw cluster constants.
import glob
import os
import re
import struct

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
TRAP = os.path.join(ORACLE, 'out', 'fence45', 'trap')
M32 = 0xffffffff


def u32(x):
    return x & M32


envs = {}
for p in glob.glob(os.path.join(TRAP, 'env_*.bin')):
    txt = open(p).read()
    m = re.match(r'LEN=(\d+) FLAGS=(\d+)\n(.*)', txt, re.S)
    if m:
        envs[(int(m.group(2)), int(m.group(1)))
             ] = bytes.fromhex(m.group(3).strip())

plains = {}
for p in glob.glob(os.path.join(TRAP, 'plain_*.hex')):
    b = bytes.fromhex(open(p).read().strip())
    plains.setdefault(len(b), set()).add(b)

pairs = []
for (fl, n), env in envs.items():
    for L in (n - 32, n - 16):
        if L in plains:
            S = env[16:16 + L] if L == n - 32 else env[16:]
            for P in plains[L]:
                if len(S) >= len(P):
                    pairs.append((fl, n, env, S, P))

# solve K6 empirically per pair (K[i%6] consensus)
def solve_k6(S, P):
    ks = [None] * 6
    votes = [[] for _ in range(6)]
    for i in range(len(S) // 4):
        sw = struct.unpack_from('<I', S, i * 4)[0]
        pw = struct.unpack_from('<I', P, i * 4)[0]
        k = sw ^ u32(pw - 0xdd15)
        votes[i % 6].append(k)
    out = []
    for v in votes:
        if not v:
            out.append(None)
            continue
        best = max(set(v), key=v.count)
        out.append(best if v.count(best) * 2 > len(v)
                   else None)
    return out


# find pair with full 6-consensus
solved = None
for fl, n, env, S, P in pairs:
    K = solve_k6(S, P)
    if all(k is not None for k in K):
        solved = (fl, n, env, K)
        print('anchor pair: n=%d flags=%x' % (n, fl))
        print('K6:', [hex(x) for x in K])
        break

if solved:
    fl, n, env, K = solved
    t = struct.unpack('<4I', env[-16:])
    d2w0 = K[0] ^ t[0]
    d2w1 = K[1] ^ u32(t[1] - 0xb35)
    daw0 = K[2] ^ u32(t[2] + 0xd6ae)
    daw1 = K[3] ^ u32(t[3] + 0xe9c3)
    e2w0, e2w1 = K[4], K[5]
    print('derived sess2 cluster:')
    print('  d2 = %08x %08x' % (d2w0, d2w1))
    print('  da = %08x %08x' % (daw0, daw1))
    print('  e2 = %08x %08x' % (e2w0, e2w1))

    def key6(tail16):
        tt = struct.unpack('<4I', tail16)
        return [
            u32(tt[0] ^ d2w0),
            u32(u32(tt[1] - 0xb35) ^ d2w1),
            u32(u32(tt[2] + 0xd6ae) ^ daw0),
            u32(u32(tt[3] + 0xe9c3) ^ daw1),
            e2w0, e2w1,
        ]

    def dec(S, tail16):
        Kk = key6(tail16)
        out = bytearray(S)
        for i in range(len(out) // 4):
            v = struct.unpack_from('<I', out, i * 4)[0]
            v = u32((v ^ Kk[i % 6]) + 0xdd15)
            struct.pack_into('<I', out, i * 4, v)
        return bytes(out)

    def enc(P, tail16):
        Kk = key6(tail16)
        out = bytearray(P)
        for i in range(len(out) // 4):
            v = struct.unpack_from('<I', out, i * 4)[0]
            v = u32(u32(v - 0xdd15) ^ Kk[i % 6])
            struct.pack_into('<I', out, i * 4, v)
        return bytes(out)

    n_ok = 0
    checked = []
    for fl2, n2, env2, S2, P2 in pairs:
        tail2 = env2[-16:]
        D = dec(S2, tail2)
        m = D[:len(P2)] == P2[:len(S2)]
        E = None
        checked.append((fl2, n2, m))
        if m:
            n_ok += 1
    print('validated %d/%d pairs' % (n_ok, len(pairs)))
    for fl2, n2, m in checked:
        print('  n=%3d f=%x %s' % (n2, fl2,
                                   'MATCH' if m else 'fail'))
    # save the cluster + key6 for the record
    with open(os.path.join(ORACLE, 'out', 'fence45',
                           'sess2_cluster.json'), 'w') as f:
        import json
        json.dump({'d2': [d2w0, d2w1], 'da': [daw0, daw1],
                   'e2': [e2w0, e2w1],
                   'anchor_block': n, 'anchor_flags': fl},
                  f, indent=1)
    print('saved sess2_cluster.json')
