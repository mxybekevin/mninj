import time
time.sleep(7)
"""fence_target44.py - v21: THE FRIDA-PARTNER SESSION.
The external debugger owns capture (hooks on PyCode_New see every
materialized code object with zero timing pressure), so the in-process
sampler is retired. This harness now concentrates on TRIGGERING:
  - two proven harvests + post marshals (metadata evidence)
  - golden toast sends x12 (drives the whole notification family:
    show_notification slot, ToastNotification ctor, slide/fade paths)
  - tier-A call waves over the census worklist (direct execution of
    every resolvable pending unit)
  - a long natural-idle window (webview/RPC/timer behaviors)
Killer at 600s.
"""
import asyncio
import ctypes
import glob
import json
import marshal
import os
import struct
import sys
import threading
import types as _t

time44 = __import__('time')
struct44 = __import__('struct')
ctypes44 = ctypes

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
RTP = os.path.join(OUT, 'fence44')
os.makedirs(RTP, exist_ok=True)
T0 = time44.time()
THREAD = threading.Thread
LOGH = open(os.path.join(RTP, 'fence44_session.log'), 'w', 1)


def slog(m):
    LOGH.write('%s\n' % m)


EXTRACT = r'C:\\Users\\brian\\Downloads\\Nighty\\Nighty.exe_extracted'
PYZ_EXT = os.path.join(EXTRACT, 'PYZ.pyz_extracted')
V5D = os.path.join(OUT, 'v5')

sys.path.insert(0, HERE)
from spp_fake import make_fake_module

census = json.load(open(os.path.join(OUT, 'pending_census.json')))
work = [(e['name'], e['line'], e['size'], k)
        for k in ('ARMED', 'OTHER') for e in census[k]]
WORK_KEYS = {(n, l) for n, l, _, _ in work}
slog('worklist: %d' % len(work))


def fp(co):
    return ('V:' + repr(tuple(co.co_varnames)) +
            '|N:' + repr(tuple(co.co_names)))


UNIT_FP = {}
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        co = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(co, _t.CodeType):
        continue
    stack = [co]
    while stack:
        c = stack.pop()
        key = (str(c.co_name), c.co_firstlineno)
        if key in WORK_KEYS:
            UNIT_FP[fp(c)] = key
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                stack.append(k)
slog('fingerprint table: %d' % len(UNIT_FP))


def classify(co):
    code = co.co_code
    if len(code) >= 6 and code[0] == 0x74 and \
            code[2:4] == b'\x83\x00' and code[4:6] == b'\x09\x00':
        return 'ARMED'
    return 'NOT-ARMED'


def marshal_obj(key, obj):
    name, line = key
    fn = 'post_%s_L%d.marshal' % (name.replace('.', '_'), line)
    try:
        with open(os.path.join(RTP, fn), 'wb') as f:
            marshal.dump(obj.__code__, f)
    except BaseException as e:
        slog('marshal fail %s %r' % (fn, e))


APP_DICTS = [None]


def harvest():
    import gc
    seen_ids = set()
    hits = {}

    def try_fn(obj):
        try:
            if not isinstance(obj, _t.FunctionType):
                return False
            oid = id(obj)
            if oid in seen_ids:
                return False
            seen_ids.add(oid)
            co = obj.__code__
            key = UNIT_FP.get(fp(co))
            if key is None:
                key = (str(co.co_name), co.co_firstlineno)
                if key not in WORK_KEYS:
                    return False
            if key in hits:
                return False
            hits[key] = obj
            return True
        except BaseException:
            return False

    t_sweep = time44.time()
    app_dicts = {}
    try:
        for o in gc.get_objects():
            try:
                if isinstance(o, type):
                    for v in list(vars(o).values()):
                        if isinstance(v, _t.FunctionType):
                            try_fn(v)
                            app_dicts[id(v.__globals__)] = v.__globals__
                elif hasattr(o, '__dict__'):
                    for v in list(o.__dict__.values()):
                        if isinstance(v, _t.FunctionType):
                            try_fn(v)
                            app_dicts[id(v.__globals__)] = v.__globals__
            except BaseException:
                continue
    except BaseException as e:
        slog('gc walk err %r' % (e,))
    for m in list(sys.modules.values()):
        try:
            for v in list(m.__dict__.values()):
                if isinstance(v, _t.FunctionType):
                    try_fn(v)
                    app_dicts[id(v.__globals__)] = v.__globals__
        except BaseException:
            continue
    for d in list(app_dicts.values()):
        try:
            for v in list(d.values()):
                if isinstance(v, _t.FunctionType):
                    try_fn(v)
        except BaseException:
            continue
    for d in list(app_dicts.values()):
        try:
            for v in list(d.values()):
                if isinstance(v, type):
                    for vv in list(vars(v).values()):
                        if isinstance(vv, _t.FunctionType):
                            try_fn(vv)
        except BaseException:
            continue
    slog('pass1: %d matches, %d app dicts, %ds'
         % (len(hits), len(app_dicts), time44.time() - t_sweep))
    APP_DICTS[0] = app_dicts
    return hits


EVENT_FAMILY = {
    'paintEvent', 'enterEvent', 'leaveEvent', 'mousePressEvent',
    'closeEvent', 'resizeEvent', 'keyPressEvent', 'showEvent',
    'hideEvent', 'focusInEvent', 'focusOutEvent', 'wheelEvent',
    'moveEvent', 'slide_up', 'start_fade_out', 'close_and_remove',
    'close_notification', 'remove_notification', 'stop',
    'show_notification', 'on_image_loaded',
}
STR_ARGS = ('message', 'msg', 'text', 'content', 'title', 'body',
            'name', 'key', 'path', 'url', 'link', 'description',
            'reason', 'prompt', 'query', 'filter', 'icon')
INT_ARGS = ('seconds', 'second', 'time', 'delay', 'timeout',
            'interval', 'duration', 'count', 'limit', 'index', 'port',
            'width', 'height', 'x', 'y', 'w', 'h')
ID_ARGS = ('channel_id', 'guild_id', 'user_id', 'role_id',
           'message_id', 'app_id')
DICT_ARGS = ('settings', 'data', 'config', 'payload', 'params',
             'values', 'options', 'headers', 'info')
LIST_ARGS = ('items', 'accounts', 'tokens', 'profiles', 'languages',
             'records', 'entries')


def derive_arg(pname):
    p = pname.lower()
    if p == 'cls':
        return None
    if any(s in p for s in STR_ARGS) and 'id' not in p:
        return 'Nighty recovery probe'
    if any(s in p for s in ID_ARGS) or p.endswith('_id'):
        return 1234567890
    if any(s in p for s in INT_ARGS):
        return 30
    if any(s in p for s in DICT_ARGS):
        return {'probe': 1}
    if any(s in p for s in LIST_ARGS):
        return [{'probe': 1}]
    if p in ('channel', 'guild', 'user', 'role', 'member', 'embed',
             'image', 'file', 'stream', 'sock', 'conn'):
        return None
    if p in ('enabled', 'flag', 'state', 'value', 'val'):
        return True
    if p.endswith('s') and len(p) > 4:
        return ['probe']
    return None


def call_one(obj, resolver):
    co = obj.__code__
    argn = co.co_argcount
    varnames = co.co_varnames
    args = []
    qn = getattr(obj, '__qualname__', obj.__name__)
    for i, vn in enumerate(varnames[:min(argn, 12)]):
        v = derive_arg(vn)
        if v is None and i == 0 and qn != obj.__name__:
            inst = resolver(qn.split('.')[0])
            if inst is None:
                return 'NEED-INSTANCE'
            args.append(inst)
            continue
        if v is None and vn == 'cls' and i == 0:
            return 'NEED-CLS'
        args.append(derive_arg(vn))
    try:
        r = obj(*args)
    except BaseException as e:
        return 'EXC:%s' % type(e).__name__
    if asyncio.iscoroutine(r):
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(r)
            return 'ASYNC-OK'
        except BaseException as e:
            return 'ASYNC-EXC:%s' % type(e).__name__
        finally:
            try:
                if not r.done():
                    r.close()
            except BaseException:
                pass
            loop.close()
    return 'OK'


def session_main():
    time44.sleep(35)
    hits = harvest()
    for key, obj in sorted(hits.items()):
        marshal_obj(key, obj)
    time44.sleep(40)
    hits2 = harvest()
    for key, obj in sorted(hits2.items()):
        if key not in hits:
            marshal_obj(key, obj)
    slog('harvest hit count: %d'
         % len(set(hits) | set(hits2)))
    objs = dict(hits)
    objs.update(hits2)

    # golden: the app's own toast machinery x12
    import gc
    app_dicts = APP_DICTS[0] or {}
    targets = []
    for d in list(app_dicts.values()):
        try:
            v = d.get('notification_sender')
            if v is not None and \
                    callable(getattr(v, 'sendToast', None)):
                targets.append(v)
        except BaseException:
            continue
    slog('golden targets: %d' % len(targets))
    t = targets[0] if targets else None
    if t is not None:
        for attempt in range(12):
            try:
                t.sendToast('Nighty recovery probe %d' % attempt,
                            logo_url='https://nighty.one/img/nighty.png',
                            on_click='https://nighty.one',
                            type_='info',
                            title='Recovery %d' % attempt,
                            details={'probe': 1},
                            timeout=30)
                slog('GOLDEN-SEND OK %d' % attempt)
            except BaseException as e:
                slog('GOLDEN-SEND %d -> %s: %s'
                     % (attempt, type(e).__name__, str(e)[:80]))
            time44.sleep(5.0)
    slog('golden phase done')

    inst_by_name = {}

    def resolver(cls_name):
        if cls_name in inst_by_name:
            return inst_by_name[cls_name]
        found = None
        try:
            for o in gc.get_objects():
                try:
                    if type(o).__name__ == cls_name and \
                            not isinstance(o, type):
                        found = o
                        break
                except BaseException:
                    continue
        except BaseException:
            pass
        inst_by_name[cls_name] = found
        return found

    tier_a = [k for k in sorted(objs)
              if k[0] not in EVENT_FAMILY]
    slog('tierA: %d units' % len(tier_a))
    for wave in range(2):
        ok = skip = 0
        for key in tier_a:
            r = call_one(objs[key], resolver)
            if r in ('NEED-INSTANCE', 'NEED-CLS'):
                skip += 1
            else:
                ok += 1
                marshal_obj(key, objs[key])
        slog('wave %d tierA ok=%d skipped=%d' % (wave, ok, skip))
        time44.sleep(2.0)
    # long natural-idle window for the externally-hooked process
    slog('idle window open (external hooks own the watch)')
    time44.sleep(240)
    final = harvest()
    slog('final harvest: %d' % len(final))
    for key in sorted(final):
        marshal_obj(key, final[key])
        slog('post-state %-26s L%-6d %s'
             % (key[0][:26], key[1], classify(final[key].__code__)))
    slog('SESSION COMPLETE')


def killer():
    time44.sleep(600)
    slog('killer exit')
    LOGH.flush()
    os._exit(0)


THREAD(target=killer, daemon=True).start()
THREAD(target=lambda: (time44.sleep(70), session_main()),
       daemon=True).start()

os.environ['TCL_LIBRARY'] = os.path.join(PYZ_EXT, '_tcl_data')
os.environ['TK_LIBRARY'] = os.path.join(PYZ_EXT, '_tk_data')
sys.path.insert(1, EXTRACT)
sys.path.append(PYZ_EXT)
sys.path.append(os.path.join(EXTRACT, 'win32'))
sys.path.append(os.path.join(PYZ_EXT, 'win32'))
sys.path.append(os.path.join(HERE, 'py38_extra'))
make_fake_module('spp_export_api')

with open(os.path.join(HERE, 'Nighty.pyc'), 'rb') as f:
    raw = f.read()
bootstrap = marshal.loads(raw[16:])
GNS = {'__name__': '__main__',
       '__file__': os.path.join(EXTRACT, 'Nighty.pyc'),
       '__builtins__': __builtins__}


def run_exec():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        exec(bootstrap, GNS)
    except BaseException as e:
        print('[44] exec ended: %r' % (e,), flush=True)


print('[44] bootstrap exec in worker', flush=True)
THREAD(target=run_exec, daemon=True).start()
time44.sleep(620)
slog('session closing')
LOGH.flush()
os._exit(0)

