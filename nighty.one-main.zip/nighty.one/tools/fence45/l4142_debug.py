# l4142_debug.py - focused decode-attempt matrix on the ONE trusted
# envelope: the L4142 ctor. Compares live capture vs stamp envelope,
# tries every key/IV/span hypothesis, prints decode quality.
import glob
import json
import marshal
import os
import struct
import types as _t

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
src = open(os.path.join(ORACLE, 'decryptor46.py')).read()
cut = src.index('# ---------- oracle ----------')
ns = {}
exec(src[:cut], ns)
aes128_ctr = ns['aes128_ctr']
ctr_key = ns['ctr_key']
wordloop_dec = ns['wordloop_dec']
wordloop_key = ns['wordloop_key']
xor24_dec = ns['xor24_dec']

# ---- envelope sources ----
live = None
for p in glob.glob(os.path.join(ORACLE, 'out', 'fence44',
                                'fridadump', '*L4142*.json')):
    rec = json.load(open(p))
    for k, v in rec.items():
        if isinstance(v, str) and len(v) > 200 and \
                all(c in '0123456789abcdefABCDEF' for c in v):
            live = bytes.fromhex(v)
            print('live envelope from %s field %s len %d'
                  % (os.path.basename(p), k, len(live)))
            break
    if live:
        break

stamp = None
for p in glob.glob(os.path.join(ORACLE, 'out', 'v5', 'v5_*.marshal')):
    t = marshal.load(open(p, 'rb'))
    if not isinstance(t, _t.CodeType):
        continue
    st = [t]
    while st:
        c = st.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                st.append(k)
        if c.co_firstlineno == 4142 and c.co_name == '__init__' \
                and len(c.co_code) > 100:
            stamp = c.co_code
    if stamp:
        break

print('live:', (live[:16].hex() + '...' + live[-16:].hex())
      if live else None, len(live) if live else 0)
print('stamp:', (stamp[:16].hex() + '...' + stamp[-16:].hex())
      if stamp else None, len(stamp) if stamp else 0)
print('identical:', live == stamp)

# ---- hypothesis matrix ----
import opcode as _op
VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}


def score(dec):
    n = ok = 0
    for i in range(0, min(len(dec) - 1, 400), 2):
        n += 1
        if dec[i] in VALID:
            ok += 1
    return (ok * 100 // n) if n else 0


def try_all(env, label, nnames=114, nloc=18):
    print('==== %s (len %d) ====' % (label, len(env)))
    tail = env[-16:]
    slot12 = env[12:28]
    span_mid = env[16:-16]
    span_end = env[16:]
    span_8 = env[8:-16]
    cands = [
        ('ctr le  iv=tail  k=tail  span16',
         aes128_ctr(ctr_key(tail), tail, span_mid, 'le')),
        ('ctr be  iv=tail  k=tail  span16',
         aes128_ctr(ctr_key(tail), tail, span_mid, 'be')),
        ('ctr le  iv=12    k=12    span16',
         aes128_ctr(ctr_key(slot12), slot12, span_mid, 'le')),
        ('ctr le  iv=12    k=tail  span16',
         aes128_ctr(ctr_key(tail), slot12, span_mid, 'le')),
        ('ctr le  iv=tail  k=12    span16',
         aes128_ctr(ctr_key(slot12), tail, span_mid, 'le')),
        ('ctr le  iv=8     k=8     span16',
         aes128_ctr(ctr_key(env[8:24]), env[8:24], span_mid, 'le')),
        ('ctr le  iv=tail  k=tail  span8',
         aes128_ctr(ctr_key(tail), tail, span_8, 'le')),
        ('ctr le  iv=tail  k=tail  noftl',
         aes128_ctr(ctr_key(tail), tail, span_end, 'le')),
        ('ctr le  iv=16    k=16    span8',
         aes128_ctr(ctr_key(env[16:32]), env[16:32],
                    env[8:-16], 'le')),
        ('wl       k=tail           span16',
         wordloop_dec(span_mid, tail)),
        ('wl       k=12             span16',
         wordloop_dec(span_mid, slot12)),
        ('wl       k=8              span16',
         wordloop_dec(span_mid, env[8:24])),
        ('wl       k=tail           span8',
         wordloop_dec(env[8:-16], tail)),
        ('x24      full', xor24_dec(env)),
        ('x24      span16', xor24_dec(span_mid)),
    ]
    for tag, dec in cands:
        if not dec:
            continue
        s = score(dec)
        head = dec[:24].hex()
        mark = ' <<<<' if s >= 92 else ''
        print('%-32s score=%3d head=%s%s' % (tag, s, head, mark))
        if s >= 92:
            with open(os.path.join(ORACLE, 'out', 'decrypt46',
                                   'L4142_%s.bin' % tag.split()[0]),
                      'wb') as f:
                f.write(dec)


if live:
    try_all(live, 'LIVE capture')
if stamp:
    try_all(stamp, 'STAMP envelope')

print('tail hex (live):', live[-16:].hex() if live else None)
print('head32 (live):', live[:32].hex() if live else None)
