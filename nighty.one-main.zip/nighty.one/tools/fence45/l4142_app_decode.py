# l4142_app_decode.py - retry L4142 with the APP-SESSION constants
# (bss_keys.bin captured live from the real harness process).
import json
import os
import struct
import marshal
import glob
import types as _t
import opcode as _op

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
TRAP = os.path.join(ORACLE, 'out', 'fence45', 'trap')

kb = open(os.path.join(TRAP, 'bss_keys.bin'), 'rb').read()
BASE = 0x10a0c0


def q(va):
    return struct.unpack_from('<Q', kb, va - BASE)[0]


M32 = 0xffffffff


def u32(x):
    return x & M32


Q1CE = q(0x10a1ce)
Q1D6 = q(0x10a1d6)
Q1D2 = q(0x10a1d2)
Q1DA = q(0x10a1da)
XOR24 = kb[0x10a1d2 - BASE:0x10a1ea - BASE]
print('app cluster hex @1ce:', kb[0x1ce:0x1fe].hex())
print('q1ce=%016x q1d6=%016x q1d2=%016x q1da=%016x'
      % (Q1CE, Q1D6, Q1D2, Q1DA))

src = open(os.path.join(ORACLE, 'decryptor46.py')).read()
cut = src.index('# ---------- the cheap decoders ----------')
ns = {}
exec(src[:cut], ns)
aes128_ctr = ns['aes128_ctr']


def ctr_key(tail16):
    w = struct.unpack('<4I', tail16)
    k0 = u32(w[0] ^ (Q1CE & M32))
    k1 = u32((u32(w[1] - 0xf275)) ^ (Q1CE >> 32))
    k2 = u32((u32(w[2] + 0xb0b0)) ^ (Q1D6 & M32))
    k3 = u32((u32(w[3] + 0xcd59)) ^ (Q1D6 >> 32))
    return struct.pack('<4I', k0, k1, k2, k3)


def wordloop_key(tail16):
    w = struct.unpack('<4I', tail16)
    k0 = u32(w[0] ^ (Q1D2 & M32))
    k1 = u32((u32(w[1] - 0xb35)) ^ (Q1D2 >> 32))
    k2 = u32((u32(w[2] + 0xd6ae)) ^ (Q1DA & M32))
    k3 = u32((u32(w[3] + 0xe9c3)) ^ (Q1DA >> 32))
    return struct.pack('<4I', k0, k1, k2, k3)


def wordloop_dec(span, tail16):
    K = struct.unpack('<4I', wordloop_key(tail16))
    out = bytearray(span)
    nd = len(out) // 4
    for i in range(nd):
        w = struct.unpack_from('<I', out, i * 4)[0]
        w = u32((w ^ K[i % 4]) + 0xdd15)
        struct.pack_into('<I', out, i * 4, w)
    return bytes(out)


def wordloop_enc(span, tail16):
    K = struct.unpack('<4I', wordloop_key(tail16))
    out = bytearray(span)
    nd = len(out) // 4
    for i in range(nd):
        w = struct.unpack_from('<I', out, i * 4)[0]
        w = u32((u32(w - 0xdd15)) ^ K[i % 4])
        struct.pack_into('<I', out, i * 4, w)
    return bytes(out)


def xor24_dec(buf):
    k = bytearray(XOR24)
    for i in range(0x18):
        c = (0x17 - i)
        k[i] ^= (u32(c * c + 3)) & 0xff
    out = bytearray(buf)
    for i in range(len(out)):
        out[i] ^= k[i % 0x18]
    return bytes(out)


# the L4142 envelope (stamp == fence44 live capture, verified)
stamp = None
for p in glob.glob(os.path.join(ORACLE, 'out', 'v5', 'v5_*.marshal')):
    t = marshal.load(open(p, 'rb'))
    if not isinstance(t, _t.CodeType):
        continue
    st = [t]
    while st:
        c = st.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                st.append(k)
        if c.co_firstlineno == 4142 and c.co_name == '__init__' \
                and len(c.co_code) > 100:
            stamp = c
    if stamp:
        break
env = stamp.co_code
print('envelope len:', len(env), 'tail:', env[-16:].hex())

VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}


def score(dec):
    n = ok = 0
    for i in range(0, min(len(dec) - 1, 600), 2):
        n += 1
        if dec[i] in VALID:
            ok += 1
    return (ok * 100 // n) if n else 0


tail = env[-16:]
cands = [
    ('ctr le', aes128_ctr(ctr_key(tail), tail, env[16:-16], 'le')),
    ('ctr be', aes128_ctr(ctr_key(tail), tail, env[16:-16], 'be')),
    ('ctr le span8', aes128_ctr(ctr_key(tail), tail,
                                env[8:-16], 'le')),
    ('ctr le key12', aes128_ctr(
        ctr_key(env[12:28]), env[12:28], env[16:-16], 'le')),
    ('wl', wordloop_dec(env[16:-16], tail)),
    ('wl-enc', wordloop_enc(env[16:-16], tail)),
    ('wl span8', wordloop_dec(env[8:-16], tail)),
    ('x24 full', xor24_dec(env)),
    ('x24 span16', xor24_dec(env[16:-16])),
]
for tag, dec in cands:
    s = score(dec)
    print('%-14s score=%3d head=%s' % (tag, s, dec[:24].hex()))
    if s >= 90:
        fn = os.path.join(ORACLE, 'out', 'decrypt46',
                          'L4142_APP_%s.bin' % tag.replace(' ', '_'))
        open(fn, 'wb').write(dec)
        print('SAVED', fn)
