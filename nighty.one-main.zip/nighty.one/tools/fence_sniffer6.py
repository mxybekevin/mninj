"""
fence_sniffer6.py - STOP-AND-GRAB.

The pyarmor restore marshal is readable only during the loader's walk.
Strategy: continuous fast FN-anchor scanning; the moment the marshal
anchor (fa 0f '<frozen Nighty>' da 08 '<module>') is spotted, SUSPEND the
target process (NtSuspendProcess) to freeze all page states, then read
out the whole neighborhood (+-32MB) page by page, then resume.
"""
import ctypes
import hashlib
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
os.makedirs(SNAPS, exist_ok=True)
STREAM = os.path.join(SNAPS, "grab_stream.bin")

pid = int(sys.argv[1])
k32 = ctypes.WinDLL("kernel32", use_last_error=True)
ntdll = ctypes.WinDLL("ntdll", use_last_error=True)

PROCESS_VM_READ = 0x0010
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_SUSPEND_RESUME = 0x0800

h = k32.OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION | PROCESS_SUSPEND_RESUME,
                    False, pid)
if not h:
    print("[-] OpenProcess failed:", k32.GetLastError())
    sys.exit(1)
print("[+] target pid %d" % pid)

def suspend():
    ntdll.NtSuspendProcess(h)

def resume():
    ntdll.NtResumeProcess(h)

class MBI(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p), ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", ctypes.c_ulong), ("RegionSize", ctypes.c_size_t),
        ("State", ctypes.c_ulong), ("Protect", ctypes.c_ulong),
        ("Type", ctypes.c_ulong),
    ]

def rpm(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t()
    ok = k32.ReadProcessMemory(h, ctypes.c_void_p(addr), buf,
                               ctypes.c_size_t(size), ctypes.byref(got))
    if not ok:
        return None
    return buf.raw[:got.value]

def regions():
    out = []
    addr = 0
    mbi = MBI()
    while addr < 0x7FFFFFFEFFFF:
        r = k32.VirtualQueryEx(h, ctypes.c_void_p(addr), ctypes.byref(mbi),
                               ctypes.sizeof(mbi))
        if r == 0:
            break
        base = mbi.BaseAddress or addr
        size = mbi.RegionSize
        if mbi.State == 0x1000:      # MEM_COMMIT
            out.append((base, size, mbi.Protect, mbi.Type))
        addr = base + size
        if size == 0:
            break
    return out

TRIGGER = b"\xfa\x0f<frozen Nighty>\xda\x08<module>"

t_start = time.time()
stream = open(STREAM, "ab", buffering=1024 * 1024)
stats = {"stored": 0, "bytes": 0, "grabs": 0}
seen = {}

def note(a, data):
    if not data:
        return
    dig = hashlib.sha1(data).digest()
    s = seen.get(a)
    if s is None:
        s = seen[a] = set()
    if dig in s or len(s) >= 40:
        return
    s.add(dig)
    stream.write(struct.pack("<QII", a, len(data), int((time.time() - t_start) * 1000) & 0xFFFFFFFF))
    stream.write(data)
    stats["stored"] += 1
    stats["bytes"] += len(data)

def full_scan(trigger_only=False):
    for base, size, prot, rtype in regions():
        if size > 0x80000000:
            continue
        off = 0
        while off < size:
            a = base + off
            data = rpm(a, min(0x10000, size - off))
            if data is not None and TRIGGER in data:
                if not trigger_only:
                    note(a, data)
                return a + data.find(TRIGGER)
            off += 0x10000
    return None

def grab_everything(center):
    print("[!] TRIGGER at %#x - suspending target" % center)
    suspend()
    time.sleep(0.05)
    stats["grabs"] += 1
    lo = int(center - 0x2000000) & ~0xFFF     # -32MB
    hi = int(center + 0x2000000) & ~0xFFF     # +32MB
    n_ok = n_fail = 0
    for pa in range(lo, hi, 0x1000):
        data = rpm(pa, 0x1000)
        if data is not None:
            note(pa, data)
            n_ok += 1
        else:
            n_fail += 1
    # also full heap sweep while suspended
    for base, size, prot, rtype in regions():
        if size > 0x80000000:
            continue
        off = 0
        while off < size:
            a = base + off
            data = rpm(a, min(0x10000, size - off))
            if data is not None:
                if len(data) == 0x10000:
                    note(a + 0, data[:0x1000])
                    note(a + 0x1000, data[0x1000:0x2000])
                    note(a + 0x2000, data[0x2000:0x3000])
                    note(a + 0x3000, data[0x3000:0x4000])
                    note(a + 0x4000, data[0x4000:0x5000])
                    note(a + 0x5000, data[0x5000:0x6000])
                    note(a + 0x6000, data[0x6000:0x7000])
                    note(a + 0x7000, data[0x7000:0x8000])
                    note(a + 0x8000, data[0x8000:0x9000])
                    note(a + 0x9000, data[0x9000:0xA000])
                    note(a + 0xA000, data[0xA000:0xB000])
                    note(a + 0xB000, data[0xB000:0xC000])
                    note(a + 0xC000, data[0xC000:0xD000])
                    note(a + 0xD000, data[0xD000:0xE000])
                    note(a + 0xE000, data[0xE000:0xF000])
                    note(a + 0xF000, data[0xF000:0x10000])
                else:
                    note(a, data)
            off += 0x10000
    resume()
    print("[+] resumed; stored so far: %d (%.1f MB), ok/fail pages: %d/%d" % (
        stats["stored"], stats["bytes"] / 1e6, n_ok, n_fail))
    stream.flush()

alive = ctypes.c_ulong()
last_report = 0.0
while True:
    hit = full_scan(trigger_only=True)
    now = time.time()
    if hit is not None:
        grab_everything(hit)
        # keep scanning for further triggers (multi-restore target)
        time.sleep(0.5)
    if now - last_report >= 10.0:
        print("[%7.2fs] stored=%d grabs=%d" % (now - t_start, stats["stored"], stats["grabs"]), flush=True)
        stream.flush()
        last_report = now
    if k32.GetExitCodeProcess(h, ctypes.byref(alive)) and alive.value != 259:
        break
    time.sleep(0.002)

stream.flush()
stream.close()
print("[done] stored=%d grabs=%d bytes=%.1fMB" % (
    stats["stored"], stats["grabs"], stats["bytes"] / 1e6))
