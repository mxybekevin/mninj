# ship44.py - integrate verified fix-wave bodies into the repo.
# For every candidate in out\vsrc44\fixed\<NAME>_L<LINE>.py:
#   1. verify byte-identity against dec truth (verify_fixed logic)
#   2. on IDENTICAL: replace the unit's section body in Nighty.py and
#      Nighty_base.py with the verified body
#   3. report
import dis
import glob
import marshal
import os
import re
import subprocess
import sys
import types as _t

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
REPO = (r'D:\SSD-Offload\brian\Downloads\Nighty\NightyRecovered')
FIXDIR = os.path.join(ORACLE, 'out', 'vsrc44', 'fixed')
NIGHTY = os.path.join(REPO, 'Nighty.py')
BASE = os.path.join(REPO, 'Nighty_base.py')

VERIFYER = (r'C:\Users\brian\AppData\Local\Temp\opencode'
            r'\verify_fixed.py')
PY = r'C:\Users\brian\Downloads\Nighty\py38\python.exe'

HEADER_PAT = re.compile(r'^#\s*([\w.]+)\s*\(original line (\d+)\)')
RULER_PAT = re.compile(r'^#-+\s*$')


def unit_from_filename(fn):
    m = re.match(r'(.+)_L(\d+)\.py$', fn)
    if not m:
        return None
    return m.group(1), int(m.group(2))


def verify(name, line, path):
    r = subprocess.run(
        [PY, VERIFYER, name, str(line), path],
        capture_output=True, text=True, timeout=60)
    return r.stdout.strip().splitlines()[-1] if r.stdout \
        else 'NO-OUTPUT'


def body_text(path):
    """extract the def block from a candidate file (skip header
    comments the agents may have added)"""
    lines = open(path, 'r', encoding='utf-8',
                 errors='replace').read().splitlines()
    out = []
    started = False
    for line in lines:
        if not started and (line.startswith('def ')
                            or line.startswith('async def ')):
            started = True
        if started:
            out.append(line)
    return '\n'.join(out)


def replace_section(target_path, name, line, new_body):
    with open(target_path, 'r', encoding='utf-8',
              errors='replace') as f:
        lines = f.read().splitlines()
    out = []
    i = 0
    replaced = False
    while i < len(lines):
        line_s = lines[i]
        m = HEADER_PAT.match(line_s.strip())
        if m and (m.group(1), int(m.group(2))) == (name, line) \
                and not replaced:
            out.append(line_s)
            i += 1
            if i < len(lines) and RULER_PAT.match(lines[i].strip()):
                out.append(lines[i])
                i += 1
            j = i
            while j < len(lines):
                if RULER_PAT.match(lines[j].strip()):
                    nxt = lines[j + 1] if j + 1 < len(lines) else ''
                    if HEADER_PAT.match(nxt.strip()) or \
                            nxt.strip().startswith(
                                '# PENDING UNITS'):
                        break
                if lines[j].strip().startswith('# PENDING UNITS'):
                    break
                j += 1
            for b in new_body.splitlines():
                out.append(b)
            replaced = True
            i = j
            continue
        out.append(line_s)
        i += 1
    if replaced:
        with open(target_path, 'w',
                  encoding='ascii',
                  errors='backslashreplace') as f:
            f.write('\n'.join(out) + '\n')
    return replaced


def main():
    shipped = []
    skipped = []
    for p in sorted(glob.glob(os.path.join(FIXDIR, '*.py'))):
        key = unit_from_filename(os.path.basename(p))
        if key is None:
            continue
        name, line = key
        verdict = verify(name, line, p)
        if verdict == 'VERDICT IDENTICAL':
            body = body_text(p)
            r1 = replace_section(NIGHTY, name, line, body)
            r2 = replace_section(BASE, name, line, body)
            if r1 or r2:
                shipped.append((name, line, p))
                print('SHIPPED %-34s L%-6d (py=%s base=%s)'
                      % (name, line, r1, r2))
            else:
                skipped.append((name, line, 'section not found'))
                print('SECTION-MISS %-30s L%d' % (name, line))
        else:
            skipped.append((name, line, verdict))
            print('SKIP %-38s L%-6d %s' % (name, line, verdict))
    print()
    print('shipped: %d skipped: %d' % (len(shipped), len(skipped)))


if __name__ == '__main__':
    main()
