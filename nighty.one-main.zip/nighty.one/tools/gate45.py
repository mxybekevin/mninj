# gate45.py - THE VM BYTE GATE v2. Compile each src_L*.py,
# vmize, compare vs live stream. Tolerates: const-arg decoys,
# armor decoy triplets (0xf4-call + LOAD_FAST + LOAD_ATTR),
# opcode equivalence classes. Jump args compared by target op.
import glob
import opcode as _op
import os
import re
import types as _t

WAVE = r'C:\Users\brian\Downloads\Nighty\oracle\out\wave45'

STD2VM = {}
for k, v in {
    0x6a: 0xc6, 0xa0: 0x76, 0xa1: 0xf8, 0x01: 0x10,
    0x53: 0x23, 0x44: 0x41, 0x6b: 0x87, 0x17: 0x12,
    0x5f: 0xe5, 0x88: 0xbc, 0x6e: 0xf1, 0x67: 0x8d,
    0x38: 0x0c,
}.items():
    STD2VM[k] = v

EQV = {
    0x7c: {0x7c, 0xc8}, 0xc8: {0x7c, 0xc8},
    0x83: {0x83, 0xf4}, 0xf4: {0x83, 0xf4},
    0xa0: {0xa0, 0x76, 0xc9}, 0x76: {0xa0, 0x76, 0xc9},
    0xc9: {0xa0, 0x76, 0xc9},
    0x67: {0x67, 0x8d, 0xce, 0xea, 0xb1},
    0x8d: {0x67, 0x8d, 0xce, 0xea, 0xb1},
    0xce: {0x67, 0x8d, 0xce, 0xea, 0xb1},
    0xea: {0x67, 0x8d, 0xce, 0xea, 0xb1},
    0xb1: {0x67, 0x8d, 0xce, 0xea, 0xb1},
    0x5f: {0x5f, 0xe5, 0xc4}, 0xe5: {0x5f, 0xe5, 0xc4},
    0xc4: {0x5f, 0xe5, 0xc4},
    0x66: {0x66, 0xc9},
    0x47: {0x47, 0x54}, 0x54: {0x47, 0x54},
    0x18: {0x18, 0x4c}, 0x4c: {0x18, 0x4c},
    0x6a: {0x6a, 0xc6}, 0xc6: {0x6a, 0xc6},
    0x9b: {0x9b, 0xf6}, 0xf6: {0x9b, 0xf6},
    0x9d: {0x9d, 0xea},
}


def compile_src(path):
    src = open(path, encoding='ascii',
               errors='replace').read()
    co = compile(src, '<g>', 'exec')
    for k in co.co_consts:
        if isinstance(k, _t.CodeType):
            return k
    return None


def vmize(std):
    out = []
    i = 0
    ext = 0
    while i < len(std):
        o, a = std[i], std[i + 1]
        if o == 0x90:
            ext = (ext << 8) | a
            i += 2
            continue
        ea = (ext << 8) | a
        ext = 0
        vo = STD2VM.get(o, o)
        out.append((vo, ea,
                    o in _op.hasjrel or o in _op.hasjabs))
        i += 2
    return out


def parse_vm(stream):
    out = []
    i = 0
    while i < len(stream):
        o, a = stream[i], stream[i + 1]
        out.append((o, a, o in _op.hasjrel
                    or o in _op.hasjabs))
        i += 2
    return out


for f in sorted(glob.glob(os.path.join(WAVE, 'src_L*.py'))):
    m = re.match(r'src_L(\d+)', os.path.basename(f))
    ln = int(m.group(1))
    sp = os.path.join(WAVE, 'live_L%d.stream' % ln)
    if not os.path.exists(sp):
        print('L%-6d no live stream (skip gate)' % ln)
        continue
    stream = open(sp, 'rb').read()
    co = compile_src(f)
    if co is None:
        print('L%-6d compile: no function found' % ln)
        continue
    mine = vmize(co.co_code)
    theirs = parse_vm(stream)
    match = total = 0
    bad = []
    ti = mi = 0
    while mi < len(mine) and ti < len(theirs):
        mo, ma, mj = mine[mi]
        to, ta, tj = theirs[ti]
        if to == 0xf4 and ti + 2 < len(theirs):
            n1 = theirs[ti + 1][0]
            n2 = theirs[ti + 2][0]
            if n1 in EQV.get(0x7c, set()) and \
                    n2 in EQV.get(0x6a, set()):
                ti += 3
                continue
        total += 1
        ok = (to in EQV.get(mo, {mo}))
        if ok and not mj and mo != 0x64:
            ok = (ma == ta)
        if ok:
            match += 1
        elif len(bad) < 4:
            bad.append((mi, 'mine %02x/%d theirs %02x/%d'
                        % (mo, ma, to, ta)))
        mi += 1
        ti += 1
    pct = match * 100 // max(1, total)
    print('L%-6d %3d%%  %d/%d instr%s'
          % (ln, pct, match, total,
             '' if len(mine) == len(theirs)
             else '  LEN mine=%d theirs=%d'
             % (len(mine), len(theirs))))
    for b in bad:
        print('        at %d: %s' % b)
