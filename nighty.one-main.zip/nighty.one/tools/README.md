# Recovery Tools

The tooling that reversed PyArmor super mode and rebuilt Nighty from ciphertext.

## Key Tools

| Tool | What it does |
|------|-------------|
| `decryptor46.py` | Offline decryption of all 3 cipher tiers (AES-128-CTR, wordloop6, XOR24) |
| `gate45.py` | Byte-exact VM opcode verification gate |
| `ship45.py` | Ships verified sources into the deliverable |
| `vmtranslate45.py` | VM -> standard py38 opcode translation |
| `rebuild46d.py` | Rebuilds the readable Nighty_source.py from shipped sections |
| `audit_v3.py` | Grades all 771 sections by evidence class |
| `hook45b.js` | Frida hook: plaintext capture at armor decrypt-return |
| `hook47i.js` | Frida hook: raw heap scanner for auth endpoint discovery |
| `hook49.js` | Frida hook: delayed SSL/heap capture (mature process) |
| `netprobe46.py` | Boots the original in our Python with network patches |
| `bootfix46.py` | Boot-loop crash capturer for the rebuild |

## Fence45 Evidence

Contains the captured cipher keys, stream bank index, and decoded envelopes used by the tools.

*Credits: Byte X / gang.baby*
