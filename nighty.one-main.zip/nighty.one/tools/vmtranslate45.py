# vmtranslate45.py - VM->standard py38 translation + decompyle3
# mass decompile + the byte-equality verification gate.
# VM map: same-opcodes stay; remapped ones substituted back.
import glob
import json
import marshal
import os
import struct
import types as _t
import opcode as _op

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out', 'vm45')
os.makedirs(OUT, exist_ok=True)

# custom-VM opcode -> standard py38 opcode
VM2STD = {
    0xc6: 0x6a,   # LOAD_ATTR
    0x76: 0xa0,   # LOAD_METHOD
    0xf8: 0xa1,   # CALL_METHOD
    0x10: 0x01,   # POP_TOP
    0x23: 0x53,   # RETURN_VALUE
    0x41: 0x44,   # GET_ITER
    0x87: 0x6b,   # COMPARE_OP
    0x12: 0x17,   # BINARY_ADD
    0x0e: 0x37,   # INPLACE_ADD (guess)
    0xe5: 0x5f,   # STORE_ATTR
    0xbc: 0x88,   # LOAD_DEREF
    0xf1: 0x6e,   # JUMP_FORWARD
    0x8d: 0x67,   # BUILD_LIST
    0xc8: 0x7c,   # LOAD_FAST (armor-wrapped self access, arg kept)
    0xc9: 0xa0,   # LOAD_METHOD variant (rare)
    0xb1: 0x09,   # NOP-ish
    0x00: 0x09,   # NOP-ish
    0xf4: 0x83,   # CALL_FUNCTION variant
    0xce: 0x67,   # BUILD_LIST variant
    0xea: 0x67,   # BUILD_LIST variant
    0xc4: 0x5f,   # STORE_ATTR variant
    0xe6: 0x5c,   # STORE_SUBSCR
    0xad: 0x50,   # DELETE_ATTR? rare
    0x29: 0x09,   # NOP-ish
    0xf6: 0x09,   # NOP-ish
    0x14: 0x14,   # same
}

VALID = {i for i, nm in enumerate(_op.opname)
         if not nm.startswith('<')}


def translate(stream):
    out = bytearray()
    unknown = []
    i = 0
    ext = 0
    pairs = []
    for i in range(0, len(stream) - 1, 2):
        pairs.append((stream[i], stream[i + 1]))
    for o, a in pairs:
        if o == 0x90:  # EXTENDED_ARG same
            out += bytes((o, a))
            continue
        std = VM2STD.get(o, o if o in VALID else None)
        if std is None:
            unknown.append(o)
            std = 0x09  # NOP placeholder
        out += bytes((std, a))
    return bytes(out), unknown


# gather stamps for metadata
census = {}
for p in glob.glob(os.path.join(ORACLE, 'out', 'v5',
                                'v5_*.marshal')):
    try:
        t = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if isinstance(t, _t.CodeType):
        st = [t]
        while st:
            c = st.pop()
            for k in c.co_consts:
                if isinstance(k, _t.CodeType):
                    st.append(k)
            if c.co_name != '<module>':
                census.setdefault((c.co_firstlineno, c.co_name), c)

from collections import Counter
unk_all = Counter()
report = []
for f in sorted(glob.glob(os.path.join(
        ORACLE, 'out', 'wave45', 'live_L*.stream'))):
    import re
    m = re.match(r'live_L(\d+)', os.path.basename(f))
    if not m:
        continue
    ln = int(m.group(1))
    stream = open(f, 'rb').read()
    std, unk = translate(stream)
    for u in unk:
        unk_all[u] += 1
    # find stamp meta
    cands = [(k, v) for k, v in census.items() if k[0] == ln]
    meta = cands[0][1] if cands else None
    # strict check
    ok = True
    i = 0
    ext = 0
    mxf = mxn = mxc = -1
    rets = 0
    while i < len(std):
        o = std[i]
        if o not in VALID:
            ok = False
            break
        a = std[i + 1]
        nm = _op.opname[o]
        if nm == 'EXTENDED_ARG':
            ext = (ext << 8) | a
            i += 2
            continue
        ea = (ext << 8) | a
        ext = 0
        if meta:
            if nm in ('LOAD_FAST', 'STORE_FAST') and \
                    ea >= len(meta.co_varnames):
                ok = False
                break
            if nm in ('LOAD_GLOBAL', 'LOAD_ATTR', 'LOAD_METHOD',
                      'STORE_ATTR') and ea >= len(meta.co_names):
                ok = False
                break
        if o in _op.hasjrel:
            t2 = i + 2 + ea
            if not (0 <= t2 < len(std)) or t2 % 2:
                ok = False
                break
        elif o in _op.hasjabs:
            if not (0 <= ea < len(std)) or ea % 2:
                ok = False
                break
        if nm == 'RETURN_VALUE':
            rets += 1
        i += 2
    report.append((ln, len(stream), len(std), ok,
                   std[-2:] == b'\x53\x00', rets,
                   sorted(set(unk))))
    if ok:
        fn = os.path.join(OUT, 'std_L%d.pyc.bin' % ln)
        open(fn, 'wb').write(std)
        if meta:
            try:
                code = meta.replace(co_code=std)
                marshal.dump(code, open(os.path.join(
                    OUT, 'code_L%d.mshal' % ln), 'wb'))
            except Exception as e:
                pass

print('%-6s %-6s %-6s %-6s %-6s %s'
      % ('line', 'vmlen', 'stdlen', 'valid', 'ret', 'unknowns'))
for ln, vl, sl, ok, endret, rets, unk in report:
    print('%-6d %-6d %-6d %-6s %-6s %s'
          % (ln, vl, sl, ok, '%s/%d' % (endret, rets),
             [hex(u) for u in unk]))
print()
print('unknown histogram:', dict(unk_all))
