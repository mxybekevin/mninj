"""fence_target32.py - v11: THE TARGETED CALL-AND-SNIFF SESSION.
fence31 proved the armor model at scale: 48 units ARMED-at-rest in the
live function objects, decrypt-at-call to scratch only. The earlier
stream passes missed most of them because matching keyed on the AT-REST
STAMP LENGTHS; real bodies run at their own true lengths.

This session: harvest the armed function objects (fingerprint match),
force-call each in a loop (the decrypt happens in the call machinery
before argument validation; garbage args raise harmlessly after), and
concurrently sample fast for valid-opcode runs - validating runs
LENGTH-FREE against each unit's real metadata bounds, byte-keyed so
real bodies recur identically across calls. ReadProcessMemory on SELF
only; the license stays reseeded; no other process is touched.
"""
import ctypes
import glob
import json
import marshal
import os
import struct
import sys
import threading
import time
import types as _t

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
RTP = os.path.join(OUT, 'fence32')
STREAM = os.path.join(RTP, 'fence32_stream.bin')
os.makedirs(RTP, exist_ok=True)
EXTRACT = r'C:\Users\brian\Downloads\Nighty\Nighty.exe_extracted'
PYZ_EXT = os.path.join(EXTRACT, 'PYZ.pyz_extracted')
V5D = os.path.join(OUT, 'v5')

sys.path.insert(0, HERE)
from spp_fake import make_fake_module

import opcode
VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}
NAME_OPS = {'LOAD_GLOBAL', 'STORE_GLOBAL', 'LOAD_NAME', 'STORE_NAME',
            'DELETE_NAME', 'LOAD_ATTR', 'STORE_ATTR', 'IMPORT_NAME',
            'IMPORT_FROM', 'LOAD_METHOD'}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)

k32 = ctypes.WinDLL('kernel32')
T0 = time.time()
LOGH = open(os.path.join(RTP, 'fence32_session.log'), 'w', 1)


def log(m):
    LOGH.write('%s\n' % m)


census = json.load(open(os.path.join(OUT, 'pending_census.json')))
work = [(e['name'], e['line'], e['size'], k)
        for k in ('ARMED', 'OTHER')
        for e in census[k]]
WORK_KEYS = {(n, l) for n, l, _, _ in work}
log('worklist: %d' % len(work))


def fp(co):
    return ('V:' + repr(tuple(co.co_varnames)) +
            '|N:' + repr(tuple(co.co_names)))


UNIT_FP = {}
META = {}
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        co = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(co, _t.CodeType):
        continue
    stack = [co]
    while stack:
        c = stack.pop()
        key = (str(c.co_name), c.co_firstlineno)
        if key in WORK_KEYS:
            UNIT_FP[fp(c)] = key
            META[key] = c
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                stack.append(k)
log('fingerprint table: %d' % len(UNIT_FP))

# in-session validators keyed by unit; length-FREE.
# bounds: names/varnames/consts from the unit's real metadata.


def make_validator(key):
    co = META[key]
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())

    def check(run):
        L = len(run)
        for i in range(0, L, 2):
            op = run[i]
            if op not in VALID:
                return False
            # sample-check only the first 64 instructions for speed
            if i >= 128:
                break
            arg = run[i + 1] if i + 1 < L else 0
            nm = opcode.opname[op]
            if op < opcode.HAVE_ARGUMENT and arg != 0:
                return False
            if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and \
                    arg >= nloc:
                return False
            if nm in NAME_OPS and arg >= nnames:
                return False
            if nm == 'LOAD_CONST' and arg >= nconst:
                return False
        return True
    return check


VALIDATORS = {key: make_validator(key) for key in META}
GOT = {}          # key -> {bytes: count}
DIE = [False]


def record_run(run):
    if len(run) < 24 or len(run) > 8192:
        return
    for key, check in VALIDATORS.items():
        try:
            if check(run):
                b = bytes(run)
                d = GOT.setdefault(key, {})
                d[b] = d.get(b, 0) + 1
                if d[b] in (2, 5, 10, 20, 40):
                    log('RECURRENCE %s L%d count=%d len=%d '
                        'head=%s'
                        % (key[0], key[1], d[b], len(b),
                           b[:8].hex()))
        except BaseException:
            pass


class MBI(ctypes.Structure):
    _fields_ = [('BaseAddress', ctypes.c_void_p),
                ('AllocationBase', ctypes.c_void_p),
                ('AllocationProtect', ctypes.c_uint32),
                ('RegionSize', ctypes.c_size_t),
                ('State', ctypes.c_uint32),
                ('Protect', ctypes.c_uint32),
                ('Type', ctypes.c_uint32)]


def walk_regions():
    mbi = MBI()
    addr = 0x10000
    hps = ctypes.c_void_p(k32.GetCurrentProcess())
    while addr < 0x7FFFFFFEFFFF:
        r = k32.VirtualQueryEx(hps, ctypes.c_void_p(addr),
                               ctypes.byref(mbi),
                               ctypes.sizeof(mbi))
        if r == 0:
            break
        if mbi.RegionSize:
            yield (mbi.BaseAddress or addr, mbi.RegionSize,
                   mbi.Protect, mbi.State, mbi.Type)
            addr += mbi.RegionSize
        else:
            addr += 0x1000


def safe_read(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t(0)
    ok = k32.ReadProcessMemory(
        ctypes.c_void_p(k32.GetCurrentProcess()),
        ctypes.c_void_p(addr), buf, size, ctypes.byref(got))
    if not ok or got.value < size:
        return None
    return buf.raw[:size]


ELF_NEEDLE = bytes.fromhex('8b0572740100488d4c24580f11742430')
ANCHOR_VA = 0x931A0
IMG_LEN = 0xafac0


def find_elf_bases():
    bases = set()
    for base, size, prot, state, mtype in walk_regions():
        if state != 0x1000 or mtype == 0x1000000:
            continue
        if not (prot & (0x02 | 0x04 | 0x20 | 0x40)) or (prot & 0x100):
            continue
        if size < 0x2000 or size > 0x1000000:
            continue
        pos = 0
        while pos + len(ELF_NEEDLE) <= size:
            chunk = safe_read(base + pos, min(0x40000, size - pos))
            if not chunk:
                break
            i = chunk.find(ELF_NEEDLE)
            while i >= 0:
                bases.add(base + pos + i - ANCHOR_VA)
                i = chunk.find(ELF_NEEDLE, i + 1)
            pos += 0x40000 if len(chunk) == 0x40000 else len(chunk)
    return bases


STREAM_WROTE = [0]


def sampler(bases):
    f = open(STREAM, 'wb')
    swept = [0]
    while not DIE[0] and time.time() - T0 < 190:
        try:
            for base, size, prot, state, mtype \
                    in walk_regions():
                if state != 0x1000 or mtype == 0x1000000:
                    continue
                if not (prot & (0x02 | 0x04 | 0x20 | 0x40)) or \
                        (prot & 0x100):
                    continue
                if mtype == 0x40000 and size > 0x400000:
                    continue
                if size > 0x1000000:
                    continue
                if any(b - 0x2000 <= base <
                       b + IMG_LEN + 0x2000 for b in bases):
                    continue
                pos = 0
                while pos + 0x800 <= size and \
                        STREAM_WROTE[0] < 800 * 1024 * 1024:
                    chunk = safe_read(base + pos,
                                      min(0x8000, size - pos))
                    if not chunk:
                        break
                    pl = len(chunk) & ~1
                    rpos = 0
                    while rpos < pl - 6:
                        if chunk[rpos] not in VALID:
                            rpos += 2
                            continue
                        q = rpos
                        while q < pl and chunk[q] in VALID:
                            q += 2
                        if q - rpos >= 24:
                            payload = bytes(chunk[rpos:q])
                            head = struct.pack(
                                '<QII', base + pos + rpos,
                                len(payload),
                                int(time.time() * 1000) & 0xFFFFFF)
                            f.write(head + payload)
                            STREAM_WROTE[0] += len(payload) + 16
                            record_run(chunk[rpos:q])
                        rpos = q if q > rpos else rpos + 2
                    pos += 0x8000
            swept[0] += 1
        except BaseException as e:
            log('sampler err %r' % (e,))
        time.sleep(0.02)
    try:
        f.flush()
        f.close()
    except Exception:
        pass
    log('sampler: sweeps=%d bytes=%d' % (swept[0],
                                         STREAM_WROTE[0]))


def harvest_caller():
    time.sleep(35)
    import gc
    seen = set()
    objs = {}

    def try_fn(o):
        try:
            if not isinstance(o, _t.FunctionType):
                return
            oid = id(o)
            if oid in seen:
                return
            seen.add(oid)
            co = o.__code__
            key = UNIT_FP.get(fp(co))
            if key is None:
                key = (str(co.co_name), co.co_firstlineno)
                if key not in WORK_KEYS:
                    return
            if key in objs:
                return
            objs[key] = o
        except BaseException:
            return

    app_dicts = {}

    def note_globals(v):
        try:
            app_dicts[id(v.__globals__)] = v.__globals__
        except BaseException:
            pass

    try:
        for o in gc.get_objects():
            try:
                if isinstance(o, type):
                    for v in list(vars(o).values()):
                        if isinstance(v, _t.FunctionType):
                            try_fn(v)
                            note_globals(v)
                elif hasattr(o, '__dict__'):
                    for v in list(o.__dict__.values()):
                        if isinstance(v, _t.FunctionType):
                            try_fn(v)
                            note_globals(v)
            except BaseException:
                continue
    except BaseException as e:
        log('gc err %r' % (e,))
    for m in list(sys.modules.values()):
        try:
            for v in list(m.__dict__.values()):
                if isinstance(v, _t.FunctionType):
                    try_fn(v)
                    note_globals(v)
        except BaseException:
            continue
    for d in list(app_dicts.values()):
        try:
            for v in list(d.values()):
                if isinstance(v, _t.FunctionType):
                    try_fn(v)
        except BaseException:
            continue
    log('harvest: %d objects' % len(objs))
    # force-call loop: repeated calls -> scratch decrypt -> sampler sees
    keys = sorted(objs)
    for rounds in range(12):
        for key in keys:
            o = objs[key]
            for args in ((), (None,), (None, None),
                         (None, None, None)):
                try:
                    if args:
                        o(*args)
                    else:
                        o()
                except BaseException:
                    pass
        time.sleep(0.2)
    log('calls done')
    # final standings
    for key in keys:
        d = GOT.get(key)
        if d:
            best = max(d.items(), key=lambda kv: kv[1])
            log('FINAL %s L%d best_count=%d len=%d head=%s'
                % (key[0], key[1], best[1], len(best[0]),
                   best[0][:8].hex()))
        else:
            log('FINAL %s L%d none' % (key[0], key[1]))
    DIE[0] = True


def killer():
    time.sleep(260)
    log('killer exit')
    LOGH.flush()
    os._exit(0)


threading.Thread(target=killer, daemon=True).start()
bases = find_elf_bases()
log('spp bases: %s' % [hex(b) for b in bases])
threading.Thread(target=sampler, args=(bases,), daemon=True).start()
threading.Thread(target=harvest_caller, daemon=True).start()

os.environ['TCL_LIBRARY'] = os.path.join(PYZ_EXT, '_tcl_data')
os.environ['TK_LIBRARY'] = os.path.join(PYZ_EXT, '_tk_data')
sys.path.insert(1, EXTRACT)
sys.path.append(PYZ_EXT)
sys.path.append(os.path.join(EXTRACT, 'win32'))
sys.path.append(os.path.join(PYZ_EXT, 'win32'))
sys.path.append(os.path.join(HERE, 'py38_extra'))
make_fake_module('spp_export_api')

with open(os.path.join(HERE, 'Nighty.pyc'), 'rb') as f:
    raw = f.read()
bootstrap = marshal.loads(raw[16:])
GNS = {'__name__': '__main__',
       '__file__': os.path.join(EXTRACT, 'Nighty.pyc'),
       '__builtins__': __builtins__}


def run_exec():
    import asyncio
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        exec(bootstrap, GNS)
    except BaseException as e:
        print('[32] exec ended: %r' % (e,), flush=True)


print('[32] bootstrap exec in worker', flush=True)
t = threading.Thread(target=run_exec, daemon=True)
t.start()
t.join(timeout=250)
print('[32] session closing t=%.1f' % (time.time() - T0), flush=True)
log('session closing')
LOGH.flush()
