# analyze29b.py - fast fence29 after-action: byte-keyed whole-body
# matcher over the scratch stream. The stream records ARE maximal
# valid-opcode runs - the corpus acceptance law is EXACT-LENGTH runs
# recurring byte-identical, so candidates are runs whose length equals
# a target's exact co_code length (no sub-offsets - that law belongs to
# raw window dumps, not run streams).
import collections
import glob
import json
import marshal
import os
import struct
import types

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out')
RTP = os.path.join(OUT, 'fence29')
V5D = os.path.join(OUT, 'v5')

import opcode
VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}
NAME_OPS = {'LOAD_GLOBAL', 'STORE_GLOBAL', 'LOAD_NAME', 'STORE_NAME',
            'DELETE_NAME', 'LOAD_ATTR', 'STORE_ATTR', 'IMPORT_NAME',
            'IMPORT_FROM', 'LOAD_METHOD'}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)

census_path = os.path.join(OUT, 'pending_census.json')
census = json.load(open(census_path))
target_keys = {(e['name'], e['line']) for k in census
               for e in census[k]}
targets = []
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        top = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(top, types.CodeType):
        continue
    stack = [(top, 0)]
    while stack:
        c, d = stack.pop()
        if d > 20:
            continue
        if (str(c.co_name), c.co_firstlineno) in target_keys:
            targets.append((str(c.co_name), c.co_firstlineno, c))
        for k in c.co_consts:
            if isinstance(k, types.CodeType):
                stack.append((k, d + 1))
print('targets: %d' % len(targets))
by_len = collections.defaultdict(list)
for nm, fl, co in targets:
    by_len[len(co.co_code)].append((nm, fl, co))
lens = set(by_len)
print('distinct lengths: %d' % len(lens))


def lnotab_offsets(lnotab):
    offs = {0}
    start = 0
    for i in range(0, len(lnotab or b''), 2):
        start += lnotab[i]
        offs.add(start)
    return offs


OFFS = {co.co_firstlineno: lnotab_offsets(co.co_lnotab or b'')
        for nm, fl, co in targets}


def hard_ok(win, co, L, offs):
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nd = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    for i in range(0, L, 2):
        op = win[i]
        if op not in VALID:
            return False
        arg = win[i + 1] if i + 1 < L else 0
        nm = opcode.opname[op]
        if op < opcode.HAVE_ARGUMENT and arg != 0:
            return False
        if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == 'LOAD_CONST' and arg >= nconst:
            return False
        if nm in ('LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                  'LOAD_CLOSURE') and arg >= nd:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


sp = os.path.join(RTP, 'fence29_stream.bin')
size = os.path.getsize(sp)
print('stream: %d bytes' % size)

cands = collections.defaultdict(collections.Counter)
validated = set()          # (unit, bytes) already verdicted
n = 0
n_rlen = 0
with open(sp, 'rb') as f:
    while True:
        head = f.read(16)
        if len(head) < 16:
            break
        addr, ln_, t_ms = struct.unpack('<QII', head)
        if ln_ == 0 or ln_ > 2 * 1024 * 1024:
            break
        payload = f.read(ln_)
        if len(payload) < ln_:
            break
        n += 1
        if ln_ in lens:
            n_rlen += 1
            run = bytes(payload)
            for nm, fl, co in by_len[ln_]:
                key = (nm, fl, run)
                if key in validated:
                    cands[(nm, fl)][run] += 1
                    continue
                if hard_ok(run, co, ln_, OFFS[fl]):
                    validated.add(key)
                    cands[(nm, fl)][run] += 1
        if n % 500000 == 0:
            print('  %d records...' % n, flush=True)
print('records: %d (exact-length candidates: %d)' % (n, n_rlen))

verdicts = []
for (nm, fl), ctr in sorted(cands.items()):
    best = ctr.most_common(1)[0]
    verdicts.append({'name': nm, 'line': fl, 'len': len(best[0]),
                     'count': best[1], 'distinct': len(ctr),
                     'head': best[0][:8].hex(),
                     'all_counts': [c for _, c in
                                     ctr.most_common(6)]})
    print('%-28s L%-6d distinct=%d counts=%s head=%s'
          % (nm[:28], fl, len(ctr),
             [c for _, c in ctr.most_common(6)],
             best[0][:8].hex()))
with open(os.path.join(RTP, 'analyze29b_report.json'), 'w') as f:
    json.dump(verdicts, f, indent=1)
print('-> analyze29b_report.json')

# bank every recurring candidate (count >= 2) as a recovered co_code
banked = []
for (nm, fl), ctr in cands.items():
    for run, cnt in ctr.most_common():
        if cnt < 2:
            continue
        fn = 'recovered_%s_L%d.bin' % (nm.replace('.', '_'), fl)
        with open(os.path.join(RTP, fn), 'wb') as f:
            f.write(run)
        banked.append((nm, fl, len(run), cnt))
        break
print('recurring byte-identical candidates banked: %d' % len(banked))
for nm, fl, L, cnt in sorted(banked, key=lambda x: x[1]):
    print('   L%-7d %-28s %d B x%d' % (fl, nm[:28], L, cnt))
print('ANALYZE29B DONE')
