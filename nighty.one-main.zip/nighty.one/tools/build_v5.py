"""
build_v4.py - THE definitive rebuild with wordcode-correct validation.

 1. extract runs (wordcode-correct) from hammer+grab
 2. match EVERY armed unit - pkl units AND live-tree units (real lnotab)
 3. rebuild all trees from out/dump/unitA_*.marshal with verified plaintext
 4. decompile each tree (decompyle3 -> uncompyle6 fallback)
 5. assemble Nighty.py v4 (compile-gated; explicit pending tails)
 6. write coverage numbers
"""
import glob
import marshal
import opcode
import os
import pickle
import struct
import subprocess
import types
import importlib.util
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = r"C:\Users\brian\Downloads\Nighty"
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
DUMPD = os.path.join(OUT, "dump")
TMP = os.path.join(OUT, "v5_tmp")
V4D = os.path.join(OUT, "v5")
os.makedirs(TMP, exist_ok=True)
os.makedirs(V4D, exist_ok=True)
FINAL = os.path.join(ROOT, "NightyRecovered", "Nighty.py")

DEC3 = r"C:\Users\brian\Downloads\Nighty\py38\Scripts\decompyle3.exe"
UNC6 = r"C:\Users\brian\Downloads\Nighty\py38\Scripts\uncompyle6.exe"
HEADER = importlib.util.MAGIC_NUMBER + struct.pack("<III", 0, 0, 0)
VALID = {i for i, nm in enumerate(opcode.opname) if not nm.startswith("<")}


def is_armed(code):
    return (len(code) >= 6 and code[0] == 0x74 and
            code[2:4] == b"\x83\x00" and code[4:6] == b"\x09\x00")


def decode_ok(code):
    if len(code) % 2:
        return None
    for i in range(0, len(code), 2):
        if code[i] not in VALID:
            return None
    return True


def lnotab_offsets(lnotab):
    offs = {0}
    start = 0
    try:
        for i in range(0, len(lnotab), 2):
            start += lnotab[i]
            offs.add(start)
    except Exception:
        return None
    return offs


# ------------------------------------------------ 1. extract runs (COUNTED)
def extract_runs():
    """Counter(bytes) - frequency matters: a unit's TRUE plaintext is
    decrypted+restored in EVERY session, junk fragments appear once."""
    import collections
    runs = collections.Counter()
    for name in ("hammer_stream.bin", "grab_stream.bin"):
        p = os.path.join(SNAPS, name)
        if not os.path.exists(p):
            continue
        n = 0
        with open(p, "rb") as f:
            while True:
                head = f.read(16)
                if len(head) < 16:
                    break
                addr, ln_, t_ms = struct.unpack("<QII", head)
                if ln_ == 0 or ln_ > 2 * 1024 * 1024:
                    break
                payload = f.read(ln_)
                if len(payload) < ln_:
                    break
                n += 1
                for parity in (0, 1):
                    pos = parity
                    pl = len(payload) & ~1
                    while pos < pl - 6:
                        if payload[pos] not in VALID:
                            pos += 2
                            continue
                        q = pos
                        while q < pl and payload[q] in VALID:
                            q += 2
                        length = q - pos
                        if 16 <= length <= 8192:
                            runs[bytes(payload[pos:q])] += 1
                        pos = q if q > pos else pos + 2
        print("  %s: %d records" % (name, n), flush=True)
    for wm in ("windows.marshal", "windows_run1.marshal"):
        p = os.path.join(SNAPS, wm)
        if not os.path.exists(p):
            continue
        try:
            obj = marshal.loads(open(p, "rb").read())
        except Exception:
            continue
        for key, val in obj.items():
            if isinstance(val, dict) and "versions" in val:
                for t, b in val["versions"]:
                    for parity in (0, 1):
                        pos = parity
                        pl = len(b) & ~1
                        while pos < pl - 6:
                            if b[pos] not in VALID:
                                pos += 2
                                continue
                            q = pos
                            while q < pl and b[q] in VALID:
                                q += 2
                            length = q - pos
                            if 16 <= length <= 8192:
                                runs[bytes(b[pos:q])] += 1
                            pos = q if q > pos else pos + 2
    print("unique runs: %d (max count %d)" % (
        len(runs), max(runs.values()) if runs else 0), flush=True)
    return runs


# ------------------------------------------------ 2. collect all armed units
def collect_armed_units():
    """every distinct armed code unit across live trees."""
    seen = {}
    loaded = []
    for p in sorted(glob.glob(os.path.join(DUMPD, "unitA_*.marshal"))):
        try:
            co = marshal.load(open(p, "rb"))
        except Exception:
            continue
        if not isinstance(co, types.CodeType):
            continue
        stack = [co]
        while stack:
            c = stack.pop()
            loaded.append(c)
            if is_armed(c.co_code):
                key = bytes(c.co_code)
                if key not in seen:
                    seen[key] = c
            for x in c.co_consts:
                if isinstance(x, types.CodeType):
                    stack.append(x)
    units = list(seen.values())
    print("distinct armed units (live trees): %d" % len(units))
    return units


LOCAL_OPS = {"LOAD_FAST", "STORE_FAST", "DELETE_FAST"}
NAME_OPS = {"LOAD_GLOBAL", "STORE_GLOBAL", "LOAD_NAME", "STORE_NAME",
            "DELETE_NAME", "LOAD_ATTR", "STORE_ATTR", "IMPORT_NAME",
            "LOAD_METHOD", "IMPORT_FROM"}
CONST_OPS = {"LOAD_CONST"}
DEREF_OPS = {"LOAD_DEREF", "STORE_DEREF", "DELETE_DEREF"}


def operand_legal(r, co):
    """Wordcode-correct operand legality for candidate plaintext r
    against unit metadata. Catches same-length junk matches."""
    n = len(r)
    nlocals = len(co.co_varnames)
    nnames = len(co.co_names)
    nconsts = len(co.co_consts)
    nderef = len(co.co_freevars) + len(co.co_cellvars)
    jrel = set(opcode.hasjrel)
    jabs = set(opcode.hasjabs)
    for i in range(0, n, 2):
        op = r[i]
        arg = r[i + 1]
        nm = opcode.opname[op]
        if nm in LOCAL_OPS and arg >= nlocals:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm in CONST_OPS and arg >= nconsts:
            return False
        if nm in DEREF_OPS and arg >= nderef:
            return False
        if nm == "LOAD_CLOSURE" and arg >= nderef:
            return False
        if op in jrel:
            t = i + 2 + arg
            if not (0 <= t < n) or t % 2:
                return False
        if op in jabs:
            if not (0 <= arg < n) or arg % 2:
                return False
    return True


def full_validate(cand, co):
    """THE strict gate (wordcode semantics):
      1. every 2-byte slot = valid opcode
      2. every lnotab offset lands on an instruction slot (even, < len)
      3. operand legality vs the unit's real metadata
    Returns True if the candidate is a plausible TRUE body."""
    L = len(cand)
    if L % 2:
        return False
    for i in range(0, L, 2):
        if cand[i] not in VALID:
            return False
    offs = lnotab_offsets(co.co_lnotab or b"")
    if offs is not None:
        for o in offs:
            if o >= L or o % 2:
                return False
    return operand_legal(cand, co)


def merge_pkl_matches(matched, units, runs):
    """wordcode_matches.pkl = strict matches keyed by the EXE-EMBEDDED armed
    bytes (nighty_units.pkl). Live-tree armed buffers can differ; the
    plaintext VALUES still apply if they validate against the live unit."""
    pk = os.path.join(OUT, "wordcode_matches.pkl")
    if not os.path.exists(pk):
        print("  (no pkl matches to merge)")
        return matched
    with open(pk, "rb") as f:
        pkl_matched = pickle.load(f)
    n_merged = 0
    unmatched = [u for u in units if bytes(u.co_code) not in matched]
    for plaintext in set(map(bytes, pkl_matched.values())):
        L = len(plaintext)
        for u in unmatched:
            if len(u.co_code) != L:
                continue
            if full_validate(plaintext, u):
                matched[bytes(u.co_code)] = plaintext
                n_merged += 1
                unmatched = [x for x in unmatched if bytes(x.co_code) != bytes(u.co_code)]
                break
    print("pkl-merge: +%d (total %d)" % (n_merged, len(matched)), flush=True)
    return matched


def match_units(units, runs):
    """Exact-length + strict validation; winner by CAPTURE COUNT.
    A unit's true body is decrypted in every session -> high count.
    Cross-unit junk of coincidental length -> count 1-2."""
    runs_by_len = {}
    for r, cnt in runs.items():
        runs_by_len.setdefault(len(r), []).append((r, cnt))
    matched = {}
    n_hit = 0
    misses = []
    for u in units:
        code = bytes(u.co_code)
        L = len(code)
        best = None
        best_cnt = -1
        for r, cnt in runs_by_len.get(L, ()):
            if cnt <= best_cnt:
                continue
            if full_validate(r, u):
                best = r
                best_cnt = cnt
        if best is not None:
            matched[code] = best
            n_hit += 1
        else:
            misses.append("%s L%d len=%d cands=%d" % (
                str(u.co_name)[:36], u.co_firstlineno, L, len(runs_by_len.get(L, ()))))
    print("live armed matched: %d / %d" % (n_hit, len(units)), flush=True)
    for m in misses[:20]:
        print("  MISS %s" % m)
    return matched


# ------------------------------------------------ 3. rebuild trees
def rebuild_tree(co, matched, depth=0):
    """Rebuild a tree replacing every ARMED code unit (at any depth) with
    its verified plaintext match. Recurses ALWAYS - plain-restored parents
    can carry armed children."""
    if depth > 40:
        return co
    armed = is_armed(co.co_code)
    if armed:
        new_code = matched.get(bytes(co.co_code), co.co_code)
    else:
        new_code = co.co_code
    consts = tuple(rebuild_tree(c, matched, depth + 1)
                   if isinstance(c, types.CodeType) else c
                   for c in co.co_consts)
    if new_code is co.co_code or bytes(new_code) == bytes(co.co_code):
        if consts == co.co_consts:
            return co
    return types.CodeType(co.co_argcount, co.co_posonlyargcount,
                          co.co_kwonlyargcount, co.co_nlocals,
                          co.co_stacksize, co.co_flags,
                          new_code, consts, co.co_names, co.co_varnames,
                          co.co_filename, co.co_name, co.co_firstlineno,
                          bytes(co.co_lnotab or b""),
                          co.co_freevars, co.co_cellvars)


# ------------------------------------------------ 4. decompile
def strip_headers(txt):
    return "\n".join(ln for ln in txt.splitlines()
                     if not ln.startswith("# decompyle3")
                     and not ln.startswith("# uncompyle6")
                     and not ln.startswith("# Python bytecode")
                     and not ln.startswith("# Decompiled from")
                     and not ln.startswith("# Embedded file name")).strip()


def decompile_units(co, key):
    fn = os.path.join(TMP, "u%s.pyc" % key)
    with open(fn, "wb") as f:
        f.write(HEADER)
        marshal.dump(co, f)
    outp = fn[:-4] + ".py"
    tmo = 40 if len(co.co_code) < 600 else 90
    for tool in (DEC3, UNC6):
        try:
            subprocess.run([tool, "-o", TMP, fn], capture_output=True, timeout=tmo)
        except Exception:
            continue
        if os.path.exists(outp):
            try:
                txt = open(outp, encoding="utf-8", errors="replace").read()
                os.remove(outp)
            except Exception:
                continue
            body = strip_headers(txt)
            if body:
                try:
                    os.remove(fn)
                except OSError:
                    pass
                return body
    try:
        os.remove(fn)
    except OSError:
        pass
    return None


# ------------------------------------------------ 5. assemble
def safe_ident(name):
    name = re.sub(r"[^0-9a-zA-Z_]", "_", str(name))
    if not name or name[0].isdigit():
        name = "_" + name
    return name


def indented(txt, n=4):
    pad = " " * n
    return "\n".join(pad + ln if ln.strip() else ln for ln in txt.splitlines())


def repair_block(block):
    block = block.replace("(`{t}` for", "(\"\x60{t}\x60\" for")
    return block


def main():
    runs = extract_runs()
    units = collect_armed_units()
    matched = match_units(units, runs)
    matched = merge_pkl_matches(matched, units, runs)

    # decompile every distinct top-level tree (armed AND plain-restored)
    entries = []
    seen_keys = set()
    idx = 0
    for p in sorted(glob.glob(os.path.join(DUMPD, "unitA_*.marshal"))):
        try:
            co = marshal.load(open(p, "rb"))
        except Exception:
            continue
        if not isinstance(co, types.CodeType):
            continue
        key = (co.co_name, co.co_firstlineno, len(co.co_code))
        if key in seen_keys:
            continue
        seen_keys.add(key)
        try:
            newco = rebuild_tree(co, matched)
        except Exception:
            newco = co
        fnm = "v5_%s_L%d.marshal" % (re.sub(r"[^0-9a-zA-Z_]", "_", str(co.co_name)), co.co_firstlineno)
        try:
            with open(os.path.join(V4D, fnm), "wb") as f:
                marshal.dump(newco, f)
        except Exception:
            pass
        src = decompile_units(newco, "a%d" % idx)
        orig_armed = is_armed(co.co_code)
        got_plain = orig_armed and bytes(co.co_code) in matched
        if src:
            st = "OK"
        elif orig_armed and not got_plain:
            st = "ARMED"          # no verified plaintext exists
        else:
            st = "EMPTY"          # plaintext present/never armed, decompilers failed
        entries.append((co.co_firstlineno, src, co, st, p))
        idx += 1
    print("top-level trees: %d | with source %d | armed %d | empty %d" % (
        len(entries),
        sum(1 for e in entries if e[3] == "OK"),
        sum(1 for e in entries if e[3] == "ARMED"),
        sum(1 for e in entries if e[3] == "EMPTY")), flush=True)

    # dedupe by (name, firstlineno, len)
    uniq = {}
    for fl, src, co, st, p in entries:
        key = (co.co_name, co.co_firstlineno, len(co.co_code))
        prev = uniq.get(key)
        if prev is None or (src and not prev[1]):
            uniq[key] = (fl, src, co, st, p)
    entries = sorted(uniq.values(), key=lambda e: e[0])
    print("unique armed callables: %d (with source %d)" % (
        len(entries), sum(1 for e in entries if e[1])))

    out = []
    out.append('"""')
    out.append("Nighty.py - RECOVERED SOURCE")
    out.append("Python 3.8; recovered from the PyArmor-protected Nighty.exe")
    out.append("Plaintext recovered via wordcode-validated capture matching.")
    out.append('"""\n')

    n_ok = n_armed_still = n_empty = n_review = 0
    pending_names = []
    review_blocks = []
    for fl, src, co, st, p in entries:
        nm = str(co.co_name)
        if not src:
            if is_armed(co.co_code) and bytes(co.co_code) not in matched:
                n_armed_still += 1
                pending_names.append("%s (line %d, %d bytes) [STILL-ARMED - no verified plaintext]" % (
                    nm, fl, len(co.co_code)))
            else:
                n_empty += 1
                pending_names.append("%s (line %d, %d bytes) [NO-BODY - decompilers produced nothing]" % (
                    nm, fl, len(co.co_code)))
            continue
        first = src.splitlines()[0] if src.splitlines() else ""
        if re.match(r"^(async\s+)?def\s+%s\b" % re.escape(nm), first) or \
           re.match(r"^class\s+%s\b" % re.escape(nm), first):
            block = src
            if re.match(r"^def\b", first) and \
                    re.search(r"\bawait\b|\basync\b", src):
                block = "async " + src
        else:
            args = list(co.co_varnames[:co.co_argcount])
            flags = co.co_flags
            if flags & 0x04:
                extra = co.co_varnames[co.co_argcount] if co.co_argcount < len(co.co_varnames) else "args"
                args.append("*" + safe_ident(extra))
            if flags & 0x08:
                args.append("**kwargs")
            is_async = bool(flags & 0x80) or bool(flags & 0x100)
            sig = "%s %s(%s):" % ("async def" if is_async else "def", safe_ident(nm), ", ".join(args))
            if not is_async and re.search(r"\bawait\b", src):
                sig = "async " + sig
            block = sig + "\n" + indented(src)
        block = repair_block(block)
        try:
            compile(block, "<unit>", "exec")
            out.append("#" + "-" * 76)
            out.append("# %s   (original line %d)" % (nm, fl))
            out.append("#" + "-" * 76)
            out.append(block)
            out.append("")
            n_ok += 1
        except Exception:
            n_review += 1
            review_blocks.append((nm, fl, block))

    if review_blocks:
        out.append("")
        out.append("# REVIEW ITEMS (decompiler artifacts, raw kept):")
        for nm, fl, block in review_blocks:
            out.append("# ---- %s (line %d) ----" % (nm, fl))
            for ln in block.splitlines():
                out.append("#    " + ln)
    if pending_names:
        out.append("")
        out.append("# PENDING UNITS (%d still-armed, %d no-body):" % (n_armed_still, n_empty))
        for a in pending_names:
            out.append("#   - %s" % a)

    with open(FINAL, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    print("Nighty.py v4: %d lines | clean %d | review %d | armed %d | empty %d" % (
        len(("\n".join(out)).splitlines()), n_ok, n_review, n_armed_still, n_empty))
    fs = open(FINAL, encoding="utf-8", errors="replace").read()
    try:
        compile(fs, "Nighty.py", "exec")
        print("Nighty.py COMPILES CLEAN")
    except SyntaxError as e:
        print("SyntaxError line %d: %s" % (e.lineno or -1, e.msg))


if __name__ == "__main__":
    main()
