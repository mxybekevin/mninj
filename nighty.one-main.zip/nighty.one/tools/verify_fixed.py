# verify_fixed.py - the strict gate for the fix wave.
#   usage: py38 verify_fixed.py <name> <line> <candidate.py>
# The candidate .py must define the unit (top-level def, matching
# name/argcount). VERDICT IDENTICAL requires:
#   - parent co_code byte-equal to the dec-truth bytes
#   - all nested code objects (lambdas/comps) byte-equal in
#     const-slot order
#   - identical argcount, varnames, names, flags
import dis
import glob
import marshal
import sys
import types as _t

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'


def armed(b):
    return b and len(b) >= 4 and b[0] == 0x74 and b[2:4] == b'\x83\x00'


def dec_truth(name, line):
    best = None
    for p in glob.glob(ORACLE + r'\out\decrypted\dec_*.marshal'):
        try:
            tco = marshal.load(open(p, 'rb'))
        except Exception:
            continue
        st = [tco]
        while st:
            c = st.pop()
            for k in c.co_consts:
                if isinstance(k, _t.CodeType):
                    st.append(k)
            if (str(c.co_name), c.co_firstlineno) == (name, line) \
                    and not armed(c.co_code):
                if best is None or len(c.co_code) > len(best.co_code):
                    best = c
    return best


def nested_ok(cand, truth):
    cn = [k for k in cand.co_consts if isinstance(k, _t.CodeType)]
    tn = [k for k in truth.co_consts if isinstance(k, _t.CodeType)]
    if len(cn) != len(tn):
        return 'nested-count %d vs %d' % (len(cn), len(tn))
    for i, (a, b) in enumerate(zip(cn, tn)):
        if bytes(a.co_code) != bytes(b.co_code):
            return 'nested[%d] %s code differs' % (i, a.co_name)
        if tuple(a.co_varnames) != tuple(b.co_varnames):
            return 'nested[%d] varnames differ' % i
        if tuple(a.co_names) != tuple(b.co_names):
            return 'nested[%d] names differ' % i
        if a.co_argcount != b.co_argcount:
            return 'nested[%d] argcount differs' % i
        sub = nested_ok(a, b)
        if sub:
            return 'nested[%d] %s' % (i, sub)
    return None


def main():
    import os
    name, line, path = sys.argv[1], int(sys.argv[2]), sys.argv[3]
    truth = None
    if len(sys.argv) > 4:
        # explicit truth file (e.g. a frida-built marshal)
        try:
            truth = marshal.load(open(sys.argv[4], 'rb'))
        except Exception as e:
            print('VERDICT TRUTH-LOAD-FAIL %r' % (e,))
            return 2
    else:
        truth = dec_truth(name, line)
    if truth is None:
        print('VERDICT NO-TRUTH')
        return 2
    if not isinstance(truth, _t.CodeType):
        print('VERDICT NO-TRUTH')
        return 2
    src = open(path, 'r', encoding='utf-8', errors='replace').read()
    try:
        mod = compile(src, 'candidate.py', 'exec')
    except BaseException as e:
        print('VERDICT COMPILE-FAIL %r' % (e,))
        return 2
    cands = [c for c in mod.co_consts
             if isinstance(c, _t.CodeType) and str(c.co_name) == name]
    if not cands:
        print('VERDICT NO-FUNCTION named %s' % name)
        return 2
    cand = cands[0]
    if cand.co_argcount != truth.co_argcount:
        print('VERDICT DIFFERS argcount %d vs %d'
              % (cand.co_argcount, truth.co_argcount))
        return 1
    if bytes(cand.co_code) != bytes(truth.co_code):
        ca, cb = bytes(cand.co_code), bytes(truth.co_code)
        d = next((i for i in range(0, min(len(ca), len(cb)), 2)
                  if ca[i:i + 2] != cb[i:i + 2]), None)
        print('VERDICT DIFFERS co_code len %d vs %d; first byte'
              ' delta at %s' % (len(ca), len(cb), d))
        if d is not None:
            ca2, cb2 = ca[d:d + 16], cb[d:d + 16]
            print('  cand bytes: %s' % ca2.hex())
            print('  true bytes: %s' % cb2.hex())
        return 1
    if tuple(cand.co_varnames) != tuple(truth.co_varnames):
        print('VERDICT DIFFERS varnames')
        return 1
    if tuple(cand.co_names) != tuple(truth.co_names):
        print('VERDICT DIFFERS names')
        print('  cand: %r' % (cand.co_names,))
        print('  true: %r' % (truth.co_names,))
        return 1
    if cand.co_flags != (truth.co_flags & ~0x20000000):
        print('VERDICT DIFFERS flags 0x%x vs 0x%x'
              % (cand.co_flags, truth.co_flags))
        return 1
    bad = nested_ok(cand, truth)
    if bad:
        print('VERDICT DIFFERS nested: %s' % bad)
        return 1
    print('VERDICT IDENTICAL')
    return 0


if __name__ == '__main__':
    sys.exit(main())
