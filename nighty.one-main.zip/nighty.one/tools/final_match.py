"""
final_match.py - whole-body matcher over ALL capture streams including the
dedicated sniffer's target stream.

Validations (in order):
  1. exact length == len(unit.co_code)
  2. wordcode decode + operand/jump legality vs the unit's real metadata
  3. lnotab statement offsets land on even in-window slots
  4. real-code profile score/diversity (learned from verified bodies)
Ranking: capture count. Optional stack-walk (fixed for no-arg ops) is
reported as advisory only (linear depth is not a soundness criterion for
control-flow code).
"""
import collections
import glob
import marshal
import math
import opcode
import os
import struct
import types
import dis

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
V5D = os.path.join(OUT, "v5")
FRD = os.path.join(OUT, "fragunit")

VALID = {i for i, nm in enumerate(opcode.opname) if not nm.startswith("<")}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)
NAME_OPS = {"LOAD_GLOBAL", "STORE_GLOBAL", "LOAD_NAME", "STORE_NAME", "DELETE_NAME",
            "LOAD_ATTR", "STORE_ATTR", "IMPORT_NAME", "LOAD_METHOD", "IMPORT_FROM"}


def is_armed(code):
    return (len(code) >= 6 and code[0] == 0x74 and
            code[2:4] == b"\x83\x00" and code[4:6] == b"\x09\x00")


def learn_profile():
    import collections as C
    hist = C.Counter()
    for p in glob.glob(os.path.join(V5D, "v5_*.marshal")):
        try:
            co = marshal.load(open(p, "rb"))
        except Exception:
            continue
        if not isinstance(co, types.CodeType) or is_armed(co.co_code):
            continue
        stack = [(co, 0)]
        while stack:
            c, d = stack.pop()
            if d > 20:
                continue
            hist.update(c.co_code[i] for i in range(0, len(c.co_code) - 1, 2))
            for k in c.co_consts:
                if isinstance(k, types.CodeType):
                    stack.append((k, d + 1))
    total = sum(hist.values())
    return {op: math.log((hist[op] + 0.5) / (total + 0.5 * len(VALID)))
            for op in VALID}


def lnotab_offsets(lnotab):
    offs = {0}
    start = 0
    for i in range(0, len(lnotab), 2):
        start += lnotab[i]
        offs.add(start)
    return offs


def hard_ok(win, co, L, offs):
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nderefc = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    for i in range(0, L, 2):
        op = win[i]
        if op not in VALID:
            return False
        arg = win[i + 1]
        nm = opcode.opname[op]
        if nm in ("LOAD_FAST", "STORE_FAST", "DELETE_FAST") and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == "LOAD_CONST" and arg >= nconst:
            return False
        if nm in ("LOAD_DEREF", "STORE_DEREF", "DELETE_DEREF", "LOAD_CLOSURE") \
                and arg >= nderefc:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


def stack_walk_depth(win, L):
    """advisory: min/max depth over a linear walk; None on ValueError."""
    d = 0
    lo = hi = 0
    for i in range(0, L, 2):
        op = win[i]
        arg = win[i + 1]
        try:
            e = dis.stack_effect(op, arg) if op >= opcode.HAVE_ARGUMENT \
                else dis.stack_effect(op)
        except ValueError:
            return None
        d += e
        lo = min(lo, d)
        hi = max(hi, d)
    return lo, hi, d


def extract_all(minlen_hint):
    runs = collections.Counter()
    streams = ["hammer_stream.bin", "grab_stream.bin"]
    streams += [os.path.basename(p) for p in
                glob.glob(os.path.join(SNAPS, "target_stream_*.bin"))]
    print("streams:", streams)
    for name in streams:
        p = os.path.join(SNAPS, name)
        if not os.path.exists(p):
            continue
        n = 0
        with open(p, "rb") as f:
            while True:
                head = f.read(16)
                if len(head) < 16:
                    break
                addr, ln_, t_ms = struct.unpack("<QII", head)
                if ln_ == 0 or ln_ > 2 * 1024 * 1024:
                    break
                payload = f.read(ln_)
                if len(payload) < ln_:
                    break
                n += 1
                pl = len(payload) & ~1
                for parity in (0, 1):
                    pos = parity
                    while pos < pl - 6:
                        if payload[pos] not in VALID:
                            pos += 2
                            continue
                        q = pos
                        while q < pl and payload[q] in VALID:
                            q += 2
                        length = q - pos
                        if 16 <= length <= 8192:
                            runs[bytes(payload[pos:q])] += 1
                        pos = q if q > pos else pos + 2
        print("  %s: %d records -> %d runs" % (name, n, len(runs)), flush=True)
    return runs


def main():
    logp = learn_profile()

    # every armed-at-rest unit still lacking a body - not just the famous 3
    targets = []
    for p in glob.glob(os.path.join(V5D, "v5_*.marshal")):
        try:
            co = marshal.load(open(p, "rb"))
        except Exception:
            continue
        if isinstance(co, types.CodeType) and is_armed(co.co_code):
            targets.append((str(co.co_name), co.co_firstlineno, co))
    minL = min(len(co.co_code) for _, _, co in targets)
    print("armed targets: %d (min length %d)" % (len(targets), minL))

    runs = extract_all(minL)

    hits = []
    for nm, fl, co in targets:
        L = len(co.co_code)
        offs = lnotab_offsets(co.co_lnotab or b"")
        cands = [(r, c) for r, c in runs.items() if len(r) == L]
        best = None
        best_cnt = -1
        for r, c in cands:
            if hard_ok(r, co, L, offs):
                ops = [r[i] for i in range(0, L, 2)]
                s = sum(logp.get(o, -9.0) for o in ops) / len(ops)
                dv = len(set(ops)) / len(ops)
                if s < -8.245 or dv < 0.06:
                    continue
                dp = stack_walk_depth(r, L)
                if dp is not None and dp[0] < -600:
                    continue
                if c > best_cnt:
                    best_cnt = c
                    best = (r, s, dv, dp)
        if best is not None:
            r, s, dv, dp = best
            hits.append((nm, fl, L, best_cnt, s, dv, dp))
            print("HIT  %-26s L%-6d len=%-5d count=%-5d score=%.2f div=%.2f depth=%s" % (
                nm[:26], fl, L, best_cnt, s, dv, dp))
            fn = os.path.join(FRD, "final_%s_L%d.bin" % (nm.replace('.', '_'), fl))
            with open(fn, "wb") as f:
                f.write(r)
        # else: silent - gathered in the summary
    print()
    print("total new-body hits: %d / %d" % (len(hits), len(targets)))
    with open(os.path.join(FRD, "_final_report.txt"), "w", encoding="utf-8") as f:
        for nm, fl, L, c, s, dv, dp in hits:
            f.write("%s L%d len=%d count=%d\n" % (nm, fl, L, c, ))


if __name__ == "__main__":
    main()
