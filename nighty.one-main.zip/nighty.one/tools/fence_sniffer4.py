"""
fence_sniffer4.py - full-heap version sniffer with on-disk capture.

The pyarmor restore workspace materializes the decrypted module tree in
the python heap (confirmed: docstrings + real 3.8 bytecode in captured
pages). A full-heap sweep from process start captures the plaintext
workspace wholesale.

Capture format (append log heap_stream.bin):
    [u64 addr][u32 len][u32 t_ms][bytes]
Dedup: per address, sha1 of content. Max versions per address: 24.

usage: python fence_sniffer4.py <pid>
"""
import ctypes
import hashlib
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
os.makedirs(SNAPS, exist_ok=True)
STREAM = os.path.join(SNAPS, "heap_stream.bin")
MEM_COMMIT = 0x1000
CHUNK = 0x10000

pid = int(sys.argv[1])
k32 = ctypes.WinDLL("kernel32", use_last_error=True)
h = k32.OpenProcess(0x0010 | 0x0400, False, pid)
if not h:
    print("[-] OpenProcess failed")
    sys.exit(1)
print("[+] target pid %d" % pid)

class MBI(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p),
        ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", ctypes.c_ulong),
        ("RegionSize", ctypes.c_size_t),
        ("State", ctypes.c_ulong),
        ("Protect", ctypes.c_ulong),
        ("Type", ctypes.c_ulong),
    ]

def rpm(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t()
    ok = k32.ReadProcessMemory(h, ctypes.c_void_p(addr), buf,
                               ctypes.c_size_t(size), ctypes.byref(got))
    if not ok:
        return None
    return buf.raw[:got.value]

def regions():
    out = []
    addr = 0
    mbi = MBI()
    while addr < 0x7FFFFFFEFFFF:
        r = k32.VirtualQueryEx(h, ctypes.c_void_p(addr), ctypes.byref(mbi),
                               ctypes.sizeof(mbi))
        if r == 0:
            break
        base = mbi.BaseAddress or addr
        size = mbi.RegionSize
        if mbi.State == MEM_COMMIT and mbi.Protect not in (0x01, 0x100 | 0x01):
            out.append((base, size, mbi.Protect, mbi.Type))
        addr = base + size
        if size == 0:
            break
    return out

seen = {}
max_versions = 24
stream = open(STREAM, "ab", buffering=1024 * 1024)
stats = {"pass": 0, "stored": 0, "bytes": 0, "fails": 0}
t_start = time.time()

def note(addr, content, t_ms):
    if not content:
        return
    dig = hashlib.sha1(content).digest()
    s = seen.get(addr)
    if s is None:
        s = seen[addr] = set()
    if dig in s or len(s) >= max_versions:
        return
    s.add(dig)
    stream.write(struct.pack("<QII", addr, len(content), t_ms))
    stream.write(content)
    stats["stored"] += 1
    stats["bytes"] += len(content)

def sweep_all():
    t0 = time.time()
    t_ms = int((t0 - t_start) * 1000) & 0xFFFFFFFF
    for base, size, prot, rtype in regions():
        if size > 0x80000000:
            continue
        off = 0
        while off < size:
            a = base + off
            data = rpm(a, min(CHUNK, size - off))
            if data is None:
                stats["fails"] += 1
                sub = 0
                while sub < CHUNK and off + sub < size:
                    d = rpm(a + sub, 0x1000)
                    if d is not None:
                        note(a + sub, d, t_ms)
                    sub += 0x1000
            else:
                if len(data) == CHUNK:
                    note(a, data, t_ms)
                else:
                    sub = 0
                    while sub < len(data):
                        note(a + sub, data[sub:sub + 0x1000], t_ms)
                        sub += 0x1000
            off += CHUNK
    stats["pass"] += 1
    return time.time() - t0

alive = ctypes.c_ulong()
last_report = 0.0
while True:
    dt = sweep_all()
    now = time.time()
    if now - last_report >= 3.0:
        print("[%7.2fs] pass#%d pass_ms=%d stored=%d MB=%.1f fails=%d" % (
            now - t_start, stats["pass"], dt * 1000, stats["stored"],
            stats["bytes"] / 1e6, stats["fails"]), flush=True)
        last_report = now
        stream.flush()
    if k32.GetExitCodeProcess(h, ctypes.byref(alive)) and alive.value != 259:
        break

stream.flush()
stream.close()
print("[done] passes=%d stored=%d MB=%.1f" % (
    stats["pass"], stats["stored"], stats["bytes"] / 1e6))
