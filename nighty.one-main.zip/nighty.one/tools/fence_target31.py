"""fence_target31.py - v10: THE FINGERPRINT HARVEST. The armor restore
relabels co_firstlineno on live code objects (proven: setup_logging's
live co_firstlineno is 1348 vs the original 1187), so strict name+line
matching never fires. But co_varnames/co_names are DATA and survive
restoration intact: the at-rest v5 stamp marshals hold the same true
metadata, so live objects are identified by METADATA FINGERPRINT.

Chain: gc containers (classes + instances) -> functions -> their
__globals__ = the hidden app dicts -> full namespace walk. Every
FunctionType found is fingerprinted against the unit table; identified
objects are marshal-dumped. The classifier logs each unit's live state.
"""
import ctypes
import glob
import json
import marshal
import os
import sys
import threading
import time
import types as _t

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
RTP = os.path.join(OUT, 'fence31')
os.makedirs(RTP, exist_ok=True)
EXTRACT = r'C:\Users\brian\Downloads\Nighty\Nighty.exe_extracted'
PYZ_EXT = os.path.join(EXTRACT, 'PYZ.pyz_extracted')
V5D = os.path.join(OUT, 'v5')

sys.path.insert(0, HERE)
from spp_fake import make_fake_module

T0 = time.time()
LOGH = open(os.path.join(RTP, 'fence31_session.log'), 'w', 1)


def log(m):
    LOGH.write('%s\n' % m)


census = json.load(open(os.path.join(OUT, 'pending_census.json')))
work = [(e['name'], e['line'], e['size'], k)
        for k in ('ARMED', 'OTHER')
        for e in census[k]]
WORK_KEYS = {(n, l) for n, l, _, _ in work}
print('[31] worklist: %d units' % len(work), flush=True)
log('worklist: %d' % len(work))


def fp(co):
    return ('V:' + repr(tuple(co.co_varnames)) +
            '|N:' + repr(tuple(co.co_names)))


UNIT_FP = {}
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        co = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(co, _t.CodeType):
        continue
    stack = [co]
    while stack:
        c = stack.pop()
        key = (str(c.co_name), c.co_firstlineno)
        if key in WORK_KEYS:
            UNIT_FP[fp(c)] = key
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                stack.append(k)
log('fingerprint table: %d' % len(UNIT_FP))


def is_armed(code):
    return (len(code) >= 6 and code[0] == 0x74 and
            code[2:4] == b'\x83\x00' and code[4:6] == b'\x09\x00')


def classify(co):
    code = co.co_code
    if is_armed(code):
        return 'ARMED'
    s = code[:256]
    nulls = s.count(0)
    printable = sum(1 for x in s if 32 <= x < 127)
    if s and (nulls + printable) / len(s) >= 0.80 and \
            nulls > len(s) * 0.25:
        return 'UTF16-STAMP'
    return 'REAL?'


def harvest():
    import gc
    seen_ids = set()
    hits = {}
    states = {}

    def try_fn(obj):
        try:
            if not isinstance(obj, _t.FunctionType):
                return False
            oid = id(obj)
            if oid in seen_ids:
                return False
            seen_ids.add(oid)
            co = obj.__code__
            key = UNIT_FP.get(fp(co))
            if key is None:
                key = (str(co.co_name), co.co_firstlineno)
                if key not in WORK_KEYS:
                    return False
            if key in hits:
                return False
            hits[key] = obj
            states[key] = classify(co)
            return True
        except BaseException:
            return False

    t_sweep = time.time()
    app_dicts = {}
    try:
        for o in gc.get_objects():
            try:
                if isinstance(o, type):
                    for v in list(vars(o).values()):
                        if isinstance(v, _t.FunctionType):
                            try_fn(v)
                            app_dicts[id(v.__globals__)] = \
                                v.__globals__
                elif hasattr(o, '__dict__'):
                    for v in list(o.__dict__.values()):
                        if isinstance(v, _t.FunctionType):
                            try_fn(v)
                            app_dicts[id(v.__globals__)] = \
                                v.__globals__
            except BaseException:
                continue
    except BaseException as e:
        log('gc walk err %r' % (e,))
    for m in list(sys.modules.values()):
        try:
            for v in list(m.__dict__.values()):
                if isinstance(v, _t.FunctionType):
                    try_fn(v)
                    app_dicts[id(v.__globals__)] = v.__globals__
        except BaseException:
            continue
    log('pass1: %d matches, %d app dicts, %ds'
        % (len(hits), len(app_dicts), time.time() - t_sweep))
    for d in list(app_dicts.values()):
        try:
            for v in list(d.values()):
                if isinstance(v, _t.FunctionType):
                    try_fn(v)
        except BaseException:
            continue
    log('pass2 (app dicts): %d matches' % len(hits))
    # second-order: classes reachable from the app dicts
    for d in list(app_dicts.values()):
        try:
            for v in list(d.values()):
                if isinstance(v, type):
                    for vv in list(vars(v).values()):
                        if isinstance(vv, _t.FunctionType):
                            try_fn(vv)
        except BaseException:
            continue
    log('pass3 (app classes): %d matches' % len(hits))
    return hits


def harvest_thread():
    time.sleep(30)
    hits = harvest()
    for key, obj in sorted(hits.items()):
        name, line = key
        try:
            fn = 'post_%s_L%d.marshal' % (
                name.replace('.', '_'), line)
            with open(os.path.join(RTP, fn), 'wb') as f:
                marshal.dump(obj.__code__, f)
        except BaseException as e:
            log('marshal fail %s L%d %r' % (name, line, e))
    # second harvest pass a minute later (more boot, more defined)
    time.sleep(45)
    hits2 = harvest()
    for key, obj in sorted(hits2.items()):
        name, line = key
        if key in hits:
            continue
        try:
            fn = 'post_%s_L%d.marshal' % (
                name.replace('.', '_'), line)
            with open(os.path.join(RTP, fn), 'wb') as f:
                marshal.dump(obj.__code__, f)
        except BaseException as e:
            log('marshal fail %s L%d %r' % (name, line, e))
    log('final hit count: %d' % (len(set(hits) | set(hits2))))
    for key in sorted(set(hits2) - set(hits)):
        pass
    # missing report
    missing = WORK_KEYS - set(hits) - set(hits2)
    log('missing units: %d' % len(missing))
    log('SESSION HARVEST COMPLETE')


def killer():
    time.sleep(220)
    log('killer exit')
    LOGH.flush()
    os._exit(0)


threading.Thread(target=killer, daemon=True).start()
threading.Thread(target=harvest_thread, daemon=True).start()

os.environ['TCL_LIBRARY'] = os.path.join(PYZ_EXT, '_tcl_data')
os.environ['TK_LIBRARY'] = os.path.join(PYZ_EXT, '_tk_data')
sys.path.insert(1, EXTRACT)
sys.path.append(PYZ_EXT)
sys.path.append(os.path.join(EXTRACT, 'win32'))
sys.path.append(os.path.join(PYZ_EXT, 'win32'))
sys.path.append(os.path.join(HERE, 'py38_extra'))
make_fake_module('spp_export_api')

with open(os.path.join(HERE, 'Nighty.pyc'), 'rb') as f:
    raw = f.read()
bootstrap = marshal.loads(raw[16:])
GNS = {'__name__': '__main__',
       '__file__': os.path.join(EXTRACT, 'Nighty.pyc'),
       '__builtins__': __builtins__}


def run_exec():
    import asyncio
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        exec(bootstrap, GNS)
    except BaseException as e:
        print('[31] exec ended: %r' % (e,), flush=True)


print('[31] bootstrap exec in worker', flush=True)
t = threading.Thread(target=run_exec, daemon=True)
t.start()
t.join(timeout=210)
print('[31] session closing t=%.1f' % (time.time() - T0), flush=True)
log('session closing')
LOGH.flush()
