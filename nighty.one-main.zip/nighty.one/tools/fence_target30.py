"""fence_target30.py - the force-call session: the bootstrap exec runs
in a WORKER thread (the app's own event loops block it - that is what
defeated the fence29 caller), while a second thread force-calls every
worklist callable against the LIVE module namespace and marshals each
code object AFTER the call. If pyarmor restores co_code in place at
call time, the post-call marshals hold real plaintext wordcode for the
whole never-executed set.

Same discipline as every fence session: in-process only,
ReadProcessMemory on SELF only, no other process is ever touched, the
license stays reseeded in %APPDATA%\\Nighty Selfbot\\auth.json.

Output: oracle/out/fence30/post_<name>_L<line>.marshal + live stream.
"""
import ctypes
import json
import marshal
import os
import struct
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
RTP = os.path.join(OUT, 'fence30')
STREAM = os.path.join(RTP, 'fence30_stream.bin')
os.makedirs(RTP, exist_ok=True)
EXTRACT = r'C:\Users\brian\Downloads\Nighty\Nighty.exe_extracted'
PYZ_EXT = os.path.join(EXTRACT, 'PYZ.pyz_extracted')

sys.path.insert(0, HERE)
from spp_fake import make_fake_module

import opcode
VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}

k32 = ctypes.WinDLL('kernel32')
T0 = time.time()
LOGH = open(os.path.join(RTP, 'fence30_session.log'), 'w', 1)


def log(m):
    LOGH.write('%s\n' % m)


census = json.load(open(os.path.join(OUT, 'pending_census.json')))
work = [(e['name'], e['line'], e['size'], k)
        for k in ('ARMED', 'OTHER')
        for e in census[k]]
print('[30] worklist: %d units' % len(work), flush=True)
log('worklist: %d' % len(work))


class MBI(ctypes.Structure):
    _fields_ = [('BaseAddress', ctypes.c_void_p),
                ('AllocationBase', ctypes.c_void_p),
                ('AllocationProtect', ctypes.c_uint32),
                ('RegionSize', ctypes.c_size_t),
                ('State', ctypes.c_uint32),
                ('Protect', ctypes.c_uint32),
                ('Type', ctypes.c_uint32)]


def walk_regions():
    mbi = MBI()
    addr = 0x10000
    hps = ctypes.c_void_p(k32.GetCurrentProcess())
    while addr < 0x7FFFFFFEFFFF:
        r = k32.VirtualQueryEx(hps, ctypes.c_void_p(addr),
                               ctypes.byref(mbi), ctypes.sizeof(mbi))
        if r == 0:
            break
        if mbi.RegionSize:
            yield (mbi.BaseAddress or addr, mbi.RegionSize,
                   mbi.Protect, mbi.State, mbi.Type)
            addr += mbi.RegionSize
        else:
            addr += 0x1000


def safe_read(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t(0)
    ok = k32.ReadProcessMemory(
        ctypes.c_void_p(k32.GetCurrentProcess()),
        ctypes.c_void_p(addr), buf, size, ctypes.byref(got))
    if not ok or got.value < size:
        return None
    return buf.raw[:size]


ELF_NEEDLE = bytes.fromhex('8b0572740100488d4c24580f11742430')
ANCHOR_VA = 0x931A0
IMG_LEN = 0xafac0
DIE = [False]
G = None
STREAM_WROTE = [0]
STREAM_BUDGET = [500 * 1024 * 1024]
ROUNDS = [0]


def find_elf_bases():
    bases = set()
    for base, size, prot, state, mtype in walk_regions():
        if state != 0x1000 or mtype == 0x1000000:
            continue
        if not (prot & (0x02 | 0x04 | 0x20 | 0x40)) or (prot & 0x100):
            continue
        if size < 0x2000 or size > 0x1000000:
            continue
        pos = 0
        while pos + len(ELF_NEEDLE) <= size:
            chunk = safe_read(base + pos, min(0x40000, size - pos))
            if not chunk:
                break
            i = chunk.find(ELF_NEEDLE)
            while i >= 0:
                bases.add(base + pos + i - ANCHOR_VA)
                i = chunk.find(ELF_NEEDLE, i + 1)
            pos += 0x40000 if len(chunk) == 0x40000 else len(chunk)
    return bases


def sampler_thread(bases):
    f = open(STREAM, 'wb')
    try:
        while not DIE[0] and time.time() - T0 < 170:
            try:
                for base, size, prot, state, mtype \
                        in walk_regions():
                    if state != 0x1000 or mtype == 0x1000000:
                        continue
                    if not (prot & (0x02 | 0x04 | 0x20 | 0x40)) \
                            or (prot & 0x100):
                        continue
                    if mtype == 0x40000 and size > 0x400000:
                        continue
                    if size > 0x1000000:
                        continue
                    if any(b - 0x2000 <= base <
                           b + IMG_LEN + 0x2000 for b in bases):
                        continue
                    pos = 0
                    while pos + 0x800 <= size and \
                            STREAM_WROTE[0] < STREAM_BUDGET[0]:
                        chunk = safe_read(base + pos,
                                         min(0x8000, size - pos))
                        if not chunk:
                            break
                        pl = len(chunk) & ~1
                        rpos = 0
                        while rpos < pl - 6:
                            if chunk[rpos] not in VALID:
                                rpos += 2
                                continue
                            q = rpos
                            while q < pl and chunk[q] in VALID:
                                q += 2
                            if q - rpos >= 16:
                                payload = bytes(chunk[rpos:q])
                                head = struct.pack(
                                    '<QII', base + pos + rpos,
                                    len(payload),
                                    int(time.time() * 1000)
                                    & 0xFFFFFF)
                                f.write(head + payload)
                                STREAM_WROTE[0] += len(payload) + 16
                            rpos = q if q > rpos else rpos + 2
                        pos += 0x8000
                ROUNDS[0] += 1
            except BaseException as e:
                log('sampler err %r' % (e,))
            time.sleep(0.05)
    finally:
        f.flush()
        f.close()
    log('sampler done: rounds=%d bytes=%d'
        % (ROUNDS[0], STREAM_WROTE[0]))


def is_resolved(co):
     # quick sanity: not armed, not utf16
    code = co.co_code
    if len(code) >= 6 and code[0] == 0x74 and \
            code[2:4] == b'\x83\x00' and code[4:6] == b'\x09\x00':
        return 'ARMED'
    s = code[:256]
    nulls = s.count(0)
    printable = sum(1 for x in s if 32 <= x < 127)
    if s and (nulls + printable) / len(s) >= 0.80 and \
            nulls > len(s) * 0.25:
        return 'UTF16'
    return 'MAYBE-PLAIN'


def _NS():
    """The real app namespace: score live frame dicts + gc modules by
    how many of the worklist names they hold (the app module has 40+;
    discord_bot.utils fooled the single-name probe with one re-export).
    diag_g2 proved the frames route; pyarmor's sys.modules['__main__']
    is a 4-key decoy - never trust it."""
    probes = {n for n, _, _, _ in work}
    best = None
    best_hits = 0
    mine = globals()
    try:
        for tid, fr in sys._current_frames().items():
            try:
                f = fr
            except BaseException:
                continue
            depth = 0
            seen = set()
            while f is not None and depth < 64:
                try:
                    gd = f.f_globals
                    if gd is None or gd is mine:
                        break
                except BaseException:
                    break
                key = None
                try:
                    key = id(gd)
                    if key not in seen:
                        seen.add(key)
                        hits = 0
                        for n in probes:
                            try:
                                if n in gd:
                                    hits += 1
                            except BaseException:
                                pass
                        if hits > best_hits:
                            best_hits = hits
                            best = gd
                except BaseException:
                    pass
                try:
                    f = f.f_back
                except BaseException:
                    break
                depth += 1
    except BaseException:
        pass
    if best_hits < 8:
        try:
            import gc
            import types as _t
            for o in gc.get_objects():
                try:
                    if isinstance(o, _t.ModuleType):
                        d = o.__dict__
                        if d is mine:
                            continue
                        hits = 0
                        for n in probes:
                            if n in d:
                                hits += 1
                        if hits > best_hits:
                            best_hits = hits
                            best = d
                            if best_hits >= 12:
                                break
                except BaseException:
                    continue
        except BaseException:
            pass
    log('NS found: hits=%d size=%d file=%r'
        % (best_hits, len(best) if best else -1,
           best.get('__file__') if best else None))
    return best if best_hits >= 8 else G


def caller_thread():
    # let the worker exec define the module (a few seconds), then call
    time.sleep(30)
    work_keys = {(n, l) for n, l, _, _ in work}
    # THE GC CONTAINER WALK: bare functions are NOT gc-tracked; classes
    # and instances ARE. Chain: gc -> classes/instances -> methods; then
    # any captured function's __globals__ IS the hidden app module dict
    # (which pyarmor unlinked from sys.modules via the decoy rebind) -
    # walk it fully for every worklist unit.
    import gc
    import types as _t
    seen_ids = set()
    results = {}

    def try_fn(obj, where):
        try:
            if not isinstance(obj, _t.FunctionType):
                return
            oid = id(obj)
            if oid in seen_ids:
                return
            seen_ids.add(oid)
            co = obj.__code__
            key = (str(co.co_name), co.co_firstlineno)
            if key in work_keys and key not in results:
                results[key] = obj
        except BaseException:
            return

    def walk_dict_values(d):
        try:
            for v in list(d.values()):
                try_fn(v, 'dict')
        except BaseException:
            pass

    t_sweep = time.time()
    app_dicts = []
    try:
        for o in gc.get_objects():
            try:
                if isinstance(o, type):
                    try:
                        for v in list(vars(o).values()):
                            try_fn(v, 'cls')
                            if isinstance(v, _t.FunctionType):
                                app_dicts.append(v.__globals__)
                    except BaseException:
                        continue
                elif hasattr(o, '__dict__'):
                    try:
                        for v in list(o.__dict__.values()):
                            try_fn(v, 'inst')
                            if isinstance(v, _t.FunctionType):
                                app_dicts.append(v.__globals__)
                    except BaseException:
                        continue
            except BaseException:
                continue
    except BaseException as e:
        log('gc walk err %r' % (e,))
    for m in list(sys.modules.values()):
        try:
            walk_dict_values(m.__dict__)
        except BaseException:
            pass
    log('gc containers: %ds, app dicts: %d, matches: %d'
        % (time.time() - t_sweep, len(set(map(id, app_dicts))),
           len(results)))
    # walk every discovered app namespace (dicts/classes full depth)
    for d in list({id(g): g for g in app_dicts}.values()):
        try:
            walk_dict_values(d)
            for v in list(d.values()):
                if isinstance(v, type):
                    for vv in list(vars(v).values()):
                        try_fn(vv, 'appcls')
        except BaseException:
            continue
    log('after app-dict walk: matches: %d' % len(results))
    plan = [(k[0], k[1], obj) for k, obj in results.items()]
    # pre-call snapshots of every callable's co_code
    for name, line, obj in plan:
        try:
            fn = 'pre_%s_L%d.marshal' % (
                name.replace('.', '_'), line)
            with open(os.path.join(RTP, fn), 'wb') as f:
                marshal.dump(obj.__code__, f)
        except BaseException as e:
            log('pre-marshal fail %s L%d %r' % (name, line, e))
    # the force-call waves
    for wave in range(3):
        n_ok = 0
        n_err = 0
        for name, line, obj in plan:
            for args in ((), (None,), (None, None),
                         (None, None, None, None)):
                try:
                    if args:
                        obj(*args)
                    else:
                        obj()
                    n_ok += 1
                except BaseException:
                    n_err += 1
                    break
            try:
                fn = 'post_%s_L%d.marshal' % (
                    name.replace('.', '_'), line)
                with open(os.path.join(RTP, fn), 'wb') as f:
                    marshal.dump(obj.__code__, f)
            except BaseException as e:
                log('post-marshal fail %s L%d %r'
                    % (name, line, e))
        log('wave %d: ok=%d err=%d' % (wave, n_ok, n_err))
        time.sleep(1)
    # final post-call classification pass
    for name, line, obj in plan:
        try:
            st = is_resolved(obj.__code__)
            log('post-state %-24s L%-7d %s'
                % (name[:24], line, st))
        except BaseException as e:
            log('state fail %s L%d %r' % (name, line, e))
    DIE[0] = True


def killer():
    time.sleep(240)
    log('killer exit')
    LOGH.flush()
    os._exit(0)


threading.Thread(target=killer, daemon=True).start()
bases = find_elf_bases()
log('spp bases: %s' % [hex(b) for b in bases])
threading.Thread(target=sampler_thread, args=(bases,),
                 daemon=True).start()

os.environ['TCL_LIBRARY'] = os.path.join(PYZ_EXT, '_tcl_data')
os.environ['TK_LIBRARY'] = os.path.join(PYZ_EXT, '_tk_data')
sys.path.insert(1, EXTRACT)
sys.path.append(PYZ_EXT)
sys.path.append(os.path.join(EXTRACT, 'win32'))
sys.path.append(os.path.join(PYZ_EXT, 'win32'))
sys.path.append(os.path.join(HERE, 'py38_extra'))

make_fake_module('spp_export_api')

with open(os.path.join(HERE, 'Nighty.pyc'), 'rb') as f:
    raw = f.read()
bootstrap = marshal.loads(raw[16:])
G = {'__name__': '__main__',
     '__file__': os.path.join(EXTRACT, 'Nighty.pyc'),
     '__builtins__': __builtins__}

threading.Thread(target=caller_thread, daemon=True).start()

print('[30] bootstrap exec in worker', flush=True)


def run_exec():
    import asyncio
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        exec(bootstrap, G)
    except BaseException as e:
        print('[30] exec ended: %r' % (e,), flush=True)
        log('exec ended %r' % (e,))
    print('[30] exec returned t=%.1f' % (time.time() - T0),
          flush=True)


t = threading.Thread(target=run_exec, daemon=True)
t.start()
t.join(timeout=225)
print('[30] session closing t=%.1f' % (time.time() - T0), flush=True)
log('session closing')
LOGH.flush()
