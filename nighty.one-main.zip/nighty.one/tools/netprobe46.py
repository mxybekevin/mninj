# netprobe46.py - capture every URL the ORIGINAL armored app
# requests during boot. Patches requests/socket before the
# bootstrap exec, writes out/netprobe46.log.
import asyncio
import marshal
import os
import socket
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out', 'netprobe46')
os.makedirs(OUT, exist_ok=True)
LOG = open(os.path.join(OUT, 'urls.log'), 'w', 1)

EXTRACT = (r'C:\Users\brian\Downloads\Nighty'
           r'\Nighty.exe_extracted')
PYZ_EXT = os.path.join(EXTRACT, 'PYZ.pyz_extracted')

sys.path.insert(1, EXTRACT)
sys.path.append(PYZ_EXT)
sys.path.append(os.path.join(EXTRACT, 'win32'))
sys.path.append(os.path.join(PYZ_EXT, 'win32'))
sys.path.append(os.path.join(HERE, 'py38_extra'))
os.environ['TCL_LIBRARY'] = os.path.join(PYZ_EXT, '_tcl_data')
os.environ['TK_LIBRARY'] = os.path.join(PYZ_EXT, '_tk_data')
sys.path.insert(0, HERE)

from spp_fake import make_fake_module
make_fake_module('spp_export_api')

# seed the REAL license so the original's auth flow fires
LICENSE = ('NzPpdiNhFiIwVgo-NIGHTY-'
           'ocjbLqJddLoGMrd')


class _SppFactory:
    def __call__(self, name, *a, **k):
        if name == 'getLicense':
            def getLicense():
                return LICENSE
            return getLicense
        import spp_fake as _sf
        return _sf.Rec()


_sppmod = sys.modules.get('spp_export_api')
if _sppmod is not None:
    _sppmod.spp_export_api = _SppFactory()
LOG.write('spp factory seeded with real license\n')

# --- network capture patches (before any app import) ---
_real_gai = socket.getaddrinfo


def logged_gai(host, *a, **kw):
    try:
        LOG.write('RESOLVE %s\n' % host)
    except Exception:
        pass
    return _real_gai(host, *a, **kw)


socket.getaddrinfo = logged_gai

_real_connect = socket.socket.connect


def logged_connect(self, address):
    try:
        LOG.write('CONNECT %s:%s\n' % address[:2])
    except Exception:
        pass
    return _real_connect(self, address)


socket.socket.connect = logged_connect

import requests  # noqa: E402
_real_request = requests.Session.request


def logged_request(self, method, url, **kw):
    body = kw.get('json') or kw.get('data')
    LOG.write('%s %s json=%r\n' % (method, url, body))
    try:
        r = _real_request(self, method, url, **kw)
        LOG.write('  -> %d %s\n' % (r.status_code,
                                    r.text[:120]))
        return r
    except Exception as e:
        LOG.write('  -> ERR %r\n' % (e,))
        raise


requests.Session.request = logged_request

# curl_cffi is the app's real HTTP lane (browser-impersonation TLS)
try:
    import curl_cffi.requests as creq  # noqa: E402
    _cr = creq.Session.request

    def logged_creq(self, method, url, **kw):
        body = kw.get('json') or kw.get('data')
        LOG.write('CURL %s %s json=%r\n' % (method, url, body))
        try:
            r = _cr(self, method, url, **kw)
            LOG.write('  -> %d %s\n' % (r.status_code,
                                        r.text[:120]))
            return r
        except Exception as e:
            LOG.write('  -> ERR %r\n' % (e,))
            raise
    creq.Session.request = logged_creq
    import curl_cffi as _cc
    LOG.write('curl_cffi patched OK\n')
except Exception as e:
    LOG.write('curl_cffi patch fail %r\n' % (e,))

# --- boot the original ---
with open(os.path.join(HERE, 'Nighty.pyc'), 'rb') as f:
    raw = f.read()
bootstrap = marshal.loads(raw[16:])
GNS = {'__name__': '__main__',
       '__file__': os.path.join(EXTRACT, 'Nighty.pyc'),
       '__builtins__': __builtins__}


def run_exec():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        exec(bootstrap, GNS)
    except BaseException as e:
        LOG.write('BOOT END %r\n' % (e,))


print('[netprobe46] booting original...', flush=True)
threading.Thread(target=run_exec, daemon=True).start()
time.sleep(300)
LOG.write('probe done\n')
os._exit(0)
