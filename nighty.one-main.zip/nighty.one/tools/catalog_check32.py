# catalog_check32.py - disambiguation of the fence32 banked candidates.
# Filters: (1) alphabet-stamp heads; (2) CATALOG identity - the candidate
# equals some OTHER code object's known bytes (v5 stamps + fence31 live
# marshals + the 22 compiled shipped bodies); (3) uniqueness - passes the
# bounds of exactly one target. Survivors are real decode candidates.
import collections
import compileall
import glob
import json
import marshal
import os
import re
import subprocess
import types as _t

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out')
RTP = os.path.join(OUT, 'fence32')
V5D = os.path.join(OUT, 'v5')
F31 = os.path.join(OUT, 'fence31')
VSRC = os.path.join(OUT, 'vsrc39')

import opcode
VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}
NAME_OPS = {'LOAD_GLOBAL', 'STORE_GLOBAL', 'LOAD_NAME', 'STORE_NAME',
            'DELETE_NAME', 'LOAD_ATTR', 'STORE_ATTR', 'IMPORT_NAME',
            'IMPORT_FROM', 'LOAD_METHOD'}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)

catalog = {}
targets = []
census = json.load(open(os.path.join(OUT, 'pending_census.json')))
WK = {(e['name'], e['line']) for k in census for e in census[k]}


def add_cat(co, label):
    catalog.setdefault(bytes(co.co_code), []).append(
        (str(co.co_name), co.co_firstlineno, label))


# 1. v5 stamps (every unit's at-rest bytes incl. junk/stamps)
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        top = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(top, _t.CodeType):
        continue
    stack = [(top, 0)]
    while stack:
        c, d = stack.pop()
        if d > 22:
            continue
        add_cat(c, 'v5')
        if (str(c.co_name), c.co_firstlineno) in WK:
            targets.append((str(c.co_name), c.co_firstlineno, c))
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                stack.append((k, d + 1))

# 2. fence31 live marshals (live at-rest stamp bodies)
for p in glob.glob(os.path.join(F31, 'post_*.marshal')):
    try:
        co = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if isinstance(co, _t.CodeType):
        add_cat(co, 'f31')

# 3. the 22 shipped bodies - compile their sources for the true bytes
VERD = os.path.join(OUT, 'fence29', 'verified')
shipped = []
for d in (VSRC, VERD):
    for p in glob.glob(os.path.join(d, 'verified', '*.py')) or \
            glob.glob(os.path.join(d, '*.py')):
        m = re.match(r'(.+)_L(\d+)\.py$', os.path.basename(p))
        if not m:
            continue
        src = open(p, encoding='utf-8').read()
        try:
            mod = compile(src, '<c>', 'exec')
        except SyntaxError:
            continue
        stack = [mod]
        while stack:
            c = stack.pop()
            for k in c.co_consts:
                if isinstance(k, _t.CodeType):
                    stack.append(k)
            if str(c.co_name) == m.group(1):
                add_cat(c, 'shipped')
                shipped.append((m.group(1), int(m.group(2))))
print('catalog: %d byte strings; shipped bodies: %d'
      % (len(catalog), len(set(shipped))))
by_len = collections.defaultdict(list)
for nm, fl, co in targets:
    by_len[len(co.co_code)].append((nm, fl, co))


def hard_ok(win, co, L):
    offs = {0}
    start = 0
    for i in range(0, len(co.co_lnotab or b''), 2):
        start += co.co_lnotab[i]
        offs.add(start)
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nd = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    for i in range(0, L, 2):
        op = win[i]
        if op not in VALID:
            return False
        arg = win[i + 1] if i + 1 < L else 0
        nm = opcode.opname[op]
        if op < opcode.HAVE_ARGUMENT and arg != 0:
            return False
        if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == 'LOAD_CONST' and arg >= nconst:
            return False
        if nm in ('LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                  'LOAD_CLOSURE') and arg >= nd:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


def alphabetish(run):
    head = run[:32]
    pairs = [head[i:i + 2] for i in range(0, len(head) - 1, 2)]
    counts = collections.Counter(pairs)
    if not counts:
        return False
    top, n = counts.most_common(1)[0]
    return n >= 4


rows = []
for p in sorted(glob.glob(os.path.join(RTP, 'recovered_*.bin'))):
    m = re.match(r'recovered_(.+)_L(\d+)\.bin', os.path.basename(p))
    if not m:
        continue
    raw = m.group(1)
    # strip the _L<line> suffix for names containing underscores
    line = int(m.group(2))
    nm = raw.rsplit('_L%d' % line, 1)[0] if \
        raw.endswith('_L%d' % line) else raw
    run = open(p, 'rb').read()
    L = len(run)
    co = next((c for n2, l2, c in targets
               if n2 == nm and l2 == line), None)
    if co is None:
        rows.append((nm, line, 'NO-TARGET', run[:8].hex()))
        continue
    if bytes(co.co_code) == run:
        rows.append((nm, line, 'SAME-AS-STAMP', run[:8].hex()))
        continue
    if alphabetish(run):
        rows.append((nm, line, 'ALPHABET', run[:8].hex()))
        continue
    owners = catalog.get(run, [])
    foreign = [(n2, l2, lab) for n2, l2, lab in owners
               if not (n2 == nm and l2 == line)]
    self_own = any(n2 == nm and l2 == line for n2, l2, lab in owners)
    passing = [t for t in by_len.get(L, ()) if hard_ok(run, t[2], L)]
    if self_own:
        rows.append((nm, line, 'SELF-CONFIRMED', run[:8].hex()))
    elif foreign:
        rows.append((nm, line,
                     'FOREIGN(%s L%d %s)' % (foreign[0][0],
                                             foreign[0][1],
                                             foreign[0][2]),
                     run[:8].hex()))
    elif len(passing) == 1 and passing[0][0] == nm and \
            passing[0][1] == line:
        rows.append((nm, line, 'CANDIDATE-UNIQUE', run[:8].hex()))
    else:
        rows.append((nm, line, 'AMBIG-%d' % len(passing),
                     run[:8].hex()))

tally = collections.Counter(r[2].split('(')[0] for r in rows)
print('verdicts:', dict(tally))
print()
print('CANDIDATE-UNIQUE / SELF-CONFIRMED survivors:')
for nm, line, v, head in sorted(rows, key=lambda r: r[1]):
    if v in ('CANDIDATE-UNIQUE', 'SELF-CONFIRMED'):
        print('   L%-7d %-30s %-16s head=%s' % (line, nm[:30], v, head))
json.dump([{'name': n, 'line': l, 'verdict': v, 'head': h}
           for n, l, v, h in rows],
          open(os.path.join(RTP, 'catalog_check32.json'), 'w'), indent=1)
print('CATALOG CHECK32 DONE')
