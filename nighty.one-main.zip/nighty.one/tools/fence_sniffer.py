"""
fence_sniffer.py - cross-process armed-buffer sweeper (race-proof).

ReadProcessMemory NEVER crashes the target on guard pages (reads simply
fail). Sweeps all recorded armed buffers page-by-page and stores every
distinct page content version it ever sees -> out/fence_snaps/all.marshal.

The union over time of readable page versions = every decrypted block.

usage: python fence_sniffer.py <pid>
"""
import ctypes
import marshal
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
os.makedirs(SNAPS, exist_ok=True)
CALLS_LOG = os.path.join(OUT, "fence_calls.log")
STORE = os.path.join(SNAPS, "all.marshal")

pid = int(sys.argv[1])
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

PROCESS_VM_READ = 0x0010
PROCESS_QUERY_INFORMATION = 0x0400
h = kernel32.OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, False, pid)
if not h:
    print("[-] OpenProcess failed:", kernel32.GetLastError())
    sys.exit(1)
print("[+] opened pid %d" % pid)

def rpm(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t()
    ok = kernel32.ReadProcessMemory(h, ctypes.c_void_p(addr), buf, ctypes.c_size_t(size),
                                    ctypes.byref(got))
    if not ok:
        err = kernel32.GetLastError()
        return None
    return buf.raw[:got.value]

# buffers: id -> {"buf": ptr, "pages": {page_off: [contents...]}}
buffers = {}
changes = [0]
file_pos = [0]

def harvest_calls_log():
    if not os.path.exists(CALLS_LOG):
        return
    with open(CALLS_LOG, "r", encoding="utf-8", errors="replace") as f:
        f.seek(file_pos[0])
        data = f.read()
        file_pos[0] = f.tell()
    for line in data.splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[1] in ("call", "task"):
            try:
                cid = int(parts[2]); ptr = int(parts[3])
            except ValueError:
                continue
            if not ptr:
                continue
            ent = buffers.get(cid)
            if ent is None or ent["buf"] != ptr:
                ent = {"buf": ptr, "pages": {}, "known_len": 0}
                buffers[cid] = ent
                # read expected length from meta record if available
                meta_path = os.path.join(OUT, "fence_meta", "%d.marshal" % cid)
                if os.path.exists(meta_path):
                    try:
                        with open(meta_path, "rb") as mf:
                            meta = marshal.load(mf)
                        base = meta.get("baseline")
                        if base:
                            ent["known_len"] = len(base)
                    except Exception:
                        pass
                print("[+] watching buffer id=%d %#x len=%d" % (cid, ptr, ent["known_len"]))

def sweep(cid, ent):
    buf = ent["buf"]
    # bytes object header: ob_size at +16, data at +24
    hdr = rpm(buf + 16, 8)
    n = 0
    if hdr is not None:
        (n,) = struct.unpack("<q", hdr)
        if n <= 0 or n > 20_000_000:
            n = 0
    if n == 0:
        n = ent.get("known_len") or 0
    if n <= 0:
        return
    data_addr = buf + 24
    # sweep page-aligned chunks of 4096
    page = 4096
    off = 0
    while off < n:
        chunk = min(page, n - off)
        cur = int(data_addr + off) & ~0xFFF
        content = rpm(cur, page if chunk == page else chunk)
        if content is not None:
            pages = ent["pages"]
            lst = pages.setdefault(off, [])
            if not lst or lst[-1] != content[:chunk]:
                lst.append(content[:chunk])
                if len(lst) > 96:
                    lst.pop(0)
                changes[0] += 1
        off += page

def save():
    try:
        tmp = STORE + ".tmp"
        with open(tmp, "wb") as f:
            marshal.dump({cid: {"buf": e["buf"],
                                "pages": {k: v for k, v in e["pages"].items()}}
                          for cid, e in buffers.items()}, f)
        os.replace(tmp, STORE)
    except Exception as ex:
        print("[!] save fail: %r" % ex)

t0 = time.time()
last_dump = 0.0
dead_checks = 0
while True:
    harvest_calls_log()
    if buffers:
        for cid, ent in list(buffers.items()):
            try:
                sweep(cid, ent)
            except Exception as e:
                print("[!] sweep err %r" % e)
    now = time.time()
    if now - last_dump >= 3.0:
        save()
        print("[%6.1fs] buffers=%d changes=%d" % (now - t0, len(buffers), changes[0]),
              flush=True)
        last_dump = now
    # detect process death properly
    code = ctypes.c_ulong()
    h2 = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION, False, pid)
    if h2:
        if kernel32.GetExitCodeProcess(h2, ctypes.byref(code)):
            if code.value != 259:   # STILL_ACTIVE
                dead_checks += 1
            else:
                dead_checks = 0
        kernel32.CloseHandle(h2)
    if dead_checks >= 10:
        print("[*] target gone; final save")
        break
    time.sleep(0.001)

kernel32.CloseHandle(h)
save()
allpages = sum(len(e["pages"]) for e in buffers.values())
allvers = sum(len(v) for e in buffers.values() for v in e["pages"].values())
print("[+] done. buffers=%d pages=%d versions=%d" % (len(buffers), allpages, allvers))
