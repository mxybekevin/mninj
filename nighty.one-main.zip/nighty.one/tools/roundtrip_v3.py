"""
roundtrip_v3.py - faithful round-trip verification, wordcode-correct.

For every v5 tree that shipped a body in Nighty.py:
  1. take the emitted source block (exactly as Nighty.py carries it)
  2. recompile it (line-padded to original firstlineno)
  3. walk original tree vs recompiled tree IN LOCK-STEP (structural pairing)
  4. compare normalized instruction streams:
       - wordcode: every instruction 2 bytes
       - jumps compared as instruction ORDINALS (order of target)
       - operands resolved to values (const repr, names, varnames)
  verdicts: IDENTICAL / EQUIV (<=2 operand diffs) / DIFFERS / FAILED

Output: out/roundtrip_v3_report.txt + console summary.
"""
import dis
import glob
import marshal
import os
import re
import types

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
V5D = os.path.join(OUT, "v5")
FINAL = r"C:\Users\brian\Downloads\Nighty\NightyRecovered\Nighty.py"


# ------------------------------------------------------------- normalization
def normalize(co):
    instrs = list(dis.get_instructions(co))
    ordinal = {ins.offset: i for i, ins in enumerate(instrs)}
    out = []
    for ins in instrs:
        nm = ins.opname
        if nm.startswith("JUMP") or nm.startswith("SETUP") or \
           nm == "FOR_ITER" or nm.startswith("POP_JUMP") or nm == "GET_ITER":
            t = ins.argval
            if isinstance(t, int) and t in ordinal:
                arg = "J%d" % ordinal[t]
            else:
                arg = "J?%r" % (t,)
        elif nm in ("LOAD_CONST", "LOAD_FAST", "STORE_FAST", "DELETE_FAST",
                    "LOAD_GLOBAL", "STORE_GLOBAL", "LOAD_NAME", "STORE_NAME",
                    "DELETE_NAME", "LOAD_ATTR", "STORE_ATTR", "LOAD_METHOD",
                    "LOAD_DEREF", "STORE_DEREF", "DELETE_DEREF",
                    "LOAD_CLOSURE", "IMPORT_NAME", "IMPORT_FROM",
                    "COMPARE_OP"):
            arg = repr(ins.argval)[:70]
        else:
            arg = ins.argrepr[:40] or repr(ins.argval)[:40]
        out.append((nm, arg))
    return out


def pairs_lockstep(orig, new, sink, path=""):
    sink.append((path, orig, new))
    seen = set()
    for i, c in enumerate(orig.co_consts):
        if not isinstance(c, types.CodeType):
            continue
        nc = None
        if i < len(new.co_consts) and isinstance(new.co_consts[i], types.CodeType):
            nc = new.co_consts[i]
        else:
            for c2 in new.co_consts:
                if isinstance(c2, types.CodeType) and \
                        (c2.co_name, c2.co_firstlineno) == (c.co_name, c.co_firstlineno) and \
                        id(c2) not in seen:
                    nc = c2
                    break
        if nc is None:
            sink.append((path + "/" + str(c.co_name), c, None))
            continue
        seen.add(id(nc))
        pairs_lockstep(c, nc, sink, path + "/" + str(c.co_name))


# ------------------------------------------------------------- source blocks
def parse_nighty_blocks():
    """cut Nighty.py into per-unit blocks keyed by (name, firstlineno)."""
    src = open(FINAL, encoding="utf-8", errors="replace").read()
    blocks = {}
    cur = []
    header = re.compile(r"# (\S.*?)   \(original line (\d+)\)")
    curkey = None
    for ln in src.splitlines():
        m = header.match(ln)
        if m:
            if curkey and cur:
                blocks[curkey] = "\n".join(cur)
            curkey = (m.group(1).strip(), int(m.group(2)))
            cur = []
            continue
        if ln.startswith("# ===") or ln.startswith("# STILL") or \
           ln.startswith("# PENDING") or ln.startswith("# REVIEW"):
            if curkey and cur:
                blocks[curkey] = "\n".join(cur)
            curkey = None
            cur = []
            continue
        if curkey is not None:
            cur.append(ln)
    if curkey and cur:
        blocks[curkey] = "\n".join(cur)
    return blocks


def main():
    blocks = parse_nighty_blocks()
    print("unit blocks found in Nighty.py: %d" % len(blocks))

    stats = {"IDENTICAL": 0, "EQUIV": 0, "DIFFERS": 0, "FAILED": 0, "NOBLOCK": 0}
    unit_stats = {"IDENTICAL": 0, "EQUIV": 0, "DIFFERS": 0, "FAILED": 0}
    rows = []

    for p in sorted(glob.glob(os.path.join(V5D, "v5_*.marshal"))):
        try:
            orig = marshal.load(open(p, "rb"))
        except Exception:
            continue
        if not isinstance(orig, types.CodeType):
            continue
        key = None
        for (nm, fl), txt in blocks.items():
            if fl == orig.co_firstlineno and nm == str(orig.co_name):
                key = (nm, fl)
                break
        if key is None:
            continue
        block = blocks[key]
        # trim banner comment lines (they shift line numbers)
        blines = block.splitlines()
        while blines and (blines[0].lstrip().startswith("#") or not blines[0].strip()):
            blines.pop(0)
        while blines and (blines[-1].lstrip().startswith("#") or not blines[-1].strip()):
            blines.pop()
        block = "\n".join(blines)
        if not block.strip():
            continue
        try:
            pad = "\n" * max(0, orig.co_firstlineno - 1)
            newmod = compile(pad + block, orig.co_filename, "exec")
        except Exception:
            stats["FAILED"] += 1
            rows.append(("FAILED-COMPILE", str(orig.co_name), orig.co_firstlineno, "-"))
            continue
        # locate the new unit in the module
        newco = None
        for c in newmod.co_consts:
            if isinstance(c, types.CodeType) and \
                    c.co_firstlineno == orig.co_firstlineno and \
                    c.co_name == orig.co_name:
                newco = c
                break
        if newco is None:
            stats["FAILED"] += 1
            rows.append(("FAILED-LOCATE", str(orig.co_name), orig.co_firstlineno, "-"))
            continue

        sink = []
        pairs_lockstep(orig, newco, sink)
        verdict = "IDENTICAL"
        worst = "n/a"
        n_ident = n_equiv = n_diff = 0
        for path, o, n in sink:
            if n is None:
                verdict = "DIFFERS"
                worst = "%s: child missing in recompile" % path
                n_diff += 1
                continue
            so, sn = normalize(o), normalize(n)
            if so == sn:
                n_ident += 1
                continue
            diffs = sum(1 for a, b in zip(so, sn) if a != b)
            if len(so) == len(sn) and diffs <= 2 and \
                    [x[0] for x in so] == [x[0] for x in sn]:
                n_equiv += 1
                if verdict == "IDENTICAL":
                    verdict = "EQUIV"
            else:
                n_diff += 1
                verdict = "DIFFERS"
                for pi, (a, b) in enumerate(zip(so, sn)):
                    if a != b:
                        worst = "%s @%d %s vs %s" % (path, pi, a[0], b[0])
                        break
                else:
                    worst = "%s len %d vs %d" % (path, len(so), len(sn))
        unit_stats[verdict] += 1
        tot = n_ident + n_equiv + n_diff
        rows.append((verdict, str(orig.co_name), orig.co_firstlineno,
                     "%d/%d/%d %s" % (n_ident, n_equiv, n_diff, worst[:60])))

    print()
    print("=== roundtrip v3 verdicts (per shipped unit, whole nested tree) ===")
    for k in ("IDENTICAL", "EQUIV", "DIFFERS", "FAILED"):
        print("  %-9s : %d" % (k, unit_stats[k]))
    print()
    with open(os.path.join(OUT, "roundtrip_v3_report.txt"), "w", encoding="utf-8") as f:
        for verdict, nm, fl, info in sorted(rows, key=lambda r: (r[0], r[2])):
            f.write("%-9s %-34s L%-6d %s\n" % (verdict, nm[:34], fl, info))
    n_diff = [r for r in rows if r[0] == "DIFFERS"]
    print("first DIFFERS rows:")
    for r in n_diff[:10]:
        print("  %-9s %-30s L%-6d %s" % r)


if __name__ == "__main__":
    main()
