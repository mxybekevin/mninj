// hook48e.js - hook ws2_32!connect to log ALL outbound TCP
// connections (IP:port). Run for 120 seconds during boot.
var OUT = 'C:\\Users\\brian\\Downloads\\Nighty\\oracle\\out\\netprobe48\\';
var fh = new File(OUT + 'connections.log', 'w', 1);
var conns = {};

var WS2 = Process.getModuleByName('WS2_32.dll');
var connectPtr = WS2.getExportByName('connect');

Interceptor.attach(connectPtr, {
    onEnter: function (args) {
        var s = args[0];
        var addr = args[1];
        try {
            var family = addr.readU16();
            if (family === 2) { // AF_INET
                var port = (addr.add(2).readU8() << 8) |
                    addr.add(3).readU8();
                var ip = addr.add(4).readU8() + '.' +
                    addr.add(5).readU8() + '.' +
                    addr.add(6).readU8() + '.' +
                    addr.add(7).readU8();
                var key = ip + ':' + port;
                if (!conns[key]) {
                    conns[key] = 1;
                    fh.write('CONNECT ' + key + '\n');
                }
            }
        } catch (e) {}
    }
});

// also hook WSAConnect for async sockets
try {
    var wsaConnect = WS2.getExportByName('WSAConnect');
    Interceptor.attach(wsaConnect, {
        onEnter: function (args) {
            var addr = args[1];
            try {
                var family = addr.readU16();
                if (family === 2) {
                    var port = (addr.add(2).readU8() << 8) |
                        addr.add(3).readU8();
                    var ip = addr.add(4).readU8() + '.' +
                        addr.add(5).readU8() + '.' +
                        addr.add(6).readU8() + '.' +
                        addr.add(7).readU8();
                    var key = ip + ':' + port;
                    if (!conns[key]) {
                        conns[key] = 1;
                        fh.write('WSACONNECT ' + key + '\n');
                    }
                }
            } catch (e) {}
        }
    });
} catch (e) {}

// also hook GetAddrInfoW for DNS lookups
try {
    var gai = WS2.getExportByName('GetAddrInfoW');
    Interceptor.attach(gai, {
        onEnter: function (args) {
            try {
                var host = args[0].readUtf16String();
                if (host) {
                    fh.write('DNS ' + host + '\n');
                }
            } catch (e) {}
        }
    });
} catch (e) {}

// also hook getaddrinfo (ANSI)
try {
    var gaiA = WS2.getExportByName('getaddrinfo');
    Interceptor.attach(gaiA, {
        onEnter: function (args) {
            try {
                var host = args[0].readUtf8String();
                if (host) {
                    fh.write('DNS-A ' + host + '\n');
                }
            } catch (e) {}
        }
    });
} catch (e) {}

send({t: 'ready-connect-probe'});
