# analyze29c.py - the decisive sort: for every banked fence29 candidate,
# compare against the unit's v5-marshal co_code.
#   identical  -> the at-rest STAMP recurring in heap (no recovery)
#   different  -> REAL RESTORED WORDCODE captured from live execution:
#                 build dec_<name>_L<line>.marshal (the unit's code
#                 object with co_code replaced) - immediately
#                 source-ifiable through the round-trip lane.
import collections
import glob
import json
import marshal
import os
import types

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
OUT = os.path.join(ORACLE, 'out')
RTP = os.path.join(OUT, 'fence29')
V5D = os.path.join(OUT, 'v5')
DEC = os.path.join(RTP, 'dec')
os.makedirs(DEC, exist_ok=True)

import opcode
VALID = {i for i, nm in enumerate(opcode.opname)
         if not nm.startswith('<')}
NAME_OPS = {'LOAD_GLOBAL', 'STORE_GLOBAL', 'LOAD_NAME', 'STORE_NAME',
            'DELETE_NAME', 'LOAD_ATTR', 'STORE_ATTR', 'IMPORT_NAME',
            'IMPORT_FROM', 'LOAD_METHOD'}
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)


def utf16ish(b):
    s = b[:256]
    if not s:
        return False
    nulls = s.count(0)
    printable = sum(1 for x in s if 32 <= x < 127)
    return (nulls + printable) / len(s) >= 0.80 and nulls > len(s) * 0.25


def soupish(code):
    if len(code) < 16:
        return False
    args_zero = sum(1 for i in range(1, len(code), 2)
                    if code[i] == 0)
    if args_zero < (len(code) // 2) * 0.9:
        return False
    popcount = sum(1 for i in range(0, min(len(code), 64), 2)
                   if code[i] in (0x01, 0x02, 0x1b, 0x10, 0x48))
    return popcount >= 8


def plain_ok(co, code):
    L = len(code)
    nnames = len(co.co_names or ())
    nloc = len(co.co_varnames or ())
    nconst = len(co.co_consts or ())
    nd = len(co.co_freevars or ()) + len(co.co_cellvars or ())
    offs = {0}
    start = 0
    for i in range(0, len(co.co_lnotab or b''), 2):
        start += co.co_lnotab[i]
        offs.add(start)
    for i in range(0, L, 2):
        op = code[i]
        if op not in VALID:
            return False
        arg = code[i + 1] if i + 1 < L else 0
        nm = opcode.opname[op]
        if op < opcode.HAVE_ARGUMENT and arg != 0:
            return False
        if nm in ('LOAD_FAST', 'STORE_FAST', 'DELETE_FAST') and arg >= nloc:
            return False
        if nm in NAME_OPS and arg >= nnames:
            return False
        if nm == 'LOAD_CONST' and arg >= nconst:
            return False
        if nm in ('LOAD_DEREF', 'STORE_DEREF', 'DELETE_DEREF',
                  'LOAD_CLOSURE') and arg >= nd:
            return False
        if op in JREL:
            t = i + 2 + arg
            if not (0 <= t < L) or t % 2:
                return False
        elif op in JABS:
            if not (0 <= arg < L) or arg % 2:
                return False
    for o in offs:
        if o >= L or o % 2:
            return False
    return True


# the unit code objects (the authoritative metadata)
units = {}
for p in glob.glob(os.path.join(V5D, 'v5_*.marshal')):
    try:
        top = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(top, types.CodeType):
        continue
    stack = [(top, 0)]
    while stack:
        c, d = stack.pop()
        if d > 20:
            continue
        units[(str(c.co_name), c.co_firstlineno)] = c
        for k in c.co_consts:
            if isinstance(k, types.CodeType):
                stack.append((k, d + 1))

report_path = os.path.join(RTP, 'analyze29b_report.json')
verdicts = json.load(open(report_path))
cands = {}
import re
for p in glob.glob(os.path.join(RTP, 'recovered_*.bin')):
    m = re.match(r'recovered_(.+)_L(\d+)\.bin', os.path.basename(p))
    if not m:
        continue
    name = m.group(1).replace('_L%d' % int(m.group(2)), '')
    # names may contain underscores; recover (name, line) from report
    line = int(m.group(2))
    cands[p] = line
# match report rows to files by line + name suffix
rows = []
for v in verdicts:
    line, nm = v['line'], v['name']
    fn = os.path.join(RTP, 'recovered_%s_L%d.bin'
                     % (nm.replace('.', '_'), line))
    if not os.path.exists(fn):
        continue
    run = open(fn, 'rb').read()
    co = units.get((nm, line))
    if co is None:
        rows.append((nm, line, 'NO-MARSHAL', None))
        continue
    same = bytes(co.co_code) == run
    if same:
        state = 'STAMP-RECURRENCE'
    elif utf16ish(run):
        state = 'UTF16-JUNK'
    elif soupish(run):
        state = 'SOUP'
    elif plain_ok(co, run):
        state = 'RESTORED!!'
    else:
        state = 'OTHER-NEW'
    rows.append((nm, line, state, run[:8].hex()))
    if state == 'RESTORED!!':
        dec_co = co.replace(co_code=run)
        with open(os.path.join(
                DEC, 'dec_%s_L%d.marshal'
                % (nm.replace('.', '_'), line)), 'wb') as f:
            marshal.dump(dec_co, f)

cnt = collections.Counter(r[2] for r in rows)
print('sort verdicts:', dict(cnt))
print()
print('--- RESTORED!! (live-captured wordcode, ready to decode) ---')
for nm, line, st, head in sorted(rows, key=lambda r: r[1]):
    if st == 'RESTORED!!':
        print('   L%-7d %-30s head=%s' % (line, nm[:30], head))
print()
print('--- STAMP/JUNK recurrences (no new info) ---')
for nm, line, st, head in sorted(rows, key=lambda r: r[1]):
    if st in ('STAMP-RECURRENCE', 'UTF16-JUNK', 'SOUP'):
        print('   L%-7d %-30s %s' % (line, nm[:30], st))
with open(os.path.join(RTP, 'analyze29c_report.json'), 'w') as f:
    json.dump([{'name': nm, 'line': line, 'state': st,
                'head': head} for nm, line, st, head in rows],
              f, indent=1)
print('-> dec marshals written:', len(os.listdir(DEC)))
print('ANALYZE29C DONE')
