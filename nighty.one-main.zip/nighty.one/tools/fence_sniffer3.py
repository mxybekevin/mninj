"""
fence_sniffer3.py - high-frequency window sweeps around known armed buffers.

The fence copy of an armed code object lives in the python heap NEAR the
original bytes object (observed: fence descriptor + content allocated
within ~4KB of the freed original buffer).

Method:
  * parse fence_calls.log 'call' entries -> buffer addresses
  * for each, sweep a +-64KB page window at full speed
  * any page read that differs from the last version of that page is
    stored with a timestamp (no marker matching; post-process offline)
  * saves to fence_snaps/windows.marshal

usage: python fence_sniffer3.py <pid>
"""
import ctypes
import marshal
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")
os.makedirs(SNAPS, exist_ok=True)
CALLS_LOG = os.path.join(OUT, "fence_calls.log")
STORE = os.path.join(SNAPS, "windows.marshal")

pid = int(sys.argv[1])
k32 = ctypes.WinDLL("kernel32", use_last_error=True)

PROCESS_VM_READ = 0x0010
PROCESS_QUERY_INFORMATION = 0x0400

h = k32.OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, False, pid)
if not h:
    print("[-] OpenProcess failed:", k32.GetLastError())
    sys.exit(1)
print("[+] target pid %d" % pid)

def rpm(addr, size):
    buf = ctypes.create_string_buffer(size)
    got = ctypes.c_size_t()
    ok = k32.ReadProcessMemory(h, ctypes.c_void_p(addr), buf, ctypes.c_size_t(size),
                               ctypes.byref(got))
    if not ok:
        return None
    return buf.raw[:got.value]

PAGE = 0x1000
WINDOW_PAGES_BEFORE = 16
WINDOW_PAGES_AFTER = 48

windows = {}     # window_key(page_addr of center) -> set of pages tracked implicit
pages = {}       # page_addr -> {"versions": [(t, bytes)...], "last": bytes}
file_pos = [0]

def harvest():
    if not os.path.exists(CALLS_LOG):
        return
    with open(CALLS_LOG, "r", encoding="utf-8", errors="replace") as f:
        f.seek(file_pos[0])
        data = f.read()
        file_pos[0] = f.tell()
    for line in data.splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[1] == "call":
            try:
                cid = int(parts[2])
                ptr = int(parts[3])
            except ValueError:
                continue
            if not ptr:
                continue
            key = (ptr >> 12) << 12
            if key not in windows:
                windows[key] = ptr
                print("[+] tracking window @%#x (buf %#x)" % (key, ptr))

t0 = time.time()
last_save = 0.0
read_ok = [0]
read_fail = [0]
alive = ctypes.c_ulong()

def sweep():
    changed = 0
    now = time.time()
    for key in list(windows.keys()):
        for pi in range(-WINDOW_PAGES_BEFORE, WINDOW_PAGES_AFTER):
            pa = key + pi * PAGE
            ent = pages.get(pa)
            if ent is None:
                ent = pages.setdefault(pa, {"versions": [], "last": None})
            try:
                content = rpm(pa, PAGE)
            except Exception:
                content = None
            if content is None:
                read_fail[0] += 1
                continue
            read_ok[0] += 1
            if content != ent["last"]:
                ent["last"] = content
                if not ent["versions"] or ent["versions"][-1][1] != content:
                    ent["versions"].append((now - t0, content))
                    if len(ent["versions"]) > 600:
                        ent["versions"].pop(0)
                changed += 1
    return changed

def save():
    try:
        payload = {a: {"versions": [(t, c) for t, c in e["versions"]]}
                   for a, e in pages.items()}
        tmp = STORE + ".tmp"
        with open(tmp, "wb") as f:
            marshal.dump(payload, f, 2)
        os.replace(tmp, STORE)
    except Exception as ex:
        print("[!] save fail %r" % ex)

while True:
    harvest()
    sweep()
    now = time.time()
    if now - last_save >= 2.0:
        save()
        total_v = sum(len(e["versions"]) for e in pages.values())
        print("[%7.2fs] windows=%d pages=%d versions=%d ok=%d fail=%d" % (
            now - t0, len(windows), len(pages), total_v, read_ok[0], read_fail[0]),
            flush=True)
        last_save = now
    if k32.GetExitCodeProcess(h, ctypes.byref(alive)) and alive.value != 259:
        break
    if not windows:
        time.sleep(0.002)

print("[*] target gone; final save")
save()
total_v = sum(len(e["versions"]) for e in pages.values())
print("[done] pages=%d versions=%d ok=%d fail=%d" % (
    len(pages), total_v, read_ok[0], read_fail[0]))
