"""
wordcode.py - THE correct CPython 3.6-3.8 (wordcode) decoder + full re-match.

In wordcode, EVERY instruction occupies exactly 2 bytes: [op][arg].
No-argument ops have a padding arg (usually 0x00). All prior tools in this
project wrongly stepped 1 byte for no-arg ops, mis-aligning everything
downstream. This module provides the correct primitives and re-runs:
  1. plain-run extraction from capture streams (correct alignment)
  2. exact-length unit matching with lnotab validation (correct boundaries)
  3. module fragment placement
"""
import bisect
import glob
import marshal
import opcode
import os
import pickle
import struct
import re

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
SNAPS = os.path.join(OUT, "fence_snaps")

VALID = {i for i, nm in enumerate(opcode.opname) if not nm.startswith("<")}
# wordcode: everything is 2 bytes; HAS_ARG only describes semantic arg use
JREL = set(opcode.hasjrel)
JABS = set(opcode.hasjabs)


def decode_ok(code):
    """Wordcode decode: every 2-byte slot must hold a valid opcode.
    Returns set of instruction start offsets or None."""
    n = len(code)
    if n % 2:
        return None
    b = set()
    for i in range(0, n, 2):
        if code[i] not in VALID:
            return None
        b.add(i)
    return b


def lnotab_offsets(lnotab):
    offs = {0}
    start = 0
    for i in range(0, len(lnotab), 2):
        start += lnotab[i]
        offs.add(start)
    return offs


def full_validate(cand, offs):
    """Length, decode, boundary-set checks for a whole unit body."""
    b = decode_ok(cand)
    if b is None:
        return None
    if offs and not offs.issubset(b):
        return None
    return b


def load_unit_candidates():
    """All (pkl-unit + live-tree) armed code buffers to match."""
    with open(os.path.join(OUT, "nighty_units.pkl"), "rb") as f:
        pkl_units = pickle.load(f)
    targets = {}
    n_skipped = 0
    for u in pkl_units:
        code = bytes(u.get("code") or b"")
        lnt = u.get("lnotab", b"")
        if not code:
            continue
        if not isinstance(lnt, (bytes, bytearray)):
            n_skipped += 1
            continue
        if code[0] in (0x74, 0x90) and b"\x83\x00" in code[:8]:
            targets.setdefault(len(code), []).append(u)
    print("pkl armed targets: %d lengths (skipped %d unresolved-lnotab)" % (
        len(targets), n_skipped))
    return targets


def extract_runs(stream_paths, max_tail_bytes=800 * 1024 * 1024):
    runs = set()
    for name in stream_paths:
        p = os.path.join(SNAPS, name)
        if not os.path.exists(p):
            continue
        size = os.path.getsize(p)
        skip = 0
        if name == "heap_stream.bin" and size > max_tail_bytes:
            with open(p, "rb") as f:
                pos = size - max_tail_bytes
                f.seek(pos)
                while pos < size - 16:
                    head = f.read(16)
                    addr, ln_, t_ms = struct.unpack("<QII", head)
                    if 0x1000000 < addr < 0x7FFFFFFFF000 and ln_ == 0x1000:
                        break
                    pos += 1
                    f.seek(pos)
                skip = pos
        n = 0
        with open(p, "rb") as f:
            if skip:
                f.seek(skip)
            while True:
                head = f.read(16)
                if len(head) < 16:
                    break
                addr, ln_, t_ms = struct.unpack("<QII", head)
                if ln_ == 0 or ln_ > 2 * 1024 * 1024:
                    break
                payload = f.read(ln_)
                if len(payload) < ln_:
                    break
                n += 1
                extract_runs_page(payload, runs)
        print("  %s: %d records -> %d unique runs" % (name, n, len(runs)), flush=True)
    for wm in ("windows.marshal", "windows_run1.marshal"):
        p = os.path.join(SNAPS, wm)
        if not os.path.exists(p):
            continue
        try:
            obj = marshal.loads(open(p, "rb").read())
        except Exception:
            continue
        for key, val in obj.items():
            if isinstance(val, dict) and "versions" in val:
                for t, b in val["versions"]:
                    extract_runs_page(b, runs)
    return list(runs)


def extract_runs_page(payload, runs):
    """Wordcode-correct maximal-run extraction from one captured page."""
    n = len(payload) & ~1
    pos = 0
    while pos < n - 6:
        if payload[pos] not in VALID:
            pos += 2 if pos % 2 == 0 else 1
            continue
        # extend forward while slots are valid
        q = pos
        while q < n and payload[q] in VALID:
            q += 2
        length = q - pos
        if 16 <= length <= 8192:
            runs.add(bytes(payload[pos:q]))
        pos = q + 2 if q > pos else pos + 2
        # also walk backward: try to extend the run to odd offsets
    # odd-aligned companion pass (captures can start mid-slot)
    pos = 1
    while pos < n - 6:
        if payload[pos] not in VALID:
            pos += 2
            continue
        q = pos
        while q < n and payload[q] in VALID:
            q += 2
        length = q - pos
        if 16 <= length <= 8192:
            runs.add(bytes(payload[pos:q]))
        pos = q + 2 if q > pos else pos + 2


def match_all():
    streams = ("hammer_stream.bin", "grab_stream.bin")
    print("extracting runs (wordcode-correct)...")
    runs = extract_runs(list(streams))
    print("unique runs: %d" % len(runs))

    runs_by_len = {}
    for r in runs:
        runs_by_len.setdefault(len(r), []).append(r)

    targets = load_unit_candidates()
    matched = {}       # bytes(armed) -> plaintext candidate
    report = []
    for L, units in sorted(targets.items()):
        cands = runs_by_len.get(L, [])
        for u in units:
            code = bytes(u["code"])
            offs = lnotab_offsets(u.get("lnotab", b""))
            best = None
            for r in cands:
                if full_validate(r, offs) is not None:
                    best = r
                    break
            name = str(u.get("name"))
            fl = u.get("firstlineno")
            if best is not None:
                matched[code] = best
                report.append("HIT   %-34s L%-6d len=%-6d cands=%d" % (name[:34], fl, L, len(cands)))
            else:
                report.append("miss  %-34s L%-6d len=%-6d cands=%d" % (name[:34], fl, L, len(cands)))

    print("matched units: %d / %d" % (
        len(matched), sum(len(v) for v in targets.values())))
    with open(os.path.join(OUT, "wordcode_match_report.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(report))
    with open(os.path.join(OUT, "wordcode_matches.pkl"), "wb") as f:
        pickle.dump(matched, f)
    print("saved wordcode_matches.pkl")
    return matched


if __name__ == "__main__":
    match_all()
