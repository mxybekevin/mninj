# audit_final.py - THE FULL ANTI-IMPOSTOR INVARIANT over Nighty.py.
# Three truth banks, every shipped unit judged:
#   A. dec/recovered/live/post/vsrc39 (armored main module evidence)
#   B. PYZ plain pycs (support modules - the 339 decompiled units)
#   C. verdicts graded: IDENTICAL / JUMP-ONLY / EQUIV-n / HARD
import glob
import marshal
import os
import py_compile
import struct
import re
import types as _t
from collections import defaultdict

ORACLE = r'C:\Users\brian\Downloads\Nighty\oracle'
EXTRACT = r'C:\Users\brian\Downloads\Nighty\Nighty.exe_extracted'
PYZD = os.path.join(EXTRACT, 'PYZ.pyz_extracted')
NIGHTY_PY = (r'D:\SSD-Offload\brian\Downloads\Nighty'
             r'\NightyRecovered\Nighty.py')
OUTDIR = r'C:\Users\brian\AppData\Local\Temp\opencode'
RTP43 = os.path.join(ORACLE, 'out', 'fence43')


def ARMED_HEAD(b):
    return b is not None and len(b) >= 4 and b[0] == 0x74 \
        and b[2:4] == b'\x83\x00'


# ---------- sections ----------
headers = []
pat = re.compile(r'^#\s*([\w.]+)\s*\(original line (\d+)\)')
with open(NIGHTY_PY, 'r', encoding='utf-8', errors='replace') as f:
    for idx, line in enumerate(f, 1):
        m = pat.match(line.strip())
        if m:
            headers.append((idx, m.group(1), int(m.group(2))))

sections_by_pos = sorted(headers)


def section_for(defline):
    best = None
    for h in sections_by_pos:
        if h[0] <= defline:
            best = h
        else:
            break
    return (None, None) if best is None else (best[1], best[2])


# ---------- compile the shipped file ----------
tmp_pyc = os.path.join(RTP43, 'audit_final.pyc')
py_compile.compile(NIGHTY_PY, cfile=tmp_pyc, doraise=True)
with open(tmp_pyc, 'rb') as f:
    top = marshal.loads(f.read()[16:])

funcs = {}
stack = [(top, 0)]
while stack:
    co, d = stack.pop()
    for k in co.co_consts:
        if isinstance(k, _t.CodeType):
            stack.append((k, d + 1))
    if co.co_name == '<module>':
        continue
    name, orig = section_for(co.co_firstlineno)
    if name is None:
        continue
    funcs.setdefault((name, orig), []).append(bytes(co.co_code))
print('sections: %d   compiled units: %d'
      % (len(headers), len(funcs)))

# ---------- bank A: main-module evidence ----------
evA = defaultdict(list)     # name -> [(line, bytes, src)]


def addA(co, src):
    if ARMED_HEAD(co.co_code):
        return
    evA[str(co.co_name)].append(
        (co.co_firstlineno, bytes(co.co_code), src))


for d in ('fence29', 'fence32', 'fence37'):
    for p in glob.glob(os.path.join(ORACLE, 'out', d,
                                    'recovered_*.bin')):
        base = os.path.basename(p)[len('recovered_'):-4]
        m = re.match(r'(.+)_L(\d+)$', base)
        if m:
            evA[m.group(1)].append((int(m.group(2)),
                                    open(p, 'rb').read(), d))

for p in glob.glob(os.path.join(ORACLE, 'out', '*', 'live_*.bin')):
    base = os.path.basename(p)[len('live_'):-4]
    m = re.match(r'(.+)_L(\d+)$', base)
    if m:
        evA[m.group(1)].append((int(m.group(2)),
                                open(p, 'rb').read(), 'live'))

for d in ('fence29', 'fence32', 'fence33', 'fence34', 'fence35',
          'fence36', 'fence37', 'fence38', 'fence39', 'fence40'):
    for p in glob.glob(os.path.join(ORACLE, 'out', d,
                                    'post_*.marshal')):
        base = os.path.basename(p)[len('post_'):-8]
        m = re.match(r'(.+)_L(\d+)$', base)
        if not m:
            continue
        try:
            co = marshal.load(open(p, 'rb'))
        except Exception:
            continue
        if isinstance(co, _t.CodeType):
            addA(co, d + ':post')

for p in glob.glob(os.path.join(ORACLE, 'out', 'vsrc39',
                                'verified', '*.marshal')):
    try:
        co = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if isinstance(co, _t.CodeType):
        addA(co, 'vsrc39')

for p in glob.glob(os.path.join(ORACLE, 'out', 'decrypted',
                                'dec_*.marshal')):
    try:
        tco = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if not isinstance(tco, _t.CodeType):
        continue
    dstack = [tco]
    while dstack:
        c = dstack.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                dstack.append(k)
        if c.co_name != '<module>':
            addA(c, 'dec')

for p in glob.glob(os.path.join(ORACLE, 'out', 'dump',
                               'unitA_*.marshal')):
    try:
        c = marshal.load(open(p, 'rb'))
    except Exception:
        continue
    if isinstance(c, _t.CodeType):
        addA(c, 'unitA')

nA = sum(len(v) for v in evA.values())
print('bank A (main module): %d objects, %d names'
      % (nA, len(evA)))

# ---------- bank B: PYZ plain pycs ----------
evB = defaultdict(list)     # name -> [(module, line, bytes)]
n_pyc = 0
n_obj = 0
for p in glob.glob(os.path.join(PYZD, '**', '*.pyc'),
                   recursive=True):
    n_pyc += 1
    try:
        with open(p, 'rb') as f:
            data = f.read()
        if len(data) < 20:
            continue
        tco = marshal.loads(data[16:])
    except Exception:
        continue
    if not isinstance(tco, _t.CodeType):
        continue
    mod = os.path.relpath(p, PYZD).replace('\\', '.')[:-4]
    pstack = [(tco, 0)]
    while pstack:
        c, d = pstack.pop()
        for k in c.co_consts:
            if isinstance(k, _t.CodeType):
                pstack.append((k, d + 1))
        if c.co_name == '<module>':
            continue
        evB[str(c.co_name)].append((mod, c.co_firstlineno,
                                    bytes(c.co_code)))
        n_obj += 1
print('bank B (PYZ): %d pycs, %d objects, %d names'
      % (n_pyc, n_obj, len(evB)))


# ---------- graders ----------
def instr_stream(code):
    out = []
    i = 0
    L = len(code)
    pending = 0
    has_ext = False
    while i < L:
        op, arg = code[i], code[i + 1]
        if op == 144:
            pending = (pending | arg) << 8
            has_ext = True
            i += 2
            continue
        eff = pending | arg if has_ext else arg
        out.append((op, eff))
        pending = 0
        has_ext = False
        i += 2
    return out


def grade(a, b):
    if a == b:
        return 'IDENTICAL'
    if len(a) != len(b):
        return 'HARD-len'
    sa, sb = instr_stream(a), instr_stream(b)
    if len(sa) != len(sb):
        return 'HARD-ext'
    deltas = [i for i, (x, y) in enumerate(zip(sa, sb))
              if x != y]
    if not deltas:
        return 'IDENTICAL-ext'
    op_d = sum(1 for i in deltas if sa[i][0] != sb[i][0])
    arg_d = len(deltas) - op_d
    import opcode
    jops = set(opcode.hasjrel) | set(opcode.hasjabs)
    if op_d == 0 and all(sa[i][0] in jops for i in deltas):
        return 'JUMP-%d' % arg_d
    if op_d == 0 and arg_d <= 2:
        return 'EQUIV-%darg' % arg_d
    if op_d == 0:
        return 'ARG-%d' % arg_d
    return 'HARD-op%d-arg%d' % (op_d, arg_d)


# ---------- audit ----------
SAFE_SRC = ('dec', 'unitA', 'live', 'vsrc39')


def is_safe(src):
    return src in SAFE_SRC or src.endswith(':post')


sec_by_name = {}
for (n, o) in funcs:
    sec_by_name.setdefault(n, []).append(o)
for k in sec_by_name:
    sec_by_name[k].sort()

report = open(os.path.join(OUTDIR, 'audit_final_report.txt'), 'w', 1)
match, mism, unknown = [], [], []
verdicts = {}
for (name, orig), codes in sorted(funcs.items()):
    mine = max(codes, key=len)
    truth = None
    src = None
    candA = evA.get(name) or []
    safeA = [e for e in candA if is_safe(e[2])]
    unsaf = [e for e in candA if not is_safe(e[2])]


    def pick(cands):
        if not cands:
            return None, None
        exact = [e for e in cands if e[0] == orig]
        if exact:
            return exact[0][1], exact[0][2]
        if len(cands) == 1:
            return cands[0][1], cands[0][2]
        if len(cands) > 1 and name in sec_by_name:
            order = sec_by_name[name]
            if orig in order:
                idx = order.index(orig)
                cl = cands[:]
                cl.sort(key=lambda e: e[0])
                sel = cl[min(idx, len(cl) - 1)]
                return sel[1], sel[2]
        return None, None


    truth, src = pick(safeA)
    if truth is None:
        # plausibility: unsafe banks only count when length is close
        t2, s2 = pick(unsaf)
        if t2 is not None and (abs(len(t2) - len(mine))
                               <= max(16, int(0.25 * len(t2)))):
            truth, src = t2, s2
    if truth is None:
        candB = evB.get(name) or []
        exactB = [e for e in candB if e[1] == orig]
        if exactB:
            truth, src = exactB[0][2], 'B:' + exactB[0][0]
        elif len(candB) == 1:
            t2 = candB[0][2]
            if abs(len(t2) - len(mine)) <= max(16, int(0.25 * len(t2))):
                truth, src = t2, 'B1:' + candB[0][0]
    if truth is None:
        unknown.append((name, orig, len(mine)))
        verdicts[(name, orig)] = 'NO-EVIDENCE'
        continue
    src = ('A:' + src) if not src.startswith('B') else src
    g = grade(mine, truth)
    verdicts[(name, orig)] = g
    if g == 'IDENTICAL' or g == 'IDENTICAL-ext':
        match.append((name, orig, src))
    else:
        mism.append((name, orig, len(mine), len(truth), g, src))

print()
print('=== IDENTICAL: %d ===' % len(match))
for name, orig, src in sorted(match, key=lambda x: x[1]):
    report.write('MATCH   %-42s L%-6d %s\n' % (name[:42], orig, src))
print('=== MISMATCH: %d ===' % len(mism))
for name, orig, cl, el, g, src in sorted(mism, key=lambda x: x[1]):
    line = 'MISM    %-42s L%-6d compiled=%-5d truth=%-5d %-14s (%s)' \
           % (name[:42], orig, cl, el, g, src)
    print(line)
    report.write(line + '\n')
print('=== NO-EVIDENCE: %d ===' % len(unknown))
for name, orig, cl in sorted(unknown, key=lambda x: x[1]):
    line = 'NOEV    %-42s L%-6d compiled=%d' % (name[:42], orig, cl)
    print(line)
    report.write(line + '\n')
hard = sum(1 for m in mism if m[4].startswith('HARD'))
print()
print('SUMMARY: sections=%d identical=%d mismatch=%d (HARD %d, '
      'JUMP %d, EQUIV %d, ARG %d) unknown=%d'
      % (len(funcs), len(match), len(mism), hard,
         sum(1 for m in mism if m[4].startswith('JUMP')),
         sum(1 for m in mism if m[4].startswith('EQUIV')),
         sum(1 for m in mism if m[4].startswith('ARG')),
         len(unknown)))
report.close()
print('report -> audit_final_report.txt')
