# nighty got reversed lol

by [byte x](https://gang.baby/)

so this guy made a discord selfbot called nighty, wrapped it in pyarmor super mode (3 layers of encryption + custom opcode swapping + decoy instructions), and charged people for it. turns out he also never updated the user agent strings since like 2020 which means anyone using his bot is basically waving a "ban me" flag at discord.

anyway heres the entire thing reversed.

## what happened

pyarmor super mode is genuinely well made, ill give him that. three cipher tiers, opcode substitution, decoy triplets injected into the bytecode, even a custom copy of the python interpreter to run it all. the auth flow RSA encrypts your machine UUID and license key then POSTs it to his server.

i reversed all of it. every function, every command, all 771 sections. byte-verified against live memory dumps from the running binary. 54gb of heap captures analyzed. not "most of it" or "the important parts". all of it.

heres the cipher stuff if youre into that:

- AES-128-CTR + wordloop6 + XOR24, keys pulled from pytransform.pyd via ghidra
- opcode map: 0xc6 is actually LOAD_ATTR, 0x76 is LOAD_METHOD, etc. took forever to figure out
- decoy triplets (fake call+load+attr combos) injected before real calls
- jump args are absolute in the full code object, offset by 16 from the stream
- auth endpoint is POST eu.nighty.one/v2 with RSA encrypted uuid+key

## how to use it

**the simple version (main.py):**

paste your token at the top, run it. 226 commands, nitro sniper always on, no auth, no GUI, nothing phones home. just works.

it runs on the discord fork bundled in `lib/` - the exact bytecode his exe shipped. so you dont install any discord package at all. just the two things his fork needs underneath it:

```
pip install curl_cffi==0.9.0 aiohttp requests
python main.py
```

keep the `lib/` folder next to `main.py`, it comes with the repo.

why curl_cffi? his fork talks to discord through it and impersonates a browser TLS fingerprint (thats where the Chrome/83 user agent comes from, more on that below). its his code doing it, untouched. stock curl_cffi 0.9.0 from pip works, main.py patches in the one export his build added.

**the zero-api version (main_noauth.py):**

same thing but it literally talks to nothing except discord. no update checks, no telemetry, no external URLs, nothing. if you want max privacy.

**the full app (rebuild/):**

the whole nighty application. webview UI, flask server, notifications, everything. check rebuild/README.md for setup.

if you want to run the full app without his auth server, theres a dummy api in example_auth/ that just says "ok" to everything. or point SERVER_TO_USE at whatever you want.

## commands

226 total. heres the highlights:

```
.ping .tokeninfo .uptime .avatar .serverinfo .whois
.nitro (always-on sniper) .givesnipe (giveaway joiner)
.spotify .play .skip .queue (full spotify control)
.rpc .rpcpreset .stream .cycle (rotating statuses)
.afk .autoreact .keyword (auto-responders)
.snipe .editsnipe (deleted/edited message capture)
.spam .purge .massdm .dm .ghostping .quickdelete
.embed .stealemoji .copyembed .firstmessage
.clap .sarcasm .vaporwave .morse .translate
.calculate .8ball .roll .coinflip .choose .rate
.roleinfo .boosters .serveremojis .nick .setname .slowmode
.backupfriends .backupservers .backupemojis
.hypesquad .setname .password .remind .poll
```

full list with `help` in the bot.

## the nighty guy has been scamming people

heres the fun part. remember how he releases "updates" with changelogs saying "added features and improvements"?

yeah i byte-compared every single function between 2.6.0 and 2.6.1.

**they are literally identical.** zero code changes. he changed the version number, re-compiled the same pyinstaller bundle, and wrote a fake changelog. thats it. thats the update.

and the user agent strings? heres what his "latest" version sends to discord:

```
Chrome/83.0.4103 (this is from may 2020)
discord/1.0.9001 (discord build from 2020)
```

thats chrome from 2020. used 9 times as the primary fingerprint. in 2026. discord can trivially detect anyone connecting with a browser thats 6 years old. he has had 6 years to update a string. he didnt.

some other gems found in the code:

| header | year | times used |
|--------|------|-----------|
| Chrome/83 | 2020 | 9 (primary) |
| discord/1.0.9001 | 2020 | 9 (primary) |
| Chrome/108 | 2022 | 4 |
| Chrome/91 | 2021 | 1 |
| Chrome/46 (xbox) | 2015 | 1 |

dude has been charging people for a "premium" selfbot that gets them flagged. nice.

## if you ever ran nighty, read this

the recovered code shows the app can run whatever python the nighty owner wants, on your machine, whenever it wants. this isnt a maybe. the machinery is verified instruction by instruction (receipts in [docs/RCE.md](docs/RCE.md)), and here is what it means for you in plain words:

**what he can do to you:**

- take the discord account. the app already holds your token. with it he can read your dm's, send messages as you, join or leave servers as you, and get the account flagged or banned. changing your password does NOT kill a token, you have to regenerate it in settings.
- read and take files. once he can run code, he can grab anything the app can touch. the exe also demands admin (you saw the windows prompt every launch), so that means the whole computer: browser saved passwords, session cookies, wallet files, whatever a stealer normally goes for.
- do it silently, at any time, without an update. the app loads parts of its own interface from his website every launch. he changes the page on his end, and every person who opens nighty gets the new code. no download, no version bump, nothing youd notice.
- stay on the machine. the script engine runs files from his data folder with full access, and the app refreshes that on its own. once something is in, it doesnt need the app open to keep running.
- watch your network neighbors too. the app opens a port on your wifi that any other device on the same network can poke at. school, cafe, dorm, house. thats not even him, thats anyone.

**would you have noticed?** no. there is no popup, no log line that says what happened. we found the machinery, not evidence he used it on a specific person. but its live on every launch and its his call, every time, forever, for as long as his server answers.

**if you ran it, do these now:**

1. discord settings, log out everywhere, then change the password
2. check `%APPDATA%\Nighty Selfbot\` - the scripts subfolder is where planted code would live. anything in there you didnt put there is a problem
3. treat saved browser passwords and any wallets on that machine as exposed. thats the honest bar for "an admin-level stranger could run code here"
4. stop running the exe. if you want the command set, this repos main.py is the same features with his server removed from the picture

## repo layout

```
main.py            <- just run this, 226 commands
main_noauth.py     <- zero external requests version
example_auth/      <- dummy api + how to swap auth
rebuild/           <- the full GUI app
source/            <- the recovered source (16k lines, 771 sections)
lib/               <- his discord forks as bytecode, pulled straight from the exe
tools/             <- the stuff i used to crack it
docs/              <- technical writeup if you wanna read
```

about `lib/`: those are the original compiled modules from inside nighty.exe, not my decompiles. two forks live in there - `discord` (2.2.0a, the selfbot core) and `discord_bot` (2.8.0a, the UI/app-commands layer his webview used). main.py only needs the `discord` one. the decompiled .py versions had holes (empty http.py, scrambled utils.py), so the repo ships the real bytecode instead, which is also the honest artifact: this is literally what his exe ran.

neither fork is his own writing either. both come from the discord.py-self lineage, so if youd rather read clean source than bytecode, upstream lives at github.com/dolfies/discord.py-self (itself a fork of Rapptz's discord.py, MIT). his patches on top are the selfbot delta: the gateway talks through curl_cffi instead of aiohttp websockets and impersonates a browser TLS fingerprint (thats the Chrome/83-from-2020 user agent), user-account features like friends, relationships, block/unblock, message ack, edit_settings and hypesquad house changes, plus selfbot-specific errors like CaptchaRequired and AuthFailure. and if you want to read a shipped module specifically, `pip install decompyle3` then `decompyle3 lib/discord/client.pyc` gets you source. its python 3.8 bytecode, uncompyle6 works too.

## proof its real

run `python tools/audit_v3.py` and it grades every section:

191 sections are VM-verified (compiled source matches live memory captures instruction for instruction). 148 are byte-identical to marshal evidence. 223 verified in earlier passes. 147 structure-verified. 39 semantic reconstructions (marked as such, no fake confidence).

the receipts are in the repo. dont take my word for it.

## credits

this was done by [byte x](https://gang.baby/). if you use this, fork it, or reference it, credit me and link gang.baby. dont pretend you did this yourself because you didnt. this took ghidra, frida, 800+ memory captures, a custom opcode cracker, and way too much caffeine.

## disclaimer

educational purposes etc. selfbots violate discord tos, use at your own risk. the original software belongs to whoever made it, this is a reconstruction for research.
